
import { EnvironmentService } from "@app/services/environment/environment.service";
import { AppEnvironmentConfig, DEFAULT_VALUES, ENV_VALUES } from "./environment.config";

export const environmentService = new EnvironmentService<AppEnvironmentConfig>();
export const environment: AppEnvironmentConfig = environmentService.initConfig(null, DEFAULT_VALUES, ENV_VALUES);
