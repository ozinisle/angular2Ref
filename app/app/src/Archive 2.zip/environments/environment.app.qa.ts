
import { EnvironmentEnum } from "@app/services/environment/environment.enum";
import { EnvironmentService } from "@app/services/environment/environment.service";
import { AppEnvironmentConfig, DEFAULT_VALUES, ENV_VALUES } from "./environment.config";

export const environmentService = new EnvironmentService<AppEnvironmentConfig>();
export const environment: AppEnvironmentConfig = environmentService.initConfig(EnvironmentEnum.QA, DEFAULT_VALUES, ENV_VALUES);
