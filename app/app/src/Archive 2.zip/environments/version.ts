export const version = {
  appversion: '{BUILD_VERSION}',
  timestamp: '{BUILD_TIMESTAMP}',
  build: '{BUILD_NUMBER}'
};
