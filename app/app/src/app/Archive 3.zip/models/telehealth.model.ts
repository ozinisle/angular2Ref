import {  ConsumerAllergy, ConsumerCondition, ConsumerVitals, Medication, TriageQuestion, VisitTopic } from "amwell-plugin";

export interface MutualAuthenticationResponse {
  result: number;
  errormessage: string;
  displaymessage: string;
  userAccessToken: string;
  sdkKey: string;
}

export interface TeleHealthDetails {
  teleHealthEligible: boolean;
  disclaimerFlag: boolean;
  wellConnectionIndicatorFlag: boolean;
  loaded: boolean;
}

export interface VisitInfo {
  consumerSourceId: string;
  callbackNumber: string;
  guestEmails?: string[];
}

export interface VisitTopics {
  shareHealthInformation?: boolean;
  topics: VisitTopic[];
  triageQuestions?: TriageQuestion[];
  otherTopic?: string;
}

export interface VitalsAndHistory {
  conditions?: ConsumerCondition[];
  allergies?: ConsumerAllergy[];
  medications?: Medication[];
  vitals?: ConsumerVitals;
  privacyAcknowledgement: boolean;
  mayShareHealthHistory: boolean;
}

export interface VitalsAndHistoryEligibility {
  conditions?: boolean,
  allergies?: boolean,
  medications?: boolean,
  vitals?: boolean
}

export interface ScheduleContext {
  consumerSourceId: string;
  providerSourceId: string;
  phoneNumber: string;
  timeSlot: string;
}

export interface CrediCardDetails {
  /**
   * The billing name associated with this payment method.
   */
   billingName: string;

   /**
    * The expiration month number associated with this payment method,
    * e.g. 1-Jan, 12-December.
    */
   expirationMonth: number;

   /**
    * The expiration year associated with this payment method, e.g. 2021.
    */
   expirationYear: number;

   /**
    * The digits of the currently stored credit card.
    */
   digits: string;

   /**
    * The credit card security code.
    */
   securityCode: string;
}
