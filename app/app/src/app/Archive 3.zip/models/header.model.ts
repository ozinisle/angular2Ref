export class HeaderInboxUnreadMsgCountReponse {
  unreadMessageCount: number;
}
