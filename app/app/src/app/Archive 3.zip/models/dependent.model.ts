export interface DependentModel {
  depId: number; // example: 123456786 Dependent ID
  firstName: string; // example: MAISIE
  lastName: string; // example: THOMAS
  middleInitial: string; // example: E
  relationship: string; // example: Spouse Member relation to the subscriber or logged in user Enum: Array [ 3 ]
  memNum: string; // example: 039800586000011 Member Number
  suffix: string; //  example: 01 Member suffix
  cardId: string; // example: XXP03980058611 Member Curd Number with Suffix
}
