export class MultiLingualFooterModel {
  footertext: string;
}

export class GetVitalsDataUpdatesRequestModel {
  useridin: string;
}

export class GetVitalsDataUpdatesResponseModel {
  dataLoadedDate: string;
}

export class SessionFadDataUpdatesModel {
  dataLoadedDate: string;
  lastUpdateDate: string;
}
