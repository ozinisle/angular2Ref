export class FooterGlobalModel {
  title: string;
  bcbslogo: string;
  facebookIcon: string;
  twitterIcon: string;
  linkedInIcon: string;
  youtubeIcon: string;
  appstoreIcon: string;
  googlePlayIcon: string;
  footerContent: string;
}
