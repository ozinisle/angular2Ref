export interface PharmacyLinkType {
  label: string;
  icon: string;
  url: string;
  isSSO: boolean;
  ssoType: string;
  isPhone: boolean;
  isExternal: boolean;
}
