import { PharmacyModel } from '../pages/my-pillpack/model/pillpack-generic.models';
import { PhoneNumberModel } from './phone-number.model';
import { LearnToLiveModel } from './learn-to-live.model';
export interface PostLoginModel {
  hasSS: boolean;
  hasCI: boolean;
  hasSSO: boolean;
  isCPDPEnrolled: boolean;
  isCPDPHandedoff: boolean;
  isCPDPPromotion: boolean;
  isKYMember: boolean;
  repPayeeFalg: string;
  isUnionBlueMember: boolean;
  phoneNumbers: PhoneNumberModel[];
  pharmacyLinks: PharmacyModel[];
  wellnessPrograms: LearnToLiveModel[];
  coverageEffecDt: string;
  showDemographicModel: boolean;
  ebillingEligibility: boolean;
  showEmailVerifyModal: boolean;
}
