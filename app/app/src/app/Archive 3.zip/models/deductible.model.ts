export interface DeductibleModel {
  memberName: string;
  isFirstCoverage?: boolean;
  isIndividual?: boolean;
  showHomePage?: boolean;
  networkStatus?: string;
  startDate: string;
  endDate: string;
  planName: string;
  type?: string;
  totalAmount?: number;
  contributed?: number;
  contributedLabel?: string;
  remaining?: number;
  remainingLabel?: string;
  limitations?: string;
  exceptions?: string;
  showDates?: boolean;
  coverageType?: string;
}
