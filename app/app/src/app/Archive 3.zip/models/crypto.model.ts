export interface CryptoModel {
  result: string;
  key1id: string;
  key1salt: string;
  key1iv: string;
  key1phrase: string;
  key2id: string;
  key2salt: string;
  key2iv: string;
  key2phrase: string;
}
