export interface LearnToLiveModel {
  name: string;
  url: string;
}
