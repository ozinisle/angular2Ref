import { RegType } from '@app/enums/reg-type.enum';

export interface LoginRequest {
  useridin: string;
  passwordin: string;
  regType?: RegType;
}
