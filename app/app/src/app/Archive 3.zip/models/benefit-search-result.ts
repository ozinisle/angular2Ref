export interface BenefitSearchResultItem {
    benefitShortDescription: string;
    benefitCategoryName: string;
    benefitCategoryID: number;
    cpcCode?: string;
    productType?: string;
    planName?: string;
}

export interface BenefitSearchResultGroup {
    cpcCode: string;
    productType: string;
    planName: string;
    benefits: BenefitSearchResultItem[];
}

export interface BenefitSearchResultResponse {
    searchResults: BenefitSearchResultGroup[];
}
