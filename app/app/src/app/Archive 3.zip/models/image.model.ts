export class Image {
  text: string;
  src: string;
  isVideo: boolean;
  videoUrl: string;
  urlLink: string;
  articleText: string;
  regularImages: string;
  articleUrl: string;
  title: string;
  mobileImages: string;
  mobilesrc: string;
  body: string;
}
