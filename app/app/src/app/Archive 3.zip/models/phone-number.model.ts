export interface PhoneNumberModel {
  text: string;
  number: string;
}
