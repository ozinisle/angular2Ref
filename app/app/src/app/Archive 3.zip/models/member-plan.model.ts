export interface MemberPlan {
    cardMemId: string;
    cardMemSuffix: string;
    activePlan: string;
    defaultPlan: string;
    futurePlan: string;
    planType: string;
    planName: string;
    planEffectiveDate: string;
    planEndDate: string;
}
