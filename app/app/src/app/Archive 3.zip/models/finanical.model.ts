import { LineChartOptionsInterface } from './financial-chart/financial-chart.interface';

export class TransactionInfo {
  amount: number;
  date: string;
  description: string;
  balance: number;
}

export class Finanical {
  acountNumber: string;
  planStartDate: string;
  planEndDate: string;
  chartOptions: LineChartOptionsInterface;
  description: string;
  type: string;
  isHeqAccount = true;
  isSavingsAccount = false;
  transactions: TransactionInfo[];
}
