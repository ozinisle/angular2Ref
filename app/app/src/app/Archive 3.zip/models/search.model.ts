export interface BenefitSearchCPC {
  cpcCode: string;
  planName: string;
  searchEnabled: boolean;
}

export interface BenefitSearchEnabledResponse {
  result: number;
  cpcCodeList: {
    searchableCPCs: BenefitSearchCPC[];
  };
}

export interface BenefitSearchCPCsList {
  cpcCode: string;
  planType: string;
  planName: string;
  groupName: string;
  subscriberId: string;
}
