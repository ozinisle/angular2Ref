export interface Health {
  allergies: string[];
  conditions: string[];
}

export interface ProfileInfo {
  useridin: string;
  fullName: string;
  userState: string;
  dob: string;
  address1: string;
  address2: string;
  city: string;
  state: string;
  zip: string;
  emailAddress: string;
  phoneNumber: string;
  phoneType: string;
  isVerifiedEmail: boolean;
  isVerifiedMobile: boolean;
  isEditableAddress: boolean;
  isDirectPay: boolean;
  isEmailOptedIn: boolean;
  isMobileOptedIn: boolean;
  hintQuestion: string;
  hintAnswer: string;
  gender: string;
  health: Health;
  dependents: any[];
  updatedEmailAddress: string;
  updatedPhoneNumber: string;
  memberSuffix: string;
}
