export interface LoginResponse {
  unreadMsgCount: string;
  hasDependents: string; // Should be a boolean
  scopename: string;
  HasActivePlan: string;
  planTypes: {
    vision: 'true' | 'false';
    medical: 'true' | 'false';
    dental: 'true' | 'false';
    CDH: 'true' | 'false';
  };
  destinationURL: string;
  isALG: string;
  access_token: string;
  refresh_token: string;
  firstName: string;
  isHEQ: string;
  syntheticID: string;
  migrationtype: string;
  userType: string;
  issued: string;
  access_token_expires: string;
  refresh_token_expires: string;
  memberPlans: string;
}
