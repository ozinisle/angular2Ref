export interface PlanInfo {
  groupUacc: string;
  covEffDate: string;
}

export interface AuthToken {
  unreadMsgCount: string;
  hasDependents: string; // Should be a boolean
  scopename: string;
  HasActivePlan: string;
  planTypes: {
    vision: string;
    medical: string;
    dental: string;
  };
  destinationURL: string;
  isALG: string;
  access_token: string;
  refresh_token: string;
  firstName: string;
  isHEQ: string;
  syntheticID: string;
  migrationtype: string;
  userType: string;
  issued: string;
  access_token_expires: string;
  refresh_token_expires: string;
  memberPlans: string;
  planInfo?: PlanInfo;
}
