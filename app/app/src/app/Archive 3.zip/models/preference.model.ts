export interface PreferenceCenterProgram {
  ID: string;
  displayName: string;
  customProperties?: Property[];
  filters: PreferenceCenterFilter[];
}

export interface PreferenceCenterFilter {
  id: string;
  channelID: string;
  selected: boolean;
}

export interface Property {
  key: string;
  value: string;
}

//This is part of the request object sent and service expect the names in TitleCase
export interface Preference {
  CID: string;
  CustomerDate: string;
  FilterID: string;
  PreferenceType: string;
  PreferenceAttributes: Property[];
}
