export interface Campaign2ComponentInputModelInterface {
  isShowOnlyWellNessConnectionImage(): boolean;
  setShowOnlyWellNessConnectionImage(showOnlyWellNessConnectionImage: boolean): Campaign2ComponentInputModel;

  isShowOnlyFindCareImage(): boolean;
  setShowOnlyFindCareImage(showOnlyFindCareImage: boolean): Campaign2ComponentInputModel;
}

export class Campaign2ComponentInputModel implements Campaign2ComponentInputModelInterface {
  private showOnlyWellNessConnectionImage = false;
  private showOnlyFindCareImage = false;

  public isShowOnlyWellNessConnectionImage(): boolean {
    return this.showOnlyWellNessConnectionImage;
  }

  public setShowOnlyWellNessConnectionImage(showOnlyWellNessConnectionImage: boolean): Campaign2ComponentInputModel {
    this.showOnlyWellNessConnectionImage = showOnlyWellNessConnectionImage;
    if (showOnlyWellNessConnectionImage) {
      this.showOnlyFindCareImage = false;
    }
    return this;
  }

  public isShowOnlyFindCareImage(): boolean {
    return this.showOnlyFindCareImage;
  }

  public setShowOnlyFindCareImage(showOnlyFindCareImage: boolean): Campaign2ComponentInputModel {
    this.showOnlyFindCareImage = showOnlyFindCareImage;
    if (showOnlyFindCareImage) {
      this.showOnlyWellNessConnectionImage = false;
    }
    return this;
  }
}
