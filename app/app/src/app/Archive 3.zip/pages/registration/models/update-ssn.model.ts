export class UpdateSsnModel {
  useridin: '';
  ssn: '';
}
