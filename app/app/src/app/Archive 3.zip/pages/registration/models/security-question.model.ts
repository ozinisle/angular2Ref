export interface SecurityQuestion {
  text: string;
  id: string;
  options: Option[];
}

export interface Option {
  label: string;
  value: string;
}
