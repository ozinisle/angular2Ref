import { AbstractControl } from '@angular/forms';
import { VerifyAccessCodeInputValidationResultModelInterface } from './registration.interfaces';

export class VerifyAccessCodeInputValidationResultModel implements VerifyAccessCodeInputValidationResultModelInterface {
  'isError' = false;
  'hasErrors' = false;
}

export class FormGroupControlsModel {
  [key: string]: AbstractControl;
}
