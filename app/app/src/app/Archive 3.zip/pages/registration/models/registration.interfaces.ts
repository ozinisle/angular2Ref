export interface VerifyAccessCodeInputValidationResultModelInterface {
  isError: boolean;
  hasErrors: boolean;
}
