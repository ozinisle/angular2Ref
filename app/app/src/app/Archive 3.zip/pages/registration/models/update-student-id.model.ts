export class UpdateStudentIdModel {
  useridin: '';
  studentid: '';
}
