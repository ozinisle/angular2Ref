import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MYBLUE } from '@app/app.constants';
import { UpdateSsnModel } from '@app/pages/registration/models/update-ssn.model';
import { UpdateStudentIdModel } from '@app/pages/registration/models/update-student-id.model';
import { AppService } from '@app/services/app.service';
import { ConstantsService } from '@app/services/constants.service';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { v4 as uuid } from 'uuid';

@Injectable({ providedIn: 'root' })
export class RegistrationService {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;

  constructor(private http: HttpClient, private constants: ConstantsService, private appService: AppService) {}

  buildHttpOptions() {
    const httpOptions = {
      headers: new HttpHeaders({
        uitxnid: 'APP_v5.0_' + uuid()
      })
    };
    MYBLUE.log("httpOptions", httpOptions.headers.get('uitxnid'));
    return httpOptions;
  }
  updateMemAuthInfo(request) {
    const generatedRequest = {
      ...request,
      useridin: this.useridin
    };
    return this.http.post(this.constants.updateMemAuthInfoUrl, generatedRequest, this.buildHttpOptions());
  }

  authWithSSN(request: UpdateSsnModel) {
    const generatedRequest = {
      ssn: 'XXXXX' + request.ssn,
      useridin: this.useridin
    };
    return this.http.post(this.constants.authWithSsnUrl, generatedRequest, this.buildHttpOptions());
  }

  handleError(response, errorCodes = null, errorMsg?: boolean) {
    this.appService.handleError(response, errorCodes, errorMsg);
  }

  sendaccesscode(requestData?, webUser?, resend?) {
    let request;
    if (webUser) {
      request = {
        ...requestData,
        useridin: this.useridin,
        userIDToVerify: this.useridin
      };
    } else {
      request = {
        useridin: this.useridin
      };
    }
    if (resend) {
      request = {
        ...requestData,
        editCommChannel: 'true'
      };
    }
    let url = this.constants.sendaccesscodeUrl;
    if (this.authToken?.scopename === 'REGISTERED-AND-VERIFIED' || this.authToken?.scopename === 'AUTHENTICATED-AND-VERIFIED') {
      url = this.constants.sendCommChlAccesscode;
      request = {
        useridin: this.useridin,
        mobile: this.useridin.indexOf('@') === -1 ? this.useridin : '',
        userIDToVerify: this.useridin
      };
      if (this.useridin.indexOf('@') !== -1) {
        request['email'] = this.useridin;
      }
    }

    return this.http.post(url, request, this.buildHttpOptions());
  }

  authStudentID(request: UpdateStudentIdModel) {
    const studentIdRequest = {
      studentid: request.studentid,
      useridin: this.useridin
    };
    return this.http.post(this.constants.authStudentIDUrl, studentIdRequest, this.buildHttpOptions());
  }

  authMedicareID(request: any) {
    const medicareIdRequest = {
      MBI: request.medicareid,
      useridin: this.useridin
    };
    return this.http.post(this.constants.authMedicareIDUrl, medicareIdRequest, this.buildHttpOptions());
  }

  authWithLn() {
    const generatedRequest = {
      useridin: this.useridin
    };
    return this.http.post(this.constants.authLnUrl, generatedRequest, this.buildHttpOptions());
  }

  postLnAnswers(generatedRequest) {
    return this.http.post(this.constants.validateLnAnsUrl, generatedRequest, this.buildHttpOptions());
  }

}
