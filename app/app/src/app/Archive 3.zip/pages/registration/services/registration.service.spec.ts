import { HttpClient } from '@angular/common/http';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed, inject } from '@angular/core/testing';

import { RegistrationService } from './registration.service';
import { ConstantsService } from '@app/services/constants.service';
import { AppService } from '@app/services/app.service';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { NgxsModule } from '@ngxs/store';

describe('RegistrationService', () => {
  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;
  let registrationService: RegistrationService;
  let constantsService: ConstantsService;
  let appService: AppService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, NgxsModule.forRoot(), NgxsSelectSnapshotModule.forRoot()],
      providers: [RegistrationService, ConstantsService, AppService]
    });

    httpClient = TestBed.inject(HttpClient);
    constantsService = TestBed.inject(ConstantsService);
    appService = TestBed.inject(AppService);
    httpTestingController = TestBed.inject(HttpTestingController);
    registrationService = new RegistrationService(httpClient, constantsService, appService);
  });

  it('exists', inject([RegistrationService], (service: RegistrationService) => {
    expect(service).toBeTruthy();
  }));

  describe('services', () => {
    it('endpoint: authentication/authwithssn', () => {
      registrationService.authWithSSN({ useridin: '', ssn: '' }).subscribe(response => {
        expect(response).toEqual({ result: 0 });
      });
      const mockResponse = {};
      const req = httpTestingController.expectOne(mockResponse);
      expect(req.request.method).toEqual('POST');
      req.flush({ result: 0 });
      httpTestingController.verify();
    });
  });
});
