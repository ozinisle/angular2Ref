import { RouterModule, Routes } from '@angular/router';
import { MemberInfoComponent } from './pages/member-info/member-info.component';
import { RegisterDetailComponent } from './pages/register-detail/register-detail.component';
import { SecurityComponent } from './pages/security-answers/security-answers.component';
import { SuccessInfoComponent } from './pages/success/success-info.component';
import { UpdatessnComponent } from './pages/updatessn/updatessn.component';
import { NgModule } from '@angular/core';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('./pages/register/register.module').then(m => m.RegisterModule)
  },
  {
    path: 'register',
    loadChildren: () => import('./pages/register/register.module').then(m => m.RegisterModule)
  },
  {
    path: 'register-detail',
    component: RegisterDetailComponent
  },
  {
    path: 'verification',
    loadChildren: () => import('./pages/verification/verification.module').then(m => m.VerificationModule)
  },
  {
    path: 'memberinfo',
    component: MemberInfoComponent
  },
  {
    path: 'updatessn',
    component: UpdatessnComponent
  },
  {
    path: 'success',
    component: SuccessInfoComponent
  },
  {
    path: 'securityanswers',
    component: SecurityComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RegistrationRoutingModule {}
