import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TextMaskModule } from 'angular2-text-mask';
import { AuthGuard } from '@app/guards/auth.guard';
import { MemberInfoComponent } from './pages/member-info/member-info.component';
import { RegisterDetailComponent } from './pages/register-detail/register-detail.component';
import { RegistrationService } from './services/registration.service';
import { UpdatessnComponent } from './pages/updatessn/updatessn.component';
import { IonicModule } from '@ionic/angular';
import { SecurityComponent } from './pages/security-answers/security-answers.component';
import { SuccessInfoComponent } from './pages/success/success-info.component';
import { AlertsModule } from '@app/components/alerts/alerts.module';
import { AppControlMessagesModule } from '@app/components/app-control-messages/app-control-messages.module';
import { AutofocusDirectiveModule } from '@app/directives/autofocus/autofocus.directive.module';
import { RegisterModule } from '@app/pages/registration/pages/register/register.module';
import { RegistrationRoutingModule } from '@app/pages/registration/registration-routing.module';
import { WordwrapModule } from '@app/directives/wordwrap/wordwrap.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  declarations: [RegisterDetailComponent, MemberInfoComponent, UpdatessnComponent, SuccessInfoComponent, SecurityComponent],
  exports: [],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    TextMaskModule,
    IonicModule,
    AlertsModule,
    RegisterModule,
    AppControlMessagesModule,
    AutofocusDirectiveModule,
    RegistrationRoutingModule,
    WordwrapModule,
    FontAwesomeModule
  ],
  providers: [AuthGuard, RegistrationService]
})
export class RegistrationModule {}
