import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { NgxsModule } from '@ngxs/store';
import { AlertService } from '@app/services/alert.service';
import { ConstantsService } from '@app/services/constants.service';
import { SwrveEventNames } from '@app/services/swrve.service';
import { ContactUsPage } from './contact-us.page';
import { IabService } from '@app/services/iab.service';
import { SwrveService } from '@app/services/swrve.service';
import { IonicModule } from '@ionic/angular';
import { AlertsComponent } from '@app/components/alerts/alerts.component';

describe('ContactUsPage', () => {
  let component: ContactUsPage;
  let fixture: ComponentFixture<ContactUsPage>;
  let iabservice: IabService;
  let swerveservice: SwrveService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [IonicModule, HttpClientTestingModule, RouterTestingModule, NgxsModule.forRoot([])],
      providers: [SwrveEventNames, IabService, ConstantsService, InAppBrowser, AlertService, CallNumber],
      declarations: [ContactUsPage, AlertsComponent]
    }).compileComponents();
    iabservice = TestBed.inject(IabService);
    swerveservice = TestBed.inject(SwrveService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactUsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check header title of component ', () => {
    const element = document.querySelector('ion-title');
    expect(element).toBeTruthy();
  });

  it('should check ion list header', () => {
    const element = document.querySelector('ion-list-header');
    expect(element).toBeTruthy();
  });

  it('should chceck links content', () => {
    const element = document.querySelector('.links');
    expect(element.textContent.length).toBeGreaterThan(0);
  });

  it('should call iabService create on openInAppBrowser', () => {
    const iabSpy = spyOn(iabservice, 'create');
    component.openInAppBrowser(null);
    expect(iabSpy).toHaveBeenCalled();
  });

  it('should call sendAppMessage on sendSwerve', () => {
    const swerveSpy = spyOn(swerveservice, 'sendAppMessage').and.returnValue(null);
    component.sendSwerve(null);
    expect(swerveSpy).toHaveBeenCalled();
  });

  it('Ion fab button check when anonymous user', () => {
    component.isAnonymousUser = true;
    component = fixture.componentInstance;
    fixture.detectChanges();
    const element = document.querySelector('ion-fab-button');
    expect(element).toBeTruthy();
  });

  it('shoul checktextHead content', () => {
    const swerveSpy = spyOn(swerveservice, 'sendAppMessage').and.returnValue(null);
    component.sendSwerve(null);
    expect(swerveSpy).toHaveBeenCalled();
  });

  it('shoul check textHead content', () => {
    const element = document.querySelector('.textHead');
    expect(element.textContent.length).toBeGreaterThan(0);
  });
});
