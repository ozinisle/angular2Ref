import { Component } from '@angular/core';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { from } from 'rxjs';
import { environment } from '@environments/environment';
import { IabService } from '@app/services/iab.service';
import { SwrveEventNames, SwrveService } from '@app/services/swrve.service';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { Location } from '@angular/common';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.page.html',
  styleUrls: ['./contact-us.page.scss']
})
export class ContactUsPage {
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;

  isAuthenticatedUser: boolean;
  isAnonymousUser: boolean;
  isRegisteredUser: boolean;
  anonymousFeedback = 'https://engage.bluecrossma.com/forms/submit-feedback';
  authenticatedSecureMessage = environment.secureMessageInquiryUrl;
  talkToDoctor = 'https://myblue.bluecrossma.com/health-plan/well-connection';

  constructor(
    public swrveEventNames: SwrveEventNames,
    private iabService: IabService,
    private swrveService: SwrveService,
    private callNumber: CallNumber,
    private location: Location
  ) {}

  openInAppBrowser(url) {
    this.iabService.create(url);
  }

  ionViewWillEnter() {
    this.swrveService.sendAppMessage(this.swrveEventNames.appScreenContactUs);
    this.isRegisteredUser = this.scopeName.includes('REGISTERED');
    this.isAuthenticatedUser = this.scopeName.includes('AUTHENTICATED');
    this.isAnonymousUser = !(this.isRegisteredUser || this.isAuthenticatedUser);
    if (this.isAuthenticatedUser) {
      this.swrveService.sendAppMessage(this.swrveEventNames.appClickHomeAuthenticatedContactUs);
    } else if (this.isRegisteredUser) {
      this.swrveService.sendAppMessage(this.swrveEventNames.appClickHomeRegisteredContactUs);
    } else if (this.isAnonymousUser) {
      this.swrveService.sendAppMessage(this.swrveEventNames.appClickHomeAnonymousContactUs);
    }
  }

  sendSwerve(event) {
    this.swrveService.sendAppMessage(event);
  }

  callHelpLine(number: string, swrveEventName: string) {
    from(this.callNumber.callNumber(number, true)).subscribe();
    this.sendSwerve(swrveEventName);
  }

  goBack() {
    this.location.back();
  }
}