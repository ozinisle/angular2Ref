import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MyBenefitDetailsResolverService } from './benefitdetails/benefit-details.resolver';
import { MyBenefitsResolverService } from './benefits/benefits.resolver';
import { MyPlansComponent } from './my-plans.component';
import { MY_PLANS_ROUTER } from './my-plans.routing';
import { MyPlansService } from './my-plans.service';
import { MatExpansionModule } from '@angular/material/expansion';
import { IonicModule } from '@ionic/angular';
import { BenefitDetailsComponent } from './benefitdetails/benefit-details.component';
import { BenefitsComponent } from './benefits/benefits.component';
import { BenefitsFilterPopoverComponent } from './benefitsFilterPopover/benefits-filter-popover.component';
import { FilterPopoverComponent } from './filterPopover/filter-popover.component';
import { PlandetailsComponent } from './plandetails/plandetails.component';
import { PopoverComponent } from './popover/popover.component';
import { CamelCaseModule } from '@app/pipes/camelcase/camel-case.module';
import { FpoLayoutModule } from '@app/components/fpo-layout/fpo-layout.module';
import { IabClickBlockModule } from '@app/components/Iab-component/iab-click-block.module';
import { MatchTextHighlightModule } from '@app/pipes/match-text-highlight/match-text-highlight.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { IntegratedPlanAcccessModule } from '../integrated-plan-access/integrated-plan-access.module';
import { ContentLinksDirective } from './benefitdetails/content-links.directive';
import { BreadcrumbModule } from '@app/components/breadcrumbs/breadcrumbs.module';


@NgModule({
  declarations: [
    MyPlansComponent,
    PlandetailsComponent,
    BenefitsComponent,
    BenefitDetailsComponent,
    FilterPopoverComponent,
    BenefitsFilterPopoverComponent,
    PopoverComponent,
    ContentLinksDirective
  ],
  imports: [
    CommonModule,
    BreadcrumbModule,
    MatExpansionModule,
    MY_PLANS_ROUTER,
    FormsModule,
    ReactiveFormsModule,
    IonicModule,
    CamelCaseModule,
    FpoLayoutModule,
    IabClickBlockModule,
    MatchTextHighlightModule,
    FontAwesomeModule,
    IntegratedPlanAcccessModule
  ],
  providers: [MyPlansService, MyBenefitsResolverService, MyBenefitDetailsResolverService]
})
export class MyPlansModule {}
