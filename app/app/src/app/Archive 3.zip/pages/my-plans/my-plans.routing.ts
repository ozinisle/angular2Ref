import { RouterModule, Routes } from '@angular/router';
import { BenefitDetailsComponent } from './benefitdetails/benefit-details.component';
import { BenefitsComponent } from './benefits/benefits.component';
import { MyBenefitsResolverService } from './benefits/benefits.resolver';
import { MyPlansComponent } from './my-plans.component';
import { PlandetailsComponent } from './plandetails/plandetails.component';

const MYPLANS_ROUTES: Routes = [
  {
    path: '',
    component: MyPlansComponent
  },
  {
    path: 'plandetails',
    component: PlandetailsComponent,
    data: {
      breadcrumb: 'Plan Details'
    }
  },
  {
    path: 'benefits',
    component: BenefitsComponent,
    data: {
      breadcrumb: 'Plan Benefits'
    },
    resolve: {
      benefits: MyBenefitsResolverService
    }
  },
  {
    path: 'benefitdetails',
    component: BenefitDetailsComponent,
    data: {
      breadcrumb: 'Benefit Details'
    }
  }
];

export const MY_PLANS_ROUTER = RouterModule.forChild(MYPLANS_ROUTES);
