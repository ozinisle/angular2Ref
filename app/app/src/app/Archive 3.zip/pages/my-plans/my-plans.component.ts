import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, ElementRef, HostListener, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { BreadCrumb } from '@app/components/breadcrumbs/breadcrumbs';
import { GeneralErrorInterface } from '@app/interfaces/generic-app-models.interface';
import { MemberPlan } from '@app/models/member-plan.model';
import { AlertService } from '@app/services/alert.service';
import { AppService } from '@app/services/app.service';
import { ConstantsService } from '@app/services/constants.service';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { NavController, PopoverController } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Select } from '@ngxs/store';
import { format } from 'date-fns';
import { from, Observable, Subject } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { FilterPopoverComponent } from './filterPopover/filter-popover.component';
import { PlanEntityInterface } from './models/interfaces/plan-benefits-page-adapted-data-model.inteface';
import { GetPlanBenefitServicesRequestModelInterface } from './models/interfaces/plans-benefits-service-model.interface';
import { PlanBenefitsListResponseModel } from './models/plan-benefits-list.model';
import { GetPlanBenefitServicesRequestModel } from './models/plans-benefits-service.model';
import { MyPlansService } from './my-plans.service';

@Component({
  selector: 'app-myplans',
  templateUrl: './my-plans.component.html',
  styleUrls: ['./my-plans.component.scss'],
  animations: [
    trigger('slideInOut', [
      state(
        'in',
        style({
          transform: 'translate3d(0,0,0)'
        })
      ),
      state(
        'out',
        style({
          transform: 'translate3d(-100%,0,0)',
          display: 'none'
        })
      ),
      transition('in => out', animate('100ms ease-in-out')),
      transition('out => in', animate('100ms ease-in-out'))
    ])
  ]
})
export class MyPlansComponent implements OnInit, OnDestroy {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getSelectedPlan) selectedPlan: MemberPlan;
  @Select(AppSelectors.isDefaultPlan) isDefaultPlan$: Observable<boolean>;

  @ViewChild('searchDrpContainer') searchDrpContainer;
  @ViewChild('sideNavContainer') elementView: ElementRef;
  @ViewChild('searchDateInput') fromInputDate: ElementRef;

  public isSearched = false;
  public isSidenavOpened = false;
  public breadCrumbs: BreadCrumb[];
  public sideNavStatus: string;
  public showClose: boolean;
  public showClearLink: boolean;
  public filteredList: PlanEntityInterface[] = [];
  public noPlans = false;
  public collapsedHeight: string = null;
  public expandedHeight = '44px';
  public filterDate: string;
  public showCalender: boolean;
  public searchDate: string;
  public toDate: string = format(new Date(), 'P');
  public dateFormat = 'MM/dd/yyyy';
  public errorMessage = null;
  public errorObj = null;
  public fpoListingUrl: string;
  public fpoInformationUrl: string;
  public fpoTargetUrl: string;
  public contactus: string;
  private selectedFilterDate: string;
  public selectedSwitchPlanEffectiveDate: string;
  mobileViewPort = 991;
  ismobile: boolean;
  destroy$ = new Subject<void>();

  constructor(
    private router: Router,
    private myPlansService: MyPlansService,
    private constants: ConstantsService,
    private appService: AppService,
    private alertService: AlertService,
    private popoverController: PopoverController,
    private navCtrl: NavController
  ) {
    this.contactus = this.constants.contactus + this.authToken.scopename;
    this.initErrorObj();
    this.ismobile = window.innerWidth <= this.mobileViewPort;
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.ismobile = event.target.innerWidth <= this.mobileViewPort;
  }

  goBack() {
    if (this.authToken) {
      this.navCtrl.back();
    } else {
      this.navCtrl.navigateRoot('home');
    }
  }

  ngOnInit() {
    this.breadCrumbs = [];
    this.breadCrumbs.push({
      label: 'Home',
      url: ['/home']
    });

    this.breadCrumbs.push({
      label: 'My Plan',
      url: ['/myplan']
    });
    this.fpoListingUrl = this.constants.drupalMyPlansListingUrl;
    this.fpoTargetUrl = this.constants.drupalMyPlansFPOUrl;
    this.fpoInformationUrl = this.constants.drupalMyPlansInformationUrl;
  }

  ionViewWillEnter() {
    const planEffectiveDt = this.getPlanEffectiveDate();
    this.getPlans(planEffectiveDt).subscribe();
  }

  getPlanEffectiveDate() {
    if (this.selectedPlan) {
      return this.selectedPlan.defaultPlan !== 'true'
        ? format(new Date(this.selectedPlan.planEffectiveDate), 'yyyy-MM-dd')
        : format(new Date(), 'yyyy-MM-dd');
    }
  }

  async showFilterPopover(ev: any) {
    const filterPopover = await this.popoverController.create({
      component: FilterPopoverComponent,
      event: ev,
      translucent: true,
      componentProps: {
        filterDate: this.selectedFilterDate,
        switchedPlan: this.selectedPlan
      },
      backdropDismiss: true
      // mode: 'ios'
    });
    from(filterPopover.onDidDismiss())
      .pipe(filter((dataReturned: any) => dataReturned && dataReturned.data !== undefined))
      .subscribe((dataReturned: any) => {
        this.selectedFilterDate = dataReturned.data;

        this.getPlans(this.selectedFilterDate || this.selectedSwitchPlanEffectiveDate).subscribe();
        this.isSearched = !!this.selectedFilterDate;
      });
    return await filterPopover.present();
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
    this.alertService.clearError();
  }

  getPlans(effectiveDate: string): Observable<PlanEntityInterface[] | GeneralErrorInterface> {
    return this.myPlansService.getPlansData(effectiveDate).pipe(
      map(data => {
        this.alertService.clearError();
        if (data['result'] < 0) {
          this.alertService.setAlert(data['displaymessage'], '', AlertType.Failure);
          this.noPlans = true;
          this.filteredList = [];
          return data as GeneralErrorInterface;
        }
        this.filteredList = this.myPlansService.mapPlanBenefitsResponse(data as PlanBenefitsListResponseModel);
        if (this.filteredList.length <= 0) {
          this.noPlans = true;
        }
        return this.filteredList;
      })
    );
  }

  openPlanBenefitsDetail(selectedPlan: PlanEntityInterface) {
    if (selectedPlan.foundFlag === false || selectedPlan.foundFlag === 'N') {
      return;
    }
    const getPlanBenefitRequest: GetPlanBenefitServicesRequestModelInterface = new GetPlanBenefitServicesRequestModel();
    getPlanBenefitRequest.coveragePackageCode = selectedPlan.coveragePackageCode;
    getPlanBenefitRequest.planName = selectedPlan.planName;
    getPlanBenefitRequest.useridin = this.useridin;
    this.myPlansService.setPlanBenefitRequest(getPlanBenefitRequest);
    this.myPlansService.setSelectedPlanEntity(selectedPlan);
    this.router.navigateByUrl('myPlan/plandetails');
  }

  initErrorObj() {
    this.errorObj = {
      isSelectedDateInvalid: false,
      sixtyDaysInvalid: false,
      twoYearsInvalid: false,
      required: false
    };
  }

  toggleFilter(toggleStatus) {
    this.isSidenavOpened = !this.isSidenavOpened;
    this.sideNavStatus = this.sideNavStatus === 'out' ? 'in' : 'out';
    if (toggleStatus) {
      this.sideNavStatus = toggleStatus;
    }
  }

  clearSearchVal() {
    this.showClose = false;
    this.searchDate = '';
  }

  clearFilter() {
    this.showClearLink = false;
    this.isSidenavOpened = false;
    this.isSearched = false;
    this.showCalender = false;
    this.filterDate = null;
    this.clearSearchVal();
    this.initErrorObj();
    this.getPlans(this.selectedSwitchPlanEffectiveDate).subscribe(data => {});
  }

  applyFilter(value) {
    if (!value) {
      this.initErrorObj();
    }
    if (Object.keys(this.errorObj).every(k => !this.errorObj[k])) {
      if (!this.searchDate) {
        this.initErrorObj();
        this.errorObj = Object.assign(this.errorObj, {
          required: true
        });
      } else {
        this.showClearLink = true;
        this.isSidenavOpened = !this.isSidenavOpened;
        this.isSearched = true;
        this.getPlans(this.appService.getUTCDate(this.searchDate)).subscribe(data => {});
      }
    }

    window.scrollTo(0, 0);
  }
}
