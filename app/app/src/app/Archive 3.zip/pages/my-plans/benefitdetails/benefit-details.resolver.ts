import { forkJoin as observableForkJoin, Observable, of as observableOf } from 'rxjs';

import { catchError } from 'rxjs/operators';

import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { MyPlansService } from '../my-plans.service';

@Injectable({ providedIn: 'root' })
export class MyBenefitDetailsResolverService implements Resolve<Observable<any | {}>> {
  constructor(public plansService: MyPlansService) {}

  resolve() {
    return observableForkJoin(
      this.plansService.getPlanBenefitDetails().pipe(
        catchError(res =>
          observableOf({
            ...res
          })
        )
      ),
      this.plansService.getLimitationText().pipe(
        catchError(res =>
          observableOf({
            ...res
          })
        )
      )
    );
  }
}
