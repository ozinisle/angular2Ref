import { ContentLinksDirective } from './content-links.directive';

describe('ContentLinksDirective', () => {
  it('should create an instance', () => {
    const directive = new ContentLinksDirective();
    expect(directive).toBeTruthy();
  });
});
