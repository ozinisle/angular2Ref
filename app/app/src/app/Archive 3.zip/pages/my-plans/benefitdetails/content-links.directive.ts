import { Directive } from '@angular/core';

@Directive({
  selector: '.content-links'
})
export class ContentLinksDirective {

  constructor() { }

}
