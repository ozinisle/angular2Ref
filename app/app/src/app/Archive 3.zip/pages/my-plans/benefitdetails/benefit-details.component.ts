import { Location } from '@angular/common';
import { Component, OnDestroy, OnInit, ElementRef, Renderer2, ViewChildren, QueryList } from '@angular/core';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { AlertService } from '@app/services/alert.service';
import { ConstantsService } from '@app/services/constants.service';
import { MY_PLANS_CONSTANTS } from '../constants/my-plans.constants';
import {
  AuthReferralResponseInterface,
  BenefitDetailsResponseInterface,
  LimitationResponseInterface,
  BenefitDetailsFaq
} from '../models/interfaces/benefit-details-model.interface';
import { NetworkType } from '../models/interfaces/benefits-model.interface';
import { MyPlansService } from '../my-plans.service';
import { Store } from '@ngxs/store';
import { SetLoader } from '@app/store/actions/app.actions';
import { Router, ActivatedRoute } from '@angular/router';
import { GlobalUtils } from '@app/utils/global.utils';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { finalize } from 'rxjs/operators';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { ContentLinksDirective } from './content-links.directive';

@Component({
  selector: 'app-benefit-details',
  templateUrl: './benefit-details.component.html',
  styleUrls: ['./benefit-details.component.scss']
})
export class BenefitDetailsComponent implements OnInit, OnDestroy {
  benefitDetails;
  planBenefits;
  authReferralDetails;
  authReferralErrorText;
  serviceProviders;
  limitationDetails;
  hideLimitationContentAndBanner = false;
  benefitName = '';
  keys = Object.keys;
  displayState = false;
  fpoTargetUrl: string;
  keyword = '';
  ismobile: boolean;
  segment = 'faq';
  faqs: BenefitDetailsFaq[] = [];
  otherHelpfulContent = [];
  internalUrl: any;

  routesList = {
    '/home': 'home',
    '/register': 'register',
    '/registerdetail': 'register/register-detail',
    '/login': 'login',
    '/whatsnew': 'whatsnew',
    '/myplans': 'myPlan',
    '/mydoctors': 'my-doctor',
    '/myclaims': 'myClaims',
    '/myinbox': 'myInbox',
    '/my-financial': 'my-financial',
    '/myprofile': 'myprofile',
    '/mycards': 'mycards',
    '/account': 'account',
    '/request-estimate': 'request-estimate',
    '/mydedco': 'deductibles',
    '/med-lookup': 'med-lookup-search',
    '/fad': 'fad',
    '/fitness-and-weightloss': 'fitness-and-weightloss',
    '/amwell_messages': 'amwell_messages',
    '/amwell_calendar': 'amwell_calendar',
    '/my-pillpack/landing': 'my-pillpack/landing',
    '/mydoctors/add-pcp-homepage': '/my-doctor/add-pcp',
    '/myplans/benefits': '/myPlan/benefits'
  }

  private unsubscribeHelper$: Subject<void> = new Subject<void>();

  public authReferralAPICallFailed = false;
  public authReferralAPIErrorText = MY_PLANS_CONSTANTS.errorMessages.authReferralFailureErrormsg;

  @SelectSnapshot(AppSelectors.isDefaultPlan) isDefaultPlan: boolean;
  @ViewChildren(ContentLinksDirective, { read: ElementRef }) contentDivs: QueryList<ElementRef>;

  constructor(
    private alertService: AlertService,
    public myPlansService: MyPlansService,
    private constants: ConstantsService,
    private location: Location,
    private store: Store,
    private route: ActivatedRoute,
    private resizeService: GlobalUtils,
    private elementRef: ElementRef,
    private router: Router,
    private renderer: Renderer2
  ) {
    this.displayState = !!this.myPlansService.getSelectedPlanEntity().pcpState;
    this.fpoTargetUrl = this.constants.drupalMyBenefitsDetailsUrl;
  }

  ionViewWillEnter() {
    this.route.queryParams.subscribe(params => {
      this.keyword = params.keyword;
    });
    if (!this.keyword) {
      this.keyword = '!@#$%';
    }
    this.faqs = [];
    this.getBenefitDetails();
    this.getLimitationText();
    const ciAcBenefiDetails = this.myPlansService.getCiAcBenefitDetails() as any;
    if (ciAcBenefiDetails) {
      this.benefitDetails = ciAcBenefiDetails;
    }
  }

  ngOnInit() {
    this.resizeService.getIsMobile().pipe(takeUntil(this.unsubscribeHelper$))
    .subscribe((isMobile: boolean) => this.ismobile = isMobile );
  }

  ngOnDestroy() {
    this.alertService.clearError();
    this.unsubscribeHelper$.next();
    this.unsubscribeHelper$.complete();
  }

  checkAuthReferral() {
    if (this.benefitDetails.authRefIndicator === true || this.benefitDetails.authRefIndicator === 'True') {
      this.getAuthReferral();
    }
  }

  getBenefitDetails() {
    this.store.dispatch(new SetLoader(true));
    this.myPlansService.getPlanBenefitDetails()
    .pipe(
      finalize(() => this.store.dispatch(new SetLoader(false))),
    )
    .subscribe(benefitDetails => {
      if (benefitDetails.result < 0) {
        this.alertService.setAlert(benefitDetails.displaymessage, '', AlertType.Failure);
        return;
      } else {
        this.populateBenefits(benefitDetails);
        this.checkAuthReferral();
      }
    });
  }

  populateBenefits(benefitDetails: BenefitDetailsResponseInterface) {
    this.benefitDetails = benefitDetails;
    this.planBenefits = this.benefitDetails.planBenefits;
    this.serviceProviders = this.groupBy(this.benefitDetails.serviceProviders, 'network');
    if ('FAQ' in benefitDetails && benefitDetails.FAQ.length > 0) {
      this.faqs = benefitDetails.FAQ;
      this.faqs.map(faq => faq['expanded'] = false);
    } else {
      this.segment = 'costs';
    }
    if (this.benefitDetails.Links || this.benefitDetails.DefaultLinks) {
      this.otherHelpfulContent = this.benefitDetails.Links.length === 3 ? this.benefitDetails.Links : this.benefitDetails.DefaultLinks;
    }
  }

  changeRoute(index) {
    const regexExp = /href="\/(.*?)"+/;
    const res = regexExp.exec(this.faqs[index].answer);
    if (res && res[1] !== null) {
      const routePath = '/' + res[1];
      this.router.navigate([routePath]);
    }
  }

  routeToMyPlans() {
    this.router.navigate(['/myPlan']);
  }

  goToLink(url: string, internal: boolean) {
    if (url) {
      if (!internal) {
        window.open(url, "_blank");
      } else {
        this.internalUrl = url.split("/")[3];
        this.router.navigate(['/' + this.internalUrl]);
      }
    }
  }

  toggleAccordion(index) {
    this.faqs[index]['expanded'] = !this.faqs[index]['expanded'];
    this.eventListenerFAQ();
  }

  onBenefitDescriptionClick(event) {
    this.segment = 'benefit_description';
  }
  onCostsClick(event) {
    this.segment = 'costs';
  }

  segmentChanged(selectedtab) {
    this.segment = selectedtab.detail['value'];
    if (this.segment === 'faq') {
      this.eventListenerFAQ();
    }
  }

  eventListenerFAQ() {
    setTimeout(() => {
      const goToBenefitDescriptionTab = this.elementRef.nativeElement.querySelectorAll(
        ".switchToBenefitDescriptionTab"
      );
      const goToCostsTab = this.elementRef.nativeElement.querySelectorAll(
        ".switchToCostsTab"
      );

      goToBenefitDescriptionTab.forEach(element => {
        element.addEventListener("click", this.onBenefitDescriptionClick.bind(this));
      });

      goToCostsTab.forEach(element => {
        element.addEventListener("click", this.onCostsClick.bind(this));
      });

      this.contentDivs.forEach((ele) => {
        const navigationElements = Array.prototype.slice.call(ele.nativeElement.querySelectorAll("a[href]"));
        navigationElements.forEach(element => {
          const isExternalLink = element.href.includes("https");
          if (!isExternalLink) {
            this.renderer.listen(element, 'click', (event) => {
              event.preventDefault();
              const link = this.routesList[element.getAttribute('href')];
              if (link) {
                this.router.navigate([link]);
              }
            });
          }
        })
      });
    }, 500);
  }

  getLimitationText() {
    this.myPlansService.getLimitationText().subscribe((data: LimitationResponseInterface) => {
      this.benefitName = JSON.parse(sessionStorage.getItem('my-plans.serviceBenefitCategoryName'));
      if (data.result < 0) {
        if (data.result === -91339) {
          this.hideLimitationContentAndBanner = true;
        } else {
          this.hideLimitationContentAndBanner = false;
          this.alertService.setAlert(data.displaymessage, '', AlertType.Failure);
        }
        return;
      } else {
        this.limitationDetails = data.RowSet.Rows;
        this.hideLimitationContentAndBanner = false;
      }
    });
  }

  groupBy(xs, prop) {
    const grouped = {};
    for (let i = 0; i < xs.length; i++) {
      const p = xs[i][prop];
      if (!grouped[p]) {
        grouped[p] = [];
      }
      grouped[p].push(xs[i]);
    }
    return grouped;
  }

  getAuthReferral() {
    this.authReferralAPICallFailed = false;
    this.myPlansService.getAuthReferral().subscribe(
      (data: AuthReferralResponseInterface) => {
        if (data.result < 0) {
          this.authReferralAPICallFailed = true;
          if (data.result === -91361) {
            this.authReferralErrorText = MY_PLANS_CONSTANTS.errorMessages['-91361'];
          } else if (data.result === -91362) {
            this.authReferralErrorText = MY_PLANS_CONSTANTS.errorMessages['-91362'];
          } else {
            this.authReferralErrorText = null;
          }
          return;
        } else {
          this.authReferralDetails = data.getAuthReferralResponse;
          if (!this.authReferralDetails) {
            this.authReferralAPICallFailed = true;
          } else {
            this.authReferralErrorText = null;
          }
        }
      },
      error => {
        this.authReferralAPICallFailed = true;
      }
    );
  }

  isString(val) {
    return typeof val === 'string';
  }

  isNetwork(network: string): boolean {
    return (
      network === NetworkType.inNetwork ||
      network === 'I' ||
      network === MY_PLANS_CONSTANTS.network.inNetwork ||
      network === NetworkType.outOfNetwork ||
      network === 'O' ||
      network === MY_PLANS_CONSTANTS.network.outNetwork ||
      network === NetworkType.inNetworkAndOutOfNetworkCombined ||
      network === 'C' ||
      network === MY_PLANS_CONSTANTS.network.combined
    );
  }

  goBack() {
    this.location.back();
  }
}
