import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NgxsModule } from '@ngxs/store';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { PlandetailsComponent } from './plandetails.component';
import { IabService } from '@app/services/iab.service';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { AlertService } from '@app/services/alert.service';
import { ModalController, AngularDelegate, NavParams, PopoverController, IonicModule } from '@ionic/angular';
import { mocks } from '@testing/constants/mocks.service';
import { MyPlansService } from '../my-plans.service';
import { MyBenefitsResolverService } from '../benefits/benefits.resolver';
import { MyBenefitDetailsResolverService } from '../benefitdetails/benefit-details.resolver';
import { CamelCaseModule } from '@app/pipes/camelcase/camel-case.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MY_PLANS_ROUTER } from '../my-plans.routing';
import { AlertsComponent } from '@app/components/alerts/alerts.component';

class MockNavParams {
  data = {};

  get(param) {
    return this.data[param];
  }
}

describe('Plan Details Component Page', () => {
  let component: PlandetailsComponent;
  let alertService: AlertService;
  let fixture: ComponentFixture<PlandetailsComponent>;
  let mockMyPlanService;
  const modalSpy = jasmine.createSpyObj('Modal', ['present']);
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);
  modalCtrlSpy.create.and.callFake(() => {
    return modalSpy;
  });

  beforeEach(waitForAsync(() => {
    mockMyPlanService = mocks.service.myPlansService;
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        RouterTestingModule,
        NgxsModule.forRoot([]),
        NgxsSelectSnapshotModule.forRoot(),
        CommonModule,
        MY_PLANS_ROUTER,
        FormsModule,
        ReactiveFormsModule,
        IonicModule,
        CamelCaseModule
      ],
      providers: [
        IabService,
        PopoverController,
        InAppBrowser,
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        },
        {
          provide: MyPlansService,
          useValue: mockMyPlanService
        },
        { provide: NavParams, useClass: MockNavParams },
        AlertService,
        ModalController,
        AngularDelegate,
        MyBenefitsResolverService,
        MyBenefitDetailsResolverService
      ],
      declarations: [PlandetailsComponent, AlertsComponent]
    }).compileComponents();
    alertService = TestBed.inject(AlertService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlandetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check toolTipVisible flag', () => {
    expect(component.toolTipVisible).toBeFalsy();
  });

  it('should check toolTipVisible flag after showToolTip method call', () => {
    component.showToolTip();
    expect(component.toolTipVisible).toBeTruthy();
  });

  it('should check planName after mock the data with getPlanBenefitServices', () => {
    expect(component.planBenefitDetails.planName.length).toBeGreaterThan(0);
  });

  it('should check planBenefitName after mock the data with getPlanBenefitServices', () => {
    expect(component.planBenefitDetails.planBenefits[0].planBenefitName.length).toBeGreaterThan(0);
  });

  it('should check innetwork  inside planBenefits array after mock the data with getPlanBenefitServices', () => {
    expect(component.planBenefitDetails.planBenefits[0].subcategory[0].memberCostText.inNetwork[0].length).toBeGreaterThan(0);
  });

  it('should check outOfNetwork  inside planBenefits array after mock the data with getPlanBenefitServices', () => {
    expect(component.planBenefitDetails.planBenefits[0].subcategory[0].memberCostText.outOfNetwork[0].length).toBeGreaterThan(0);
  });

  it('should check inNetworkAndOutOfNetworkCombined  inside planBenefits array after mock the data with getPlanBenefitServices', () => {
    expect(component.planBenefitDetails.planBenefits[0].subcategory[0].memberCostText.outOfNetwork[0].length).toBeGreaterThan(0);
  });

  it('should check ion title in templatefile', () => {
    const element = document.querySelector('ion-title');
    expect(element.innerHTML.length).toBeGreaterThan(0);
  });

  // it('should check ion plan title in templatefile', () => {
  //   const element = document.querySelector('.ion-text-wrap');
  //   expect(element.innerHTML.length).toBeGreaterThan(0);
  // });

  it('should check ion title in templatefile', () => {
    const element = document.querySelector('.plan-header h3');
    expect(element.innerHTML.length).toBeGreaterThan(0);
  });

  it('should check deductible plan name in templatefile', () => {
    const element = document.querySelector('.plan-name-header');
    expect(element.innerHTML.length).toBeGreaterThan(0);
  });

  it('should check deductible plan label in templatefile', () => {
    const element = document.querySelector('.plan-label-value');
    expect(element.innerHTML.length).toBeGreaterThan(0);
  });

  it('should check deductible detail text in templatefile', () => {
    const element = document.querySelector('.plan-details-text');
    expect(element.innerHTML.length).toBeGreaterThan(0);
  });

  it('should check other template values', () => {
    const element = document.querySelector('.details-right-link .text-label');
    expect(element.innerHTML.length).toBeGreaterThan(0);
  });

  it('should check inNetworkAndOutOfNetworkCombined from lifetimeBenefitObject', () => {
    expect(component.lifetimeBenefitObject.inNetworkAndOutOfNetworkCombined[0].length).toBeGreaterThan(0);
  });

  it('should check inNetworkAndOutOfNetworkCombined from coinsuranceMaxObject', () => {
    expect(component.coinsuranceMaxObject.inNetworkAndOutOfNetworkCombined[0].length).toBeGreaterThan(0);
  });

  it('should check inNetworkAndOutOfNetworkCombined from deductibleObject', () => {
    expect(component.deductibleObject.inNetworkAndOutOfNetworkCombined[0].length).toBeGreaterThan(0);
  });

  it('should check onDestroy method', () => {
    const spyon = spyOn(alertService, 'clearError');
    component.ngOnDestroy();
    expect(spyon).toHaveBeenCalled();
  });
});
