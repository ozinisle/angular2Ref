import { Location } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { AuthToken } from '@app/models/auth-token.model';
import { AlertService } from '@app/services/alert.service';
import { ConstantsService } from '@app/services/constants.service';
import { SwrveEventNames, SwrveService } from '@app/services/swrve.service';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { GlobalUtils } from '@app/utils/global.utils';
import { PopoverController, Platform } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { from, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { SsoService } from '../../sso/sso.service';
import { GetPlanBenefitServicesResponseModelInterface } from '../models/interfaces/plans-benefits-service-model.interface';
import { MyPlansService } from '../my-plans.service';
import { PopoverComponent } from '../popover/popover.component';

@Component({
  selector: 'app-plandetails',
  templateUrl: './plandetails.component.html',
  styleUrls: ['./plandetails.component.scss']
})
export class PlandetailsComponent implements OnInit, OnDestroy {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: AuthToken;
  @SelectSnapshot(AppSelectors.isDefaultPlan) isDefaultPlan: boolean;


  public planBenefitDetails = null;
  public deductibleObject;
  public coinsuranceMaxObject;
  public lifetimeBenefitObject;
  public fpoTargetUrl: string;
  public fpoTargetTooltipUrl: string;
  public drupalData: object;
  public isplandetails = true;
  public keys = Object.keys;

  submenu: any = {};
  toolTipVisible = false;
  ismobile: boolean;
  isFinancialFlag: boolean;
  isDisplayOverallDedution : boolean = false;
  isOutOfPocket: boolean = false;
  isOverallBenfit: boolean = false;
  showFinancialAccout: boolean;
  private unsubscribeHelper$: Subject<void> = new Subject<void>();

  constructor(
    public myPlansService: MyPlansService,
    private constants: ConstantsService,
    private alertService: AlertService,
    private location: Location,
    private popoverController: PopoverController,
    private ssoService: SsoService,
    private http: HttpClient,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames,
    private resizeService: GlobalUtils,
    private platform: Platform
  ) {
    this.fpoTargetTooltipUrl = this.constants.drupalMyPlansDetailsTooltipUrl;
    this.fpoTargetUrl = this.constants.drupalMyPlansDetails;
  }

  goBack() {
    this.location.back();
  }

  isToggle(menuName  : string)
  {
    if(menuName == 'OD') {
    this.isDisplayOverallDedution = !this.isDisplayOverallDedution;
    } else if(menuName == "OPM") {
    this.isOutOfPocket = !this.isOutOfPocket;
    } else if(menuName == "OBM"){
    this.isOverallBenfit = !this.isOverallBenfit;
  }
}

  async showPopover(ev: any) {
    const popover = await this.popoverController.create({
      component: PopoverComponent,
      event: ev,
      mode: 'ios',
      showBackdrop: true,
      cssClass: 'drupal-tooltip planDetails-infoPopup',
      componentProps: {
        tooltip: {
          targetUrl: this.fpoTargetTooltipUrl,
          toolTipdataPlans: this.drupalData,
          isplandetails: this.isplandetails
        }
      }
    });
    this.toolTipVisible = true;
    from(popover.onDidDismiss()).subscribe(() => (this.toolTipVisible = false));
    await popover.present();
  }

  ngOnInit() {
    this.swrveService.sendAppMessage(this.swrveEventNames.appScreenMyPlan);
    this.getPlanDetails();
    this.getTooltipData();
    this.resizeService.getIsMobile().pipe(takeUntil(this.unsubscribeHelper$))
    .subscribe((isMobile: boolean) => this.ismobile = isMobile );
    this.isFinancialFlag = this.authToken?.isALG === 'true' || this.authToken?.isHEQ === 'true' ? true : false;
    if (this.platform.is('mobile') && this.isFinancialFlag === true) {
      this.showFinancialAccout = true;
    } else if (this.platform.is('desktop') === true) {
      this.showFinancialAccout = false;
    }
  }

  getTooltipData() {
    this.http.get(this.fpoTargetTooltipUrl).subscribe((response: any) => {
      this.drupalData = response;
    });
  }

  ngOnDestroy() {
    this.alertService.clearError();
    this.unsubscribeHelper$.next();
    this.unsubscribeHelper$.complete();
  }

  getPlanDetails() {
    this.myPlansService.getPlanBenefitServices(false).subscribe(planBenefitDetails => {
      if (planBenefitDetails.result < 0) {
        this.alertService.setAlert(planBenefitDetails.displaymessage, '', AlertType.Failure);
        return;
      }
      this.planBenefitDetails = planBenefitDetails as GetPlanBenefitServicesResponseModelInterface;
      this.populateBenefits();
    });
  }

  populateBenefits() {
    if (this.planBenefitDetails.PlanBenefitFeatures) {
      if (this.planBenefitDetails.PlanBenefitFeatures.deductibleText) {
        this.deductibleObject = this.planBenefitDetails.PlanBenefitFeatures.deductibleText;
      }
      if (this.planBenefitDetails.PlanBenefitFeatures.coinsuranceMaxText) {
        this.coinsuranceMaxObject = this.planBenefitDetails.PlanBenefitFeatures.coinsuranceMaxText;
      }
      if (this.planBenefitDetails.PlanBenefitFeatures.lifetimeBenefitText) {
        this.lifetimeBenefitObject = this.planBenefitDetails.PlanBenefitFeatures.lifetimeBenefitText;
      }
    }
  }

  showToolTip() {
    this.toolTipVisible = !this.toolTipVisible;
  }

  openSSOUrl(): void {
    const hasALG = (sessionStorage.getItem('hasALG') || 'false').toString().toLowerCase();
    const hasHEQ = (sessionStorage.getItem('hasHEQ') || 'false').toString().toLowerCase();

    if (hasHEQ === 'true') {
      this.ssoService.openSSO('heq');
    } else if (hasALG === 'true') {
      this.ssoService.openSSO('alg');
    }
  }
}
