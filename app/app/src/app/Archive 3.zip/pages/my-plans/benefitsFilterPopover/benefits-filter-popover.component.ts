import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { GlobalUtils } from '@app/utils/global.utils';
import { PopoverController } from '@ionic/angular';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-benefits-filter-popover',
  templateUrl: './benefits-filter-popover.component.html',
  styleUrls: ['./benefits-filter-popover.component.scss']
})
export class BenefitsFilterPopoverComponent implements OnInit {
  @Input() sortList: Array<any>;
  isOpen = false;
  selectedFilter = 'A-Z';
  ismobile: boolean;
  private unsubscribeHelper$: Subject<void> = new Subject<void>();
  @Output() filterOutput = new EventEmitter<any>();

  constructor(private popoverController: PopoverController, private resizeService: GlobalUtils) {}

  ngOnInit() {
    this.selectedFilter = this.sortList.find(item => item.checked === true).text;
    this.resizeService.getIsMobile().pipe(takeUntil(this.unsubscribeHelper$))
    .subscribe((isMobile: boolean) => this.ismobile = isMobile );
  }

  selectFilter(event) {
    this.sortList.forEach(item => (item.checked = false));
    this.sortList.forEach((item, index) => {
      if (event.detail.value === item.value) {
        this.sortList[index].checked = true;
        this.selectedFilter = this.sortList[index].text;
      }
    });
  }
  toggleOpen() {
    this.isOpen = !this.isOpen;
  }

  applyFilter() {
    this.ismobile ? this.popoverController.dismiss(this.sortList) : this.filterOutput.emit(this.sortList);
  }

  clearFilter() {
    this.sortList.forEach(item => (item.checked = item.text === 'A-Z'));
    this.applyFilter();
  }
}
