import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Store, NgxsModule } from '@ngxs/store';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { IabService } from '@app/services/iab.service';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { AlertService } from '@app/services/alert.service';
import { ModalController, AngularDelegate, NavParams, PopoverController, IonicModule } from '@ionic/angular';
import { mocks } from '@testing/constants/mocks.service';
import { MyPlansService } from './../my-plans.service';
import { MyBenefitsResolverService } from './../benefits/benefits.resolver';
import { MyBenefitDetailsResolverService } from './../benefitdetails/benefit-details.resolver';
import { CamelCaseModule } from '@app/pipes/camelcase/camel-case.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MY_PLANS_ROUTER } from './../my-plans.routing';
import { BenefitsFilterPopoverComponent } from './benefits-filter-popover.component';
import { AlertsComponent } from '@app/components/alerts/alerts.component';
class MockNavParams {
  data = {
    sortList: [{ text: 'cov', checked: true }, { text: 'encov', checked: false }]
  };

  get(param) {
    return this.data[param];
  }
}

describe('BenefitsFilterPopoverComponent Page', () => {
  let component: BenefitsFilterPopoverComponent;
  let fixture: ComponentFixture<BenefitsFilterPopoverComponent>;
  let mockMyPlanService;
  let popoverController: PopoverController;

  const modalSpy = jasmine.createSpyObj('Modal', ['present']);
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);
  modalCtrlSpy.create.and.callFake(() => {
    return modalSpy;
  });

  let store: Store;
  beforeEach(waitForAsync(() => {
    mockMyPlanService = mocks.service.myPlansService;
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        RouterTestingModule,
        NgxsModule.forRoot([]),
        NgxsSelectSnapshotModule.forRoot(),
        CommonModule,
        MY_PLANS_ROUTER,
        FormsModule,
        ReactiveFormsModule,
        IonicModule,
        CamelCaseModule
      ],
      providers: [
        IabService,
        PopoverController,
        InAppBrowser,
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        },
        DatePipe,
        {
          provide: MyPlansService,
          useValue: mockMyPlanService
        },
        { provide: NavParams, useClass: MockNavParams },
        AlertService,
        ModalController,
        AngularDelegate,
        MyBenefitsResolverService,
        MyBenefitDetailsResolverService
      ],
      declarations: [BenefitsFilterPopoverComponent, AlertsComponent]
    }).compileComponents();

    store = TestBed.inject(Store);
    spyOn(store, 'selectSnapshot').and.returnValue({ authToken: { scopename: true } });
    popoverController = TestBed.inject(PopoverController);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BenefitsFilterPopoverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check title value in  template file', () => {
    const element = document.querySelector('.header ion-label');
    expect(element.innerHTML.length).toBeGreaterThan(0);
  });

  it('should check button label in  template file', () => {
    const element = document.querySelector('.btn-apply');
    expect(element.innerHTML.length).toBeGreaterThan(0);
  });

  it('should check header button in  template file', () => {
    const element = document.querySelector('.header ion-button');
    expect(element.innerHTML.length).toBeGreaterThan(0);
  });

  it('should check apply text in  template file', () => {
    const element = document.querySelector('.btn-apply');
    expect(element.innerHTML.length).toBeGreaterThan(0);
  });

  it('should check filter text in  template file', () => {
    const element = document.querySelector('.sort-options ion-label');
    expect(element.innerHTML.length).toBeGreaterThan(0);
  });

  it('should check applyFilter method', () => {
    const spyon = spyOn(popoverController, 'dismiss');
    component.applyFilter();
    expect(spyon).toHaveBeenCalled();
  });

  it('should check name after clearFilter', () => {
    component.clearFilter();
    expect(component.sortList[0].text.length).toBeGreaterThan(0);
  });

  it('should check checked after clearFilter', () => {
    component.clearFilter();
    expect(component.sortList[0].checked).toBeFalsy();
  });

  it('should check name after selectFilter', () => {
    component.selectFilter({ detail: { value: 'cov' } });
    expect(component.sortList[1].checked).toBeFalsy();
  });
});
