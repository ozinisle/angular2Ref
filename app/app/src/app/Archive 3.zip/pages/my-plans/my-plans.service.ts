import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ConstantsService } from '@app/services/constants.service';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable, of as observableOf, of, throwError as observableThrowError } from 'rxjs';
import { map } from 'rxjs/operators';
import { ValidationService } from '@app/services/validation.service';
import { MY_PLANS_CONSTANTS } from './constants/my-plans.constants';
import {
  AuthReferralResponseInterface,
  BenefitDetailsResponseInterface,
  LimitationResponseInterface
} from './models/interfaces/benefit-details-model.interface';
import { NetworkType } from './models/interfaces/benefits-model.interface';
import {
  PlanBenefitsListRequestModelInterface,
  PlanBenefitsListResponseModelInterface
} from './models/interfaces/plan-benefits-list-model.interface';
import { PlanEntityInterface, PlanEntityMemberInterface } from './models/interfaces/plan-benefits-page-adapted-data-model.inteface';
import {
  GetPlanBenefitDetailsRequestModelInterface,
  GetPlanBenefitServicesRequestModelInterface,
  GetPlanBenefitServicesResponseModelInterface
} from './models/interfaces/plans-benefits-service-model.interface';
import { PlanBenefitsListRequestModel, PlanBenefitsListResponseModel } from './models/plan-benefits-list.model';
import { PlanEntity, PlanEntityMember } from './models/plan-benefits-page-adapted-data.model';
import { PlanEntityMemberType } from './models/types/myplans.types';

@Injectable({ providedIn: 'root' })
export class MyPlansService {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  private benefitCategoryTitle = '';
  private planBenefitRequest: GetPlanBenefitServicesRequestModelInterface = null;
  private planBenefitDetailsRequest: GetPlanBenefitDetailsRequestModelInterface;
  private selectedPlanEntity: PlanEntityInterface = null;
  private planBenefits: GetPlanBenefitServicesResponseModelInterface;
  private serviceBenefitCategoryName = ''; // To Do
  private ciAcBenefitsDetails = '';

  constructor(
    private constants: ConstantsService,
    private http: HttpClient,
    private router: Router,
    private validationService: ValidationService
  ) {}

  public getBenefitCategoryTitle() {
    return this.benefitCategoryTitle;
  }

  public getPlanBenefits() {
    return this.planBenefits;
  }

  public setPlanBenefits(planBenefits) {
    this.planBenefits = planBenefits;
  }

  public setPlanBenefitRequest(planBenefitRequest: GetPlanBenefitServicesRequestModelInterface) {
    this.planBenefitRequest = planBenefitRequest;
    sessionStorage.setItem('my-plans.selectedPlan', JSON.stringify(planBenefitRequest));
  }

  public getPlanBenefitRequest(): GetPlanBenefitServicesRequestModelInterface {
    if (this.planBenefitRequest) {
      return this.planBenefitRequest;
    } else {
      const plan = sessionStorage.getItem('my-plans.selectedPlan');
      if (plan) {
        return JSON.parse(plan);
      } else {
        return null;
      }
    }
  }

  public setPlanBenefitDetailsRequest(planBenefitDetailsRequest: GetPlanBenefitDetailsRequestModelInterface) {
    this.planBenefitDetailsRequest = planBenefitDetailsRequest;
    sessionStorage.setItem('my-plans.selectedPlan', JSON.stringify(planBenefitDetailsRequest));
  }

  public getPlanBenefitDetailsRequest(): GetPlanBenefitDetailsRequestModelInterface {
    if (this.planBenefitDetailsRequest) {
      return this.planBenefitDetailsRequest;
    } else {
      const plan = sessionStorage.getItem('my-plans.selectedPlan');
      if (plan) {
        return JSON.parse(plan);
      } else {
        return null;
      }
    }
  }

  public setSelectedPlanEntity(setSelectedPlanEntity: PlanEntityInterface) {
    this.selectedPlanEntity = setSelectedPlanEntity;
    sessionStorage.setItem('my-plans.selectedPlanEntity', JSON.stringify(setSelectedPlanEntity));
  }

  public getSelectedPlanEntity(): PlanEntityInterface {
    if (this.selectedPlanEntity) {
      return this.selectedPlanEntity;
    } else {
      const selectedPlanEntity = sessionStorage.getItem('my-plans.selectedPlanEntity');
      if (selectedPlanEntity) {
        return JSON.parse(selectedPlanEntity);
      } else {
        return {} as PlanEntityInterface;
      }
    }
  }

  public getServiceBenefitCategoryName(): string {
    if (this.serviceBenefitCategoryName) {
      return this.serviceBenefitCategoryName;
    } else {
      const serviceBenefitCategoryName = sessionStorage.getItem('my-plans.serviceBenefitCategoryName');
      if (serviceBenefitCategoryName) {
        return JSON.parse(serviceBenefitCategoryName);
      } else {
        return '';
      }
    }
  }

  public setServiceBenefitCategoryName(serviceBenefitCategoryName: string) {
    this.serviceBenefitCategoryName = serviceBenefitCategoryName;
    sessionStorage.setItem('my-plans.serviceBenefitCategoryName', JSON.stringify(serviceBenefitCategoryName));
  }

  getPlansData(effectiveDate: string): Observable<PlanBenefitsListResponseModelInterface> {
    const request: PlanBenefitsListRequestModelInterface = new PlanBenefitsListRequestModel();
    request.useridin = this.useridin;
    request.effectiveDate = effectiveDate;

    return this.http.post<PlanBenefitsListResponseModelInterface>(this.constants.getPlansBenefitsListUrl, request).pipe(
      map(response => {
        if (response.result < 0) {
          return response as PlanBenefitsListResponseModelInterface;
        } else {
          const planBenefitsListResponse: PlanBenefitsListResponseModelInterface = response as PlanBenefitsListResponseModelInterface;

          if (planBenefitsListResponse['type'] !== 'error') {
            if (planBenefitsListResponse.fault && planBenefitsListResponse.fault.faultstring) {
              return;
            } else {
              return planBenefitsListResponse;
            }
          }
        }
      })
    );
  }

  public getCiAcBenefitsRequest() {
    const planBenefitRequest = this.getPlanBenefitRequest();
    if (planBenefitRequest && planBenefitRequest.planName === 'BlueFit Plan') {
      const planEntity = this.getSelectedPlanEntity();
      const year = new Date(planEntity.effectiveStartDate).getFullYear();
      return this.http.get(`${this.constants.getCiAcBenefits}${year}`);
    } else {
      return of(null);
    }
  }

  public getCiAcBenefitDetails() {
    if (!this.ciAcBenefitsDetails) {
      const details = sessionStorage.getItem('myplans.ciAcBenefiDetails');
      if (details) {
        this.ciAcBenefitsDetails = JSON.parse(details);
      }
    }
    return this.ciAcBenefitsDetails;
  }

  public clearCIAcBenefitDetails() {
    this.ciAcBenefitsDetails = null;
    sessionStorage.removeItem('myplans.ciAcBenefiDetails');
  }

  public setCiAcBenefitDetails(details: any) {
    this.ciAcBenefitsDetails = details;
    sessionStorage.setItem('myplans.ciAcBenefiDetails', JSON.stringify(details));
  }

  getPlanBenefitServices(checkAvailablility: boolean, sortFlag?: string): Observable<GetPlanBenefitServicesResponseModelInterface> {
    if (!this.getPlanBenefitRequest()) {
      this.router.navigate(['home']);
      return observableThrowError(new Error('Invalid Request'));
    }
    if (checkAvailablility) {
      const benefits = this.getPlanBenefits();
      if (benefits && benefits.planBenefits.length > 0) {
        return observableOf(benefits);
      }
    }
    const request = Object.assign(this.getPlanBenefitRequest(), {
      sortFlag: sortFlag || 'A-Z'
    });
    return this.http.post(this.constants.getPlanBenefitServicesUrl, request).pipe(
      map(response => {
        // tslint:disable-next-line:max-line-length
        const planmemberCostTextResponse: GetPlanBenefitServicesResponseModelInterface = response as GetPlanBenefitServicesResponseModelInterface;

        if (planmemberCostTextResponse.planBenefits) {
          this.setPlanBenefits(planmemberCostTextResponse);
        }
        return planmemberCostTextResponse;
      })
    );
  }

  getPlanBenefitDetails(): Observable<BenefitDetailsResponseInterface> {
    let request = this.getPlanBenefitDetailsRequest();
    if (!request) {
      this.router.navigate(['home']);
      return observableThrowError(new Error('Invalid Request'));
    }
    if (!request.benefitCategoryName) {
      request = Object.assign(this.getPlanBenefitRequest(), {
        benefitCategoryName: this.getServiceBenefitCategoryName(),
        benefitCategoryID: null,
        cpcCode: this.getPlanBenefitRequest().coveragePackageCode
      });
    }
    this.benefitCategoryTitle = request.benefitCategoryName;

    return this.http.post<BenefitDetailsResponseInterface>(this.constants.getBenefitEnhancedDetailsUrl, request).pipe(
      map(response => {
        return response;
      })
    );
  }

  getLimitationText(): Observable<LimitationResponseInterface> {
    if (!this.getPlanBenefitRequest()) {
      this.router.navigate(['home']);
      return observableThrowError(new Error('Invalid Request'));
    }
    const request = Object.assign(this.getPlanBenefitRequest(), {
      benefitCategoryName: this.getServiceBenefitCategoryName()
    });
    return this.http.post<LimitationResponseInterface>(this.constants.getLimitationTextUrl, request).pipe(
      map(response => {
        return response;
      })
    );
  }

  getAuthReferral(): Observable<AuthReferralResponseInterface> {
    const request = Object.assign(this.getPlanBenefitRequest(), {
      state: this.getSelectedPlanEntity().pcpState,
      benefitCategoryName: this.getServiceBenefitCategoryName(),
      planEffectiveDate: this.getSelectedPlanEntity().effectiveStartDate
    });
    return this.http.post<AuthReferralResponseInterface>(this.constants.getAuthReferralUrl, request).pipe(
      map(response => {
        return response;
      })
    );
  }

  getNetworkString(network: string): string {
    if (network === NetworkType.inNetwork || network === 'I' || network === MY_PLANS_CONSTANTS.network.inNetwork) {
      return MY_PLANS_CONSTANTS.network.inNetwork;
    } else if (network === NetworkType.outOfNetwork || network === 'O' || network === MY_PLANS_CONSTANTS.network.outNetwork) {
      return MY_PLANS_CONSTANTS.network.outNetwork;
    } else if (
      network === NetworkType.inNetworkAndOutOfNetworkCombined ||
      network === 'C' ||
      network === MY_PLANS_CONSTANTS.network.combined
    ) {
      return MY_PLANS_CONSTANTS.network.combined;
    }
  }

  getStyledHtmlText(str: string): string {
    if (str === null || str === undefined) {
      return;
    }
    const currencyMatch = str.match(/[$]/i);
    const percentMatch = str.match(/([0-9]+)[%]/i);
    for (let i = 0; i < MY_PLANS_CONSTANTS.regexMatch.length; i++) {
      const customMatch = str.match(new RegExp(MY_PLANS_CONSTANTS.regexMatch[i], 'i'));
      if (currencyMatch && currencyMatch.length > 0) {
        if (customMatch && customMatch.length > 0 && customMatch.index > currencyMatch.index) {
          return (
            str.substring(0, currencyMatch.index) +
            '<span class="bold">' +
            str.substring(currencyMatch.index, customMatch.index + customMatch[0].length) +
            '</span>' +
            str.substring(customMatch.index + customMatch[0].length, str.length)
          );
        }
      }
      if (percentMatch && percentMatch.length > 0) {
        if (customMatch && customMatch.length > 0 && customMatch.index > percentMatch.index) {
          return (
            str.substring(0, percentMatch.index) +
            '<span class="bold">' +
            str.substring(percentMatch.index, customMatch.index + customMatch[0].length) +
            '</span>' +
            str.substring(customMatch.index + customMatch[0].length, str.length)
          );
        }
      }
    }
    if (str === MY_PLANS_CONSTANTS.noCostText || str === MY_PLANS_CONSTANTS.noLimitText) {
      return '<span class="bold">' + str + '</span>';
    }
    return str;
  }

  public mapPlanBenefitsResponse(planBenefitsResponseData: PlanBenefitsListResponseModel) {
    const transformedResponse: PlanEntityInterface[] = [];
    try {
      const planBenefitRowSet = Object.freeze(planBenefitsResponseData.RowSet);
      planBenefitRowSet.osplinPlans.plans.map(plan => {
        const planEntity = new PlanEntity();
        planEntity.planName = plan.planName;
        planEntity.coveragePackageCode = plan.coveragePackageCode;
        planEntity.pcpState = plan.pcpState;
        plan.groupInfo.group.map(group => {
          planEntity.effectiveEndDate = '';
          planEntity.effectiveStartDate = group.planEffectiveDt;
          planEntity.subscriberId = group.subscriberId;
          planEntity.groupName = group.groupName;
          planEntity.groupNumber = group.groupNumber;
        });
        planEntity.foundFlag = plan.foundFlag;
        const planEntityMembers: PlanEntityMemberInterface[] = [];
        plan.osplinPlanMembers.members.map(member => {
          const planEntityMember: PlanEntityMemberInterface = new PlanEntityMember();
          planEntityMember.memberId = member.memberId;

          planEntityMember.name = member.middleInitial
            ? `${member.firstName} ${member.middleInitial} ${member.lastName}`
            : `${member.firstName} ${member.lastName}`;
          planEntityMember.memberDOB = member.memberDOB;
          planEntityMember.uaCoverageCode = member.UACoverageCode;
          switch (member.memberId) {
            case '00':
              planEntityMember.memberType = 'Subscriber' as PlanEntityMemberType;
              break;
            case '01':
            case '02':
            case '03':
            case '04':
            case '05':
            case '06':
            case '07':
            case '08':
              planEntityMember.memberType = 'Spouse' as PlanEntityMemberType;
              break;
            default:
              const age = this.validationService.getAge(member.memberDOB);
              planEntityMember.memberType =
                !isNaN(age) && age > 18 ? ('Dependent over 18 years' as PlanEntityMemberType) : ('Dependent' as PlanEntityMemberType);
              break;
          }
          planEntityMembers.push(planEntityMember);
        });
        planEntity.members = planEntityMembers;
        transformedResponse.push(planEntity);
      });
    } catch (exception) {
      console.error(exception, null, 2);
    }
    return transformedResponse;
  }
}
