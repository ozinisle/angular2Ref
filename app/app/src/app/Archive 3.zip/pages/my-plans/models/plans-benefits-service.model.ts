import { MyBlueGeneralAPIRequestModel } from '../../../models/generic-app.model';
import { GetPlanBenefitServicesRequestModelInterface } from './interfaces/plans-benefits-service-model.interface';

export class GetPlanBenefitServicesRequestModel extends MyBlueGeneralAPIRequestModel
  implements GetPlanBenefitServicesRequestModelInterface {
  planName: string; // string    example: Dental Blue Program 2    plan Name
  coveragePackageCode: string; // string    example: 106167    Coverage Package Code
}
