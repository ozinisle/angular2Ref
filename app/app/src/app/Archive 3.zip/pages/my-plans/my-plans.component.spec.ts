import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Store, NgxsModule } from '@ngxs/store';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { IabService } from '@app/services/iab.service';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { AlertService } from '@app/services/alert.service';
import { ModalController, AngularDelegate, NavParams, PopoverController, IonicModule, NavController } from '@ionic/angular';
import { mocks } from '@testing/constants/mocks.service';
import { MyPlansService } from './my-plans.service';
import { MyBenefitsResolverService } from './benefits/benefits.resolver';
import { MyBenefitDetailsResolverService } from './benefitdetails/benefit-details.resolver';
import { CamelCaseModule } from '@app/pipes/camelcase/camel-case.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MY_PLANS_ROUTER } from './my-plans.routing';
import { MyPlansComponent } from './my-plans.component';
import { ConstantsService } from '@app/services/constants.service';
import { AlertsComponent } from '@app/components/alerts/alerts.component';

class MockNavParams {
  data = {};

  get(param) {
    return this.data[param];
  }
}

describe('Plan Details Component Page', () => {
  let component: MyPlansComponent;
  let alertService: AlertService;
  let fixture: ComponentFixture<MyPlansComponent>;

  let mockMyPlanService;
  let navCtrl: NavController;
  const modalSpy = jasmine.createSpyObj('Modal', ['present']);
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);
  modalCtrlSpy.create.and.callFake(() => {
    return modalSpy;
  });

  let store: Store;
  beforeEach(waitForAsync(() => {
    mockMyPlanService = mocks.service.myPlansService;
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        RouterTestingModule,
        NgxsModule.forRoot([]),
        NgxsSelectSnapshotModule.forRoot(),
        CommonModule,
        MY_PLANS_ROUTER,
        FormsModule,
        ReactiveFormsModule,
        IonicModule,
        CamelCaseModule
      ],
      providers: [
        IabService,
        ConstantsService,
        PopoverController,
        InAppBrowser,
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        },
        DatePipe,
        {
          provide: MyPlansService,
          useValue: mockMyPlanService
        },
        { provide: NavParams, useClass: MockNavParams },
        AlertService,
        ModalController,
        AngularDelegate,
        MyBenefitsResolverService,
        MyBenefitDetailsResolverService
      ],
      declarations: [MyPlansComponent, AlertsComponent]
    }).compileComponents();

    alertService = TestBed.inject(AlertService);
    store = TestBed.inject(Store);
    spyOn(store, 'selectSnapshot').and.returnValue({ authToken: { scopename: true } });
    navCtrl = TestBed.inject(NavController);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyPlansComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  xdescribe('shouild check planBenefitsList object after getPlansData api service', () => {
    it('should check plan from planBenefitsList object', () => {
      expect(component['planBenefitsList']['RowSet']['osplinPlans']['plans'][0].planName.length).toBeGreaterThan(0);
    });

    it('should check coveragePackageCode from planBenefitsList object', () => {
      expect(component['planBenefitsList']['RowSet']['osplinPlans']['plans'][0].coveragePackageCode.length).toBeGreaterThan(0);
    });

    it('should check foundFlag from planBenefitsList object', () => {
      expect(component['planBenefitsList']['RowSet']['osplinPlans']['plans'][0].foundFlag.length).toBeGreaterThan(0);
    });

    it('should check groupName from planBenefitsList with groupInfo object', () => {
      expect(component['planBenefitsList']['RowSet']['osplinPlans']['plans'][0].groupInfo.group[0].groupName.length).toBeGreaterThan(0);
    });

    it('should check groupName from planBenefitsList with groupInfo object', () => {
      expect(component['planBenefitsList']['RowSet']['osplinPlans']['plans'][0].groupInfo.group[0].groupName.length).toBeGreaterThan(0);
    });

    it('should check groupNumber from planBenefitsList with groupInfo object', () => {
      expect(component['planBenefitsList']['RowSet']['osplinPlans']['plans'][0].groupInfo.group[0].groupNumber.length).toBeGreaterThan(0);
    });

    it('should check lastName from planBenefitsList with osplinPlanMembers object', () => {
      expect(
        component['planBenefitsList']['RowSet']['osplinPlans']['plans'][0].osplinPlanMembers.members[0].lastName.length
      ).toBeGreaterThan(0);
    });

    it('should check memberId from planBenefitsList with osplinPlanMembers object', () => {
      expect(
        component['planBenefitsList']['RowSet']['osplinPlans']['plans'][0].osplinPlanMembers.members[0].memberId.length
      ).toBeGreaterThan(0);
    });

    it('should check isSelectedDateInvalid flag afet initErrorObj method call', () => {
      component.initErrorObj();
      expect(component.errorObj.isSelectedDateInvalid).toBeFalsy();
    });

    it('should check sixtyDaysInvalid flag afet initErrorObj method call', () => {
      component.initErrorObj();
      expect(component.errorObj.sixtyDaysInvalid).toBeFalsy();
    });

    it('should check sideNavStatus flag afet toggleFilter method call', () => {
      component.toggleFilter(false);
      expect(component.sideNavStatus.length).toBeGreaterThan(0);
    });

    it('should check sideNavStatus flag afet toggleFilter method call', () => {
      component.toggleFilter(true);
      expect(component.sideNavStatus).toBeTruthy();
    });

    it('should check showClearLink flag afet clearFilter method call', () => {
      component.clearFilter();
      expect(component.showClearLink).toBeFalsy();
    });

    it('should check isSearched flag afet clearFilter method call', () => {
      component.clearFilter();
      expect(component.isSearched).toBeFalsy();
    });

    it('should check navivigation back method after call goBack method', () => {
      const spyon = spyOn(navCtrl, 'back');
      component.goBack();
      expect(spyon).toHaveBeenCalled();
    });

    it('should check alertService clearError method after call goBack method', () => {
      const spyon = spyOn(alertService, 'clearError');
      component.ngOnDestroy();
      expect(spyon).toHaveBeenCalled();
    });

    it('should check fpoListingUrl  after call ngOnInit method', () => {
      component.ngOnInit();
      expect(component.fpoListingUrl.length).toBeGreaterThan(0);
    });

    it('should check fpoTargetUrl  after call ngOnInit method', () => {
      component.ngOnInit();
      expect(component.fpoTargetUrl.length).toBeGreaterThan(0);
    });

    it('should check title value in  template file', () => {
      const element = document.querySelector('ion-title');
      expect(element.innerHTML.length).toBeGreaterThan(0);
    });

    it('should check plan name value in  template file', () => {
      const element = document.querySelector('.plan-name-header');
      expect(element.innerHTML.length).toBeGreaterThan(0);
    });

    it('should check label name value in  template file', () => {
      const element = document.querySelector('.plan-label-name');
      expect(element.innerHTML.length).toBeGreaterThan(0);
    });

    it('should check dateValue value in  template file', () => {
      const element = document.querySelector('.plan-label-dateValue');
      expect(element.innerHTML.length).toBeGreaterThan(0);
    });
  });
});
