import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Store, NgxsModule } from '@ngxs/store';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { IabService } from '@app/services/iab.service';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { AlertService } from '@app/services/alert.service';
import { ModalController, AngularDelegate, NavParams, PopoverController, IonicModule } from '@ionic/angular';
import { mocks } from '@testing/constants/mocks.service';
import { MyPlansService } from './../my-plans.service';
import { MyBenefitsResolverService } from './../benefits/benefits.resolver';
import { MyBenefitDetailsResolverService } from './../benefitdetails/benefit-details.resolver';
import { CamelCaseModule } from '@app/pipes/camelcase/camel-case.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MY_PLANS_ROUTER } from './../my-plans.routing';
import { FilterPopoverComponent } from './filter-popover.component';
import { AlertsComponent } from '@app/components/alerts/alerts.component';

class MockNavParams {
  data = { filterDate: '10-10-2020' };

  get(param) {
    return this.data[param];
  }
}

describe('FilterPopoverComponent Page', () => {
  let component: FilterPopoverComponent;
  let fixture: ComponentFixture<FilterPopoverComponent>;
  let mockMyPlanService;
  let popoverController: PopoverController;

  const modalSpy = jasmine.createSpyObj('Modal', ['present']);
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);
  modalCtrlSpy.create.and.callFake(() => {
    return modalSpy;
  });

  let store: Store;
  beforeEach(waitForAsync(() => {
    mockMyPlanService = mocks.service.myPlansService;
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        RouterTestingModule,
        NgxsModule.forRoot([]),
        NgxsSelectSnapshotModule.forRoot(),
        CommonModule,
        MY_PLANS_ROUTER,
        FormsModule,
        ReactiveFormsModule,
        IonicModule,
        CamelCaseModule
      ],
      providers: [
        IabService,
        PopoverController,
        InAppBrowser,
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        },
        DatePipe,
        {
          provide: MyPlansService,
          useValue: mockMyPlanService
        },
        { provide: NavParams, useClass: MockNavParams },
        AlertService,
        ModalController,
        AngularDelegate,
        MyBenefitsResolverService,
        MyBenefitDetailsResolverService
      ],
      declarations: [FilterPopoverComponent, AlertsComponent]
    }).compileComponents();

    store = TestBed.inject(Store);
    spyOn(store, 'selectSnapshot').and.returnValue({ authToken: { scopename: true } });

    popoverController = TestBed.inject(PopoverController);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilterPopoverComponent);

    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check showFilter after checkSelected method without date', () => {
    component.selectedDate = '';
    component.checkSelected();
    expect(component.showFilter).toBeTruthy();
  });

  it('should check showFilter after checkSelected method with date', () => {
    component.selectedDate = '27-04-2020';
    component.checkSelected();
    expect(component.showFilter).toBeTruthy();
  });

  it('should check applyFilter method', () => {
    const spyon = spyOn(popoverController, 'dismiss');
    component.applyFilter();
    expect(spyon).toHaveBeenCalled();
  });

  it('should check applyFilter method', () => {
    const spyon = spyOn(popoverController, 'dismiss');
    component.applyFilter();
    expect(spyon).toHaveBeenCalled();
  });

  it('should check showFilter after call clearFilter method', () => {
    component.clearFilter();
    expect(component.showFilter).toBeFalsy();
  });

  it('should check selectedDate after call clearFilter method', () => {
    component.clearFilter();
    expect(component.selectedDate.length).toBeLessThan(1);
  });

  it('should check title value in  template file', () => {
    const element = document.querySelector('ion-title');
    expect(element.innerHTML.length).toBeGreaterThan(0);
  });

  it('should check filterText value in  template file', () => {
    const element = document.querySelector('.filterText');
    expect(element.innerHTML.length).toBeGreaterThan(0);
  });

  it('should check button label in  template file', () => {
    const element = document.querySelector('.btn-apply');
    expect(element.innerHTML.length).toBeGreaterThan(0);
  });
});
