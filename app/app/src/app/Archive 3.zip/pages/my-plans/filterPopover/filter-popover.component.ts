import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { NavParams, PopoverController } from '@ionic/angular';
import { format, sub } from 'date-fns';


@Component({
  selector: 'app-filter-popover',
  templateUrl: './filter-popover.component.html',
  styleUrls: ['./filter-popover.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FilterPopoverComponent implements OnInit {
  showFilter = false;
  selectedDate = '';
  maxDate: string;
  minDate: string;
  dateFormat = 'yyyy-MM-dd';
  currentPlan: string;

  constructor(private popoverController: PopoverController, private navParams: NavParams) {
    this.maxDate = format(new Date(), this.dateFormat);
    this.minDate = format(sub(new Date(), { years: 2}), this.dateFormat);
  }

  onDateChange($event) {
    this.selectedDate = $event.target.value.split('T')[0];
    this.checkSelected();
  }

  ngOnInit() {
    // this.selectedDate = this.navParams.data.filterDate || '';
    this.currentPlan = sessionStorage.getItem('previousPlanOnmemidOnFilter');
    if(this.currentPlan !== this.navParams.data.switchedPlan.cardMemId) {
      this.selectedDate = '';
      sessionStorage.setItem('previousPlanOnmemidOnFilter',this.navParams.data.switchedPlan.cardMemId);
      this.currentPlan = sessionStorage.getItem('previousPlanOnmemidOnFilter');
    }else {
      this.selectedDate = this.navParams.data.filterDate 
    }
    this.checkSelected();
  }

  checkSelected() {
    if (this.selectedDate) {
      this.showFilter = true;
    }
  }

  applyFilter() {
    this.popoverController.dismiss(this.selectedDate);
  }

  clearFilter() {
    this.selectedDate = '';
    this.showFilter = false;
    this.applyFilter();
  }
}
