import { Component, OnInit } from '@angular/core';
import { NavParams } from '@ionic/angular';
import { ConstantsService } from '@app/services/constants.service';

@Component({
  selector: 'app-popover',
  templateUrl: './popover.component.html',
  styleUrls: ['./popover.component.scss']
})
export class PopoverComponent implements OnInit {
  public fpoTargetTooltipUrl: string;
  tooltip: any;

  constructor(private navParams: NavParams, private constants: ConstantsService) {
    this.fpoTargetTooltipUrl = this.constants.drupalMyPlansDetailsTooltipUrl;
  }

  ngOnInit() {
    this.tooltip = this.navParams.data.tooltip;
  }
}
