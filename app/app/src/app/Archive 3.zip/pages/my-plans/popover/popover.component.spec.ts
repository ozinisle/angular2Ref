import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { NavParams, IonContent, IonicModule } from '@ionic/angular';
import { ConstantsService } from '@app/services/constants.service';
import { PopoverComponent } from './popover.component';

class MockNavParams {
  data = {};

  get(param) {
    return this.data[param];
  }
}

describe('PopoverComponent', () => {
  let component: PopoverComponent;
  let fixture: ComponentFixture<PopoverComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [IonicModule],
      providers: [{ provide: NavParams, useClass: MockNavParams }, ConstantsService, IonContent],
      declarations: [PopoverComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PopoverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
