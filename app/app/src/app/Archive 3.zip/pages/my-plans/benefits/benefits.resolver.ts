import { forkJoin, from, Observable } from 'rxjs';

import { catchError, map } from 'rxjs/operators';

import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { MyPlansService } from '../my-plans.service';
import { GetPlanBenefitServicesResponseModelInterface } from '../models/interfaces/plans-benefits-service-model.interface';

@Injectable()
export class MyBenefitsResolverService implements Resolve<Observable<GetPlanBenefitServicesResponseModelInterface | {}>> {
  constructor(public plansService: MyPlansService) {}

  resolve() {
    return forkJoin([
      this.plansService.getPlanBenefitServices(true).pipe(
        catchError(() => {
          return from(null);
        })
      ),
      this.plansService.getCiAcBenefitsRequest().pipe(
        catchError(() => {
          return from(null);
        }),
        map((result: any[]) => {
          return result && result.length ? result[0] : result;
        })
      )
    ]);
  }
}
