import { Location } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PlanConfigService } from '@app/services/plan-config/plan-config-service';
import { GlobalUtils } from '@app/utils/global.utils';
import { PopoverController } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { from, Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';
import { AlertType } from '../../../components/alerts/alert-type.model';
import { AlertService } from '../../../services/alert.service';
import { ConstantsService } from '../../../services/constants.service';
import { IabService } from '../../../services/iab.service';
import { AppSelectors } from '../../../store/selectors/app.selectors';
import { BenefitsFilterPopoverComponent } from '../benefitsFilterPopover/benefits-filter-popover.component';
import { NetworkType } from '../models/interfaces/benefits-model.interface';
import { MyPlansModuleRadioListInterface } from '../models/interfaces/plan-benefits-list-model.interface';
import { PlanEntityInterface } from '../models/interfaces/plan-benefits-page-adapted-data-model.inteface';
import { MyPlansService } from '../my-plans.service';

enum SORT_FLAG {
  A_Z = 'A-Z',
  Z_A = 'Z-A'
}

@Component({
  selector: 'app-benefits',
  templateUrl: './benefits.component.html',
  styleUrls: ['./benefits.component.scss']
})
export class BenefitsComponent implements OnInit, OnDestroy {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;
  @SelectSnapshot(AppSelectors.isDefaultPlan) isDefaultPlan: boolean;


  isSidenavOpened = false;
  sideNavStatus: string;
  index: number;
  showClearLink: boolean;
  sortSelectedFilter: string;
  collapsedHeight: string;
  expandedHeight: string;
  benefitList;
  sortList: MyPlansModuleRadioListInterface[];
  plans = [];
  selectedPlan: PlanEntityInterface;
  effectiveStartDate = '';
  effectiveEndDate = '';
  keys = Object.keys;
  contactus: string;
  fpoTargetUrl: string;
  planName: string;
  ismobile: boolean;
  private unsubscribeHelper$: Subject<void> = new Subject<void>();
  ciAcBenefits: any;
  hasCvsLink =  false;

  constructor(
    public myPlansService: MyPlansService,
    private alertService: AlertService,
    private route: ActivatedRoute,
    private constants: ConstantsService,
    private location: Location,
    private popoverController: PopoverController,
    private iabService: IabService,
    private resizeService: GlobalUtils,
    private planConfigService: PlanConfigService
  ) {
    const resolvedData = {...this.route.snapshot.data};
    if (resolvedData && resolvedData.benefits) {
      if (resolvedData.benefits['result'] < 0) {
        this.alertService.setAlert(resolvedData.benefits['displaymessage'], '', AlertType.Failure);
        this.benefitList = [];
      } else {
        this.benefitList = this.route.snapshot.data.benefits[0].planBenefits;
        this.planName = this.route.snapshot.data.benefits[0].planName;
      }
      if (this.route.snapshot.data.benefits[1]) {
        this.ciAcBenefits = this.route.snapshot.data.benefits[1];
        this.benefitList = [this.ciAcBenefits, ...this.benefitList];
      }
    } else {
      this.getBenefits(SORT_FLAG.A_Z);
    }
    this.selectedPlan = this.myPlansService.getSelectedPlanEntity();
    if (this.selectedPlan) {
      this.effectiveStartDate = this.selectedPlan.effectiveStartDate;
      this.effectiveEndDate = this.selectedPlan.effectiveEndDate;
    }
    this.contactus = this.constants.contactus + this.authToken.scopename;
    this.sortSelectedFilter = SORT_FLAG.A_Z;
    this.sortList = [
      {
        value: SORT_FLAG.A_Z,
        text: SORT_FLAG.A_Z,
        checked: true
      },
      {
        value: SORT_FLAG.Z_A,
        text: SORT_FLAG.Z_A,
        checked: false
      }
    ];

    this.fpoTargetUrl = this.constants.drupalMyBenefitsUrl;
  }

  ngOnInit() {
    this.resizeService.getIsMobile().pipe(takeUntil(this.unsubscribeHelper$))
    .subscribe((isMobile: boolean) => this.ismobile = isMobile );
    this.planConfigService.getCurrentPlanConfig$().pipe(takeUntil(this.unsubscribeHelper$)).subscribe( data =>{
      this.hasCvsLink = data.elligibility.hasCvsLink;
    });
  }

  ngOnDestroy() {
    this.unsubscribeHelper$.next();
    this.unsubscribeHelper$.complete();
  }

  async showFilterPopover(ev: any) {
    const filterPopover = await this.popoverController.create({
      component: BenefitsFilterPopoverComponent,
      event: ev,
      translucent: true,
      componentProps: {
        sortList: this.sortList
      },
      backdropDismiss: false
      // mode: 'ios'
    });
    from(filterPopover.onDidDismiss())
      .pipe(filter((dataReturned: any) => dataReturned && dataReturned.data !== undefined))
      .subscribe((dataReturned: any) => {
        this.sortList = dataReturned.data;
        this.sortSelectedFilter = this.sortList.find(item => item.checked).value;
        this.getBenefits(this.sortSelectedFilter);
      });
    return await filterPopover.present();
  }

  handleFilterOut(event) {
        this.sortList = event;
        this.sortSelectedFilter = this.sortList.find(item => item.checked).value;
        this.getBenefits(this.sortSelectedFilter);
  }

  getBenefits(sortFlag: string) {
    this.myPlansService.getPlanBenefitServices(false, sortFlag).subscribe(response => {
      if (response['result'] < 0) {
        this.alertService.setAlert(response['displaymessage'], '', AlertType.Failure);
        this.benefitList = [];
        return;
      }
      // this.closeExpansionPanel();
      this.benefitList = response.planBenefits;
      if (this.ciAcBenefits) {
        if (sortFlag === 'A-Z') {
          this.benefitList.unshift(this.ciAcBenefits);
        } else {
          this.benefitList.push(this.ciAcBenefits);
        }
      }
    });
  }

  setBenefitName(planBenefit: any) {
    this.myPlansService.clearCIAcBenefitDetails();
    if (planBenefit.planBenefitName) {
      this.myPlansService.setServiceBenefitCategoryName(planBenefit.planBenefitName);
    } else {
      this.myPlansService.setServiceBenefitCategoryName(planBenefit);
      this.myPlansService.setCiAcBenefitDetails(planBenefit);
    }
  }

  isNetwork(network: string): boolean {
    return (
      network === NetworkType.inNetwork || network === NetworkType.outOfNetwork || network === NetworkType.inNetworkAndOutOfNetworkCombined
    );
  }

  navigateToContactUs() {
    this.iabService.create(this.contactus);
  }

  goBack() {
    this.location.back();
  }
}
