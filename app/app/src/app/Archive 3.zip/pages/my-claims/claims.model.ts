export enum Status {
  Complete = 'C' as any,
  Denied = 'D' as any,
  Pending = 'P' as any
}

export class RadioList {
  value: string;
  checked: boolean;
}

export class MockClaim {
  DOS: string;
  clmStatus: string;
  memNum: number;
  date: Date;
}

export class StateHelper {
  initializeSelectedAndDisabledStates(item: any): any {
    item = { ...item, selected: this.ifUndefinedSetToFalse(item.selected), disabled: this.ifUndefinedSetToFalse(item.disabled) };
    return item;
  }
  ifUndefinedSetToFalse(nullableBool?: boolean): any {
    return nullableBool === undefined ? false : nullableBool;
  }
}

