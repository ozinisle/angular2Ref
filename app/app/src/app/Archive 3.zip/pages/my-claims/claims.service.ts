import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Injectable} from '@angular/core';
import {BehaviorSubject, Observable, of as observableOf} from 'rxjs';
import {MockClaim} from './claims.model';
import {ConstantsService} from '@app/services/constants.service';
import {GET_REIMBURSEMENT_BENEFITS_ENDPOINT} from "@app/pages/fwb/constants/fitness.constants";
import {SelectSnapshot} from "@ngxs-labs/select-snapshot";
import {AppSelectors} from "@app/store/selectors/app.selectors";
import {
  GetMemBasicInfoRequestModelInterface,
  GetMemBasicInfoResponseModelInterface
} from "@app/pages/my-medication/models/interfaces/get-member-basic-info-model.interface";
import {
  GetMemBasicInfoRequestModel,
  GetMemBasicInfoResponseModel
} from "@app/pages/my-medication/models/get-member-basic-info.model";
import {map} from "rxjs/operators";
import {SetBasicMemberInfo} from "@app/store/actions/app.actions";
import {Store} from "@ngxs/store";

@Injectable({providedIn: 'root'})
export class ClaimsService {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getBasicMemberInfo) basicMemInfo: any;
  @SelectSnapshot(AppSelectors.getAccessToken) token: string;
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;

  private claimRecord = new BehaviorSubject<MockClaim>(null);
  public claimRecord$ = this.claimRecord.asObservable();

  constructor(private http: HttpClient, private constants: ConstantsService, private store: Store) {
  }

  getClaimDetails(body): Observable<any> {
    const url = body.depid ? this.constants.claimsdepdetailsUrl : this.constants.claimdetailsUrl;
    return this.http.post(url, body);
  }

  getClaimProcessingStatus(requestParams) {
    const url = this.constants.claimProcessingStatusUrl;
    return this.http.post(url, requestParams);
  }

  getClaimsBenefitsLink(body): Observable<any> {
    const url = this.constants.benefitsLinkUrl;
    return this.http.post(url, body);
  }

  getCostShareClaimStatusMessage(): Observable<any> {
    return this.http.get(this.constants.drupalCostShareForClaimsUrl);
  }

  getBenefitsInfo(): Observable<any> {
    const request = {
      useridin: this.useridin,
      isCommercial: 'true'
    };
    return this.http.post(GET_REIMBURSEMENT_BENEFITS_ENDPOINT, request);
  }

  getClaimId(): Observable<any> {
    const request = {
      useridin: this.useridin,
    };
    return this.http.post(this.constants.userClaimEndPoint, request).pipe(map(data => data as any));
  }

  uploadDocument(blob: Blob, format: string, claimID: string): Observable<any> {

    let formatType = 'image/png';

    if (format === 'jpg') {
      formatType = 'image/jpg';
    } else if (format === 'pdf') {
      formatType = 'application/pdf'
    }

    const filename = `file.png`;
    console.log('the file name is ', filename);
    console.log('formatt type', formatType);

    const file = new File([blob], filename, {
      type: formatType,
    });
    const fd = new FormData();
    fd.append('file', file);
    fd.append('format', format);

    console.log('sneding doc');

    return this.http.post(`${this.constants.userClaimEndPoint}/${claimID}/documents`, fd);
  }

  getMemBasicInfo(): Observable<GetMemBasicInfoResponseModelInterface> {
    if (this.basicMemInfo) {
      return observableOf(this.basicMemInfo);
    }
    const request: GetMemBasicInfoRequestModelInterface = new GetMemBasicInfoRequestModel();
    request.useridin = this.useridin;

    return this.http.post<any>(this.constants.getMemBasicInfoUrl, request).pipe(
      map(response => {
        if (response.result < 0) {
          return new GetMemBasicInfoResponseModel();
        } else {
          const basicInfo = new GetMemBasicInfoResponseModel();
          basicInfo.rxSummary = response.getMemBasicInfoResponse;
          this.store.dispatch(new SetBasicMemberInfo(basicInfo));
          return basicInfo as GetMemBasicInfoResponseModel;
        }
      })
    );
  }

  deleteDocument(claimID, myFile, myData: any) {
    console.log('this delete', this.authToken);
    const request = {
      Authorization: `Bearer ${this.authToken.access_token}`
    };

    return this.http.delete(`${this.constants.userClaimEndPoint}/documents/${myData.documentObjectId}`,  { headers: new HttpHeaders( request ) });
  }
}
