import { AlertsModule } from '@app/components/alerts/alerts.module';
import { BreadcrumbModule } from '@app/components/breadcrumbs/breadcrumbs.module';
import { CLAIMS_APP_ROUTER } from './claims.routing';
import { CalendarModule } from 'ion2-calendar';
import { ClaimDetailsPage } from './claim-details/claim-details.page';
import { ClaimFormPage } from './claim-form/claim-form.component';
import { ClaimIdModule } from '@app/pipes/claim-id/claim-id.module';
import { ClaimStatusDetailsPage } from './claim-status-details/claim-status-details.page';
import { ClaimsPage } from './claims/claims.page';
import { ClaimsService } from './claims.service';
import { CommonModule } from '@angular/common';
import { DatePipe } from '@angular/common';
import { FileUploadResultModalModule } from '@app/modals/file-upload-result-modal/file-upload-result-modal.module';
import { FilterClaimsComponent } from './claims/filter-claims/filter-claims.component';
import { FilterPipe } from 'ngx-filter-pipe';
import { FilterPipeModule } from 'ngx-filter-pipe';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FpoLayoutModule } from '@app/components/fpo-layout/fpo-layout.module';
import { IabClickBlockModule } from '@app/components/Iab-component/iab-click-block.module';
import { IonicModule } from '@ionic/angular';
import { MatExpansionModule } from '@angular/material/expansion';
import { MaterialModule } from '@app/material.module';
import { NgModule } from '@angular/core';
import { NgxCurrencyModule } from 'ngx-currency';
import { NgxMaskModule } from 'ngx-mask';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { IntegratedPlanAcccessModule } from '../integrated-plan-access/integrated-plan-access.module';
import { OrderModule } from 'ngx-order-pipe';
import { PromoImagesModule } from '@app/components/promo/promo-images/promo-images.module';
import { TextMaskModule } from 'angular2-text-mask';
import { TitleCasePipe } from '@angular/common';
import { VisitCommonModule } from '@app/pages/virtual-visit/components/common/visit-common.module';
import { FontAwesomeLibraryModule } from '@app/fontawesome-library.module';
import { CurrencyMaskDirective } from '@app/directives/format-decimal.directive';

@NgModule({
  declarations: [ClaimsPage, ClaimDetailsPage, ClaimStatusDetailsPage, FilterClaimsComponent, ClaimFormPage, CurrencyMaskDirective],
  imports: [
    AlertsModule,
    CLAIMS_APP_ROUTER,
    CalendarModule,
    ClaimIdModule,
    CommonModule,
    FileUploadResultModalModule,
    FilterPipeModule,
    FontAwesomeModule,
    FontAwesomeLibraryModule,
    FormsModule,
    FpoLayoutModule,
    IabClickBlockModule,
    IonicModule,
    ReactiveFormsModule,
    BreadcrumbModule,
    MatExpansionModule,
    MaterialModule,
    NgxCurrencyModule,
    NgxMaskModule,
    OrderModule,
    PromoImagesModule,
    FpoLayoutModule,
    IabClickBlockModule,
    NgxMaskModule,
    FontAwesomeModule,
    CalendarModule,
    AlertsModule,
    IntegratedPlanAcccessModule,
    TextMaskModule,
    VisitCommonModule,
  ],
  providers: [ClaimsService, DatePipe, FilterPipe, TitleCasePipe]
})
export class ClaimsAppModule {}
