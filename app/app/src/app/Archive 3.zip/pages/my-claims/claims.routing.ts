import { RouterModule, Routes } from '@angular/router';
import { ClaimDetailsPage } from './claim-details/claim-details.page';
import { ClaimStatusDetailsPage } from './claim-status-details/claim-status-details.page';
import { ClaimsPage } from './claims/claims.page';
import { ClaimFormPage } from './claim-form/claim-form.component';

const CLAIMS_APP_ROUTES: Routes = [
  {
    path: '',
    component: ClaimsPage,
    data: {
      pageTitle: 'My Claims'
    }
  },
  {
    path: 'claimform',
    component: ClaimFormPage,
    data: {
      pageTitle: 'My Claim Form',
      breadcrumb: 'Claim Form'
    }
  },
  {
    path: 'claimdetails',
    component: ClaimDetailsPage,
    data: {
      pageTitle: 'Claim Detail',
      breadcrumb: 'Claim Details'
    }
  },
  {
    path: ':detail/:claimstatusdetails',
    component: ClaimStatusDetailsPage,
    data: {
      pageTitle: 'Claim Status Detail',
      breadcrumb: 'Claim Status Detail'
    }
  }
];

export const CLAIMS_APP_ROUTER = RouterModule.forChild(CLAIMS_APP_ROUTES);
