import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { MedLookupToolPage } from './med-lookup-tool.page';
import { DomSanitizer } from '@angular/platform-browser';
import { IonicModule } from '@ionic/angular';

describe('MedLookupToolPage', () => {
  let component: MedLookupToolPage;
  let sanitizer: DomSanitizer;
  let fixture: ComponentFixture<MedLookupToolPage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [IonicModule],
      declarations: [MedLookupToolPage]
    }).compileComponents();
    sanitizer = TestBed.inject(DomSanitizer);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedLookupToolPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should contain text Medication Lookup Tool on ion-title', () => {
    const element = document.querySelector('ion-title');
    expect(element).toBeTruthy();
    expect(element.textContent.length).toBeGreaterThan(0);
  });

  it('should contain iframe', () => {
    const element = document.querySelector('iframe');
    expect(element).toBeDefined();
  });

  it('should call sanitize bypassSecurityTrustResourceUrl on ngoninit', () => {
    const sanitizeSpy = spyOn(sanitizer, 'bypassSecurityTrustResourceUrl');
    component.ngOnInit();
    expect(sanitizeSpy).toHaveBeenCalled();
  });

  it('should deinfe pageurl,screenWidth,screenHeight', () => {
    component.ngOnInit();
    expect(component.pageUrl).toBeTruthy();
    expect(component.screenHeight).toBeTruthy();
    expect(component.screenWidth).toBeTruthy();
  });
});
