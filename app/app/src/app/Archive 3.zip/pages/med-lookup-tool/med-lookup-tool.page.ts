import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { Location } from '@angular/common';

@Component({
  selector: 'app-med-lookup-tool',
  templateUrl: './med-lookup-tool.page.html',
  styleUrls: ['./med-lookup-tool.page.scss']
})
export class MedLookupToolPage implements OnInit {
  pageUrl: SafeResourceUrl;
  screenWidth: number;
  screenHeight: number;
  constructor(private sanitize: DomSanitizer, private location: Location) {}

  ngOnInit() {
    this.pageUrl = this.sanitize.bypassSecurityTrustResourceUrl(
      'http://20181129medication.test-bluecrossma.acsitefactory.com/?referer=mobile-app'
    );
    this.screenWidth = screen.width;
    this.screenHeight = screen.height;
  }

  goBack() {
    this.location.back();
  }
}
