import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { RouterModule, Routes } from '@angular/router';
import { LandingPageModule } from './landing/landing.module';
import { ReactiveFormsModule } from '@angular/forms';
import { LandingPage } from './landing/landing.page';
import { SearchListPage } from './search-list/search-list.page';
import { SearchListPageModule } from './search-list/search-list.module';
import { MedicationViewPage } from './medication-view/medication-view.page';
import { MedicationViewPageModule } from './medication-view/medication-view.module';
const routes: Routes = [
  {
    path: '',
    component: LandingPage
  },
  {
    path: 'search-list',
    component: SearchListPage
  },
  {
    path: 'medication-view',
    component: MedicationViewPage
  }
];

@NgModule({
  declarations: [],
  imports: [CommonModule, IonicModule, RouterModule.forChild(routes), LandingPageModule, MedicationViewPageModule, SearchListPageModule, ReactiveFormsModule]
})
export class MedLookupSearchModule {}
