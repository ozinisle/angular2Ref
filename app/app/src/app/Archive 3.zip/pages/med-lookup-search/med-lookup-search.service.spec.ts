import { TestBed } from '@angular/core/testing';

import { MedLookupSearchService } from './med-lookup-search.service';

describe('MedLookupSearchService', () => {
  let service: MedLookupSearchService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MedLookupSearchService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
