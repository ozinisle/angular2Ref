import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { v4 as uuid } from 'uuid';
import { MedicationDetailModel, MedictionsSearchResultsModel, MedlookupsModel } from './models/search-results';
import { ConstantsService } from '@app/services/constants.service';
@Injectable({
  providedIn: 'root'
})
export class MedLookupSearchService {
  @SelectSnapshot(AppSelectors.getAccessToken) token: string;
  @SelectSnapshot(AppSelectors.getMemProfile) memProfile;
  constructor(public http: HttpClient, public constantService: ConstantsService) {}

  getMedicationSearchList(medicationtype, pages, q): Observable<MedictionsSearchResultsModel> {
    const url = `${this.constantService.medlookupUrl}?medicationType=${medicationtype}&medicationKeyword=${encodeURIComponent(
      q
    )}&page=${pages}`;
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: 'Bearer ' + this.token,
        uitxnid: 'APP_v5.0_' + uuid()
      })
    };
    return this.http.get(url, httpOptions).pipe(map(data => data as MedictionsSearchResultsModel));
  }

  getMedicationDetail(medicationID, planTier): Observable<MedicationDetailModel> {
    const url = `${this.constantService.medlookupDetailUrl}?medicationID=${medicationID}&planTier=${planTier}`;
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: 'Bearer ' + this.token,
        uitxnid: 'APP_v5.0_' + uuid()
      })
    };
    return this.http.get(url, httpOptions).pipe(map(data => data as MedicationDetailModel));
  }

  getStaticLinks() {
    if (!sessionStorage.getItem('staticLinks')) {
      const importantInformationurl = `${this.constantService.medlookupStaticLinkUrl}?medicationPdfType=allPdfLinks&showMore=true`;
      const httpOptions = {
        headers: new HttpHeaders({
          Authorization: 'Bearer ' + this.token,
          uitxnid: 'APP_v5.0_' + uuid()
        })
      };
      this.http.get(importantInformationurl, httpOptions).subscribe(data => {
        sessionStorage.setItem('staticLinks', JSON.stringify(data));
      });
    }
  }

  getformularyandtierInfo(): Observable<MedlookupsModel> {
    if (this.memProfile?.subscriberId && this.memProfile?.memberSuffix && this.memProfile?.groupUaCvg) {
      const url = `${this.constantService.medlookupFormularyAndTier}`;
      const reqParams = {
        useridin: this.memProfile?.useridin,
        subscriberId: this.memProfile?.subscriberId,
        memberSuffix: this.memProfile?.memberSuffix,
        groupUaCvg: this.memProfile?.groupUaCvg
      };
      return this.http.post(url, reqParams).pipe(map(data => data as MedlookupsModel));
    } else {
      return of(null);
    }
  }

  getTierMapping(): any {
    if (!sessionStorage.getItem('tireMappingData')) {
      const url = `${this.constantService.medlookupTierMapping}`;
      const httpOptions = {
        headers: new HttpHeaders({
          Authorization: 'Bearer ' + this.token,
          uitxnid: 'APP_v5.0_' + uuid()
        })
      };
      this.http.get(url, httpOptions).subscribe(
        data => {
          sessionStorage.setItem('tireMappingData', JSON.stringify(data));
        },
        err => {
          sessionStorage.setItem('tireMappingData', '');
        }
      );
    }
  }
}
