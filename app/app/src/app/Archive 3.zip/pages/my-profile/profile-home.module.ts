import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatGridListModule } from '@angular/material/grid-list';
import { IonicModule } from '@ionic/angular';
import { TextMaskModule } from 'angular2-text-mask';
import { AboutMeComponent } from './about-me/about-me.component';
import { AccountSecurityComponent } from './account-security/account-security.component';
import { CommunicationPreferencesComponent } from './communication-preferences/communication-preferences.component';

import { ContactInfoComponent } from './contact-info/contact-info.component';
import { PopoverComponent } from './popover/popover.component';
import { ProfileComponent } from './profile/profile.component';
import { PROFILE_HOME_ROUTER } from './profile-home.routing';
import { VerifyEmailMobileModule } from './verify-email-mobile/verify-email-mobile.module';
import { AlertsModule } from '@app/components/alerts/alerts.module';
import { NgxMaskModule } from 'ngx-mask';
import { CamelCaseModule } from '@app/pipes/camelcase/camel-case.module';
import { PromoImagesModule } from '@app/components/promo/promo-images/promo-images.module';
import { AppControlMessagesModule } from '@app/components/app-control-messages/app-control-messages.module';
import { PreferenceVerifyChannelModule } from '@app/components/preference-verify-channel/preference-verify-channel.module';
import { PreferenceSelectionsModule } from '@app/components/preference-selections/preference-selections.module';
import { WordwrapModule } from '@app/directives/wordwrap/wordwrap.module';
import { PasswordControlMessageModule } from '@app/components/password-control-messages/password-control-message.module';
import { FpoLayoutModule } from '@app/components/fpo-layout/fpo-layout.module';
import { LearnMoreModalComponent } from './about-me/learn-more-modal/learn-more-modal.component';
import { ConfirmModalComponent } from './about-me/confirm-modal/confirm-modal.component';
import { IonicSelectableModule } from 'ionic-selectable';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { NumberOnlyDirectiveModule } from '@app/directives/number-only/number-only.directive.module';

@NgModule({
  imports: [
    CommonModule,
    PROFILE_HOME_ROUTER,
    FormsModule,
    ReactiveFormsModule,
    TextMaskModule,
    MatTooltipModule,
    MatGridListModule,
    IonicModule,
    AlertsModule,
    NgxMaskModule,
    CamelCaseModule,
    PromoImagesModule,
    VerifyEmailMobileModule,
    AppControlMessagesModule,
    PreferenceVerifyChannelModule,
    PreferenceSelectionsModule,
    WordwrapModule,
    PasswordControlMessageModule,
    FpoLayoutModule,
    IonicSelectableModule,
    FontAwesomeModule,
    NumberOnlyDirectiveModule
  ],
  providers: [],
  declarations: [
    ProfileComponent,
    AccountSecurityComponent,
    ContactInfoComponent,
    AboutMeComponent,
    PopoverComponent,
    CommunicationPreferencesComponent,
    LearnMoreModalComponent,
    ConfirmModalComponent
  ]
})
export class ProfileHomeModule {}
