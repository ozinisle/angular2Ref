import { RouterModule, Routes } from '@angular/router';
import { AboutMeComponent } from './about-me/about-me.component';
import { AccountSecurityComponent } from './account-security/account-security.component';
import { ContactInfoComponent } from './contact-info/contact-info.component';
import { ProfileComponent } from './profile/profile.component';
import { VerifyEmailMobileComponent } from './verify-email-mobile/verify-email-mobile.component';
import { CommunicationPreferencesComponent } from './communication-preferences/communication-preferences.component';

const REGISTER_ROUTER: Routes = [
  {
    path: '',
    children: [
      {
        path: '',
        component: ProfileComponent
      }
    ]
  },
  {
    path: 'verify',
    children: [
      {
        path: '',
        component: VerifyEmailMobileComponent
      }
    ]
  },
  {
    path: 'account-security',
    component: AccountSecurityComponent
  },
  {
    path: 'contact-info',
    component: ContactInfoComponent,
    runGuardsAndResolvers: 'always'
  },
  {
    path: 'about-me',
    component: AboutMeComponent
  },
  {
    path: 'communication-preferences',
    component: CommunicationPreferencesComponent,
    runGuardsAndResolvers: 'always'
  }
];

export const PROFILE_HOME_ROUTER = RouterModule.forChild(REGISTER_ROUTER);
