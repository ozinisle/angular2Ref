import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { IonicModule } from '@ionic/angular';

import { TooSoonPage } from './too-soon.page';

const routes: Routes = [
  {
    path: '',
    component: TooSoonPage
  }
];

@NgModule({
  imports: [CommonModule, FormsModule, IonicModule, FontAwesomeModule, RouterModule.forChild(routes)],
  declarations: [TooSoonPage]
})
export class TooSoonPageModule {}
