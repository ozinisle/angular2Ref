import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { PostLoginModel } from '@app/models/post-login.model';
import { ConstantsService } from '@app/services/constants.service';
import { Logout } from '@app/store/actions/app.actions';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Store } from '@ngxs/store';
import { format } from 'date-fns';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

interface DrupalResponse {
  Body: string;
}

@Component({
  selector: 'too-soon',
  templateUrl: './too-soon.page.html',
  styleUrls: ['./too-soon.page.scss']
})
export class TooSoonPage implements OnInit {
  startDate: Date;
  content$: Observable<string>;

  @SelectSnapshot(AppSelectors.getPostLoginInfo) postLoginInfo: PostLoginModel;

  constructor(
    private store: Store,
    private constantsService: ConstantsService,
    private http: HttpClient
  ) {}

  ngOnInit() {
    // Get content from drupal and inject date
    this.content$ = this.http
      .get<DrupalResponse[]>(this.constantsService.drupalFutureEnrolleeUrl)
      .pipe(map(response => this.handdleDrupalResponse(response)));
  }

  /**
   * Extract the html fragment from drupal response and inject the date.
   * @param html to be inserted in the page
   */
  private handdleDrupalResponse(response: DrupalResponse[]): string {
    if (response[0]) {
      let content = response[0].Body;
      const startMoment = format(new Date(this.postLoginInfo.coverageEffecDt), this.constantsService.coverageEffectiveDateFormat)
      const formatedStartDate = format(new Date(startMoment), this.constantsService.futureEnrolleeStartDateDisplayFormat);
      content = content.replace(this.constantsService.drupalFutureEnrolleeDateToken, formatedStartDate);
      return content;
    }
    return '';
  }

  logout() {
    sessionStorage.clear();
    this.store.dispatch(new Logout());
  }
}
