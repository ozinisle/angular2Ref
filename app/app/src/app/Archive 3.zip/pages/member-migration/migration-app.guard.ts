import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { MigrationGuardHelper } from './migration-guard-helper';

@Injectable({ providedIn: 'root' })
export class MigrationAppGuard implements CanActivate {
  constructor(private router: Router) {}

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    return MigrationGuardHelper.naivgateToRequiredStep(this.router, state.url);
  }
}
