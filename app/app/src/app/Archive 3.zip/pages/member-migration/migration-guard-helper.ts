export class MigrationGuardHelper {
  static naivgateToRequiredStep(router, desiredUrl) {
    const sendCodeRes = sessionStorage.getItem('sendCodeRes');
    if (sendCodeRes) {
      return this.checkAndNavgateUrl('/member-migration/verify', desiredUrl, router);
    } else {
      const migrationReq = sessionStorage.getItem('migrationReq');
      const migrationReJson = migrationReq ? JSON.parse(migrationReq) : null;
      const migrationConfirmed = sessionStorage.getItem('migrationConfirmed') || null;
      if (migrationReJson && migrationReJson.hintAnswer) {
        if (migrationConfirmed === 'true') {
          return this.checkAndNavgateUrl('/member-migration/updatePassword', desiredUrl, router);
        }
        return this.checkAndNavgateUrl('/member-migration/confirm', desiredUrl, router);
      }
    }
    return this.checkAndNavgateUrl('/member-migration', desiredUrl, router);
  }

  static checkAndNavgateUrl(url: string, desiredURL: string, router) {
    if (desiredURL === '/member-migration' && url === '/member-migration/confirm') {
      return true;
    } else if (desiredURL === '/member-migration/confirm' && url === '/member-migration/updatePassword') {
      return true;
    } else if (desiredURL === url) {
      return true;
    } else if (desiredURL === '/member-migration/updatePassword' && url === '/member-migration/verify') {
      return true;
    } else {
      router.navigate([url]);
      return false;
    }
  }
}
