import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { IonicModule } from '@ionic/angular';
import { TextMaskModule } from 'angular2-text-mask';
import { MIGRATION_APP_ROUTER } from './member-migration-app.routing';
import { MigrationAppGuard } from './migration-app.guard';
import { MigrationAppService } from './migration-app.service';
import { ProfileInfoAppPage } from './profile-info-app/profile-info-app.page';
import { MigrationConfirmationAppPage } from './profile-info-update-app/migration-confirmation-app/migration-confirmation-app.page';
import { MigrationSuccessAppPage } from './profile-info-update-app/migration-success-app/migration-success-app.page';
import { UpdatePasswordAppPage } from './profile-info-update-app/update-password-app/update-password-app.page';
import { VerifyEmailMobileAppPage } from './profile-info-update-app/verify-email-mobile-app/verify-email-mobile-app.page';
import { AlertsModule } from '@app/components/alerts/alerts.module';
import { AppControlMessagesModule } from '@app/components/app-control-messages/app-control-messages.module';
import { WordwrapModule } from '@app/directives/wordwrap/wordwrap.module';
import { NumberOnlyDirectiveModule } from '@app/directives/number-only/number-only.directive.module';
import { AutofocusDirectiveModule } from '@app/directives/autofocus/autofocus.directive.module';
import { PasswordControlMessageModule } from '@app/components/password-control-messages/password-control-message.module';
@NgModule({
  imports: [
    IonicModule,
    CommonModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    MIGRATION_APP_ROUTER,
    TextMaskModule,
    AlertsModule,
    AppControlMessagesModule,
    WordwrapModule,
    NumberOnlyDirectiveModule,
    AutofocusDirectiveModule,
    PasswordControlMessageModule
  ],
  declarations: [
    ProfileInfoAppPage,
    UpdatePasswordAppPage,
    VerifyEmailMobileAppPage,
    MigrationSuccessAppPage,
    MigrationConfirmationAppPage
  ],
  providers: [MigrationAppService, MigrationAppGuard]
})
export class MemberMigrationAppModule {}
