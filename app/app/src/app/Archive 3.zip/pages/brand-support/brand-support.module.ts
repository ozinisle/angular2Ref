import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { BrandSupportPageRoutingModule } from './brand-support-routing.module';
import { BrandSupportPage } from './brand-support.page';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BrandSupportPageRoutingModule,
    FontAwesomeModule
  ],
  declarations: [BrandSupportPage]
})
export class BrandSupportPageModule {}
