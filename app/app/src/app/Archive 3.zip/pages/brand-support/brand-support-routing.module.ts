import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BrandSupportPage } from './brand-support.page';

const routes: Routes = [
  {
    path: '',
    component: BrandSupportPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BrandSupportPageRoutingModule {}
