import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IabService } from '@app/services/iab.service';
import { SwrveEventNames, SwrveService } from '@app/services/swrve.service';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { from, Subject } from 'rxjs';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { environment } from '@environments/environment';
import { GlobalUtils } from '@app/utils/global.utils';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-brand-support',
  templateUrl: './brand-support.page.html',
  styleUrls: ['./brand-support.page.scss']
})
export class BrandSupportPage implements OnInit, OnDestroy {
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;
  @SelectSnapshot(AppSelectors.getUserType) userType: string;
  isAuthenticatedUser: boolean;
  isAnonymousUser: boolean;
  isRegisteredUser: boolean;
  authenticatedSecureMessage = environment.secureMessageInquiryUrl;
  talkToDoctor = 'https://myblue.bluecrossma.com/health-plan/well-connection';
  sendSecureLink = 'https://myblue.bluecrossma.com/form/inquiry';
  ismobile: boolean;
  private unsubscribeHelper$: Subject<void> = new Subject<void>();
  constructor(
    private router: Router,
    public swrveEventNames: SwrveEventNames,
    private iabService: IabService,
    private swrveService: SwrveService,
    private callNumber: CallNumber,
    private resizeService: GlobalUtils
  ) {}

  ngOnInit() {
    this.resizeService.getIsMobile().pipe(takeUntil(this.unsubscribeHelper$))
    .subscribe((isMobile: boolean) => this.ismobile = isMobile );
  }

  ngOnDestroy(): void {
    this.unsubscribeHelper$.next();
    this.unsubscribeHelper$.complete();
  }

  ionViewWillEnter() {
    this.swrveService.sendAppMessage(this.swrveEventNames.appScreenContactUs);
  }

  sendSwerve(event) {
    this.swrveService.sendAppMessage(event);
  }

  goBack() {
    this.router.navigate(['/brand-home']);
  }

  callHelpLine(number: string, swrveEventName: string) {
    from(this.callNumber.callNumber(number, true)).subscribe();
    this.sendSwerve(swrveEventName);
  }

  openInAppBrowser(url, isExternal) {
    if (!isExternal) {
      this.router.navigate([url]);
    } else {
      this.iabService.create(url);
    }
  }
}
