import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AppSelectors } from '../../../app/store/selectors/app.selectors';
import { AuthToken } from '../../../app/models/auth-token.model';
import { CheckForModal } from '../../../app/store/actions/profile.action';
import { Store } from '@ngxs/store';

@Component({
  selector: 'app-first-time.page',
  templateUrl: './first-time.page.component.html',
  styleUrls: ['./first-time.page.component.scss']
})
export class FirstTimePage {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: AuthToken;

  constructor(private route: Router, private store: Store) {}

  goHome() {
    if (
      this.authToken.destinationURL &&
      this.authToken.migrationtype === 'NONE' &&
      this.authToken.scopename !== 'AUTHENTICATED-NOT-VERIFIED'
    ) {
      this.route.navigate([this.authToken.destinationURL]);
      this.store.dispatch(new CheckForModal());
    } else {
      this.route.navigateByUrl('home');
      this.store.dispatch(new CheckForModal());
    }
  }
}
