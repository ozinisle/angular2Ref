import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { FirstTimePage } from './first-time.page.component';
import { of } from 'rxjs';
import { Store } from '@ngxs/store';
import { By } from '@angular/platform-browser';
import { ControlMessagesComponent } from '@app/components/app-control-messages/app-control-messages.component';
import { MatHint } from '@angular/material/form-field';
import { IonicModule } from '@ionic/angular';
import { AlertsComponent } from '@app/components/alerts/alerts.component';

describe('FirstTimePageComponent', () => {
  let component: FirstTimePage;
  let fixture: ComponentFixture<FirstTimePage>;

  const storeMock = {
    select() {
      return of({});
    }
  };

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [IonicModule, RouterTestingModule],
      declarations: [FirstTimePage, ControlMessagesComponent, MatHint, AlertsComponent],
      providers: [
        {
          provide: Store,
          useValue: storeMock
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FirstTimePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('Welcome element exist', () => {
    const element = document.querySelector('.welcome-message');
    expect(element).toBeTruthy();
  });
  it('Welcome element contains text', () => {
    const element = document.querySelector('.welcome-message');
    expect(element.textContent.length).toBeGreaterThan(0);
  });

  it('Bullet points checking in template file', () => {
    const element = document.querySelector('.bullet-list');
    expect(element.childElementCount).toEqual(4);
  });

  it('bullet point element is exist', () => {
    const element = document.querySelector('.bullet-list');
    expect(element).toBeTruthy();
  });
  it('bullet point element contains text', () => {
    const element = document.querySelector('.bullet-list');
    expect(element.textContent.length).toBeGreaterThan(0);
  });
  it('Checking Home navigation functionality', () => {
    const onClickMock = spyOn(component, 'goHome');
    fixture.debugElement.query(By.css('ion-button')).triggerEventHandler('click', null);
    expect(onClickMock).toHaveBeenCalled();
  });
});
