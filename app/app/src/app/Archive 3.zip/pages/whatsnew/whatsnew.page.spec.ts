import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { WhatsnewPage } from './whatsnew.page';
import { Router } from '@angular/router';
import { mocks } from '@testing/constants/mocks.service';
import { IonicModule } from '@ionic/angular';

describe('WhatsnewPage', () => {
  let component: WhatsnewPage;
  let fixture: ComponentFixture<WhatsnewPage>;
  let mockRouter;
  beforeEach(waitForAsync(() => {
    mockRouter = mocks.service.router;
    TestBed.configureTestingModule({
      imports: [IonicModule, RouterTestingModule],
      declarations: [WhatsnewPage],
      providers: [{ provide: Router, useValue: mockRouter }]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WhatsnewPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('Header is Exist', () => {
    const element = document.querySelector('.content-header');
    expect(element).toBeTruthy();
  });
  it('Header contains text', () => {
    const element = document.querySelector('.content-header');
    expect(element.childNodes[1].textContent.length).toBeGreaterThan(0);
  });
  it('List is Exist', () => {
    const element = document.querySelector('.bullet-list');
    expect(element).toBeTruthy();
  });
  it('check List contains text', () => {
    const element = document.querySelector('.bullet-list');
    expect(element.firstChild.textContent.length).toBeGreaterThan(0);
    expect(element.lastChild.textContent.length).toBeGreaterThan(0);
  });
  it('Check Button Text is Explore', () => {
    const defaultButtonText = 'Explore';
    const element = document.querySelector('ion-button');
    expect(element.textContent.trim()).toBe(defaultButtonText);
  });
  it('Check explore navigation', () => {
    component.explore();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['home']);
  });
});
