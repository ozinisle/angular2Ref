import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { DeductibleDetailsPage } from './deductible-details/deductible-details.page';
import { DeductibleDetailsModule } from './deductible-details/deductible-details.module';


const routes: Routes = [
  {
    path: '',
    component: DeductibleDetailsPage
  }
];

@NgModule({
  imports: [CommonModule, IonicModule, RouterModule.forChild(routes), DeductibleDetailsModule]
})
export class DeductiblesModule {}
