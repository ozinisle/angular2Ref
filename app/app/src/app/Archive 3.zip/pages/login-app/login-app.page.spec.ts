import { DebugElement, Component } from '@angular/core';
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { Storage } from '@ionic/storage';
import { NgxsModule, Store } from '@ngxs/store';
import { Router } from '@angular/router';
import { FingerprintAIO } from '@ionic-native/fingerprint-aio/ngx';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DatePipe } from '@angular/common';
import { Keyboard } from '@ionic-native/keyboard/ngx';
import { CommonModule } from '@angular/common';
import { RouterTestingModule } from '@angular/router/testing';
import { LoginAppPage } from './login-app.page';
import { Observable } from 'rxjs';
import 'rxjs/add/observable/empty';
import 'rxjs/add/observable/of';
import { MockStorage } from '@testing/storage.stub';
import { AlertService } from '@app/services/alert.service';
import { ConstantsService } from '@app/services/constants.service';
import { IonContent, IonicModule } from '@ionic/angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AlertsComponent } from '@app/components/alerts/alerts.component';

class MockStore {}
class MockConstantsService {}

@Component({
  template: ''
})
class DummyRouteComponent {}

// TODO: Way too many errors since form is not set
xdescribe('LoginappPage', () => {
  let component: LoginAppPage;
  let fixture: ComponentFixture<LoginAppPage>;
  let submitEl: DebugElement;
  let storage: Storage;
  let router: Router;

  const contentSpy = jasmine.createSpyObj('IonContent', ['scrollToBottom']);

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        IonicModule,
        RouterTestingModule.withRoutes([{ path: 'account/forgotusername', component: DummyRouteComponent }]),
        HttpClientTestingModule,
        NgxsModule.forRoot([]),
        FormsModule,
        ReactiveFormsModule,
        CommonModule
      ],
      declarations: [LoginAppPage, DummyRouteComponent, AlertsComponent],
      providers: [
        { provide: Storage, useClass: MockStorage },
        { provide: Store, useClass: MockStore },
        { provide: ConstantsService, useClass: MockConstantsService },
        {
          provide: IonContent,
          useValue: contentSpy
        },
        DatePipe,
        Keyboard,
        AlertService,
        FingerprintAIO
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginAppPage);
    router = TestBed.inject(Router);
    fixture.detectChanges();
    component = fixture.componentInstance;
    submitEl = fixture.debugElement;
    storage = fixture.debugElement.injector.get(Storage);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should contain text Sign In on ion-title', () => {
    const element = document.querySelector('ion-title');
    expect(element).toBeTruthy();
    expect(element.textContent.length).toBeGreaterThan(0);
  });

  it('should contain need to create an account link', () => {
    const element = document.querySelector('h3');
    expect(element).toBeTruthy();
    expect(element.textContent.length).toBeGreaterThan(0);
  });

  it('should call remember me method on ionViewWillEnter', () => {
    const spy = spyOn(component, 'checkRememberMe').and.callFake(() => {
      return Observable.empty();
    });
    component.ionViewWillEnter();
    expect(spy).toHaveBeenCalled();
  });

  it('should call clearform on ionViewWillLeave', () => {
    const spy = spyOn(component, 'clearForm').and.returnValue(null);
    component.ionViewWillLeave();
    expect(spy).toHaveBeenCalled();
  });

  it('should create a form with four fields', () => {
    expect(component.loginForm.contains('userName')).toBeTruthy();
    expect(component.loginForm.contains('password')).toBeTruthy();
    expect(component.loginForm.contains('rememberMe')).toBeTruthy();
    expect(component.loginForm.contains('bioMetrics')).toBeTruthy();
  });

  it('should make the username and password required', () => {
    const usernameController = component.loginForm.get('userName');
    const passwordController = component.loginForm.get('password');
    usernameController.setValue('');
    passwordController.setValue('');
    fixture.detectChanges();
    expect(usernameController.valid).toBeFalsy();
    expect(passwordController.valid).toBeFalsy();
  });

  it('should call the handlesubmit method on onSubmit', () => {
    const spy = spyOn(component, 'handleSubmit').and.callFake(() => {
      return null;
    });
    component.onSubmit();
    expect(spy).toHaveBeenCalled();
  });

  it('should call the saveusername if remember value is true on handlesubmit', () => {
    spyOn(component, 'showHidePassword').and.returnValue(null);
    spyOn(component, 'login').and.returnValue(null);
    const saveUsernameSpy = spyOn(component, 'saveUserName').and.returnValue(null);
    component.loginForm.get('rememberMe').setValue(true);
    component.handleSubmit();
    expect(saveUsernameSpy).toHaveBeenCalled();
  });

  it('should call the setBioUp if bioMetrics value is true on handlesubmit', () => {
    spyOn(component, 'showHidePassword').and.returnValue(null);
    spyOn(component, 'login').and.returnValue(null);
    const setBioUpspy = spyOn(component, 'setBioUp').and.returnValue(null);
    component.loginForm.get('bioMetrics').setValue(true);
    component.handleSubmit();
    expect(setBioUpspy).toHaveBeenCalled();
  });

  it('should call eraseUserNameFromStorage  if remember me and biometrics value is false', () => {
    spyOn(component, 'showHidePassword').and.returnValue(null);
    spyOn(component, 'login').and.returnValue(null);
    const eraseBiometricsFromStorageSpy = spyOn(component, 'eraseBiometricsFromStorage').and.returnValue(null);
    const eraseUserNameFromStorageSpy = spyOn(component, 'eraseUserNameFromStorage').and.returnValue(null);
    component.loginForm.get('bioMetrics').setValue(false);
    component.loginForm.get('rememberMe').setValue(false);
    component.handleSubmit();
    expect(eraseBiometricsFromStorageSpy).toHaveBeenCalled();
    expect(eraseUserNameFromStorageSpy).toHaveBeenCalled();
  });

  it('should call the showhidepassword and login on handlesubmit', () => {
    const showhidePasswordSpy = spyOn(component, 'showHidePassword').and.returnValue(null);
    const loginSpy = spyOn(component, 'login').and.returnValue(null);
    component.handleSubmit();
    expect(showhidePasswordSpy).toHaveBeenCalled();
    expect(loginSpy).toHaveBeenCalled();
  });

  it('should call eraseUserNameFromStorage if rememberMe value is false', () => {
    const spy = spyOn(component, 'eraseUserNameFromStorage').and.callFake(() => {
      return Observable.empty();
    });
    component.rememberMeChange();
    const rememberMeController = component.loginForm.get('rememberMe');
    rememberMeController.setValue(false);
    expect(spy).toHaveBeenCalled();
  });

  it('sign in button should be disabled if loginform is invalid', () => {
    component.loginForm.get('userName').setValue('');
    component.loginForm.get('password').setValue('');
    fixture.detectChanges();
    expect(submitEl).toBeTruthy();
    expect(submitEl.nativeElement.querySelector('ion-button[type=submit]').disabled).toBeTruthy();
  });

  it('should toggle hide and show buttons on click', () => {
    component.showHidePassword('text');
    expect(component.showPassword).toBe('text');
    component.showHidePassword('password');
    expect(component.showPassword).toBe('password');
  });

  it('should navigate to forgotpassword  page while clicking Forgot password text', () => {
    const navigateSpy = spyOn(router, 'navigate');
    component.navigateToForgotPassword();
    expect(navigateSpy).toHaveBeenCalledWith(['/account/forgotPassword']);
  });

  it('should set pBioData to empty storage on eraseBiometricsFromStorage', () => {
    const spy = spyOn(storage, 'set').and.callThrough();
    component.eraseBiometricsFromStorage();
    expect(spy).toHaveBeenCalled();
  });

  it('should set userid to storage on eraseUserNameFromStorage', () => {
    const spy = spyOn(storage, 'set').and.callThrough();
    component.eraseUserNameFromStorage();
    expect(spy).toHaveBeenCalled();
  });

  it('should set userName to storage on saveUserName', () => {
    const spy = spyOn(storage, 'set').and.callThrough();
    component.saveUserName(null);
    expect(spy).toHaveBeenCalled();
  });

  it('should dispatch password empty on clearform method', () => {
    const passwordController = component.loginForm.get('password');
    component.clearForm();
    expect(passwordController.valid).toBeFalsy();
  });

  it('should set username and rememberme on getSavedUserName if userid is there', () => {
    const passwordController = component.loginForm.get('password');
    const rememberMeController = component.loginForm.get('rememberMe');
    component.getSavedUserName();
    expect(passwordController).toBeTruthy();
    expect(rememberMeController).toBeTruthy();
  });

  it('should return username and password on createRequest', () => {
    component.createRequest();
    expect(component.loginForm.get('userName')).toBeTruthy();
    expect(component.loginForm.get('password')).toBeTruthy();
  });

  it('should call get on checkremember me', () => {
    const spy = spyOn(storage, 'get').and.returnValue(Promise.resolve(true));
    component.checkRememberMe();
    expect(spy).toHaveBeenCalled();
  });

  it('should call get on checkbiosetup me', () => {
    const spy = spyOn(storage, 'get').and.returnValue(Promise.resolve(true));
    component.checkIsBioSetup();
    expect(spy).toHaveBeenCalled();
  });

  it('should call storage set on setBioUp', () => {
    const spy = spyOn(storage, 'set').and.returnValue(Promise.resolve(null));
    component.setBioUp();
    expect(spy).toHaveBeenCalled();
  });

  it('should call get on bioMetricSuccess me', () => {
    const spy = spyOn(storage, 'get').and.callThrough();
    component.bioMetricSuccess();
    expect(spy).toHaveBeenCalled();
  });
});
