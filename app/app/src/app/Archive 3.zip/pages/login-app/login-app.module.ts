import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { FingerprintAIO } from '@ionic-native/fingerprint-aio/ngx';
import { LoginAppPage } from './login-app.page';
import { AlertsModule } from '@app/components/alerts/alerts.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

const routes: Routes = [
  {
    path: '',
    component: LoginAppPage,
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [CommonModule, FormsModule, ReactiveFormsModule, IonicModule, RouterModule.forChild(routes), AlertsModule, FontAwesomeModule],
  declarations: [LoginAppPage],
  providers: [FingerprintAIO]
})
export class LoginAppPageModule {}
