import { Location } from '@angular/common';
import { ChangeDetectorRef, Component, HostListener, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MYBLUE } from '@app/app.constants';
import { FingerprintAIO } from '@ionic-native/fingerprint-aio/ngx';
import { IonButton, NavController, Platform } from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Store } from '@ngxs/store';
import { from } from 'rxjs';
import { LoginRequest } from '../../models/login-request.model';
import { SwrveEventNames, SwrveService } from '../../services/swrve.service';
import { GetTokens } from '../../store/actions/app.actions';
import { AppSelectors } from '../../store/selectors/app.selectors';
import { Plugins } from '@capacitor/core';
const { Keyboard } = Plugins;

@Component({
  selector: 'app-login-app',
  templateUrl: './login-app.page.html',
  styleUrls: ['./login-app.page.scss']
})
export class LoginAppPage {
  @ViewChild('signInButton') signInButton: IonButton;
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getCryptoToken) cryptoToken: any;

  loginForm = new FormGroup({
    userName: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required]),
    rememberMe: new FormControl(''),
    bioMetrics: new FormControl('')
  });
  showPassword: string;
  message: string;
  faceIdAvailable = false;
  fingerPrintAvailable = false;
  isAuthenticatedUser: boolean;
  userName: string;
  mobileViewPort = 991;
  ismobile: boolean;
  isRememberMeChecked: boolean = false

  private redirectURL = null;

  constructor(
    private storage: Storage,
    private store: Store,
    private router: Router,
    private route: ActivatedRoute,
    private faio: FingerprintAIO,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames,
    private location: Location,
    private platform: Platform,
    private navController: NavController,
    private cdr: ChangeDetectorRef
  ) {
    this.showPassword = 'password';
    this.swrveService.sendAppMessage(this.swrveEventNames.appScreenSignIn);

    if (this.platform.is('cordova')) {
      this.checkIdTech();
    }
    this.ismobile = window.innerWidth <= this.mobileViewPort;
    MYBLUE.log('this.ismobile = ', this.ismobile);
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.ismobile = event.target.innerWidth <= this.mobileViewPort;
  }

  checkIdTech() {
    this.faio.isAvailable().then(result => {
      result === 'finger' ? (this.fingerPrintAvailable = true) : (this.faceIdAvailable = true);
    });
  }

  ionViewWillEnter() {
    const params = this.route.snapshot.queryParams;
    this.redirectURL = params['redirectURL'] || null;

    this.checkRememberMe();
    if (this.platform.is('cordova')) {
      this.checkIsBioSetup();
    }
  }

  ionViewWillLeave() {
    this.clearForm();
  }

  checkRememberMe() {
    from(this.storage.get('userid')).subscribe(data => {
      if (data) {
        this.loginForm.patchValue({ rememberMe: true });
        this.getSavedUserName();
      } else {
        this.loginForm.patchValue({ rememberMe: false });
        this.checkLocalStorageForUserId();
      }
    });
  }

  checkLocalStorageForUserId() {
    if (window.localStorage && localStorage.getItem('userid')) {
      this.loginForm.patchValue({
        userName: localStorage.getItem('userid'),
        rememberMe: true
      });
    }
  }

  checkIsBioSetup() {
    from(this.storage.get('pBioData')).subscribe(pBioData => {
      if (pBioData) {
        this.launchBioMetrics();
      } else {
        this.loginForm.patchValue({ bioMetrics: false });
      }
    });
  }

  getSavedUserName() {
    from(this.storage.get('userid')).subscribe(data => {
      this.userName = data;
      this.loginForm.patchValue({
        userName: data,
        rememberMe: true
      });
    });
  }

  showHidePassword(type: string) {
    type === 'text' ? (this.showPassword = 'text') : (this.showPassword = 'password');
  }

  onSubmit() {
    this.handleSubmit();
  }

  handleSubmit() {
    this.loginForm.get('rememberMe').value ? this.saveUserName(this.loginForm.get('userName').value.trim()) : this.eraseUserNameFromStorage();
    this.loginForm.get('bioMetrics').value ? sessionStorage.setItem("biometric", "true") : this.eraseBiometricsFromStorage();
    this.showHidePassword('password');
    this.login(this.createRequest());
  }

  closeKeyboard() {
    Keyboard.hide();
  }

  createRequest(): LoginRequest {
    return {
      useridin: this.loginForm.get('userName').value.trim(),
      passwordin: this.loginForm.get('password').value
    };
  }

  launchBioMetrics() {
    this.faio
      .show({
        title: 'Use Pin',
        disableBackup: true // Only for Android(optional)
      })
      .then((result: any) => {
        return this.bioMetricSuccess();
      })
      .catch((error: any) => MYBLUE.error(error));
  }

  bioMetricSuccess() {
    this.storage
      .get('pBioData')
      .then(pBioData => {
        this.store.dispatch(new GetTokens({ useridin: this.userName, passwordin: pBioData.password }));
      })
      .catch((error: any) => {
        MYBLUE.error(error);
      });
  }

  setBioUp() {
    const pBioData = {
      password: this.loginForm.get('password').value,
      userid: this.loginForm.get('userName').value
    };
    this.storage.set('pBioData', pBioData).catch((error: any) => MYBLUE.error(error));
  }

  clearForm() {
    this.loginForm.patchValue({ password: '' });
  }

  login(request: LoginRequest) {
    this.store.dispatch(new GetTokens(request, false, false, this.redirectURL));
  }

  saveUserName(userName: string) {
    from(this.storage.set('userid', userName)).subscribe(() => { });
  }

  eraseBiometricsFromStorage() {
    sessionStorage.setItem("biometric", "false");
    from(this.storage.set('pBioData', '')).subscribe(() => { });
    this.storage.remove('pBioData');
    this.loginForm.patchValue({ biometrics: false });
  }

  eraseUserNameFromStorage() {
    from(this.storage.set('userid', '')).subscribe(() => { });
  }

  bioMetricChange() {
    this.loginForm.get('bioMetrics').value ? this.loginForm.patchValue({ rememberMe: true }) : this.eraseBiometricsFromStorage();
  }

  rememberMeChange() {
    MYBLUE.log('rememberMe', this.loginForm.get('rememberMe').value, typeof(this.loginForm.get('rememberMe').value))
    this.isRememberMeChecked = this.loginForm.get('rememberMe').value;
    if (!this.loginForm.get('rememberMe').value) {
      this.eraseUserNameFromStorage();
      this.eraseBiometricsFromStorage();
    }
  }

  navigateToForgotPassword() {
    const userName =
      this.loginForm && this.loginForm.controls && this.loginForm.controls.useridin ? this.loginForm.controls.useridin.value.trim() : '';

    if (userName) {
      this.router.navigate(['/account/forgotPassword', userName]);
    } else {
      this.router.navigate(['/account/forgotPassword']);
    }
  }

  onCredentialUpdate() {
    this.cdr.detectChanges();
    if (this.loginForm.valid) {
      this.signInButton["el"].style.color = "#ffffff";
    } else {
      this.signInButton["el"].style.color = "#949494";
    }

  }



  goBack() {
    if (this.authToken) {
      this.location.back();
    } else {
      this.navController.navigateRoot('/home');
    }
  }
}
