import { waitForAsync, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { Search, SetSearchOnlyFlag } from '@app/store/actions/search.actions';
import { IonicModule } from '@ionic/angular';
import { Store } from '@ngxs/store';

import { SearchComponent } from './search.component';

describe('SearchComponent', () => {
  let component: SearchComponent;
  let fixture: ComponentFixture<SearchComponent>;
  let store: Store;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [SearchComponent],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(SearchComponent);
    store = TestBed.inject(Store);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('onInit', () => {
    it('should initiate form', () => {
      const formBuilderStub: FormBuilder = fixture.debugElement.injector.get(FormBuilder);
      spyOn(formBuilderStub, 'group').and.callThrough();
      component.ngOnInit();
      expect(formBuilderStub.group).toHaveBeenCalled();
    });
    it('should initalises the keyword', fakeAsync(() => {
      component.ngOnInit();
      tick();
      expect(component.keyword).toBeTruthy();
    }));
  });

  describe('ionViewWillEnter', () => {
    it('should dispatch SetSearchOnlyFlag action', (done) => {
      store.dispatch(new SetSearchOnlyFlag(true));
      const spyStore = spyOn(store, 'dispatch').and.callThrough();
      component.ionViewWillEnter();
      expect(spyStore).toHaveBeenCalled();
    });
    it('should dispatch search action for keyword', (done) => {
      const keyword = 'Family';
      store.dispatch(new Search(keyword));
      const spyStore = spyOn(store, 'dispatch').and.callThrough();
      component.keyword = keyword;
      fixture.detectChanges();
      component.ionViewWillEnter();
      expect(component.search).toHaveBeenCalled();
      expect(spyStore).toHaveBeenCalled();
    });
  });

  it('should dispatch ViewBenefitDetails action on goToDetails', () => {
    const testBenefit = {
      benefitShortDescription: 'Lorem ipsum dollar sit amet',
      benefitCategoryName: 'Internal Medicine',
      benefitCategoryID: 1,
      productType: 'Medical',
    };
    const testSearchable = {
      productType: "Medical",
      planName: "Internal Medicine",
      cpcCode: '1231',
      searchEnabled: true,
      benefits: [testBenefit]
    };
    const spyStore = spyOn(store, 'dispatch').and.callThrough();
    component.searachableCpcs = [testSearchable];
    fixture.detectChanges();
    component.goToDetails(testBenefit);
    expect(spyStore).toHaveBeenCalled();
  });

  it('should dispatch FilterByPlan action', () => {
    const testEvent = {
      detail: {
        value: "Dental"
      }
    };
    const spyStore = spyOn(store, 'dispatch').and.callThrough();
    component.onProductTypeChange(testEvent);
    expect(spyStore).toHaveBeenCalled();
  });

  it('should dispatch navigate event while form submit if valid', () => {
    const spyStore = spyOn(store, 'dispatch').and.callThrough();
    component.searchForm.get('query').setValue('Family');
    fixture.detectChanges();
    component.submit();
    expect(spyStore).toHaveBeenCalled();
  });

  it('should not dispatch navigate event while form submit if invalid', () => {
    const spyStore = spyOn(store, 'dispatch').and.callThrough();
    component.searchForm.get('query').setValue('');
    fixture.detectChanges();
    component.submit();
    expect(spyStore).not.toHaveBeenCalled();
  });

});
