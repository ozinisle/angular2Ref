import { Component, ViewChild, OnInit, OnDestroy } from '@angular/core';
import { Select, Store, Actions, ofActionCompleted } from '@ngxs/store';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { SearchSelectors } from '@app/store/selectors/search.selectors';
import { SetSearchOnlyFlag, Search, ViewBenefitDetails, FilterByProduct } from '@app/store/actions/search.actions';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IonContent, IonInput, NavController, ModalController } from '@ionic/angular';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { BenefitSearchResultGroup } from '@app/models/benefit-search-result';
import { Observable } from 'rxjs/Observable';
import { ActivatedRoute, Router } from '@angular/router';
import { Navigate } from '@ngxs/router-plugin';
import { BenefitSearchCPC } from '@app/models/search.model';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ConstantsService } from '@app/services/constants.service';
import { IabService } from '@app/services/iab.service';
import { OTHER_POPULAR_LINKS, QUICK_LINKS } from './search.constants';
import { ServiceFailureModalComponent } from '@app/components/service-failure-modal/service-failure-modal.component';
import { IsSearchEnabled } from '@app/store/actions/app.actions';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit, OnDestroy {
  @Select(SearchSelectors.getPagedItems) pagedItems$: Observable<BenefitSearchResultGroup[]>;
  @Select(SearchSelectors.getProductTypes) productTypes$: Observable<string[]>;
  @Select(SearchSelectors.getSelectedProductType) selectedProductType$: Observable<string>;
  @SelectSnapshot(SearchSelectors.isSearchOnly) isSearchOnly: boolean;
  @SelectSnapshot(AppSelectors.getSearchableCpcs) searachableCpcs: BenefitSearchCPC[];
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;
  @SelectSnapshot(AppSelectors.isSearchEnabled) isSearchEnabled: boolean;
  searchForm: FormGroup;
  @ViewChild(IonContent) ionContent: IonContent;
  @ViewChild('searchInput', { static: false }) searchInput: IonInput;

  keyword: string;
  fpoLastUpdateUrl: string;
  destroy$ = new Subject<void>();
  popularLinks = OTHER_POPULAR_LINKS;
  quickLinks = QUICK_LINKS;
  searchEnableRetryCount = 0;

  constructor(
    private store: Store,
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private constants: ConstantsService,
    private iabService: IabService,
    private navCtrl: NavController,
    private modalController: ModalController,
    private actions$: Actions
  ) {}

  ngOnInit() {
    this.route.paramMap.pipe(takeUntil(this.destroy$)).subscribe(paramsMap => {
      this.keyword = paramsMap.get('keyword');
    });
    this.searchForm = this.fb.group({
      keyword: ['', [Validators.required]]
    });
    this.fpoLastUpdateUrl = this.constants.drupalSearchLastRefresh;
  }

  ionViewWillEnter() {
    this.store.dispatch(new SetSearchOnlyFlag(true));
    if (this.keyword) {
      this.search();
      this.searchForm.patchValue({
        keyword: this.keyword
      });
    }
  }

  ionViewDidEnter() {
    this.searchInput.setFocus();
  }

  submit() {
    if (this.searchForm.valid) {
      if (this.searachableCpcs?.length) {
        this.keyword = this.searchForm.value.keyword.trim();
        this.searchForm.reset();
        this.store.dispatch(new Navigate(['/search/' + this.keyword]));
      } else {
        this.showErrorModal();
      }
    }
  }

  search() {
    this.store.dispatch(new Search(this.keyword));
  }

  goToDetails(resultRow) {
    this.store.dispatch(new ViewBenefitDetails(resultRow));
  }

  onProductTypeChange($event) {
    this.store.dispatch(new FilterByProduct($event.detail.value));
  }

  navigateTo(link) {
    if (link.external) {
      this.iabService.create(link.url);
    } else {
      this.router.navigate([link.url]);
    }
  }

  goBack() {
    if (this.authToken) {
      this.navCtrl.back();
    } else {
      this.navCtrl.navigateRoot('home');
    }
  }

  async showErrorModal() {
    const modal = await this.modalController.create({
      component: ServiceFailureModalComponent,
      cssClass: 'search-failure-modal',
      keyboardClose: false,
      showBackdrop: true,
      backdropDismiss: false,
      componentProps: {
        data: {
          showRetry: this.searchEnableRetryCount === 0,
          title: 'Error Occurred',
          description: 'Searching for Benefits is not available at this time. Refresh the page or try again later.',
          ctaRetry: 'Refresh Page',
          cta2Text: 'Close'
        }
      }
    });
    modal.onDidDismiss().then(response => {
      this.searchEnableRetryCount++;
      if (response.data.retry) {
        this.store.dispatch(new IsSearchEnabled());
        this.actions$.pipe(ofActionCompleted(IsSearchEnabled), takeUntil(this.destroy$)).subscribe(() => {
          if (this.isSearchEnabled && this.searachableCpcs?.length) {
            this.submit();
          } else if (this.isSearchEnabled) {
            this.showErrorModal();
          } else {
            this.router.navigate(['/home']);
          }
        });
      }
    });
    await modal.present();
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
