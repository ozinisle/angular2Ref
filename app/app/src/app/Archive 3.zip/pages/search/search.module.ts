import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchComponent } from '@app/pages/search/search.component';
import { IonicModule } from '@ionic/angular';
import { Routes, RouterModule } from '@angular/router';
import { SearchResultRowComponent } from './components/search-result-row/search-result-row.component';
import { ReactiveFormsModule } from '@angular/forms';
import { SelectArrowStyleDirective } from './select-arrow-style.directive';
import { MatchTextHighlightModule } from '@app/pipes/match-text-highlight/match-text-highlight.module';
import { FpoLayoutModule } from '@app/components/fpo-layout/fpo-layout.module';
import { ServiceFailureModalModule } from '@app/components/service-failure-modal/service-failure-modal.module';

const routes: Routes = [
  {
    path: '',
    component: SearchComponent
  }
];

@NgModule({
  declarations: [SearchComponent, SearchResultRowComponent, SelectArrowStyleDirective],
  imports: [CommonModule,
    IonicModule,
    RouterModule.forChild(routes),
    ReactiveFormsModule,
    MatchTextHighlightModule,
    FpoLayoutModule,
    ServiceFailureModalModule,
  ]
})
export class SearchModule {}
