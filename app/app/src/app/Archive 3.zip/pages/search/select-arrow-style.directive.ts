import { Directive, OnChanges, Input, ElementRef, SimpleChanges } from '@angular/core';

@Directive({
  selector: '[selectArrowStyle]'
})
export class SelectArrowStyleDirective implements OnChanges {
  @Input() selectArrowStyle = '';
  constructor(private el: ElementRef) {}
  ngOnChanges(changes: SimpleChanges): void {
    const shadow = this.el.nativeElement.shadowRoot;
    if (shadow) {
      setTimeout(() => {
        shadow
          .querySelector('.select-icon-inner')
          .setAttribute(
            'style',
            'left: 1rem;border-top: 7px solid;border-right: 7px solid transparent;border-left: 7px solid transparent;'
          );
      }, 200);
    }
  }
}
