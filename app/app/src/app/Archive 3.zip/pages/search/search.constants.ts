export const OTHER_POPULAR_LINKS = [
  {
    url: '/tax-forms',
    title: 'Tax Forms',
    external: false,
    sso: false
  },
  {
    url: '/fitness-and-weightloss',
    title: 'Fitness & Weight Loss Reimbursement',
    external: false,
    sso: false
  },
  {
    url: 'https://www.bluecrossma.org/myblue/find-care/care-options/video-call-a-doctor',
    title: 'Virtual Video Visits (Telehealth)',
    external: true,
    sso: false
  },
  {
    url: '/myClaims',
    title: 'My Claims',
    external: false,
    sso: false
  },
  {
    url: '/myInbox/documents/eob',
    title: 'Explanation of Benefits',
    external: false,
    sso: false
  },
  {
    url: 'https://www.bluecrossma.org/myblue/contact-us',
    title: 'Billing Address for Non-group Premium Payments',
    external: true,
    sso: false
  }
];
export const QUICK_LINKS = [
  {
    url: '/fad',
    title: 'FIND A DOCTOR OR HOSPITAL',
    external: false,
    sso: false
  },
  {
    url: '/my-medications',
    title: 'LOOK UP A MEDICATION',
    external: false,
    sso: false
  },
  {
    url: '/myPlan',
    title: 'VIEW PLANS AND BENEFITS',
    external: false,
    sso: false
  }
];
