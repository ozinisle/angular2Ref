import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { BrandMymedicationPageRoutingModule } from './brand-mymedication-routing.module';
import { BrandMymedicationPage } from './brand-mymedication.page';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BrandMymedicationPageRoutingModule,
    FontAwesomeModule
  ],
  declarations: [BrandMymedicationPage]
})
export class BrandMymedicationPageModule {}
