import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MYBLUE } from '@app/app.constants';
import { GetMedlookupInfo } from '@app/store/actions/medlookup.actions';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { MedlookupSelectors } from '@app/store/selectors/medlookup.selectors';
import { GlobalUtils } from '@app/utils/global.utils';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { FileTransfer } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import { Platform } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Store } from '@ngxs/store';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { PharmacyLinkType } from '../../models/pharmacy-link-type';
import { IabService } from '../../services/iab.service';
import { MedLookupSearchService } from '../med-lookup-search/med-lookup-search.service';
import { SsoService } from '../sso/sso.service';

@Component({
  selector: 'app-brand-mymedication',
  templateUrl: './brand-mymedication.page.html',
  styleUrls: ['./brand-mymedication.page.scss']
})
export class BrandMymedicationPage implements OnInit, OnDestroy {
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;
  @SelectSnapshot(AppSelectors.getPharmacyLinks) pharmacyLinks: PharmacyLinkType[];
  @SelectSnapshot(AppSelectors.getUserType) userType: string;
  @SelectSnapshot(AppSelectors.getMemProfile) memProfile;
  @SelectSnapshot(MedlookupSelectors.getMedlookup) medlookup;
  @SelectSnapshot(AppSelectors.isActiveUser) isActiveUser: any;

  isAuthenticatedUser: boolean;
  showMedlookupTool: boolean;
  medLookUpUrl = 'https://home.bluecrossma.com/medication/?icid=myblueglobalnav';
  npfUrl = 'https://home.bluecrossma.com/medication/national-preferred-formulary';
  directPayMedicareUrl = 'http://www2.bluecrossma.com/search-app/formulary-2021';
  directPayMedexUserUrl = 'https://rxmedicareplans.com/Coverage/PricingTool';
  medLookUpurlMedicare = 'http://www2.bluecrossma.com/search-app/formulary-2020';
  medexWithoutdirectPayUrl =
    'https://home.bluecrossma.com/collateral/sites/g/files/csphws1571/files/acquiadam-assets/50-0207_Medex_Closed_Formulary.pdf';
  medicareWithoutDirectPay =
    'https://home.bluecrossma.com/collateral/sites/g/files/csphws1571/files/acquiadam-assets/55-0184_2021_MedAdvFormulary.pdf';
  ismobile: boolean;
  private unsubscribeHelper$: Subject<void> = new Subject<void>();

  constructor(
    private router: Router,
    public medLookupSearchService: MedLookupSearchService,
    private ssoService: SsoService,
    private iabService: IabService,
    private fileOpener: FileOpener,
    private file: File,
    private transfer: FileTransfer,
    private platform: Platform,
    private store: Store,
    private resizeService: GlobalUtils
  ) {}

  ionViewWillEnter() {
    const scopeName = this.scopeName;
    this.isAuthenticatedUser = scopeName.includes('AUTHENTICATED');
  }
  ngOnInit() {
    this.resizeService.getIsMobile().pipe(takeUntil(this.unsubscribeHelper$))
    .subscribe((isMobile: boolean) => this.ismobile = isMobile );
  }

  ngOnDestroy(): void {
    this.unsubscribeHelper$.next();
    this.unsubscribeHelper$.complete();
  }

  goBack() {
    this.router.navigate(['/brand-home']);
  }

  navigate(item: PharmacyLinkType) {
    if (item.isSSO && this.isAuthenticatedUser) {
      this.ssoService.openSSO(item.ssoType);
    } else if (item.isExternal) {
      this.iabService.create(item.url);
    } else {
      this.router.navigateByUrl(item.url);
    }
  }

  redirectPageOtherpage() {
    if (!this.pharmacyLinks) {
      this.iabService.create(this.medLookUpUrl);
    } else {
      this.medLookupSearchService.getTierMapping();
      this.store.dispatch([new GetMedlookupInfo()]);
      this.medLookupSearchService.getStaticLinks();
    }
  }

  redirectDirectPayUser() {
    if (this.userType?.toLowerCase() === 'medicare' && this.memProfile?.isDirectPay) {
      this.iabService.create(this.directPayMedicareUrl);
    } else if (this.userType?.toLowerCase() === 'medicare' && !this.memProfile?.isDirectPay) {
      this.openFile(this.medicareWithoutDirectPay);
    } else if (this.userType?.toLowerCase() === 'medex' && this.memProfile?.isDirectPay) {
      this.iabService.create(this.directPayMedexUserUrl);
    } else if (this.userType?.toLowerCase() === 'medex' && !this.memProfile?.isDirectPay) {
      this.openFile(this.medexWithoutdirectPayUrl);
    } else {
      this.iabService.create(this.medLookUpUrl);
    }
  }

  public openFile(url) {
    if (this.platform.is('ios') && url) {
      const path = this.file.documentsDirectory;
      const transfer = this.transfer.create();

      transfer.download(url, path + 'myfile.doc').then(entry => {
        const appUrl = entry.toURL();
        this.fileOpener.open(appUrl, 'application/pdf').catch(e => MYBLUE.error('Error opening file', e));
      });
    } else {
      if (url) {
        window.open(url, '_system', 'location=yes');
      }
    }
  }

  redirectOtherUser() {
    this.iabService.create(this.medLookUpUrl);
  }
}
