import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BrandMymedicationPage } from './brand-mymedication.page';

const routes: Routes = [
  {
    path: '',
    component: BrandMymedicationPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BrandMymedicationPageRoutingModule {}
