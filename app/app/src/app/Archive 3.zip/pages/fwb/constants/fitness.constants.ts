import { environment } from '../../../../environments/environment';

export const GET_REIMBURSEMENT_BENEFITS_ENDPOINT = environment.serviceUrl + 'fitnessbenefitswl/getfitnessbenefits';

export const SUBMIT_REIMBURSEMENT_BENEFITS_ENDPOINT = environment.serviceUrlV2 + 'fitnessbenefitswl/submitfitnessbenefitclaim';

export const FITNESS_URL = 'http://www.bluecrossma.com/common/en_US/pdfs/New_SOB/55-0763_Fitness_Reimbursement_Form.pdf';
export const FITNESS_PDF_NAME = 'Fitness_Reimbursement_Form.pdf';

export const WEIGHTLOSS_URL = 'http://www.bluecrossma.com/common/en_US/pdfs/New_SOB/55-0764_Weight_Loss_Reimbursement_Form.pdf';
export const WEIGHTLOSS_PDF_NAME = 'Weight_Loss_Reimbursement_Form.pdf';

export const FITNESS_POPUP_HELP =
  'A reimbursement is a request for compensation. The fitness reimbursement is' +
  ' covered for each individual (or family) plan per year. Receiving your reimbursement can take up to 30 calendar days after we receive ' +
  'a complete request. Keep copies of proof of payment in case we need to request them from you.';

export const WEIGHTLOSS_POPUP_HELP =
  'A reimbursement is a request for compensation. The weight loss reimbursement is covered for each individual (or family) plan per ' +
  'year. ' +
  'Receiving your reimbursement can take up to 30 calendar days after we receive a complete request. Keep copies of proof of payment in ' +
  'case we need to request them from you.';

export const CERTIFICATIONS_ACKNOWLEDGEMENTS =
  'I certify that the information provided in support of this submission is complete and correct and ' +
  'that I have not previously submitted for these services. I understand that Blue Cross ' +
  'Blue Shield of Massachusetts may require proof of ' +
  'payment for a ' +
  'reimbursement decision. I authorize the release of any information about my qualified fitness/weight loss program to Blue Cross Blue ' +
  'Shield of Massachusetts. ' +
  'By providing my email address, I consent to receiving an email message confirming receipt of my fitness/weight loss submission through' +
  ' an unencrypted method ' +
  'of communication, which means that such information can be at risk of being accessed by third parties during transmission or storage,' +
  ' as the internet is not a ' +
  'secured method of communication.';

export const ERROR_CODES = [-94026, -94027, -94028, -94029, -94030, -94031, -94032, -94033, -94034, -94035];

export const ERROR_CODES_GETFWB = [-94000, -94001, -94002, -94003, -94004, -94005, -94006, -94007, -94011, -94012, -94013, -94015];

export const ERROR_CODES_NOT_ELIGIBLE = [-94008, -94010, -94014];
