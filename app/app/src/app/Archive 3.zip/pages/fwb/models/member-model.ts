export interface MemberModel {
  fullName: string;
  suffix: string;
  status: string;
  relationship: string;
  memberCancelDate: string;
  groupNumber?: string;
}
