import { BenefitModel } from './benefit-model';

export interface FitnessResponseModel {
  subscriberMaskedEmail: string;
  memberEmail: string;
  userSuffix: string;
  benefits: BenefitModel[];
  result?: number;
  displaymessage?: string;
}
