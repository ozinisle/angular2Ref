import { TestBed } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '../../../services/constants.service';
import { FitnessService } from './fitness.service';
import { RouterTestingModule } from '@angular/router/testing';
import { IonicModule, IonContent } from '@ionic/angular';

xdescribe('FitnessService', () => {
  beforeEach(() =>
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule, IonicModule, NgxsModule.forRoot([])],
      providers: [ConstantsService, IonContent]
    })
  );

  it('should be created', () => {
    const service: FitnessService = TestBed.inject(FitnessService);
    expect(service).toBeTruthy();
  });
});
