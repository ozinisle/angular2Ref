import { Injectable } from '@angular/core';
import { InboxMessageModel } from './modals/messages.model';

@Injectable({ providedIn: 'root' })
export class MessageCenterService {
  public msgListingResponse: InboxMessageModel;
  constructor() {
    this.msgListingResponse = new InboxMessageModel();
  }
}
