import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { TabsPageComponent } from './tabs-page.component';
import { TabsPageRoutingModule } from './tabs.router.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { IntegratedPlanAcccessModule } from '../integrated-plan-access/integrated-plan-access.module';

@NgModule({
  imports: [IonicModule, CommonModule, FormsModule, IntegratedPlanAcccessModule , TabsPageRoutingModule, TabsPageRoutingModule, FontAwesomeModule],
  declarations: [TabsPageComponent ]
})
export class TabsPageModule {}
