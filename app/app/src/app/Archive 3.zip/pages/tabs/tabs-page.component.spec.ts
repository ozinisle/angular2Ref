import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { IonTabs, IonContent, IonicModule } from '@ionic/angular';
import { NgxsModule } from '@ngxs/store';
import { HeaderService } from '@app/services/header.service';
import { ConstantsService } from '@app/services/constants.service';
import { TabsPageComponent } from './tabs-page.component';

xdescribe('TabsPage', () => {
  let component: TabsPageComponent;
  let fixture: ComponentFixture<TabsPageComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [IonicModule, RouterTestingModule, HttpClientTestingModule, NgxsModule.forRoot([])],
      providers: [HeaderService, ConstantsService, IonContent],
      declarations: [TabsPageComponent, IonTabs]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TabsPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
