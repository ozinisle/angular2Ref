import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '@app/guards/auth.guard';
import { FadResolverService } from '@app/pages/fad/fad-resolver.service';
import { YesGuard } from '@app/pages/year-end-summary/yes.guard';
import { HomeResolver } from '../home/home.resolver';
import { SsoResolver } from '../sso/sso.resolver';
import { TabsPageComponent } from './tabs-page.component';

const routes: Routes = [
  {
    path: '',
    component: TabsPageComponent,
    children: [
      {
        path: 'home',
        children: [
          {
            path: '',
            loadChildren: () => import('../home/home.module').then((m) => m.HomePageModule),
          },
        ],
        resolve: {
          home: HomeResolver,
        },
      },
      {
        path: 'careCost',
        children: [
          {
            path: '',
            loadChildren: () => import('../care-cost/care-cost.module').then((m) => m.CareCostPageModule),
          },
        ],
      },
      {
        path: 'my-pharmacy',
        children: [
          {
            path: '',
            loadChildren: () => import('../my-pharmacy/my-pharmacy.module').then((m) => m.MyPharmacyPageModule),
          },
        ],
        canActivate: [AuthGuard],
      },
      {
        path: 'myInbox',
        children: [
          {
            path: '',
            loadChildren: () => import('../message-center/message-center.module').then((m) => m.MessageCenterModule),
          },
        ],
        canActivate: [AuthGuard],
      },
      {
        path: 'login',
        children: [
          {
            path: '',
            loadChildren: () => import('../login-app/login-app.module').then((m) => m.LoginAppPageModule),
          },
        ],
      },
      {
        path: 'register',
        children: [
          {
            path: '',
            loadChildren: () => import('../registration/registration.module').then((m) => m.RegistrationModule),
          },
        ],
      },
      {
        path: 'member-migration',
        children: [
          {
            path: '',
            loadChildren: () => import('../member-migration/member-migration-app.module').then((m) => m.MemberMigrationAppModule),
          },
        ],
      },
      {
        path: 'pages',
        children: [
          {
            path: '',
            loadChildren: () => import('../static/static.module').then((m) => m.StaticModule),
          },
        ],
      },
      {
        path: 'whatsnew',
        children: [
          {
            path: '',
            loadChildren: () => import('../whatsnew/whatsnew.module').then((m) => m.WhatsnewPageModule),
          },
        ],
      },
      {
        path: 'too-soon',
        children: [
          {
            path: '',
            loadChildren: () => import('../too-soon/too-soon.module').then((m) => m.TooSoonPageModule),
          },
        ],
      },
      {
        path: 'terms-of-use',
        children: [
          {
            path: '',
            loadChildren: () => import('../terms-of-use/terms-of-use.module').then((m) => m.TermsOfUsePageModule),
          },
        ],
      },
      {
        path: 'confidentiality',
        children: [
          {
            path: '',
            loadChildren: () => import('../confidentiality/confidentiality.module').then((m) => m.ConfidentialityPageModule),
          },
        ],
      },
      {
        path: 'care-cost',
        children: [
          {
            path: '',
            canActivate: [AuthGuard],
            loadChildren: () => import('../care-cost/care-cost.module').then((m) => m.CareCostPageModule),
          },
        ],
      },
      {
        path: 'myPlan',
        children: [
          {
            path: '',
            canActivate: [AuthGuard],
            loadChildren: () => import('../my-plans/my-plans.module').then((m) => m.MyPlansModule),
          },
        ],
      },
      {
        path: 'my-doctor',
        children: [
          {
            path: '',
            canActivate: [AuthGuard],
            loadChildren: () => import('../my-doctors-pcp/mydoctors-pcp.module').then((m) => m.MyDoctorsPcpModule),
          },
        ],
      },
      {
        path: 'myClaims',
        children: [
          {
            path: '',
            canActivate: [AuthGuard],
            loadChildren: () => import('../my-claims/claims.module').then((m) => m.ClaimsAppModule),
          },
        ],
      },
      {
        path: 'my-financial',
        children: [
          {
            path: '',
            canActivate: [AuthGuard],
            loadChildren: () => import('../my-financial/my-financial.module').then((m) => m.MyFinancialPageModule),
          },
        ],
      },
      {
        path: 'myprofile',
        children: [
          {
            path: '',
            canActivate: [AuthGuard],
            loadChildren: () => import('../my-profile/profile-home.module').then((m) => m.ProfileHomeModule),
          },
        ],
      },
      {
        path: 'contact-us',
        children: [
          {
            path: '',
            loadChildren: () => import('../contact-us/contact-us.module').then((m) => m.ContactUsPageModule),
          },
        ],
      },
      {
        path: 'my-medications',
        children: [
          {
            path: '',
            canActivate: [AuthGuard],
            loadChildren: () => import('../my-medication/my-medications.module').then((m) => m.MyMedicationsModule),
          },
        ],
      },
      {
        path: 'orderreplacement',
        children: [
          {
            path: '',
            canActivate: [AuthGuard],
            loadChildren: () => import('../orderreplacement/orderreplacement.module').then((m) => m.OrderreplacementModule),
          },
        ],
      },
      {
        path: 'request-estimate',
        children: [
          {
            path: '',
            canActivate: [AuthGuard],
            loadChildren: () => import('../request-estimate/request-estimate.module').then((m) => m.RequestEstimateModule),
          },
        ],
      },
      {
        path: 'deductibles',
        children: [
          {
            path: '',
            canActivate: [AuthGuard],
            loadChildren: () => import('../deductibles/deductibles.module').then((m) => m.DeductiblesModule),
          },
        ],
      },
      {
        path: 'sso/cerner',
        children: [
          {
            path: '',
            canActivate: [AuthGuard],
            loadChildren: () => import('../sso/sso.module').then((m) => m.SsoModule),
            resolve: {
              sso: SsoResolver,
            },
          },
        ],
      },
      {
        path: 'sso/alegeus',
        children: [
          {
            path: '',
            canActivate: [AuthGuard],
            loadChildren: () => import('../sso/sso.module').then((m) => m.SsoModule),
            resolve: {
              sso: SsoResolver,
            },
          },
        ],
      },
      {
        path: 'sso/heathequity',
        children: [
          {
            path: '',
            canActivate: [AuthGuard],
            loadChildren: () => import('../sso/sso.module').then((m) => m.SsoModule),
            resolve: {
              sso: SsoResolver,
            },
          },
        ],
      },
      {
        path: 'sso/connecture',
        children: [
          {
            path: '',
            canActivate: [AuthGuard],
            loadChildren: () => import('../sso/sso.module').then((m) => m.SsoModule),
            resolve: {
              sso: SsoResolver,
            },
          },
        ],
      },
      {
        path: 'account',
        children: [
          {
            path: '',
            loadChildren: () => import('../my-account/my-account.module').then((m) => m.MyAccountModule),
          },
        ],
      },
      {
        path: 'med-lookup-tool',
        children: [
          {
            path: '',
            loadChildren: () => import('../med-lookup-tool/med-lookup-tool.module').then((m) => m.MedLookupToolPageModule),
          },
        ],
      },
      {
        path: 'med-lookup-search',
        children: [
          {
            path: '',
            loadChildren: () => import('../med-lookup-search/med-lookup-search.module').then((m) => m.MedLookupSearchModule),
          },
        ],
      },
      {
        path: 'mycards',
        children: [
          {
            path: '',
            canActivate: [AuthGuard],
            loadChildren: () => import('../my-cards/mycards.module').then((m) => m.MyCardsModule),
          },
        ],
      },
      {
        path: 'fad',
        children: [
          {
            path: '',
            resolve: {
              fadInfo: FadResolverService,
            },
            loadChildren: () => import('../fad/fad.module').then((m) => m.FadModule),
          },
        ],
      },
      {
        path: 'fitness-and-weightloss',
        canActivate: [AuthGuard],
        children: [
          {
            path: '',
            loadChildren: () => import('../fwb/fwb.module').then((m) => m.FitnessBenefitsModule),
          },
        ],
      },
      {
        path: 'my-pillpack',
        canActivate: [AuthGuard],
        children: [
          {
            path: '',
            loadChildren: () => import('../my-pillpack/my-pillpack.module').then((m) => m.MyPillpackModule),
          },
        ],
      },
      {
        path: 'tax-forms',
        canActivate: [AuthGuard],
        children: [
          {
            path: '',
            loadChildren: () => import('../message-center/tax-forms/tax-forms.module').then((m) => m.TaxFormsModule),
          },
        ],
      },
      {
        path: 'cost-share',
        canActivate: [AuthGuard],
        children: [
          {
            path: '',
            loadChildren: () =>
              import('../cost-share-assistance/cost-share-assistance.module').then((m) => m.CostShareAssistancePageModule),
          },
        ],
      },
      {
        path: 'search',
        canActivate: [AuthGuard],
        children: [
          {
            path: '',
            loadChildren: () => import('../search/search.module').then((m) => m.SearchModule),
          },
        ],
      },
      {
        path: 'search/:keyword',
        canActivate: [AuthGuard],
        children: [
          {
            path: '',
            loadChildren: () => import('../search/search.module').then((m) => m.SearchModule),
          },
        ],
      },
      {
        path: 'yes',
        canActivate: [AuthGuard, YesGuard],
        children: [
          {
            path: '',
            loadChildren: () => import('../year-end-summary/year-end-summary.module').then((m) => m.YearEndSummaryModule),
          },
        ],
      },
      {
        path: 'brand-my-medication',
        children: [
          {
            path: '',
            loadChildren: () => import('../brand-mymedication/brand-mymedication.module').then((m) => m.BrandMymedicationPageModule),
          },
        ],
      },
      {
        path: 'brand-support',
        children: [
          {
            path: '',
            loadChildren: () => import('../brand-support/brand-support.module').then((m) => m.BrandSupportPageModule),
          },
        ],
      },
      {
        path: 'brand-home',
        children: [
          {
            path: '',
            loadChildren: () => import('../brand-home/brand-home.module').then((m) => m.BrandHomePageModule),
          },
        ],
      },
      {
        path: 'loading',
        children: [
          {
            path: '',
            loadChildren: () => import('../loading/loading.module').then((m) => m.LoadingPageModule),
          },
        ],
      },
      {
        path: 'brandMyPlan',
        children: [
          {
            path: '',
            loadChildren: () => import('../myplans-claim/myplans-claim.module').then((m) => m.MyplansClaimPageModule),
          },
        ],
      },

      {
        path: 'virtual-visit',
        children: [
          {
            path: '',
            canActivate: [AuthGuard],
            loadChildren: () => import('../virtual-visit/virtual-visit.module').then((m) => m.VirtualVisitPageModule),
          },
        ],
      },
      {
        path: 'guest-visit',
        children: [
          {
            path: '',
            loadChildren: () => import('../guest-visit/guest-visit.module').then((m) => m.GuestVisitPageModule),
          },
        ],
      },
      {
        path: '',
        redirectTo: '/home',
        pathMatch: 'full',
      },
    ],
  },
  {
    path: '',
    redirectTo: '/home',
    pathMatch: 'full',
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class TabsPageRoutingModule {}
