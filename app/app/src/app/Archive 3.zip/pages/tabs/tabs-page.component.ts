import { HttpClient } from '@angular/common/http';
import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { IonTabs, NavController, Platform } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Select, Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { PostLoginModel } from '@app/models/post-login.model';
import { HeaderService } from '@app/services/header.service';
import { ConstantsService } from '@app/services/constants.service';
import { Logout } from '@app/store/actions/app.actions';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { environment } from '@environments/environment';
import { IabService } from '@app/services/iab.service';
import { GlobalUtils } from '@app/utils/global.utils';
import { takeUntil } from 'rxjs/operators';

const enum Tabs {
  Home = 'home',
  CareCast = 'careCost',
  MyPlan = 'brandMyPlan',
  MyMedications = 'brand-my-medication',
  MyInbox = 'myInbox',
  TaxForm = 'tax-forms'
}

@Component({
  selector: 'app-tabs',
  templateUrl: 'tabs-page.component.html',
  styleUrls: ['tabs-page.component.scss']
})
export class TabsPageComponent implements AfterViewInit, OnInit, OnDestroy {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;
  @SelectSnapshot(AppSelectors.isAuthenticatedUser) isAuthenticatedUser: string;
  @SelectSnapshot(AppSelectors.hasNewPwkMessage) hasNewPwkMessage: boolean;
  @Select(AppSelectors.getPostLoginInfo) postLoginInfo$: Observable<PostLoginModel>;

  from: any;
  showMyPharmacy = false;
  ismobile: boolean;
  memberFirstName: string;
  public search: string;
  private unsubscribeHelper$: Subject<void> = new Subject<void>();
  constructor(
    public headerService: HeaderService,
    public router: Router,
    private http: HttpClient,
    private constants: ConstantsService,
    private store: Store,
    private navCtrl: NavController,
    private iabService: IabService,
    private resizeService: GlobalUtils,
    private platform: Platform
  ) {
    // TODO: unsubscribe
    this.postLoginInfo$.subscribe(postLoginInfo => {
      this.showMyPharmacy = postLoginInfo?.pharmacyLinks?.length > 0;
    });
    this.memberFirstName = this.authToken?.firstName ? this.authToken.firstName : '';
  }

  @ViewChild(IonTabs) tabs: IonTabs;
  currentTab = 'home';
  baseImageUrl = '../../../assets/icon/';
  homeIcon = this.baseImageUrl + 'bottomnav-home-';
  carecastIcon = this.baseImageUrl + 'bottomnav-carecosts-';
  myPlanIcon = this.baseImageUrl + 'bottomnav-myplan-';
  myPharmacyIcon = this.baseImageUrl + 'bottomnav-mypharmacy-';
  myInboxIcon = this.baseImageUrl + 'bottomnav-myinbox-';

  ngAfterViewInit(): void {
    this.tabs.ionTabsDidChange.subscribe(tabs => {
      this.currentTab = tabs.tab;
    });
  }

  ngOnInit(): void {
    this.resizeService.getIsMobile().pipe(takeUntil(this.unsubscribeHelper$))
      .subscribe((isMobile: boolean) => this.ismobile = isMobile );
  }

  ngOnDestroy(): void {
    this.unsubscribeHelper$.next();
    this.unsubscribeHelper$.complete();
  }

  get isHomeActive() {
    return this.currentTab === Tabs.Home;
  }

  get isCarecastActive() {
    return this.currentTab === Tabs.CareCast;
  }

  get isMyPlanActive() {
    return this.currentTab === Tabs.MyPlan;
  }

  get isMyMedicationsActive() {
    return this.currentTab === Tabs.MyMedications;
  }

  get isMyInboxActive() {
    return this.currentTab === Tabs.MyInbox || this.currentTab === Tabs.TaxForm;
  }

  redirectToLoginPage() {
    this.store.dispatch(new Logout());
    this.router.navigate(['/login']);
  }

  onTabClick($event: any, tabRoute: string) {
    if (this.router.url.endsWith('register/success')) {
      $event.preventDefault();
      $event.stopPropagation();
      $event.stopImmediatePropagation();
      const url = $event.currentTarget.dataset.href;
      if (url) {
        const requestPayload = {
          useridin: this.useridin,
          linkinfo: url
        };
        this.http.post(this.constants.postdesinfoUrl, requestPayload).subscribe(response => {
          this.redirectToLoginPage();
        });
      } else {
        this.redirectToLoginPage();
      }
    } else {
      this.navCtrl.navigateRoot(tabRoute);
    }
  }

  //GLobal search
  public doSearch(value: string): void {
    const searchKey = value.trim();
    if (searchKey.length > 0) {
      window.location.href = environment.searchKeyUrl + 'keys=' + searchKey;
    }
  }
  //GLobal search

  openInAppBrowser(url, isExternal) {
    if (!isExternal) {
      this.router.navigate([url]);
    } else {
      this.iabService.create(url);
    }
  }

  logOut() {
    sessionStorage.clear();
    this.store.dispatch(new Logout());
    if (this.platform.is("desktop") && !this.isAuthenticatedUser) {
      this.router.navigate(['/login']);
    }
  }

  get getUnreadMsgCount() {
    return this.headerService.unReadMsgCount + (this.hasNewPwkMessage ? 1 : 0);
  }
}
