import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { MyFinancialPage } from './my-financial.page';
import { IonicModule } from '@ionic/angular';

xdescribe('MyFinancialPage', () => {
  let component: MyFinancialPage;
  let fixture: ComponentFixture<MyFinancialPage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [IonicModule],
      declarations: [MyFinancialPage]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyFinancialPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
