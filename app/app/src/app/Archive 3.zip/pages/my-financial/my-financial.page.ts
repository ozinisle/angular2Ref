import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-financial',
  templateUrl: './my-financial.page.html',
  styleUrls: ['./my-financial.page.scss']
})
export class MyFinancialPage implements OnInit {
  constructor() {}

  ngOnInit() {}
}
