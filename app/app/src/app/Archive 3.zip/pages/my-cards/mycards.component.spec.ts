import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Store, NgxsModule } from '@ngxs/store';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { FormBuilder } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { TitleCasePipe } from '@angular/common';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { IonicModule, ModalController, NavController } from '@ionic/angular';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MycardsComponent } from './mycards.component';
import { PopoverController } from '@ionic/angular';
import { mocks } from '@testing/constants/mocks.service';
import { MyCardsService } from '@app/services/mycards.service';
import { ConstantsService } from '@app/services/constants.service';
import { AlertService } from '@app/services/alert.service';
import { CardComponent } from '@app/pages/my-cards/card/card.component';
import { FileTransfer } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import { LocalNotifications } from '@ionic-native/local-notifications/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { EmailComposer } from '@ionic-native/email-composer/ngx';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { AlertsComponent } from '@app/components/alerts/alerts.component';

describe('MyCardsComponent', () => {
  let component: MycardsComponent;
  let fixture: ComponentFixture<MycardsComponent>;
  let navController;
  let cardService;
  let alertService;
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);
  const popoverCtrlSpy = jasmine.createSpyObj('PopoverController', ['create']);

  beforeEach(waitForAsync(() => {
    cardService = mocks.service.cardService;
    TestBed.configureTestingModule({
      imports: [IonicModule, HttpClientTestingModule, RouterTestingModule, NgxsModule.forRoot([]), NgxsSelectSnapshotModule.forRoot()],
      providers: [
        MycardsComponent,
        InAppBrowser,
        BrowserAnimationsModule,
        NoopAnimationsModule,
        ConstantsService,
        LocalNotifications,
        FormBuilder,
        AndroidPermissions,
        BrowserModule,
        EmailComposer,
        DatePipe,
        FileTransfer,
        FileOpener,
        File,
        Store,
        TitleCasePipe,
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        },
        {
          provide: PopoverController,
          useValue: popoverCtrlSpy
        },
        {
          provide: MyCardsService,
          useValue: cardService
        }
      ],
      declarations: [MycardsComponent, CardComponent, AlertsComponent]
    }).compileComponents();

    navController = TestBed.inject(NavController);
    alertService = TestBed.inject(AlertService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MycardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  xdescribe('ngOnInit', () => {
    beforeEach(() => {
      fixture = TestBed.createComponent(MycardsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
    it('should load', () => {
      expect(component).toBeTruthy();
    });
    xit('should check defalut component values after oninit', () => {
      component.ngOnInit();
      expect(component.currentView.length).toBeGreaterThan(0);
      // expect(component.isSidenavOpened).toBeFalsy();
    });
  });

  it('should check ion-title content', () => {
    const element = document.querySelector('ion-title');
    expect(element.textContent.length).toBeGreaterThan(0);
  });

  it('should check header text content', () => {
    const element = document.querySelector('.header-text');
    expect(element.textContent.length).toBeGreaterThan(0);
  });

  it('should card helpline text content', () => {
    const element = document.querySelector('.card-helper-header');
    expect(element.textContent.length).toBeGreaterThan(0);
  });

  it('should check orderReplacement call', () => {
    const spy = spyOn(navController, 'navigateForward');
    component.orderReplacement();
    expect(spy).toHaveBeenCalledWith('orderreplacement');
  });

  xit('should check sideNavStatus flag if toggleFilter called with true flage', () => {
    // component.toggleFilter(true);
    expect(component.sideNavStatus).toBeTruthy();
  });

  xit('should check showFilterPopover have been called', () => {
    // const spy = spyOn(component, 'showFilterPopover').and.returnValue(null);
    // component.showFilterPopover(null);
    // expect(spy).toHaveBeenCalled();
  });

  xit('should check sideNavStatus flag if toggleFilter called with false flage', () => {
    // component.toggleFilter(false);
    expect(component.sideNavStatus.length).toBeGreaterThan(0);
  });

  it('should check contact info text content', () => {
    const element = document.querySelector('.header-text a');
    expect(element.textContent.length).toBeGreaterThan(0);
  });

  it('should check member listlenth and member name of first list', () => {
    component.ionViewDidEnter();
    expect(component.membersList.length).toBeGreaterThan(0);
    expect(component.membersList[0].name.length).toBeGreaterThan(0);
  });

  it('should check subscriber default selection', () => {
    component.ionViewDidEnter();
    expect(component.membersList[0].selected).toBeTruthy();
  });

  xit('should check Total cards after the displaySelectedDependantData func call', () => {
    component.ionViewDidEnter();
    // component.displaySelectedDependantData();
    expect(component.cards.length).toBeGreaterThan(0);
    expect(component.cards[0].cardType.length).toBeGreaterThan(0);
  });

  xit('should check selected card type after the displaySelectedDependantData func call', () => {
    component.ionViewDidEnter();
    // component.displaySelectedDependantData();
    expect(component.selectedCard.cardType.length).toBeGreaterThan(0);
  });

  it('should check ngDestroy', () => {
    const spy = spyOn(alertService, 'clearError');
    component.ngOnDestroy();
    expect(spy).toHaveBeenCalled();
  });
});
