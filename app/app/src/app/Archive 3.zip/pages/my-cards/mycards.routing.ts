import { RouterModule, Routes } from '@angular/router';
import { MycardsComponent } from './mycards.component';
import { MyCardsGuard } from './mycards.guard';
import { DownloadModal } from './downloadModal/download-modal.component';
const MYCARDS_ROUTER: Routes = [
  {
    path: '',
    component: MycardsComponent,
    data: {
      breadcrumb: 'My Cards'
    },
    canActivate: [MyCardsGuard]
  },
  {
    path: "downloadModal",
    component: DownloadModal,
    canActivate: [MyCardsGuard]
  }
];

export const MY_CARDS_ROUTER = RouterModule.forChild(MYCARDS_ROUTER);
