import { BreadcrumbModule } from '@app/components/breadcrumbs/breadcrumbs.module';
import { CommonModule, TitleCasePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatListModule } from '@angular/material/list';
import { AlertsModule } from '@app/components/alerts/alerts.module';
import { FpoLayoutModule } from '@app/components/fpo-layout/fpo-layout.module';
import { CamelCaseModule } from '@app/pipes/camelcase/camel-case.module';
import { Clipboard } from '@ionic-native/clipboard/ngx';
import { IonicModule } from '@ionic/angular';
import { CardComponent } from './card/card.component';
import { CardModal } from './cardModal/card-modal.component';
import { DentalCardComponent } from './dental-card/dental-card.component';
import { DownloadModal } from './downloadModal/download-modal.component';
import { FilterPopoverComponent } from './filterPopover/filter-popover.component';
import { MedicalStandardComponent } from './medical-standard/medical-standard.component';
import { MycardsComponent } from './mycards.component';
import { MyCardsGuard } from './mycards.guard';
import { MY_CARDS_ROUTER } from './mycards.routing';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { VisionCardComponent } from './vision-card/vision-card.component';

@NgModule({
  declarations: [
    MycardsComponent,
    CardComponent,
    FilterPopoverComponent,
    DownloadModal,
    MedicalStandardComponent,
    VisionCardComponent,
    DentalCardComponent,
    CardModal
  ],
  imports: [
    CommonModule,
    MY_CARDS_ROUTER,
    FormsModule,
    FpoLayoutModule,
    BreadcrumbModule,
    ReactiveFormsModule,
    MatListModule,
    MatExpansionModule,
    MatDatepickerModule,
    MatNativeDateModule,
    IonicModule,
    CamelCaseModule,
    AlertsModule,
    FontAwesomeModule
  ],
  providers: [TitleCasePipe, MyCardsGuard, Clipboard]
})
export class MyCardsModule {}
