import { TitleCasePipe } from '@angular/common';
import { Component, ElementRef, HostListener, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatSelectionList } from '@angular/material/list';
import { Router } from '@angular/router';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { BreadCrumb } from '@app/components/breadcrumbs/breadcrumbs';
import { CardListResponse } from '@app/interfaces/carddetails-model.interface';
import { OrderreplacementService } from '@app/pages/orderreplacement/services/orderreplacement.service';
import { AlertService } from '@app/services/alert.service';
import { ConstantsService } from '@app/services/constants.service';
import { MyCardsService } from '@app/services/mycards.service';
import { SwrveEventNames, SwrveService } from '@app/services/swrve.service';
import { SetLoader } from '@app/store/actions/app.actions';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { getRTMSMode } from '@app/utils/app.utils';
import { Capacitor } from '@capacitor/core';
import { environment } from '@environments/environment';
import { NavController, Platform } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Store } from '@ngxs/store';
import { CardComponent } from './card/card.component';
@Component({
  templateUrl: './mycards.component.html',
  styleUrls: ['./mycards.component.scss']
})
export class MycardsComponent implements OnInit, OnDestroy {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;

  @ViewChild('cardfrontCanvas') canvasFrontRef: ElementRef;
  @ViewChild('cardbackCanvas') canvasBackRef: ElementRef;
  @ViewChild('cardsContainer') cardContainer: ElementRef;
  @ViewChild('cards') card: CardComponent;
  @ViewChild('members') members: MatSelectionList;

  cards: any[];
  membersList = [];
  public breadCrumbs: BreadCrumb[];
  isFrontView: boolean;
  currentView: string;
  memberName: string;
  dependant: string;
  sideNavStatus: string;
  sideNavMode: string;
  index: number;
  showClearLink = false;
  memberCard: any[];
  contactNumber: any;
  downloadFileName: string;
  cardData = false;
  fpoTargetUrl = environment.drupalUrl + '/page/mycards';
  accordions: { [prop: string]: boolean } = {};
  cardListResponse: CardListResponse;
  cardListResponseCount: number;
  contactus: string;
  selectedCard: any;
  mobileViewPort = 991;
  ismobile: boolean;
  isApp: boolean;
  isNative: boolean;
  singleMemPlan = false;
  isRtmsUpmode: boolean;
  disableOrder = false;
  disableDentalDownload = false;
  constructor(
    private cardService: MyCardsService,
    private alertService: AlertService,
    private constants: ConstantsService,
    private platform: Platform,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames,
    private navCtrl: NavController,
    private store: Store,
    private router: Router,
    public titleCasePipe: TitleCasePipe,
    public orderreplacementService: OrderreplacementService
  ) {
    //to be switched for Capacitor.isNativePlatform() after upgrade to Capcitor3;
    this.isNative = Capacitor.isNative;
    this.contactus = this.constants.contactus + this.authToken?.scopename;
    this.ismobile = window.innerWidth <= this.mobileViewPort;
    this.fpoTargetUrl = this.constants.drupalalMyCardsUrl;
    if (this.platform.is('desktop') === true) {
      this.isApp = true;
    }
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.ismobile = event.target.innerWidth <= this.mobileViewPort;
  }



  ngOnDestroy() {
    this.alertService.clearError();
    this.disableOrder = false;
    this.cardListResponse = null;
  }

  ngOnInit() {
    this.breadCrumbs = [];
    this.breadCrumbs.push(
      {
      label: 'Home',
      url: ['/home']
    });
    this.breadCrumbs.push({
      label: 'My Card',
      url: ['/mycards']
    });
 
    this.index = -1;
    this.cards = [];
    this.isFrontView = true;
    this.currentView = 'View Back';
    this.memberName = '';
  }

  ionViewDidEnter() {
    this.cardListResponseCount = 0;
    this.swrveService.sendAppMessage(this.swrveEventNames.appScreenMyCards);
    this.isRtmsUpmode = getRTMSMode();
    this.cardService.getfamilycards().subscribe(data => {
      if ((data && data < 0) || !data.familyMembers) {
        this.cardData = false;
        this.alertService.setAlert(data['displaymessage'], '', AlertType.Failure);
      } else {
        this.cardListResponse = data;
        this.cardListResponseCount = this.cardListResponse.familyMembers.length;
        this.singleMemPlan =
          this.cardListResponseCount === 1 && this.cardListResponse.familyMembers[0].memberCards.length === 1 ? true : false;
        this.cardData = true;
        this.disableDentalDownload = this.cardListResponse.familyMembers.length === 1
                                      && this.cardListResponse.familyMembers[0].memberCards.length === 1
                                        &&  this.cardListResponse.familyMembers[0].memberCards[0].cardType === 'DENTAL' ? true : false;
        if (this.cardListResponse.familyMembers.length) {
          this.accordions.acc0 = true;
        }
        if (this.isRtmsUpmode && this.singleMemPlan) {
          this.orderreplacementService.getCardPage().subscribe(data => {
            if (data) {
              if (data.MemberDetails && data.MemberDetails.length === 1) {
                if (data.MemberDetails[0].RequestIDcardEligibilityIndicator === 'false') {
                  this.alertService.setAlert(
                    'Our records show that you have placed an order in the past 14 days.',
                    'Too soon to order!',
                    AlertType.Notification
                  );
                  this.disableOrder = true;
                }
              } else {
                this.disableOrder = false;
              }
            }
          });
        }
      }
    });
    setTimeout(() => {
      this.store.dispatch(new SetLoader(false));
    }, 2000);
  }

  showSelectedMemberCard(email?: boolean) {
    const cardDetails = this.cardListResponse.familyMembers[0];
    const fileName = this.transformCardName(cardDetails);
    this.card.downloadPdf(fileName, email);
  }
  transformCardName(carddata) {
    let name = this.titleCasePipe.transform(carddata.memberName).replace(' ', '_');
    name = name + '_' + this.titleCasePipe.transform(carddata.memberCards[0].cardType);
    return name;
  }
  openDownloadModal() {
    this.router.navigate(['mycards/downloadModal']);
  }

  orderReplacement() {
    this.navCtrl.navigateForward('orderreplacement');
  }

  emailCard() {
    this.swrveService.sendAppMessage(this.swrveEventNames.appClickMyCardsEmailCard);
    this.router.navigate(['mycards/downloadModal'], { queryParams: { email: true } });
  }

  goBack() {
    this.router.navigate(['brandMyPlan'])
  }
  directDownEmail(email?: boolean) {
    if (!this.disableDentalDownload) {
      this.showSelectedMemberCard(email);
    }
  }
  expandAccordion(index: number): void {
    const prop = `acc${index}`;
    if (this.accordions[prop] === undefined) {
      this.accordions[prop] = false;
    }
    this.accordions[prop] = !this.accordions[prop];
  }
  ionViewDidLeave() {
    this.ngOnDestroy();
  }
}
