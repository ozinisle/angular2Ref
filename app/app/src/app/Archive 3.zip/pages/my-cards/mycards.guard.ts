import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class MyCardsGuard implements CanActivate {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;

  constructor(private router: Router) {}

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    const authTokenDetails = this.authToken;
    if (authTokenDetails && authTokenDetails !== 'undefined') {
      const authTokenDetailsJson = this.authToken;
      if (authTokenDetailsJson && authTokenDetailsJson.HasActivePlan !== 'true') {
        this.router.navigate(['/home']);
        return false;
      }
    }
    return true;
  }
}
