import { Observable, of as observableOf } from 'rxjs';

import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { ConstantsService } from '@app/services/constants.service';
import {
  GetRecentVisitsRequestModelInterface,
  GetRecentVisitsResponseModelInterface
} from '../my-doctors-pcp/models/interfaces/get-recent-visits-models.interface';
import { MyDoctorsGenericRequestModel } from '../my-doctors-pcp/models/my-doctor-module-common.model';
import { GetMemBasicInfoRequestModel, GetMemBasicInfoResponseModel } from '../my-medication/models/get-member-basic-info.model';
import {
  GetMemBasicInfoRequestModelInterface,
  GetMemBasicInfoResponseModelInterface
} from '../my-medication/models/interfaces/get-member-basic-info-model.interface';
import { GetRequestEstimateDetailsRequestModel } from './models/get-request-estimate-details.model';
import {
  GetRequestEstimateDetailsRequestModelInterface,
  GetRequestEstimateDetailsResponseModelInterface
} from './models/interfaces/get-request-estimate-details-models.interface';
import {
  SubmitRequestEstimateDetailsRequestModelInterface,
  SubmitRequestEstimateDetailsResponseModelInterface
} from './models/interfaces/submit-request-estimate-details-models.inteface';

import { HttpClient } from '@angular/common/http';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { GetDependentRecentVisitsResponseModelInterface } from '../my-doctors-pcp/models/interfaces/get-dependent-recent-visits-model.interface';
import { Store } from '@ngxs/store';
import { SetBasicMemberInfo } from '@app/store/actions/app.actions';

@Injectable({ providedIn: 'root' })
export class RequestEstimateService {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getBasicMemberInfo) basicMemInfo: any;

  constructor(private http: HttpClient, private store: Store, private constants: ConstantsService) {}

  getMemBasicInfo(): Observable<GetMemBasicInfoResponseModelInterface> {
    if (this.basicMemInfo) {
      return observableOf(this.basicMemInfo);
    }

    const request: GetMemBasicInfoRequestModelInterface = new GetMemBasicInfoRequestModel();
    request.useridin = this.useridin;

    return this.http.post(this.constants.getMemBasicInfoUrl, request).pipe(
      map((response: any) => {
        if (response.result < 0) {
          return new GetMemBasicInfoResponseModel();
        } else {
          const basicInfo = new GetMemBasicInfoResponseModel();
          basicInfo.rxSummary = response.getMemBasicInfoResponse;
          this.store.dispatch(new SetBasicMemberInfo(basicInfo));
          return basicInfo as GetMemBasicInfoResponseModel;
        }
      })
    );
  }

  getRecentVisits(): Observable<GetRecentVisitsResponseModelInterface> {
    const request: GetRecentVisitsRequestModelInterface = new MyDoctorsGenericRequestModel();
    request.useridin = this.useridin;

    return this.http.post(this.constants.myDoctorListUrl, request).pipe(
      map(response => {
        return response as GetRecentVisitsResponseModelInterface;
      })
    );
  }

  getDependentRecentVisits(dependentsData): Observable<GetDependentRecentVisitsResponseModelInterface> {
    const request = new MyDoctorsGenericRequestModel();
    request.useridin = this.useridin;
    request.dependentId = dependentsData.dependent ? dependentsData.dependent.depId : '';
    return this.http.post(this.constants.myDepDoctorListUrl, request).pipe(
      map(response => {
        return response as GetDependentRecentVisitsResponseModelInterface;
      })
    );
  }

  getRequestEstimate(): Observable<GetRequestEstimateDetailsResponseModelInterface> {
    const request: GetRequestEstimateDetailsRequestModelInterface = new GetRequestEstimateDetailsRequestModel();
    request.useridin = this.useridin;

    return this.http.post(this.constants.getRequestEstimateUrl, request).pipe(
      map(response => {
        return response as GetRequestEstimateDetailsResponseModelInterface;
      })
    );
  }

  submitrequestestimatedetails(
    request: SubmitRequestEstimateDetailsRequestModelInterface
  ): Observable<SubmitRequestEstimateDetailsResponseModelInterface> {
    return this.http.post(this.constants.submitrequestestimatedetailsUrl, request).pipe(
      map(response => {
        return response as SubmitRequestEstimateDetailsResponseModelInterface;
      })
    );
  }
}
