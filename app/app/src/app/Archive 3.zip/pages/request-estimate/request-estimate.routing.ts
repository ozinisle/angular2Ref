import { RouterModule, Routes } from '@angular/router';
import { RequestEstimateComponent } from './landing/request-estimate.component';
import { RequestEstimateGuard } from './request-estimate.guard';
import { RequestEstimateSuccessComponent } from './success/request-estimate-success.component';

const REQUEST_ESTIMATE_ROUTES: Routes = [
  {
    path: '',
    canActivate: [RequestEstimateGuard],
    children: [
      {
        path: '',
        component: RequestEstimateComponent
      }
    ]
  },
  {
    path: 'success',
    children: [
      {
        path: '',
        component: RequestEstimateSuccessComponent
      }
    ]
  }
];

export const REQUEST_ESTIMATE_ROUTER = RouterModule.forChild(REQUEST_ESTIMATE_ROUTES);
