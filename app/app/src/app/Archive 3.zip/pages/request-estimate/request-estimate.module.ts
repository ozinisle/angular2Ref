import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatListModule } from '@angular/material/list';
import { MatTooltipModule } from '@angular/material/tooltip';
import { TextMaskModule } from 'angular2-text-mask';
import { ProfileService } from '@app/services/profile.service';
import { RequestEstimateComponent } from './landing/request-estimate.component';
import { PopoverComponent } from './popover/popover.component';
import { RequestEstimateGuard } from './request-estimate.guard';
import { REQUEST_ESTIMATE_ROUTER } from './request-estimate.routing';
import { RequestEstimateService } from './request-estimate.service';
import { RequestEstimateSuccessComponent } from './success/request-estimate-success.component';
import { AlertsModule } from '@app/components/alerts/alerts.module';
import { IonicModule } from '@ionic/angular';
import { CamelCaseModule } from '@app/pipes/camelcase/camel-case.module';
import { AppControlMessagesModule } from '@app/components/app-control-messages/app-control-messages.module';
import { WordwrapModule } from '@app/directives/wordwrap/wordwrap.module';
import { FpoLayoutModule } from '@app/components/fpo-layout/fpo-layout.module';
import { IabClickBlockModule } from '@app/components/Iab-component/iab-click-block.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  imports: [
    REQUEST_ESTIMATE_ROUTER,
    FormsModule,
    CommonModule,
    TextMaskModule,
    ReactiveFormsModule,
    MatListModule,
    MatExpansionModule,
    MatTooltipModule,
    AlertsModule,
    IonicModule,
    CamelCaseModule,
    AppControlMessagesModule,
    WordwrapModule,
    FpoLayoutModule,
    IabClickBlockModule,
    FontAwesomeModule
  ],
  declarations: [RequestEstimateComponent, RequestEstimateSuccessComponent, PopoverComponent],
  providers: [RequestEstimateService, RequestEstimateGuard, ProfileService]
})
export class RequestEstimateModule {}
