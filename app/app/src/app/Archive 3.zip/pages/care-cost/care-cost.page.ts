import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthToken } from '@app/models/auth-token.model';
import { PostLoginModel } from '@app/models/post-login.model';
import { ConstantsService } from '@app/services/constants.service';
import { HomeService } from '@app/services/home.service';
import { IabService } from '@app/services/iab.service';
import { SwrveEventNames, SwrveService } from '@app/services/swrve.service';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { ProfileSelectors } from '@app/store/selectors/profile.selectors';
import { GlobalUtils } from '@app/utils/global.utils';
import { Platform } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Select } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { HomePageAppInfoModel } from '../home/home.model';
import { SsoService } from '../sso/sso.service';

@Component({
  selector: 'app-careCost',
  templateUrl: 'care-cost.page.html',
  styleUrls: ['care-cost.page.scss']
})
export class CareCostPage implements OnInit, OnDestroy {
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;
  @SelectSnapshot(AppSelectors.getPostLoginInfo) postLoginInfo: PostLoginModel;
  @SelectSnapshot(AppSelectors.getUserType) userType: string;
  @SelectSnapshot(AppSelectors.getMemberInfo) memberInfo: HomePageAppInfoModel;
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: AuthToken;
  @SelectSnapshot(ProfileSelectors.getTeleHealthFlag) amwellTeleHealthFlag: boolean;
  @Select(ProfileSelectors.getTeleHealthFlag) teleHealthFlag$: Observable<boolean>;

  homeNavigationApiResponse: any;
  listItems: CareCostItemType[];
  isAuthenticatedUser: boolean;
  callNurseLine: CallNurseLine;
  healthyAction = '';
  identityProduction = '';
  ahealthym = '';
  isAnonymousUser: boolean;
  isRegisteredUser: boolean;
  isMedicareUser = false;
  ahealthyme = false;
  featureUrl = this.constants.featureUrl;
  authAHealthyMe = this.swrveEventNames.appClickHomeAuthenticatedAHealthyMe;
  unAuthAHealthyMe = this.swrveEventNames.appClickHomeAnonymousAHealthyMe;
  healthyActions = 'http://healthy-actions.com/';
  iswellnessRewardsProgramUser = false;
  ismobile: boolean;
  private unsubscribeHelper$: Subject<void> = new Subject<void>();

  constructor(
    private router: Router,
    private ssoService: SsoService,
    private iabService: IabService,
    private constants: ConstantsService,
    public homeService: HomeService,
    private swrveEventNames: SwrveEventNames,
    private swrveService: SwrveService,
    private resizeService: GlobalUtils,
    private platform: Platform
  ) {}

  ngOnInit() {
    this.resizeService
      .getIsMobile()
      .pipe(takeUntil(this.unsubscribeHelper$))
      .subscribe((isMobile: boolean) => (this.ismobile = isMobile));
  }

  ngOnDestroy(): void {
    this.unsubscribeHelper$.next();
    this.unsubscribeHelper$.complete();
  }

  ionViewWillEnter() {
    this.isRegisteredUser = this.scopeName?.includes('REGISTERED');
    this.isAuthenticatedUser = this.scopeName.includes('AUTHENTICATED');
    this.isAnonymousUser = !(this.isRegisteredUser || this.isAuthenticatedUser);
    this.initializeItemList();
    this.healthyAction = this.constants.healthAction;
    this.identityProduction = this.constants.identityProduction;
    this.ahealthym = this.constants.cernerMedicareUrl;
  }

  goBack() {
    this.router.navigate(['/brand-home']);
  }

  ionViewDidEnter() {
    if (this.userType && (this.userType.toLowerCase() === 'medicare' || this.userType.toLowerCase() === 'medex')) {
      this.isMedicareUser = true;
    }
    if (this.memberInfo) {
      this.ahealthyme = this.memberInfo?.wellnessVendorCd === 'C' || this.memberInfo?.cerner.hasCernerMedicare === 'true';
      this.iswellnessRewardsProgramUser = this.memberInfo?.wellnessVendorCd === 'VP' && this.memberInfo?.cerner.hasCernerMedicare === 'false';
    }
  }
  initializeItemList() {
    this.homeService.setSessionLinks();

    this.homeService.getHomeNavigationResponse().subscribe(response => {
      this.homeNavigationApiResponse = Array.isArray(response) ? response[0] : response;
      if (this.homeNavigationApiResponse) {
        const findADoctorUrl = this.homeNavigationApiResponse.APPTextUrl3 || '';
        const callNurseLinkUrl = this.homeNavigationApiResponse.APPTextUrl2 || '';
        this.callNurseLine = { labelText: 'Call the 24/7 Nurse Line', phoneNumber: callNurseLinkUrl, icon: 'fal fa-phone fa-lg' };
        this.listItems = [
          {
            label: 'Find a Doctor & Estimate Costs',
            icon: 'fal fa-stethoscope fa-lg',
            url: findADoctorUrl,
            isSSO: true,
            ssoType: 'fad',
            isPhone: false,
            id: 'fad'
          },
          {
            label: 'Live Video Visits with Well Connection',
            icon: 'fal fa-comment-medical fa-lg',
            url: this.constants.wellConnectionUrl,
            isSSO: false,
            ssoType: '',
            isPhone: false,
            id: 'well-connection'
          }
        ];
      }
    });
  }

  openInAPPBrowser(url) {
    this.iabService.create(url);
  }

  openWellnessRewardsProgram() {
     if (this.iswellnessRewardsProgramUser) {
    this.ssoService.openSSO('wellnessRewardsProgram_VP');
     }
  }

  openIdentityProtection() {
    this.router.navigate(['pages/campaign1']);
  }

  checkSmartShopperUser(postLoginInfo: any = {}) {
    return postLoginInfo.hasSS;
  }

  checkSapphireDigitalUser(postLoginInfo: any = {}) {
    return postLoginInfo.hasCI || postLoginInfo.hasSS || postLoginInfo.hasSSO;
  }
  /*openWelconnection() {
    this.iabService.create(this.constants.wellConnectionUrl);
  }*/

  openInAppBrowserSso(url: string, ssoLink: string, unAuthSwrveEvent: string, authSwrveEvent: string) {
    if (ssoLink === 'cerner') {
      if (this.memberInfo?.cerner.hasCernerMedicare === 'true') {
        if (this.platform.is('cordova')) {
          this.openInAPPBrowser(this.constants.cernerMedicareUrl);
        } else {
          window.open(this.constants.cernerMedicareUrl, '_blank');
        }
      } else if (this.memberInfo?.wellnessVendorCd === 'C' && this.memberInfo?.cerner.hasCernerMedicare === 'false') {
        this.sendSwrveEventsForIABClicks(authSwrveEvent);
        this.ssoService.openSSO('cerner');
      }
      return;
    }
  }

  sendSwrveEventsForIABClicks(desctiption: string) {
    if (desctiption === 'Find_a_doctor') {
      if (this.isAuthenticatedUser) {
        this.swrveService.sendAppMessage(this.swrveEventNames.appClickHomeAuthenticatedFindADoctor);
      } else if (this.isRegisteredUser) {
        this.swrveService.sendAppMessage(this.swrveEventNames.appClickHomeRegisteredFindADoctor);
      } else if (this.isAnonymousUser) {
        this.swrveService.sendAppMessage(this.swrveEventNames.appClickHomeAnonymousFindADoctor);
      }
    }
  }

  navigate(item: CareCostItemType) {
    if (item.url.endsWith('fad')) {
      const isSapphireDigitalUser = this.postLoginInfo ? this.checkSapphireDigitalUser(this.postLoginInfo) : false;
      if (isSapphireDigitalUser) {
        this.ssoService.openSSO('fad');
      } else {
        this.router.navigate(['fad']);
      }
      return;
    }
    if (item.isSSO && this.isAuthenticatedUser) {
      this.ssoService.openSSO(item.ssoType);
    } else {
      this.iabService.create(item.url);
    }
  }

  navigateSmartShopperLink() {
    const isSmartShopperUser = this.postLoginInfo ? this.checkSmartShopperUser(this.postLoginInfo) : false;
    if (isSmartShopperUser) {
      this.ssoService.openSSO('fad');
    }
  }

  navigateVirtualVisits() {
    this.router.navigate(['/virtual-visit']);
  }

  /*openHealthActionLink() {
    window.open(this.healthyActions, '_blank');
  }*/
}

interface CareCostItemType {
  label: string;
  icon: string;
  url: string;
  isSSO: boolean;
  ssoType: string;
  isPhone: boolean;
  id: string;
}

interface CallNurseLine {
  labelText: string;
  phoneNumber: string;
  icon: string;
}
