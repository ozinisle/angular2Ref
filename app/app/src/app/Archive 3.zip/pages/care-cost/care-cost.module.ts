import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { CareCostPage } from './care-cost.page';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { VitalsService } from '@app/services/vitals.service';

@NgModule({
  imports: [IonicModule, CommonModule, FormsModule, FontAwesomeModule, RouterModule.forChild([{ path: '', component: CareCostPage }])],
  declarations: [CareCostPage],
  providers: [InAppBrowser,  VitalsService]
})
export class CareCostPageModule {}
