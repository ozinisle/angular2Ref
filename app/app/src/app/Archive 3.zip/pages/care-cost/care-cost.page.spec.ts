import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { IonicModule } from '@ionic/angular';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '@app/services/constants.service';
import { HomeService } from '@app/services/home.service';
import { SsoService } from '../sso/sso.service';
import { CareCostPage } from './care-cost.page';
import { mocks } from '@testing/constants/mocks.service';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { AppState } from '@app/store/state/app.state';
import { LoadingController } from '@ionic/angular';
import { DatePipe } from '@angular/common';

describe('Care Cost Page Tests', () => {
  let component: CareCostPage;
  let fixture: ComponentFixture<CareCostPage>;

  let mockHomeService;

  beforeEach(waitForAsync(() => {
    mockHomeService = mocks.service.homeService;
    TestBed.configureTestingModule({
      imports: [
        IonicModule,
        RouterTestingModule,
        HttpClientTestingModule,
        NgxsModule.forRoot([AppState]),
        NgxsSelectSnapshotModule.forRoot()
      ],
      providers: [
        SsoService,
        ConstantsService,
        InAppBrowser,
        LoadingController,
        DatePipe,
        {
          provide: HomeService,
          useValue: mockHomeService
        }
      ],
      declarations: [CareCostPage]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CareCostPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('Validating List Items is exist', () => {
    component.ionViewWillEnter();
    expect(component.listItems.length).toBeTruthy();
  });
  it('Validating List Items with Mock Home API', () => {
    component.ionViewWillEnter();
    expect(component.listItems.length).toEqual(2);
    expect(component.listItems[0].label.length).toBeGreaterThan(0);
  });

  it('Validating callNurseLine is exist and contains text', () => {
    component.ionViewWillEnter();
    expect(component.callNurseLine).toBeTruthy();
    expect(component.callNurseLine.labelText.length).toBeGreaterThan(0);
  });

  it('Validating Ion List with Mock Home API', () => {
    component.ionViewWillEnter();
    component = fixture.componentInstance;
    fixture.detectChanges();
    const element = document.querySelector('.features-list');
    expect(element.childElementCount).toEqual(3);
    expect(element.childNodes[1].childNodes[1].textContent.length).toBeGreaterThan(0);
  });

  it('Ion Title is Exist', () => {
    const element = document.querySelector('ion-title');
    expect(element).toBeTruthy();
  });
  it('Ion Title contains text', () => {
    const element = document.querySelector('ion-title');
    expect(element.textContent.length).toBeGreaterThan(0);
  });

  it('check checkSmartShopperUser function return value as true besed on arguement', () => {
    const returnFlag = component.checkSmartShopperUser({ hasCI: true });
    expect(returnFlag).toBeTruthy();
  });

  it('check checkSmartShopperUser function return value as false besed on arguement', () => {
    const returnFlag = component.checkSmartShopperUser({});
    expect(returnFlag).toBeFalsy();
  });
});
