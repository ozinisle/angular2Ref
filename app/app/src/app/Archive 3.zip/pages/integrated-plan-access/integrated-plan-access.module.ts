import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { IntegratedPlanAccessComponent } from './integrated-plan-access.component';
import { IpaAlertComponent } from './ipa-alert/ipa-alert.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { AlertsModule } from '@app/components/alerts/alerts.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    FontAwesomeModule,
    AlertsModule
  ],
  declarations: [IntegratedPlanAccessComponent, IpaAlertComponent],
  exports: [IntegratedPlanAccessComponent, IpaAlertComponent]
})
export class IntegratedPlanAcccessModule {}
