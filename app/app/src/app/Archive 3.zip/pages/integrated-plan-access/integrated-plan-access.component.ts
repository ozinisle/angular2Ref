import { Component } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { Observable } from 'rxjs';
import { ModalController} from '@ionic/angular';
import { IPAModalComponent } from '@app/modals/ipa-modal/ipa-modal.component';
import { MemberPlan } from '@app/models/member-plan.model';
import { Select } from '@ngxs/store';

@Component({
  selector: 'integrated-plan-access',
  templateUrl: './integrated-plan-access.component.html',
  styleUrls: ['./integrated-plan-access.component.scss']
})

export class IntegratedPlanAccessComponent  {

  @Select(AppSelectors.getSelectedPlan) selectedPlan$: Observable<MemberPlan>;
  @SelectSnapshot(AppSelectors.getPlansList) memberPlans: MemberPlan[];

  constructor(
    private modalController: ModalController
  ) {}

  async openIPAModal() {
    const modal = await this.modalController.create({
      component: IPAModalComponent,
      cssClass: 'ipa-modal',
      keyboardClose: false,
      showBackdrop: true,
      backdropDismiss: false
    });
    await modal.present();
  }
}
