import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ConstantsService } from '../../services/constants.service';
import { map } from 'rxjs/operators';
import { LoginResponse } from '@app/models/login-response.model';

@Injectable({ providedIn: 'root' })
export class  IntegratedPlanAccessService {

  constructor(private constants: ConstantsService, private http: HttpClient) {}

  getSwitchPlanAPI(memberId, memberSuffix, useridin, authToken, cryptoToken  ): Observable<LoginResponse> {

    const request = {
      mesg: {
      useridin: useridin,
      cardMemId: memberId,
      cardMemSuffix: memberSuffix,
      migrationType : authToken.migrationtype,
      destinationURL : authToken.destinationURL,
      key2id: cryptoToken.key2id
    },
    key1id: cryptoToken.key1id
    };
    this.http.get(this.constants.tokenbaseurl + this.constants.tokensEndPoint)
    return this.http.post(this.constants.switchPlanAPI, request).pipe(map(data => data as LoginResponse));
  }
}
