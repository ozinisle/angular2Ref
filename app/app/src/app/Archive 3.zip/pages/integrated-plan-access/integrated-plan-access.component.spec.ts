import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { IonicModule, ModalController } from '@ionic/angular';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { NgxsModule } from '@ngxs/store';
import { IntegratedPlanAccessComponent } from './integrated-plan-access.component';

describe('IntegratedPlanAccessComponent', () => {
  let component: IntegratedPlanAccessComponent;
  let fixture: ComponentFixture<IntegratedPlanAccessComponent>;
  let modalController: ModalController;
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ IntegratedPlanAccessComponent ],
      imports: [CommonModule, HttpClientTestingModule, RouterTestingModule, IonicModule.forRoot(), NgxsModule.forRoot([]), NgxsSelectSnapshotModule.forRoot()
    ]
    }).compileComponents();
    modalController = TestBed.inject(ModalController);
    fixture = TestBed.createComponent(IntegratedPlanAccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call modalcontroller', () => {
    const spyStore = spyOn(modalController, 'create').and.callThrough();
    component.openIPAModal();
    expect(spyStore).toHaveBeenCalled();
  });
});
