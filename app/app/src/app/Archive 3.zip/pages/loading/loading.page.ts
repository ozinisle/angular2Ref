import { Component  , OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SetLoader } from '@app/store/actions/app.actions';
import { NavController } from '@ionic/angular';
import { Store } from '@ngxs/store';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-loading',
  templateUrl: './loading.page.html',
  styleUrls: ['./loading.page.scss'],
})
export class LoadingPage implements OnInit {

  destroy$ = new Subject<void>();
  constructor(private store: Store, private route: ActivatedRoute, private router: Router, private navCtrl: NavController) { }

  ngOnInit() {
  }

  ionViewWillEnter() {
    this.navCtrl.pop();
    this.route.queryParams.pipe(takeUntil(this.destroy$)).subscribe(params => {
      const url = params.redirectUrl;
      setTimeout(() => {
        if (url) {
          this.router.navigate([url], {queryParams: {'t' : (new Date()).getTime()}});
        }
      }, 3000);
    });
  }
  ionViewWillLeave() {
    this.store.dispatch(new SetLoader(false));
    this.destroy$.next();
    this.destroy$.complete();
  }
}
