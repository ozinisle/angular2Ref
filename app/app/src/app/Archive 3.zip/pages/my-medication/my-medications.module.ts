import { CommonModule, TitleCasePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatListModule } from '@angular/material/list';
import { FilterPipe, FilterPipeModule } from 'ngx-filter-pipe';
import { OrderModule } from 'ngx-order-pipe';
import { MyMedicationDetailsPage } from './my-medication-details/my-medication-details.page';
import { MyMedicationDetailsService } from './my-medication-details/my-medication-details.service';
import { MEDICATIONS_ROUTES } from './my-medications.routing';
import { IonicModule } from '@ionic/angular';
import { MatFormFieldModule } from '@angular/material/form-field';
import { CasingForFilterModule } from '@app/pipes/casingForFilter/casing-for-filter.module';
import { NgxMaskModule } from 'ngx-mask';
import { FpoLayoutModule } from '@app/components/fpo-layout/fpo-layout.module';
import { MyMedicationFilterComponent } from './my-medication-filter/my-medication-filter.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { MyMedicationsPage } from './my-medications/my-medications.page';
import { CalendarModule } from 'ion2-calendar';
import { IntegratedPlanAcccessModule } from '../integrated-plan-access/integrated-plan-access.module';
import { BreadcrumbModule } from '@app/components/breadcrumbs/breadcrumbs.module';

@NgModule({
  declarations: [MyMedicationsPage, MyMedicationDetailsPage, MyMedicationFilterComponent],
  imports: [
    CommonModule,
    MEDICATIONS_ROUTES,
    FormsModule,
    BreadcrumbModule,
    ReactiveFormsModule,
    MatExpansionModule,
    MatListModule,
    MatDatepickerModule,
    MatNativeDateModule,
    FilterPipeModule,
    OrderModule,
    IonicModule,
    MatFormFieldModule,
    CasingForFilterModule,
    NgxMaskModule,
    FpoLayoutModule,
    FontAwesomeModule,
    CalendarModule,
    IntegratedPlanAcccessModule
  ],
  providers: [FilterPipe, TitleCasePipe, MyMedicationDetailsService]
})
export class MyMedicationsModule {}
