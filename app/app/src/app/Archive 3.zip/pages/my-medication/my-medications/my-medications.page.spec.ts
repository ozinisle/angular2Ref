import { DependentState } from '@app/store/state/dependent.state';
import { AppState } from '@app/store/state/app.state';
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { MyMedicationsPage } from './my-medications.page';
import { NavController, ModalController, LoadingController, IonicModule } from '@ionic/angular';
import { UrlSerializer } from '@angular/router';
import { MedicationsService } from '@app/services/medications.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Store, NgxsModule } from '@ngxs/store';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { mocks } from '@testing/constants/mocks.service';
import { DatePipe, Location, TitleCasePipe } from '@angular/common';
import { SwrveEventNames, SwrveService } from '@app/services/swrve.service';
import { MyMedicationDetailsService } from '../my-medication-details/my-medication-details.service';
import { FilterService } from '@app/services/filter.service';
import { SsoService } from '../../sso/sso.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { DependentService } from '@app/services/dependent.service';
import { SetLoader } from '@app/store/actions/app.actions';
import { Router } from '@angular/router';
import { AlertService } from '@app/services/alert.service';
import { ConstantsService } from '@app/services/constants.service';
import { MatListModule } from '@angular/material/list';
import { FpoLayoutComponent } from '@app/components/fpo-layout/fpo-layout.component';
import { MatExpansionModule } from '@angular/material/expansion';
import { of } from 'rxjs';

class MockConstantsService {}
class MockSwrveEventNames {}
class MockMyMedicationDetailsService {}

class MockMedicationsService {
  getMemBasicInfo(): Promise<any[]> {
    return of([]).toPromise();
  }
  getMedications(): Promise<any[]> {
    return of([]).toPromise();
  }

  setBasicMemInfo() {}
}

const modalObj = {
  present: () => Promise.resolve(true),
  onDidDismiss: () => Promise.resolve({ res: { data: 'test-value1' } })
};

describe('MyMedicationsPage', () => {
  let store: Store;
  let location: Location;
  // let actions$: Observable<any>;
  let mockAlertService;
  let swrveService;
  let ssoService;
  let medicationsService;
  let router: Router;
  let component: MyMedicationsPage;
  let fixture: ComponentFixture<MyMedicationsPage>;
  let modalControllerSpy;

  modalControllerSpy = jasmine.createSpyObj('ModalController', ['create', 'present']);

  // mock the returned value from the service
  modalControllerSpy.create.and.returnValue(modalObj);
  modalControllerSpy.present.and.returnValue(Promise.resolve('test-value2'));

  beforeEach(waitForAsync(() => {
    mockAlertService = mocks.service.alertService;
    TestBed.configureTestingModule({
      imports: [
        IonicModule,
        NgxsModule.forRoot([AppState, DependentState]),
        NgxsSelectSnapshotModule.forRoot(),
        HttpClientTestingModule,
        RouterTestingModule,
        BrowserAnimationsModule,
        BrowserModule,
        NoopAnimationsModule,
        MatListModule,
        MatExpansionModule
      ],
      declarations: [MyMedicationsPage, FpoLayoutComponent],
      providers: [
        NavController,
        UrlSerializer,
        TitleCasePipe,
        SwrveService,
        LoadingController,
        InAppBrowser,
        DependentService,
        SsoService,
        FilterService,
        { provide: AlertService, useValue: mockAlertService },
        { provide: ConstantsService, useClass: MockConstantsService },
        {
          provide: ModalController,
          useValue: modalControllerSpy
        },
        { provide: SwrveEventNames, useClass: MockSwrveEventNames },
        { provide: MyMedicationDetailsService, useClass: MockMyMedicationDetailsService },
        { provide: MedicationsService, useClass: MockMedicationsService },
        DatePipe
      ]
    }).compileComponents();
      store = TestBed.inject(Store);
      // actions$ = TestBed.inject(Actions);
      location = TestBed.inject(Location);
      swrveService = TestBed.inject(SwrveService);
      ssoService = TestBed.inject(SsoService);
      medicationsService = TestBed.inject(MedicationsService);
      router = TestBed.inject(Router);
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(MyMedicationsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should create ModalController on openModal', () => {
    component.openModal('text', 'text');
    expect(modalControllerSpy.create).toHaveBeenCalled();
  });
  it('should noMedicationsAvailable defined', () => {
    component.ionViewDidEnter();
    expect(component.noMedicationsAvailable).toBeDefined();
  });
  it('should noMedicationsAvailable truthy', () => {
    component.ionViewDidEnter();
    expect(component.noMedicationsAvailable).toBeTruthy();
  });
  it('should dispatch SetLoader on ionViewDidEnter', done => {
    store.dispatch(new SetLoader(true));
    const spyStore = spyOn(store, 'dispatch').and.callThrough();
    component.ionViewDidEnter();
    expect(spyStore).toHaveBeenCalled();
  });
  it('should medicationsService  getMemBasicInfo to be defined', () => {
    const medicationSpy = spyOn(medicationsService, 'getMemBasicInfo');
    component.ionViewDidEnter();
    expect(medicationSpy).toBeDefined();
  });
  it('should medicationsService  getMemBasicInfo to be called', () => {
    const medicationSpy = spyOn(medicationsService, 'getMemBasicInfo');
    component.ionViewDidEnter();
    expect(medicationSpy).toHaveBeenCalled();
  });
  it('should medicationsService  getMedications to be defined', () => {
    const medicationSpy = spyOn(medicationsService, 'getMedications');
    component.ionViewDidEnter();
    expect(medicationSpy).toBeDefined();
  });
  it('should medicationsService  getMedications to be called', () => {
    const medicationSpy = spyOn(medicationsService, 'getMedications');
    component.ionViewDidEnter();
    expect(medicationSpy).toHaveBeenCalled();
  });
  it('should navigate to pillpack on navigateToPillPack', () => {
    const navigateSpy = spyOn(router, 'navigate');
    component.navigateToPillPack();
    expect(navigateSpy).toHaveBeenCalledWith(['/my-pillpack/landing'], { queryParams: { icid: 'PillPack Global' } });
  });
  it('should call sessionStorage on clearSessionItems', () => {
    const sessionSpy = spyOn(sessionStorage, 'removeItem');
    component.clearSessionItems();
    expect(sessionSpy).toHaveBeenCalled();
    expect(sessionSpy).toHaveBeenCalledTimes(2);
  });
  it('should call sessionStorage setItem on openPillPackSite', () => {
    const sessionSpy = spyOn(sessionStorage, 'setItem');
    component.openPillPackSite();
    expect(sessionSpy).toHaveBeenCalled();
  });
  it('should call sessionStorage setItem on openPillPackSite', () => {
    const spy = spyOn(component, 'openModal');
    component.openPillPackSite();
    expect(spy).toHaveBeenCalled();
  });
  it('should call swrveService on ngOnInit', () => {
    const swrveSpy = spyOn(swrveService, 'sendAppMessage');
    component.ngOnInit();
    expect(swrveSpy).toHaveBeenCalled();
  });
  it('should isPillPackEnrolledThisSession to be defined and true', () => {
    sessionStorage.setItem('isCompleteHanddoff', 'true');
    component.ngOnInit();
    expect(component.isPillPackEnrolledThisSession).toBeDefined();
    expect(component.isPillPackEnrolledThisSession).toBe(true);
  });
  it('should isPillPackEnrolledThisSession to be defined', () => {
    component.ngOnInit();
    expect(component.isPillPackEnrolledThisSession).toBeDefined();
  });
  it('should isPillPackEnrolledThisSession to be falsy', () => {
    sessionStorage.setItem('isCompleteHanddoff', '');
    component.ngOnInit();
    expect(component.isPillPackEnrolledThisSession).toBeFalsy();
  });
  it('should isCPDPPromotion to be defined', () => {
    component.ngOnInit();
    expect(component.isCPDPPromotion).toBeDefined();
  });
  it('should isCPDPEnrolled to be defined', () => {
    component.ngOnInit();
    expect(component.isCPDPEnrolled).toBeDefined();
  });
  it('should isCPDPHandedoff to be defined', () => {
    component.ngOnInit();
    expect(component.isCPDPHandedoff).toBeDefined();
  });
  it('should hasESIAccountInfoFlag to be defined', () => {
    component.ngOnInit();
    expect(component.hasESIAccountInfoFlag).toBeDefined();
  });
  it('should hasESIAccountInfoFlag to be false', () => {
    component.ngOnInit();
    expect(component.hasESIAccountInfoFlag).toBeFalsy();
  });
  it('should isInActiveUser to be defined', () => {
    expect(component.isInActiveUser).toBeDefined();
  });
  it('should call the "alertService.clearError" function', () => {
    component.ngOnDestroy();
    expect(mockAlertService.clearError).toHaveBeenCalled();
  });
  it('should call removeItem on ngOnDestroy', () => {
    const sessionSpy = spyOn(sessionStorage, 'removeItem');
    component.ngOnDestroy();
    expect(sessionSpy).toHaveBeenCalled();
  });
  it('should call removeItem with medicationSelectedUserId on ngOnDestroy', () => {
    const sessionSpy = spyOn(sessionStorage, 'removeItem');
    component.ngOnDestroy();
    expect(sessionSpy).toHaveBeenCalledWith('medicationSelectedUserId');
  });
  it('should issearchShowing to be defined and false', () => {
    component.ClearSearch();
    expect(component.issearchShowing).toBeDefined();
    expect(component.issearchShowing).toBeFalsy();
  });
  // TEST FAILS AT TIMES
  it('should searchval to be defined and empty', () => {
    component.ClearSearch();
    expect(component.searchval).toBeDefined();
    expect(component.searchval).toBe('');
  });
  it('should isDisplayMessage to be defined and false', () => {
    component.ClearSearch();
    expect(component.isDisplayMessage).toBeDefined();
    expect(component.isDisplayMessage).toBeFalsy();
  });
  it('should isautosearch to be defined and false', () => {
    component.ClearSearch();
    expect(component.isautosearch).toBeDefined();
    expect(component.isautosearch).toBeFalsy();
  });
  it('should call removeItem with searchval on ClearSearch', () => {
    const sessionSpy = spyOn(sessionStorage, 'removeItem');
    component.ClearSearch();
    expect(sessionSpy).toHaveBeenCalled();
    expect(sessionSpy).toHaveBeenCalledWith('searchval');
  });
  it('should call ssoService on openExpressScripts', () => {
    const ssoSpy = spyOn(ssoService, 'openSSO');
    component.openExpressScripts();
    expect(ssoSpy).toHaveBeenCalled();
  });
  it('should isSidenavOpened to be defined and false', () => {
    component.closeSideNavigation();
    expect(component.isSidenavOpened).toBeDefined();
    expect(component.isSidenavOpened).toBeFalsy();
  });

  it('should sideNavStatus to be defined and out', () => {
    component.closeFilter();
    expect(component.sideNavStatus).toBeDefined();
    expect(component.sideNavStatus).toBe('out');
  });
  it('should isSidenavOpened to be defined and false on closeFilter', () => {
    component.closeFilter();
    expect(component.isSidenavOpened).toBeDefined();
    expect(component.isSidenavOpened).toBeFalsy();
  });
  it('should showClearLink to be defined and true on setShowClearLink', () => {
    component.setShowClearLink();
    expect(component.showClearLink).toBeDefined();
    expect(component.showClearLink).toBeTruthy();
  });

  it('should call onSelectionChange on onMemberSelectionChange', () => {
    const spy = spyOn(component, 'onSelectionChange');
    component.onMemberSelectionChange(null);
    expect(spy).toHaveBeenCalled();
  });
  it('should call onSelectionChange on onPharmacySelectionChange', () => {
    const spy = spyOn(component, 'onSelectionChange');
    component.onPharmacySelectionChange(null);
    expect(spy).toHaveBeenCalled();
  });
  it('should call removeItem on clearSessionStorageItems', () => {
    const spy = spyOn(sessionStorage, 'removeItem');
    component.clearSessionStorageItems();
    expect(spy).toHaveBeenCalled();
    expect(spy).toHaveBeenCalledWith('providerSelectedfilter');
    expect(spy).toHaveBeenCalledWith('visitTypeSelectedfilter');
    expect(spy).toHaveBeenCalledWith('claimStatusSelectedfilter');
    expect(spy).toHaveBeenCalledWith('dateSelectedFilter');
    expect(spy).toHaveBeenCalledWith('fromDate');
    expect(spy).toHaveBeenCalledWith('toDate');
    expect(spy).toHaveBeenCalledWith('sortSelectedFilter');
    expect(spy).toHaveBeenCalledWith('medicationSelectedUserId');
  });
  it('should make selectedDoctorList empty on clearFilterList', () => {
    component.clearFilterList();
    expect(component.selectedDoctorList).toBeDefined();
    expect(component.selectedDoctorList).toEqual([]);
  });

  it('should make dateSelectedFilter empty on clearFilterList', () => {
    component.clearFilterList();
    expect(component.dateSelectedFilter).toBeDefined();
    expect(component.dateSelectedFilter).toEqual('');
  });
  it('should make step empty on clearFilterList', () => {
    component.clearFilter();
    expect(component.step).toBeDefined();
    expect(component.step).toEqual([]);
  });
  it('should define dependant  on clearFilterList', () => {
    component.clearFilter();
    expect(component.dependant).toBeDefined();
  });
  it('should call setSortFiltervalue on clearFilter', () => {
    const spy = spyOn(component, 'setSortFiltervalue');
    component.clearFilter();
    expect(spy).toHaveBeenCalled();
  });
  it('should call ClearSearch on clearFilter', () => {
    const spy = spyOn(component, 'ClearSearch');
    component.clearFilter();
    expect(spy).toHaveBeenCalled();
  });
  it('should call closeFilter on clearFilter', () => {
    const spy = spyOn(component, 'closeFilter');
    component.clearFilter();
    expect(spy).toHaveBeenCalled();
  });
  it('should call clearFilterList on clearFilter', () => {
    const spy = spyOn(component, 'clearFilterList');
    component.clearFilter();
    expect(spy).toHaveBeenCalled();
  });
  it('should call clearSessionStorageItems on clearFilter', () => {
    const spy = spyOn(component, 'clearSessionStorageItems');
    component.clearFilter();
    expect(spy).toHaveBeenCalled();
  });
  it('should call setShowClearLink on clearFilter', () => {
    const spy = spyOn(component, 'setShowClearLink');
    component.clearFilter();
    expect(spy).toHaveBeenCalled();
  });
  it('should make showClose false on clearFilter', () => {
    component.clearFilter();
    expect(component.showClose).toBeFalsy();
  });
  it('should make showCalender false on clearFilter', () => {
    component.clearFilter();
    expect(component.showCalender).toBeFalsy();
  });
  it('should make showResultsCount false on clearFilter', () => {
    component.clearFilter();
    expect(component.showResultsCount).toBeFalsy();
  });
  it('should make isSortExpanded false on clearFilter', () => {
    component.clearFilter();
    expect(component.isSortExpanded).toBeFalsy();
  });
  it('should make isSelectedDateInvalid false on clearFilter', () => {
    component.clearFilter();
    expect(component.isSelectedDateInvalid).toBeFalsy();
  });
  it('should make isCustomDateRangeInValid false on clearFilter', () => {
    component.clearFilter();
    expect(component.isCustomDateRangeInValid).toBeFalsy();
  });
  it('should make showFilterCount false on clearFilter', () => {
    component.clearFilter();
    expect(component.showFilterCount).toBeFalsy();
  });
  it('should call clearSessionStorageItems on clearFilter', () => {
    const spy = spyOn(sessionStorage, 'setItem');
    component.clearFilter();
    expect(spy).toHaveBeenCalled();
    expect(spy).toHaveBeenCalledWith('medicationSelectedUserId', 'User');
  });
  it('should make isSortExpanded true on isSortOpened', () => {
    component.isSortOpened();
    expect(component.isSortExpanded).toBeTruthy();
  });

  // TEST FAILS AT TIMES
  it('should make isSortExpanded false on isSortClosed', () => {
    component.isSortClosed();
    expect(component.isSortExpanded).toBeFalsy();
  });
  it('should make medicationsMessage defined on claimsErrorMessage', () => {
    component.claimsErrorMessage();
    expect(component.medicationsMessage).toBeDefined();
    expect(component.medicationsMessage.length).toBeGreaterThan(0);
  });
  it('should make isDisplayMessage defined and true on claimsErrorMessage', () => {
    component.claimsErrorMessage();
    expect(component.isDisplayMessage).toBeDefined();
    expect(component.isDisplayMessage).toBeTruthy();
  });
  it('should call setCalendarMinimumDate on toggleCalender', () => {
    const spy = spyOn(component, 'setCalendarMinimumDate');
    component.toggleCalender('');
    expect(spy).toHaveBeenCalled();
  });
  it('should make showCalender true on toggleCalender', () => {
    component.toggleCalender('');
    expect(component.showCalender).toBeTruthy();
  });
  it('should make isCustomDateRangeInValid false on getSelectedValue', () => {
    component.getSelectedValue(null);
    expect(component.isCustomDateRangeInValid).toBeFalsy();
  });
  it('should make isSelectedDateInvalid false on getSelectedValue', () => {
    component.getSelectedValue(null);
    expect(component.isSelectedDateInvalid).toBeFalsy();
  });
  it('should call setCalendarMinimumDate on getSelectedValue', () => {
    const spy = spyOn(component, 'setCalendarMinimumDate');
    component.getSelectedValue(null);
    expect(spy).toHaveBeenCalled();
  });
  it('should call location back on goback', () => {
    const navigateSpy = spyOn(location, 'back');
    component.goBack();
    expect(navigateSpy).toHaveBeenCalled();
  });
});
