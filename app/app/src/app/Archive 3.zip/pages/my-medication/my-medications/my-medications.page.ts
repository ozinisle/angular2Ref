import { animate, state, style, transition, trigger } from '@angular/animations';
import { Location, TitleCasePipe } from '@angular/common';
import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatCalendar } from '@angular/material/datepicker';
import { MatSelectionList, MatSelectionListChange } from '@angular/material/list';
import { MatRadioGroup } from '@angular/material/radio';
import { MatSidenav } from '@angular/material/sidenav';
import { Router, RoutesRecognized } from '@angular/router';
import { DependentModel } from '@app/models/dependent.model';
import { FilterComponentConstants } from '@app/pages/fad/components/cost-breakdown-financialsfilter/filter.constants';
import { FilterOptionInterface } from '@app/pages/fad/components/cost-breakdown-financialsfilter/filter.model';
import { FilterInterface, FilterItemInterface, MyMedicationFilterInputInterface } from '@app/pages/my-medication/models/filter/filter-model.interface';
import { FilterItem, FilterOption, FILTER_ERROR_CONSTANTS, MyMedicationFilterInput } from '@app/pages/my-medication/models/filter/filter.model';
import { AlertService } from '@app/services/alert.service';
import { ConstantsService } from '@app/services/constants.service';
import { FilterService } from '@app/services/filter.service';
import { MedicationsService } from '@app/services/medications.service';
import { SwrveEventNames, SwrveService } from '@app/services/swrve.service';
import { SetLoader } from '@app/store/actions/app.actions';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { DependentSelectors } from '@app/store/selectors/dependent.selectors';
import { GlobalUtils } from '@app/utils/global.utils';
import { environment } from '@environments/environment';
import { ModalController, PopoverController } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Select, Store } from '@ngxs/store';
import { cloneDeep } from 'lodash-es';
import { differenceInCalendarDays, format, isValid, differenceInMilliseconds } from 'date-fns';
import { forkJoin, Observable, Subject, Subscription } from 'rxjs';
import { filter, pairwise, takeUntil } from 'rxjs/operators';
import { ProfileModalComponent } from '../../my-pillpack/profile-modal/profile-modal.component';
import { SsoService } from '../../sso/sso.service';
import { DependentRecentRxResponseModel } from '../models/dependant-recent-rx.model';
import { DependentRecentRxResponseModelInterface } from '../models/interfaces/dependant-recent-rx-model.interface';
import { GetMemBasicInfoResponseModelInterface } from '../models/interfaces/get-member-basic-info-model.interface';
import { RadioListInterface, RxSummaryInterface } from '../models/interfaces/my-medications-generic-models.interface';
import { RxDetailsRequestModelInterface } from '../models/interfaces/rx-details-model.interface';
import { RadioList } from '../models/my-medications-generic.models';
import { RxDetailsRequestModel } from '../models/rx-details.model';
import { MyMedicationDetailsService } from '../my-medication-details/my-medication-details.service';
import { MyMedicationFilterComponent } from '../my-medication-filter/my-medication-filter.component';
import { MemberPlan } from '@app/models/member-plan.model';
import { BreadCrumb } from '@app/components/breadcrumbs/breadcrumbs';

@Component({
  selector: 'app-my-medications',
  templateUrl: './my-medications.page.html',
  styleUrls: ['./my-medications.page.scss'],
  animations: [
    trigger('slideInOut', [
      state(
        'in',
        style({
          transform: 'translate3d(0,0,0)'
        })
      ),
      state(
        'out',
        style({
          transform: 'translate3d(-100%,0,0)',
          display: 'none'
        })
      ),
      transition('in => out', animate('100ms ease-in-out')),
      transition('out => in', animate('100ms ease-in-out'))
    ])
  ]
})
export class MyMedicationsPage implements OnInit, OnDestroy {
  @SelectSnapshot(DependentSelectors.getDependentsList) dependentsList: DependentModel[];
  @SelectSnapshot(AppSelectors.getUserType) userType: string;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @Select(AppSelectors.getPostLoginInfo) postLoginInfo: any;
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;
  @Select(AppSelectors.getSelectedPlan) selectedPlan$: Observable<MemberPlan>;
  @SelectSnapshot(AppSelectors.getPlansList) memberPlans: MemberPlan[];



  userString: 'User' = 'User';
  dependant: string;
  public breadCrumbs: BreadCrumb[];
  basicMemInfo: GetMemBasicInfoResponseModelInterface;
  medications: DependentRecentRxResponseModelInterface = new DependentRecentRxResponseModel();
  filteredMedications: DependentRecentRxResponseModelInterface = new DependentRecentRxResponseModel();
  private allMedications: DependentRecentRxResponseModelInterface = new DependentRecentRxResponseModel();
  sideNavStatus: string;
  noMedicationsAvailable = false;
  dateList = [];
  showClose: boolean;
  showCalender: boolean;
  bHasDependents = false;
  fpoTargetUrl = environment.drupalUrl + '/page/mymedications-nomedications';
  fpoPillPackPromoTargetUrl = environment.drupalUrl + '/page/pillpack-mymedications-defaultscreen';

  fpoTargetUrlMedicare = environment.drupalUrl + '/page/medicare-options-formulary';
  fpoTargetUrlMedex = environment.drupalUrl + '/page/medicare-options-formulary';
  layout = 'central';
  // Fix for MWIT-522
  sortList: RadioListInterface[] = [
    new RadioList().setValue('Most Recent').setChecked(true),
    new RadioList().setValue('A to Z').setChecked(false),
    new RadioList().setValue('Z to A').setChecked(false)
  ];
  sortSelectedFilter: string;
  searchval: string;
  isautosearch: boolean;
  isDisplayMessage: boolean;
  medicationsMessage: string;
  issearchShowing: boolean;

  // Filter options
  dateSelectedFilter: string;
  showDate: boolean;
  fromMinDate: Date;
  calendarMaxDate = new Date();
  currentSelectedDate: Date = null;
  isCustomDateRangeInValid = false;
  isSelectedDateInvalid = false;
  sideNavMode: string;

  fromDate: any;
  toDate: string = format(new Date(), 'P');

  index: number;
  isSidenavOpened: boolean;
  errorMessage: string;
  collapsedHeight: string;
  collapsedSortHeight: string;
  expandedHeight: string;
  expandedSortHeight: string;
  isSortExpanded: boolean;

  isFormDateSelected = true;
  dateFormat = 'MM/dd/yyyy';
  prescribingDoctorList = [];
  selectedDoctorList: string[] = [];
  pharmacyList = [];
  membersList = [];
  selectedPharmacyList: string[] = [];
  memberSelectedFilter = [];
  allPharmaciesString = 'All Pharmacies';
  allDoctorsString = 'All Prescribing Doctors';
  allMembersString = 'All Members';
  selectedSortString: string;

  showClearLink = false;
  showResultsCount = false;
  searchString: string;
  step = [];
  medsInfo: DependentRecentRxResponseModelInterface[] = [];
  isInActiveUser = false;
  showFilterCount = false;
  resolverSubscription: Subscription;
  dataReturned = '';

  isCPDPPromotion = true;
  isCPDPEnrolled = false;
  isCPDPHandedoff = false;
  isPillPackEnrolledThisSession = false;
  filterConfig: FilterInterface;
  filterConfigZeroState: FilterInterface;
  tempDoctorList: any;
  isFilterDirty = false;
  private oSortingFilterItem;
  public hasESIAccountInfoFlag = false;
  public isMedicareUser = false;
  public isMedexUser = false;
  private unsubscribeHelper$: Subject<void> = new Subject<void>();
  ismobile: boolean;
  filterDataInfo: any;
  loadFilter = false;

  @ViewChild('searchDrpContainer') searchDrpContainer;
  @ViewChild('sideNavContainer') elementView: ElementRef;
  @ViewChild('filterWidth') filterElementView: ElementRef;
  @ViewChild('searchInput') searchInput;
  @ViewChild('sidenav') sideNav: MatSidenav;
  @ViewChild('dependantFilter') dependantFilterComponent: MatRadioGroup;
  @ViewChild('matcalender') picker: MatCalendar<Date>;
  @ViewChild('fromDateInput') fromInputDate: ElementRef;
  @ViewChild('toDateInput') toInputDate: ElementRef;
  @ViewChild('searchInput') inputSearch: ElementRef;
  defaultPlan: boolean;
  previousUrl: string;

  constructor(
    private medicationsService: MedicationsService,
    private router: Router,
    public filterService: FilterService,
    public constants: ConstantsService,
    private title: TitleCasePipe,
    private myMedicationsDetailsService: MyMedicationDetailsService,
    private alertService: AlertService,
    private swrveService: SwrveService,
    private ssoService: SsoService,
    private swrveEventNames: SwrveEventNames,
    public modalController: ModalController,
    private store: Store,
    private location: Location,
    private popoverController: PopoverController,
    private resizeService: GlobalUtils
  ) {}

  async openModal(link: string, modelId: string) {
    const modal = await this.modalController.create({
      component: ProfileModalComponent,
      componentProps: {
        modelId: modelId,
        link: link
      }
    });

    modal.onDidDismiss().then(dataReturned => {
      if (dataReturned !== null) {
        this.dataReturned = dataReturned.data;
      }
    });
    return await modal.present();
  }

  ionViewDidEnter() {
    if(this.medicationsService.getPreviousUrl() === '/home' || this.medicationsService.getPreviousUrl() === '/brand-my-medication') {
      this.previousUrl = this.medicationsService.getPreviousUrl();
    }
    this.selectedPlan$.subscribe((data) => {
      this.defaultPlan = data?.activePlan === 'true' ? true : false;
    })
    //Commenting as part of IPA defect DOAIP-6853
    // this.noMedicationsAvailable = true;
    this.store.dispatch(new SetLoader(true));
    const observers: Array<Observable<any>> = []
    observers.push(this.medicationsService.getMemBasicInfo());
    observers.push(this.medicationsService.getMedications());
    this.dependentsList?.forEach(dependant => {
      observers.push(this.medicationsService.getDependentMedications(dependant));
    });
    forkJoin(observers).subscribe(
      (response: any) => {
        // TODO: Figure out how to tie dependents into this
        this.store.dispatch(new SetLoader(false));
        this.basicMemInfo = cloneDeep(response[0]);
        this.medsInfo = response.slice(1);
        if (this.basicMemInfo.rxSummary) {
          this.basicMemInfo.rxSummary.filterName = this.basicMemInfo.rxSummary.memMiddleInitial
            ? [
                this.title.transform(this.basicMemInfo.rxSummary.memFirstName),
                ' ',
                this.title.transform(this.basicMemInfo.rxSummary.memMiddleInitial),
                ' ',
                this.title.transform(this.basicMemInfo.rxSummary.memLastName)
              ].join('')
            : [
                this.title.transform(this.basicMemInfo.rxSummary.memFirstName),
                ' ',
                this.title.transform(this.basicMemInfo.rxSummary.memLastName)
              ].join('');
        }
        this.medicationsService.setBasicMemInfo(this.basicMemInfo);

        this.sortSelectedFilter = 'Most Recent';
        this.isautosearch = false;
        this.isDisplayMessage = false;
        this.issearchShowing = false;
        this.showDate = false;
        this.sideNavMode = 'side';
        this.index = -1;
        this.errorMessage = null;
        this.collapsedHeight = '32px';
        this.collapsedSortHeight = '48px';
        this.expandedHeight = '40px';
        this.expandedSortHeight = '48px';
        this.isSortExpanded = false;
        this.showCalender = false;
        this.searchString = '';
        this.sideNavStatus = 'out';

        this.dependant = this.userString;
        this.membersList = this.getMembersList();
        this.sortSelectedFilter = 'Most Recent';

        this.initializeFiltersState();

        let medications: DependentRecentRxResponseModelInterface;
        if (this.medsInfo && this.medsInfo[0] !== undefined && this.medsInfo[0].rxSummary) {
          this.medsInfo[0].rxSummary = this.medsInfo[0].rxSummary.map(med => {
            const stampedMed: any = Object.assign({ currUser: true }, med);
            return stampedMed;
          });
          medications = this.medsInfo.reduce((prev: DependentRecentRxResponseModelInterface, curr: DependentRecentRxResponseModelInterface) => {
              if (curr.rxSummary && prev.rxSummary) {
                curr.rxSummary = curr.rxSummary.concat(prev.rxSummary);
              }
              return curr;
            },
            new DependentRecentRxResponseModel()
          );
        }
        var currUser;
        // for(var i=0; i < medications.rxSummary.length; i++){
        //   currUser = medications.rxSummary[i].currUser;
        // }

        medications.rxSummary.filter((el)=>currUser=el.currUser);
        if (medications && medications.rxSummary && medications.rxSummary.length > 0) {
          if(currUser){
            this.noMedicationsAvailable = false;
            this.handleMedicationsResponse(medications, false);
          }else{
            this.noMedicationsAvailable = true;
          }
        }else{
          this.noMedicationsAvailable = true;
        }

        this.clearSessionStorageItems();
        this.clearSessionItems();
        this.setInActiveUserFlag();

        const filterStateStr = sessionStorage.getItem('med_filterState');
        const filterState = JSON.parse(filterStateStr);
        if (filterState) {
          sessionStorage.setItem('medicationSelectedUserId', filterState.dependant);
        } else {
          sessionStorage.setItem('medicationSelectedUserId', 'User');
        }
        this.applyUserFilter();
        this.updateFilterConfig();
        this.applyDefaultSorting();
        if (!this.ismobile) {
          this.filterDataInfo = this.filterInfo();
          this.loadFilter = true;
        }
      },
      error => this.store.dispatch(new SetLoader(false))
    );
  }

  navigateToPillPack() {
    this.router.navigate(['/my-pillpack/landing'], { queryParams: { icid: 'PillPack Global' } });
  }

  openPillPackSite() {
    sessionStorage.setItem('consentLink', 'https://www.pillpack.com');
    this.openModal('https://www.pillpack.com', 'openPillPackSite');
  }

  ngOnInit() {
    this.breadCrumbs = [];
    this.breadCrumbs.push(
      {
      label: 'Home',
      url: ['/home']
    });

    this.breadCrumbs.push({
      label: 'My Medications',
      url: ['/my-medications']
    });
    this.swrveService.sendAppMessage(this.swrveEventNames.appScreenMyMedications);

    if (sessionStorage.getItem('isCompleteHanddoff') != null && sessionStorage.getItem('isCompleteHanddoff') !== '') {
      this.isPillPackEnrolledThisSession = JSON.parse(sessionStorage.getItem('isCompleteHanddoff'));
    } else {
      this.isPillPackEnrolledThisSession = false;
    }

    this.postLoginInfo.subscribe((data) => {
      if (data) {
        this.isCPDPPromotion = data.isCPDPPromotion;
        this.isCPDPEnrolled = data.isCPDPEnrolled;
        this.isCPDPHandedoff = data.isCPDPHandedoff;
      }
      if (this.userType && this.userType.toLowerCase() === 'medicare') {
        this.isMedicareUser = true;
      }
      if (this.userType && this.userType.toLowerCase() === 'medex') {
        this.isMedexUser = true;
      }
      if(this.userType && this.userType.toLowerCase() === 'member'){
        this.isMedicareUser = false;
      }
    });


    const cachedMyAccountInfo = sessionStorage.getItem('myAccountInfo');

    if (cachedMyAccountInfo) {
      const myAccountInfo = JSON.parse(cachedMyAccountInfo);
      if (myAccountInfo && myAccountInfo[0] && myAccountInfo[0].accountinforesponse && myAccountInfo[0].accountinforesponse[0]) {
        const esiAccountInfoResponse = myAccountInfo[0].accountinforesponse[0].esi;

        this.hasESIAccountInfoFlag =
          esiAccountInfoResponse.hasESI === 'true' ||
          esiAccountInfoResponse.hasESIMedex === 'true' ||
          esiAccountInfoResponse.hasESI === 'True' ||
          esiAccountInfoResponse.hasESIMedex === 'True';
      }
    }
    this.hasESIAccountInfoFlag = false;

    if (this.userType && this.userType.toLowerCase() === 'medicare') {
      this.isMedicareUser = true;
    }
    if (this.userType && this.userType.toLowerCase() === 'medex') {
      this.isMedexUser = true;
    }
    this.resizeService.getIsMobile().pipe(takeUntil(this.unsubscribeHelper$))
    .subscribe((isMobile: boolean) => this.ismobile = isMobile );
  }

  setInActiveUserFlag() {
    const authDetails = this.authToken;
    if (authDetails && authDetails.HasActivePlan && authDetails.HasActivePlan === 'false') {
      this.isInActiveUser = true;
    }
  }

  ngOnDestroy() {
    this.alertService.clearError();
    sessionStorage.removeItem('medicationSelectedUserId');
    if (this.resolverSubscription) {
      this.resolverSubscription.unsubscribe();
    }
    this.unsubscribeHelper$.next();
    this.unsubscribeHelper$.complete();
  }

  initializeFiltersState() {
    const filterStateStr = sessionStorage.getItem('med_filterState');
    const filterState = JSON.parse(filterStateStr);
    if (filterState) {
      this.selectedDoctorList = filterState.selectedDoctorList;
      this.selectedPharmacyList = filterState.selectedPharmacyList;
      this.dateSelectedFilter = filterState.dateSelectedFilter;
      this.toDate = filterState.toDate;
      this.fromDate = filterState.fromDate;
      this.searchval = filterState.searchval;
      this.sortSelectedFilter = filterState.sortSelectedFilter;
      this.dependant = filterState.dependant;
      this.membersList = this.getMembersList();
      if (this.searchval) {
        this.issearchShowing = true;
      }
    }
    this.router.events
      .pipe(
        filter(e => e instanceof RoutesRecognized),
        pairwise()
      )
      .subscribe((event: any[]) => {
        if (!(event[0].urlAfterRedirects === '/my-medications/medicationdetails' || event[0].urlAfterRedirects === '/my-medications')) {
          sessionStorage.removeItem('med_filterState');
        }
      });
  }

  ClearSearch(value: boolean = true) {
    this.issearchShowing = false;
    this.searchval = '';
    this.isDisplayMessage = false;
    this.isautosearch = false;
    sessionStorage.removeItem('searchval');
  }

  search(event, data: any, doctorList: MatSelectionList, pharmacyList: MatSelectionList) {
    this.issearchShowing = true;
    this.index = 0;
    this.isDisplayMessage = false;
    this.isautosearch = false;

    const val = data.value === undefined ? data : data.value;
    if (val.length > 0) {
      sessionStorage.setItem('searchval', val);
    } else {
      this.isautosearch = false;
      this.issearchShowing = false;
    }
    this.searchString = val;
    this.applyFilter(doctorList, pharmacyList);
    this.claimsErrorMessage();
  }

  // filter Logic below
  toggleFilter(toggleStatus) {
    this.isSidenavOpened = !this.isSidenavOpened;
    this.sideNavStatus = this.sideNavStatus === 'out' ? 'in' : 'out';
    if (toggleStatus) {
      this.sideNavStatus = toggleStatus;
    }

    if (window.innerWidth <= 992) {
      this.sideNavMode = 'over';
    } else {
      this.sideNavMode = 'side';
    }
  }

  closeSideNavigation() {
    this.isSidenavOpened = false;
  }

  getSelectedItems(list: MatSelectionList) {
    if (list && list.selectedOptions.selected.length > 0) {
      return list.selectedOptions.selected.map(selectedItem => selectedItem.value);
    }
    return null;
  }

  closeFilter() {
    this.sideNavStatus = 'out';
    this.isSidenavOpened = false;
  }

  setShowClearLink() {
    this.showClearLink = false;
    if (this.dependant !== this.userString) {
      this.showClearLink = true;
    } else {
      if (
        this.searchval ||
        this.sortSelectedFilter !== 'Most Recent' ||
        this.filteredMedications.rxSummary.length !==
          this.medications.rxSummary.filter(medication => {
            const bufferMedication: any = Object.assign({}, medication);
            return bufferMedication.currUser ? bufferMedication.currUser : !medication.uniquePersonId;
          }).length
      ) {
        this.showClearLink = true;
      }
    }
  }

  applyFilter(doctorList: MatSelectionList, pharmacyList: MatSelectionList) {
    this.filterService.scrollToTop();
    this.closeFilter();
    this.closeSideNavigation();

    this.selectedDoctorList = this.getSelectedItems(doctorList);
    this.selectedPharmacyList = this.getSelectedItems(pharmacyList);
    sessionStorage.setItem('sortSelectedFilter', this.sortSelectedFilter);
    if (this.checkIfIsDependentIsChanged()) {
      this.clearFilterList();
      this.handleMedicationsResponse(this.allMedications, true);
    } else {
      this.showResultsCount = true;
      this.filterData();
      this.applySorting();
    }
    this.setShowClearLink();
    this.isautosearch = false;
    this.showCalender = false;
    this.showFilterCount = this.isFilterApplied();
  }

  applyUserFilter() {
    const selectedMembers: string[] = [];
    if (this.filterConfig && this.filterConfig.items) {
        const memberFilter = this.filterConfig.items.find(item => item.headerText === "Member");
        if (memberFilter && memberFilter.list) {
          memberFilter.list.map((listItem) => {
            if (listItem.selected) {
              selectedMembers.push(listItem.name);
            }
            return listItem;
          });
        }
    }

    if (this.dependant) {
      selectedMembers.push(this.dependant);
    }
    const selectedMembersStr: string = selectedMembers.join('~');
    if (selectedMembersStr && selectedMembersStr.indexOf('All Members') === -1) {
      this.medications.rxSummary = this.allMedications.rxSummary.filter(medication => {
        const bufferMedication: any = Object.assign({}, medication);
        return (
          (selectedMembersStr.includes(this.userString) && bufferMedication.currUser) ||
          (bufferMedication.dependentId && selectedMembersStr.includes(bufferMedication.dependentId.toString()))
        );
      });
      this.tempDoctorList = JSON.parse(JSON.stringify(this.prescribingDoctorList));
    } else {
      this.medications.rxSummary = this.allMedications.rxSummary.map(medication => {
        return { ...medication };
      });
    }
  }

  getDependantMedicationCount(dependentId: number | 'User') {
    return dependentId === this.userString
      ? this.allMedications.rxSummary.filter(medication => {
          const bufferMedication: any = Object.assign({}, medication);
          return bufferMedication.currUser;
        }).length
      : this.allMedications.rxSummary.filter(medication => {
          const bufferMedication: any = Object.assign({}, medication);
          return bufferMedication.dependentId === dependentId;
        }).length;
  }

  applyDoctorsFilter() {
    if (this.selectedDoctorList && this.selectedDoctorList.length && this.filteredMedications) {
      this.filteredMedications.rxSummary = this.filteredMedications.rxSummary.filter(medication => {
        return this.selectedDoctorList.includes(medication.prescribingDoctor);
      });
    }
  }

  applyPharmacyFilter() {
    if (this.selectedPharmacyList && this.selectedPharmacyList.length && this.filteredMedications) {
      this.filteredMedications.rxSummary = this.filteredMedications.rxSummary.filter(medication => {
        return this.selectedPharmacyList.includes(medication.pharmacy.name);
      });
    }
  }

  applyCustomRangeDateFilter() {
    if (this.toDate && this.fromDate) {
      const toDate = new Date(this.toDate);
      const fromDate = new Date(this.fromDate);
      if (isValid(toDate) && isValid(fromDate)) {
        this.filteredMedications.rxSummary = this.filteredMedications.rxSummary.filter(medication => {
          const medicationDate = new Date(medication.rxIncurredDate);

          return differenceInMilliseconds(medicationDate, toDate) <= 0 && differenceInMilliseconds(medicationDate, fromDate) >= 0;
        });
      } else {
        this.filteredMedications.rxSummary = [];
      }
    }
  }

  applyDateFilter() {
    if (this.dateSelectedFilter && this.dateSelectedFilter !== 'All') {
      if (this.dateSelectedFilter === 'Custom') {
        this.applyCustomRangeDateFilter();
      } else if (this.dateSelectedFilter !== 'Year') {
        this.filteredMedications.rxSummary = this.filteredMedications.rxSummary.filter(medication => {
          return differenceInCalendarDays(new Date(), new Date(medication.rxIncurredDate)) <= +this.dateSelectedFilter;
        });
      } else {
        this.filteredMedications.rxSummary = this.filteredMedications.rxSummary.filter(medication => {
          // a.diff(b, 'years', true) returns decimal value
          return (differenceInCalendarDays(new Date(), new Date(medication.rxIncurredDate)) / 365) <= 1;
        });
      }
    }
  }

  checkIfIsDependentIsChanged() {
    const previousSelectedDependent = sessionStorage.getItem('medicationSelectedUserId');
    if (this.dependant && this.dependant.toString() !== previousSelectedDependent) {
      sessionStorage.setItem('medicationSelectedUserId', this.dependant.toString());
      return true;
    } else {
      return false;
    }
  }

  getMembersList() {
    const membersListItems = [];
    membersListItems.push({
      selected: this.dependant && (this.dependant.includes(this.userString) || this.dependant === 'All Members'),
      count: this.getDependantMedicationCount(this.userString),
      name: this.userString,
      value: this.basicMemInfo?.rxSummary?.filterName?.toUpperCase(),
      disabled: this.dependant === 'All Members'
    });

    if (this.dependentsList) {
      this.dependentsList.forEach(user => {
        membersListItems.push({
          selected: this.dependant.includes(user.depId.toString()) || this.dependant === 'All',
          count: this.getDependantMedicationCount(user.depId),
          name: user.depId.toString(),
          value: user.middleInitial
            ? [user.firstName, ' ', user.middleInitial, ' ', user.lastName].join('').toUpperCase()
            : [user.firstName, ' ', user.lastName].join('').toUpperCase(),
          disabled: this.dependant === 'All'
        });
      });
    }

    membersListItems.push({
      value: 'All Members',
      selected: this.dependant === 'All Members',
      count: this.allMedications.rxSummary.length,
      name: 'All Members',
      disabled: false
    });

    return membersListItems;
  }

  getListItems(property: string, list, selectAllOptionIdentifier: string, secondaryProperty: string = '') {
    const itemsCount = {};
    for (const listItem of list) {
      const propertyValue = secondaryProperty ? listItem[property][secondaryProperty] : listItem[property];
      itemsCount[propertyValue] = itemsCount[propertyValue] ? itemsCount[propertyValue] + 1 : 1;
    }
    const listItems = [];
    for (const key of Object.keys(itemsCount)) {
      listItems.push({
        value: key,
        selected: false,
        count: itemsCount[key]
      });
    }
    if (listItems && listItems.length > 1) {
      listItems.push({
        value: selectAllOptionIdentifier,
        selected: false,
        count: list.length
      });
    }
    return listItems;
  }

  onSelectionChange(selectionListChange: MatSelectionListChange, selectAllOptionIdentifier: string, selectedList) {
    const changeEvent = selectionListChange.option;
    if (changeEvent && changeEvent.value === selectAllOptionIdentifier) {
      this.selectAllOptions(selectedList, changeEvent.selected, selectAllOptionIdentifier);
    } else {
      const selectedOption = selectedList.find(listItem => changeEvent && listItem.value === changeEvent.value);
      if (selectedOption) {
        selectedOption.selected = changeEvent.selected;
      }
      if (changeEvent.selected) {
        // when the user wants to check all option if he selects all the other list items
        if (changeEvent.selectionList.selectedOptions.selected.length === selectedList.length - 1) {
          this.checkSelectAllOptionIfAllSelected(selectedList, selectAllOptionIdentifier);
        }
      } else {
        this.unCheckSelectAllOption(selectedList, selectAllOptionIdentifier);
      }
    }
  }

  onDoctorSelectionChange(selectionListChange: MatSelectionListChange) {
    this.onSelectionChange(selectionListChange, this.allDoctorsString, this.prescribingDoctorList);
  }

  onMemberSelectionChange(selectionListChange: MatSelectionListChange) {
    this.onSelectionChange(selectionListChange, 'All', this.membersList);
  }

  onPharmacySelectionChange(selectionListChange: MatSelectionListChange) {
    this.onSelectionChange(selectionListChange, this.allPharmaciesString, this.pharmacyList);
  }

  checkSelectAllOptionIfAllSelected(list, selectedAllOptionIdentifier: string) {
    const selectedAllOption = list.find(listItem => listItem.value === selectedAllOptionIdentifier);
    if (selectedAllOption && !selectedAllOption.selected) {
      selectedAllOption.selected = true;
    }
    return list;
  }

  unCheckSelectAllOption(list, selectedAllOptionIdentifier: string) {
    const selectedAllOption = list.find(listItem => listItem.value === selectedAllOptionIdentifier);
    if (selectedAllOption && selectedAllOption.selected) {
      selectedAllOption.selected = false;
    }
    return list;
  }

  selectAllOptions(list, selectedValue: boolean, selectAllOptionIdentifier: string) {
    return list.map(listItem => {
      listItem.selected = selectedValue;
      if (selectedValue) {
        listItem.selected = true;
        listItem.disabled = listItem.value !== selectAllOptionIdentifier;
      } else {
        listItem.selected = false;
        listItem.disabled = false;
      }

      return listItem;
    });
  }

  getDateCount(listOfDatesDiffInDays, dateSpan) {
    if (listOfDatesDiffInDays) {
      const filterList = listOfDatesDiffInDays.filter(item => item <= dateSpan);
      return filterList ? filterList.length : 0;
    }
    return 0;
  }
  private getDateCountNew(property: string, year?: boolean): Array<any> {
    if (year) {
      // a.diff(b, 'years', true) returns decimal value
      return this.medications.rxSummary.map((visit: RxSummaryInterface) => (differenceInCalendarDays(new Date(), new Date(visit[property])) / 365));
    } else {
      return this.medications.rxSummary.map((visit: RxSummaryInterface) => differenceInCalendarDays(new Date(), new Date(visit[property])));
    }
  }

  getDateListItems(property: string) {
    const listOfDatesDiffInDays: number[] = this.medications.rxSummary.map(medication =>
      differenceInCalendarDays(new Date(), new Date(medication[property])));
    const listOfDatesDiffInYears: number[] = this.medications.rxSummary.map(medication =>
      (differenceInCalendarDays(new Date(), new Date(medication[property])) / 365)
    );
    this.dateList = [
      {
        label: 'Last 30 days',
        value: 30,
        checked: false,
        count: this.getDateCount(listOfDatesDiffInDays, 30)
      },
      {
        label: 'Last 60 days',
        value: 60,
        checked: false,
        count: this.getDateCount(listOfDatesDiffInDays, 60)
      },
      {
        label: 'Last 90 days',
        value: 90,
        checked: false,
        count: this.getDateCount(listOfDatesDiffInDays, 90)
      },
      {
        label: 'Year-to-date',
        value: 'Year',
        checked: false,
        count: this.getDateCount(listOfDatesDiffInYears, 1)
      },
      {
        label: 'All dates',
        value: 'All',
        checked: false,
        count: listOfDatesDiffInDays.length
      },
      {
        label: 'Custom Date Range',
        value: 'Custom',
        checked: false,
        count: ''
      }
    ];
    return this.dateList;
  }

  setFilterData() {
    if (this.prescribingDoctorList && this.selectedDoctorList) {
      this.prescribingDoctorList.map(item => {
        item.selected = this.selectedDoctorList.includes(this.allDoctorsString) || this.selectedDoctorList.includes(item.value);
        return item;
      });
    }
    if (this.pharmacyList && this.selectedPharmacyList) {
      this.pharmacyList.map(item => {
        item.selected = this.selectedPharmacyList.includes(this.allPharmaciesString) || this.selectedPharmacyList.includes(item.value);
        return item;
      });
    }
    if (this.dateList && this.dateSelectedFilter) {
      for (let i = 0; i < this.dateList.length; i++) {
        if (this.dateList[i].value === this.dateSelectedFilter) {
          this.dateList[i].checked = true;
        }
      }
    }
  }

  handleMedicationsResponse(medications: DependentRecentRxResponseModelInterface, applyFilter: boolean = true) {
    this.allMedications = medications;
    if (this.dependentsList == null) {
      this.bHasDependents = this.allMedications.rxSummary.length !== 1;
    } else {
      this.bHasDependents = true;
    }
    this.applyUserFilter();
    this.prescribingDoctorList = this.getListItems('prescribingDoctor', this.medications.rxSummary, this.allDoctorsString);
    this.pharmacyList = this.getListItems('pharmacy', this.medications.rxSummary, this.allPharmaciesString, 'name');
    this.membersList = (applyFilter === true) ?
        this.getListItems('fullName', this.medications.rxSummary, this.allMembersString) :
        this.getMembersList();
    this.dateList = this.getDateListItems('rxIncurredDate');
    this.setFilterData();
    if (applyFilter) {
      this.filterData();
    } else {
      this.filteredMedications.rxSummary = this.medications.rxSummary;
    }
    this.applySorting();
    this.setShowClearLink();
    this.showFilterCount = this.isFilterApplied();
  }

  filterData() {
    this.filteredMedications.rxSummary = this.medications.rxSummary;
    if (this.searchval) {
      this.filteredMedications.rxSummary = this.medications.rxSummary.filter(
        medication =>
          (medication.genericName &&
            medication.genericName
              .toString()
              .toLowerCase()
              .includes(this.searchval.toString().toLowerCase())) ||
          (medication.prescribingDoctor &&
            medication.prescribingDoctor
              .toString()
              .toLowerCase()
              .includes(this.searchval.toString().toLowerCase())) ||
          (medication.genericName && medication.genericName.toLowerCase().includes(this.searchval.toString().toLowerCase()))
      );
    }

    this.applyDoctorsFilter();
    this.applyPharmacyFilter();
    this.applyDateFilter();

    this.isDisplayMessage = !this.filteredMedications || this.filteredMedications.rxSummary.length === 0;
  }

  setSortFiltervalue(sortValue: string = 'Most Recent') {
    for (let i = 0; i < this.sortList.length; i++) {
      if (this.sortList[i].value === sortValue) {
        this.sortSelectedFilter = sortValue;
        sessionStorage.setItem('sortSelectedFilter', this.sortSelectedFilter);
        this.sortList[i].checked = true;
      } else {
        this.sortList[i].checked = false;
      }
    }
  }

  clearSessionStorageItems() {
    sessionStorage.removeItem('providerSelectedfilter');
    sessionStorage.removeItem('visitTypeSelectedfilter');
    sessionStorage.removeItem('claimStatusSelectedfilter');
    sessionStorage.removeItem('dateSelectedFilter');
    sessionStorage.removeItem('fromDate');
    sessionStorage.removeItem('toDate');
    sessionStorage.removeItem('sortSelectedFilter');
    if (sessionStorage.getItem('medicationSelectedUserId') !== 'User') {
      sessionStorage.removeItem('medicationSelectedUserId');
    }
  }

  clearFilterList() {
    this.selectedDoctorList = [];
    this.selectedPharmacyList = [];
    this.dateList = [];
    this.dateSelectedFilter = '';
    this.memberSelectedFilter = [];
  }

  clearFilter() {
    this.step = [];
    this.dependant = this.userString;
    this.setSortFiltervalue();
    this.ClearSearch();
    this.closeFilter();
    this.clearFilterList();
    this.handleMedicationsResponse(this.allMedications, true);
    this.clearSessionStorageItems();
    this.setShowClearLink();
    this.showClose = false;
    this.showCalender = false;
    this.showResultsCount = false;
    this.isSortExpanded = false;
    this.isSelectedDateInvalid = false;
    this.isCustomDateRangeInValid = false;
    this.showFilterCount = false;
    sessionStorage.setItem('medicationSelectedUserId', 'User');
    this.filterService.scrollToTop();
    this.filterConfig = cloneDeep(this.filterConfigZeroState);
  }

  isFilterApplied(): boolean {
    return !!(
      (this.selectedDoctorList && this.selectedDoctorList.length > 0) ||
      (this.selectedPharmacyList && this.selectedPharmacyList.length > 0) ||
      this.dateSelectedFilter ||
      this.memberSelectedFilter.length > 0
    );
  }

  isSortOpened() {
    this.isSortExpanded = true;
  }

  isSortClosed() {
    this.isSortExpanded = false;
  }

  isOpened(value) {
    switch (value) {
      case 1:
        this.step[1] = 1;
        break;
      case 2:
        this.step[2] = 2;
        break;
      case 3:
        this.step[3] = 3;
        break;
      case 4:
        this.step[4] = 4;
        break;
    }
  }

  sortFilterChanged(selectedOption) {
    for (let i = 0; i < this.sortList.length; i++) {
      if (this.sortList[i].value === selectedOption.value) {
        this.sortList[i].checked = false;
        this.sortSelectedFilter = selectedOption.value;
      } else {
        this.sortList[i].checked = false;
      }
    }

    const sortFilterItem = this.sortList.find(item => item.value === this.sortSelectedFilter);
    if (sortFilterItem) {
      sortFilterItem.checked = true;
    }
  }

  applySorting() {
    const selectedSortFilter = this.sortSelectedFilter;
    if (!selectedSortFilter || selectedSortFilter === 'Most Recent') {
      this.filteredMedications.rxSummary = this.filteredMedications.rxSummary.sort(
        (item1, item2) =>
        differenceInCalendarDays(new Date(item1.rxIncurredDate), new Date(item2.rxIncurredDate)) ||
        this.compareStringField(item1.genericName, item2.genericName)
      );
      this.filteredMedications.rxSummary = this.filteredMedications.rxSummary.reverse();
    } else if (selectedSortFilter === 'A to Z') {
      this.filteredMedications.rxSummary = this.filteredMedications.rxSummary.sort(
        (item1, item2) =>
          this.compareStringField(item2.genericName, item1.genericName) ||
          differenceInCalendarDays(new Date(item2.rxIncurredDate), new Date(item1.rxIncurredDate))
      );
    } else if (selectedSortFilter === 'Z to A') {
      this.filteredMedications.rxSummary = this.filteredMedications.rxSummary.sort(
        (item1, item2) =>
          this.compareStringField(item1.genericName, item2.genericName) ||
          differenceInCalendarDays(new Date(item2.rxIncurredDate), new Date(item1.rxIncurredDate))
      );
    }

    this.selectedSortString = selectedSortFilter ? selectedSortFilter : 'Most Recent';
  }

  compareStringField(value1: string, value2: string) {
    if (value1 === value2) {
      return 0;
    }
    return value1 > value2 ? -1 : 1;
  }

  claimsErrorMessage() {
    if (this.filteredMedications.rxSummary.length === 0) {
      this.medicationsMessage = 'For further inquiries, please contact member services';
      this.isDisplayMessage = true;
    }
  }

  showMedicationDetails(medication: RxSummaryInterface) {
    const medicationDetailReq: RxDetailsRequestModelInterface = new RxDetailsRequestModel();
    medicationDetailReq.useridin = this.useridin;
    medicationDetailReq.rxIncurredDate = medication.rxIncurredDate;
    medicationDetailReq.ndcCd = medication.ndcCd;
    if (medication.dependentId) {
      medicationDetailReq.dependentId = medication.dependentId;
    }

    this.myMedicationsDetailsService.setMyMedicationDetailsRequest(medicationDetailReq);
    this.myMedicationsDetailsService.setCurrentUserInfo(!medication.currUser, medication.memberInfo);
    this.router.navigate(['../my-medications/medicationdetails']);

    this.saveFilterDetails();
  }

  stopEventPropagation(event) {
    this.swrveService.sendAppMessage(this.swrveEventNames.appClickMyMedicationsCall);
    event.stopPropagation();
  }

  saveFilterDetails() {
    const filterDetails = {
      selectedDoctorList: this.selectedDoctorList,
      selectedPharmacyList: this.selectedPharmacyList,
      dateSelectedFilter: this.dateSelectedFilter,
      toDate: this.toDate,
      fromDate: this.fromDate,
      searchval: this.searchval,
      sortSelectedFilter: this.sortSelectedFilter,
      dependant: this.dependant
    };
    sessionStorage.setItem('med_filterState', JSON.stringify(filterDetails));
  }

  dateFilterChanged(temp) {
    for (let i = 0; i < this.dateList.length; i++) {
      if (this.dateList[i].value === temp.value) {
        this.dateList[i].checked = true;
      }
    }
    if (temp.value === 'Custom Date Range') {
      this.showDate = true;
      this.showCalender = true;
    } else {
      this.showDate = false;
      this.showCalender = false;
    }
    this.clearCustomDateRangeSelections();
  }

  validateFromDate() {
    const minFromDate = this.getMinimumFromDate();
    const froDate = new Date(this.fromDate);
    if (isValid(this.fromDate)) {
      this.isSelectedDateInvalid =
        !this.fromDate ||
        this.fromDate.length !== 10 ||
        differenceInCalendarDays(froDate, new Date(this.calendarMaxDate)) > 0 ||
        differenceInMilliseconds(froDate, new Date(minFromDate)) < 0;
    } else {
      this.isSelectedDateInvalid = true;
    }
  }

  getMinimumFromDate() {
    const minFormDate = new Date();
    const dateRangeAllowedYeardRange: number = this.isInActiveUser ? 1 : 2;
    minFormDate.setFullYear(minFormDate.getFullYear() - dateRangeAllowedYeardRange);
    return minFormDate;
  }

  validateToDate() {
    const minFormDate = this.getMinimumFromDate();
    const tDate = new Date(this.toDate);
    if (isValid(tDate)) {
      this.isSelectedDateInvalid =
        !this.toDate ||
        differenceInMilliseconds(tDate, new Date(this.calendarMaxDate)) > 0 ||
        differenceInMilliseconds(new Date(this.fromDate), new Date(minFormDate)) < 0;
    } else {
      this.isSelectedDateInvalid = true;
    }
  }

  validateCustomRange() {
    if (this.toDate && this.fromDate) {
      this.isCustomDateRangeInValid = differenceInMilliseconds(new Date(this.toDate), new Date(this.fromDate)) < 0;
    }
    return this.isCustomDateRangeInValid;
  }

  clearCustomDateRangeSelections() {
    this.toDate = format(new Date(), 'P');
    this.fromDate = '';
    this.fromMinDate = null;
    this.isCustomDateRangeInValid = false;
    this.isSelectedDateInvalid = false;
  }

  toggleCalender(selectedDateType: string) {
    const isControlChanged =
      (selectedDateType === 'to' && this.isFormDateSelected) || (selectedDateType === 'from' && !this.isFormDateSelected);
    this.isFormDateSelected = selectedDateType === 'from';
    this.currentSelectedDate = this.isFormDateSelected ? new Date(this.fromDate) : new Date(this.toDate);
    this.setCalendarMinimumDate();
    if (isControlChanged) {
      this.toggleCalendarDisplay();
    } else {
      this.showCalender = true;
    }
  }

  toggleCalendarDisplay() {
    this.showCalender = false;
    setTimeout(() => {
      this.showCalender = true;
      setTimeout(() => {
        if (this.isFormDateSelected) {
          this.fromInputDate.nativeElement.focus();
        } else {
          this.toInputDate.nativeElement.focus();
        }
      }, 1);
    }, 1);
  }

  getFormatDateString(date) {
    return format(new Date(), 'P');
  }

  getSelectedValue(date) {
    this.isCustomDateRangeInValid = false;
    this.isSelectedDateInvalid = false;
    if (this.isFormDateSelected) {
      this.fromDate = this.getFormatDateString(date);
    } else {
      this.toDate = this.getFormatDateString(date);
    }
    this.setCalendarMinimumDate();
    this.showCalender = this.validateCustomRange();
  }

  setCalendarMinimumDate() {
    if (!this.isFormDateSelected && this.fromDate) {
      this.fromMinDate = new Date(this.fromDate);
    } else {
      this.fromMinDate = this.getMinimumFromDate();
    }
  }

  formatInputFromDate(value) {
    const dateString: any = this.convertInputStringToDate(value);
    if (dateString) {
      this.fromDate = dateString;
    }
    if (this.fromDate.length >= 10) {
      this.validateFromDate();
      this.validateCustomRange();
      if (!this.isCustomDateRangeInValid && !this.isSelectedDateInvalid) {
        this.currentSelectedDate = new Date(this.fromDate);
        this.toggleCalendarDisplay();
      }
    }
  }

  formatInputToDate(value) {
    const dateString = this.convertInputStringToDate(value);
    if (dateString) {
      this.toDate = dateString;
    }
    if (this.toDate.length >= 10) {
      this.validateToDate();
      this.validateCustomRange();
      if (!this.isCustomDateRangeInValid && !this.isSelectedDateInvalid) {
        this.currentSelectedDate = new Date(this.toDate);
        this.toggleCalendarDisplay();
      }
    }
  }

  convertInputStringToDate(inputDateString: string) {
    if (inputDateString) {
      inputDateString = inputDateString.replace(/[/]/g, '');
      if (inputDateString.length >= 4) {
        inputDateString = inputDateString.substring(0, 2) + '/' + inputDateString.substring(2, 4) + '/' + inputDateString.substring(4);
      } else if (inputDateString.length >= 2) {
        inputDateString = inputDateString.substring(0, 2) + '/' + inputDateString.substring(2, 4);
      }
      return inputDateString;
    }
    return null;
  }

  trackByFn(index, medication) {
    return medication ? medication.id : index;
  }

  clearSessionItems() {
    sessionStorage.removeItem('medicationDetailRequest');
    sessionStorage.removeItem('medicationDependentMemberInfo');
  }

  openExpressScripts() {
    this.ssoService.openSSO('expressscripts');
  }

  goBack() {
    if(this.previousUrl === '/brand-my-medication' && this.medicationsService.getPreviousUrl() === "/loading") {
      this.router.navigate(['/brand-my-medication']);
    }else if(this.previousUrl === '/home' && this.medicationsService.getPreviousUrl() === "/loading") {
      this.router.navigate(['/home']);
    }else {
      this.location.back();
    }
  }

  filterInfo() {
    const filterInput: MyMedicationFilterInputInterface = new MyMedicationFilterInput();
    filterInput.componentInput = cloneDeep(this.filterConfig);
    filterInput.zeroState = this.filterConfigZeroState;
    return filterInput;
  }

  async showMedicationsFilter(filterEvent: any) {
    let popover: HTMLIonPopoverElement;
    const filterInput = this.filterInfo();
    popover = await this.popoverController.create({
      component: MyMedicationFilterComponent,
      event: filterEvent,
      cssClass: 'my-claims-filter',
      translucent: true,
      mode: 'ios',
      componentProps: {filterInput: filterInput}
    });

    popover.onDidDismiss().then(dataReturned => {
      if (dataReturned.data) {
        this.filterConfig = dataReturned.data.componentInput;
        this.applyFilterNew(cloneDeep(this.filterConfig), dataReturned.data.isFilterChanged);
        this.filterConfig.showClearLink = dataReturned.data.isFilterChanged ? this.showClearLink : false;
      }
    });

    return await popover.present();
  }

  handleFilterOut(event) {
    this.filterConfig = event.componentInput;
    this.applyFilterNew(cloneDeep(this.filterConfig), event.isFilterChanged);
    this.filterConfig.showClearLink = event.isFilterChanged ? this.showClearLink : false;
  }

  private updateFilterConfig(): void {
    if (!this.oSortingFilterItem) {
      this.oSortingFilterItem = new FilterItem();
    }

    this.oSortingFilterItem
      .setType('radio')
      .setDivider(true)
      .setSortBy(true)
      .setMulti(true)
      .setHeaderText('Sort by')
      .setHideToggle(false)
      .setExpanded(false)
      .setDisabled(false)
      .setDisableRipple(false)
      .setCollapsedHeight(null)
      .setExpandedHeight('48px')
      .setTitlecase(false)
      .setModel('Most Recent')
      .setDefaultModel('Most Recent')
      .setList([
        new FilterOption()
          .setText('Most Recent')
          .setValue('Most Recent')
          .setSelected(true)
          .setDisabled(false),
        new FilterOption()
          .setText('A to Z')
          .setValue('A to Z')
          .setSelected(false)
          .setDisabled(false),
        new FilterOption()
          .setText('Z to A')
          .setValue('Z to A')
          .setSelected(false)
          .setDisabled(false)
      ]);

    this.filterConfig = {
      showClearLink: this.showClearLink,
      hasSearch: false,
      searchPlaceHolder: 'Keyword',
      searchDataList: [
        {
          data: this.filteredMedications.rxSummary,
          property: ['providerName', 'providerSpeciality', 'mem_name']
        }
      ],
      dontEmitOnInit: true,
      saveFilterState: false,
      filterStatePropName: 'mymedications',
      closeAccordionOnBack: false,
      error: {
        START_DATE_INCORRECT_FORMAT_MSG: FILTER_ERROR_CONSTANTS.START_DATE_INCORRECT_FORMAT_MSG,
        START_DATE_PRIOR_TWO_YEARS_MSG: FILTER_ERROR_CONSTANTS.START_DATE_PRIOR_TWO_YEARS_MSG,
        END_DATE_INCORRECT_FORMAT_MSG: FILTER_ERROR_CONSTANTS.END_DATE_INCORRECT_FORMAT_MSG,
        END_DATE_PRIOR_TWO_YEARS_MSG: FILTER_ERROR_CONSTANTS.END_DATE_PRIOR_TWO_YEARS_MSG,
        END_DATE_PRIOR_START_DATE_MSG: FILTER_ERROR_CONSTANTS.END_DATE_PRIOR_START_DATE_MSG
      },
      items: [
        this.oSortingFilterItem,
        new FilterItem()
          .setType('calendar')
          .setDivider(false)
          .setMulti(true)
          .setHeaderText('Date')
          .setHideToggle(false)
          .setExpanded(false)
          .setDisabled(false)
          .setDisableRipple(false)
          .setCollapsedHeight(null)
          .setExpandedHeight('44px')
          .setTitlecase(false)
          .setList([
            new FilterOption()
              .setText('Last 30 days')
              .setValue(30)
              .setSelected(false)
              .setDisabled(false)
              .setCount(this.filterService.getDateCount(this.getDateCountNew('rxIncurredDate', false), 30)),
            new FilterOption()
              .setText('Last 60 days')
              .setValue(60)
              .setSelected(false)
              .setDisabled(false)
              .setCount(this.filterService.getDateCount(this.getDateCountNew('rxIncurredDate', false), 60)),
            new FilterOption()
              .setText('Last 90 days')
              .setValue(90)
              .setSelected(false)
              .setDisabled(false)
              .setCount(this.filterService.getDateCount(this.getDateCountNew('rxIncurredDate', false), 90)),
            new FilterOption()
              .setText('Year-to-date')
              .setValue('Year')
              .setSelected(false)
              .setDisabled(false)
              .setCount(this.filterService.getDateCount(this.getDateCountNew('rxIncurredDate', true), 1)),
            new FilterOption()
              .setText('All dates')
              .setValue(FilterComponentConstants.ALL)
              .setSelected(true)
              .setDisabled(false)
              .setCount(this.medications.rxSummary.length),
            new FilterOption()
              .setText('Custom Date Range')
              .setValue(FilterComponentConstants.CUSTOM)
              .setSelected(false)
              .setDisabled(false)
          ]),
        new FilterItem()
          .setType('checkbox')
          .setDivider(false)
          .setMulti(true)
          .setHeaderText('Member')
          .setHideToggle(false)
          .setExpanded(false)
          .setDisabled(false)
          .setDisableRipple(false)
          .setCollapsedHeight(null)
          .setExpandedHeight('44px')
          .setTitlecase(false)
          .setSelectEveryOnAll(true)
          .setSelectAllOnEvery(true)
          .setDisableOnAll(true)
          .setList(this.membersList),
        new FilterItem()
          .setType('checkbox')
          .setDivider(false)
          .setMulti(true)
          .setHeaderText('Prescribing Doctor')
          .setHideToggle(false)
          .setExpanded(false)
          .setDisabled(false)
          .setDisableRipple(false)
          .setCollapsedHeight(null)
          .setExpandedHeight('44px')
          .setTitlecase(false)
          .setSelectEveryOnAll(true)
          .setSelectAllOnEvery(true)
          .setDisableOnAll(true)
          .setList(this.prescribingDoctorList),
        new FilterItem()
          .setType('checkbox')
          .setDivider(false)
          .setMulti(true)
          .setHeaderText('Pharmacy')
          .setHideToggle(false)
          .setExpanded(false)
          .setDisabled(false)
          .setDisableRipple(false)
          .setCollapsedHeight(null)
          .setExpandedHeight('44px')
          .setTitlecase(false)
          .setSelectEveryOnAll(true)
          .setSelectAllOnEvery(true)
          .setDisableOnAll(true)
          .setList(this.pharmacyList)
      ]
    };

    this.filterConfigZeroState = cloneDeep(this.filterConfig);

    // Dont add the member filter if there are no dependents
    if (this.basicMemInfo && !this.bHasDependents) {
      this.filterConfig.items.splice(2, 1);
    }
  }

  private applyDefaultSorting() {
    this.filteredMedications.rxSummary = this.filteredMedications.rxSummary.sort((item1, item2) =>
      differenceInCalendarDays(new Date(item1.rxIncurredDate), new Date(item2.rxIncurredDate)));
    this.filteredMedications.rxSummary = this.filteredMedications.rxSummary.reverse();
  }

  private checkMemberSelectionChange(newFilters: FilterInterface) {
    newFilters.items.map((value) => {
      if (value.headerText === 'Member') {
        value.list.map((val) => {
          if (val.selected) {
            this.dependant = val.name;
          }
        })
      }
    })
  }

  private applyFilterNew(newFilters: FilterInterface, isFilterDirty: boolean) {

    this.isFilterDirty = isFilterDirty;
    this.checkMemberSelectionChange(newFilters);
    this.filteredMedications = cloneDeep(this.allMedications)
    if (this.checkIfIsDependentIsChanged()) {
      this.clearFilterList();
      this.handleMedicationsResponse(this.allMedications, true);
    } else {
      this.showResultsCount = true;
      this.filterData();
      this.applySorting();
    }

    this.applyMemberFilter(newFilters);
    this.applySortingNew(newFilters);
    this.applyDateFilterNew(newFilters);
    this.applyPrescribingDoctorFilter(newFilters);
    this.applyPharmacyFilterNew(newFilters);

    this.applyUserFilter();

    this.prescribingDoctorList = this.getListItems('prescribingDoctor', this.medications.rxSummary, this.allDoctorsString);
    this.pharmacyList = this.getListItems('pharmacy', this.medications.rxSummary, this.allPharmaciesString, 'name');

    this.filterConfig.items = this.filterConfig.items.map((filterCategoryItem) => {
      if (filterCategoryItem.headerText === 'Prescribing Doctor') {
        const selectedPrescribingDoctors = filterCategoryItem.list.filter(listItem => listItem.selected);
        this.prescribingDoctorList = this.prescribingDoctorList.map(prescribingDoctor => {
          selectedPrescribingDoctors.map(selectedPrescribingDoctor => {
            if (prescribingDoctor.value === selectedPrescribingDoctor.value) {
              prescribingDoctor.selected = true;
            }
          });
          return prescribingDoctor;
        });
        filterCategoryItem.setList(this.prescribingDoctorList);
      } else if (filterCategoryItem.headerText === 'Pharmacy') {
        const selectedPharmacyList = filterCategoryItem.list.filter(listItem => listItem.selected);
        this.pharmacyList = this.pharmacyList.map(pharmacy => {
          selectedPharmacyList.map(selectedPharmacy => {
            if (pharmacy.value === selectedPharmacy.value) {
              pharmacy.selected = true;
            }
          });
          return pharmacy;
        });
        filterCategoryItem.setList(this.pharmacyList);
      }
      return filterCategoryItem;
    });
    this.showClearLink = true;
    this.noMedicationsAvailable = (this.filteredMedications.rxSummary.length <= 0);
  }

  private applyMemberFilter(newFilters: FilterInterface): void {
    const memberFilterCol: FilterItemInterface[] = newFilters.items.filter((item) => {
      return (item.headerText === "Member")
    });
    let memberFilter: FilterItemInterface = null;
    if (memberFilterCol && memberFilterCol.length) {
      memberFilter = memberFilterCol[0];
    }
    if (memberFilter) {
      const memberFilterOptionArr = memberFilter.list.filter((filterOption) => {
        return filterOption.selected
      });
      if (memberFilterOptionArr && memberFilterOptionArr.length) {
        const allMembersOptionChoosen = memberFilterOptionArr.some((memberFilterOption) => {
          return (memberFilterOption.value === 'All')
        })
        if (!allMembersOptionChoosen) {
          const allSelectedMemberIndices: number[] = [];
          this.allMedications.rxSummary.map((medicationItem, medItr) => {
            const foundMatch = memberFilterOptionArr.some((memberFilterOption) => {
              return medicationItem['fullName'].toUpperCase().includes(memberFilterOption.value.toUpperCase())
            });
            if (foundMatch) {
              allSelectedMemberIndices.push(medItr);
            }
          });

          if (allSelectedMemberIndices.length) {
            this.filteredMedications.rxSummary = [];
            allSelectedMemberIndices.map((selectedIndex) => {
              this.filteredMedications.rxSummary[this.filteredMedications.rxSummary.length] = this.allMedications.rxSummary[selectedIndex];
            });
          }
        } else {
          this.filteredMedications.rxSummary = [];
          this.filteredMedications.rxSummary = this.allMedications.rxSummary;
        }
      }
    }
  }



  private applySortingNew(newFilters: FilterInterface): void {
    const sortByFilterCol: FilterItemInterface[] = newFilters.items.filter((item) => {
      return (item.headerText === "Sort by")
    });
    let sortByFilter: FilterItemInterface = null;
    if (sortByFilterCol && sortByFilterCol.length) {
      sortByFilter = sortByFilterCol[0];
    }

    if (sortByFilter) {
      const selectedSortFilterArr = sortByFilter.list.filter((filterOption) => {
        return filterOption.selected
      });
      if (selectedSortFilterArr && selectedSortFilterArr.length) {
        const selectedSortFilter = selectedSortFilterArr[0];
        if (selectedSortFilter) {
          if (selectedSortFilter.value === 'Most Recent') {
            this.filteredMedications.rxSummary = this.filteredMedications.rxSummary.sort((item1, item2) =>
              differenceInCalendarDays(new Date(item1.rxIncurredDate), new Date(item2.rxIncurredDate)));
            this.filteredMedications.rxSummary = this.filteredMedications.rxSummary.reverse();
          } else if (selectedSortFilter.value === 'A to Z') {
            this.filteredMedications.rxSummary = this.filteredMedications.rxSummary.sort(
              (item1, item2) =>
                this.compareStringField(item2.genericName, item1.genericName) ||
                differenceInCalendarDays(new Date(item2.rxIncurredDate), new Date(item1.rxIncurredDate))
            );
          } else if (selectedSortFilter.value === 'Z to A') {
            this.filteredMedications.rxSummary = this.filteredMedications.rxSummary.sort(
              (item1, item2) =>
                this.compareStringField(item1.genericName, item2.genericName) ||
                differenceInCalendarDays(new Date(item2.rxIncurredDate), new Date(item1.rxIncurredDate))
            );
          }
        }
      }
    }
  }


  private applyDateFilterNew(newFilters: FilterInterface): void {
    const dateFilterCol: FilterItemInterface[] = newFilters.items.filter((item) => {
      return (item.headerText === "Date")
    });
    let dateFilter: FilterItemInterface = null;
    if (dateFilterCol && dateFilterCol.length) {
      dateFilter = dateFilterCol[0];
    }
    if (dateFilter) {
      const dateFilterOptionArr = dateFilter.list.filter((filterOption) => {
        return filterOption.selected
      });
      if (dateFilterOptionArr && dateFilterOptionArr.length) {
        const dateFilterOption: FilterOption = dateFilterOptionArr[0];
        if (dateFilterOption) {
          if (dateFilterOption.value === 'CUSTOM') {
            this.applyCustomRangeDateFilterNew(dateFilterOption);
          } else if (dateFilterOption.value !== 'Year') {
            if (dateFilterOption.value !== 'ALL') {
              this.filteredMedications.rxSummary = this.filteredMedications.rxSummary.filter(doctor => {
                return differenceInCalendarDays(new Date(), new Date(doctor.rxIncurredDate)) <= dateFilterOption.value;
              });
            }
          } else {
            this.filteredMedications.rxSummary = this.filteredMedications.rxSummary.filter(doctor => {
              return (differenceInCalendarDays(new Date(), new Date(doctor.rxIncurredDate)) / 365) <= 1;
            });
          }
        }
      }
    }
  }

  private applyPrescribingDoctorFilter(newFilters: FilterInterface): void {
    const doctorFilterCol: FilterItemInterface[] = newFilters.items.filter((item) => {
      return (item.headerText === "Prescribing Doctor")
    });
    let doctorFilter: FilterItemInterface = null;
    if (doctorFilterCol && doctorFilterCol.length) {
      doctorFilter = doctorFilterCol[0];
    }
    if (doctorFilter) {
      const doctorFilterOptionArr = doctorFilter.list.filter((filterOption) => {
        return filterOption.selected
      });
      if (doctorFilterOptionArr && doctorFilterOptionArr.length) {
        const allMembersOptionChoosen = doctorFilterOptionArr.some((memberFilterOption) => {
          return (memberFilterOption.value === 'ALL')
        })
        if (!allMembersOptionChoosen) {
          const allMissingDoctorIndices: number[] = [];
          this.filteredMedications.rxSummary.map((medicationItem, medItr) => {
            const foundMatch = doctorFilterOptionArr.some((memberFilterOption) => {
              return medicationItem['prescribingDoctor'].toUpperCase() === memberFilterOption.value.toUpperCase()
            });
            if (!foundMatch) {
              allMissingDoctorIndices.push(medItr);
            }
          });

          if (allMissingDoctorIndices.length) {
            allMissingDoctorIndices.map((missingIndex) => {
              this.filteredMedications.rxSummary[missingIndex] = null;
            });

            this.filteredMedications.rxSummary = this.filteredMedications.rxSummary.filter(medicationItem => {
              return (medicationItem !== null)
            });
          }
        }
      }
    }
  }


  private applyPharmacyFilterNew(newFilters: FilterInterface): void {
    const pharmacyFilterCol: FilterItemInterface[] = newFilters.items.filter((item) => {
      return (item.headerText === "Pharmacy")
    });
    let pharmacyFilter: FilterItemInterface = null;
    if (pharmacyFilterCol && pharmacyFilterCol.length) {
      pharmacyFilter = pharmacyFilterCol[0];
    }
    if (pharmacyFilter) {
      const pharmacyFilterOptionArr = pharmacyFilter.list.filter((filterOption) => {
        return filterOption.selected
      });
      if (pharmacyFilterOptionArr && pharmacyFilterOptionArr.length) {
        const allPharmacyOptionChoosen = pharmacyFilterOptionArr.some((pharmacyFilterOption) => {
          return (pharmacyFilterOption.value === 'ALL')
        })
        if (!allPharmacyOptionChoosen) {
          const allMissingPharmacyIndices: number[] = [];
          this.filteredMedications.rxSummary.map((medication, medItr) => {
            const foundMatch = pharmacyFilterOptionArr.some((pharmacyFilterOption) => {
              return medication.pharmacy['name'].toUpperCase() === pharmacyFilterOption.value.toUpperCase()
            });
            if (!foundMatch) {
              allMissingPharmacyIndices.push(medItr);
            }
          });

          if (allMissingPharmacyIndices.length) {
            allMissingPharmacyIndices.map((missingIndex) => {
              this.filteredMedications.rxSummary[missingIndex] = null;
            });

            this.filteredMedications.rxSummary = this.filteredMedications.rxSummary.filter(medicationItem => {
              return (medicationItem !== null)
            });
          }
        }
      }
    }
  }


  private applyCustomRangeDateFilterNew(filterOption: FilterOptionInterface) {
    if (filterOption.toDate && filterOption.fromDate) {
      const toDate = new Date(filterOption.toDate);
      const fromDate = new Date(filterOption.fromDate);
      if (isValid(toDate) && isValid(fromDate)) {
        this.filteredMedications.rxSummary = this.filteredMedications.rxSummary.filter(medication => {
          const medicationDate = new Date(medication.rxIncurredDate);
          return differenceInMilliseconds(medicationDate, toDate) <= 0 && differenceInMilliseconds(medicationDate, fromDate) >= 0;
        });
      }
    }
  }

}
