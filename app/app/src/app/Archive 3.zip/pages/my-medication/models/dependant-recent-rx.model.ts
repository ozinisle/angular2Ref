import { MyBlueGeneralAPIRequestModel } from '../../../models/generic-app.model';
import {
  DependentRecentRxRequestModelInterface,
  DependentRecentRxResponseModelInterface
} from './interfaces/dependant-recent-rx-model.interface';
import { BaseRecentRxResponseModel } from './my-medications-generic.models';

export class DependentRecentRxRequestModel extends MyBlueGeneralAPIRequestModel implements DependentRecentRxRequestModelInterface {
  dependentId: number; // *dependentIdnumber- example: 123456786 - Dependent ID
}

// tslint:disable-next-line:no-empty-interface
export class DependentRecentRxResponseModel extends BaseRecentRxResponseModel implements DependentRecentRxResponseModelInterface {}
