import { MyBlueGeneralAPIRequestModel } from '@app/models/generic-app.model';
import { BaseRecentRxResponseModel } from './my-medications-generic.models';

export class RecentRxRequestModel extends MyBlueGeneralAPIRequestModel {}
export class RecentRxResponseModel extends BaseRecentRxResponseModel {}
