import { ChangeDetectorRef, Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { DateState } from '@app/pages/my-claims/models/date-state.model';
import { DateSearchListInterface } from '@app/pages/my-claims/models/interfaces/claims-generic-models.interface';
import { GlobalUtils } from '@app/utils/global.utils';
import { PopoverController } from '@ionic/angular';
import { CalendarComponentOptions } from 'ion2-calendar';
import { cloneDeep } from 'lodash-es';
import { isValid } from 'date-fns';
import { Subject, Subscription } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { FilterInterface, FilterItemInterface, FilterOptionInterface, MyMedicationFilterInputInterface } from '../models/filter/filter-model.interface';
import { Filter } from '../models/filter/filter.model';

@Component({
  selector: 'app-my-medication-filter',
  templateUrl: './my-medication-filter.component.html',
  styleUrls: ['./my-medication-filter.component.scss'],
})
export class MyMedicationFilterComponent implements OnInit, OnDestroy {

  @Output() componentOutput = new EventEmitter<MyMedicationFilterInputInterface>();
  @Input() getPopOver: any;
  @Input() componentInput: FilterInterface = new Filter();
  @Output() filterOut = new EventEmitter<any>();

  public showClearLink = false;
  public submenu: any = {};
  public clearFilterFlagSubjectSubscription: Subscription;
  @Input() filterInput: MyMedicationFilterInputInterface;
  public radioFilters: FilterItemInterface[] = null;
  public checkboxFilters: FilterItemInterface[] = null;
  public calendarFilters: FilterItemInterface[] = null;
  public selectedValue: object = null;
  public defaultSortText = '';
  public dateState: DateState = null;
  public dateList: DateSearchListInterface[] = [];
  public hideDateRangeSelection = true;
  ismobile: boolean;
  private unsubscribeHelper$: Subject<void> = new Subject<void>();
  optionsRange: CalendarComponentOptions = {
    pickMode: 'range'
  };
  type: 'string';
  dateRange: { from: string; to: string; };


  constructor(
    private cdRef: ChangeDetectorRef,
    private popoverController: PopoverController,
    private resizeService: GlobalUtils

  ) {
    this.dateState = new DateState(this.dateList);
  }

  ngOnInit() {
    this.resizeService.getIsMobile().pipe(takeUntil(this.unsubscribeHelper$))
    .subscribe((isMobile: boolean) => this.ismobile = isMobile );
    this.populateFilter();
  }

  ngOnDestroy(): void {
    this.unsubscribeHelper$.next();
    this.unsubscribeHelper$.complete();
  }

  private populateFilter() {
    this.radioFilters = [];
    this.checkboxFilters = [];
    this.calendarFilters = [];
    this.selectedValue = {};
    this.showClearLink = this.filterInput.componentInput.showClearLink;
    this.filterInput.componentInput.items.map((item: FilterItemInterface) => {

      this.submenu[item.headerText] = item.expanded;

      if (item.type === 'radio') {
        this.radioFilters.push(item);
      } else if (item.type === 'calendar') {
        this.calendarFilters.push(item);
        const customDateOption = item.list[item.list.length - 1];
        if (customDateOption.toDate) {
          const toDate = new Date(customDateOption.toDate);
          if (isValid(toDate)) {
            this.dateState.endRangeValue = customDateOption.toDate;
          }
        }
        if (customDateOption.fromDate) {
          const fromDate = new Date(customDateOption.fromDate);
          if (isValid(fromDate)) {
            this.dateState.startRangeValue = customDateOption.fromDate ;
          }
        }

        this.hideDateRangeSelection = !customDateOption.selected;
      } else if (item.type === 'checkbox') {
        this.checkboxFilters.push(item);
      }

      if (item.type === 'radio' || item.type === 'calendar') {
        item.list.some((option: FilterOptionInterface) => {
          if (option.selected) {
            this.selectedValue[item.headerText] = option.text;
            if (item.type === 'radio') {
              this.defaultSortText = option.text;
            }
            return true;
          }
        });
      } else if (item.type === 'checkbox') {
        item.list.map((option: FilterOptionInterface) => {
          if (option.selected) {
            if (Object.prototype.toString.call(this.selectedValue[item.headerText]) === "[object Array]") {
              this.selectedValue[item.headerText].push(option.value);
            }
            this.selectedValue[item.headerText] = [option.value];
          }
        });
      }
    });
  }

  toggleSubmenu(menu: string) {
    if (typeof this.submenu[menu] === "undefined" || this.submenu[menu] === null) {
      this.submenu[menu] = false;
    }

    this.submenu[menu] = !this.submenu[menu];

    if (menu !== "Sort by") {
      this.filterInput.componentInput.items = this.filterInput.componentInput.items.map((item: FilterItemInterface) => {
        if (item.headerText === menu) {
          item.expanded =  this.submenu[menu];
        }
        return item;
      });
    }

    this.cdRef.detectChanges();
  }

  public clearFilter() {
    this.filterInput.componentInput = cloneDeep(this.filterInput.zeroState);
    this.populateFilter();
    this.filterInput.isFilterChanged = false;
    this.showClearLink = false;
    this.ismobile ? this.popoverController.dismiss(this.filterInput) : this.filterOut.emit(this.filterInput);

  }

  manageRadioFilterSelection(event, categoryName, sortSelectionFlag?: boolean) {
    this.showClearLink = true;
    if (sortSelectionFlag) {
      this.defaultSortText = event.detail.value;
    }
    this.selectedValue[categoryName] = null;

    this.filterInput.componentInput.items = this.filterInput.componentInput.items.map((selectedFilter) => {
      if (selectedFilter.headerText.toUpperCase() === categoryName.toUpperCase()) {
        selectedFilter.list = selectedFilter.list.filter((selectedItem) => {
          if (selectedItem.text === event.detail.value) {
            selectedItem.selected = true;
            this.selectedValue[categoryName] = selectedItem.text
            this.hideDateRangeSelection = (selectedItem.text !== "Custom Date Range");
            if (!this.hideDateRangeSelection) {
              selectedItem.fromDate = this.dateState.startRangeValue;
              selectedItem.toDate = this.dateState.endRangeValue;
            }
          } else {
            selectedItem.selected = false;
          }

          return selectedItem;
        });
      }
      return selectedFilter;
    });
  }

  manageCheckboxFilterSelection(event, categoryName) {
    this.showClearLink = true;
    const selectedMemberItems = [];
    let filterGroupItems = cloneDeep(this.filterInput.componentInput.items);

    filterGroupItems = filterGroupItems.map((selectedFilter) => {
      if (selectedFilter.headerText.toUpperCase() === categoryName.toUpperCase()) {

        if (event.detail.value === 'All Prescribing Doctors' || event.detail.value === 'All Pharmacies' || event.detail.value === 'All Members') {
          selectedFilter.list[selectedFilter.list.length - 1].selected = event.detail.checked;

          //if all option is selected, select all other options in the category
          selectedFilter.list = selectedFilter.list.map(listItem => {
            listItem.selected = event.detail.checked;
            return listItem;
          });
        }

        selectedFilter.list = selectedFilter.list.filter((selectedItem) => {
          if (Object.prototype.toString.call(this.selectedValue[categoryName]) !== "[object Array]") {
            this.selectedValue[categoryName] = [];
          }
          if ( selectedItem.value === event.detail.value) {
            selectedItem.selected = event.detail.checked;
            if (selectedItem.selected) {
              //add selection to checkbox values array
              if (categoryName === "Prescribing Dcotor") {
                selectedMemberItems.push(selectedItem);
              }
            }
          }

          return selectedItem;
        });

      }
      return selectedFilter;
    });

    filterGroupItems = filterGroupItems.map((filterGroup) => {

      if (filterGroup.headerText.toUpperCase() === categoryName.toUpperCase()) {
        //if all other options are selected excet the all options item select all options item
        const bufferSelected = filterGroup.list.filter((listItem, listItemIndex) => {
          if (listItem.selected && listItemIndex < filterGroup.list.length - 1) {
            return listItem;
          }
        });

        //if all other options except "all" is selected , mark "all" as selected else unselected
        filterGroup.list[filterGroup.list.length - 1].selected = (bufferSelected.length >= filterGroup.list.length - 1);
      }
      return filterGroup;
    });

    if (categoryName === "Prescribing Doctor") {
      const isAnyMemberSelected: boolean = filterGroupItems.some((filterGroup) => {
        if (filterGroup.headerText === "Prescribing Doctor") {
          const allMembersSelected: boolean = filterGroup.list[filterGroup.list.length - 1].selected;
          const selectedMembersArr: string[] = filterGroup.list.map((filterItem) => {
            if (allMembersSelected || filterItem.selected) {
              return filterItem.value;
            }
          });

          const selectedMembers = selectedMembersArr.join('~');
          const selectedSpecialities = [];
          this.filterInput.componentInput.searchDataList[0].data.map((doctor) => {
            if (selectedMembers.toUpperCase().indexOf(doctor['prescribingDoctor']) >= 0) {
              selectedSpecialities.push(doctor['providerSpeciality']);
            }
          });
          if (selectedMembersArr && selectedMembersArr.length > 0) {
            filterGroupItems = filterGroupItems.map((item) => {
              if (item.headerText === "Pharmacy") {
                let unhideCount = 0;
                item.list = item.list.map((specialityItem) => {

                    specialityItem.hide = true;

                    if ( selectedSpecialities.join('~').indexOf(specialityItem.value) >= 0 ) {
                      specialityItem.hide = false;
                      unhideCount++;
                      return specialityItem;
                    }

                    if ( specialityItem.value === "All Pharmacies" && unhideCount > 0 ) {
                      specialityItem.hide = false;
                    }

                    return specialityItem;

                });
              }
              return item;
            });
          }

          //remove undefined values from array and return the number of valid elements in it
          return selectedMembersArr.filter(e => e).length;
        }
      });

      //if no member is selected show all specialities
      if (!isAnyMemberSelected) {
        filterGroupItems = filterGroupItems.map((filterGroup) => {
          if (filterGroup.headerText === "Pharmacy") {
            filterGroup.list = filterGroup.list.map((filterItem) => {
              filterItem.hide = false;
              return filterItem;
            });
          }
          return filterGroup;
        });
      }

    }

    this.filterInput.componentInput.items = filterGroupItems;

    //ppulate filter selection on screen by updating the screen bounded value this.checkboxFilters
    this.checkboxFilters = [];
    filterGroupItems.map((filterGroup) => {
      if (filterGroup.headerText === "Prescribing Doctor" || filterGroup.headerText === "Pharmacy" || filterGroup.headerText === "Member") {
        this.selectedValue[filterGroup.headerText] = [];
        filterGroup.list.map(filterItem => {
          if (filterItem.selected) {
            this.selectedValue[filterGroup.headerText].push(filterItem.value);
          }
        });
        this.checkboxFilters.push(filterGroup);
      }
    });
  }

  closeFilter() {
    this.filterInput.isFilterChanged = true;
    if (!this.hideDateRangeSelection) {
      this.filterInput.componentInput.items = this.filterInput.componentInput.items.map(filterGroup => {
        if (filterGroup.headerText === "Date") {
          filterGroup.list = filterGroup.list.map(filterItem => {
            if (filterItem.text === "Custom Date Range") {
              filterItem.fromDate = this.dateState.startRangeValue;
              filterItem.toDate = this.dateState.endRangeValue;
            }
            return filterItem;
          });
        }
        return filterGroup;
      })
    }

    this.ismobile ? this.popoverController.dismiss(this.filterInput) : this.filterOut.emit(this.filterInput);
  }

  onStartDateChange($event) {
    this.dateState.startRangeValue = $event.target.value.split('T')[0];
  }

  onEndDateChange($event) {
    this.dateState.endRangeValue = $event.target.value.split('T')[0];
  }

  onDateChange(event) {
    this.dateState.startRangeValue = event.from.format("YYYY-MM-DD");
    this.dateState.endRangeValue = event.to.format("YYYY-MM-DD");
  }
}
