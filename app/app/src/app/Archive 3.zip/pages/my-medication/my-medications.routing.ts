import { RouterModule, Routes } from '@angular/router';
import { MyMedicationDetailsPage } from './my-medication-details/my-medication-details.page';
import { MyMedicationsPage } from './my-medications/my-medications.page';

const MEDICATIONS_ROUTER: Routes = [
  {
    path: '',
    component: MyMedicationsPage
  },
  {
    path: 'medicationdetails',
    data: {
      breadcrumb: 'Medication Details'
    },
    component: MyMedicationDetailsPage
  }
];

export const MEDICATIONS_ROUTES = RouterModule.forChild(MEDICATIONS_ROUTER);
