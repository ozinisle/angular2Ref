import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { AlertService } from '@app/services/alert.service';
import { RxDetailsRequestModelInterface, RxDetailsResponseModelInterface } from '../models/interfaces/rx-details-model.interface';
import { RxDetailsResponseModel } from '../models/rx-details.model';
import { ConstantsService } from '@app/services/constants.service';

@Injectable({ providedIn: 'root' })
export class MyMedicationDetailsService {
  private myMedicationDetailsRequest: RxDetailsRequestModelInterface = null;
  private isDependentUser = false;
  private dependentMemberInfo = '';
  constructor(private http: HttpClient, private constants: ConstantsService, private alertService: AlertService) {}

  public setCurrentUserInfo(isDependentUser, dependentMemberInfo): MyMedicationDetailsService {
    this.isDependentUser = isDependentUser;
    this.dependentMemberInfo = dependentMemberInfo;
    sessionStorage.setItem('medicationDependentMemberInfo', JSON.stringify(this.dependentMemberInfo));
    return this;
  }

  public getCurrentUserInfo() {
    return { isDependentUser: this.isDependentUser, dependentMemberInfo: this.dependentMemberInfo };
  }

  public setMyMedicationDetailsRequest(myMedicationDetailsRequest: RxDetailsRequestModelInterface): MyMedicationDetailsService {
    this.myMedicationDetailsRequest = myMedicationDetailsRequest;
    sessionStorage.setItem('medicationDetailRequest', JSON.stringify(this.myMedicationDetailsRequest));
    return this;
  }

  public getMyMedicationDetailsRequest(): RxDetailsRequestModelInterface {
    return this.myMedicationDetailsRequest;
  }

  public getMedicationDetails(): Observable<RxDetailsResponseModelInterface> {
    const getmedicationDetailRequest = sessionStorage.getItem('medicationDetailRequest');
    const getmedicationDetailRequestdata = JSON.parse(getmedicationDetailRequest);
    const getmedArray = [];
    getmedArray.push(JSON.parse(getmedicationDetailRequest));
    const url =
      getmedicationDetailRequestdata && getmedArray[0].dependentId
        ? this.constants.depMedicationsDetailsUrl
        : this.constants.medicationsDetailsUrl;

    return this.http.post<RxDetailsResponseModelInterface>(url, getmedicationDetailRequestdata).pipe(
      map(response => {
        if (response.result < 0) {
          this.alertService.setAlert('', response['displaymessage'], AlertType.Failure);
          return null;
        } else {
          return response as RxDetailsResponseModel;
        }
      })
    );
  }
}
