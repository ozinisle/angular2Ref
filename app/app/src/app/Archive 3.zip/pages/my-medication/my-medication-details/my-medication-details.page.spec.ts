import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { ConstantsService } from '@app/services/constants.service';
import { NgxsModule } from '@ngxs/store';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { HomeService } from '@app/services/home.service';
import { MyMedicationDetailsPage } from './my-medication-details.page';
import { FormBuilder } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { AlertService } from '@app/services/alert.service';
import 'rxjs/add/observable/of';
import { TitleCasePipe } from '@angular/common';
import { MyMedicationDetailsService } from './my-medication-details.service';
import { MedicationsService } from '@app/services/medications.service';
import { mocks } from '@testing/constants/mocks.service';
import { SwrveEventNames, SwrveService } from '@app/services/swrve.service';
import { IonicModule } from '@ionic/angular';
import { AlertsComponent } from '@app/components/alerts/alerts.component';
import { FpoLayoutComponent } from '@app/components/fpo-layout/fpo-layout.component';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';

describe('MyMedicationDetailsPage', () => {
  let component: MyMedicationDetailsPage;

  let fixture: ComponentFixture<MyMedicationDetailsPage>;
  let mockRouter;
  let mockAlertService;
  let mockmyMedicationDetailsService;
  let mockmedicationsService;
  let mockConstantsService;

  beforeEach(
    waitForAsync(() => {
      mockRouter = mocks.service.router;
      mockAlertService = mocks.service.alertService;
      mockmyMedicationDetailsService = mocks.service.myMedicationDetailsService;
      mockmedicationsService = mocks.service.medicationsService;
      mockConstantsService = mocks.service.constantsService;
      TestBed.configureTestingModule({
        imports: [IonicModule, HttpClientTestingModule, RouterTestingModule, NgxsModule.forRoot([]), NgxsSelectSnapshotModule.forRoot()],
        providers: [
          ConstantsService,
          MyMedicationDetailsPage,
          HomeService,
          InAppBrowser,
          MyMedicationDetailsService,
          FormBuilder,
          AlertService,
          DatePipe,
          TitleCasePipe,
          SwrveEventNames,
          SwrveService,
          { provide: Router, useValue: mockRouter },
          { provide: AlertService, useValue: mockAlertService },
          { provide: MyMedicationDetailsService, useValue: mockmyMedicationDetailsService },
          { provide: MedicationsService, useValue: mockmedicationsService },
          { provide: ConstantsService, useValue: mockConstantsService }
        ],
        declarations: [MyMedicationDetailsPage, AlertsComponent, FpoLayoutComponent]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(MyMedicationDetailsPage);

    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit', () => {
    it('should call the "myMedicationDetailsService.getCurrentUserInfo" service function', () => {
      fixture = TestBed.createComponent(MyMedicationDetailsPage);
      component = fixture.componentInstance;
      component.ngOnInit();
      expect(mockmyMedicationDetailsService.getCurrentUserInfo).toHaveBeenCalled();
    });

    it('should call the "myMedicationDetailsService.getMyMedicationDetailsRequest" service function', () => {
      fixture = TestBed.createComponent(MyMedicationDetailsPage);
      component = fixture.componentInstance;
      component.ngOnInit();
      expect(mockmyMedicationDetailsService.getMyMedicationDetailsRequest).toHaveBeenCalled();
    });
    it('should call the "medicationsService.getMemBasicInfo" service function', () => {
      fixture = TestBed.createComponent(MyMedicationDetailsPage);
      component = fixture.componentInstance;
      component.ngOnInit();
      expect(mockmedicationsService.getMemBasicInfo).toHaveBeenCalled();
    });
    it('should define basicMemInfo variable', () => {
      fixture = TestBed.createComponent(MyMedicationDetailsPage);
      component = fixture.componentInstance;
      component.ngOnInit();
      expect(component.basicMemInfo).toBeDefined();
    });
    it('should call the "myMedicationDetailsService.getMedicationDetails" service function', () => {
      fixture = TestBed.createComponent(MyMedicationDetailsPage);
      component = fixture.componentInstance;
      component.ngOnInit();
      expect(mockmyMedicationDetailsService.getMedicationDetails).toHaveBeenCalled();
    });
    it('should call the "populateDetailsFromSessionStorageIfEmpty" function', () => {
      fixture = TestBed.createComponent(MyMedicationDetailsPage);
      component = fixture.componentInstance;
      spyOn(component, 'populateDetailsFromSessionStorageIfEmpty');
      component.ngOnInit();
      expect(component.populateDetailsFromSessionStorageIfEmpty).toHaveBeenCalled();
    });
    it('should call the "alertService.clearError" function', () => {
      fixture = TestBed.createComponent(MyMedicationDetailsPage);
      component = fixture.componentInstance;
      component.ngOnDestroy();
      expect(mockAlertService.clearError).toHaveBeenCalled();
    });
    it('should call the "myMedicationDetailsService.setMyMedicationDetailsRequest" service function', () => {
      fixture = TestBed.createComponent(MyMedicationDetailsPage);
      component = fixture.componentInstance;
      component.ngOnInit();
      component.populateDetailsFromSessionStorageIfEmpty();
      expect(mockmyMedicationDetailsService.setMyMedicationDetailsRequest).toHaveBeenCalled();
    });
    it('should call the "navigateToClaimDetails" function', () => {
      fixture = TestBed.createComponent(MyMedicationDetailsPage);
      component = fixture.componentInstance;
      component.navigateToClaimDetails('0210');
      expect(mockmyMedicationDetailsService.setMyMedicationDetailsRequest).toHaveBeenCalled();
    });
    it('should call the "navigateToClaimDetails" function', () => {
      fixture = TestBed.createComponent(MyMedicationDetailsPage);
      component = fixture.componentInstance;
      component.navigateToClaimDetails('0210');
      expect(mockmyMedicationDetailsService.setMyMedicationDetailsRequest).toHaveBeenCalled();
    });
    it('should call the "navigateToClaimDetails" function with navigateByUrl', () => {
      component.navigateToClaimDetails('0210');
      expect(mockRouter.navigateByUrl).toHaveBeenCalledWith('/myClaims/claimdetails');
    });

    it('should call the "navigateToDoctorDetails" function with navigate', () => {
      const doctorInfo = {};
      component.navigateToDoctorDetails(doctorInfo);
      expect(mockRouter.navigate).toHaveBeenCalledWith([`/my-doctor/details`]);
    });
  });
});
