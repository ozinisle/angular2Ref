import { Location, TitleCasePipe } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertService } from '@app/services/alert.service';
import { ConstantsService } from '@app/services/constants.service';
import { MedicationsService } from '@app/services/medications.service';
import { SwrveEventNames, SwrveService } from '@app/services/swrve.service';
import { BasicMemInfoRxSummary, GetMemBasicInfoResponseModel } from '../models/get-member-basic-info.model';
import { GetMemBasicInfoResponseModelInterface } from '../models/interfaces/get-member-basic-info-model.interface';
import { RxDetailsResponseModelInterface } from '../models/interfaces/rx-details-model.interface';
import { MyMedicationDetailsService } from './my-medication-details.service';
import { Observable, Subject } from 'rxjs';
import { GlobalUtils } from '@app/utils/global.utils';
import { takeUntil } from 'rxjs/operators';
import { Select } from '@ngxs/store';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { MemberPlan } from '@app/models/member-plan.model';

@Component({
  selector: 'app-my-medication-details',
  templateUrl: './my-medication-details.page.html',
  styleUrls: ['./my-medication-details.page.scss']
})
export class MyMedicationDetailsPage implements OnInit, OnDestroy {
  @Select(AppSelectors.getSelectedPlan) selectedPlan$: Observable<MemberPlan>;
  
  public medicationDetail: RxDetailsResponseModelInterface;
  public basicMemInfo: GetMemBasicInfoResponseModelInterface;
  public fpoTargetUrl = '';
  ismobile: boolean;
  private unsubscribeHelper$: Subject<void> = new Subject<void>();
  defaultPlan: boolean;
  dependentMemInfo: string[];
  basicMemInfoRx: BasicMemInfoRxSummary;

  constructor(
    private myMedicationDetailsService: MyMedicationDetailsService,
    private router: Router,
    private alertService: AlertService,
    private medicationsService: MedicationsService,
    private title: TitleCasePipe,
    private constantsService: ConstantsService,
    private location: Location,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames,
    private resizeService: GlobalUtils
  ) {
    this.fpoTargetUrl = this.constantsService.drupalUrl + '/page/mymedications-nomedications';
    this.selectedPlan$.subscribe((data) => {
      this.defaultPlan = data?.activePlan === 'true' ? true : false;
    });
  }

  ngOnInit() {
    const currentUserInfo = this.myMedicationDetailsService.getCurrentUserInfo();
    const medicationDetailsRequest = this.myMedicationDetailsService.getMyMedicationDetailsRequest(); 
    if (currentUserInfo.isDependentUser || (medicationDetailsRequest && medicationDetailsRequest.dependentId)) {
      if(currentUserInfo.dependentMemberInfo){
        this.dependentMemInfo = currentUserInfo.dependentMemberInfo.split(' ');
        this.basicMemInfoRx = new BasicMemInfoRxSummary();
        this.basicMemInfoRx .fullName = this.dependentMemInfo.join(' ');
      }
      // const dependentMemInfo = currentUserInfo.dependentMemberInfo.split(' ');

      // const basicMemInfoRx = new BasicMemInfoRxSummary();
      // basicMemInfoRx.fullName = dependentMemInfo.join(' ');

      this.basicMemInfo = new GetMemBasicInfoResponseModel();
      this.basicMemInfo.rxSummary = this.basicMemInfoRx;
    } else {
      this.medicationsService.getMemBasicInfo().subscribe(memBasicInfoResp => {
        this.basicMemInfo = memBasicInfoResp;
        if (this.basicMemInfo.rxSummary && !this.basicMemInfo.rxSummary.fullName) {
          const fullName = this.createFullName();
          this.basicMemInfo = { ...this.basicMemInfo, ...{ rxSummary: { ...this.basicMemInfo.rxSummary, ...{ fullName: fullName } } } };
        }
      });
    }
    this.myMedicationDetailsService.getMedicationDetails().subscribe(medicationDetailResp => {
      this.medicationDetail = medicationDetailResp;
      if (medicationDetailsRequest && medicationDetailsRequest.dependentId) {
        this.medicationDetail.rxDetails.dependentId = medicationDetailsRequest.dependentId.toString();
      }
    });
    this.populateDetailsFromSessionStorageIfEmpty();
    this.resizeService
      .getIsMobile()
      .pipe(takeUntil(this.unsubscribeHelper$))
      .subscribe((isMobile: boolean) => (this.ismobile = isMobile));
  }

  createFullName(): string {
    return this.basicMemInfo.rxSummary.memMiddleInitial
      ? [
          this.title.transform(this.basicMemInfo.rxSummary.memFirstName),
          ' ',
          this.title.transform(this.basicMemInfo.rxSummary.memMiddleInitial),
          ' ',
          this.title.transform(this.basicMemInfo.rxSummary.memLastName),
          ' (',
          this.title.transform(this.basicMemInfo.rxSummary.relationship),
          ')'
        ].join('')
      : [
          this.title.transform(this.basicMemInfo.rxSummary.memFirstName),
          ' ',
          this.title.transform(this.basicMemInfo.rxSummary.memLastName),
          ' (',
          this.title.transform(this.basicMemInfo.rxSummary.relationship),
          ')'
        ].join('');
  }

  ngOnDestroy() {
    this.alertService.clearError();
    this.unsubscribeHelper$.next();
    this.unsubscribeHelper$.complete();
  }

  populateDetailsFromSessionStorageIfEmpty() {
    const getmedicationDetailRequest = sessionStorage.getItem('medicationDetailRequest');
    if (!getmedicationDetailRequest) {
      const medDetails = sessionStorage.getItem('medicationDetailRequest');
      if (medDetails !== 'null') {
        this.myMedicationDetailsService.setMyMedicationDetailsRequest(JSON.parse(medDetails));
        this.fetchDependentDetailsFromSession();
      } else {
        this.router.navigate(['/my-medications']);
      }
    }
  }

  fetchDependentDetailsFromSession() {
    const getmedicationDetailRequest = sessionStorage.getItem('medicationDetailRequest');
    const getmedArray = [];
    getmedArray.push(JSON.parse(getmedicationDetailRequest));
    if (getmedicationDetailRequest && getmedArray[0] && getmedArray[0].dependentId) {
      const dependentDetails = sessionStorage.getItem('medicationDependentMemberInfo');
      if (dependentDetails !== undefined || 'null') {
        this.myMedicationDetailsService.setCurrentUserInfo(true, JSON.parse(dependentDetails));
      }
    }
  }

  getDirections() {
    this.swrveService.sendAppMessage(this.swrveEventNames.appClickMyMedicationsMap);
    const location = this.medicationDetail.rxDetails.pharmacy;
    const address = [location.address, ', ', location.city, ', ', location.state, ' ', location.zip].join('');
    const geoLocation = 'http://maps.google.com/?q=' + encodeURI(address);
    window.open(geoLocation, '_self');
  }

  navigateToClaimDetails(item) {
    this.swrveService.sendAppMessage(this.swrveEventNames.appClickMyMedicationsViewHistory);
    sessionStorage.setItem('claimId', item.claimNumber);
    this.router.navigateByUrl('/myClaims/claimdetails');
  }

  public goBack(): void {
    this.location.back();
  }

  navigateToDoctorDetails(doctorInfo): void {
    sessionStorage.setItem('providerName', doctorInfo.prescribingDoctor);
    sessionStorage.setItem('providerNumber', doctorInfo.prescribingDoctorNumber);
    if (doctorInfo.dependentId) {
      sessionStorage.setItem('docDependentId', doctorInfo.dependentId);
    }
    this.router.navigate([`/my-doctor/details`]);
  }
}
