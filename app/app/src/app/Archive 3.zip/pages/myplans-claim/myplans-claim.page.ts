import { Component, OnDestroy, OnInit } from '@angular/core';
import { LearnToLiveModel } from '@app/models/learn-to-live.model';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { SsoService } from '../sso/sso.service';
import { AuthToken } from '@app/models/auth-token.model';
import { ConstantsService } from '@app/services/constants.service';
import { IabService } from '@app/services/iab.service';
import { Router } from '@angular/router';
import { takeUntil } from 'rxjs/operators';
import { GlobalUtils } from '@app/utils/global.utils';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-myplans-claim',
  templateUrl: './myplans-claim.page.html',
  styleUrls: ['./myplans-claim.page.scss']
})
export class MyplansClaimPage implements OnInit, OnDestroy {
  @SelectSnapshot(AppSelectors.getLearnToLive) learnToLive: LearnToLiveModel;
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: AuthToken;
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;
  @SelectSnapshot(AppSelectors.getEbilling) ebilling: boolean;
  isAuthenticatedUser: boolean;
  public isFinancialFlag = false;
  ismobile: boolean;
  private unsubscribeHelper$: Subject<void> = new Subject<void>();

  constructor(private ssoService: SsoService,
              private iabService: IabService,
              private constantService: ConstantsService,
              private router: Router,
              private resizeService: GlobalUtils
  ) {}

  ngOnInit() {
    this.resizeService.getIsMobile().pipe(takeUntil(this.unsubscribeHelper$))
    .subscribe((isMobile: boolean) => this.ismobile = isMobile );
  }

  ngOnDestroy(): void {
    this.unsubscribeHelper$.next();
    this.unsubscribeHelper$.complete();
  }

  ionViewDidEnter() {
    this.isAuthenticatedUser = this.scopeName?.includes('AUTHENTICATED');
    this.isFinancialFlag = this.authToken?.isALG === 'true' || this.authToken?.isHEQ === 'true' ? true : false;
  }

  learntoLive() {
    sessionStorage.setItem('brandPlan', 'true');
    this.ssoService.openSSO('Learn2Live');
  }

  goBack() {
    this.router.navigate(['/brand-home']);
  }

  openFinancialLink() {
    if (this.authToken?.isHEQ === 'true') {
      this.ssoService.openSSO('heq');
    } else if (this.authToken?.isALG === 'true') {
      this.ssoService.openSSO('alg');
    }
  }

  ebillingLink() {
    this.ssoService.openSSO('ebilling');
  }

  openRewardLink() {
    this.iabService.create(this.constantService.reward360DealUrl);
  }
}
