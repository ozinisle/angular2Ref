import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { MyplansClaimPageRoutingModule } from './myplans-claim-routing.module';
import { MyplansClaimPage } from './myplans-claim.page';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MyplansClaimPageRoutingModule,
    FontAwesomeModule
  ],
  declarations: [MyplansClaimPage],
  providers: [InAppBrowser]
})
export class MyplansClaimPageModule {}
