import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MyplansClaimPage } from './myplans-claim.page';

const routes: Routes = [
  {
    path: '',
    component: MyplansClaimPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MyplansClaimPageRoutingModule {}
