import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { VirtualVisitPageRoutingModule } from './virtual-visit-routing.module';

import { VirtualVisitPage } from './virtual-visit.page';
import { VirtualVisitModalModule } from '@app/modals/virtual-visit-modal/virtual-visit-modal.module';
import { VirtualVisitModalComponent } from '@app/modals/virtual-visit-modal/virtual-visit-modal.component';
import { NgxsModule } from '@ngxs/store';
import { TelehealthState } from './store/state/telehealth.state';


@NgModule({
  imports: [
    CommonModule,
    IonicModule,
    VirtualVisitPageRoutingModule,
    VirtualVisitModalModule,
    ReactiveFormsModule,
    NgxsModule.forFeature([
      TelehealthState
    ])
  ],
  declarations: [ VirtualVisitPage ],
  entryComponents: [ VirtualVisitModalComponent ]
})
export class VirtualVisitPageModule {}
