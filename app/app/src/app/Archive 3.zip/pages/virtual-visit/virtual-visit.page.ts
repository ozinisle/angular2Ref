import { Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';

import {
  Observable,
  Subject
} from 'rxjs';
import {
  takeUntil,
} from 'rxjs/operators';
import {
  AcceptOutstandingDisclaimer,
  FetchOutstandingDisclaimer,
  Initialize,
  TeleHealthGlobalError,
  TeleHealthDuplicateEmailError
} from '@app/pages/virtual-visit/store/actions/telehealth.actions';
import { TelehealthSelectors } from '@app/pages/virtual-visit/store/selectors/telehealth.selectors';
import {
  Actions,
  ofActionCompleted,
  Select,
  Store
} from '@ngxs/store';
import { PopoverController } from '@ionic/angular';
import { ServiceFailureModalComponent } from '@app/components/service-failure-modal/service-failure-modal.component';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { ERROR_MSGS } from './virtual-visit.constants';


@Component({
  selector: 'app-virtual-visit',
  templateUrl: './virtual-visit.page.html',
  styleUrls: ['./virtual-visit.page.scss'],
})
export class VirtualVisitPage implements OnInit {
  private destroy$ = new Subject<void>();
  errorModal = false;

  @Select(TelehealthSelectors.getIsAuthenticated)
  public isAuthenticated$: Observable<boolean>;

  @SelectSnapshot(TelehealthSelectors.getIsAuthenticated)
  public isAuthenticated: boolean;

  @Select(TelehealthSelectors.getOutstandingDisclaimer)
  public outstandingDisclaimer$: Observable<string>;

  public isAcceptingOutstandingDisclaimer = false;

  constructor(private router: Router, private store: Store, private actions$: Actions, private popoverController: PopoverController) {}

  ngOnInit() {
  }

  public ionViewDidEnter() {
    this.actions$.pipe(ofActionCompleted(TeleHealthGlobalError), takeUntil(this.destroy$))
    .subscribe(() => {
      this.showError();
    });
    this.actions$.pipe(ofActionCompleted(TeleHealthDuplicateEmailError), takeUntil(this.destroy$))
    .subscribe(() => {
      this.showDuplicateEmailError();
    })
    this.isAcceptingOutstandingDisclaimer = false;
    this.store.dispatch(new Initialize());
    this.errorModal = false;
  }

  public ionViewDidLeave() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  public goBack() {
    this.router.navigate(['/brand-home']);
  }

  public acceptOutstandingDisclaimer() {
    this.isAcceptingOutstandingDisclaimer = true;
    this.store.dispatch(new AcceptOutstandingDisclaimer());
  }

  public declineOutstandingDisclaimer() {
    this.goBack();
  }


  private async showError() {
    if (!this.errorModal) {
      this.errorModal = true;
      const modal = await this.popoverController.create({
        component: ServiceFailureModalComponent,
        cssClass: 'virtual-visit-failure-modal',
        keyboardClose: false,
        showBackdrop: true,
        backdropDismiss: false,
        componentProps: {
          data: {
            showRetry: this.isAuthenticated,
            title: 'Error Occurred',
            description: ERROR_MSGS.ENROLLEMENT_ERROR,
            ctaRetry: 'Retry',
            cta2Text: 'Close'
          }
        }
      });
      modal.onDidDismiss().then(response => {
        if (response.data.retry) {
          this.store.dispatch(new FetchOutstandingDisclaimer());
        } else {
          this.router.navigate(['/home']);
        }
        this.errorModal = false;
      });
      await modal.present();
    }
  }

  private async showDuplicateEmailError() {
    if (!this.errorModal) {
      this.errorModal = true;
      const modal = await this.popoverController.create({
        component: ServiceFailureModalComponent,
        cssClass: 'virtual-visit-failure-modal',
        keyboardClose: false,
        showBackdrop: true,
        backdropDismiss: false,
        componentProps: {
          data: {
            showRetry: true,
            title: 'Error Occurred',
            description: '',
            ctaRetry: 'Retry',
            cta2Text: 'Close',
            duplicateEmailError: true
          }
        }
      });
      modal.onDidDismiss().then(response => {
        if (response.data.retry) {
          this.store.dispatch(new FetchOutstandingDisclaimer());
        } 
        this.errorModal = false;
      });
      await modal.present();
    }
  }
}
