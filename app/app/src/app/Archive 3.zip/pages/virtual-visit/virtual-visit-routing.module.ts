import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '@app/guards/auth.guard';
import { VirtualVisitGuardGuard } from './guards/virtual-visit-guard.guard';

import { VirtualVisitPage } from './virtual-visit.page';

const routes: Routes = [
  {
    path: '',
    canActivate: [AuthGuard],
    component: VirtualVisitPage
  },
  {
    path: 'get-started',
    canActivate: [VirtualVisitGuardGuard],
    loadChildren: () => import('./get-started/get-started.module').then(m => m.GetStartedPageModule)
  },
  {
    path: 'shipping-address',
    canActivate: [VirtualVisitGuardGuard],
    loadChildren: () => import('./pharmacy/shipping-address/shipping-address.module').then( m => m.ShippingAddressPageModule)
  },
  {
    path: 'waiting-room',
    canActivate: [VirtualVisitGuardGuard],
    loadChildren: () => import('./waiting-room/waiting-room.module').then( m => m.WaitingRoomPageModule)
  },
  {
    path: 'visit-summary',
    canActivate: [VirtualVisitGuardGuard],
    loadChildren: () => import('./visit-summary/visit-summary.module').then( m => m.VisitSummaryPageModule)
  },
  {
    path: 'visit-declined',
    loadChildren: () => import('./visit-declined/visit-declined.module').then( m => m.VisitDeclinedPageModule)
  },
  {
    path: 'visit-disconnected',
    loadChildren: () => import('./visit-declined/visit-declined.module').then( m => m.VisitDeclinedPageModule)
  },
  {
    path: 'appointment-payment',
    canActivate: [VirtualVisitGuardGuard],
    loadChildren: () => import('./appointment-payment/appointment-payment.module').then( m => m.AppointmentPaymentPageModule)
  },
  {
    path: 'appointment-confirmation',
    canActivate: [VirtualVisitGuardGuard],
    loadChildren: () => import('./appointment-confirmation/appointment-confirmation.module').then( m => m.AppointmentConfirmationPageModule)
  },
  {
    path: 'schedule-appointment',
    canActivate: [VirtualVisitGuardGuard],
    loadChildren: () => import('./schedule-appointment/schedule-appointment.module').then(m => m.ScheduleAppointmentPageModule)
  },
  {
    path: 'provider-details',
    canActivate: [VirtualVisitGuardGuard],
    loadChildren: () => import('./provider-details/provider-details.module').then(m => m.ProviderDetailsPageModule)
  },
  {
    path: 'schedule-provider-details',
    canActivate: [VirtualVisitGuardGuard],
    loadChildren: () => import('./appointment-provider-details/appointment-provider-details.module').then(m => m.AppointmentProviderDetailsPageModule)
  },
  {
    path: 'appointment-details',
    canActivate: [VirtualVisitGuardGuard],
    loadChildren: () => import('./appointment-details/appointment-details.module').then(m => m.AppointmentDetailsPageModule)
  },
  {
    path: 'appointment-get-started',
    canActivate: [VirtualVisitGuardGuard],
    loadChildren: () => import('./appointment-get-started/appointment-get-started.module').then( m => m.AppointmentGetStartedPageModule)
  },
  {
    path: 'well-connection',
    canActivate: [VirtualVisitGuardGuard],
    loadChildren: () => import('./well-connection/well-connection.module').then(m => m.WellConnectionPageModule)
  },
  {
    path: 'well-connection/:tab',
    canActivate: [VirtualVisitGuardGuard],
    loadChildren: () => import('./well-connection/well-connection.module').then(m => m.WellConnectionPageModule)
  },
  {
    path: 'medical-care',
    children: [
      {
        path: '',
        canActivate: [VirtualVisitGuardGuard],
        loadChildren: () => import('../virtual-visit/medical-care/medical-care.module').then(m => m.MedicalCarePageModule)
      }
    ]
  },
  {
    path: 'your-visit',
    children: [
      {
        path: '',
        canActivate: [VirtualVisitGuardGuard],
        loadChildren: () => import('../virtual-visit/your-visit/your-visit.module').then(m => m.YourVisitPageModule)
      },
      {
        path: 'additional-visit-details',
        children: [
          {
            path: '',
            canActivate: [VirtualVisitGuardGuard],
            loadChildren: () => import('../virtual-visit/your-visit/additional-visit-details/additional-visit-details.module').then(m => m.AdditionalVisitDetailsPageModule)
          }
        ]
      }
    ]
  },
  {
    path: 'choose-pharmacy',
    canActivate: [VirtualVisitGuardGuard],
    loadChildren: () => import('../virtual-visit/pharmacy/choose-pharmacy/choose-pharmacy.module').then(m => m.ChoosePharmacyPageModule)
  },
  {
    path: 'search-pharmacy',
    canActivate: [VirtualVisitGuardGuard],
    loadChildren: () => import('../virtual-visit/pharmacy/search-pharmacy/search-pharmacy.module').then(m => m.SearchPharmacyPageModule)
  },
  {
    path: 'choose-other-pharmacy',
    canActivate: [VirtualVisitGuardGuard],
    loadChildren: () => import('../virtual-visit/pharmacy/choose-other-pharmacy/choose-other-pharmacy.module').then(m => m.ChooseOtherPharmacyPageModule)
  },
  {
    path: 'payment',
    canActivate: [VirtualVisitGuardGuard],
    loadChildren: () => import('../virtual-visit/payment/payment.module').then(m => m.PaymentModule)
  },
  {
    path: 'appointment-provider-details',
    loadChildren: () => import('./appointment-provider-details/appointment-provider-details.module').then( m => m.AppointmentProviderDetailsPageModule)
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class VirtualVisitPageRoutingModule {}
