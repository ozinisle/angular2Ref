export enum VISIT_INFO_FORM_CONTROL_NAMES {
    VISIT_IS_FOR = 'visitIsFor',
    CALLBACK_NUMBER = 'callbackNumber',
    GUEST_EMAIL = 'emailAddress'
}

export enum TOPICS_FORM_CONTROL_NAMES {
    TOPIC = 'topic',
    OTHER_TOPIC = 'otherTopic',
    TRIAGE_QUESTIONS = 'triageQuestions'
}

export enum HISTORY_VITAL_FORM_CONTROL_NAMES {
    CONDITIONS = 'conditions',
    MEDICATIONS = 'medications',
    VITALS = 'vitals',
    ALLERGIES = 'allergies',
    ACCEPT_LEGAL = 'acceptLegal',
    SHARE_INFORMATION = 'shareInformation'
}

export enum ADDRESS_FORM {
    ADDRESS_1 = 'address1',
    ADDRESS_2 = 'address2',
    CITY = 'city',
    STATE_CODE = 'stateCode',
    ZIP_CODE = 'zipCode'
}

export enum CREDIT_CARD_FORM {
    CARD_NUM = 'digits',
    CVC_NUM = 'securityCode',
    NAME = 'billingName',
    MONTH = 'expirationMonth',
    YEAR = 'expirationYear'
}

export enum PAYMENT_FORM {
    CREDIT_CARD = 'creditCard',
    ADDRESS = 'address',
    COUPON_CODE = 'couponCode',
    CC_SELECTION = 'creditCardSelection'
}

export enum COUPON_CODE_FORM {
    COUPON_CODE = 'couponCode'
}

export enum SHARE_VISIT_SUMMARY_FORM {
    FAX_NUMBER = 'faxNumber',
    PCP_MAIL = 'pcpMail',
    ANOTHER_MAIL = 'anotherMail',
    FEEDBACK_RESPONSE = 'feedbackResponse',
    ACCEPT_HIPAA_NOTICE = 'acceptHipaaNotice'
}

export enum VISIT_RATINGS_FORM {
    PROVIDER_RATING = 'providerRating',
    VISIT_RATING = 'visitRating'
}

export enum PHARMACY_SELECTION_FORM_CONTROL_NAMES {
    PHARMACY_SELECTION = 'pharmacySelection'
}

export enum PHARMACY_SEARCH_FORM_CONTROL_NAMES {
    ZIP_CODE = 'zipCode',
    PHARMACY = 'pharmacy'
}

export const MOBILE_MESSAGES = {
    required: 'You must enter a valid phone number.',
    invalidNumber: 'You must enter a valid phone number.',
    invalidMobile: 'You must enter a valid phone number.',
    pattern: 'You must enter a valid phone number.'
};

export const EMAIL_MESSAGES = {
    required: 'You must enter a valid email address.',
    invalidEmail: 'You must enter a valid email address.',
    pattern: 'You must enter a valid email address.',
};

export const VISIT_IS_FOR_MESSAGES = {
    required: 'Select the member for the visit.',
};


export const CARD_NUMBER_MESSAGES = {
    required: 'You must enter the valid card number.'
};

export const CARD_NAME_MESSGES = {
    required: 'You must enter the valid card name.',
    invalidField: 'You must enter the valid card name.'
};

export const CARD_CCV_MESSGES = {
    required: 'Enter the valid CVC number',
    invalidField: 'Enter the valid CVC number'
};

export const CARD_MONTH_MESSGES = {
    required: 'You must select the valid month',
};

export const CARD_YEAR_MESSGES = {
    required: 'You must select the valid year',
};

export const ADDRESS_1_MESSGES = {
    required: 'You must enter the valid Address',
    pattern: 'You must enter the valid Address',
    invalidField: 'You must enter the valid Address'
};

export const CITY_MESSGES = {
    required: 'You must enter the valid City',
    invalidCityNameString: 'City Name cannot have Special Characters',
    pattern: 'You must enter the valid City',
};

export const ZIP_CODE_MESSGES = {
    required: 'You must select the valid Zip Code',
    pattern: 'You must select the valid Zip Code',
};

export const STATE_CODE_MESSGES = {
    required: 'You must enter the valid State',
};

export const ACCEPT_LEGAL_MESSAGE = {
    required: 'Acknowledge the Privacy Practices Notice.',
};

export const ACCEPT_SHARE_SUMMARY = {
    required: 'Acknowledge to share your health summary and previuos visits.',
};

export const COUPON_CODE_MESSAGES = {
    required: 'You must enter the valid coupon code.',
};

export const FEEDBACK_MESSAGES = {
    required: 'You must choose an option',
};

export const FAX_NMBER_MESSAGES = {
    pattern: 'You must enter a valid fax number.',
    invalidMobile: 'You must enter a valid fax number.'
};

export const EMAIL_ADDRESS_MESSAGES = {
    pattern: 'You must enter a valid email address .',
};

export const PHARMACY_TITLES = {
   IN_STORE: 'IN-STORE PICKUP',
   MAIL_ORDER: 'MAIL ORDER'
}

export const TELEHEALTH_ROUTES = {
    HOME : '/home',
    VIRTUAL_VISIT : '/virtual-visit',
    WELL_CONNECTION_LANDING : '/virtual-visit/well-connection',
    PROVIDER_DETAILS: '/virtual-visit/provider-details',
    SCHEDULE_APPOINTMENT: '/virtual-visit/schedule-appointment',
    SCHEDULE_PROVIDER_DETAILS: '/virtual-visit/schedule-provider-details',
    PROVIDER_SEARCH: '/virtual-visit/medical-care/clinician-search',
    GET_STARTED: '/virtual-visit/get-started',
    YOUR_VISIT: '/virtual-visit/your-visit',
    ADDITIONAL_VISIT_DETAILS : '/virtual-visit/your-visit/additional-visit-details',
    PAYMENT: '/virtual-visit/payment',
    PHARMACY_LANDING: '/virtual-visit/choose-other-pharmacy',
    PHARMACY: '/virtual-visit/choose-pharmacy',
    MEDICAL_CARE: '/virtual-visit/medical-care',
    APPOINTMENT_DETAILS: '/virtual-visit/appointment-details',
    INBOX: '/virtual-visit/well-connection/inbox',
    SENT_MESSAGES: '/virtual-visit/well-connection/sent-messages',
    TEXT_REMINDERS: '/virtual-visit/well-connection/preferences',

}

export const MONTHS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];

export const ERROR_MSGS = {
    ENROLLEMENT_ERROR : 'Sorry, we\'re experiencing technical difficulties. Please try again later. If you need immediate assistance, call 1-855-292-6355.'
}

export const VITALS_MESSAGES = {
    BLOOD_PRESSURE_SYSTOLIC : {
        pattern: 'Invalid value'
    },
    BLOOD_PRESSURE_DIASTOLIC : {
        pattern: 'Invalid value'
    },
    WEIGHT_MINOR : {
        required: 'Weight is required.',
        pattern: 'Range 0 to 15 ounces.',
        max: 'Range 0 to 15 ounces.',
        min: 'Range 0 to 15 ounces.'
    },
    WEIGHT_MAJOR : {
        required: 'Weight is required.',
        pattern: 'Range 0 to 1500 pounds.',
        max: 'Range 0 to 1500 pounds.',
        min: 'Range 0 to 1500 pounds.'
    },
    HEIGHT_MINOR : {
        required: 'Height is required.',
        pattern: 'Range 0 to 11 inches.',
        max: 'Range 0 to 11 inches.',
        min: 'Range 0 to 11 inches.',
    },
    HEIGHT_MAJOR : {
        required: 'Height is required.',
        pattern: 'Range 0 to 10 feet.',
        max: 'Range 0 to 10 feet.',
        min: 'Range 0 to 10 feet'

    },
    TEMPERATURE : {
        required: 'Enter Temperature',
        pattern: 'Invalid value',
        max: 'Max temperature is 108F.'
    }
};

export const AMEX_STARTING_DIGITS = ['34', '37'];

export const CARD_LENGTH = {
    AMEX: 17,
    NON_AMEX : 19
}

export const CVC_LENGTH = {
    AMEX: 4,
    NON_AMEX : 3
}

export const CVC_PLACEHOLDER = {
    AMEX: '0000',
    NON_AMEX : '000'
}

export const VISIT_INCOMPLETE_TITLE = {
    DECLINE : 'Clinician declined Visit',
    DISCONNECT: 'Clinician no longer available'
};

export const VISIT_INCOMPLETE_MESSAGE = {
    DECLINE : 'has declined your request for a visit. You will not be charged.',
    DISCONNECT: ' is no longer available. You will not be charged.'
};

export const IN_TAKE_TITLE = {
    VISIT : 'Before Your Visit...',
    SCHEDULE : 'Schedule Appointment'
};

export const IN_TAKE_STEPS = {
    VISIT : 4,
    SCHEDULE : 2
};

export enum CREATE_MESSAGE {
    CONTACT = 'contact',
    SUBJECT = 'subject',
    TOPIC = 'topic',
    BODY = 'body',
    SHARE_SUMMARY = 'shareSummary',
}

export  enum TEXT_REMINDER {
    TEXTS_ENABLED = 'textsEnabled'
}

export const CONTACT_MEESSAGES = {
    required: 'Send To is required.'
}

export const TOPIC_MEESSAGES = {
    required: 'Topic is required.'
}
