import { MyBlueGeneralAPIRequestModel } from '../../../models/generic-app.model';

import {
  MaintenanceMedicationModelInterface,
  PartnerModelInterface,
  PharmacyAddressModelInterface,
  PharmacyModelInterface,
  UpdatePharmacyMedicationModelInterface
} from './pillpack-generic-models.interface';

export class UpdatePharmacyMedicationRequestModel extends MyBlueGeneralAPIRequestModel implements UpdatePharmacyMedicationModelInterface {
  partner: PartnerModelInterface;
  medications: MaintenanceMedicationModelInterface[];
  key2id: string;
}

export class PharmacyModel implements PharmacyModelInterface {
  id: string;
  url: string;
  text: string;
  name: string;
  phoneNumber: string;
  address: PharmacyAddressModelInterface;
}
