import { Location, TitleCasePipe } from '@angular/common';
import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MYBLUE } from '@app/app.constants';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { AuthToken } from '@app/models/auth-token.model';
import { PostLoginModel } from '@app/models/post-login.model';
import { OrderSummaryModel } from '@app/pages/my-pillpack/model/rx-order-summary.model';
import { STATES_LIST } from '@app/pages/my-profile/contact-info/contact-info.component.constant';
import { AlertService } from '@app/services/alert.service';
import { MyPillpackService } from '@app/services/my-pillpack.service';
import { ProfileService } from '@app/services/profile.service';
import { ValidationService } from '@app/services/validation.service';
import { SetLoader, SetPostLogin } from '@app/store/actions/app.actions';
import { FetchProfile, SetVerificationCategory } from '@app/store/actions/profile.action';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { GlobalUtils } from '@app/utils/global.utils';
import { ModalController } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Store } from '@ngxs/store';
import { cloneDeep } from 'lodash-es';
import { Subject } from 'rxjs';
import { flatMap, takeUntil } from 'rxjs/operators';
import { GetMemberProfileResponseModel } from '../../my-profile/models/get-member-profile-request.model';
import { CreditCardComponent } from '../components/credit-card/credit-card.component';
import {
  MaintenanceMedicationModelInterface,
  PartnerModelInterface,
  UpdatePharmacyMedicationModelInterface
} from '../model/pillpack-generic-models.interface';
import { UpdatePharmacyMedicationRequestModel } from '../model/pillpack-generic.models';
import { ProfileModalComponent } from '../profile-modal/profile-modal.component';

@Component({
  selector: 'app-medications',
  templateUrl: './medications.component.html',
  styleUrls: ['./medications.component.scss']
})
export class MedicationsComponent implements OnInit, OnDestroy {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: AuthToken;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getCryptoToken) cryptoToken: any;
  @SelectSnapshot(AppSelectors.getPostLoginInfo) postLoginInfo: PostLoginModel;
  @SelectSnapshot(AppSelectors.getMemProfile) memProfile: GetMemberProfileResponseModel;

  @ViewChild('creditCard') creditCard: CreditCardComponent;
  ismobile: boolean;
  private unsubscribeHelper$: Subject<void> = new Subject<void>();
  dataReturned: any;
  profile: GetMemberProfileResponseModel;
  error: any;
  profileEditForm: FormGroup;
  addressEditForm: FormGroup;
  rxOrderSummary: OrderSummaryModel;
  addOTCFlag = false;
  hasNonPharmacyMed: any;
  medications: any;
  selectedMedications: any[];
  selectedOTCs: any[];
  pillpackForm: FormGroup;
  pillpackQuestionsForm: FormGroup;
  currentStep = 1;
  popupCnt = 'Email';
  popuplink = 'email';
  diplayEmailAdress = '';
  sendingpageUrl = 'my-pillpack';
  memberName = '';
  isMemberPregnancy = false;
  isAddingOTC = false;

  editAddress = true;
  editEmail = true;
  editPhone = true;
  alreadyEmailExist = false;
  registeredUserOnly = false;
  address3 = '';
  showDependantDisclaimer = false;
  isVerifyEmailProcessComplete: boolean;
  isVerifiedEmail: boolean;
  otcSummaryTotal: number;
  maintenanceMedicationsSummaryTotal: number;
  estimatedOrderTotal: number;
  hasMaintenanceMeds: boolean;
  selectedMaintenanceMedications: any[];
  selectedOTCsToTransfer: any[];
  partnerId: string;
  tokenId: string;
  isIncompleteHandoff: boolean;
  isPillPackEnrolledThisSession: boolean;
  phoneMask: Array<any>;
  isStepTwoFail = false;
  isStepThreeFail = false;
  isCPDPPromotion = false;
  shippingAddress: any = [
    {
      address1: '',
      address2: '',
      city: '',
      state: '',
      zipcode: '',
      phoneNumber: '',
      emailAddress: ''
    }
  ];

  statesList = STATES_LIST;

  options: any = [
    {
      question: 'Do you have any allergies?',
      choices: ['Yes', 'No'],
      placeholder: 'Please list your allergies, separated by commas.',
      hint: 'Allergy 1, Allergy 2'
    },
    {
      question: 'Do you have any health conditions?',
      choices: ['Yes', 'No'],
      placeholder: 'Please list your health conditions, separated by commas.',
      hint: 'Health Condition 1, Health Condition 2'
    },
    {
      question: 'Are you pregnant or nursing?',
      choices: ['Yes', 'No']
    }
  ];
  emailMessages = {
    required: 'You must enter your email address.',
    invalidEmail: 'You must enter a valid email address.'
  };
  mobileNumberMessages = {
    required: 'You must enter a valid phone number.',
    invalidNumber: 'You must enter a valid phone number.',
    invalidMobile: 'You must enter a valid phone number.'
  };
  mask = { mask: this.validationService.phoneMask, guide: false };

  allowedChars = new Set('0123456789'.split('').map(c => c.charCodeAt(0)));

  check(event: KeyboardEvent) {
    // 31 and below are control keys, don't block them.
    if (event.keyCode > 31 && !this.allowedChars.has(event.keyCode)) {
      event.preventDefault();
    }
  }
  zipCode(event) {
    if (event.target.value.length > 0) {
      const zipValid = /^[0-9]+$/.test(event.target.value);
      if (!zipValid) {
        event.target.value = '';
        this.addressEditForm.get('zipcode').setValue('');
      }
    }
  }
  constructor(
    private router: Router,
    private fb: FormBuilder,
    private store: Store,
    private alertService: AlertService,
    private validationService: ValidationService,
    private profileService: ProfileService,
    private myPillpackService: MyPillpackService,
    private titleCase: TitleCasePipe,
    private pillPackService: MyPillpackService,
    private modalController: ModalController,
    private location: Location,
    private resizeService: GlobalUtils
  ) {
    this.rxOrderSummary = new OrderSummaryModel(42.0, 106.0, this.isAddingOTC, 148.0, 0, 0);
    this.isVerifyEmailProcessComplete = false;
    this.isIncompleteHandoff = false;
    this.memberName = this.authToken.firstName;

    this.pillpackForm = this.fb.group({
      medications: new FormArray([], minSelectedCheckboxes(1)),
      hasNonPharmacyMed: [false]
    });
    this.myPillpackService.getDiscountedVitaminsAndOTCs();
    this.profileEditForm = this.fb.group({
      useridin: '',
      isEditableAddress: false,
      userState: '',
      isDirectPay: false,
      address1: ['', this.editAddress ? [Validators.required, this.validationService.specialCharactersValidator()] : []],
      address2: ['', this.editAddress ? [this.validationService.specialCharactersValidator()] : []],
      dob: ['', []],
      city: ['', this.editAddress ? [Validators.required, this.validationService.specialCharactersValidator()] : []],
      state: ['', this.editAddress ? [Validators.required] : []],
      zip: ['', this.editAddress ? [Validators.required, Validators.minLength(5)] : []],
      emailAddress: ['', this.editEmail ? [Validators.required, this.validationService.emailValidator()] : []],
      fullName: '',
      healthInfo: this.fb.array([]),
      health: this.fb.group({
        allergies: new FormControl(),
        conditions: new FormControl()
      }),
      phoneNumber: [
        this.editPhone ? [Validators.required, this.validationService.phoneValidator(), this.validationService.mobileValidator()] : []
      ],
      isVerifiedEmail: false,
      isVerifiedMobile: false,
      isEmailOptedIn: false,
      isMobileOptedIn: false
    });

    function minSelectedCheckboxes(min = 1) {
      const validator: ValidatorFn = (formArray: FormArray) => {
        const totalSelected = formArray.controls
          // get a list of checkbox values (boolean)
          .map(control => control.value)
          // total up the number of checked checkboxes
          .reduce((prev, next) => (next ? prev + next : prev), 0);

        // if the total is not greater than the minimum, return the error message
        return totalSelected >= min ? null : { required: true };
      };

      return validator;
    }

    this.pillpackQuestionsForm = this.fb.group({
      healthInfo: this.fb.array([]),
      health: this.fb.group({
        allergies: new FormControl(),
        conditions: new FormControl()
      })
    });

    this.profileService.fetchProfileInfo(this.useridin).subscribe(profileInfo => {
      const dobDate = new Date(profileInfo.dob);
      const timeDiff = Math.abs(Date.now() - +dobDate);
      const memberAge = Math.floor(timeDiff / (1000 * 3600 * 24) / 365);
      this.diplayEmailAdress = profileInfo.emailAddress;
      this.isVerifiedEmail = profileInfo.isVerifiedEmail;
      this.isMemberPregnancy = memberAge >= 13 && memberAge <= 60 && profileInfo.gender === 'F';
      this.options.map((healthOptions, i) => {
        if (i < 2 || this.isMemberPregnancy) {
          (this.pillpackQuestionsForm.get('healthInfo') as FormArray).push(this.addQuesFormGroup());
        }
      });
      (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[0].get('healthHintAns').setValue(profileInfo.health.allergies);
      if (profileInfo.health.allergies.length > 0) {
        (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[0]
          .get('healthquestion')
          .setValue(profileInfo.health.allergies.length > 0);
      }
      (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[1].get('healthHintAns').setValue(profileInfo.health.conditions);
      if (profileInfo.health.conditions.length > 0) {
        (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[1]
          .get('healthquestion')
          .setValue(profileInfo.health.conditions.length > 0);
      }
    });

    this.pillPackService.getMedicationsForSelf().subscribe(medications => {
      this.medications = medications;

      this.hasMaintenanceMeds = this.medications && this.medications.length > 0;

      const medicationsArray = this.pillpackForm.controls.medications as FormArray;

      if (this.medications && this.medications.length > 0) {
        this.medications.map(() => {
          medicationsArray.push(new FormControl(false));
        });
      }
    });
  }

  processComplete($event) {
    this.isVerifyEmailProcessComplete = event.returnValue;
    this.gotoStep(5);
  }

  backNav() {
    if (this.currentStep > 1) {
      const step = this.currentStep - 1;
      this.gotoStep(step);
    } else if (this.currentStep === 1) {
      if (this.isAddingOTC) {
        this.isAddingOTC = false;
        this.currentStep = 1;
        return false;
      } else {
        this.location.back();
      }
    }
  }

  getStpsArray(n: number = 4) {
    return Array.from(Array(n), (x, index) => index + 1);
  }

  onQuestionClick(index: number) {
    const isValid: boolean = (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[index].get('healthquestion').value;
    const healthHintAnswer = (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[index].get('healthHintAns');
    if (isValid && index < 2) {
      healthHintAnswer.setValidators([Validators.required]);
      healthHintAnswer.setValue(healthHintAnswer.value);
    } else {
      healthHintAnswer.setValidators([]);
      healthHintAnswer.setValue('');
      healthHintAnswer.updateValueAndValidity();
    }
  }

  maintenanceTotalChange(checkbox: any, medications: MaintenanceMedicationModelInterface) {
    this.selectedMedications =
      this.medications && this.medications.length > 0 ? this.medications.filter(med => med.isSelected === true) : [];
    if (sessionStorage.getItem('selectedOTCs')) {
      this.selectedOTCs = JSON.parse(sessionStorage.getItem('selectedOTCs'));
    }
    if (checkbox.isSelected) {
      this.maintenanceMedicationsSummaryTotal = this.maintenanceMedicationsSummaryTotal + medications.copay;
      this.estimatedOrderTotal = this.estimatedOrderTotal + medications.copay;
    } else {
      this.maintenanceMedicationsSummaryTotal = this.maintenanceMedicationsSummaryTotal - medications.copay;
      this.estimatedOrderTotal = this.estimatedOrderTotal - medications.copay;
    }
  }

  selectedOptions() {
    return this.medications.filter(opt => opt.isSelected).map(opt => opt.isSelected);
  }

  async completePillPackHandoff() {
    const handoffRequest = {
      useridin: this.useridin,
      partner: {
        id: this.partnerId,
        status: this.isIncompleteHandoff ? 'incomplete' : 'done',
        token: this.tokenId
      },
      key2id: this.cryptoToken.key2id
    };
    await this.pillPackService.completePillPackHandoff(handoffRequest).then((res: any) => {
      if (Number(res.result) < 0) {
        this.alertService.setAlert('', res['displaymessage'], AlertType.Failure);
        sessionStorage.setItem('isCompleteHanddoff', 'false');
        this.gotoStep(4);
        return false;
      } else {
        sessionStorage.setItem('isCompleteHanddoff', 'true');
        // TODO: This seems weird to recall a service to change current state - should just change state directly
        this.store.dispatch(new SetPostLogin());
        this.navigatToConformationScreen();
        return true;
      }
    });
  }

  async sendPillPackMedications(request) {
    this.store.dispatch(new SetLoader(true));
    await this.pillPackService
      .addMedications(request)
      .then((res: any) => {
        this.store.dispatch(new SetLoader(false));
        if (Number(res.result) < 0) {
          this.alertService.setAlert('', res['displaymessage'], AlertType.Failure);
          sessionStorage.setItem('isAddedMedicationsComplete', 'false');
          this.isIncompleteHandoff = true;
          this.gotoStep(4);
          return false;
        } else {
          sessionStorage.setItem('isAddedMedicationsComplete', 'true');
          this.completePillPackHandoff();
          return true;
        }
      })
      .then(() => this.store.dispatch(new SetLoader(false)));
  }

  createAddMedicationsRequest() {
    //Get Selected Maintenance Medications

    const selectedMedications =
      this.medications && this.medications.length > 0 ? this.medications.filter(med => med.isSelected === true) : [];
    //Get Selected OTCs
    if (sessionStorage.getItem('selectedOTCs')) {
      this.selectedOTCs = JSON.parse(sessionStorage.getItem('selectedOTCs'));
    }
    if (!this.partnerId) {
      this.partnerId = sessionStorage.getItem('partnerId');
    }
    //CALL Add Medications API here

    const request: UpdatePharmacyMedicationModelInterface = new UpdatePharmacyMedicationRequestModel();
    const thisPartner = {} as PartnerModelInterface;
    thisPartner.id = this.partnerId;

    //Add Partner to Request
    request.partner = thisPartner;

    request.useridin = this.useridin;

    this.selectedMaintenanceMedications = selectedMedications.map(med => {
      return {
        ndcCd: med.prescription.ndcCd,
        rxcui: med.prescription.ndcCd,
        description: med.prescription.description,
        isSelfPrescribed: false,
        shouldChase: true,
        doseTimes: '',
        genericName: med.prescription.genericName,
        form: '',
        daysSupply: 30,
        lastFill: med.prescription.lastFill ? med.prescription.lastFill : '0000-00-00',
        strength: '',
        copay: med.prescription.copay,
        pharmacy: {
          id: med.pharmacy.id,
          name: med.pharmacy.name,
          phoneNumber: med.pharmacy.phoneNumber,
          address: med.pharmacy.address
            ? {
                address1: med.pharmacy.address.address1,
                address2: med.pharmacy.address.address2,
                city: med.pharmacy.address.city,
                state: med.pharmacy.address.state,
                zipcode: med.pharmacy.address.zipcode
              }
            : undefined
        },
        prescriber: {
          firstName: med.prescriber.firstName,
          lastName: med.prescriber.lastName,
          middleInitial: med.prescriber.middleInitial,
          id: med.prescriber.id,
          deaNumber: med.prescriber.deaNumber,
          phoneNumber: med.prescriber.phoneNumber,
          address: med.prescriber.address
            ? {
                address1: med.prescriber.address.address1,
                address2: med.prescriber.address.address2,
                city: med.prescriber.address.city,
                state: med.prescriber.address.state,
                zipcode: med.prescriber.address.zipcode
              }
            : undefined
        }
      };
    });
    if (this.selectedOTCs) {
      this.selectedOTCsToTransfer = this.selectedOTCs.map(med => {
        let sNonInPacketOTC: any = [];
        if (med.orderDetails && !med.inPackets) {
          med.orderDetails.forEach(orderDetail => {
            sNonInPacketOTC.push(orderDetail.orderCount + '  of ' + orderDetail.strength + ', Requested');
          });
        }

        if (sNonInPacketOTC.length > 0) {
          sNonInPacketOTC = sNonInPacketOTC.join(',');
        } else {
          sNonInPacketOTC = '';
        }

        let sDossage: any = [];
        let totalCount = 0;
        if (med.orderDetails) {
          med.orderDetails.forEach(orderDetail => {
            sDossage.push(orderDetail.strength);
            totalCount += orderDetail.orderCount;
          });
        }

        if (sDossage.length > 0) {
          sDossage = sDossage.join(',');
        } else {
          sDossage = '';
        }

        let sPacketTimePacketCount: any = [];
        if (med.orderDetails) {
          med.orderDetails.forEach(orderDetail => {
            if (med.inPackets) {
              for (let i = 0; i < orderDetail.orderCount; i++) {
                sPacketTimePacketCount.push(orderDetail.time + ':' + orderDetail.minute + orderDetail.mer);
              }
            }
          });
        }

        if (sPacketTimePacketCount.length > 0) {
          sPacketTimePacketCount = sPacketTimePacketCount.join(',');
        } else {
          sPacketTimePacketCount = '';
        }

        return {
          ndcCd: med.upc,
          rxcui: med.rxcui,
          description: '',
          isSelfPrescribed: true,
          shouldChase: false,
          doseTimes: sPacketTimePacketCount,
          dosage: sNonInPacketOTC,
          inPackets: med.inPackets,
          genericName: med.name,
          form: med.doseType,
          daysSupply: 30,
          lastFill: '0000-00-00',
          copay: '',
          strength: med.strength,
          count: totalCount
        };
      });
    }

    //Add Selected Maintenance Meds to Request
    request.medications = this.selectedMaintenanceMedications;

    //Add Selected OTC
    if (this.selectedOTCsToTransfer) {
      request.medications = request.medications.concat(this.selectedOTCsToTransfer);
    }
    //Add Encrypt Key
    request.key2id = this.cryptoToken.key2id;
    return request;
  }

  onCompleteHandHandoffClicked($event) {
    //goto step 5
    this.currentStep = $event.number;
    this.tokenId = $event.tokenId;
    this.gotoStep(5);
  }

  async updatePharmacyUser(req, step) {
    this.store.dispatch(new SetLoader(true));
    this.pillPackService
      .updatePharmacyUser(req)
      .toPromise()
      .then((res: any) => {
        this.store.dispatch(new SetLoader(false));
        if (res.errormessage) {
          if (step === 3) {
            this.isStepTwoFail = true;
          } else if (step === 4) {
            this.isStepThreeFail = true;
          }
        }
        if (!this.isStepTwoFail && !this.isStepThreeFail) {
          this.isIncompleteHandoff = false;
        } else {
          this.isIncompleteHandoff = true;
        }
        if (!res.errormessage) {
          this.isIncompleteHandoff = false;
        } else if (res.errormessage) {
          if (res.result === -95026) {
            this.alreadyEmailExist = true;
            this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
            this.gotoStep(3);
          }
        }
        if (step === 4 && res.result !== -95026) {
          this.profileEmailUpdate();
        }
      })
      .catch(() => this.store.dispatch(new SetLoader(false)));
  }

  navigatToConformationScreen() {
    this.router.navigate(['my-pillpack/confirmation']);
    this.sendNotification();
    sessionStorage.removeItem('otcTotal');
    sessionStorage.removeItem('selectedOTCs');
  }

  async gotoStep(step: number, disableFlag: boolean = false) {
    if (disableFlag) {
      return;
    }

    const { hasNonPharmacyMed } = this.pillpackForm.value;
    document.getElementById('payment-section').classList.add('hide');
    if (step === 5 && (this.isVerifiedEmail || this.isVerifyEmailProcessComplete)) {
      const request = this.createAddMedicationsRequest();
      await this.sendPillPackMedications(request);
    }

    if (step === 4 && !this.isVerifiedEmail && !this.isVerifyEmailProcessComplete) {
      this.currentStep = 5;
      this.gotoStep(5);
    }
    if (step === 1) {
      this.alertService.clearError();
    }
    if (step === 2) {
      this.alertService.clearError();
      this.isStepTwoFail = false;
    }

    if (step === 3) {
      if (!this.alreadyEmailExist) {
        this.alertService.clearError();
      }
      this.isStepThreeFail = false;

      if (!this.alertService.hasError('displaymessage')) {
        const prfEdtFrm = this.profileEditForm.value;

        prfEdtFrm.useridin = this.profile.useridin;
        prfEdtFrm.health.allergies = (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[0].get('healthHintAns').value;
        prfEdtFrm.health.conditions = (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[1].get('healthHintAns').value;
        if ((this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[2]) {
          prfEdtFrm.healthInfo.pregnant = (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[2].get(
            'healthquestion'
          ).value;
        }
        const allergiestr = prfEdtFrm.health.allergies + '';
        const conditionstr = prfEdtFrm.health.conditions + '';

        const allerarr = allergiestr != null && allergiestr !== '' ? allergiestr.replace(' ', '').split(',') : '';
        const condarr = conditionstr != null && conditionstr !== '' ? conditionstr.replace(' ', '').split(',') : '';
        const req = {
          useridin: this.useridin,
          member: {
            partner: {
              id: this.partnerId
            },
            pregnant: prfEdtFrm.healthInfo.pregnant,
            conditions: condarr.length > 0 ? condarr : undefined,
            allergies: allerarr.length > 0 ? allerarr : undefined,
            key2id: this.cryptoToken.key2id
          }
        };
        await this.updatePharmacyUser(req, step);
      }
    }

    if (step === 4) {
      document.getElementById('payment-section').classList.remove('hide');
      const prfEdtFrm = this.profileEditForm.value;

      prfEdtFrm.useridin = this.profile.useridin;
      const req = {
        useridin: this.useridin,
        member: {
          partner: {
            id: this.partnerId
          },
          address: {
            street: this.addressEditForm.get('address1').value,
            street2: this.addressEditForm.get('address2').value,
            city: this.addressEditForm.get('city').value,
            state: this.addressEditForm.get('state').value,
            zipcode: this.addressEditForm.get('zipcode').value
          },
          key2id: this.cryptoToken.key2id,
          mobileNumber: (this.addressEditForm.get('phoneNumber').value + '').replace(/-/g, ''),
          emailAddress: this.addressEditForm.get('emailAddress').value
        }
      };

      prfEdtFrm.phoneNumber = (this.addressEditForm.get('phoneNumber').value + '').replace(/-/g, '');
      prfEdtFrm.phoneType = 'MOBILE';
      await this.updatePharmacyUser(req, step);
      if (!this.profile.isVerifiedMobile && this.profile.phoneNumber !== prfEdtFrm.phoneNumber) {
        this.profileService
          .updateProfile(prfEdtFrm, false, false, true, false, false)
          .pipe(
            flatMap(result => {
              return this.profileService.fetchProfileInfo(this.useridin);
            })
          )
          .subscribe();
      }
    }

    if (step === 6) {
      this.router.navigate(['my-pillpack/confirmation']);
      this.sendNotification();
    }

    if (this.currentStep === 2) {
      const prfEdtFrm = this.profileEditForm.value;

      prfEdtFrm.useridin = this.profile.useridin;
      prfEdtFrm.health.allergies = (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[0].get('healthHintAns').value;
      prfEdtFrm.health.conditions = (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[1].get('healthHintAns').value;
      this.profileService
        .updateProfile(prfEdtFrm, false, false, false, false, true)
        .pipe(
          flatMap(result => {
            return this.profileService.fetchProfileInfo(this.useridin);
          })
        )
        .subscribe();
    }
    if (hasNonPharmacyMed && this.currentStep === 1) {
      this.isAddingOTC = !(step === 1 && this.currentStep === 1 && hasNonPharmacyMed);
    } else {
      setTimeout(() => (this.currentStep = step), 0);
    }
    window.scrollTo(0, 0);
    const elementList = document.querySelectorAll('.targetElement');
    const element = elementList[0] as HTMLElement;
    element.scrollIntoView({ behavior: 'smooth' });
  }

  addQuesFormGroup(): FormGroup {
    return this.fb.group({
      healthHintAns: [''],
      healthquestion: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.partnerId = sessionStorage.getItem('partnerId');

    if (this.postLoginInfo) {
      this.isCPDPPromotion = this.postLoginInfo.isCPDPPromotion;
    }

    if (!this.isCPDPPromotion) {
      this.router.navigate(['home']);
    }

    if (this.isCPDPPromotion && !this.partnerId) {
      this.router.navigate(['my-pillpack/landing']);
    }

    this.otcSummaryTotal = 0;
    this.maintenanceMedicationsSummaryTotal = 0;
    this.estimatedOrderTotal = 0;

    if (sessionStorage.getItem('isCompleteHanddoff') != null && sessionStorage.getItem('isCompleteHanddoff') !== '') {
      this.isPillPackEnrolledThisSession = JSON.parse(sessionStorage.getItem('isCompleteHanddoff'));
    } else {
      this.isPillPackEnrolledThisSession = false;
    }
    sessionStorage.setItem('selectedOTCs', JSON.stringify([]));

    if (this.memProfile === null) {
      this.profileService.fetchProfileInfo(this.useridin).subscribe(res => {
        this.profileService.setProfile(res);
        this.updateProfile();
      });
    } else {
      this.updateProfile();
    }
    this.resizeService.getIsMobile().pipe(takeUntil(this.unsubscribeHelper$))
    .subscribe((isMobile: boolean) => this.ismobile = isMobile );
  }

  profileEmailUpdate() {
    const prfEdtFrm = this.profileEditForm.value;
    prfEdtFrm.useridin = this.profile.useridin;
    const currentEmail = this.profile.emailAddress;
    const updatedEmail = this.addressEditForm.get('emailAddress').value + '';
    if (!this.isVerifiedEmail && !(currentEmail === updatedEmail)) {
      prfEdtFrm.emailAddress = this.addressEditForm.get('emailAddress').value + '';
      this.profileService
        .updateProfile(prfEdtFrm, false, true, false, false, false)
        .pipe(
          flatMap(result => {
            this.profileService.fetchProfileInfo(this.useridin).subscribe(res => {
              this.profileService.setProfile(res);
            });
            return this.profileService.fetchProfileInfo(this.useridin);
          })
        )
        .subscribe(profile => {
          this.diplayEmailAdress = profile.emailAddress;
        });
    }
  }

  rightSideCntClick(medicationIndex, maintananceFlag) {
    if (maintananceFlag) {
      const medication = document.querySelector('.medi_' + medicationIndex) as HTMLElement;
      medication.click();
    }
  }

  hasNonPharmacyLink() {
    const hasmedication = document.querySelector('.hasMaintanace') as HTMLElement;
    hasmedication.click();
  }

  async ProfileModal(emailText) {
    if (emailText === 'mobile') {
      this.popupCnt = 'mobile phone';
      this.popuplink = 'phone';
    } else {
      this.popupCnt = 'email';
      this.popuplink = 'email';
    }
    const modal = await this.modalController.create({
      component: ProfileModalComponent,

      componentProps: {
        popupCnt: this.popupCnt,
        popuplink: this.popuplink,
        modelId: 'profile'
      }
    });

    modal.onDidDismiss().then(dataReturned => {
      if (dataReturned !== null) {
        this.dataReturned = dataReturned.data;
      }
    });

    return await modal.present();
  }

  updateProfile() {
    this.profile = cloneDeep(this.memProfile);
    if (this.profile) {
      if (!this.profile.phoneType) {
        this.profile.phoneType = 'MOBILE';
      }
      const userRole = this.authToken.scopename;
      this.registeredUserOnly = userRole === 'REGISTERED-AND-VERIFIED';
      this.address3 = '';
      this.shippingAddress.address1 = this.profile.address1;
      this.shippingAddress.address2 = this.profile.address2;
      this.shippingAddress.city = this.profile.city;
      this.shippingAddress.state = this.profile.state;
      this.shippingAddress.zipcode = this.profile.zip;
      this.shippingAddress.phoneNumber = this.profile.phoneNumber;
      this.shippingAddress.emailAddress = this.profile.emailAddress;
      const numericNumberReg = '^-?[0-9]\\d*(\\.\\d{1,2})?$';
      const defaultNumber = this.shippingAddress.phoneNumber ? this.formatPhone(this.shippingAddress.phoneNumber) : '';
      this.addressEditForm = this.fb.group({
        address1: [
          this.shippingAddress.address1,
          this.editAddress ? [Validators.required, this.validationService.specialCharactersValidator()] : []
        ],
        address2: [this.shippingAddress.address2, this.editAddress ? [this.validationService.specialCharactersValidator()] : []],
        city: [
          this.shippingAddress.city,
          this.editAddress ? [Validators.required, this.validationService.specialCharactersValidator()] : []
        ],
        state: [this.shippingAddress.state, this.editAddress ? [Validators.required] : []],
        zipcode: [
          this.shippingAddress.zipcode,
          this.editAddress ? [Validators.required, Validators.minLength(5), Validators.pattern(numericNumberReg)] : []
        ],
        phoneNumber: [
          defaultNumber,
          this.editAddress ? [Validators.required, this.validationService.phoneValidator(), this.validationService.mobileValidator()] : []
        ],
        emailAddress: [
          this.shippingAddress.emailAddress,
          this.editAddress ? [Validators.required, this.validationService.emailValidator()] : []
        ]
      });

      if ((this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls.length >= 2) {
        (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[0]
          .get('healthHintAns')
          .setValue(this.profile.health.allergies);
        if (this.profile.health.allergies.length > 0) {
          (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[0]
            .get('healthquestion')
            .setValue(this.profile.health.allergies.length > 0);
        }
        (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[1]
          .get('healthHintAns')
          .setValue(this.profile.health.conditions);
        if (this.profile.health.conditions.length > 0) {
          (this.pillpackQuestionsForm.get('healthInfo') as FormArray).controls[1]
            .get('healthquestion')
            .setValue(this.profile.health.conditions.length > 0);
        }
      }
    }
  }
  AddOTCVitamin() {
    this.addOTCFlag = !this.addOTCFlag;
    if (!this.addOTCFlag) {
      this.selectedOTCs = [];
      sessionStorage.setItem('selectedOTCs', JSON.stringify(this.selectedOTCs));
      this.otcSummaryTotal = 0.0;
      this.estimatedOrderTotal = this.maintenanceMedicationsSummaryTotal + this.otcSummaryTotal;
    }
  }
  getBasePrice(price: number) {
    return ('' + price).split('.')[0];
  }

  checkHealthText(event) {
    const healthText = event.target.value;
    if (healthText.length > 1000) {
      event.target.value = healthText.substr(0, 1000);
    }
  }

  ngOnDestroy() {
    this.unsubscribeHelper$.next();
    this.unsubscribeHelper$.complete();
  }

  addedOTC($event) {
    this.otcSummaryTotal = $event;
    this.estimatedOrderTotal = this.maintenanceMedicationsSummaryTotal + this.otcSummaryTotal;
  }

  onDoneAddingOTC($event) {
    this.isAddingOTC = false;
    if ($event.length < 1) {
      if (this.selectedMaintenanceMedications.length < 1) {
        setTimeout(() => (this.currentStep = 1), 0);
      } else {
        setTimeout(() => (this.currentStep = 2), 0);
      }
    } else {
      setTimeout(() => (this.currentStep = 2), 0);
    }
    const elementList = document.querySelectorAll('.targetElement');
    const element = elementList[0] as HTMLElement;
    element.scrollIntoView({ behavior: 'smooth' });
  }

  formatPhone(inputPhoneNumber) {
    if (inputPhoneNumber !== undefined && inputPhoneNumber !== null && inputPhoneNumber !== '') {
      let phoneNumber: string = inputPhoneNumber;
      phoneNumber = phoneNumber.replace(/-/g, '');
      const areaCode = phoneNumber.slice(0, 3);
      const number = phoneNumber.slice(3);
      return areaCode + '-' + number.slice(0, 3) + '-' + number.slice(3);
    } else {
      return '';
    }
  }

  verifyEmail(emailId?: string) {
    if (!this.isVerifiedEmail) {
      this.alertService.clearError();
      const email = 'Email';
      const currScope = this.authToken ? this.authToken.scopename : '';
      if (currScope === 'AUTHENTICATED-AND-VERIFIED' || currScope === 'REGISTERED-AND-VERIFIED') {
        this.sendcommchlaccesscode(emailId ? emailId : this.diplayEmailAdress, '').subscribe(res => {
          if (res) {
            this.alertService.clearError();
            // only if success
            this.store.dispatch(new SetVerificationCategory(email));
            this.profileService.maskedVerify = this.maskEmailId(emailId ? emailId : this.diplayEmailAdress);
            sessionStorage.setItem('maskedVerifyPhone', 'N');
            sessionStorage.setItem('maskedVerify', this.profileService.maskedVerify);
            this.navigateToVerifyScreen();
          } else {
            if (res['displaymessage']) {
              this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
            }
          }
        });
      } else {
        this.sendaccesscode('EMAIL', emailId ? emailId : this.diplayEmailAdress).subscribe(
          res => {
            if (res) {
              sessionStorage.setItem('sendCodeRes', res);

              this.alertService.clearError();
              // only if success
              this.store.dispatch(new SetVerificationCategory(email));
              const sentMailId = JSON.parse(sessionStorage.getItem('sendCodeRes'));
              const userId = sentMailId && sentMailId['commChannel'];
              this.profileService.maskedVerify = this.maskEmailId(emailId ? emailId : userId);
              sessionStorage.setItem('maskedVerifyPhone', 'N');
              sessionStorage.setItem('maskedVerify', this.profileService.maskedVerify);
              this.navigateToVerifyScreen();
            } else {
              if (res['displaymessage']) {
                this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
              }
            }
          },
          err => {
            MYBLUE.error('error', err);
          }
        );
      }
    }
  }

  navigateToVerifyScreen() {
    this.store.dispatch(new FetchProfile());
    this.isVerifyEmailProcessComplete = false;
    this.alertService.setAlert('Verification code sent!.', '', AlertType.Success);
  }

  maskEmailId(userId: string): string {
    return userId
      ? userId.replace(/^(.{3})(.*)(@.*)$/, (_, firstCharacter, charToMasked, domain) => {
          return `${firstCharacter}${charToMasked.replace(/./g, '*')}${domain}`;
        })
      : userId;
  }

  private sendaccesscode(commChannelType, commChannel) {
    return this.profileService.sendaccesscode(commChannelType, commChannel, this.useridin);
  }

  private sendNotification() {
    const shippingAmt = this.rxOrderSummary.shippingAmount === 0 ? 'No Cost' : this.rxOrderSummary.shippingAmount + '';
    const dispenserAmt = this.rxOrderSummary.dispenserAmount === 0 ? 'No Cost' : this.rxOrderSummary.dispenserAmount + '';
    const medicationAmt = this.maintenanceMedicationsSummaryTotal != null ? this.maintenanceMedicationsSummaryTotal.toFixed(2) : 0.0;
    const vitaminsAmt = this.otcSummaryTotal != null ? this.otcSummaryTotal.toFixed(2) : 0.0;
    const totalAmt = this.estimatedOrderTotal != null ? this.estimatedOrderTotal.toFixed(2) : 0.0;
    const yourMedications = 'Your Medications~$' + medicationAmt;
    const yourVitaminsAndOTCs = 'Your Vitamins & OTCs~$' + vitaminsAmt;
    const shipping = 'Shipping~' + shippingAmt;
    const dispenser = 'Reusable Dispenser~' + dispenserAmt;
    const yourTotal = 'Your Estimated Total~$' + totalAmt;
    const notificationRequest = {
      useridin: this.useridin,
      commChannel: this.diplayEmailAdress,
      commChannelType: 'EMAIL',
      templateKeyword: 'CPDPNOTIFICATION_EMAIL',
      key2id: this.cryptoToken.key2id,
      notificationParms: [
        {
          keyName: 'firstName',
          keyValue: this.authToken && this.authToken.firstName ? this.titleCase.transform(this.authToken.firstName) : ''
        },
        {
          keyName: 'OrderDetails',
          keyValue: [yourMedications, yourVitaminsAndOTCs, shipping, dispenser, yourTotal]
        }
      ]
    };

    this.profileService.sendUpdateNotification(notificationRequest).subscribe(res => {});
  }

  private sendcommchlaccesscode(email, mobile) {
    return this.profileService.sendcommchlaccesscode(email, mobile.replace(/\D/g, ''), this.useridin);
  }

  ionViewDidEnter() {
    const pillpackNav = sessionStorage.getItem('pillpackNav');
    if (pillpackNav === 'true') {
      sessionStorage.setItem('pillpackNav', 'false');
      this.gotoStep(1);
    }
  }
}
