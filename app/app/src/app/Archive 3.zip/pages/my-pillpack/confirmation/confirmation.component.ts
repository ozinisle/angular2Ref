import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { AlertService } from '@app/services/alert.service';
import { ProfileService } from '@app/services/profile.service';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AppSelectors } from '@app/store/selectors/app.selectors';

/* tslint:disable */
@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.scss']
})
export class ConfirmationComponent implements OnInit {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  currentStep: Number = 2;
  diplayEmailAddress: string;
  ACopyofEmailStr: string;
  SampleEmail: Array<{ text: string }> = [
    { text: 'PillPack will work with your doctor and pharmacist to transfer your prescriptions.' },
    { text: "PillPack will notify you of the date you'll receive your first shipment." },
    { text: 'Your medications will be delivered in easy-to-open, presorted packets.' },
    { text: 'Your prescriptions will be refilled automatically and shipped to your door every month.' }
  ];
  constructor(private router: Router, private alertService: AlertService, private profileService: ProfileService) {}

  ngOnInit() {
    this.profileService.fetchProfileInfo(this.useridin).subscribe(profileInfo => {
      this.diplayEmailAddress = profileInfo.emailAddress;
      this.ACopyofEmailStr = 'A copy of your receipt as been emailed to ' + this.diplayEmailAddress;
      this.alertService.setAlert("Success! We've emailed your sign up confirmation to " + this.diplayEmailAddress, '', AlertType.Success);
    });
  }

  backNav() {
    this.router.navigate(['/home']);
  }

  ngOnDestroy() {
    this.alertService.clearError();
  }
}
