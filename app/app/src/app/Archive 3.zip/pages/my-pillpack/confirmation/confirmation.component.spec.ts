import { HttpClientTestingModule } from '@angular/common/http/testing';
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { ModalController } from '@ionic/angular';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { AlertService } from '@app/services/alert.service';
import { ConfirmationComponent } from './confirmation.component';
import { RouterTestingModule } from '@angular/router/testing';
import { IonicModule } from '@ionic/angular';
import { NgxsModule } from '@ngxs/store';
import { DatePipe } from '@angular/common';
import { AppState } from '@app/store/state/app.state';
import { mocks } from '@testing/constants/mocks.service';
import { ProfileService } from '@app/services/profile.service';
import { ConstantsService } from '@app/services/constants.service';
import { Router } from '@angular/router';
import { AlertsComponent } from '@app/components/alerts/alerts.component';
import { SafePipeModule } from '@app/pipes/safe-html/safe-html.module';

describe('Mypillpack Confirmation Page', () => {
  let component: ConfirmationComponent;
  let fixture: ComponentFixture<ConfirmationComponent>;
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);
  let mockProfileService;
  let router: Router;
  let alertService: AlertService;
  beforeEach(waitForAsync(() => {
    mockProfileService = mocks.service.profileService;
    TestBed.configureTestingModule({
      declarations: [ConfirmationComponent, AlertsComponent],
      providers: [
        {
          provide: ProfileService,
          useValue: mockProfileService
        },
        AlertService,
        ConstantsService,
        DatePipe,
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        }
      ],
      imports: [
        HttpClientTestingModule,
        IonicModule,
        SafePipeModule,
        RouterTestingModule,
        NgxsModule.forRoot([AppState]),
        NgxsSelectSnapshotModule.forRoot()
      ]
    }).compileComponents();
    router = TestBed.inject(Router);
    alertService = TestBed.inject(AlertService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check ion header content', () => {
    const element = document.querySelector('ion-title');
    expect(element.innerHTML.length).toBeGreaterThan(0);
  });

  it('should check title content', () => {
    component.currentStep = 2;
    component = fixture.componentInstance;
    fixture.detectChanges();
    const element = document.querySelector('.header_text');
    expect(element.innerHTML.length).toBeGreaterThan(0);
  });

  it('should check aCopyofEmailStr address', () => {
    component.ngOnInit();
    expect(component.ACopyofEmailStr.length).toBeGreaterThan(0);
  });

  it('should check diplayEmailAddress  address', () => {
    component.ngOnInit();
    expect(component.diplayEmailAddress.length).toBeGreaterThan(0);
  });

  it('should check router Navigation', () => {
    const routerSpy = spyOn(router, 'navigate');
    component.backNav();
    expect(routerSpy).toHaveBeenCalled();
  });

  it('should check ngDestroy clear service', () => {
    const alertServiceSpy = spyOn(alertService, 'clearError');
    component.ngOnDestroy();
    expect(alertServiceSpy).toHaveBeenCalled();
  });

  it('should check ngOnit alert service', () => {
    const alertServiceSpy = spyOn(alertService, 'setAlert');
    component.ngOnInit();
    expect(alertServiceSpy).toHaveBeenCalled();
  });
});
