import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MYBLUE } from '@app/app.constants';
import { IabService } from '@app/services/iab.service';
import { ModalController, NavParams } from '@ionic/angular';

@Component({
  selector: 'app-profile-modal',
  templateUrl: './profile-modal.component.html',
  styleUrls: ['./profile-modal.component.scss']
})
export class ProfileModalComponent implements OnInit {
  popupCnt: string;
  popuplink: string;
  modelId: string;

  constructor(
    private modalController: ModalController,
    private navParams: NavParams,
    private router: Router,
    private iabService: IabService
  ) {}

  ngOnInit() {
    MYBLUE.table(this.navParams);
    this.popupCnt = this.navParams.data.popupCnt;
    this.popuplink = this.navParams.data.popuplink;
    this.modelId = this.navParams.data.modelId;
  }

  async closeModal() {
    await this.modalController.dismiss();
  }

  async navigateProfilePage() {
    this.closeModal();
    sessionStorage.setItem('pillpack', 'true');
    this.router.navigate(['/myprofile']);
  }

  openPillPackLink() {
    this.closeModal();
    if (sessionStorage.getItem('consentLink') != null && sessionStorage.getItem('consentLink') !== '') {
      const consentLink = sessionStorage.getItem('consentLink');
      if (consentLink === 'https://www.pillpack.com') {
        const iabRef = this.iabService.create(consentLink);
        iabRef.on('loaderror').subscribe(msg => {
          MYBLUE.error('Load error', msg);
        });
      } else {
        const iabRef = this.iabService.create(consentLink);
        iabRef.on('loaderror').subscribe(msg => {
          MYBLUE.error('Load error', msg);
        });
      }
    }
  }

  closePillPackModal() {
    this.closeModal();
  }

  closeEmailModals() {
    this.closeModal();
  }
}
