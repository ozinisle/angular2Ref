import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Observable, Subject } from 'rxjs';
import { of } from 'rxjs/observable/of';
import { catchError, debounceTime, distinctUntilChanged, filter, startWith, switchMap, takeUntil } from 'rxjs/operators';
import { MyPillpackService } from '@app/services/my-pillpack.service';
import { GlobalUtils } from '@app/utils/global.utils';

@Component({
  selector: 'app-add-otc',
  templateUrl: './add-otc.component.html',
  styleUrls: ['./add-otc.component.scss']
})
export class AddOtcComponent implements OnInit, OnDestroy {
  @Output() doneAddingOTC = new EventEmitter();
  @Output() addedOTC = new EventEmitter<number>();
  @Input() otcSummaryTotal: number;
  @Input() medicationsLength: number;
  @Input() estimatedOrderTotal: number;
  @Input() maintenanceMedicationsSummaryTotal: number;
  @Input() hasMaintenanceMeds: boolean;

  addOtcForm: FormGroup;
  thisItem: any;
  medications$: Observable<any[]>;
  selectedMedication: any;
  selectedOrderDetails: any[] = [{ strength: '', time: '', minute: '', mer: '', orderCount: 0 }];
  selectedMedications: any[];
  valid = false;
  strength = '';
  searchFieldValue = '';
  otcTotal: number;
  inPackets = false;
  orderDetails: {
    time: string;
    minute: string;
    mer: string;
    strength: string;
    orderCount: number;
  }[] = [{ time: '', minute: '', mer: '', strength: '', orderCount: 0 }];
  orderCount = 1;
  capCount = [];
  disCountedItems: any = [];
  medicationsAdded: any = [];
  doseType = { T: 'Tablet(s)', C: 'Capsule(s)', S: 'Spray(s)', O: 'Tube(s)' };
  public searchPlaceHolderText = 'Search for a Vitamin or an OTC';
  public disablePlaceHolder = false;
  public searchFocusFlag = false;
  searchResultsEmpty = false;
  showVitaminOtcFlag = false;
  ismobile: boolean;
  private unsubscribeHelper$: Subject<void> = new Subject<void>();

  constructor(private myPillpackService: MyPillpackService,
              private fb: FormBuilder,
              private resizeService: GlobalUtils) {
    this.getCount();
    this.getDiscountedVitaminsAndOTCs();
  }

  ngOnInit() {
    this.addOtcForm = this.fb.group({
      searchText: ['']
    });
    this.medications$ = this.addOtcForm.get('searchText').valueChanges.pipe(
      startWith(''),
      filter(text => text?.length > 2),
      debounceTime(400),
      distinctUntilChanged(),
      switchMap((query: string) => {
        this.resetSelection();
        return this.myPillpackService.getVitaminsAndOTC(query);
      }),
      catchError(error => of([]))
    );

    if (sessionStorage.getItem('selectedOTCs') !== '') {
      this.medicationsAdded = JSON.parse(sessionStorage.getItem('selectedOTCs'));
    }
    this.medications$.subscribe(data => {
      if (data) {
        this.searchResultsEmpty = data?.length <= 0;
      }
    });
    this.resizeService.getIsMobile().pipe(takeUntil(this.unsubscribeHelper$))
    .subscribe((isMobile: boolean) => this.ismobile = isMobile );
  }

  ngOnDestroy() {
    this.unsubscribeHelper$.next();
    this.unsubscribeHelper$.complete();
  }

  searchFocus() {
    this.searchFocusFlag = true;
  }

  searchFocusOut() {
    this.searchFocusFlag = false;
  }

  searchText(event) {
    if (event.target.value?.length >= 3) {
      this.medications$ = this.myPillpackService.getVitaminsAndOTC(event.target.value);
      this.medications$.subscribe(data => {
        if (data) {
          if (data.length > 0) {
            this.searchResultsEmpty = false;
          } else {
            this.searchResultsEmpty = true;
          }
        }
      });
    } else if (event.target.value?.length === 0) {
      this.clearSearchText();
    }

    this.disablePlaceHolder = !!event.target.value;
  }

  resetSelection() {
    this.selectedOrderDetails = [{ strength: '', time: '', minute: '', mer: '', orderCount: 0 }];
  }

  getDiscountedVitaminsAndOTCs() {
    this.disCountedItems = this.myPillpackService.getDiscountedVitaminsAndOTCs();
  }

  pasteSearch(event) {
    if (event.length >= 3) {
      this.medications$ = this.myPillpackService.getVitaminsAndOTC(event);
      this.medications$.subscribe(data => {
        if (data) {
          if (data.length > 0) {
            this.searchResultsEmpty = false;
          } else {
            this.searchResultsEmpty = true;
          }
        }
      });
    } else if (event.length === 0) {
      this.clearSearchText();
    }

    this.disablePlaceHolder = !!event;
  }

  isAddable(orderDetails: any[]) {
    const arrValidCond = [];
    orderDetails.map(orderDet => {
      if (this.selectedMedication.inPackets) {
        this.valid =
          this.strength !== '' && orderDet.time !== '' && orderDet.minute !== '' && orderDet.mer !== '' && orderDet.orderCount !== 0;
        if (!this.valid) {
          arrValidCond.push(true);
        }
      } else {
        this.valid = this.strength !== '' && orderDet.orderCount !== 0;
        if (!this.valid) {
          arrValidCond.push(true);
        }
      }
    });
    this.valid = arrValidCond.length < 1;
    return this.valid;
  }

  getType(T: string) {
    return this.doseType[T];
  }

  getCount() {
    if (this.capCount.length === 0) {
      for (let i = 0, j = 1; i <= 9; i++, j++) {
        this.capCount[i] = j;
      }
    }
    return this.capCount;
  }

  removeItem(deleteMedication: any) {
    const index = this.medicationsAdded.findIndex(medication => medication.upc === deleteMedication.upc);
    this.medicationsAdded.splice(index, 1);
    sessionStorage.setItem('selectedOTCs', JSON.stringify(this.medicationsAdded));
    this.otcTotal = this.otcTotal - (deleteMedication.price / deleteMedication.count) * deleteMedication.orderDetails[0].orderCount * 30;
    sessionStorage.setItem('otcTotal', this.otcTotal.toString());
    this.onAddedOTC();
  }

  clearSearchText() {
    this.addOtcForm.patchValue({ searchText: null });
    this.disablePlaceHolder = false;
    this.searchFieldValue = null;
    this.selectedMedication = null;
    this.medications$ = null;
    this.searchResultsEmpty = false;
  }

  onOptionSelect(selection, isDiscounted) {
    this.strength = '';
    this.resetSelection();
    this.searchResultsEmpty = false;
    this.searchFieldValue = selection;
    this.disablePlaceHolder = true;
    this.medications$ = null;
    this.searchFocusFlag = false;
    this.selectedMedications = this.myPillpackService.getSelectedVitaminsAndOTC(selection, isDiscounted);
    this.selectedMedication = this.selectedMedications[0];
    if (this.selectedMedications.length === 1) {
      this.strength = this.selectedMedications[0].strength;
    }
    if (this.medicationsAdded?.length !== 0) {
      const selectAddedMeds = this.medicationsAdded?.filter(
        addedMeds => addedMeds.name.toLowerCase() === this.selectedMedications[0].name.toLowerCase()
      )[0];
      if (selectAddedMeds) {
        const selectedMed = this.selectedMedications.filter(selMeds => selMeds.upc.toLowerCase() === selectAddedMeds.upc.toLowerCase())[0];
        if (selectedMed) {
          this.selectedMedication = selectedMed;
        }
      }
      this.medicationsAdded?.map(medication => {
        if (medication.name === this.selectedMedication.name) {
          this.selectedOrderDetails = Object.assign([], medication.orderDetails);
          this.strength = medication.orderDetails[0].strength;
        }
      });
    }
    if (isDiscounted) {
      this.showVitaminOtcFlag = !this.showVitaminOtcFlag;
    }
  }

  setSelectedOrderDetails(index, event, key) {
    if (event.target.value !== '' && index >= 0 && this.selectedOrderDetails && this.selectedOrderDetails.length > 0) {
      switch (key) {
        case 'mer':
          this.selectedOrderDetails[index].mer = event.target.value;
          break;
        case 'minute':
          this.selectedOrderDetails[index].minute = event.target.value;
          break;
        case 'time':
          this.selectedOrderDetails[index].time = event.target.value;
          break;
        case 'orderCount':
          this.selectedOrderDetails[index].orderCount = event.target.value;
          break;
      }
    }
  }

  showVitaminOtc() {
    this.showVitaminOtcFlag = !this.showVitaminOtcFlag;
  }

  onDoseSelect(event) {
    const selection = event.target.value;
    if (selection !== '') {
      this.strength = event.target.value;
      this.selectedMedication = this.selectedMedications.filter(otcs => otcs.strength.toLowerCase() === selection.toLowerCase())[0];
    }
  }

  displayFn(value: any) {
    return value && value.name ? value.name : '';
  }
  addMedicationsToCart(selectedOrderDetails: any[]) {
    this.searchResultsEmpty = false;
    let totalMedCount = 0;
    this.inPackets = this.selectedMedication.inPackets;
    if (this.isAddable(selectedOrderDetails)) {
      selectedOrderDetails.map(orderdet => {
        orderdet.strength = this.strength;
        totalMedCount = totalMedCount + orderdet.orderCount;
      });

      if (this.medicationsAdded.length !== 0) {
        this.medicationsAdded.map(medication => {
          if (medication.name === this.selectedMedication.name) {
            const index = this.medicationsAdded.findIndex(medication => medication.name === this.selectedMedication.name);
            this.medicationsAdded.splice(index, 1);
          }
        });
      }

      this.medicationsAdded.push(
        Object.assign({}, this.selectedMedication, {
          orderDetails: selectedOrderDetails
        })
      );

      sessionStorage.setItem('selectedOTCs', JSON.stringify(this.medicationsAdded));
      this.otcSummaryTotal = this.otcSummaryTotal + (this.selectedMedication.price / this.selectedMedication.count) * totalMedCount;
      sessionStorage.setItem('otcTotal', this.otcSummaryTotal.toString());
      this.onAddedOTC();
      this.clearSearchText();
      this.selectedMedication = null;
      this.resetSelection();
      this.medications$ = null;
    }
  }

  addAnotherPacketTime(selectedOrderDetails: any[]) {
    if (selectedOrderDetails.length < 10) {
      this.selectedOrderDetails.push({ strength: '', time: '', minute: '', mer: '', orderCount: 0 });
      this.valid = false;
    }
  }

  getCost(medication: any) {
    let cost = 0.0;
    const unitCost = medication.price / medication.count;
    medication.orderDetails.map(item => {
      if (medication.inPackets) {
        cost = cost + unitCost * item.orderCount * 30;
      } else {
        cost = cost + item.orderCount * medication.price;
      }
    });
    return cost;
  }

  onAddedOTC() {
    this.otcTotal = 0.0;
    this.medicationsAdded.map(medication => {
      this.otcTotal = +this.otcTotal + this.getCost(medication);
    });
    this.addedOTC.emit(this.otcTotal);
  }

  onDoneAddingOTC() {
    this.doneAddingOTC.emit(this.medicationsAdded);
  }
}
