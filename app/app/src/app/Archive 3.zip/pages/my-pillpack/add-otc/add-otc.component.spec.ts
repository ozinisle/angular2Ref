import { HttpClientTestingModule } from '@angular/common/http/testing';
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { ModalController } from '@ionic/angular';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { AlertService } from '@app/services/alert.service';
import { MyPillpackService } from '@app/services/my-pillpack.service';
import { AddOtcComponent } from './add-otc.component';
import { RouterTestingModule } from '@angular/router/testing';
import { IonicModule } from '@ionic/angular';
import { NgxsModule } from '@ngxs/store';
import { DatePipe } from '@angular/common';
import { AppState } from '@app/store/state/app.state';
import { mocks } from '@testing/constants/mocks.service';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { OrderPipe } from '@app/pipes/order/order.pipe';
import { AlertsComponent } from '@app/components/alerts/alerts.component';
import { RxOrderSummaryComponent } from '@app/pages/my-pillpack/components/rx-order-summary/rx-order-summary.component';

xdescribe('Add OTC Page', () => {
  let component: AddOtcComponent;
  let fixture: ComponentFixture<AddOtcComponent>;
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);
  let mockMyPillpackService;
  const formBuilder = new FormBuilder();
  beforeEach(waitForAsync(() => {
    mockMyPillpackService = mocks.service.myPillpackService;
    TestBed.configureTestingModule({
      declarations: [AddOtcComponent, OrderPipe, AlertsComponent, RxOrderSummaryComponent],
      providers: [
        {
          provide: MyPillpackService,
          useValue: mockMyPillpackService
        },
        AlertService,
        DatePipe,
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        },
        {
          provide: FormBuilder,
          useValue: formBuilder
        },
        OrderPipe
      ],
      imports: [
        HttpClientTestingModule,
        IonicModule,
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule,
        NgxsModule.forRoot([AppState]),
        NgxsSelectSnapshotModule.forRoot()
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddOtcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check discounted list', () => {
    expect(component.disCountedItems.length).toBeGreaterThan(0);
  });

  it('should check discounted items in template', () => {
    component.showVitaminOtcFlag = true;
    component = fixture.componentInstance;
    fixture.detectChanges();
    const element = document.querySelector('.discount-list ion-text');
    expect(element.childNodes[0].textContent.length).toBeGreaterThan(0);
  });

  it('should check Add OTC title', () => {
    const element = document.querySelector('.dis_vit_otc');
    expect(element.textContent.length).toBeGreaterThan(0);
  });

  it('should check searchResultsEmpty flag after the call searchText', () => {
    component.searchText({ target: { value: 'fish oil' } });
    expect(component.searchResultsEmpty).toBeFalsy();
  });

  it('should check searchFieldValue flag after the call searchText', () => {
    component.searchText({ target: { value: '' } });
    expect(component.searchFieldValue).toBeNull();
    expect(component.selectedMedication).toBeNull();
  });

  it('should check showVitaminOtc flag after the showVitaminOtc', () => {
    component.showVitaminOtc();
    expect(component.showVitaminOtcFlag).toBeTruthy();
  });

  it('should check strength: from selected vitamin item after  onOptionSelect method call', () => {
    component.onOptionSelect('Acetaminophen', false);
  });

  it('should check mer after setSelectedOrderDetails method call', () => {
    component.selectedOrderDetails = [{ strength: '', time: '', minute: '', mer: '', orderCount: 0 }];
    component.setSelectedOrderDetails(0, { target: { value: '04' } }, 'mer');
    expect(component.selectedOrderDetails[0].mer.length).toBeGreaterThan(0);
  });

  it('should check time after setSelectedOrderDetails method call', () => {
    component.selectedOrderDetails = [{ strength: '', time: '', minute: '', mer: '', orderCount: 0 }];
    component.setSelectedOrderDetails(0, { target: { value: '12' } }, 'time');
    expect(component.selectedOrderDetails[0].time.length).toBeGreaterThan(0);
  });

  it('should check minute after setSelectedOrderDetails method call', () => {
    component.selectedOrderDetails = [{ strength: '', time: '', minute: '', mer: '', orderCount: 0 }];
    component.setSelectedOrderDetails(0, { target: { value: '30' } }, 'minute');
    expect(component.selectedOrderDetails[0].minute.length).toBeGreaterThan(0);
  });
});
