import { HttpClientTestingModule } from '@angular/common/http/testing';
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { ModalController } from '@ionic/angular';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { AlertService } from '@app/services/alert.service';
import { MyPillpackService } from '@app/services/my-pillpack.service';
import { LandingComponent } from './landing.component';
import { RouterTestingModule } from '@angular/router/testing';
import { IonicModule } from '@ionic/angular';
import { NgxsModule, Store } from '@ngxs/store';
import { DatePipe } from '@angular/common';
import { AppState } from '@app/store/state/app.state';
import { of } from 'rxjs';
import { mocks } from '@testing/constants/mocks.service';
import { ConstantsService } from '@app/services/constants.service';
import { AlertsComponent } from '@app/components/alerts/alerts.component';

describe('Landing Page', () => {
  let component: LandingComponent;
  let fixture: ComponentFixture<LandingComponent>;
  let store: Store;
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);
  let mockMyPillpackService;

  beforeEach(waitForAsync(() => {
    mockMyPillpackService = mocks.myPillpackService;
    TestBed.configureTestingModule({
      declarations: [LandingComponent, AlertsComponent],
      providers: [
        {
          provide: MyPillpackService,
          useValue: mockMyPillpackService
        },
        AlertService,
        ConstantsService,
        DatePipe,
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        }
      ],
      imports: [
        HttpClientTestingModule,
        IonicModule,
        RouterTestingModule,
        NgxsModule.forRoot([AppState]),
        NgxsSelectSnapshotModule.forRoot()
      ]
    }).compileComponents();

    store = TestBed.inject(Store);

    const mock = {
      isCPDPEnrolled: false,
      isCPDPHandedoff: false,
      isCPDPPromotion: true,
      isKYMember: false,
      repPayeeFalg: true
    };
    spyOn(store, 'select').and.returnValue(of(mock)); // be sure to mock the implementation here
    spyOn(store, 'selectSnapshot').and.returnValue(mock); // same here
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check ion header content', () => {
    const element = document.querySelector('ion-title');
    expect(element.innerHTML.length).toBeGreaterThan(0);
  });

  // TEST FAILS AT TIMES
  it('should check iondidenter functionality', () => {
    const spy = spyOn(document, 'querySelectorAll').and.callThrough();
    document.querySelectorAll('.pillpack-landingpage-container');
    component.ionViewDidEnter();
    expect(spy).toHaveBeenCalled();
  });

  it('should check the cpdppromotion flag after ngonit', () => {
    component.ngOnInit();
    expect(component.isCPDPPromotion).toBeTruthy();
  });

  it('should check the banner content bottom values', () => {
    const element = document.querySelector('.banner_cnt_btm');
    expect(element.innerHTML.length).toBeGreaterThan(0);
  });

  it('should check the how it works title', () => {
    const element = document.querySelector('.how-it-works');
    expect(element.innerHTML.length).toBeGreaterThan(0);
  });

  it('should check the how it works steps content', () => {
    const element = document.querySelector('.how_its_work_cont');
    expect(element.childElementCount).toBeGreaterThan(0);
  });

  it('should check the first child of toggle element content', () => {
    const element = document.querySelector('.accor_main_cnt');
    expect(element.firstChild.childNodes[0].childNodes[0].textContent.length).toBeGreaterThan(0);
  });

  it('should check the last child of toggle element content', () => {
    const element = document.querySelector('.accor_main_cnt');
    expect(element.lastChild.childNodes[0].childNodes[0].textContent.length).toBeGreaterThan(0);
  });

  it('should check addtionalCost toggle flag after paneltoggel call', () => {
    component.paneltoggel(0);
    expect(component.addtionalCost).toBeFalsy();
  });

  it('should check hasFree toggle flag after paneltoggel call', () => {
    component.paneltoggel(1);
    expect(component.hasFree).toBeFalsy();
  });

  it('should check saveOnQau toggle flag after paneltoggel call', () => {
    component.paneltoggel(2);
    expect(component.saveOnQau).toBeFalsy();
  });

  it('should check location href after the openPhoneDialer', () => {
    component.openPhoneDialer();
    expect(document.location.href.length).toBeGreaterThan(0);
  });

  it('should check the promocontent content', () => {
    const element = document.querySelector('.promo-name');
    expect(element.childElementCount).toBeGreaterThan(0);
  });

  it('should check the how it works steps content', () => {
    const element = document.querySelector('.getStart_button ion-button');
    expect(element.innerHTML.length).toBeGreaterThan(0);
  });
});
