import { Component, HostListener, OnInit } from '@angular/core';
import { ModalController, NavController } from '@ionic/angular';
import { environment } from '@environments/environment';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { AlertService } from '@app/services/alert.service';
import { MyPillpackService } from '@app/services/my-pillpack.service';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { ProfileModalComponent } from '../profile-modal/profile-modal.component';
import { MY_PILLPACK_CONSTANTS } from '../my-pillpack.constants';
import { Select, Store } from '@ngxs/store';
import { SetLoader } from '@app/store/actions/app.actions';
import { Location } from '@angular/common';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss']
})
export class LandingComponent implements OnInit {
  @Select(AppSelectors.getPostLoginInfo) postLoginInfo: any;

  currentStep = 1;
  isPillPackEnrolledThisSession: boolean;
  public welcomeMsg;

  public isCPDPPromotion = false;
  public isCPDPEnrolled = false;
  public isCPDPHandedoff = false;
  public isKentuckyMember = false;
  public isCreatePharmacyUser = false;
  public addtionalCost = false;
  public hasFree = false;
  public saveOnQau = false;
  public pharmatics = false;

  impersonate = true;
  dataReturned: any;
  mobileViewPort = 991;
  ismobile: boolean;

  constructor(
    private pillpackService: MyPillpackService,
    private alertService: AlertService,
    private modalController: ModalController,
    private location: Location,
    private store: Store,
    private navCtrl: NavController
  ) {
    this.ismobile = window.innerWidth <= this.mobileViewPort;
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.ismobile = event.target.innerWidth <= this.mobileViewPort;
  }

  openPillPackSite() {
    sessionStorage.setItem('consentLink', 'https://www.pillpack.com');
    this.openModal('https://www.pillpack.com', 'openPillPackSite');
  }

  ngOnInit() {
    this.postLoginInfo.subscribe((data) => {
      if (data) {
        this.isCPDPPromotion = data.isCPDPPromotion;
        this.isCPDPEnrolled = data.isCPDPEnrolled;
        this.isCPDPHandedoff = data.isCPDPHandedoff;
        this.isKentuckyMember = data.isKYMember;
      }
      if (!this.isCPDPPromotion) {
        this.navCtrl.navigateRoot(['/home']);
      }
    });

    if (sessionStorage.getItem('isCompleteHanddoff') != null && sessionStorage.getItem('isCompleteHanddoff') !== '') {
      this.isPillPackEnrolledThisSession = JSON.parse(sessionStorage.getItem('isCompleteHanddoff'));
    } else {
      this.isPillPackEnrolledThisSession = false;
    }
    this.welcomeMsg = MY_PILLPACK_CONSTANTS.WelcomeMsg;

    sessionStorage.setItem('selectedOTCs', '');

    this.impersonate = environment.impersonation;
  }

  async openModal(link: string, modelId: string) {
    const modal = await this.modalController.create({
      component: ProfileModalComponent,
      componentProps: {
        modelId: modelId,
        link: link
      }
    });

    modal.onDidDismiss().then(dataReturned => {
      if (dataReturned !== null) {
        this.dataReturned = dataReturned.data;
      }
    });
    return await modal.present();
  }

  async navigateToCPDP() {
    if (!this.isCPDPEnrolled && !this.isCPDPHandedoff && !this.isPillPackEnrolledThisSession) {
      await this.checkPharmacyUserCreated().then(res => {
        this.isCreatePharmacyUser = true;
        if (res) {
          this.navCtrl.navigateForward('/my-pillpack');
        }
      });
    } else {
      this.gotoStep(2);
      window.scrollTo(0, 0);
    }
  }

  async checkPharmacyUserCreated() {
    if (!this.isCPDPEnrolled && !this.isCPDPHandedoff && !this.isPillPackEnrolledThisSession) {
      this.store.dispatch(new SetLoader(true));
      return await this.pillpackService
        .createPharmacyUser()
        .then((res: any) => {
          this.store.dispatch(new SetLoader(false));
          if (!res.existingUser && res.errormessage) {
            sessionStorage.setItem('isCreatePharmacyUser', 'false');
            this.alertService.setAlert('', res['displaymessage'], AlertType.Failure);
            return false;
          } else if (res.existingUser) {
            sessionStorage.setItem('isCreatePharmacyUser', 'true');
            sessionStorage.setItem('partnerId', res.partner.id);
            return true;
          } else {
            sessionStorage.setItem('isCreatePharmacyUser', 'true');
            sessionStorage.setItem('partnerId', res.partner.id);
            return true;
          }
        })
        .catch(() => this.store.dispatch(new SetLoader(false)));
    } else {
      this.gotoStep(2);
    }
  }

  paneltoggel(id) {
    switch (id) {
      case 1:
        this.addtionalCost = !this.addtionalCost;
        break;
      case 2:
        this.hasFree = !this.hasFree;
        break;
      case 3:
        this.saveOnQau = !this.saveOnQau;
        break;
      case 4:
        this.pharmatics = !this.pharmatics;
        break;
    }
  }

  openPhoneDialer() {
    document.location.href = 'tel:+18557455725 ';
  }

  gotoStep(step: number) {
    setTimeout(() => (this.currentStep = step), 0);
  }

  goBack() {
    this.location.back();
  }

  ionViewDidEnter() {
    const elementList = document.querySelectorAll('.pillpack-landingpage-container');
    const element = elementList[0] as HTMLElement;
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  }
}
