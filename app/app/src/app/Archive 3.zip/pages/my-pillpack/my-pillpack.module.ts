import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { TextMaskModule } from 'angular2-text-mask';
import { VerifyEmailMobileModule } from '../my-profile/verify-email-mobile/verify-email-mobile.module';
import { AddOtcComponent } from './add-otc/add-otc.component';
import { CreditCardComponent } from './components/credit-card/credit-card.component';
import { MedicationDetailsComponent } from './components/medication-details/medication-details.component';
import { RxOrderSummaryComponent } from './components/rx-order-summary/rx-order-summary.component';
import { ConfirmationComponent } from './confirmation/confirmation.component';
import { LandingComponent } from './landing/landing.component';
import { MedicationsComponent } from './medications/medications.component';
import { PILLPACK_ROUTER } from './my-pillpack.route';
import { AlertsModule } from '@app/components/alerts/alerts.module';
import { CamelCaseModule } from '@app/pipes/camelcase/camel-case.module';
import { AppControlMessagesModule } from '@app/components/app-control-messages/app-control-messages.module';
import { AutoCompleteHighlightModule } from '@app/pipes/auto-complete-highlight/auto-complete-highlight.module';
import { OrderPipeModule } from '@app/pipes/order/order.pipe.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  imports: [
    CommonModule,
    PILLPACK_ROUTER,
    TextMaskModule,
    ReactiveFormsModule,
    IonicModule,
    FormsModule,
    VerifyEmailMobileModule,
    AlertsModule,
    CamelCaseModule,
    AppControlMessagesModule,
    AutoCompleteHighlightModule,
    OrderPipeModule,
    FontAwesomeModule
  ],
  declarations: [
    MedicationsComponent,
    AddOtcComponent,
    MedicationDetailsComponent,
    LandingComponent,
    ConfirmationComponent,
    RxOrderSummaryComponent,
    CreditCardComponent
  ]
})
export class MyPillpackModule {}
