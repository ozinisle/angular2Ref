import { RouterModule, Routes } from '@angular/router';
import { ConfidentialityComponent } from './confidentiality/confidentiality.component';
import { FpoMyprofileComponent } from './fpo-myprofile/fpo-myprofile.component';
import { LearnMoreComponent } from './learn-more/learn-more.component';
import { StaticComponent } from './static.component';
import { TermsComponent } from './terms/terms.component';

const STATIC_ROUTER: Routes = [
  {
    path: '',
    component: StaticComponent,
    children: [
      {
        path: 'confidentiality',
        component: ConfidentialityComponent
      },
      {
        path: 'learnmore',
        component: LearnMoreComponent
      },
      {
        path: 'terms',
        component: TermsComponent
      },
      {
        path: 'relFpo',
        component: FpoMyprofileComponent
      }
    ]
  },
  {
    path: 'parent/:type',
    component: StaticComponent,
    children: [
      {
        path: 'confidentiality',
        component: ConfidentialityComponent
      },
      {
        path: 'learnmore',
        component: LearnMoreComponent
      },
      {
        path: 'terms',
        component: TermsComponent
      }
    ]
  }
];

export const STATIC_COMPONENT_ROUTER = RouterModule.forChild(STATIC_ROUTER);
