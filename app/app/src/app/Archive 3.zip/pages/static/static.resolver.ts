import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { forkJoin, Observable } from 'rxjs';
import { ConstantsService } from '@app/services/constants.service';

@Injectable({ providedIn: 'root' })
export class StaticPagesResolver {
  public sourceURL = '';
  public currUrl = '';

  constructor(private http: HttpClient, private constants: ConstantsService) {}

  async resolve(routeInfo: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    this.sourceURL = state.url;
    const numberal = this.sourceURL.substring(this.sourceURL.length - 1);
    this.currUrl = 'drupalContentSecureCampaignUrl' + numberal;
    return await forkJoin([this.fetchMyAccountInfo()]).toPromise();
  }

  fetchMyAccountInfo(): Observable<any> {
    return this.http.get(this.constants[this.currUrl]);
  }
}
