import { Component, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  templateUrl: './static.component.html',
  styleUrls: ['./static.component.scss']
})
export class StaticComponent implements OnDestroy {
  private sub;
  public displayClose = false;
  constructor(private route: ActivatedRoute) {
    this.sub = this.route.params.subscribe(params => {
      this.displayClose = params['type'] === 'notification';
    });
  }

  ngOnDestroy() {
    if (this.sub) {
      this.sub.unsubscribe();
    }
  }
}
