import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { ConfidentialityComponent } from './confidentiality/confidentiality.component';
import { FpoMyprofileComponent } from './fpo-myprofile/fpo-myprofile.component';
import { LearnMoreComponent } from './learn-more/learn-more.component';
import { MaintenanceComponent } from './maintenance/maintenance.component';
import { StaticComponent } from './static.component';
import { StaticPagesResolver } from './static.resolver';
import { STATIC_COMPONENT_ROUTER } from './static.routing';
import { TermsComponent } from './terms/terms.component';
import { FpoLayoutModule } from '@app/components/fpo-layout/fpo-layout.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  declarations: [
    StaticComponent,
    ConfidentialityComponent,
    LearnMoreComponent,
    TermsComponent,
    MaintenanceComponent,
    FpoMyprofileComponent
  ],
  imports: [STATIC_COMPONENT_ROUTER, FormsModule, ReactiveFormsModule, CommonModule, IonicModule, FpoLayoutModule, FontAwesomeModule],
  providers: [StaticPagesResolver]
})
export class StaticModule {}
