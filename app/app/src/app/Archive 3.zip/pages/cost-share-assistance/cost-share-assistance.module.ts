import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { CostShareAssistancePage } from './cost-share-assistance.page';
import { CostShareAssistancePageService } from './cost-share-assistance.service';
import { AlertsModule } from '@app/components/alerts/alerts.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

const routes: Routes = [
  {
    path: '',
    component: CostShareAssistancePage
  }
];

@NgModule({
  imports: [CommonModule, FormsModule, AlertsModule, IonicModule, RouterModule.forChild(routes), FontAwesomeModule],
  providers: [CostShareAssistancePageService],
  declarations: [CostShareAssistancePage]
})
export class CostShareAssistancePageModule {}
