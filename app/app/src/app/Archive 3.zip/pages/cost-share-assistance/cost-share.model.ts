export class CostShareLink {
  link: string;
  text: string;
  fontawsomeclass: any;
  group: string;
}

export class CostShareContent {
  title: string;
  description: string;
  imageUrl: string;
  navLinks: CostShareLink[];
}
