import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { CostShareAssistancePage } from './cost-share-assistance.page';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { CommonModule } from '@angular/common';
import { ConstantsService } from '@app/services/constants.service';
import { CostShareAssistancePageService } from './cost-share-assistance.service';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { FileTransfer } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import { IonicModule } from '@ionic/angular';
import { AlertsComponent } from '@app/components/alerts/alerts.component';

describe('CostShareAssistancePage', () => {
  let component: CostShareAssistancePage;
  let fixture: ComponentFixture<CostShareAssistancePage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [IonicModule, HttpClientTestingModule, RouterTestingModule, CommonModule],
      declarations: [CostShareAssistancePage, AlertsComponent],
      providers: [InAppBrowser, ConstantsService, CostShareAssistancePageService, FileOpener, File, FileTransfer]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CostShareAssistancePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should openurl external', () => {
    component.openUrl('https://www.bcbsma.com');
    expect(component).toBeTruthy();
  });
  it('should openurl telephone', () => {
    component.openUrl('tel://3523442345');
    expect(component).toBeTruthy();
  });

});
