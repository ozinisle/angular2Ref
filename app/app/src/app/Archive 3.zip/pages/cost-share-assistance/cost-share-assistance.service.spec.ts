import { MyPlansService } from './../my-plans/my-plans.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { waitForAsync, inject, TestBed } from '@angular/core/testing';
import { ConstantsService } from '@app/services/constants.service';
import { CostShareAssistancePageService } from './cost-share-assistance.service';
import { COST_SHARE } from '@testing/data/cost-share/cost-share.data';
import { mocks } from '@testing/constants/mocks.service';
import { IonicModule } from '@ionic/angular';
import { format } from 'date-fns';

describe('CostShareAssistancePageService', () => {
  let mockConstantsService;
  let mockCostShareService;
  let mockMyPlanService;
  mockMyPlanService = mocks.service.myPlansService;
  mockConstantsService = mocks.service.ConstantsService;
  mockCostShareService = mocks.service.costShareAssistService;
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, IonicModule],
      providers: [HttpTestingController,
        { provide: MyPlansService, useValue: mockMyPlanService },
        { provide: CostShareAssistancePageService, useValue: mockCostShareService },
        { provide: ConstantsService, useValue: mockConstantsService }]
    }).compileComponents();
  }));
  it('should be created', inject([CostShareAssistancePageService], (service: CostShareAssistancePageService) => {
    expect(service).toBeTruthy();
  }));
  it('getCostShareDrupalContent should return data', () => {
    const service: CostShareAssistancePageService = TestBed.inject(CostShareAssistancePageService);
    service.getCostShareDrupalContent().subscribe((res) => {
      expect(res).toEqual(COST_SHARE[0]);
    })
  });
  it('verify group number are available in drupal response', waitForAsync(() => {
    const service: CostShareAssistancePageService = TestBed.inject(CostShareAssistancePageService);
    service.getCostShareDrupalContent().subscribe((response) => {
      response[0]?.Links?.map((linkValues) => {
        expect(linkValues.group).not.toBeNull();
      })
    })
  }));
  it('planDataServiceApi', inject([MyPlansService], (service: MyPlansService) => {
    expect(service.getPlansData(format(new Date(), 'yyyy-MM-dd'))).toBeTruthy();
  }));
});
