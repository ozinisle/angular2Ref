import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { AlertService } from '@app/services/alert.service';
import { ConstantsService } from '@app/services/constants.service';
import { format } from 'date-fns';
import { forkJoin } from 'rxjs';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { PlanBenefitsListResponseModelInterface } from '../my-plans/models/interfaces/plan-benefits-list-model.interface';
import { PlanBenefitsListResponseModel } from '../my-plans/models/plan-benefits-list.model';
import { MyPlansService } from '../my-plans/my-plans.service';
import { CostShareContent, CostShareLink } from './cost-share.model';

@Injectable({ providedIn: 'root' })
export class CostShareAssistancePageService {
  constructor(
    private constantsService: ConstantsService,
    private http: HttpClient,
    private planDataService: MyPlansService,
    private alertService: AlertService
  ) {}

  getCostShareDrupalContent(): Observable<any> {
    return this.http.get(this.constantsService.drupalCostShareAssistanceUrl);
  }

  getCostShareContent(): Observable<CostShareContent> {
    const drupalContent$ = this.getCostShareDrupalContent();
    const planData$: Observable<PlanBenefitsListResponseModelInterface> = this.planDataService.getPlansData(
      format(new Date(), 'yyyy-MM-dd')
    );
    return forkJoin([drupalContent$, planData$]).pipe(
      map(([drupalContent, planData]) => {
        let costShareContent;
        if (planData.result < 0) {
          this.alertService.clearError();
          this.alertService.setAlert(planData.displaymessage, '', AlertType.Failure);
          costShareContent = null;
        } else {
          const memberGroups = this.getGroupMembers(planData);
          costShareContent = this.handleCostShareDrupal(drupalContent[0], memberGroups);
        }
        return costShareContent;
      })
    );
  }

  private getGroupMembers(planResponse): string[] {
    const userGroupNumbers: string[] = [];
    const planResponseFromService = new PlanBenefitsListResponseModel();
    planResponseFromService.RowSet = planResponse.RowSet;
    planResponseFromService.RowSet.osplinPlans.plans.map(planValue => {
      planValue.groupInfo.group.map(groupValue => {
        userGroupNumbers.push(groupValue.groupNumber);
      });
    });
    return userGroupNumbers;
  }

  handleCostShareDrupal(content, memberGroups): CostShareContent {
    const costShareContent = new CostShareContent();
    costShareContent.title = content.Title;
    costShareContent.description = content.ShortDescription;
    costShareContent.imageUrl = this.constantsService.drupalUrl + '/' + content.MobileImage;
    const contentLinks = content.Links as CostShareLink[];
    const finalLinks: CostShareLink[] = [];
    contentLinks.map(values => {
      if (values.group != null) {
        const drupalGroupNumbers = values.group.split(',');
        if (drupalGroupNumbers.length > 0) {
          for (const memberGroup of memberGroups) {
            if (drupalGroupNumbers.includes(memberGroup)) {
              finalLinks.push(values);
            }
          }
        }
      } else {
        finalLinks.push(values);
      }
    });
    costShareContent.navLinks = finalLinks;
    for (let i = 0; i < costShareContent.navLinks.length; i++) {
      let link = costShareContent.navLinks[i];
      let faArray = link.fontawsomeclass.split(' ', 2);
      costShareContent.navLinks[i].fontawsomeclass = [faArray[0], faArray[1].replace('fa-', '')];
    }
    return costShareContent;
  }
}
