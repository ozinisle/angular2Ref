import { DOCUMENT } from '@angular/common';
import { Component, Inject, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MYBLUE } from '@app/app.constants';
import { IabService } from '@app/services/iab.service';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { FileTransfer } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import { IonContent } from '@ionic/angular';
import { Observable } from 'rxjs';
import { CostShareAssistancePageService } from './cost-share-assistance.service';
import { CostShareContent } from './cost-share.model';

@Component({
  selector: 'app-cost-share-assistance',
  templateUrl: './cost-share-assistance.page.html',
  styleUrls: ['./cost-share-assistance.page.scss']
})
export class CostShareAssistancePage {
  @ViewChild(IonContent) content: IonContent;
  costShareContent$: Observable<CostShareContent>;

  constructor(
    @Inject(DOCUMENT) private document: Document,
    private iabService: IabService,
    private costShareAssistancePageService: CostShareAssistancePageService,
    private fileOpener: FileOpener,
    private file: File,
    private transfer: FileTransfer,
    private activeRoute: ActivatedRoute
  ) {
    this.activeRoute.params.subscribe(() => {
      this.loadContent();
    });
  }

  loadContent() {
    this.costShareContent$ = this.costShareAssistancePageService.getCostShareContent();
  }

  ionViewDidEnter() {
    this.content.scrollToTop();
  }

  openUrl(url: string) {
    MYBLUE.log('open url call', url);
    if (url?.indexOf('http') !== -1 && url?.toLowerCase().indexOf('pdf') !== -1) {
      this.openPdfUrl(url);
    } else if (url?.indexOf('http') !== -1) {
      this.iabService.create(url);
    } else {
      this.document.location.href = url;
    }
  }

  openPdfUrl(url) {
    if (url) {
      /* open pdf */
      const downloadUrl = url;
      const path = this.file.dataDirectory;
      const transfer = this.transfer.create();

      transfer.download(downloadUrl, path + 'myfile.pdf').then(entry => {
        const appUrl = entry.toURL();
        this.fileOpener.open(appUrl, 'application/pdf').catch(e => MYBLUE.error('Error opening file', e));
      });
    }
  }
}
