import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { IabService } from '../../services/iab.service';
import { AppSelectors } from '../../store/selectors/app.selectors';
import { SsoService } from '../sso/sso.service';
import { PharmacyLinkType } from '../../models/pharmacy-link-type';

@Component({
  selector: 'app-myPharmacy',
  templateUrl: 'my-pharmacy.page.html',
  styleUrls: ['my-pharmacy.page.scss']
})
export class MyPharmacyPage {
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;
  @SelectSnapshot(AppSelectors.getPharmacyLinks) listItems: PharmacyLinkType[];

  isAuthenticatedUser: boolean;

  constructor(private router: Router, private ssoService: SsoService, private iabService: IabService) {}

  ionViewWillEnter() {
    const scopeName = this.scopeName;
    this.isAuthenticatedUser = scopeName.includes('AUTHENTICATED');
  }

  navigate(item: PharmacyLinkType) {
    if (item.isSSO && this.isAuthenticatedUser) {
      this.ssoService.openSSO(item.ssoType);
    } else if (item.isExternal) {
      this.iabService.create(item.url);
    } else {
      this.router.navigateByUrl(item.url);
    }
  }

  goBack() {
    this.router.navigate(['/home']);
  }
}
