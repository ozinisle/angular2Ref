import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { ModalController, IonContent, IonicModule } from '@ionic/angular';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '@app/services/constants.service';
import { SsoService } from '../sso/sso.service';
import { IabService } from '@app/services/iab.service';
import { MyPharmacyPage } from './my-pharmacy.page';
import { CommonModule } from '@angular/common';
import { DatePipe } from '@angular/common';
import { LoadingController } from '@ionic/angular';
const mockPharmacyLinkType: any = {
  label: 'string',
  icon: 'string',
  isSSO: false,
  ssoType: 'string',
  isPhone: false,
  isExternal: false
};

xdescribe('MyPharmacyPage', () => {
  let component: MyPharmacyPage;
  let fixture: ComponentFixture<MyPharmacyPage>;
  let mockSsoService: SsoService;
  let mockIabService: IabService;
  const modalSpy = jasmine.createSpyObj('Modal', ['present']);
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);
  modalCtrlSpy.create.and.callFake(() => {
    return modalSpy;
  });

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [MyPharmacyPage],
      imports: [
        IonicModule,
        RouterTestingModule,
        HttpClientTestingModule,
        NgxsSelectSnapshotModule.forRoot(),
        NgxsModule.forRoot([]),
        CommonModule
      ],
      providers: [
        SsoService,
        ConstantsService,
        InAppBrowser,
        IabService,
        LoadingController,
        DatePipe,
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        },
        IonContent
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyPharmacyPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
    mockSsoService = TestBed.inject(SsoService);
    mockIabService = TestBed.inject(IabService);
  });

  afterEach(() => {
    mockPharmacyLinkType.isExternal = false;
    mockPharmacyLinkType.isPhone = false;
    mockPharmacyLinkType.isSSO = false;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should contain text My Pharmacy on ion-title', () => {
    const element = document.querySelector('ion-title');
    expect(element).toBeTruthy();
    expect(element.textContent.length).toBeGreaterThan(0);
  });

  it('should contain ion-label', () => {
    const element = document.querySelector('ion-label');
    expect(element).toBeDefined();
  });

  it('should set isauthenticated and scopename on ionviewwillenter', () => {
    spyOnProperty(component, 'scopeName').and.returnValue('AUTHENTICATED');
    component.ionViewWillEnter();
    expect(component.isAuthenticatedUser).toBeTruthy();
    expect(component.scopeName).toBeDefined();
  });

  it('should call sso service when issso and authenticated user is true', () => {
    const spy = spyOn(mockSsoService, 'openSSO').and.returnValue(null);
    component.isAuthenticatedUser = true;
    mockPharmacyLinkType.isSSO = true;
    component.navigate(mockPharmacyLinkType);
    expect(spy).toHaveBeenCalled();
  });

  it('should call iabservice create when isExternal is true', () => {
    const spy = spyOn(mockIabService, 'create').and.returnValue(null);
    mockPharmacyLinkType.isExternal = true;
    component.navigate(mockPharmacyLinkType);
    expect(spy).toHaveBeenCalled();
  });
});
