import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IabService } from '@app/services/iab.service';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { HeaderService } from '@app/services/header.service';
import { Store, Select } from '@ngxs/store';
import { Logout } from '../../store/actions/app.actions';
import { NavController } from '@ionic/angular';
import { Observable } from 'rxjs';
import { AuthToken } from '@app/models/auth-token.model';

import { version } from '@environments/version';
@Component({
  selector: 'app-brand-home',
  templateUrl: './brand-home.page.html',
  styleUrls: ['./brand-home.page.scss'],
})
export class BrandHomePage implements OnInit {

  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;
  @Select(AppSelectors.getAuthToken) authToken$: Observable<AuthToken>
  @SelectSnapshot(AppSelectors.hasNewPwkMessage) hasNewPwkMessage: boolean;
  buildVersion = version.build;
  mobileAppVersion = version.appversion;
  isAuthenticatedUser: boolean;
  isRegisteredUser: boolean;
  anonymousFeedback = 'https://engage.bluecrossma.com/forms/submit-feedback';
  isAnonymousUser: boolean;
  constructor(private router: Router,
    private navCtrl: NavController, private store: Store,
    private iabService: IabService,
    public headerService: HeaderService) { }

  ngOnInit() {
  }

  ionViewWillEnter() {
    this.isRegisteredUser = this.scopeName?.includes('REGISTERED');
    this.isAuthenticatedUser = this.scopeName?.includes('AUTHENTICATED');
    this.isAnonymousUser = !(this.isRegisteredUser || this.isAuthenticatedUser);
  }

  goBack() {
    this.router.navigate(['/home']);
  }

  ionViewDidEnter() {
    this.isRegisteredUser = this.scopeName?.includes('REGISTERED');
    this.isAuthenticatedUser = this.scopeName?.includes('AUTHENTICATED');
    this.isAnonymousUser = !(this.isRegisteredUser || this.isAuthenticatedUser);
  }

  logOut() {
    sessionStorage.clear();
    this.store.dispatch(new Logout());
  }

  openInAppBrowser(url, isExternal) {
    if (isExternal) {
      this.iabService.create(url);
    } else {
      this.router.navigate([url]);
    }
  }

  logIn() {
    this.navCtrl.navigateRoot('login');
  }

  get getUnreadMsgCount() {
    return this.headerService.unReadMsgCount + (this.hasNewPwkMessage ? 1 : 0);
  }
}
