import { GeneralError } from '../../../models/generic-app.model';
import {
  GetVisitDetailsRequestModelInterface,
  GetVisitDetailsResponseModelInterface
} from './interfaces/get-visit-details-models.interface';
import { MyDoctorsGenericRequestModel, VisitDetail } from './my-doctor-module-common.model';

export class GetVisitDetailsRequestModel extends MyDoctorsGenericRequestModel implements GetVisitDetailsRequestModelInterface {
  providerNumber: string; // providerNumberstring  example: 70010000J12136
  providerName: string; // * providerNamestring  example: John Smith MD
}

export class GetVisitDetailsResponseModel extends GeneralError implements GetVisitDetailsResponseModelInterface {
  visitDetails: VisitDetail;
}
