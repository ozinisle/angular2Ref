import { GeneralError } from '@app/models/generic-app.model';
import { GetDependentRecentVisitsResponseModelInterface } from './interfaces/get-dependent-recent-visits-model.interface';
import { MyDoctorsGenericRequestModel, VisitsResponse } from './my-doctor-module-common.model';

export class GetDependentRecentVisitsRequestModel extends MyDoctorsGenericRequestModel {
  dependentId: string;
}

export class GetDependentRecentVisitsResponseModel extends GeneralError implements GetDependentRecentVisitsResponseModelInterface {
  recentVisits: VisitsResponse[];
}
