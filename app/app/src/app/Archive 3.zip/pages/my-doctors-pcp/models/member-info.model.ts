export class MemberInfo {
  memFistName: string;
  memLastName: string;
  relationship: string;
  hasDependents: boolean;
  clmAllowAmt: string;
  clmDOS: string;
  clmICN: number;
  clmPaidAmt: string;
  clmPaymtStatus: string;
  clmPrvName: string;
  memGender: string;
  clmSrvType: string;
  clmStatus: string;
  hasALG: string;
  hasHEQ: string;
  lastLoginDt: string;
  memMidInit: string;
  numOfClmsSinceLastLogin: string;
  rxDispDt: string;
  rxDispPrvCity: string;
  rxDispPrvName: string;
  rxDispPrvNum: string;
  rxDispPrvPhone: string;
  rxDispPrvState: string;
  rxDispPrvStreet: string;
  rxDispPrvZip: string;
  rxDrugName: string;
  rxNSDC: string;
  rxPrescPhone: string;
  rxPrescPrvName: string;
  rxPrescPrvNum: string;
  rxStrength: string;
  visitCity: string;
  visitPhone: string;
  visitPrvName: string;
  visitPrvNum: string;
  visitSpec: string;
  visitState: string;
  visitStreet: string;
  visitSvcDate: string;
  visitZip: string;
  // tslint:disable-next-line:variable-name
  member_id: string;
  userState: string;
  userType: string;
  memMedexFlag: string; // Verify  is this needed with FRD >
  memMedicareFlag: string;
  hasSS: string;
  clmLastDOS: string; // or clmDOS -> Wats the diff?
  clmYouOweAmt: string;
  clmCopay: string;
  unreadMessageCount: string;
  visitLastSvcDate: string;
  rxDrugType: string;
  rxCoPay: string;
  rxLastFillDate: string;
  rxUniquePersonId: string;
  rxNDCCode: string;
  rxIncurredDate: string;
  planName: string;
  planType: string;
  groupNumber: string;
  groupName: string;
  planEffectiveDate: string;
  isMedicarePPO?: boolean;

  get fullName() {
    return `${this.memFistName} ${this.memLastName}`;
  }
}
