import { CommonModule, DatePipe, TitleCasePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { RouterModule } from '@angular/router';
import { AlertsModule } from '@app/components/alerts/alerts.module';
import { AppControlMessagesModule } from '@app/components/app-control-messages/app-control-messages.module';
import { FpoLayoutModule } from '@app/components/fpo-layout/fpo-layout.module';
import { DoctorNameModule } from '@app/pipes/doctor-name/doctor-name.module';
import { IonicModule } from '@ionic/angular';
import { TextMaskModule } from 'angular2-text-mask';
import { FilterPipe, FilterPipeModule } from 'ngx-filter-pipe';
import { NgxMaskModule } from 'ngx-mask';
import { OrderModule } from 'ngx-order-pipe';
import { MaintenanceComponent } from './maintenance/maintenance.component';
import { MyDoctorsPcpFilterComponent } from './my-doctors-pcp-filter/my-doctors-pcp-filter.component';
import { MyDoctorsChangePcpHomepageGuard, MyDoctorsPcpGuard } from './mydoctors-pcp.guard';
import { MyDoctorsPcpRouter } from './mydoctors-pcp.routing';
import { MyDoctorsPcpService } from './mydoctors-pcp.service';
import { MyDoctorDetailsComponent } from './mydoctors/details/mydoctor-details.component';
import { MyDoctorsComponent } from './mydoctors/landing/mydoctors.component';
import { AddPcpComponent } from './pcp/add-pcp/add-pcp.component';
import { PcpErrorComponent } from './pcp/pcp-error/pcp-error.component';
import { PcpResultComponent } from './pcp/pcp-result/pcp-result.component';
import { UpdatePcpComponent } from './pcp/update-pcp/update-pcp.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { IntegratedPlanAcccessModule } from '../integrated-plan-access/integrated-plan-access.module';
import { BreadcrumbModule } from '@app/components/breadcrumbs/breadcrumbs.module';

@NgModule({
  imports: [
    CommonModule,
    BreadcrumbModule,
    FormsModule,
    ReactiveFormsModule,
    TextMaskModule,
    OrderModule,
    FilterPipeModule,
    MyDoctorsPcpRouter,
    IonicModule,
    RouterModule,
    AlertsModule,
    NgxMaskModule,
    MatFormFieldModule,
    AppControlMessagesModule,
    DoctorNameModule,
    FontAwesomeModule,
    FpoLayoutModule,
    IntegratedPlanAcccessModule
  ],
  declarations: [
    MyDoctorsComponent,
    MyDoctorDetailsComponent,
    AddPcpComponent,
    UpdatePcpComponent,
    PcpResultComponent,
    PcpErrorComponent,
    MaintenanceComponent,
    MyDoctorsPcpFilterComponent
  ],
  providers: [DatePipe, FilterPipe, TitleCasePipe, MyDoctorsPcpService, MyDoctorsPcpGuard, MyDoctorsChangePcpHomepageGuard]
})
export class MyDoctorsPcpModule {}
