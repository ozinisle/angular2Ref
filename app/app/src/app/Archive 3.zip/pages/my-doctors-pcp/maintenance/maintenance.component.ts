import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Platform } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { ConstantsService } from '@app/services/constants.service';
import { AppSelectors } from '@app/store/selectors/app.selectors';

@Component({
  selector: 'app-maintenance',
  templateUrl: './maintenance.component.html',
  styleUrls: ['./maintenance.component.scss']
})
export class MaintenanceComponent implements OnInit {
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;

  contactus: string;
  urlConfig = {
    myplans: '/myPlan',
    myaccount: '/account',
    fad: '../fad'
  };

  constructor(public constants: ConstantsService, private router: Router, private platform: Platform, private r: ActivatedRoute) {
    this.platform.backButton.subscribeWithPriority(1, () => {
      this.goBack();
    });
    this.contactus = this.constants.contactus + this.scopeName;
  }

  ngOnInit() {}
  openContactUs() {
    this.router.navigate(['/contact-us']);
  }

  openUrl(url) {
    if (url) {
      window.open(url, '_self');
    }
  }

  openSsoUrl(url) {
    if (url) {
      window.open(url, '_blank');
    }
  }

  public goBack(): void {
    this.router.navigate(['../my-doctor/pcp-error'], { replaceUrl: true });
  }

  navigate(id, routeParams?) {
    const url = this.urlConfig[id];

    if (url) {
      if (!routeParams) {
        this.router.navigate([url], { relativeTo: this.r });
      } else {
        this.router.navigate([url], { relativeTo: this.r });
      }
    } else {
      return;
    }
  }
}
