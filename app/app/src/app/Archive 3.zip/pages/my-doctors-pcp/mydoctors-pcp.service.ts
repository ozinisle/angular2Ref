import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router, RoutesRecognized } from '@angular/router';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { DependentModel } from '@app/models/dependent.model';
import { MemberInfo } from '@app/pages/my-doctors-pcp/models/member-info.model';
import { AlertService } from '@app/services/alert.service';
import { ConstantsService } from '@app/services/constants.service';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { DependentSelectors } from '@app/store/selectors/dependent.selectors';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable } from 'rxjs';
import { filter, map, pairwise } from 'rxjs/operators';
import { HomePageAppInfoModel } from '../home/home.model';
import { GetDependentRecentVisitsRequestModel, GetDependentRecentVisitsResponseModel } from './models/get-dependent-recent-visits.model';
import { GetDependentVisitDetailsResponseModel } from './models/get-dependent-visit-details.model';
import { GetMemberPlanDependentResponseModel } from './models/get-member-plan-dependent-model';
import { GetMemberPlanInformation } from './models/get-member-plan-info-model';
import { GetVisitDetailsResponseModel } from './models/get-visit-details.model';
import { ChangePCPResponseModelInterface } from './models/interfaces/change-pcp-request-model-interface';
import { GetCodeResponseModelInterface } from './models/interfaces/get-code-model-interface';
import { GetDependentRecentVisitsResponseModelInterface } from './models/interfaces/get-dependent-recent-visits-model.interface';
import { GetPCPInfoResponseModellInterface } from './models/interfaces/get-pcp-info-request-model-interface';
import { GetRecentVisitsRequestModelInterface } from './models/interfaces/get-recent-visits-models.interface';
import { MemberPCPDataModelInterface, VisitsResponseInterface } from './models/interfaces/my-doctor-module-common-models.interface';
import { MyDoctorsGenericRequestModel, VisitsResponse } from './models/my-doctor-module-common.model';
import { Provider } from './mydoctors-pcp.model';

/* tslint:disable */
@Injectable({ providedIn: 'root' })
export class MyDoctorsPcpService {
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(DependentSelectors.getDependentsList) dependentsList: DependentModel[];
  @SelectSnapshot(AppSelectors.getMemberInfo) memInfo: HomePageAppInfoModel;

  private _selectedDoctor: Provider;
  private _doctorList: Provider[];
  private _memberPCP: MemberPCPDataModelInterface;
  private _active: boolean;
  private _memberInfo: MemberInfo;
  private _doctorDetails: Object;
  private _previousPCPUrl: string;
  private previousUrl: string;

  // public clearFilterFlagSubject = new Subject<ClearSearchResultFlagInterface>();
  // public clearFilterFlagSubject$ = this.clearFilterFlagSubject.asObservable();

  public isFilterChangedFlag = false;
  
  constructor(private http: HttpClient, private constants: ConstantsService, private alertService: AlertService,private router: Router) {
    this.setActiveStatus();
    this.router.events
    .pipe(
      filter(e => e instanceof RoutesRecognized),
      pairwise()
    )
    .subscribe((event: any[]) => {
      this.previousUrl = event[0].urlAfterRedirects;
    });
  }
  public getPreviousUrl() {
    return this.previousUrl;
  }
  getMemberPlanInfo(requestParam): Observable<GetMemberPlanInformation> {
    const targetUrl = this.constants.getMemPlanInfo;
    return this.http.post<GetMemberPlanInformation>(targetUrl, requestParam);
  }

  getMemberPlanDependentsInfo(requestParam): Observable<GetMemberPlanDependentResponseModel> {
    const targetUrl = this.constants.getMemPlanDependents;
    return this.http.post<GetMemberPlanDependentResponseModel>(targetUrl, requestParam);
  }

  getChangePCPReasonInfo(requestParam): Observable<GetCodeResponseModelInterface> {
    const targetUrl = this.constants.getCodes;
    return this.http.post<GetCodeResponseModelInterface>(targetUrl, requestParam);
  }

  getPCPInfo(requestParam): Observable<GetPCPInfoResponseModellInterface> {
    const targetUrl = this.constants.getPCPInfo;
    return this.http.post<GetPCPInfoResponseModellInterface>(targetUrl, requestParam);
  }

  changePCPInfo(requestParam): Observable<ChangePCPResponseModelInterface> {
    const targetUrl = this.constants.changePCP;
    return this.http.post<ChangePCPResponseModelInterface>(targetUrl, requestParam);
  }

  getDoctorList(): Observable<VisitsResponseInterface[]> {
    const request: GetRecentVisitsRequestModelInterface = new MyDoctorsGenericRequestModel();
    request.useridin = this.useridin;

    return this.http.post<VisitsResponseInterface[]>(this.constants.myDoctorListUrl, request).pipe(
      map((response: any) => {
        if (response && response.recentVisits) {
          response.recentVisits.map(visit => (visit.currUser = true));
          this.doctorList = response.recentVisits as VisitsResponse[];
        }
        return response.recentVisits as VisitsResponse[];
      })
    );
  }

  setActiveStatus(): void {
    const scopename = this.scopeName ? this.scopeName : '';
    if (scopename.toLowerCase().indexOf('inactive') >= 0) {
      this.active = false;
    } else {
      this.active = true;
    }
  }

  // To Do after clarification
  setMemberPCP(): void {
    if (this.memberInfo && this.doctorList) {
      const pcpId = this.doctorList[0] && this.doctorList[0].pcpId ? this.doctorList[0].pcpId : '';
      this.memberPCP = {
        isRequiredPCP: this.memInfo.isRequiredPCP === 'true', // Member Plan`s PCP Requirement
        hasPCP: this.memInfo.hasPCP === 'true',
        pcpId: pcpId
      } as MemberPCPDataModelInterface;
    } else {
      // Default To Do
      this.memberPCP = {
        isRequiredPCP: false, // Member Plan`s PCP Requirement
        hasPCP: false, // Does member has a PCP
        pcpId: ''
      } as MemberPCPDataModelInterface;
    }
  }

  get memberInfo() {
    const storedMemInfo = sessionStorage.getItem('mydoctors.memberInfo');
    if (
      storedMemInfo &&
      storedMemInfo.toString &&
      storedMemInfo.toString().trim() !== 'undefined' &&
      storedMemInfo.toString().trim() !== 'null'
    ) {
      if (this._memberInfo === null || this._memberInfo === undefined) {
        return JSON.parse(storedMemInfo);
      }
    }

    return this._memberInfo;
  }

  set memberInfo(memberInfo: MemberInfo) {
    this._memberInfo = memberInfo;
    sessionStorage.setItem('mydoctors.memberInfo', JSON.stringify(memberInfo));
  }

  get active() {
    if (this._active === null || this._active === undefined) {
      return JSON.parse(sessionStorage.getItem('mydoctors.active'));
    }
    return this._active;
  }

  set previousPCPUrl(previsousUrl: string) {
    this._previousPCPUrl = previsousUrl;
  }
  get previousPCPUrl() {
    return this._previousPCPUrl;
  }

  set active(active: boolean) {
    this._active = active;
    sessionStorage.setItem('mydoctors.active', JSON.stringify(active));
  }

  get memberPCP(): MemberPCPDataModelInterface {
    if (this._memberPCP === null || this._memberPCP === undefined) {
      return JSON.parse(sessionStorage.getItem('mydoctors.memberPCP'));
    }
    return this._memberPCP;
  }

  set memberPCP(memberPCP: MemberPCPDataModelInterface) {
    this._memberPCP = memberPCP;
    sessionStorage.setItem('mydoctors.memberPCP', JSON.stringify(memberPCP));
  }

  get doctorList() {
    return this._doctorList;
  }

  set doctorList(doctorList: Provider[]) {
    this._doctorList = doctorList;
  }

  get selectedDoctor() {
    if (this._selectedDoctor == null) {
      return JSON.parse(sessionStorage.getItem('mydoctors.selectedDoctor'));
    }
    return this._selectedDoctor;
  }

  set selectedDoctor(doctor: Provider) {
    this._selectedDoctor = doctor;
    sessionStorage.setItem('mydoctors.selectedDoctor', JSON.stringify(this._selectedDoctor));
  }

  get doctorDetails() {
    if (this._doctorDetails === null || this._doctorDetails === undefined) {
      return JSON.parse(sessionStorage.getItem('mydoctors.doctorDetails'));
    }
    return this._doctorDetails;
  }

  set doctorDetails(doctor) {
    this._doctorDetails = doctor;
    sessionStorage.setItem('mydoctors.doctorDetails', JSON.stringify(this._doctorDetails));
  }

  getDoctorDetails(request): any {
    const url = request.dependentId ? this.constants.myDepDoctorDetailsUrl : this.constants.myDoctorDetailsUrl;
    return this.http.post(url, request).pipe(
      map((response: any) => {
        if (!response || (response && response.result < 0)) {
          this.doctorDetails = null;
          this.alertService.setAlert(response.displaymessage, '', AlertType.Failure);
          return null;
        } else {
          if (request.dependentId) {
            this.doctorDetails = response as GetDependentVisitDetailsResponseModel;
          } else {
            this.doctorDetails = response as GetVisitDetailsResponseModel;
          }
          return this.doctorDetails;
        }
      })
    );
  }

  loadDependantRecords(dependantId: any, url: string): Observable<GetDependentRecentVisitsResponseModelInterface> {
    const dependentRecentRxReq: GetDependentRecentVisitsRequestModel = new GetDependentRecentVisitsRequestModel();
    dependentRecentRxReq.useridin = this.useridin;
    dependentRecentRxReq.dependentId = dependantId;
    return this.http.post<GetDependentRecentVisitsResponseModelInterface>(url, dependentRecentRxReq).pipe(
      map(response => {
        if (response.result < 0) {
          return new GetDependentRecentVisitsResponseModel();
        } else {
          return this.addDependentIdToRecords(response, dependantId);
        }
      })
    );
  }

  addDependentIdToRecords(records, dependantId) {
    const dependantInfo: DependentModel = this.dependentsList?.find(dependant => dependant.depId === dependantId);
    let memberInfo = '';
    let mem_name = '';

    if (dependantInfo && dependantInfo.middleInitial) {
      memberInfo = `${dependantInfo.firstName} ${dependantInfo.middleInitial}
      ${dependantInfo.lastName} (${dependantInfo.relationship})`;
      mem_name = `${dependantInfo.firstName} ${dependantInfo.middleInitial} ${dependantInfo.lastName}`;
    } else if (dependantInfo) {
      memberInfo = `${dependantInfo.firstName} ${dependantInfo.lastName} (${dependantInfo.relationship})`;
      mem_name = `${dependantInfo.firstName} ${dependantInfo.lastName}`;
    }

    if (records && records.recentVisits.length > 0) {
      return records.recentVisits.map(record => {
        return { ...record, MemberInfo: memberInfo, mem_name, dependentId: dependantId };
      });
    }

    if (records && records.recentVisits.length === undefined && Object.keys(records).length) {
      return { ...records, MemberInfo: memberInfo, mem_name, dependentId: dependantId };
    }

    return records;
  }
}
