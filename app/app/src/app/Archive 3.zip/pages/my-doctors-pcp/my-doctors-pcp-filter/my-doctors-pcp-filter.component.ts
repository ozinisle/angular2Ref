import { ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, OnDestroy } from '@angular/core';
import { DateState } from '@app/pages/my-claims/models/date-state.model';
import { DateSearchListInterface } from '@app/pages/my-claims/models/interfaces/claims-generic-models.interface';
import { GlobalUtils } from '@app/utils/global.utils';
import { PopoverController } from '@ionic/angular';
import { cloneDeep } from 'lodash-es';
import { Subject, Subscription } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { isValid } from 'date-fns';
import {
  FilterItemInterface,
  FilterOptionInterface,
  MyDoctorsPcpFilterInputInterface
} from '../models/filter/filter-model.interface';
import { Filter } from '../models/filter/filter.model';

@Component({
  selector: 'app-my-doctors-pcp-filter',
  templateUrl: './my-doctors-pcp-filter.component.html',
  styleUrls: ['./my-doctors-pcp-filter.component.scss']
})
export class MyDoctorsPcpFilterComponent implements OnInit, OnDestroy {
  @Output() componentOutput = new EventEmitter<MyDoctorsPcpFilterInputInterface>();
  @Input() getPopOver: any;
  @Input() componentInput;
  @Input() isDoctorAvailable;

  private unsubscribeHelper$: Subject<void> = new Subject<void>();
  public ismobile: boolean;
  public showClearLink = true;
  public somevar: any = '';
  public submenu: any = {};
  public clearFilterFlagSubjectSubscription: Subscription;
  public filterInput: MyDoctorsPcpFilterInputInterface = {
    componentInput: new Filter(),
    isFilterChanged: false
  };
  public radioFilters: FilterItemInterface[] = null;
  public checkboxFilters: FilterItemInterface[] = null;
  public calendarFilters: FilterItemInterface[] = null;
  public selectedValue: object = null;
  public defaultSortText = '';
  public dateState: DateState = null;
  public dateList: DateSearchListInterface[] = [];
  public hideDateRangeSelection = true;

  constructor(
    private cdRef: ChangeDetectorRef,
    private resizeService: GlobalUtils,
    private popoverController: PopoverController
  ) {
    this.dateState = new DateState(this.dateList);
  }

  ngOnInit() {
    this.filterInput.componentInput = cloneDeep(this.componentInput);
    this.populateFilter();
    this.resizeService.getIsMobile().pipe(takeUntil(this.unsubscribeHelper$))
    .subscribe((isMobile: boolean) => this.ismobile = isMobile );
  }

  ngOnDestroy(): void {
    this.unsubscribeHelper$.next();
    this.unsubscribeHelper$.complete();
  }

  private populateFilter() {
    this.radioFilters = [];
    this.checkboxFilters = [];
    this.calendarFilters = [];
    this.selectedValue = {};
    this.filterInput.componentInput.items.map((item: FilterItemInterface) => {
      this.submenu[item.headerText] = item.expanded;

      if (item.type === 'radio') {
        this.radioFilters.push(item);
      } else if (item.type === 'calendar') {
        this.calendarFilters.push(item);
        const customDateOption = item.list[item.list.length - 1];
        if (customDateOption.toDate) {
          const toDate = new Date(customDateOption.toDate);
          if (isValid(toDate)) {
            this.dateState.endRangeValue = customDateOption.toDate;
          }
        }
        if (customDateOption.fromDate) {
          const fromDate = new Date(customDateOption.fromDate);
          if (isValid(fromDate)) {
            this.dateState.startRangeValue = customDateOption.fromDate;
          }
        }

        this.hideDateRangeSelection = !customDateOption.selected;
      } else if (item.type === 'checkbox') {
        this.checkboxFilters.push(item);
      }

      if (item.type === 'radio' || item.type === 'calendar') {
        item.list.some((option: FilterOptionInterface) => {
          if (option.selected) {
            this.selectedValue[item.headerText] = option.text;
            if (item.type === 'radio') {
              this.defaultSortText = option.text;
            }
            return true;
          }
        });
      } else if (item.type === 'checkbox') {
        item.list.map((option: FilterOptionInterface) => {
          if (option.selected) {
            if (Object.prototype.toString.call(this.selectedValue[item.headerText]) === '[object Array]') {
              this.selectedValue[item.headerText].push(option.text);
            }
            this.selectedValue[item.headerText] = [option.text];
          }
        });
      }
    });
  }

  toggleSubmenu(menu: string) {
    if (typeof this.submenu[menu] === 'undefined' || this.submenu[menu] === null) {
      this.submenu[menu] = false;
    }

    this.submenu[menu] = !this.submenu[menu];

    if (menu !== 'Sort by') {
      this.filterInput.componentInput.items = this.filterInput.componentInput.items.map((item: FilterItemInterface) => {
        if (item.headerText === menu) {
          item.expanded = this.submenu[menu];
        }
        return item;
      });
    }

    this.cdRef.detectChanges();
  }

  public clearFilter() {
    this.filterInput.componentInput.items = this.filterInput.componentInput.items.map(filterCategory => {
      filterCategory.list = filterCategory.list.map(filterOption => {
        filterOption.selected = false;
        return filterOption;
      });
      if (filterCategory.headerText === 'Sort by') {
        filterCategory.list = filterCategory.list.map(filterOption => {
          if (filterOption.text === 'Most Recent') {
            filterOption.selected = true;
          }
          return filterOption;
        });
      }
      return filterCategory;
    });
    this.populateFilter();

    if (this.ismobile) {
      this.filterInput.isFilterChanged = false;
      this.filterInput.filterClearedFlag = true;
      this.popoverController.dismiss(this.filterInput);
    } else {
        this.componentOutput.emit(this.filterInput);
      }
  }

  manageRadioFilterSelection(event, categoryName, sortSelectionFlag?: boolean) {
    if (sortSelectionFlag) {
      this.defaultSortText = event.detail.value;
    }
    this.selectedValue[categoryName] = null;

    this.filterInput.componentInput.items = this.filterInput.componentInput.items.map(selectedFilter => {
      if (selectedFilter.headerText.toUpperCase() === categoryName.toUpperCase()) {
        selectedFilter.list = selectedFilter.list.filter(selectedItem => {
          if (selectedItem.text === event.detail.value) {
            selectedItem.selected = true;
            this.selectedValue[categoryName] = selectedItem.text;
            this.hideDateRangeSelection = selectedItem.text !== 'Custom Date Range';
            if (!this.hideDateRangeSelection) {
              selectedItem.fromDate = this.dateState.startRangeValue;
              selectedItem.toDate = this.dateState.endRangeValue;
            }
          } else {
            selectedItem.selected = false;
          }

          return selectedItem;
        });
      }
      return selectedFilter;
    });
  }

  manageCheckboxFilterSelection(event, categoryName) {
    const selectedMemberItems = [];
    let filterGroupItems = cloneDeep(this.filterInput.componentInput.items);

    filterGroupItems = filterGroupItems.map(selectedFilter => {
      if (selectedFilter.headerText.toUpperCase() === categoryName.toUpperCase()) {
        if (event.detail.value === 'All Members' || event.detail.value === 'All Specialties') {
          selectedFilter.list[selectedFilter.list.length - 1].selected = event.detail.checked;

          //if all option is selected, select all other options in the category
          selectedFilter.list = selectedFilter.list.map(listItem => {
            listItem.selected = event.detail.checked;
            return listItem;
          });
        }

        selectedFilter.list = selectedFilter.list.filter(selectedItem => {
          if (Object.prototype.toString.call(this.selectedValue[categoryName]) !== '[object Array]') {
            this.selectedValue[categoryName] = [];
          }
          if (selectedItem.text === event.detail.value) {
            selectedItem.selected = event.detail.checked;
            if (selectedItem.selected) {
              //add selection to checkbox values array
              if (categoryName === 'Member') {
                selectedMemberItems.push(selectedItem);
              }
            }
          }

          return selectedItem;
        });
      }
      return selectedFilter;
    });

    filterGroupItems = filterGroupItems.map(filterGroup => {
      if (filterGroup.headerText.toUpperCase() === categoryName.toUpperCase()) {
        //if all other options are selected excet the all options item select all options item
        const bufferSelected = filterGroup.list.filter((listItem, listItemIndex) => {
          if (listItem.selected && listItemIndex < filterGroup.list.length - 1) {
            return listItem;
          }
        });

        //if all other options except "all" is selected , mark "all" as selected else unselected
        filterGroup.list[filterGroup.list.length - 1].selected = bufferSelected.length >= filterGroup.list.length - 1;
      }
      return filterGroup;
    });

    if (categoryName === 'Member') {
      const isAnyMemberSelected: boolean = filterGroupItems.some(filterGroup => {
        if (filterGroup.headerText === 'Member') {
          const allMembersSelected: boolean = filterGroup.list[filterGroup.list.length - 1].selected;
          const selectedMembersArr: string[] = filterGroup.list.map(filterItem => {
            if (allMembersSelected || filterItem.selected) {
              return filterItem.text;
            }
          });

          const selectedMembers = selectedMembersArr.join('~');
          const selectedSpecialities = [];
          this.filterInput.componentInput.searchDataList[0].data.map(doctor => {
            if (selectedMembers.toUpperCase().indexOf(doctor['mem_name']) >= 0) {
              selectedSpecialities.push(doctor['providerSpeciality']);
            }
          });
          if (selectedMembersArr && selectedMembersArr.length > 0) {
            filterGroupItems = filterGroupItems.map(item => {
              if (item.headerText === 'Specialty') {
                let unhideCount = 0;
                item.list = item.list.map(specialityItem => {
                  specialityItem.hide = true;

                  if (selectedSpecialities.join('~').indexOf(specialityItem.text) >= 0) {
                    specialityItem.hide = false;
                    unhideCount++;
                    return specialityItem;
                  }

                  if (specialityItem.text === 'All Specialties' && unhideCount > 0) {
                    specialityItem.hide = false;
                  }

                  return specialityItem;
                });
              }
              return item;
            });
          }

          //remove undefined values from array and return the number of valid elements in it
          return selectedMembersArr.filter(e => e).length;
        }
      });

      //if no member is selected show all specialities
      if (!isAnyMemberSelected) {
        filterGroupItems = filterGroupItems.map(filterGroup => {
          if (filterGroup.headerText === 'Specialty') {
            filterGroup.list = filterGroup.list.map(filterItem => {
              filterItem.hide = false;
              return filterItem;
            });
          }
          return filterGroup;
        });
      }
    }

    this.filterInput.componentInput.items = filterGroupItems;

    //ppulate filter selection on screen by updating the screen bounded value this.checkboxFilters
    this.checkboxFilters = [];
    filterGroupItems.map(filterGroup => {
      if (filterGroup.headerText === 'Member' || filterGroup.headerText === 'Specialty') {
        this.selectedValue[filterGroup.headerText] = [];
        filterGroup.list.map(filterItem => {
          if (filterItem.selected) {
            this.selectedValue[filterGroup.headerText].push(filterItem.text);
          }
        });
        this.checkboxFilters.push(filterGroup);
      }
    });
  }

  closeFilter() {
    if (!this.hideDateRangeSelection) {
      this.filterInput.componentInput.items = this.filterInput.componentInput.items.map(filterGroup => {
        if (filterGroup.headerText === 'Date') {
          filterGroup.list = filterGroup.list.map(filterItem => {
            if (filterItem.text === 'Custom Date Range') {
              filterItem.fromDate = this.dateState.startRangeValue;
              filterItem.toDate = this.dateState.endRangeValue;
            }
            return filterItem;
          });
        }
        return filterGroup;
      });
    }
    if (this.ismobile) {
      this.filterInput.isFilterChanged = true;
      this.popoverController.dismiss(this.filterInput);
    } else {
      this.componentOutput.emit(this.filterInput)
    }
  }

  onStartDateChange($event) {
    this.dateState.startRangeValue = $event.target.value.split('T')[0];
  }

  onEndDateChange($event) {
    this.dateState.endRangeValue = $event.target.value.split('T')[0];
  }
}
