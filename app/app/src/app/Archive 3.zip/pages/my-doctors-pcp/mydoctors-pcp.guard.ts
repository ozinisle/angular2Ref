import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable } from 'rxjs';
import { AppSelectors } from '@app/store/selectors/app.selectors';

@Injectable({ providedIn: 'root' })
export class MyDoctorsPcpGuard implements CanActivate {
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    const scopename = this.scopeName ? this.scopeName : '';
    switch (scopename) {
      case 'AUTHENTICATED-AND-VERIFIED': {
        return true;
      }
      default: {
        return false;
      }
    }
  }
}

@Injectable({ providedIn: 'root' })
export class MyDoctorsChangePcpHomepageGuard implements CanActivate {
  constructor(private router: Router) {}
  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    const sourceURL = this.router.url;

    if (sourceURL.indexOf('/home') !== -1) {
      return true;
    }
    if (sourceURL.indexOf('/my-doctor/pcp-error') !== -1) {
      return true;
    }
    if (sourceURL.indexOf('/my-doctor/pcp-result') !== -1) {
      return true;
    }
    if (sourceURL.indexOf('/my-doctor/update-pcp-homepage') !== -1) {
      return true;
    }

    this.router.navigate(['/my-doctor']);
    return false;
  }
}
