import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MaintenanceComponent } from './maintenance/maintenance.component';
import { MyDoctorDetailsComponent } from './mydoctors/details/mydoctor-details.component';
import { MyDoctorsComponent } from './mydoctors/landing/mydoctors.component';
import { AddPcpComponent } from './pcp/add-pcp/add-pcp.component';
import { PcpErrorComponent } from './pcp/pcp-error/pcp-error.component';
import { PcpResultComponent } from './pcp/pcp-result/pcp-result.component';
import { UpdatePcpComponent } from './pcp/update-pcp/update-pcp.component';

const routes: Routes = [
  {
    path: '',
    component: MyDoctorsComponent
  },
  {
    path: 'details',
    component: MyDoctorDetailsComponent
  },

  {
    path: 'update-pcp',
    component: UpdatePcpComponent
  },

  {
    path: 'add-pcp',
    component: AddPcpComponent
  },
  {
    path: 'update-pcp-homepage',
    component: UpdatePcpComponent
  },
  {
    path: 'pcp-result',
    component: PcpResultComponent
  },
  {
    path: 'pcp-error',
    component: PcpErrorComponent
  },
  {
    path: 'maintenance',
    component: MaintenanceComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MyDoctorsPcpRouter {}
