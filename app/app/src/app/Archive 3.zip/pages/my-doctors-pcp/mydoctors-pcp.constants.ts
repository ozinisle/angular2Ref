export class MyDoctorsPcpConstants {
  public static YES = 'Yes';
  public static NO = 'No';
}
