export interface Provider {
  rowId: string;
  claimId: string;
  recordKey: string;
  providerPhone: string;
  providerNumber: string;
  providerType: string;
  providerName: string;
  memberFirstName: string;
  memberLastName: string;
  memberMiddleInitial: string;
  memberRelationship: string;
  providerSpeciality: string;
  dateOfservice: string;
  isAllowedChangePCP: boolean;
  isPCP: boolean;
  isPCPEligible: boolean;
  isRequiredPCP: boolean;
  pcpId: string;
  dependentId: string;
}

export type MyDoctorsFilterHeaderType = "Sort by" | "Specialty" | "Date" | "Member";
