import { Component } from '@angular/core';
import { EarnAndSaveService } from '../../services/earn-and-save/earn-and-save.service';

/**
 * @deprecated Not used for now.
 */
@Component({
  selector: 'app-earn-and-save',
  templateUrl: './earn-and-save.page.html',
  styleUrls: ['./earn-and-save.page.scss'],
  providers: [
    /* For testing only! Remove or comment out to use real service. */
    // { provide: EarnAndSaveService, useClass: EarnAndSaveMockService }
  ]
})
export class EarnAndSavePage {
  public isEarnAndSaveWidgetEnabled$ = this.earnAndSaveService.isEarnAndSaveWidgetEnabledForCurrentUser$;
  public isMaximizePlanWidgetEnabled$ = this.earnAndSaveService.isMaximizePlanWidgetEnabledForCurrentUser$;

  // prettier-ignore
  constructor(
    private earnAndSaveService: EarnAndSaveService,
  ) {}
}
