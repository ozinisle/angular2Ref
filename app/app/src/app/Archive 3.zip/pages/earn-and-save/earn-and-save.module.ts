import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/shared.module';
import { EarnAndSavePageRoutingModule } from './earn-and-save-routing.module';
import { EarnAndSavePage } from './earn-and-save.page';

/**
 * @deprecated Not used for now.
 */
@NgModule({
  imports: [SharedModule, EarnAndSavePageRoutingModule],
  declarations: [EarnAndSavePage],
})
export class EarnAndSavePageModule {}
