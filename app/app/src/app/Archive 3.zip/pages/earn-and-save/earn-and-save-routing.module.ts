import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EarnAndSavePage } from './earn-and-save.page';

const routes: Routes = [
  {
    path: '',
    component: EarnAndSavePage,
  },
];

/**
 * @deprecated Not used for now.
 */
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EarnAndSavePageRoutingModule {}
