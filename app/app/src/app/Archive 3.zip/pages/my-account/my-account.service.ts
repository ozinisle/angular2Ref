import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Store } from '@ngxs/store';
import { ConstantsService } from '@app/services/constants.service';
import { SetUserID } from '@app/store/actions/app.actions';
import { AppService } from '@app/services/app.service';

@Injectable({ providedIn: 'root' })
export class MyAccountService {
  private fpverifyUnecryptedResponse: any;
  private useridin: string;

  constructor(private http: HttpClient, private store: Store, private appService: AppService, private constants: ConstantsService) {}

  verifyUser(requestObj?) {
    this.useridin = requestObj.useridin;
    const request = { useridin: requestObj.useridin };
    return this.http.post(this.constants.verifyUserUrl, request);
  }

  verifyUserValid(requestObj?) {
    const request = { email: requestObj.email, mobilenum: requestObj.mobile };
    return this.http.post(this.constants.userNameVerify, request);
  }

  verifyUserAuth(requestObj?) {
    const request = Object.assign(requestObj, {
      useridin: this.useridin
    });
    return this.http.post(this.constants.verifyUserAuthUrl, request);
  }

  confirmIdentity(requestObj?) {
    const request = {
      useridin: this.getUserId(),
      dob: this.appService.getUTCDate(requestObj.dob)
    };
    this.store.dispatch(new SetUserID(request.useridin));
    return this.http.post(this.constants.identityVerify, request);
  }

  getUserId(): string {
    if (sessionStorage.getItem('fpverifyUnencryptedResponse')) {
      return JSON.parse(sessionStorage.getItem('fpverifyUnencryptedResponse')).userId
        ? JSON.parse(sessionStorage.getItem('fpverifyUnencryptedResponse')).userId
        : this.useridin;
    } else {
      return this.useridin;
    }
  }

  resetPassword(requestObj?) {
    const generatedRequest = {
      ...requestObj,
      useridin: this.useridin,
      webNonMigratedUser:
        this.fpverifyUnecryptedResponse && this.fpverifyUnecryptedResponse['webNonMigratedUser']
          ? this.fpverifyUnecryptedResponse['webNonMigratedUser']
          : 'FALSE'
    };
    return this.http.post(this.constants.resetPwd, generatedRequest);
  }

  getUnencryptedResponse() {
    return this.fpverifyUnecryptedResponse;
  }

  setUnencryptedResponse(res) {
    this.fpverifyUnecryptedResponse = res ? res : null;
    if (this.useridin == null && this.fpverifyUnecryptedResponse.userId) {
      this.useridin = this.fpverifyUnecryptedResponse.userId;
    }
    sessionStorage.setItem('fpverifyUnencryptedResponse', JSON.stringify(this.fpverifyUnecryptedResponse));
  }

  VerifyAccessCode(accesscode: any, isFWP: boolean): any {
    if (isFWP) {
      // Encrypted
      const generatedRequest = {
        useridin: this.getUserId(),
        accessCode: accesscode,
        commType: JSON.parse(sessionStorage.getItem('fpverifyUnencryptedResponse')).commType,
        commValue: JSON.parse(sessionStorage.getItem('fpverifyUnencryptedResponse')).commValue,
        userIdRequired: isFWP === true ? 'false' : 'true'
      };

      return this.http.post(this.constants.verifyRestAccessCodeUrl, generatedRequest);
    } else {
      const generatedRequest = {
        useridin: this.getUserId(),
        accessCode: accesscode,
        commType: JSON.parse(sessionStorage.getItem('fpverifyUnencryptedResponse')).commType,
        commValue: JSON.parse(sessionStorage.getItem('fpverifyUnencryptedResponse')).commValue,
        userIdRequired: 'true'
      };

      return this.http.post(this.constants.verifyRestAccessCodeUrl, generatedRequest);
    }
  }

  sendfunaccesscode() {
    const request = {
      useridin: this.getUserId(),
      commType: JSON.parse(sessionStorage.getItem('fpverifyUnencryptedResponse')).commType,
      commValue: JSON.parse(sessionStorage.getItem('fpverifyUnencryptedResponse')).commValue,
      webNonMigratedUser: JSON.parse(sessionStorage.getItem('fpverifyUnencryptedResponse')).webNonMigratedUser
    };
    return this.http.post(this.constants.sendfunaccesscodeUrl, request);
  }

  clearStorage() {
    sessionStorage.removeItem('fpw.hint');
    sessionStorage.removeItem('fpw.fpverifyuserResponse');
    sessionStorage.removeItem('fun.funverifyuserResponse');
    sessionStorage.removeItem('isauthenticated');
    sessionStorage.removeItem('otp');
    sessionStorage.removeItem('otpsuccess');
  }
}
