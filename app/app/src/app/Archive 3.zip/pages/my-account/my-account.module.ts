import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SmsRetriever } from '@ionic-native/sms-retriever/ngx';
import { IonicModule } from '@ionic/angular';
import { TextMaskModule } from 'angular2-text-mask';
import { AuthGuard } from '@app/guards/auth.guard';
import { RegistrationService } from '../registration/services/registration.service';
import { ConfirmidentityComponent } from './confirm-identity/confirmidentity.component';
import { CreatePasswordComponent } from './create-password/create-password.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ForgotUsernameComponent } from './forgot-username/forgot-username.component';
import { FpConfirmidentityComponent } from './fp-confirm-identity/fpconfirmidentity.component';
import { MY_ACCOUNT_ROUTER } from './my-account.routing';
import { MyAccountService } from './my-account.service';
import { CreatePasswordGuard } from './utils/create-password.guard';
import { ForgetPasswordFlowGuard } from './utils/forget-password-flow.guard';
import { ForgetUserNameFlowGuard } from './utils/forget-username-flow.guard';
import { VerifyAccessGuard } from './utils/verify-access.guard';
import { VerifyOTPaccesscodeComponent } from './verifyOTPaccesscode/verifyaccesscode.component';
import { AlertsModule } from '@app/components/alerts/alerts.module';
import { AppControlMessagesModule } from '@app/components/app-control-messages/app-control-messages.module';
import { NumberOnlyDirectiveModule } from '@app/directives/number-only/number-only.directive.module';
import { AutofocusDirectiveModule } from '@app/directives/autofocus/autofocus.directive.module';
import { PasswordControlMessageModule } from '@app/components/password-control-messages/password-control-message.module';

@NgModule({
  declarations: [
    ForgotPasswordComponent,
    ForgotUsernameComponent,
    CreatePasswordComponent,
    ConfirmidentityComponent,
    FpConfirmidentityComponent,
    VerifyOTPaccesscodeComponent
  ],
  exports: [],
  imports: [
    CommonModule,
    MY_ACCOUNT_ROUTER,
    FormsModule,
    ReactiveFormsModule,
    TextMaskModule,
    IonicModule,
    AlertsModule,
    AppControlMessagesModule,
    NumberOnlyDirectiveModule,
    AutofocusDirectiveModule,
    PasswordControlMessageModule
  ],
  providers: [
    AuthGuard,
    ForgetUserNameFlowGuard,
    ForgetPasswordFlowGuard,
    VerifyAccessGuard,
    CreatePasswordGuard,
    MyAccountService,
    RegistrationService,
    SmsRetriever
  ]
})
export class MyAccountModule {}
