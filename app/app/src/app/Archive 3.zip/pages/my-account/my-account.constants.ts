export const MY_ACCOUNT_CONSTANTS = {
  Success: '',
  VerificationMsgSuccess: 'Verification code sent!',
  VerificationMsgSuccessForMobile: 'Verification code is sent!',
  VerificationResentMsgSuccess: 'Verification code resent! You may need to check your spam folder.',
  NotificationMsg: 'Please check your email account or mobile number for your username.',

  controls: {
    accessCode1: 'accesscode1',
    accessCode2: 'accesscode2',
    accessCode3: 'accesscode3',
    accessCode4: 'accesscode4',
    accessCode5: 'accesscode5',
    accessCode6: 'accesscode6'
  }
};
