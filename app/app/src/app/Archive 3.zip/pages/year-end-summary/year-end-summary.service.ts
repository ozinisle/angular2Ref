import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AppSelectors } from '../../store/selectors/app.selectors';
import { YES_CONSTANTS } from './constants/yes.constants';
import {
  ClaimsSummaryFiterModel,
  ClaimsSummaryQueryModel,
  ClaimsSummaryQueryRecordModel,
  ClaimsSummaryRequestModel,
  ClaimsSummarySortModel
} from './modals/claim-summary.model';
import { ClaimsSummaryAmountsRequestModel } from './modals/claims-summary-amounts-request.model';
import {
  ClaimsSummaryFiterInterface,
  ClaimsSummaryQueryInterface,
  ClaimsSummaryQueryRecordInterface,
  ClaimsSummaryRequestModelInterface,
  ClaimsSummarySortInterface
} from './modals/interfaces/claims-summary.interface';
import { GetClaimsSummaryAmountsRequestModelInterface } from './modals/interfaces/claims-summary-amounts.interface';

@Injectable({ providedIn: 'root' })
export class YearEndSummaryService {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  constructor(private http: HttpClient) {}

  getClaimsSummaryAmounts() {
    const claimsSummaryAmountsReq: GetClaimsSummaryAmountsRequestModelInterface = new ClaimsSummaryAmountsRequestModel();
    if (this.useridin) {
      claimsSummaryAmountsReq.setUserId(this.useridin);
    }
    const url = YES_CONSTANTS.urls.claimsSummaryAmounts;
    return this.http.post(url, claimsSummaryAmountsReq);
  }
  getClaimsSummary(year, scrolIndex, sortField, sortFieldValue) {
    const url = YES_CONSTANTS.urls.claimsSummary;

    const claimsSummaryReq: ClaimsSummaryRequestModelInterface = new ClaimsSummaryRequestModel();
    const filterCriteria: ClaimsSummaryFiterInterface = new ClaimsSummaryFiterModel();
    const queryCriteria: ClaimsSummaryQueryInterface = new ClaimsSummaryQueryModel();
    const sortCriteria: ClaimsSummarySortInterface = new ClaimsSummarySortModel();
    const scroll: ClaimsSummaryQueryRecordInterface = new ClaimsSummaryQueryRecordModel();

    if (this.useridin) {
      claimsSummaryReq.setUserId(this.useridin);
    }
    if (sortField && sortFieldValue) {
      sortCriteria.setField(sortField);
      sortCriteria.setDirectionValue(sortFieldValue);
      claimsSummaryReq.sortCriteria = sortCriteria;
    }
    if (year) {
      filterCriteria.setField('Year');
      filterCriteria.setYearValue(year.toString());
      claimsSummaryReq.filterCriteria = filterCriteria;
    }

    if (scrolIndex) {
      claimsSummaryReq.queryCriteria = queryCriteria;
      scroll.setRecordStartIndex(scrolIndex);
      claimsSummaryReq.queryCriteria.scroll = scroll;
    }
    return this.http.post(url, claimsSummaryReq);
  }
  getPromoContent() {
    const url = YES_CONSTANTS.urls.promoUrl;
    return this.http.get(url);
  }
}
