import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { YES_ROUTER } from './year-end-summary.route';
import { YearEndSummaryService } from './year-end-summary.service';
import { YesComponent } from './yes/yes.component';
import { DeductiblesListModule } from '@app/components/deductibles-list/deductibles-list.module';
import { FinancialsListModule } from '@app/components/financials-list/financials-list.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { BreadcrumbModule } from '@app/components/breadcrumbs/breadcrumbs.module';

@NgModule({
  imports: [CommonModule, YES_ROUTER, IonicModule, FinancialsListModule, DeductiblesListModule, FontAwesomeModule, BreadcrumbModule],
  declarations: [YesComponent],
  providers: [YearEndSummaryService]
})
export class YearEndSummaryModule {}
