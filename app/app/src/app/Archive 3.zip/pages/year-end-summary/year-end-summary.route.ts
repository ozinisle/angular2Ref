import { Routes, RouterModule } from '@angular/router';
import { YesComponent } from './yes/yes.component';

const YES_ROUTES: Routes = [
  {
    path: '',
    component: YesComponent
  }
];
export const YES_ROUTER = RouterModule.forChild(YES_ROUTES);
