import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable } from 'rxjs/Observable';
import { AppSelectors } from '@app/store/selectors/app.selectors';

@Injectable({ providedIn: 'root' })
export class YesGuard implements CanActivate {
  @SelectSnapshot(AppSelectors.getUserState) userState: string;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  constructor(private router: Router) {}

  canActivate(): Observable<boolean> | Promise<boolean> | boolean {
    if (!this.useridin) {
      this.router.navigate(['login']);
    } else if (!this.userState) {
      this.router.navigate(['home']);
    } else {
      return true;
    }
  }
}
