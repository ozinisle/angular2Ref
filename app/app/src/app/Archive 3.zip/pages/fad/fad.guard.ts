import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';
import { Router } from '@angular/router';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable } from 'rxjs/Observable';
import { PostLoginModel } from '../../models/post-login.model';
import { AppSelectors } from '../../store/selectors/app.selectors';
import { SsoService } from '../sso/sso.service';

@Injectable({ providedIn: 'root' })
export class FadGuard implements CanActivate {
  @SelectSnapshot(AppSelectors.getPostLoginInfo) postLoginInfo: PostLoginModel;
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;

  constructor(
    private router: Router,
    private ssoService: SsoService) {
  }

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    if (this.isUserAuthenticatedAndVerified()) {
      if (this.postLoginInfo) {
        if (this.postLoginInfo.hasCI || this.postLoginInfo.hasSS || this.postLoginInfo.hasSSO) {
          this.ssoService.openSSO('fad');
          return false;
        }
      } else {
        this.router.navigate(['/home']);
        return false;
      }
    }
    return true;
  }

  isUserAuthenticatedAndVerified() {
    if (this.authToken) {
      const authTokenDetailsJson = this.authToken;
      if (authTokenDetailsJson && authTokenDetailsJson.scopename === 'AUTHENTICATED-AND-VERIFIED') {
        return true;
      }
    }
    return false;
  }
}
