import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NgxsModule } from '@ngxs/store';
import { AlertService } from '@app/services/alert.service';
import { ConstantsService } from '@app/services/constants.service';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { FadSearchListService } from '../fad-search-list/fad-search-list.service';
import { FadFacilityCompareComponent } from './fad-facility-compare.component';
import { FadFacilityCompareService } from './fad-facility-compare.service';
import { NgxMaskModule } from 'ngx-mask';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { StarRatingComponent } from '@app/pages/fad/components/star-rating/star-rating.component';
import { AlertsComponent } from '@app/components/alerts/alerts.component';

xdescribe('FadFacilityCompareComponent', () => {
  let component: FadFacilityCompareComponent;
  let fixture: ComponentFixture<FadFacilityCompareComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        IonicModule,
        RouterTestingModule,
        NgxMaskModule.forRoot(),
        FormsModule,
        ReactiveFormsModule,
        HttpClientTestingModule,
        NgxsModule.forRoot([])
      ],
      declarations: [FadFacilityCompareComponent, StarRatingComponent, AlertsComponent, StarRatingComponent],
      providers: [FadFacilityCompareService, ConstantsService, FadSearchListService, FadBreadCrumbsService, AlertService]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadFacilityCompareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
