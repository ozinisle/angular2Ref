import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FadDoctorRatingComponent } from './fad-doctor-rating.component';
import { IonicModule } from '@ionic/angular';

xdescribe('FadDoctorRatingComponent', () => {
  let component: FadDoctorRatingComponent;
  let fixture: ComponentFixture<FadDoctorRatingComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [IonicModule, FormsModule, ReactiveFormsModule],
      declarations: [FadDoctorRatingComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadDoctorRatingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
