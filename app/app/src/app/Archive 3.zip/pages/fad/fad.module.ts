import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Clipboard } from '@ionic-native/clipboard/ngx';
import { IonicModule } from '@ionic/angular';
import { NgxMaskModule } from 'ngx-mask';
import { RemoveSelectArrowDirective } from '@app/directives/remove-select-arrow.directive';
import { AlertsModule } from '@app/components/alerts/alerts.module';
import { FadBreadCrumbsComponent } from './fad-bread-crumbs/fad-bread-crumbs.component';
import { FadCostBreakdownComponent } from './fad-cost-breakdown/fad-cost-breakdown.component';
import { FadDoctorProfileComponent } from './fad-doctor-profile/fad-doctor-profile.component';
import { FadDoctorProfileResolver } from './fad-doctor-profile/fad-doctor-profile.resolver';
import { FadDoctorRatingComponent } from './fad-doctor-rating/fad-doctor-rating.component';
import { FadFacilityCardComponent } from './fad-facility-card/fad-facility-card.component';
import { FadFacilityCompareComponent } from './fad-facility-compare/fad-facility-compare.component';
import { FadFacilityListComponent } from './fad-facility-list/fad-facility-list.component';
import { FadFacilityProfileComponent } from './fad-facility-profile/fad-facility-profile.component';
import { FadFacilityProfileResolver } from './fad-facility-profile/fad-facility-profile.resolver';
import { FadFacilitySearchFilterComponent } from './fad-facility-search-filter/fad-facility-search-filter.component';
import { FadLandingPageComponent } from './fad-landing-page/fad-landing-page.component';
import { FadMedicalIndexComponent } from './fad-medical-index/fad-medical-index.component';
import { FadNoDocsPageComponent } from './fad-no-docs-page/fad-no-docs-page.component';
import { FadPastSearchQueryListComponent } from './fad-past-search-query-list/fad-past-search-query-list.component';
import { FadProfessionalCompareComponent } from './fad-professional-compare/fad-professional-compare.component';
import { FadProfileCardComponent } from './fad-profile-card/fad-profile-card.component';
import { FadProviderCompareComponent } from './fad-provider-compare/fad-provider-compare.component';
import { FadProviderFacilityCardComponent } from './fad-provider-facility-card/fad-provider-facility-card.component';
import { FadProviderFacilityListComponent } from './fad-provider-facility-list/fad-provider-facility-list.component';
import { FadReviewQuestionComponent } from './fad-review/fad-review-question/fad-review-question.component';
import { FadReviewComponent } from './fad-review/fad-review.component';
import { RatingComponent } from './fad-review/rating/rating.component';
import { FadSearchFilterComponent } from './fad-search-filter/fad-search-filter.component';
import { FadSearchListComponent } from './fad-search-list/fad-search-list.component';
import { FadSearchResultsComponent } from './fad-search-results/fad-search-results.component';
import { FadSearchResultsResolver } from './fad-search-results/fad-search-results.resolver';
import { FadSpecialtySearchFilterComponent } from './fad-specialty-search-filter/fad-specialty-search-filter.component';
import { FadSuggestAnEditDialogComponent } from './fad-suggest-an-edit-dialog/fad-suggest-an-edit-dialog.component';
import { FadSuggestAnEditDialogService } from './fad-suggest-an-edit-dialog/fad-suggest-an-edit-dialog.service';
import { FadTooltipComponent } from './fad-tooltip/fad-tooltip.component';
import { FadGuard } from './fad.guard';
import { FAD_ROUTER } from './fad.routing';
import { PopoverComponent } from './popover/popover.component';
import { SendProviderEmailInquiryComponent } from './send-provider-email-inquiry/send-provider-email-inquiry.component';
import { MatListModule } from '@angular/material/list';
import { AppControlMessagesModule } from '@app/components/app-control-messages/app-control-messages.module';
import { HelpChoosingNetworkComponent } from './help-choosing-network/help-choosing-network.component';
import { IabClickBlockModule } from '@app/components/Iab-component/iab-click-block.module';
import { FadFooterModule } from '@app/pages/fad/components/fad-footer/fad-footer.module';
import { AwardDetailsModule } from '@app/pages/fad/components/award-details/award-details.module';
import { AlegeusLinechartModule } from '@app/components/alegeus-line-chart/alegeus-linechart.module';
import { CampaignModule } from '@app/components/campaign-2/campaign.module';
import { StarRatingModule } from '@app/pages/fad/components/star-rating/star-rating.module';
import { CostBreakdownFinancialsFilterModule } from '@app/pages/fad/components/cost-breakdown-financialsfilter/cost-breakdown-financials-filter.module';
import { MassGovLeaveModule } from '@app/components/mass-gov-leave-component/mass-gov-leave.module';
import { FadSendEmailPopoverModule } from '@app/pages/fad/components/fad-send-email-popover/fad-send-email-popover.module';
import { FadFinancialInfoModule } from '@app/pages/fad/components/fad-financial-info/fad-financial-info.module';
import { FadMyPlanFinancialsModule } from '@app/pages/fad/components/fad-my-plan-financials/fad-my-plan-financials.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { TelehealthCampaignModule } from '@app/components/telehealth-campaign/telehealth-campaign.module';
import { TelehealthCampaignMobileModule } from '@app/components/telehealth-campaign-mobile/telehealth-campaign-mobile.module';

@NgModule({
  imports: [
    CommonModule,
    FAD_ROUTER,
    ReactiveFormsModule,
    FormsModule,
    IonicModule,
    AlertsModule,
    NgxMaskModule,
    MatListModule,
    AppControlMessagesModule,
    IabClickBlockModule,
    FadFooterModule,
    AwardDetailsModule,
    AlegeusLinechartModule,
    CampaignModule,
    StarRatingModule,
    CostBreakdownFinancialsFilterModule,
    MassGovLeaveModule,
    FadSendEmailPopoverModule,
    FadFinancialInfoModule,
    FadMyPlanFinancialsModule,
    FontAwesomeModule,
    TelehealthCampaignModule,
    TelehealthCampaignMobileModule
  ],
  exports: [],
  declarations: [
    FadLandingPageComponent,
    FadMedicalIndexComponent,
    FadSearchResultsComponent,
    FadNoDocsPageComponent,
    FadSearchFilterComponent,
    FadSearchListComponent,
    FadDoctorProfileComponent,
    FadFacilityProfileComponent,
    FadProfileCardComponent,
    FadPastSearchQueryListComponent,
    FadProviderCompareComponent,
    FadProfessionalCompareComponent,
    FadFacilityCompareComponent,
    FadCostBreakdownComponent,
    FadDoctorRatingComponent,
    FadFacilityListComponent,
    FadFacilityCardComponent,
    FadFacilitySearchFilterComponent,
    FadSpecialtySearchFilterComponent,
    FadBreadCrumbsComponent,
    FadReviewComponent,
    FadReviewQuestionComponent,
    RatingComponent,
    FadProviderFacilityListComponent,
    FadProviderFacilityCardComponent,
    FadTooltipComponent,
    PopoverComponent,
    RemoveSelectArrowDirective,
    SendProviderEmailInquiryComponent,
    FadSuggestAnEditDialogComponent,
    HelpChoosingNetworkComponent
  ],
  providers: [
    FadSearchResultsResolver,
    FadDoctorProfileResolver,
    FadFacilityProfileResolver,
    FadGuard,
    Clipboard,
    FadSuggestAnEditDialogService
  ]
})
export class FadModule {}
