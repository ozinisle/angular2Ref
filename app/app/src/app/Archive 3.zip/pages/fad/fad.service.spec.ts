import { inject, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { FadService } from './fad.service';
import { IonContent } from '@ionic/angular';
import { HttpClientTestingModule } from '@angular/common/http/testing';

xdescribe('FadService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [FadService, IonContent]
    });
  });

  it(
    'should be created',
    inject([FadService], (service: FadService) => {
      expect(service).toBeTruthy();
    })
  );
});
