import { BreadCrumbInterface } from '../modals/interfaces/fad.interface';

export class FadUtilities {}

export class BreadCrumb implements BreadCrumbInterface {
  private label: string;

  private url: string;

  private stackIndex: number;

  getLabel(): string {
    return this.label;
  }

  setLabel(label: string): BreadCrumb {
    this.label = label;
    return this;
  }

  getUrl(): string {
    return this.url;
  }
  setUrl(url: string): BreadCrumb {
    this.url = url;
    return this;
  }

  getStackIndex(): number {
    return this.stackIndex;
  }
  setStackIndex(stackIndex: number): BreadCrumb {
    this.stackIndex = stackIndex;
    return this;
  }
}
