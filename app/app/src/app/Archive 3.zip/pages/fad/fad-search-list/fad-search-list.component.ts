import { ChangeDetectorRef, Component, ElementRef, EventEmitter, Input, OnChanges, Output, SimpleChanges, ViewChild } from '@angular/core';

import { FadProfessionalCompareService } from '../fad-professional-compare/fad-professional-compare.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadNoDocsPageInputDataModel } from '../modals/fad-no-docs-page.modal';
import { FadProfileCardComponentInputModel } from '../modals/fad-profile-card.modal';
import { FadSearchListComponentOutputModel } from '../modals/fad-search-list.modal';
import { FadNoDocsPageInputDataModelInterface } from '../modals/interfaces/fad-no-docs-page.interface';
import { FadNoSearchResultsPageConsumer, FadProfileCardConsumer } from '@app/pages/fad/modals/interfaces/fad.interface';
import { FadSearchListComponentInputModelInterface } from '@app/pages/fad/modals/interfaces/fad-search-list.interface';
import {
  FadProfessionalInterface,
  GetSearchByProfessionalResponseModelInterface
} from '@app/pages/fad/modals/interfaces/search-professional.interface';
import { FadSearchListService } from '@app/pages/fad/fad-search-list/fad-search-list.service';
import { FadResouceTypeCodeConfig } from '@app/pages/fad/modals/types/fad.types';
import { FadProfileCardComponentOutputModelInterface } from '@app/pages/fad/modals/interfaces/fad-profile-card.interface';

@Component({
  selector: 'app-fad-search-list',
  templateUrl: './fad-search-list.component.html',
  styleUrls: ['./fad-search-list.component.scss']
})
export class FadSearchListComponent implements OnChanges, FadNoSearchResultsPageConsumer, FadProfileCardConsumer {
  @Output() componentOutput: EventEmitter<any> = new EventEmitter<FadSearchListComponentOutputModel>();

  @Output() clearFilter: EventEmitter<any> = new EventEmitter<FadSearchListComponentOutputModel>();

  @Input() componentInput: FadSearchListComponentInputModelInterface;
  @Input() hpnZeroResults: boolean;

  @ViewChild('profileCardList') profileCardList: ElementRef;

  // No search results page consumption requirement
  public noSearchResultsPageData: FadNoDocsPageInputDataModelInterface = new FadNoDocsPageInputDataModel();
  public isNoSearchResults = false;
  // End: No search results page consumption requirement

  public searchResponse: GetSearchByProfessionalResponseModelInterface;
  public professionalsList: FadProfessionalInterface[] = null;
  public selectedProfessionals: FadProfessionalInterface[] = [];
  private maxSelectionAllowed = 5;
  public list: number[] = [];
  isFilterChanged: boolean;

  constructor(
    private fadSearchListService: FadSearchListService,
    private fadProfessionalCompareService: FadProfessionalCompareService,
    private fadSearchResultsService: FadSearchResultsService,
    private cdRef: ChangeDetectorRef
  ) {
    this.noSearchResultsPageData.type = FadResouceTypeCodeConfig.professional;
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes) {
      this.componentInput = Object.assign({}, changes.componentInput.currentValue);
      this.isFilterChanged = this.fadSearchResultsService.filterChanged;
      if (this.componentInput) {
        this.searchResponse = this.componentInput.searchResults;
        if (this.searchResponse) {
          if (this.fadSearchListService.isFilterChangedFlag === true) {
            this.fadSearchListService.isFilterChangedFlag = false;
            this.clearProfileSelections();
          }
          if (this.fadProfessionalCompareService.getSearchResult() == null) {
            this.clearProfileSelections();
          }
          this.professionalsList = this.searchResponse.professionals;
          if (this.professionalsList ) {
            this.selectedProfessionals = this.professionalsList.filter(professional => professional.isChecked);
          }
          const disableFurtherSelection = this.selectedProfessionals && this.selectedProfessionals.length >= this.maxSelectionAllowed;
          this.professionalsList = this.professionalsList.map(item => ({
            ...item,
            isDisabled: item.isChecked ? false : disableFurtherSelection
          }));
          this.isNoSearchResults = false;
        } else {
          this.isNoSearchResults = true;
        }
        this.cdRef.detectChanges();
      }
    }
  }

  // FadProfileCardConsumer consumption requirement
  public getProfileCardInput(professional: FadProfessionalInterface): FadProfileCardComponentInputModel {
    return new FadProfileCardComponentInputModel(professional);
  }

  public onSearchListComponentInteraction(event) {
    this.clearFilter.emit(event);
  }
  public onProfileCardComponentInteraction(profileCardCompOutput: FadProfileCardComponentOutputModelInterface) {
    const index = this.professionalsList.findIndex(item => item.providerId === profileCardCompOutput.professional.providerId);
    const selectedItem = this.professionalsList[index];
    selectedItem.isChecked = profileCardCompOutput.isSelected;
    this.selectedProfessionals = this.professionalsList.filter(item => item.isChecked);
    const fadSeachListComponentOutput = {
      selectedProfessionals: this.selectedProfessionals
    };
    const disableFurtherSelection = this.selectedProfessionals && this.selectedProfessionals.length >= this.maxSelectionAllowed;
    this.professionalsList = this.professionalsList.map(item => {
      item.isDisabled = item.isChecked ? false : disableFurtherSelection;
      return item;
    });

    this.fadProfessionalCompareService.setSearchResult(this.selectedProfessionals);
    this.componentOutput.emit({ fadSeachListComponentOutput, index, isChecked: profileCardCompOutput.isSelected });
  }

  public clearProfileSelections() {
    this.selectedProfessionals = [];
    if (this.profileCardList !== undefined) {
      const checkBoxList: NodeListOf<Element> = this.profileCardList.nativeElement.querySelectorAll('[type="checkbox"]');
      Array.from(checkBoxList).forEach(checkBox => {
        const chkBox = checkBox as HTMLInputElement;
        chkBox.removeAttribute('checked');
        chkBox.checked = false;
      });
    }
  }
}
