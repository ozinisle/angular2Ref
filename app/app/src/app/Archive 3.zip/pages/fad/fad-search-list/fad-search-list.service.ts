import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class FadSearchListService {
  public isFilterChangedFlag = false;

  isFilterChanged(value) {
    this.isFilterChangedFlag = value;
  }
}
