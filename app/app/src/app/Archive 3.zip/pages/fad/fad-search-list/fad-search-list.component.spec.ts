import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '@app/services/constants.service';
import { FadLandingPageService } from '../fad-landing-page/fad-landing-page.service';
import { FadProfessionalCompareService } from '../fad-professional-compare/fad-professional-compare.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadSearchListComponent } from './fad-search-list.component';
import { FadSearchListService } from './fad-search-list.service';
import { IonContent, IonicModule } from '@ionic/angular';
import { FadNoDocsPageComponent } from '@app/pages/fad/fad-no-docs-page/fad-no-docs-page.component';

xdescribe('FadSearchListComponent', () => {
  let component: FadSearchListComponent;
  let fixture: ComponentFixture<FadSearchListComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [IonicModule, RouterTestingModule, HttpClientTestingModule, NgxsModule.forRoot([])],
      declarations: [FadSearchListComponent, FadNoDocsPageComponent],
      providers: [
        FadSearchListService,
        FadSearchResultsService,
        FadProfessionalCompareService,
        ConstantsService,
        FadLandingPageService,
        IonContent
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadSearchListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
