import { inject, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FadPastSearchQueryListService } from './fad-past-search-query-list.service';
import { IonContent, IonicModule } from '@ionic/angular';

xdescribe('FadPastSearchQueryListService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [IonicModule, HttpClientTestingModule],
      providers: [FadPastSearchQueryListService, IonContent]
    });
  });

  it('should be created', inject([FadPastSearchQueryListService], (service: FadPastSearchQueryListService) => {
    expect(service).toBeTruthy();
  }));
});
