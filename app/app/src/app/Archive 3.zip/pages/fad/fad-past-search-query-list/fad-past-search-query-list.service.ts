import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { FAD_CONSTANTS } from '../constants/fad.constants';
import { FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import { FadVitalsSearchHistoryResponseModelInterface } from '../modals/interfaces/fad-vitals-collection.interface';
import { HttpClient } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export class FadPastSearchQueryListService {
  public searchControlValues: FadLandingPageSearchControlValuesInterface = null;

  constructor(private httpClient: HttpClient) {}

  getVitalsSearchHistory(): Observable<FadVitalsSearchHistoryResponseModelInterface> {
    const url = FAD_CONSTANTS.jsonurls.fadSearchHistoryUrl;
    return this.httpClient.get<FadVitalsSearchHistoryResponseModelInterface>(url);
  }
}
