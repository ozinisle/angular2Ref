import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { FadPastSearchQueryListComponent } from './fad-past-search-query-list.component';
import { FadPastSearchQueryListService } from './fad-past-search-query-list.service';
import { IonicModule } from '@ionic/angular';
import { MatListModule } from '@angular/material/list';

xdescribe('FadPastSearchQueryListComponent', () => {
  let component: FadPastSearchQueryListComponent;
  let fixture: ComponentFixture<FadPastSearchQueryListComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [IonicModule, HttpClientTestingModule, MatListModule, RouterTestingModule],
      providers: [FadPastSearchQueryListService],
      declarations: [FadPastSearchQueryListComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadPastSearchQueryListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
