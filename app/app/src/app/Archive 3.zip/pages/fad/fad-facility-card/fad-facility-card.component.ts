import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { StarRatingComponentInputModelInterface } from '../components/star-rating/star-rating.interface';
import { StarRatingComponentInputModel } from '../components/star-rating/star-rating.model';
import { FAD_CONSTANTS } from '../constants/fad.constants';
import { FadFacilityCardComponentOutputModel } from '../modals/fad-profile-card.modal';
import {
  FadFacilityCardComponentInputModelInterface,
  FadFacilityCardComponentOutputModelInterface
} from '../modals/interfaces/fad-profile-card.interface';

import { Router } from '@angular/router';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { PopoverController } from '@ionic/angular';
import { from } from 'rxjs';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import { PopoverComponent } from '../popover/popover.component';

@Component({
  selector: 'app-fad-facility-card',
  templateUrl: './fad-facility-card.component.html',
  styleUrls: ['./fad-facility-card.component.scss']
})
export class FadFacilityCardComponent implements OnInit {
  @Output() componentOutput: EventEmitter<FadFacilityCardComponentOutputModelInterface> = new EventEmitter<
    FadFacilityCardComponentOutputModelInterface
  >();

  @Input() componentInput: FadFacilityCardComponentInputModelInterface;
  @Input() disbaleSelection: boolean;

  // temporary stuff
  public doctorStarRating: StarRatingComponentInputModelInterface;
  public checked = false;
  // end of temporary stuff
  public tier: string;
  public tierTooltip = new Array();
  public facilityName: string;
  public speciality: string;
  public medicalGroup: string;
  public address: string;
  public phoneNumber: string;
  public awards = [];
  public numberOfLocations: number;
  public costDollars = '00';
  public costPennies = '00';
  public costAvailable = false;
  public isProcedure = false;
  public accordianToggleStatus: any = {};
  public disclaimers: any;
  public disclaimersText: string;
  public disclaimersFlag: boolean;
  public toggleShowMoreLocationStatus = false;
  public costNotAvailableToolTipVisible = false;
  public blueDistinct: string;
  public blueDistinctPlus: string;
  public tierTooltipDescription: string;
  public fasFlag = false;
  public blueAwardFlag = false;
  public endDateDisclaimers: string;
  public endDateDisclaimersFlag: boolean;
  public endDateDisclaimersDate: string;

  toolTipVisible = false;

  constructor(
    private router: Router,
    private fadSearchResultsService: FadSearchResultsService,
    private facilityProfileService: FadFacilityProfileService,
    private callNumber: CallNumber,
    private popoverController: PopoverController
  ) {}

  ngOnInit() {
    try {
      if (JSON.parse(sessionStorage.getItem('tiersLabel'))) {
        this.tierTooltip = JSON.parse(sessionStorage.getItem('tiersLabel'));
      }
      this.facilityName = this.componentInput.facility.facilityName;
      if (this.componentInput.facility.disclaimers) {
        this.disclaimers = this.componentInput.facility.disclaimers;
        if (this.disclaimers && this.disclaimers.category && this.disclaimers.category === 'on_record' && this.disclaimers.text) {
          this.disclaimersFlag = true;
          this.disclaimersText = this.disclaimers.text;
        }
      }

      this.speciality = this.componentInput.facility.specialty;
      this.blueDistinct = FAD_CONSTANTS.text.blueDistinct;
      this.blueDistinctPlus = FAD_CONSTANTS.text.blueDistinctPlus;
      if (this.componentInput.facility.locations) {
        this.numberOfLocations = this.componentInput.facility.locations.length;
        const firstLocation = this.componentInput.facility.locations[0];
        this.medicalGroup = firstLocation.name;
        this.address = firstLocation.address;
        this.phoneNumber = firstLocation.phone;
        this.endDateDisclaimers = firstLocation.endDateDisclaimers.text;
        this.endDateDisclaimersFlag = firstLocation.endDateDisclaimers.showEndDateDisclmrs;
        this.endDateDisclaimersDate = firstLocation.endDateDisclaimers.futureTerminationDate;
        this.awards = [];

        this.accordianToggleStatus = {};
        if (firstLocation.awards && firstLocation.awards.length) {
          const blueAwards = firstLocation.awards.filter(award => {
            return award.name.indexOf('BLUE DISTINCTION') >= 0;
          });
          if (blueAwards.length > 0) {
            this.awards = [{ name: 'Blue Distinctions', awardDetails: [] }];
            blueAwards.forEach(award => {
              if (award.awardDetails.length) {
                this.blueAwardFlag = true;
                award.awardDetails.forEach(awardDetail => {
                  this.awards[0].awardDetails.push(awardDetail);
                });
              }
            });
          }
        }

        /* COST IS MISSING */
        /* kalagi01: DO NOT DELETE******************/
        if (firstLocation.facilityCost && firstLocation.facilityCost.memberCost >= 0) {
          const costString: string = firstLocation.facilityCost.memberCost + '';
          this.costDollars = costString.split('.')[0];
          this.costPennies = costString.split('.')[1];
          this.costAvailable = true;
        } else {
          this.costAvailable = false;
        }
        if (firstLocation && firstLocation.tiers && firstLocation.tiers.description) {
          this.tier = firstLocation.tiers.description;
          this.getToolTipDescription(this.tierTooltip, this.tier);
        }
      } else {
        this.numberOfLocations = 0;
      }

      // temporary stuff
      this.doctorStarRating = new StarRatingComponentInputModel();
      if (this.componentInput.facility.reviews) {
        if (this.componentInput.facility.reviews.overallRating) {
          this.doctorStarRating.ratingInPercentage = parseInt(
            // tslint:disable-next-line:no-magic-numbers
            '' + (parseFloat(this.componentInput.facility.reviews.overallRating.toString()) * 100) / 5,
            10
          );
        }

        this.doctorStarRating.totalRatings = this.componentInput.facility.reviews.totalRatings;
        if (this.componentInput.facility.reviews.overallRating) {
          this.doctorStarRating.overAllRating = parseFloat(this.componentInput.facility.reviews.overallRating.toString());
        }
        // end of temporary stuff
      }
    } catch (exception) {}

    const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
    if (searchCriteria) {
      this.isProcedure = searchCriteria.getSearchText().isProcedure();
    }
  }
  callHelpLine(number: string) {
    from(this.callNumber.callNumber(number, true)).subscribe();
  }

  getToolTipDescription(toolTip, tier) {
    this.tierTooltipDescription = '';
    if (toolTip) {
      toolTip.forEach(toolTips => {
        if (toolTips.toolTip.code && toolTips.toolTip.code.toLowerCase() === tier.toLowerCase()) {
          this.tierTooltipDescription = toolTips.toolTip.description;
        }
      });
    }
    return this.tierTooltipDescription;
  }

  toggleAccordion(listItem) {
    if (this.accordianToggleStatus[listItem] === undefined) {
      this.accordianToggleStatus[listItem] = false;
    }
    this.accordianToggleStatus[listItem] = !this.accordianToggleStatus[listItem];
  }

  public openProfile(event): void {
    try {
      const facilityDetails: any = this.componentInput.facility;
      this.facilityProfileService.facilityProfile = facilityDetails.facilityId;
      sessionStorage.setItem('facilityProfileId', facilityDetails.facilityId.toString());

      sessionStorage.setItem('locationId', this.componentInput.facility.locations[0].id.toString());
      setTimeout(() => {
        this.router.navigate(['/fad/facility-profile']);
      }, 1);
    } catch (exception) {}
  }

  public toggleShowMoreLocation() {
    this.toggleShowMoreLocationStatus = !this.toggleShowMoreLocationStatus;
  }
  /**
   * @description: get triggered when check box selection changes in the profile card. Triggers an output with the necessary info to
   * the parent component
   */
  public onSelectionChange(event): void {
    try {
      const output: FadFacilityCardComponentOutputModelInterface = new FadFacilityCardComponentOutputModel();
      output.facility = this.componentInput.facility;
      output.facility.isChecked = event.detail.checked;
      output.isSelected = event.detail.checked;
      this.checked = event.detail.checked;
      this.componentOutput.emit(output);
    } catch (exception) {}
  }

  public doAuthentication() {
    this.router.navigateByUrl('/login');
  }

  public reviewBenifits(): void {
    throw new Error('yet to be coded');
  }

  showCostCostAvailableToolTip() {
    this.costNotAvailableToolTipVisible = !this.costNotAvailableToolTipVisible;
  }
  async showToolTip(ev) {
    this.toolTipVisible = !this.toolTipVisible;
    if (this.toolTipVisible) {
      const popover = await this.popoverController.create({
        component: PopoverComponent,
        event: ev,
        mode: 'ios',
        cssClass: 'drupal-tooltip',
        componentProps: {
          tooltip: {
            targetUrl: null,
            toolTipdataPlans: this.tierTooltipDescription,
            isplandetails: null
          }
        }
      });
      popover.onDidDismiss().then(dataReturned => {
        this.toolTipVisible = !this.toolTipVisible;
      });

      return await popover.present();
    }
  }
}
