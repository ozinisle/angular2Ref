import { HttpClientTestingModule } from '@angular/common/http/testing';
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { PopoverController, IonContent, IonicModule } from '@ionic/angular';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '@app/services/constants.service';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadFacilityCardComponent } from './fad-facility-card.component';
import { NgxMaskModule } from 'ngx-mask';
import { StarRatingComponent } from '@app/pages/fad/components/star-rating/star-rating.component';

xdescribe('FadFacilityCardComponent', () => {
  let component: FadFacilityCardComponent;
  let fixture: ComponentFixture<FadFacilityCardComponent>;
  const popoverSpy = jasmine.createSpyObj('Popover', ['present']);
  const popoverCtrlSpy = jasmine.createSpyObj('PopoverController', ['create']);
  popoverCtrlSpy.create.and.callFake(() => {
    return popoverSpy;
  });

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [IonicModule, RouterTestingModule, HttpClientTestingModule, NgxMaskModule.forRoot(), NgxsModule.forRoot([])],
      declarations: [FadFacilityCardComponent, StarRatingComponent],
      providers: [
        FadSearchResultsService,
        ConstantsService,
        IonContent,
        FadFacilityProfileService,
        CallNumber,
        {
          provide: PopoverController,
          useValue: popoverCtrlSpy
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadFacilityCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
