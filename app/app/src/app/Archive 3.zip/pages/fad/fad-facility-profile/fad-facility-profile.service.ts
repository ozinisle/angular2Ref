import { HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable } from 'rxjs/Observable';
import { AppSelectors } from '../../../store/selectors/app.selectors';
import { FAD_CONSTANTS } from '../constants/fad.constants';
import { FadService } from '../fad.service';
import {
  FadFacilityProfileRequestModelInterface,
  FadFacilityResponseModelInterface
} from '../modals/interfaces/fad-facility-profile-details.interface';
import { tap } from 'rxjs/operators';
import { format } from 'date-fns';

@Injectable({ providedIn: 'root' })
export class FadFacilityProfileService {
  @SelectSnapshot(AppSelectors.getFADHCCSFlag) hccsFlag: string;

  public facilityProfile: any;
  constructor(private fadService: FadService) {}

  getFadGetprofessionalprofileDetails(request: FadFacilityProfileRequestModelInterface): Observable<FadFacilityResponseModelInterface> {
    let params = new HttpParams();

    // tslint:disable-next-line:forin
    for (const key in request) {
      params = params.append(key.toString(), request[key]);
    }
    if (this.hccsFlag !== null) {
      request['hccsFlag'] = this.hccsFlag;
    }
    return this.fadService.post<FadFacilityResponseModelInterface>(FAD_CONSTANTS.urls.facilityProfile, request)
    .pipe(
      tap(res=>{
        for(let location of res.facility.location) {
          if(location.endDateDisclaimers && location.endDateDisclaimers.futureTerminationDate) {
            const futureTerminationDate = new Date(location.endDateDisclaimers.futureTerminationDate).toISOString().split('T')[0];
            location.endDateDisclaimers.futureTerminationDate = format(new Date(futureTerminationDate), 'MM/dd/yyyy');
          }
        }
      })
    )
  }
}
