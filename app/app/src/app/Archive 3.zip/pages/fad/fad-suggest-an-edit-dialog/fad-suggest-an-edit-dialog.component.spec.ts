import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { FadSuggestAnEditDialogComponent } from './fad-suggest-an-edit-dialog.component';
import { FadSuggestAnEditDialogService } from './fad-suggest-an-edit-dialog.service';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgxMaskModule } from 'ngx-mask';
import { NgxsModule } from '@ngxs/store';
import { PopoverController, NavParams, ModalController, IonicModule } from '@ionic/angular';
import { ConstantsService } from '@app/services/constants.service';

class MockNavParams {
  data = {};

  get(param) {
    return this.data[param];
  }
}

describe('FadSuggestAnEditDialogComponent', () => {
  let component: FadSuggestAnEditDialogComponent;
  let fixture: ComponentFixture<FadSuggestAnEditDialogComponent>;
  const popoverSpy = jasmine.createSpyObj('Popover', ['present']);
  const popoverCtrlSpy = jasmine.createSpyObj('PopoverController', ['create']);
  popoverCtrlSpy.create.and.callFake(() => {
    return popoverSpy;
  });
  const modalSpy = jasmine.createSpyObj('Modal', ['present']);
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);
  modalCtrlSpy.create.and.callFake(() => {
    return modalSpy;
  });

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [IonicModule, RouterTestingModule, HttpClientTestingModule, NgxMaskModule.forRoot(), NgxsModule.forRoot([])],
      declarations: [FadSuggestAnEditDialogComponent],
      providers: [
        FadSuggestAnEditDialogService,
        ConstantsService,
        { provide: NavParams, useClass: MockNavParams },
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        },
        {
          provide: PopoverController,
          useValue: popoverCtrlSpy
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadSuggestAnEditDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
