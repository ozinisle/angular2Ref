import { Component, Input, OnInit } from '@angular/core';
import { ModalController, NavParams } from '@ionic/angular';
import { FadLandingPageSearchControlValues } from '../modals/fad-landing-page.modal';
import { FadSuggestAnEditSubmitFeedbackMessage, FadSuggestAnEditSubmitFeedbackRequest } from '../modals/fad-suggest-an-edit-dialog.model';
import { FadIdentifiersInterface } from '../modals/interfaces/fad-facility-profile-details.interface';
import { FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import {
  FadSuggestAnEditDialogInputDataInterface,
  FadSuggestAnEditSubmitFeedbackMessageInterface,
  FadSuggestAnEditSubmitFeedbackRequestInterface
} from '../modals/interfaces/fad-suggest-an-edit-dialog.interface';
import { FadSuggestAnEditDialogService } from './fad-suggest-an-edit-dialog.service';
import { ConstantsService } from '@app/services/constants.service';
import { HashMapInterface } from '@app/interfaces/hash-map.interface';
import { HashMap } from '@app/models/hash-map.model';

@Component({
  selector: 'app-fad-suggest-an-edit-dialog',
  templateUrl: './fad-suggest-an-edit-dialog.component.html',
  styleUrls: ['./fad-suggest-an-edit-dialog.component.scss']
})
export class FadSuggestAnEditDialogComponent implements OnInit {
  // Data passed in by componentProps
  @Input() data: FadSuggestAnEditDialogInputDataInterface;

  public correctionType: string[];
  public suggestingEditFor: string;
  private providerIdentifier: FadIdentifiersInterface[];
  public selectedValues: string[] = [];
  private selectedValueMap: HashMapInterface<boolean> = new HashMap();

  constructor(
    private fadSuggestAnEditDialogService: FadSuggestAnEditDialogService,
    navParams: NavParams,
    public modalController: ModalController,
    private constants: ConstantsService
  ) {}

  ngOnInit() {
    try {
      this.selectedValues = [];
      const dialogInputData: FadSuggestAnEditDialogInputDataInterface = this.data;
      if (dialogInputData) {
        this.suggestingEditFor = dialogInputData.suggestingEditFor;
        const feedbackValues = dialogInputData.feedBackValues;
        this.providerIdentifier = dialogInputData.providerIdentifier;
        if (feedbackValues) {
          this.correctionType = feedbackValues.correctionType;
        }
      }

      let uiCleanUpCount = 0;
      const uiCleanUpFlag = window.setInterval(() => {
        uiCleanUpCount++;

        const chkBoxColl: HTMLCollectionOf<Element> = document.getElementsByTagName('ion-item');
        const chkBoxArr = Array.prototype.slice.call(chkBoxColl);
        chkBoxArr.map(chkBox => {
          const innerItems: HTMLCollectionOf<HTMLDivElement> = chkBox.shadowRoot.children[0].getElementsByClassName('item-inner');
          const innerItemsArr = Array.prototype.slice.call(innerItems);
          innerItemsArr.map(innerItem => {
            innerItem.style.border = '0px solid black';
          });
        });

        const modalWrapper: HTMLElement = document.getElementsByClassName('modal-wrapper')[0] as HTMLElement;
        modalWrapper.style.width = '90vw';
        modalWrapper.style.height = '90vh';

        if (uiCleanUpCount > 15) {
          window.clearInterval(uiCleanUpFlag);
        }
      }, 250);
    } catch (exception) {
      throw exception;
    }
  }

  cancel(): void {
    this.modalController.dismiss({
      dismissed: true
    });
  }

  submit(): void {
    //do submission and close
    this.selectedValues = [];
    const interactedValues = this.selectedValueMap.getKeys();
    if (interactedValues && interactedValues.length >= 0) {
      interactedValues.map(key => {
        if (this.selectedValueMap.get(key)) {
          this.selectedValues.push(key);
        }
      });
    }

    if (this.selectedValues && this.selectedValues.length > 0) {
      // submission api call here
      const fadSuggestAnEditSubmitFeedbackRequest: FadSuggestAnEditSubmitFeedbackRequestInterface = new FadSuggestAnEditSubmitFeedbackRequest();
      const message: FadSuggestAnEditSubmitFeedbackMessageInterface = new FadSuggestAnEditSubmitFeedbackMessage();
      message.issue = this.selectedValues;

      const searchCriteriaText = sessionStorage.getItem('FadLandingPageSearchCriteria');
      let searchCriteria: FadLandingPageSearchControlValuesInterface = new FadLandingPageSearchControlValues();
      if (searchCriteriaText) {
        searchCriteria = Object.assign(searchCriteria, JSON.parse(searchCriteriaText));
      }

      message.providerName = this.suggestingEditFor;
      message.providerNetwork = searchCriteria.getPlanName().getNetworkId() + ' - ' + searchCriteria.getPlanName().getSimpleText() + '';
      message.providerAddress = this.data.providerAddress;
      message.providerPhone = this.data.providerPhone;
      message.providerIdentifier = this.providerIdentifier.map(identifier => {
        return identifier.typeCode + ':' + identifier.value;
      });

      fadSuggestAnEditSubmitFeedbackRequest.emailMessage = message;
      fadSuggestAnEditSubmitFeedbackRequest.paramGroupName = this.constants.sendEmailConfig['fad_provider_issues'];

      this.fadSuggestAnEditDialogService.getFadSuggestAnEditSubmitFeedback(fadSuggestAnEditSubmitFeedbackRequest).subscribe(
        data => {
          this.modalController.dismiss({
            dismissed: true,
            response: data
          });
        },
        err => {
          this.modalController.dismiss({
            dismissed: true,
            error: err
          });
        }
      );
    } else {
      return;
    }
  }

  onSelectionChange(selectionEvent): void {
    const selectedValue = selectionEvent.srcElement.parentElement.getElementsByTagName('ion-label')[0].textContent.trim();
    //update selection in map
    this.selectedValueMap.put(selectedValue, selectionEvent.detail.checked);

    this.selectedValues = [];
    const interactedValues = this.selectedValueMap.getKeys();
    if (interactedValues && interactedValues.length >= 0) {
      interactedValues.map(key => {
        // if the check  box is selected then add the selected key to the selectedValues array
        if (this.selectedValueMap.get(key)) {
          this.selectedValues.push(key);
        }
      });
    }
  }
}
