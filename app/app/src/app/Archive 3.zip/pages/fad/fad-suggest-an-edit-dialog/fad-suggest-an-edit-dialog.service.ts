import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { FAD_CONSTANTS } from '../constants/fad.constants';
import { FadSuggestAnEditSubmitFeedbackRequestInterface } from '../modals/interfaces/fad-suggest-an-edit-dialog.interface';

@Injectable({ providedIn: 'root' })
export class FadSuggestAnEditDialogService {
  constructor(private http: HttpClient) {}

  getFadSuggestAnEditSubmitFeedback(
    fadSuggestAnEditSubmitFeedbackRequest: FadSuggestAnEditSubmitFeedbackRequestInterface
  ): Observable<any> {
    let params = new HttpParams();

    // tslint:disable-next-line:forin
    for (const key in fadSuggestAnEditSubmitFeedbackRequest) {
      params = params.append(key.toString(), fadSuggestAnEditSubmitFeedbackRequest[key]);
    }
    // this.authService.isFadAccessTokenRequired()
    return this.http.post(FAD_CONSTANTS.urls.fadSuggestAnEdit_submitFeedbackUrl, fadSuggestAnEditSubmitFeedbackRequest);
  }
}
