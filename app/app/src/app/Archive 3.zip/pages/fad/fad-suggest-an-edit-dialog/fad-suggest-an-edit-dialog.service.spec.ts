import { TestBed, inject } from '@angular/core/testing';

import { FadSuggestAnEditDialogService } from './fad-suggest-an-edit-dialog.service';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgxMaskModule } from 'ngx-mask';
import { NgxsModule } from '@ngxs/store';
import { IonContent } from '@ionic/angular';

xdescribe('FadSuggestAnEditDialogService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, NgxMaskModule.forRoot(), NgxsModule.forRoot([])],
      providers: [FadSuggestAnEditDialogService, IonContent]
    });
  });

  it('should be created', inject([FadSuggestAnEditDialogService], (service: FadSuggestAnEditDialogService) => {
    expect(service).toBeTruthy();
  }));
});
