import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { AlertService } from '@app/services/alert.service';
import { BehaviorSubject, Observable } from 'rxjs';
import { AlertType } from '../../components/alerts/alert-type.model';
import { FAD_CONSTANTS } from './constants/fad.constants';

@Injectable({ providedIn: 'root' })
export class FadService {
  public fadConstants = FAD_CONSTANTS;
  public searchDataSource = new BehaviorSubject<any>('');
  public isUserNotMemberInCHC = false;

  constructor(private alertService: AlertService, private router: Router, private http: HttpClient) {}

  public setServiceAlert(title, type = AlertType.Failure, scope = 'component'): void {
    const errorList = this.alertService.getAllError();
    if (JSON.stringify(errorList) === '{}' || errorList['component'] == null) {
      this.alertService.setAlert(title, '', type, scope);
    }
  }

  public clearServiceAlert(scope = 'component'): void {
    const errorList = this.alertService.getAllError();
    if (errorList?.hasOwnProperty(scope)) {
      this.resetServiceError();
    }
  }

  public resetServiceError(): void {
    this.alertService.resetErrorObject();
  }

  public reviewMyBenfits() {
    this.router.navigate([this.fadConstants.urls.reviewmybenfits]);
  }

  public requestWrittenEstimate() {
    this.router.navigate([this.fadConstants.urls.requestEstimateUrl]);
  }

  public post<T>(url, request): Observable<T> {
    if (this.isUserNotMemberInCHC) {
      request.useridin = '';
    }
    return this.http.post<T>(url, request);
  }

  public notAcceptingPatients(acceptingNewPatients) {
    return (acceptingNewPatients === 'E' || acceptingNewPatients === 'EX' || acceptingNewPatients === 'XE' || acceptingNewPatients === 'N');
  }

  public acceptingPatients(acceptingNewPatients) {
    return (acceptingNewPatients === 'O' || acceptingNewPatients === 'Y' || acceptingNewPatients === 'OX' || acceptingNewPatients === 'XO');
  }

  public acceptingPatientsPCP(acceptingNewPatients) {
    return (acceptingNewPatients === 'OE');
  }

  public acceptingPatientsSpecialist(acceptingNewPatients) {
    return (acceptingNewPatients === 'EO');
  }

  public acceptingFamilyPatients(acceptingNewPatients) {
    return (acceptingNewPatients === 'F');
  }
}
