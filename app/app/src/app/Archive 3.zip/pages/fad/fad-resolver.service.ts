import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { FadService } from '@app/pages/fad/fad.service';
import { GetTokens, SetLoader } from '@app/store/actions/app.actions';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Store } from '@ngxs/store';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { FAD_CONSTANTS } from './constants/fad.constants';
import { FadMembersInfoModel, FadMembersInfoRequestModel } from './modals/fad-landing-page.modal';
import { FadPlanSearchRequestModel } from './modals/fad-vitals-collection.model';
import { FadMembersInfoRequestModelInterface } from './modals/interfaces/fad-landing-page.interface';
import { FadPlanSearchRequestModelInterface } from './modals/interfaces/fad-vitals-collection.interface';
import { GetSearchByProcedureRequestModelInterface } from './modals/interfaces/search-procedure.interface';
import { GetSearchByProcedureRequestModel } from './modals/search-procedure.model';
@Injectable({ providedIn: 'root' })
export class FadResolverService implements Resolve<Observable<any>> {
  @SelectSnapshot(AppSelectors.getFADHCCSFlag) hccsFlag: string;
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  public dependantsList: FadMembersInfoModel[] = [];

  constructor(private http: HttpClient, private store: Store, private fadService: FadService) {}

  async resolve(): Promise<any> {
    const isAuthenticatedUser = this.scopeName.includes('AUTHENTICATED');

    if (isAuthenticatedUser) {
      this.store.dispatch(new SetLoader(true));
      await this.getVitalsDependantList()
        .toPromise()
        .then((response: any) => {
          if (response && response.result && response.result < 0) {
            //Suppress -92829 error because its a valid error from CHC
            if (response.result !== -92829) {
              sessionStorage.setItem('memberdisplayerrormessage', response['displaymessage']);
            }

            return this.getVitalsPlanInfo(true).toPromise();
          } else if (response && response.membersInfoList && response.membersInfoList.length > 0) {
            this.dependantsList = response.membersInfoList;

            if (!sessionStorage.getItem('fadVendorMemberNumber')) {
              sessionStorage.setItem('fadVendorMemberNumber', this.dependantsList[0].fadVendorMemberNumber);
            }
            sessionStorage.setItem('dependantsList', JSON.stringify(this.dependantsList));
          }
        });
      await this.getProcedureSummary().toPromise();

      return await this.getVitalsPlanInfo(true)
        .toPromise()
        .then(response => {
          sessionStorage.setItem('fadInfo', JSON.stringify(response));
        })
        .finally(() => this.store.dispatch(new SetLoader(false)));
    } else {
      const request = {
        useridin: '',
        passwordin: ''
      };
      await this.store
        .dispatch(new GetTokens(request, false, true))
        .toPromise()
        .then(response => {
          return this.getVitalsPlanInfo(true)
            .toPromise()
            .then(response => {
              sessionStorage.setItem('fadInfo', JSON.stringify(response));
            })
            .finally(() => this.store.dispatch(new SetLoader(false)));
        })
        .finally(() => this.store.dispatch(new SetLoader(false)));
    }
  }

  public getVitalsPlanInfo(isResolverCall?: boolean): Observable<any> {
    const request: FadPlanSearchRequestModelInterface = new FadPlanSearchRequestModel();
    request.useridin = this.useridin && this.useridin !== 'undefined' ? this.useridin : '';
    const customAccountName = sessionStorage.getItem('customAccountName');
    if (customAccountName) {
      request.accountName = customAccountName;
    }
    const url = FAD_CONSTANTS.urls.fadLandingPagePlansAutocompleteListUrl;
    return this.http.post(url, request);
  }

  getVitalsDependantList(): Observable<any> {
    const request: FadMembersInfoRequestModelInterface = new FadMembersInfoRequestModel();
    request.useridin = this.useridin;
    if (this.hccsFlag !== null) {
      request['hccsFlag'] = this.hccsFlag;
    }

    const url = FAD_CONSTANTS.urls.fadLandingPageDependentsListUrl;
    return this.http.post(url, request).pipe(
      map(response => {
        if (response['result'] === -92829) {
          sessionStorage.setItem('isUserNotMemberInCHC', 'true');
          this.fadService.isUserNotMemberInCHC = true;
        }
        return response;
      })
    );
  }

  getProcedureSummary() {
    const procedureSearchReq: GetSearchByProcedureRequestModelInterface = new GetSearchByProcedureRequestModel();
    procedureSearchReq.setUserId(this.useridin).setLocale(FAD_CONSTANTS.defaults.locale + '');
    if (this.hccsFlag !== null) {
      procedureSearchReq['hccsFlag'] = this.hccsFlag;
    }
    if (sessionStorage.getItem('fadVendorMemberNumber')) {
      procedureSearchReq['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
    }
    const url = FAD_CONSTANTS.urls.fadVitalsProcedureUrl;
    return this.fadService.post(url, procedureSearchReq);
  }
}
