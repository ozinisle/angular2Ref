import {
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { FadFacilitySearchFilterComponentOutputModel, FilterRadioItem } from '../modals/fad-search-filter.modal';
import {
  FadFacilitySearchFilterComponentOutputModelInterface,
  FilterCheckboxItemInterface,
  FilterListItemInterface
} from '../modals/interfaces/fad-search-filter.interface';
import {
  FacetsFacilityListInterface,
  FacilityFiltersMetadataInterface,
  GetSearchByFacilityResponseModelInterface
} from '../modals/interfaces/search-facility.interface';
import { SortMetadataInterface } from '../modals/interfaces/search-professional.interface';

import { MatSidenav } from '@angular/material/sidenav';
import { NavParams, PopoverController } from '@ionic/angular';
import { FAD_CONSTANTS } from '../constants/fad.constants';
import { FadFacilityListService } from '../fad-facility-list/fad-facility-list.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FacilityFiltersMetadataModel } from '../modals/search-facility.model';
import { SortMetadata } from '../modals/search-professional.model';
import { FadFacilityListComponentInputModelInterface } from '../modals/interfaces/fad-search-list.interface';
import { FadResouceTypeCodeConfig } from '../modals/types/fad.types';

@Component({
  selector: 'app-facility-search-filter',
  templateUrl: './fad-facility-search-filter.component.html',
  styleUrls: ['./fad-facility-search-filter.component.scss']
})
export class FadFacilitySearchFilterComponent implements OnInit, OnChanges, OnDestroy {
  @Output() componentOutput = new EventEmitter<FadFacilitySearchFilterComponentOutputModelInterface>();
  @ViewChild('sideNavContainer') elementView: ElementRef;
  @ViewChild('filterWidth') filterElementView: ElementRef;
  @ViewChild('searchInput') searchInput;
  @ViewChild('sidenav') sideNav: MatSidenav;

  // being used both the html view and the component(this file)
  public isDisplayFilter = false;
  public fadConstants;
  public outputTransaction: FadFacilitySearchFilterComponentOutputModelInterface = new FadFacilitySearchFilterComponentOutputModel();

  // flag values used bound to the view alone (html tags)
  public collapsedSortHeight: string;
  public expandedSortHeight: string;
  public sortSelectedFilter: string;
  public collapsedHeight: string;
  public expandedHeight: string;

  @Input() componentFilterInput: FadFacilityListComponentInputModelInterface;
  public searchResponse: GetSearchByFacilityResponseModelInterface;
  public facetsList: FacetsFacilityListInterface;
  public locationGeoList: FilterListItemInterface[] = [];
  public ratingList: FilterListItemInterface[] = [];
  public specialtyList: FilterListItemInterface[] = [];
  public bdcTypeList: FilterListItemInterface[] = [];
  public awardTypeList: FilterListItemInterface[] = [];
  public cqmsTypeList: FilterListItemInterface[] = [];
  public inNetworkOnlyCheckbox: FilterCheckboxItemInterface;
  public tiersList: FilterListItemInterface[] = [];

  public enableClearfilterFlag = false;
  public filterMetaData: FacilityFiltersMetadataInterface = new FacilityFiltersMetadataModel();
  public sortMetaData: SortMetadataInterface = new SortMetadata();
  public clearFilterFlagSubjectSubscription: Subscription;
  public showClearLink = false;

  public sortCurrentValue: string;
  public isSortExpanded: boolean;
  public radioValueSort: string;
  public radioValueDistance: string;
  public radioValueGender: string;
  public radioValueLanguages: string;
  public radioValueRatings: string;
  public radioValueAges: string;
  public radioValuespecialtyList: string;
  public radioValuedisordersTreated: string;
  public radioValuetreatmentMethods: string;
  public radioValuegroupAffiliation: string;
  public radioValuegrouptiers: string;
  public radioValueawardTypeCodes: string;
  public radioValuebcdTypeCodes: string;
  public radioValuehospitalAffiliation: string;
  public radioValueProviders: string;
  public radioValueClinicalQuality: string;
  submenu: any = {};
  public sortList: FilterRadioItem[] = [
    {
      name: 'Distance',
      value: 'distance+asc',
      checked: true
    },
    {
      name: 'Name A-Z',
      value: 'provider_name_sortable+asc',
      checked: false
    },
    {
      name: 'Name Z-A',
      value: 'provider_name_sortable+desc',
      checked: false
    },
    {
      name: 'Best Match',
      value: 'relevancy+desc',
      checked: false
    },
    {
      name: 'Quality',
      value: 'clinical_quality+desc',
      checked: false
    },
    {
      name: 'Ratings',
      value: 'prs_overall_rating+desc,+prs_experience_of_care+desc',
      checked: false
    }
  ];
  locationGeoListduplicate: FilterListItemInterface[];

  constructor(
    private fadSearchResultsService: FadSearchResultsService,
    private fadSearchListService: FadFacilityListService,
    private cdRef: ChangeDetectorRef,
    private popoverContrioller: PopoverController,
    private navParams: NavParams
  ) {
    this.fadConstants = FAD_CONSTANTS;
    this.collapsedHeight = '32px';
    this.collapsedSortHeight = '56px';
    this.expandedHeight = '40px';
    this.expandedSortHeight = '48px';
    this.isSortExpanded = false;
    this.sortSelectedFilter = 'Distance';
  }

  ngOnInit() {
    this.clearFilterFlagSubjectSubscription = this.fadSearchResultsService.clearFilterFlagSubject$.subscribe(message => {
      if (message && message.clearFlag === true && message.type === FadResouceTypeCodeConfig.facility) {
        this.clearFilter();
      }
    });

    this.initialData(this.navParams.data);
  }
  initialData(data) {
    if (data) {
      this.searchResponse = data.facilityListComponentInput.facilityResults;

      if (this.searchResponse && this.searchResponse.facets) {
        this.facetsList = this.searchResponse.facets;
        this.manageFilter(this.facetsList);
      }

      if (this.searchResponse && this.searchResponse.sort) {
        this.radioValueSort = this.sortCurrentValue;
        this.sortCurrentValue = this.searchResponse.sort;
        this.manageSorting();
      }
    }

    this.filterMetaData = Object.assign(this.filterMetaData, data.filterMetaData ? data.filterMetaData : {});
    setTimeout(() => {
      this.showClearLink = data.isFilterChanged;
      this.cdRef.detectChanges();
    }, 0);
  }

  ngOnChanges(changes: SimpleChanges) {
    try {
      this.componentFilterInput = changes.componentFilterInput.currentValue;

      if (this.componentFilterInput) {
        this.searchResponse = this.componentFilterInput.facilityResults;
        if (this.searchResponse && this.searchResponse.facets) {
          this.facetsList = this.searchResponse.facets;
          this.manageFilter(this.facetsList);
        }

        if (this.searchResponse && this.searchResponse.sort) {
          this.sortCurrentValue = this.searchResponse.sort;
          this.manageSorting();
        }
        this.cdRef.detectChanges();
      }
    } catch (exception) {}
  }

  ngOnDestroy(): void {
    this.clearFilterFlagSubjectSubscription.unsubscribe();
  }

  public manageSorting() {
    this.sortList = this.sortList.map(sortObj => {
      if (this.sortCurrentValue && sortObj.value === this.sortCurrentValue) {
        sortObj.checked = true;
        this.sortSelectedFilter = sortObj.name;
      } else {
        sortObj.checked = false;
      }
      return sortObj;
    });
  }

  public manageFilter(facetsList: FacetsFacilityListInterface) {
    this.locationGeoList = facetsList.locationGeo ? [...facetsList.locationGeo] : [];
    this.ratingList = facetsList.overallRating ? facetsList.overallRating : [];
    this.specialtyList = facetsList.fieldSpecialtyIds ? facetsList.fieldSpecialtyIds : [];
    this.bdcTypeList = facetsList.bdcTypeCodes ? facetsList.bdcTypeCodes : [];
    this.awardTypeList = facetsList.awardTypeCodes ? facetsList.awardTypeCodes : [];
    this.cqmsTypeList = facetsList.cqms ? facetsList.cqms : [];
    this.inNetworkOnlyCheckbox = facetsList.inNetwork ? facetsList.inNetwork : null;
    this.tiersList = facetsList.tiers ? facetsList.tiers : [];
    let itemslected = false;
    let firstelement = false;
    this.locationGeoListduplicate = this.locationGeoList.map(item => {
      if (item.selected) {
        itemslected = true;
        firstelement = true;
        this.radioValueDistance = item.value;
      } else {
        firstelement = false;
      }
      return {
        ...item,
        count: itemslected && !firstelement ? 'N' : item.count
      };
    });

    this.locationGeoList = this.locationGeoListduplicate;
    this.ratingList = this.ratingList.map(item => {
      if (item.selected) {
        itemslected = true;
        firstelement = true;
        this.radioValueRatings = item.value;
      } else {
        firstelement = false;
      }
      return {
        ...item
      };
    });

    this.specialtyList = this.specialtyList.map(item => {
      if (item.selected) {
        itemslected = true;
        firstelement = true;
        this.radioValuespecialtyList = item.value;
      } else {
        firstelement = false;
      }
      return {
        ...item
      };
    });
    this.tiersList = this.tiersList.map(item => {
      if (item.selected) {
        itemslected = true;
        firstelement = true;
        this.radioValuegrouptiers = item.value;
      } else {
        firstelement = false;
      }
      return {
        ...item
      };
    });
    this.awardTypeList = this.awardTypeList.map(item => {
      if (item.selected) {
        itemslected = true;
        firstelement = true;
        this.radioValueawardTypeCodes = item.value;
      } else {
        firstelement = false;
      }
      return {
        ...item
      };
    });
    this.bdcTypeList = this.bdcTypeList.map(item => {
      if (item.selected) {
        itemslected = true;
        firstelement = true;
        this.radioValuebcdTypeCodes = item.value;
      } else {
        firstelement = false;
      }
      return {
        ...item
      };
    });
    this.cqmsTypeList = this.cqmsTypeList.map(item => {
      if (item.selected) {
        itemslected = true;
        firstelement = true;
        this.radioValueClinicalQuality = item.value;
      } else {
        firstelement = false;
      }
      return {
        ...item
      };
    });
  }

  public isSortOpened() {
    this.isSortExpanded = true;
  }

  public isSortClosed() {
    this.isSortExpanded = false;
  }

  /**
   * @description helps hide the sections other than the filter section and vice versa when the "Filter" dropdown is clicked in
   *  mobile screen only. Does not have any effect on the desktop screens
   */
  public toggleFilter() {
    this.isDisplayFilter = !this.isDisplayFilter;
    this.outputTransaction.filterOverlayFlag = this.isDisplayFilter;
    this.outputTransaction.filterCriteriaData = null;
    this.outputTransaction.sortCriteriaData = null;
    this.componentOutput.emit(this.outputTransaction);
  }
  toggleSubmenu(menu: string) {
    if (!this.submenu[menu]) {
      this.submenu[menu] = false;
    }
    this.submenu[menu] = !this.submenu[menu];
  }
  public applySortFilter() {
    this.outputTransaction.filterCriteriaData = this.filterMetaData;
    this.outputTransaction.sortCriteriaData = this.sortMetaData;
    this.isDisplayFilter = false;
    this.outputTransaction.filterOverlayFlag = this.isDisplayFilter;
    this.enableClearfilterFlag = true;
    this.fadSearchListService.isFilterChanged(true);
    this.popoverContrioller.dismiss(this.outputTransaction);
    this.componentOutput.emit(this.outputTransaction);
  }

  public clearFilter() {
    this.showClearLink = false;
    this.isSortExpanded = false;
    this.isDisplayFilter = false;
    this.enableClearfilterFlag = false;
    this.outputTransaction.filterOverlayFlag = this.isDisplayFilter;

    this.filterMetaData = new FacilityFiltersMetadataModel();
    this.sortMetaData = new SortMetadata();
    this.outputTransaction.filterCriteriaData = this.filterMetaData;
    this.outputTransaction.sortCriteriaData = this.sortMetaData;
    this.fadSearchListService.isFilterChanged(true);
    this.popoverContrioller.dismiss(this.outputTransaction);
    this.componentOutput.emit(this.outputTransaction);
  }

  /*
     To get the selected sorted criteria from the view/template while changing the options
  */
  public onSortItemChanged(selectedSortObject): void {
    const selectValue = selectedSortObject.target.value;
    this.radioValueSort = selectValue;
    this.sortList = this.sortList.map(sortObj => {
      if (selectValue && sortObj.value === selectValue) {
        sortObj.checked = true;
        this.sortSelectedFilter = sortObj.name;
      } else {
        sortObj.checked = false;
      }
      return sortObj;
    });
    this.sortMetaData = selectedSortObject.target.value;
    this.applySortFilter();
  }

  /*
     To get the selected filter criteria from the view/template while changing the options
  */
  public manageSelectedProfessionalFilter(filtertype, value) {
    const selectValue = value;
    window.scroll(0, 0);
    switch (filtertype) {
      case 'filterLocation':
        this.filterMetaData.filterLocation = selectValue;
        break;
      case 'filterRating':
        this.filterMetaData.filterRating = selectValue;
        break;
      case 'filterSpecialities':
        this.filterMetaData.filterSpecialities = selectValue;
        break;
      case 'filterBDC':
        this.filterMetaData.filterBDC = selectValue;
        break;
      case 'filterAward':
        this.filterMetaData.filterAward = selectValue;
        break;
      case 'filterCQMS':
        this.filterMetaData.filterCQMS = selectValue;
        break;
      case 'filterTiers':
        this.filterMetaData.filterTiers = selectValue;
        break;
    }
    setTimeout(() => {
      this.showClearLink = true;
      this.cdRef.detectChanges();
    }, 0);
    this.applySortFilter();
  }
  public manageSelectedProfessionalFilterTreatementMethod(selectionListRadioBoxChange) {
    const selectValue = selectionListRadioBoxChange.detail.value;
    this.radioValuetreatmentMethods = selectValue;
    this.manageSelectedProfessionalFilter('filterTreatment', selectValue);
  }
  public manageSelectedProfessionalFilterTiers(selectionListRadioBoxChange) {
    const selectValue = selectionListRadioBoxChange.detail.value;
    this.radioValuegrouptiers = selectValue;
    this.manageSelectedProfessionalFilter('filterTiers', selectValue);
  }
  public manageSelectedProfessionalFilterAwards(selectionListRadioBoxChange) {
    const selectValue = selectionListRadioBoxChange.detail.value;
    this.radioValueawardTypeCodes = selectValue;
    this.manageSelectedProfessionalFilter('filterAward', selectValue);
  }
  public manageSelectedProfessionalFilterbcdTypeCodes(selectionListRadioBoxChange) {
    const selectValue = selectionListRadioBoxChange.detail.value;
    this.radioValuebcdTypeCodes = selectValue;
    this.manageSelectedProfessionalFilter('filterBDC', selectValue);
  }
  public manageSelectedProfessionalFilterHospitalAffiliation(selectionListRadioBoxChange) {
    const selectValue = selectionListRadioBoxChange.detail.value;
    this.radioValuehospitalAffiliation = selectValue;
    this.manageSelectedProfessionalFilter('filterHospitalAffilation', selectValue);
  }
  public manageSelectedProfessionalFilterGroupAffiliation(selectionListRadioBoxChange) {
    const selectValue = selectionListRadioBoxChange.detail.value;
    this.radioValuegroupAffiliation = selectValue;
    this.manageSelectedProfessionalFilter('filterGroupAffilation', selectValue);
  }
  public manageSelectedProfessionalFilterAges(selectionListRadioBoxChange) {
    const selectValue = selectionListRadioBoxChange.detail.value;
    this.radioValueAges = selectValue;
    this.manageSelectedProfessionalFilter('filterAges', selectValue);
  }
  public manageSelectedProfessionalFilterDisorder(selectionListRadioBoxChange) {
    const selectValue = selectionListRadioBoxChange.detail.value;
    this.radioValuedisordersTreated = selectValue;
    this.manageSelectedProfessionalFilter('filterDisorders', selectValue);
  }
  public manageSelectedProfessionalFilterSpecialities(selectionListRadioBoxChange) {
    const selectValue = selectionListRadioBoxChange.detail.value;
    this.radioValuespecialtyList = selectValue;
    this.manageSelectedProfessionalFilter('filterSpecialities', selectValue);
  }
  public manageSelectedProfessionalFilterLanguages(selectionListRadioBoxChange) {
    const selectValue = selectionListRadioBoxChange.detail.value;
    this.radioValueLanguages = selectValue;
    this.manageSelectedProfessionalFilter('filterLanguage', selectValue);
  }
  public manageSelectedProfessionalFilterRating(selectionListRadioBoxChange) {
    const selectValue = selectionListRadioBoxChange.detail.value;
    this.radioValueRatings = selectValue;
    this.filterMetaData.filterRating = selectValue;
    this.manageSelectedProfessionalFilter('filterRating', selectValue);
  }
  public manageSelectedProfessionalFilterLocation(selectionListRadioBoxChange) {
    const selectValue = selectionListRadioBoxChange.detail.value;
    this.radioValueDistance = selectValue;
    this.manageSelectedProfessionalFilter('filterLocation', selectValue);
  }
  public manageSelectedProfessionalFilterGender(selectionListRadioBoxChange) {
    const selectValue = selectionListRadioBoxChange.detail.value;
    this.radioValueGender = selectValue;
    this.manageSelectedProfessionalFilter('filterGender', selectValue);
  }
  public manageSelectedProfessionalFilterClinicalQuality(selectionListRadioBoxChange) {
    const selectValue = selectionListRadioBoxChange.detail.value;
    this.radioValueClinicalQuality = selectValue;
    this.manageSelectedProfessionalFilter('filterCQMS', selectValue);
  }
  public manageSelectedProfessionalFilterProviders(selectionListRadioBoxChange) {
    const selectValue = selectionListRadioBoxChange.detail.value;
    this.radioValueProviders = selectValue;
    this.manageSelectedProfessionalFilter('filterProviderType', selectValue);
  }

  /*
      To get the selected filter criteria from the view/template while changing the options
   */
  public manageCheckboxFacilityFilter(selectionChBoxChange) {
    const selectValue = selectionChBoxChange.detail.checked ? selectionChBoxChange.source.value : null;
    switch (selectionChBoxChange.source.name) {
      case 'filterInNetwork':
        this.filterMetaData.filterInNetwork = selectValue;
        break;
    }
    setTimeout(() => {
      this.showClearLink = true;
      this.cdRef.detectChanges();
    }, 0);
    this.applySortFilter();
  }

  /**
   * @description checks whether filters have key data
   */
  public expandAccordion(property): boolean {
    if (this.filterMetaData && this.filterMetaData.hasOwnProperty(property)) {
      return true;
    }

    return false;
  }
}
