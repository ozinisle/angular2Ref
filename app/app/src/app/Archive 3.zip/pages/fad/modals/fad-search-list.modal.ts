import {
  FadFacilityListComponentInputModelInterface,
  FadSearchListComponentInputModelInterface,
  FadSpecialtyListComponentInputModelInterface
} from './interfaces/fad-search-list.interface';
import { FadFacilityInterface, GetSearchByFacilityResponseModelInterface } from './interfaces/search-facility.interface';
import { GetSearchByProfessionalResponseModelInterface } from './interfaces/search-professional.interface';
import { GetSearchBySpecialtyResponseModelInterface } from './interfaces/search-speciality.interface';

export class FadSearchListComponentInputModel implements FadSearchListComponentInputModelInterface {
  public searchResults: GetSearchByProfessionalResponseModelInterface;
}

export class FadSearchListComponentOutputModel {
  selectedProfessionals: FadFacilityInterface[];
}

export class FadFacilityListComponentInputModel implements FadFacilityListComponentInputModelInterface {
  public facilityResults: GetSearchByFacilityResponseModelInterface;
}

export class FadSpecialtyListComponentInputModel implements FadSpecialtyListComponentInputModelInterface {
  public specialtyResults: GetSearchBySpecialtyResponseModelInterface;
}
