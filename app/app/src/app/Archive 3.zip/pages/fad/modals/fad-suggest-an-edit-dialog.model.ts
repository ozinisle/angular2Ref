import { FadIdentifiersInterface } from './interfaces/fad-facility-profile-details.interface';
import {
  FadSuggestAnEditDialogCorrectionTypeInterface,
  FadSuggestAnEditDialogInputDataInterface,
  FadSuggestAnEditSubmitFeedbackMessageInterface,
  FadSuggestAnEditSubmitFeedbackRequestInterface
} from './interfaces/fad-suggest-an-edit-dialog.interface';


export class FadSuggestAnEditDialogCorrectionType implements FadSuggestAnEditDialogCorrectionTypeInterface {
  correctionType: string[];
}

export class FadSuggestAnEditDialogInputData implements FadSuggestAnEditDialogInputDataInterface {
  suggestingEditFor: string;
  feedBackValues: FadSuggestAnEditDialogCorrectionType;
  providerIdentifier: FadIdentifiersInterface[];
  providerAddress: string;
  providerPhone: string;
}

export class FadSuggestAnEditSubmitFeedbackRequest implements FadSuggestAnEditSubmitFeedbackRequestInterface {
  fromAddress?: string;
  toAddress?: string;
  subject?: string;
  emailMessage: FadSuggestAnEditSubmitFeedbackMessage;
  paramGroupName: string;
}

export class FadSuggestAnEditSubmitFeedbackMessage implements FadSuggestAnEditSubmitFeedbackMessageInterface {
  providerName: string;
  providerIdentifier: string[];
  providerNetwork: string;
  issue: string[];
  providerAddress: string;
  providerPhone: string;
}
