import {
  DoctorProfileSearchRequestModelInterface,
  FadPlanSearchRequestModelInterface,
  FadVitalsNetworkInterface,
  FadVitalsZipCodeSearchRequestModelInterface,
} from './interfaces/fad-vitals-collection.interface';


export class FadVitalsNetwork implements FadVitalsNetworkInterface {
  private network: FPSRPlan;
  getNetwork(): FPSRPlan {
    return this.network;
  }
  setNetwork(network: FPSRPlan): FadVitalsNetwork {
    this.network = network;
    return this;
  }
}
export class FZCSRCity {
  public name = '';
  public city = '';
  public county = '';
  public state = '';
  // tslint:disable-next-line:variable-name
  public state_code = '';
  public score = 0;
  public zip = '';
  public geo = '';
  public lat = '';
  public lng = '';
  // tslint:disable-next-line:variable-name
  public place_id = '';

  getDisplayValue(): string {
    let zipCodeText = `${this.getZip()} - ${this.getCity()}, ${this.getState_code()}`;
    if (zipCodeText === ' - , ') {
      zipCodeText = zipCodeText.replace(/[-,]/g, '').trim();
    }
    return zipCodeText;
  }

  public getName(): string {
    return this.name;
  }

  public setName(name: string): FZCSRCity {
    this.name = name;
    return this;
  }
  public getCity(): string {
    return this.city;
  }

  public setCity(city: string): FZCSRCity {
    this.city = city;
    return this;
  }

  public setCounty(county: string): FZCSRCity {
    this.county = county;
    return this;
  }
  public setState(state: string): FZCSRCity {
    this.state = state;
    return this;
  }
  public getState_code(): string {
    return this.state_code;
  }

  public setState_code(stateCode: string): FZCSRCity {
    this.state_code = stateCode;
    return this;
  }

  public setScore(score: number): FZCSRCity {
    this.score = score;
    return this;
  }
  public getZip(): string {
    return this.zip;
  }

  public setZip(zip: string): FZCSRCity {
    this.zip = zip;
    return this;
  }
  public getGeo(): string {
    return this.geo;
  }

  public setGeo(geo: string): FZCSRCity {
    this.geo = geo;
    return this;
  }

  public setLat(lat: string): FZCSRCity {
    this.lat = lat;
    return this;
  }

  public setLng(lng: string): FZCSRCity {
    this.lng = lng;
    return this;
  }

  public setPlace_id(placeId: string): FZCSRCity {
    this.place_id = placeId;
    return this;
  }
}

export class FPSRPlan {
  public id: number;
  public name: string;
  public planIndicator: boolean;

  getId(): number {
    return this.id;
  }

  getName(): string {
    return this.name;
  }

  setName(name: string): FPSRPlan {
    this.name = name;
    return this;
  }

  getPlanIndicator(): boolean {
    return this.planIndicator;
  }

}

export class FadVitalsZipCodeSearchRequestModel implements FadVitalsZipCodeSearchRequestModelInterface {
  public place: string;
  public page: number;
  public limit: number;
}

export class DoctorProfileSearchRequestModel implements DoctorProfileSearchRequestModelInterface {
  public professionalid: string;
  public geolocation: string; // "lattitude,longitude"
  public networkId: string;
  public userid: string;
  public locationId: string;
}

export class FadPlanSearchRequestModel implements FadPlanSearchRequestModelInterface {
  public useridin: string;
  public accountName: string;
}
