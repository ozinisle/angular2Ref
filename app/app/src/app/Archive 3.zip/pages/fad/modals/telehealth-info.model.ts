import { GeneralError } from '@app/models/generic-app.model';
import { GetTelehealthInfoRequestModelInterface, GetTelehealthInfoResponseModelInterface, PlatformProvider } from './interfaces/telehealth-info.interface';

export class GetTelehealthInfoRequestModel implements GetTelehealthInfoRequestModelInterface {
  useridin: string;

  getUserId(): string {
    return this.useridin;
  }
  setUserId(useridin: string): GetTelehealthInfoRequestModel {
    this.useridin = useridin;
    return this;
  }
}

export class GetTelehealthInfoResponseModel extends GeneralError implements GetTelehealthInfoResponseModelInterface {
  teleHealthEligible: boolean;
  platformProvider: PlatformProvider;
}
