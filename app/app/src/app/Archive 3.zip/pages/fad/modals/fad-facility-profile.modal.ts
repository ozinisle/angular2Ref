import { LinkInterface } from './interfaces/fad-facility-profile.interface';

export class Link implements LinkInterface {
  name: string;
  url: string;
}
