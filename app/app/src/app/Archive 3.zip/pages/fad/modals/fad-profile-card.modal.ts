import {
  FadFacilityCardComponentInputModelInterface,
  FadFacilityCardComponentOutputModelInterface,
  FadProfileCardComponentInputModelInterface,
  FadProfileCardComponentOutputModelInterface,
  FadProviderCardComponentInputModelInterface,
  FadProviderCardComponentOutputModelInterface
} from './interfaces/fad-profile-card.interface';

import { FadFacilityInterface } from './interfaces/search-facility.interface';
import { FadProfessionalInterface } from './interfaces/search-professional.interface';
import { FadSpecialtyInterface } from './interfaces/search-speciality.interface';
import { FadProfileCardComponentMode } from './types/fad.types';

export class FadProfileCardComponentOutputModel implements FadProfileCardComponentOutputModelInterface {
  public professional: FadProfessionalInterface;
  public isSelected: boolean;
}

export class FadProfileCardComponentInputModel implements FadProfileCardComponentInputModelInterface {
  public mode: FadProfileCardComponentMode = 'ListItem';

  constructor(public professional: FadProfessionalInterface) {}
}

export class FadFacilityCardComponentOutputModel implements FadFacilityCardComponentOutputModelInterface {
  public facility: FadFacilityInterface;
  public isSelected: boolean;
}

export class FadFacilityCardComponentInputModel implements FadFacilityCardComponentInputModelInterface {
  public mode: FadProfileCardComponentMode = 'ListItem';

  constructor(public facility: FadFacilityInterface) {}
}

export class FadProviderProfileCardComponentOutputModel implements FadProviderCardComponentOutputModelInterface {
  public provider: FadSpecialtyInterface;
  public isSelected: boolean;
}

export class FadProviderProfileCardComponentInputModel implements FadProviderCardComponentInputModelInterface {
  public mode: FadProfileCardComponentMode = 'ListItem';

  constructor(public provider: FadSpecialtyInterface) {}
}
