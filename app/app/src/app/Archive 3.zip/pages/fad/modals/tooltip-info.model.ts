import { GetToolTipInfoRequestModelInterface } from './interfaces/tootip-info.interface';

export class GetToolTipInfoRequestModel implements GetToolTipInfoRequestModelInterface {
  useridin: string;
  locale: string;

  getUserId(): string {
    return this.useridin;
  }
  setUserId(useridin: string): GetToolTipInfoRequestModel {
    this.useridin = useridin;
    return this;
  }
}
