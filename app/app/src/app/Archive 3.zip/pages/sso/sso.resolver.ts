import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Router } from '@angular/router';
import { MYBLUE } from '@app/app.constants';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { AlertService } from '@app/services/alert.service';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { map } from 'rxjs/operators';
import { SsoService } from './sso.service';

@Injectable({ providedIn: 'root' })
export class SsoResolver {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;

  constructor(private ssoService: SsoService, private router: Router, private alertService: AlertService) {}

  resolve(routeInfo: ActivatedRouteSnapshot) {
    let ssoUrl;
    if (this.authToken && this.authToken.scopename === 'AUTHENTICATED-AND-VERIFIED') {
      ssoUrl = routeInfo && routeInfo.routeConfig && routeInfo.routeConfig.path ? routeInfo.routeConfig.path : '';
      ssoUrl = routeInfo && routeInfo.routeConfig && routeInfo.routeConfig.path === 'fad' ? 'sso/vitals' : routeInfo.routeConfig.path;
    }

    return ssoUrl
      ? this.ssoService.getSsoDetails(ssoUrl).pipe(
          map(response => {
            MYBLUE.warn(response);
            if (response && response.error) {
              this.router.navigate(['home']);
            } else {
              if (response.result < 0) {
                this.router.navigate([this.router.url]).then(() => {
                  this.alertService.setAlert(response.displaymessage, '', AlertType.Failure);
                });
              } else {
                return response;
              }
            }
          })
        )
      : null;
  }
}
