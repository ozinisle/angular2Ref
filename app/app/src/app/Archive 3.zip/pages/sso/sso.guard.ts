import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';
import { Router } from '@angular/router';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable } from 'rxjs';
import { AppSelectors } from '../../store/selectors/app.selectors';

@Injectable({ providedIn: 'root' })
export class SsoGuard implements CanActivate {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;

  constructor(private router: Router) {}

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    if (!this.isUserAuthenticated(state)) {
      return false;
    }
    let navigatedUrl = '';
    const isUserNotAuthenticatedAndVerified = this.isUserNotAuthenticatedAndVerified();
    switch (next.parent.routeConfig.path) {
      case 'fad':
        if (isUserNotAuthenticatedAndVerified) {
          navigatedUrl = 'https://myblue.bluecrossma.com/health-plan/find-doctor-provider-dentist';
          break;
        } else {
          return true;
        }
      case 'sso/alegeus':
        navigatedUrl = '/home'; // need to know if not authenticated to which we have to navigate
        break;
    }
    if (isUserNotAuthenticatedAndVerified && navigatedUrl) {
      if (navigatedUrl) {
        window.open(navigatedUrl, '_self');
      }
      return false;
    }
    return true;
  }

  isUserNotAuthenticatedAndVerified() {
    const authTokenDetails = this.authToken;
    if (authTokenDetails && authTokenDetails !== 'undefined') {
      const authTokenDetailsJson = this.authToken;
      if (authTokenDetailsJson && authTokenDetailsJson.scopename !== 'AUTHENTICATED-AND-VERIFIED') {
        return true;
      }
    } else {
      this.router.navigate(['/login']);
    }
    return false;
  }

  isUserAuthenticated(state) {
    const authTokenDetails = this.authToken;
    if (!authTokenDetails || authTokenDetails === 'undefined' || authTokenDetails === 'null') {
      sessionStorage.clear();
      localStorage.setItem('targetRoute', state.url);
      this.router.navigate(['login']);
      return false;
    }
    return true;
  }
}
