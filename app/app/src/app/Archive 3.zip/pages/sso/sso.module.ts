import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatListModule } from '@angular/material/list';
import { SsoGuard } from './sso.guard';
import { SsoResolver } from './sso.resolver';
import { SSO_ROUTER } from './sso.routing';
import { SsoService } from './sso.service';
import { SsoComponent } from './sso/sso.component';

@NgModule({
  declarations: [SsoComponent],
  imports: [
    CommonModule,
    SSO_ROUTER,
    FormsModule,
    ReactiveFormsModule,
    MatExpansionModule,
    MatListModule,
    MatDatepickerModule,
    MatNativeDateModule
  ],
  providers: [SsoService, SsoResolver, SsoGuard]
})
export class SsoModule {}
