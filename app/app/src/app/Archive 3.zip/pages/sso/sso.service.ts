import { HttpClient } from '@angular/common/http';
import { Injectable, OnDestroy } from '@angular/core';
import { MYBLUE } from '@app/app.constants';
import { ConstantsService } from '@app/services/constants.service';
import { IabService } from '@app/services/iab.service';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { environment } from '@environments/environment';
import { ModalController } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { from, Observable, Subject } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';
import { JumpScreenComponent } from './jump-screen/jump-screen.component';

@Injectable({ providedIn: 'root' })
export class SsoService implements OnDestroy {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  module: string;
  unsubscribe$ = new Subject<void>();
  teleHealthFlag: boolean;

  constructor(
    private constants: ConstantsService,
    private http: HttpClient,
    private iabService: IabService,
    private modalController: ModalController
  ) {}

  getSsoDetails(ssoUrl: string): Observable<any> {
    const targetLocation = JSON.parse(sessionStorage.getItem('targetHEQLocation'));
    const request = targetLocation
      ? {
          useridin: this.useridin,
          targetContext: targetLocation
        }
      : {
          useridin: this.useridin
        };
    sessionStorage.removeItem('targetHEQLocation');
    if (ssoUrl === 'sso/ebilling' || ssoUrl === 'sso/psw') {
      return this.http.post(this.constants.serviceUrlV2 + ssoUrl, request);
    } else if (ssoUrl === '/sso/vitals') {
      const vitalsResponse = JSON.parse(sessionStorage.getItem('vitalsResponse'));
      this.teleHealthFlag = vitalsResponse.teleHealthEligible;
      request['amwellTeleHealthFlag'] = this.teleHealthFlag && vitalsResponse.platformProvider?.code === '01'
      return this.http.post(this.constants.serviceUrlV2 + 'sso/vitals', request);
    } else {
      return this.http.post(this.constants.serviceUrl + ssoUrl, request);
    }
  }

  createSSOSubmitForm(resp) {
    return `document.body.innerHTML = "<div><FORM METHOD='POST' ACTION='${resp.samlUrl}'>\
        <INPUT TYPE='HIDDEN' NAME='NameValue' VALUE='${resp.samlValue}'></FORM>\
        </div>";setTimeout(function(){ document.forms[0].submit(); }, 500);`;
  }

  createEbillSSOSubmitForm(resp) { 
    const samlValue = resp.samlValue.replace(/\//g,"\\/");
    const samlUrl = resp.samlUrl.replace(/\//g,"\\/");
    return `document.body.innerHTML = "<div><form method='POST' action='${samlUrl}'><input type='hidden' name='NameValue' value='${samlValue}'></form></div>";setTimeout(function(){ document.forms[0].submit(); }, 500);`;
  }
  navigateToIAB(ssoLink: string) {
    this.getSsoDetails(ssoLink).subscribe(response => {
      const js = (ssoLink === 'sso/ebilling') ? this.createEbillSSOSubmitForm(response.ssomsg) : this.createSSOSubmitForm(response.ssomsg);
      const iabRef = this.iabService.create('about:blank');
       iabRef.on('loaderror').subscribe(msg => {
        MYBLUE.error('Load error', msg);
      }); 
      iabRef
        .on('loadstop')
        .pipe(take(1))
        .subscribe(() => {
          iabRef
            .executeScript({
              code: js
            })
            .catch(() => MYBLUE.error('Script execution failed'));
        });
    });
  }

  navigateToNonSSOIAB(link: string) {
    const iabRef = this.iabService.create(link);
    iabRef.on('loaderror').subscribe(msg => {
      MYBLUE.error('Load error', msg);
    });
  }

  async openSSO(module?) {
    const modal = await this.modalController.create({
      component: JumpScreenComponent,
      componentProps: {
        module
      }
    });
    from(modal.onDidDismiss())
      .pipe(takeUntil(this.unsubscribe$))
      .subscribe((dataReturned: any) => {
        if (dataReturned !== undefined) {
          this.continueJumpScreenModal(dataReturned.data);
        }
      });
    return await modal.present();
    this.module = module;
  }

  continueJumpScreenModal(module) {
    if (module === 'alg') {
      this.navigateToIAB('/sso/alegeus');
    } else if (module === 'heq') {
      this.navigateToIAB('/sso/heathequity');
    } else if (module === 'connecture') {
      this.navigateToIAB('/sso/connecture');
    } else if (module === 'fad') {
      this.navigateToIAB('/sso/vitals');
    } else if (module === 'bqi') {
      this.navigateToIAB('/sso/bqi');
    } else if (module === 'cerner') {
      this.navigateToIAB('/sso/cerner');
    } else if (module === 'fdl') {
      this.navigateToIAB('/sso/esi');
    } else if (module === 'expressscripts') {
      this.navigateToIAB('/sso/expressscript');
    } else if (module === 'pillpack') {
      this.navigateToNonSSOIAB('https://www.pillpack.com');
    } else if (module === 'wellnessRewardsProgram') {
      this.navigateToNonSSOIAB(this.constants.wellnessRewardsProgram);
    } else if (module === 'openEyeMedExt') {
      this.navigateToNonSSOIAB(this.constants.eyeMedNavLink);
    } else if (module === 'ebilling') {
      this.navigateToIAB('sso/ebilling');
    } else if (module === 'wellnessRewardsProgram_VP') {
      if (environment.featureVirginPulseSsoEnabled) {
        this.navigateToIAB('sso/virginpulse');
      } else {
        this.navigateToNonSSOIAB('https://www.join.virginpulse.com/wellness');
      }
    } else if (module === 'psw') {
      this.navigateToIAB('sso/psw');
    } else if (module === 'maximizePlanSavingProgram') {
      this.navigateToNonSSOIAB('https://google.com'); // Temporary navigation - DOAIP-5244
    } else if (module === 'otcCvsLink') {
      this.navigateToNonSSOIAB(this.constants.cvsOtcLink);
    }
  }

  ngOnDestroy() {
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}
