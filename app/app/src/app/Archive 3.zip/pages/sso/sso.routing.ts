import { RouterModule, Routes } from '@angular/router';
import { SsoGuard } from './sso.guard';
import { SsoComponent } from './sso/sso.component';

const SSO_ROUTES: Routes = [
  {
    path: '',
    component: SsoComponent,
    canActivate: [SsoGuard]
  }
];

export const SSO_ROUTER = RouterModule.forChild(SSO_ROUTES);
