import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NgxsModule } from '@ngxs/store';
import { ConstantsService } from '@app/services/constants.service';
import { HomeService } from '@app/services/home.service';
import { ConfidentialityPage } from './confidentiality.page';
import { mocks } from '@testing/constants/mocks.service';
import { IonicStorageModule } from '@ionic/storage';
import { IonicModule } from '@ionic/angular';

describe('ConfidentialityPage', () => {
  let component: ConfidentialityPage;
  let fixture: ComponentFixture<ConfidentialityPage>;
  let mockHomeService;
  beforeEach(waitForAsync(() => {
    mockHomeService = mocks.service.homeService;
    TestBed.configureTestingModule({
      imports: [IonicModule, RouterTestingModule, HttpClientTestingModule, NgxsModule.forRoot([]), IonicStorageModule.forRoot()],
      providers: [
        {
          provide: HomeService,
          useValue: mockHomeService
        },
        ConstantsService
      ],
      declarations: [ConfidentialityPage]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfidentialityPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  xdescribe('ngOnInit', () => {
    it('should Call ngOnInit', () => {
      component.ngOnInit();
      expect(component).toBeTruthy();
    });
    it('should call the this.homeService.getConfidentialityPageResponse', () => {
      fixture = TestBed.createComponent(ConfidentialityPage);
      component = fixture.componentInstance;
      // act
      fixture.detectChanges();
      // assert
      expect(mockHomeService.getConfidentialityPageResponse).toHaveBeenCalled();
    });
    it('confidentialityPageApiResponse should be defined', () => {
      expect(component.confidentialityPageApiResponse).toBeDefined();
    });
    // it('Ion Title is Exist', () => {
    //   const element = document.querySelector('ion-title');
    //   expect(element).toBeTruthy();
    // });
    it('Ion Title contains text', () => {
      const element = document.querySelector('ion-title');
      expect(element.textContent.length).toBeGreaterThan(0);
    });
    it('Validating Ion text in template file after component loaded with Mock Home API', () => {
      component.ngOnInit();
      component = fixture.componentInstance;
      fixture.detectChanges();
      const element = document.querySelector('.content');
      expect(element.textContent).toContain('Our Commitment to Confidentiality');
    });
    it('should initiate "confidentialityPageApiResponse" variable', () => {
      fixture = TestBed.createComponent(ConfidentialityPage);
      component = fixture.componentInstance;
      const mockconfidentialResponse = mockHomeService.getConfidentialityPageResponse();
      component.confidentialityPageApiResponse = Array.isArray(mockconfidentialResponse)
        ? mockconfidentialResponse[0]
        : mockconfidentialResponse;
      expect(component.confidentialityPageApiResponse).toEqual(mockconfidentialResponse);
    });
  });
});
