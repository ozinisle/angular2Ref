import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';
import { GuestVisitPageRoutingModule } from './guest-visit-routing.module';
import { GuestVisitPage } from './guest-visit.page';
import { NgxsModule } from '@ngxs/store';
import { TelehealthGuestState } from './store/state/guest-visit.state';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReactiveFormsModule,
    NgxsModule.forFeature(
      [TelehealthGuestState]
    ),
    GuestVisitPageRoutingModule
  ],
  declarations: [GuestVisitPage]
})
export class GuestVisitPageModule {}
