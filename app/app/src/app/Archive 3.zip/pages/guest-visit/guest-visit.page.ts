import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ValidationService } from '@app/services/validation.service';
import { Select, Store } from '@ngxs/store';
import { Observable } from 'rxjs';
import { Initialize, StartGuestVisit } from './store/actions/guest-visit.actions';
import { TelehealthGuestSelectors } from './store/selectors/guest-visit.selectors';

@Component({
  selector: 'app-guest-visit',
  templateUrl: './guest-visit.page.html',
  styleUrls: ['./guest-visit.page.scss'],
})
export class GuestVisitPage {
  form: FormGroup;
  FORM_CONTROL_NAMES = {
    EMAIL_ADDRESS: 'guestEmail',
    GUEST_NAME: 'guestName'
  };

  @Select(TelehealthGuestSelectors.isEmailError) isEmailError$: Observable<boolean>
  constructor(private fb: FormBuilder,
    private validationService: ValidationService,
    private activatedRoute: ActivatedRoute,
    private store: Store) {
      const launchUrl = this.activatedRoute.snapshot.queryParamMap.get('launchUrl');
      this.store.dispatch(new Initialize(launchUrl));
      this.form = this.fb.group({
        [this.FORM_CONTROL_NAMES.GUEST_NAME] : new FormControl('', Validators.required),
        [this.FORM_CONTROL_NAMES.EMAIL_ADDRESS]: new FormControl('', this.validationService.emailValidator())
      })
  }

  submit() {
    if (this.form.valid) {
      this.store.dispatch(new StartGuestVisit(this.form.controls[this.FORM_CONTROL_NAMES.GUEST_NAME].value,
        this.form.controls[this.FORM_CONTROL_NAMES.EMAIL_ADDRESS].value));
    }
  }
}
