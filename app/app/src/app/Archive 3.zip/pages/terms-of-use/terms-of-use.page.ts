import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HomeService } from '@app/services/home.service';

@Component({
  selector: 'app-terms-of-use',
  templateUrl: './terms-of-use.page.html',
  styleUrls: ['./terms-of-use.page.scss']
})
export class TermsOfUsePage implements OnInit {
  text: string;
  from: any;
  termsPageApiResponse: any;

  constructor(private route: ActivatedRoute, private location: Location, private homeService: HomeService) {}

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.from = params.from;
    });
    this.homeService.getTermsPageResponse().subscribe(response => {
      this.termsPageApiResponse = Array.isArray(response) ? response[0] : response;
    });
  }

  close() {
    this.location.back();
  }

  get isFromRegister() {
    return this.from === 'register';
  }
}
