import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MYBLUE } from '@app/app.constants';
import { ConstantsService } from '@app/services/constants.service';
import { HomeService } from '@app/services/home.service';
import { IonicModule } from '@ionic/angular';
import { IonicStorageModule } from '@ionic/storage';
import { NgxsModule } from '@ngxs/store';
import { mocks } from '@testing/constants/mocks.service';
import { TermsOfUsePage } from './terms-of-use.page';

xdescribe('TermsOfUsePage', () => {
  let component: TermsOfUsePage;
  let fixture: ComponentFixture<TermsOfUsePage>;
  let mockHomeService;

  beforeEach(waitForAsync(() => {
    mockHomeService = mocks.service.homeService;
    TestBed.configureTestingModule({
      imports: [IonicModule, RouterTestingModule, HttpClientTestingModule, NgxsModule.forRoot([]), IonicStorageModule.forRoot()],
      providers: [
        {
          provide: HomeService,
          useValue: mockHomeService
        },
        ConstantsService
      ],
      declarations: [TermsOfUsePage]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TermsOfUsePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit', () => {
    it('should Call ngOnInit', () => {
      component.ngOnInit();
      expect(component).toBeTruthy();
    });
    it('should call the this.homeService.getTermsPageResponse', () => {
      try {
        // arrange
        fixture = TestBed.createComponent(TermsOfUsePage);
        component = fixture.componentInstance;

        // act
        fixture.detectChanges();

        // assert
        expect(mockHomeService.getTermsPageResponse).toHaveBeenCalled();
      } catch (error) {
        MYBLUE.warn(error);
      }
    });
    it('termsPageApiResponse should be defined', () => {
      expect(component.termsPageApiResponse).toBeDefined();
    });
    it('Ion Title is Exist', () => {
      const element = document.querySelector('ion-title');
      expect(element).toBeTruthy();
    });
    it('Ion Title contains text', () => {
      const element = document.querySelector('ion-title');
      expect(element.textContent.length).toBeGreaterThan(0);
    });
    it('Validating Ion text in template file after component loaded with Mock Home API', () => {
      component.ngOnInit();
      component = fixture.componentInstance;
      fixture.detectChanges();
      const element = document.querySelector('.content');
      expect(element.textContent).toContain('Limitation of Liability');
    });
    it('should initiate "termsPageApiResponse" variable', () => {
      fixture = TestBed.createComponent(TermsOfUsePage);
      component = fixture.componentInstance;
      const mocktermResponse = mockHomeService.getTermsPageResponse();
      component.termsPageApiResponse = Array.isArray(mocktermResponse) ? mocktermResponse[0] : mocktermResponse;
      expect(component.termsPageApiResponse).toEqual(mocktermResponse);
    });
  });
});
