import { Component, OnDestroy, OnInit } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { OrderreplacementService } from '@app/pages/orderreplacement/services/orderreplacement.service';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { getRTMSMode } from '@app/utils/app.utils';
import { OrderReplacementModel } from './orderreplacement.model';
import { DependentSelectors } from '@app/store/selectors/dependent.selectors';
import { DependentModel } from '@app/models/dependent.model';
import { AlertService } from '@app/services/alert.service';
import { Subject } from 'rxjs';
import { GlobalUtils } from '@app/utils/global.utils';
import { takeUntil } from 'rxjs/operators';

import { Router } from '@angular/router';
import { Store } from '@ngxs/store';
import { SetLoader } from '@app/store/actions/app.actions';
@Component({
  templateUrl: './orderreplacement.component.html',
  styleUrls: ['./orderreplacement.component.scss']
})
export class OrderreplacementComponent implements OnInit, OnDestroy {
  @SelectSnapshot(DependentSelectors.getDependentsList) dependentsList: DependentModel[];
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;

  memberList: Array<any>;
  message: string;
  isEligible: boolean;
  requestIDcardEligibilityIndicator: boolean;
  isRtmsUpmode: boolean;

  isReviewed: boolean;
  isSubmitted: boolean;
  submissionMessageHeader: string;
  submissionMessage: string;
  reviewMessage: string;
  submittedSuccessfully: boolean;
  sideNavStatus: string;
  res: any;
  isMemberText: boolean;
  userString: 'User' = 'User';
  dependant: string;
  selectedMemberList = [];
  submittedMembersList: any[];
  subscriberAddress: any = {};
  successList: any[];
  failureList: any[];
  orderIdCardsData = true;
  memberData: OrderReplacementModel = new OrderReplacementModel().deserialize({});
  allSelected = false;
  isNotEligible: boolean;
  ismobile: boolean;
  private unsubscribeHelper$: Subject<void> = new Subject<void>();

  cardListResponseCount: number;
  medicalCardUsers = [];
  dentalCardUsers = [];
  selectedMedicalMemberList = [];
  selectedDentalMemberList = [];
  medicalUnEligibleList = [];
  dentalUnEligibleList = [];
  successMedicalList = [];
  successDentalList = [];
  cardKeys = [];
  keys = [];
  authTokenDetailsJson: any;
  allmeidcalselected = false;
  alldentalselected = false;
  allMedicalCardSelectDisable = false;

  constructor(
    private alertService: AlertService,
    public router: Router,
    public orderreplacementService: OrderreplacementService,
    private store: Store,
    private resizeService: GlobalUtils
  ) {}

  ngOnInit(): void {
    this.memberList = [];
    this.message = '';
    this.isEligible = true;
    this.isReviewed = false;
    this.isSubmitted = false;
    this.submittedMembersList = [];
    this.successList = [];
    this.failureList = [];
    this.submissionMessageHeader = '';
    this.submissionMessage = '';

    this.reviewMessage =
      'Our records show that you have placed an order in the past 14 days. We cannot duplicate card orders. ' +
      'If you have not received your order, please call Member Services at 1-800-555-5555.';
    this.submittedSuccessfully = false;
    this.isMemberText = true;
    this.resizeService.getIsMobile().pipe(takeUntil(this.unsubscribeHelper$))
    .subscribe((isMobile: boolean) => this.ismobile = isMobile );
  }

  handleError(errRes) {
    if (errRes && errRes['result'] && errRes['result'] < 0) {
      const displayMessage = errRes['displaymessage']
        ? errRes['displaymessage']
        : "We're sorry, there's been a system error. Please try again.";
      this.alertService.setAlert(displayMessage, '', AlertType.Failure);
      this.orderIdCardsData = false;
    }
  }

  ionViewDidEnter() {
    this.isSubmitted = false;
    this.medicalCardUsers = [];
    this.dentalCardUsers = [];
    this.selectedMedicalMemberList = [];
    this.selectedDentalMemberList = [];
    this.medicalUnEligibleList = [];
    this.dentalUnEligibleList = [];
    this.successMedicalList = [];
    this.successDentalList = [];
    this.isRtmsUpmode = getRTMSMode();

    if (this.isRtmsUpmode) {
      this.store.dispatch(new SetLoader(true));
      this.orderreplacementService.getCardPage().subscribe(data => {
        if (data) {
          if (data.SubscriberAddress) {
            this.subscriberAddress = data.SubscriberAddress;
          }
          if (data.MemberDetails && data.MemberDetails.length) {
            this.cardListResponseCount = data.MemberDetails.length;
            this.verifyPreSelectedCards(data.MemberDetails);
          } else {
            this.handleError(data);
          }
        }
        this.store.dispatch(new SetLoader(false));
        this.dependant = this.userString;
        this.memberList.forEach(card => {
          card.selected = false;
          card.isChecked = false;
        });
      });
    }
  }

  close() {
    this.isReviewed = false;
  }

  ngOnDestroy() {
    this.alertService.clearError();
    this.unsubscribeHelper$.next();
    this.unsubscribeHelper$.complete();
  }

  preparesuccessResponse(resultset) {
    this.successMedicalList = [];
    this.successDentalList = [];
    const memberList = this.selectedMemberList && this.selectedMemberList.length ? this.selectedMemberList : this.memberList;
    resultset.forEach(result => {
      const selectedMember = memberList.find(member => member.GroupNumber === result.groupNumber && member.MemberID === result.memberID);
      if (selectedMember) {
        result.result.toString() === '0' ? this.successList.push(selectedMember) : this.failureList.push(selectedMember);
      }
    });
    this.successList.forEach(card => {
      if (card.PlanType === 'medical') {
        this.successMedicalList.push(card);
      }
      if (card.PlanType === 'dental') {
        this.successDentalList.push(card);
      }
    });
  }

  submit() {
    const selectedMemberList = this.getSelectedMembersList();
    this.isSubmitted = true;
    this.orderreplacementService.submitCard(selectedMemberList).subscribe(resultset => {
      const errorList = resultset.filter(result => result.result < 0);
      if (errorList && errorList.length === resultset.length) {
        this.alertService.setAlert('', 'Error!', AlertType.Failure);
        this.submissionMessageHeader = "We Can't Complete Your Order";
        this.submissionMessage = resultset[0]['displayMessage'] || this.reviewMessage;
      } else {
        this.alertService.setAlert('', 'Success!', AlertType.Success);
        this.submissionMessageHeader = 'We Received Your Order';
        this.submittedSuccessfully = true;
        this.preparesuccessResponse(resultset);
      }
    });
  }
  goBack() {
    this.router.navigate(['mycards']);
  }
  disbaledSubmitButton() {
    return this.selectedMedicalMemberList.length + this.selectedDentalMemberList.length < 1 ? true : false;
  }
  verifyPreSelectedCards(data) {
    data.forEach(card => {
      if (card.PlanType === 'medical') {
        this.medicalCardUsers.push(card);
        if (card.RequestIDcardEligibilityIndicator === 'false') {
          this.medicalUnEligibleList.push(card);
        }
        if (card.isChecked) {
          card.selected = true;
          this.selectedMedicalMemberList.push(card);
        }
      } else if (card.PlanType === 'dental') {
        this.dentalCardUsers.push(card);
        if (card.RequestIDcardEligibilityIndicator === 'false') {
          this.dentalUnEligibleList.push(card);
        }
        if (card.isChecked) {
          card.selected = true;
          this.selectedDentalMemberList.push(card);
        }
      }
    });
    this.memberList = data;
    this.allmeidcalselected = this.selectedMedicalMemberList.length === this.medicalCardUsers.length ? true : false;
    this.alldentalselected = this.selectedDentalMemberList.length === this.dentalCardUsers.length ? true : false;

    if (this.medicalUnEligibleList.length || this.dentalUnEligibleList.length) {
      this.alertService.setAlert(
        'Our records show that you have placed an order in the past 14 days.',
        'Too soon to order!',
        AlertType.Notification
      );
    }

    if (data && data.length === 1) {
      if (data[0].RequestIDcardEligibilityIndicator !== 'false') {
        data[0].isChecked = true;
        data[0].selected = true;
        this.memberList = data;
        this.submit();
      }
    }
  }
  onCardAllCheckedStatusChange($event, type) {
    const { checked } = $event.target;
    if (type === 'medical') {
      if (checked) {
        this.selectedMedicalMemberList = [];
        this.memberList.forEach(card => {
          if (card.PlanType === 'medical' && card.RequestIDcardEligibilityIndicator !== 'false') {
            card.selected = true;
            card.isChecked = true;
            this.selectedMedicalMemberList.push(card);
          }
        });
        this.allmeidcalselected = true;
      } else {
        this.memberList.forEach(card => {
          if (card.PlanType === 'medical' && card.RequestIDcardEligibilityIndicator !== 'false') {
            card.selected = false;
            card.isChecked = false;
          }
        });
        this.selectedMedicalMemberList = [];
        this.allmeidcalselected = false;
      }
    }
    if (type === 'dental') {
      if (checked) {
        this.selectedDentalMemberList = [];
        this.memberList.forEach(card => {
          if (card.PlanType === 'dental' && card.RequestIDcardEligibilityIndicator !== 'false') {
            card.selected = true;
            card.isChecked = true;
            this.selectedDentalMemberList.push(card);
          }
        });
        this.alldentalselected = true;
      } else {
        this.memberList.forEach(card => {
          if (card.PlanType === 'dental' && card.RequestIDcardEligibilityIndicator !== 'false') {
            card.selected = true;
            card.selected = false;
            card.isChecked = false;
          }
        });
        this.selectedDentalMemberList = [];
        this.alldentalselected = false;
      }
    }
  }
  onUserCheckedStatusChange($event, member, type) {
    const { checked } = $event.target;
    if (type === 'medical' && member.RequestIDcardEligibilityIndicator !== 'false') {
      if (checked) {
        member.selected = checked;
        member.isChecked = checked;
        this.selectedMedicalMemberList.push(member);
      } else {
        member.selected = checked;
        member.isChecked = checked;
        const findItem = this.selectedMedicalMemberList.find((e, i) => {
          if (e.MemberID === member.MemberID) {
            e.index = i;
            return e;
          }
        });
        if (findItem) {
          this.selectedMedicalMemberList.splice(findItem.index, 1);
        }
        this.allmeidcalselected = false;
      }

      this.allmeidcalselected = this.selectedMedicalMemberList.length === this.medicalCardUsers.length ? true : false;
    }

    if (type === 'dental' && member.RequestIDcardEligibilityIndicator !== 'false') {
      if (checked) {
        member.selected = checked;
        member.isChecked = checked;
        this.selectedDentalMemberList.push(member);
      } else {
        member.selected = checked;
        member.isChecked = checked;
        const findItem = this.selectedDentalMemberList.find((e, i) => {
          if (e.MemberID === member.MemberID) {
            e.index = i;
            return e;
          }
        });
        if (findItem) {
          this.selectedDentalMemberList.splice(findItem.index, 1);
        }
        this.alldentalselected = false;
      }

      this.alldentalselected = this.selectedDentalMemberList.length === this.dentalCardUsers.length ? true : false;
    }
  }
  getSelectedMembersList() {
    const selectedMemberCardList = [];
    for (const member of this.memberList) {
      if (member.isChecked) {
        this.submittedMembersList.push(member);
        selectedMemberCardList.push({
          groupNumber: member.GroupNumber,
          idCardIndicator: 'Y',
          subscriberNumber: member.SubscriberNumber,
          memberID: member.MemberID
        });
      }
    }
    return selectedMemberCardList;
  }
  ionViewDidLeave() {
    this.alertService.clearError();
  }
}
