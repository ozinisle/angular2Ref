import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatListModule } from '@angular/material/list';
import { MaintenanceComponent } from './maintenance/maintenance.component';
import { OrderreplacementComponent } from './orderreplacement.component';
import { ORDER_REPLACEMENT_ROUTER } from './orderreplacement.routing';
import { CamelCaseModule } from '@app/pipes/camelcase/camel-case.module';
import { IonicModule } from '@ionic/angular';
import { AlertsModule } from '@app/components/alerts/alerts.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  declarations: [OrderreplacementComponent, MaintenanceComponent],
  imports: [
    CommonModule,
    ORDER_REPLACEMENT_ROUTER,
    FormsModule,
    ReactiveFormsModule,
    MatListModule,
    CamelCaseModule,
    IonicModule,
    AlertsModule,
    FontAwesomeModule
  ]
})
export class OrderreplacementModule {}
