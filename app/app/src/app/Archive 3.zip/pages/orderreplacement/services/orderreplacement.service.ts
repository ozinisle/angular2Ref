import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { map } from 'rxjs/operators';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { ConstantsService } from '@app/services/constants.service';

@Injectable({ providedIn: 'root' })
export class OrderreplacementService {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  constructor(private http: HttpClient, private constants: ConstantsService) {}

  getCardPage() {
    const request = {
      useridin: this.useridin
    };
    return this.http.post(this.constants.getCardPageurl, request).pipe(
      map((response: any) => {
        if (response.type !== 'error') {
          if (response['fault'] && response['fault'].faultstring) {
            return;
          } else {
            return response;
          }
        }
      })
    );
  }
  submitCard(data) {
    const request = {
      useridin: this.useridin,
      idCardList: data
    };
    return this.http.post(this.constants.orderIdcardurl, request).pipe(
      map((response: any) => {
        if (response.type !== 'error') {
          if (response['fault'] && response['fault'].faultstring) {
            return;
          } else {
            return response['resultSet'] && response['resultSet'].length && response['resultSet'];
          }
        }
      })
    );
  }
}
