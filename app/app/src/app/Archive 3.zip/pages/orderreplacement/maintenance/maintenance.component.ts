import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { ConstantsService } from '@app/services/constants.service';
import { AppSelectors } from '@app/store/selectors/app.selectors';

@Component({
  selector: 'app-maintenance',
  templateUrl: './maintenance.component.html',
  styleUrls: ['./maintenance.component.scss']
})
export class MaintenanceComponent {
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;

  contactus: string;
  urlConfig = {
    myplans: '../my-plans',
    myaccount: '../myaccount',
    fad: '../fad'
  };

  constructor(public constants: ConstantsService, private router: Router, private r: ActivatedRoute) {
    this.contactus = this.constants.contactus + this.scopeName;
  }

  openContactUs() {
    window.open(this.contactus, '_self');
  }

  openUrl(url) {
    if (url) {
      window.open(url, '_self');
    }
  }

  navigate(id, routeParams?) {
    const url = this.urlConfig[id];

    if (url) {
      if (!routeParams) {
        this.router.navigate([url], { relativeTo: this.r });
      } else {
        this.router.navigate([url], { relativeTo: this.r });
      }
    } else {
      return;
    }
  }
}
