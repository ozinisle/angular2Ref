import { RouterModule, Routes } from '@angular/router';
import { OrderreplacementComponent } from './orderreplacement.component';
const ORDERIDCARDS_ROUTER: Routes = [
  {
    path: '',
    data: {
      breadcrumb: 'Order ID Card'
    },
    component: OrderreplacementComponent
  }
];

export const ORDER_REPLACEMENT_ROUTER = RouterModule.forChild(ORDERIDCARDS_ROUTER);
