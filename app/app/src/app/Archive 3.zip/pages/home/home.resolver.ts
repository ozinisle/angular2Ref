import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { SwrveEventNames, SwrveService } from '@app/services/swrve.service';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';

@Injectable({
  providedIn: 'root'
})
export class HomeResolver {
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;
  constructor(private swrveService: SwrveService, private swrveEventNames: SwrveEventNames) {}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (this.scopeName.includes('AUTHENTICATED')) {
      this.swrveService.sendAppMessage(this.swrveEventNames.appScreenHomeAuthenticated);
    } else if (this.scopeName.includes('REGISTERED')) {
      this.swrveService.sendAppMessage(this.swrveEventNames.appScreenHomeRegistered);
    } else {
      this.swrveService.sendAppMessage(this.swrveEventNames.appScreenHomeAnonymous);
    }
  }
}
