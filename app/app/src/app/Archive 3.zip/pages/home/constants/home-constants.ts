export const QUICK_ACCESS_LINKS = [
  {
    id: 'ql-claim-status',
    label: 'Check A Claim',
    icon: ['fal', 'file-invoice-dollar'],
    link: '/myClaims'
  },
  {
    id: 'ql-my-doctors',
    label: 'See MY DOCTORS',
    icon: ['fal', 'user-md'],
    link: '/my-doctor'
  },
  {
    id: 'ql-plan-documentsclaim',
    label: 'See My Plan',
    icon: ['fal', 'file-alt'],
    link: 'myInbox/documents/planDocuments'
  },
  {
    id: 'ql-fad',
    label: 'Find A Doctor & Estimate costs',
    icon: ['fal', 'stethoscope'],
    link: '/fad'
  }
];

export const TRACK_WIDGETS = [
  // {
  //   id: 'ql-rewards',
  //   label: 'REWARDS',
  //   icon: ["fal", "gift-card]',
  //   link: '../myclaims',
  //   hasWidget: true,
  //   selected: false,
  // },
  {
    id: 'ql-health-savings',
    label: 'HEALTH SAVINGS',
    icon: ['fal', 'piggy-bank'],
    hasWidget: true,
    selected: true
  }
  // {
  //   id: 'ql-inbox',
  //   label: 'INBOX',
  //   icon: ["fal", "envelope"],
  //   link: '../message-center/documents/planDocuments',
  //   hasWidget: true,
  //   selected: false,
  // },
  // {
  //   id: 'ql-add-widget-1',
  //   label: 'Add a widget',
  //   icon: ["fal", "fa-plus"],
  //   link: '../message-center/documents/planDocuments',
  //   hasWidget: false,
  //   selected: false,
  // },
  // {
  //   id: 'ql-add-widget-2',
  //   label: 'Add a widget',
  //   icon: ["fal", "fa-plus"],
  //   link: '../message-center/documents/planDocuments',
  //   hasWidget: false,
  //   selected: false,
  // }
];

export const MEMBER_LINKS = [
  {
    label: 'Explore Mental Health Care Options',
    icon: ['fal', 'head-side-brain'],
    content: 'Learn more about everything from remote therapy visits and self-guided programs to substance use support on our',
    active: true,
    buttonTxt: 'Explore Your Benefits',
    link: 'myPlan',
    isExternal: false,
    id: 'ml-mental-health',
    linkLabel: 'Mental Health Resource Center',
    promoLink: 'https://www.bluecrossma.org/myblue/your-health/mental-and-behavioral-health/mental-health-resource-center',
    bottomContent:
      'Looking for your coverage information? Click the link below, then choose your plan. ' +
      'Select &#8220;View Plan Benefits&#8221; (or &#8220;Plan Benefits&#8221; from our mobile app) and select a mental health service to view your coverage.'
  },
  {
    label: 'Get Your Flu Shot',
    icon: ['fal', 'user-injured'],
    content:
      'Getting your flu shot this season is more crucial than ever. It will help keep you, your family, and your community from getting sick. And it could keep you all' +
      ' out of the doctor’s office when so many others may need critical care. Plus, getting your shot is no-cost* and safe.',
    bottomContent:
      '*Exceptions may apply. Check your plan materials for details. Medicare Advantage members are covered when administered by ' +
      'an in-network or out-of-network provider. Flu vaccines are covered under Medicare Part B.',
    active: false,
    buttonTxt: 'Where to Get Your Shot',
    link: 'https://www.bluecrossma.org/myblue/your-health/health-and-wellness/flu-resources',
    isExternal: true,
    id: 'ml-care'
  },
  {
    label: 'Well Connection',
    icon: ['fal', 'video-plus'],
    content: 'Doctors on call, on your device.',
    bottomContent:
      'Well Connection is now accessible through MyBlue, making it easier than ever for you to get the care you need. ' +
      'Get convenient access to medical care 24/7 or schedule a visit with a licensed therapist or psychiatrist on your computer or mobile device.',
    active: false,
    buttonTxt: 'Start Video Visit',
    link: 'virtual-visit',
    isExternal: false,
    id: 'ml-telehealth'
  },
  {
    label: 'Find COVID-19 Testing',
    icon: ['fal', 'vial'],
    content:
      'To find a COVID-19 testing location, click below. Please consult your provider to determine' +
      ' if  COVID-19 testing is medically appropriate for you. For information about coverage for COVID-19 testing, see our',
    active: false,
    buttonTxt: 'Find a Testing Location',
    link: 'https://www.bluecrossma.org/myblue/coronavirus-resource-center',
    isExternal: true,
    id: 'ml-covid-19-testing',
    linkLabel: 'frequently asked questions',
    promoLink: 'https://www.bluecrossma.org/myblue/coronavirus-resource-center#FAQs'
  },
  {
    label: 'Remote Doctor Visits',
    // fontawesome-todo ?
    icon: ['fal', 'video'],
    content: 'Get care virtually with expanded telehealth benefits.',
    active: false,
    buttonTxt: 'Find a Doctor',
    link: 'fad',
    isExternal: false,
    id: 'ml-remote-doctor-visits',
    bottomContent:
      'The pandemic has shown us that telehealth is a vitally important method of providing medical and behavioral health care for members. We are expanding the types of care available via telehealth to include early intervention, short-term rehabilitation, and preventive care as covered services. Effective July 1, your applicable costs (copay, co-insurance, and deductible), if any, will apply for non-COVID telehealth visits*, as they would for in-person services. For more than a year, we waived member costs for non-COVID-19 telehealth visits to help ensure access to care and to help prevent COVID-19 infection and illness. With the successful roll out of vaccines and the relaxation of restrictions, we are ending this temporary accommodation.',
    buttonBottomText: '*Benefits may vary by plan, does not apply to Medicare or FEP plans.'
  },
  {
    label: 'Get Your Fitness/Weight-Loss Reimbursement',
    icon: ['fal', 'weight'],
    content:
      'You <b>may</b> be eligible for a fitness OR weight-loss reimbursement! It’s easy, quick, and paperless. And it could cover health club ' +
      'memberships, and fitness classes like spin, yoga, and kickboxing. Plus in-person or online weight-loss programs like WW®´´ ' +
      '(formerly Weight Watchers). So don’t forget to submit the form!',
    active: false,
    buttonTxt: 'Get Reimbursement',
    link: 'fitness-and-weightloss',
    isExternal: false,
    id: 'ml-fitness-reimbursement'
  }
];

export const lockOutMsg =
  "You've exceeded the maximum number of attempts to verify your account. " +
  'Try again in 24 hours, or call Member Service at ' +
  '<a href="tel:8887721722">1&#8209;888&#8209;772&#8209;1722</a> ' +
  'Monday through Friday, 8:00 a.m. to 6:00 p.m.';
  