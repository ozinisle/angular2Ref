import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { DatePipe, TitleCasePipe } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { AppRate } from '@ionic-native/app-rate/ngx';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { ModalController, IonContent, IonicModule } from '@ionic/angular';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { NgxsModule } from '@ngxs/store';
import { NgxMaskModule } from 'ngx-mask';
import { CamelCasePipe } from '@app/pipes/camelcase/camel-case.pipe';
import { CasingForFilterPipe } from '@app/pipes/casingForFilter/casing-for-filter.pipe';
import { ClaimIdPipe } from '@app/pipes/claim-id/claim-id.pipe';
import { FooterService } from '@app/services/footer.service';
import { HeaderService } from '@app/services/header.service';
import { AlertService } from '@app/services/alert.service';
import { ConstantsService } from '@app/services/constants.service';
import { HomeService } from '@app/services/home.service';
import { AppState } from '@app/store/state/app.state';
import { MyMedicationDetailsService } from '../my-medication/my-medication-details/my-medication-details.service';
import { SsoService } from '../sso/sso.service';
import { HomePageComponent } from './home-page.component';
import { DeductibleService } from '@app/services/deductible.service';
import { NgxsStoragePluginModule } from '@ngxs/storage-plugin';
import { AppVersion } from '@ionic-native/app-version/ngx';
import { AlertsComponent } from '@app/components/alerts/alerts.component';

xdescribe('HomePage', () => {
  let component: HomePageComponent;
  let fixture: ComponentFixture<HomePageComponent>;
  const modalSpy = jasmine.createSpyObj('Modal', ['present']);
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);

  const mockService = jasmine.createSpyObj('FeatureToggleService', ['isFeatureEnabled']);

  mockService.isFeatureEnabled.and.returnValue(true);

  modalCtrlSpy.create.and.callFake(() => {
    return modalSpy;
  });

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        IonicModule,
        RouterTestingModule,
        HttpClientTestingModule,
        NgxMaskModule.forRoot(),
        NgxsStoragePluginModule.forRoot(),
        NgxsSelectSnapshotModule.forRoot(),
        NgxsModule.forRoot([AppState]),
        NgxMaskModule.forRoot()
      ],
      declarations: [HomePageComponent, CamelCasePipe, ClaimIdPipe, AlertsComponent, CasingForFilterPipe],
      providers: [
        {
          useValue: mockService
        },
        AppVersion,
        ConstantsService,
        AlertService,
        TitleCasePipe,
        DatePipe,
        HomeService,
        DeductibleService,
        MyMedicationDetailsService,
        InAppBrowser,
        SsoService,
        HeaderService,
        FooterService,
        AndroidPermissions,
        AppRate,
        IonContent,
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
