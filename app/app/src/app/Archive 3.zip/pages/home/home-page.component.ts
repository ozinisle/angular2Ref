import { Location, TitleCasePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, HostListener, OnDestroy, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { Router } from '@angular/router';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { DeductiblesListComponent } from '@app/components/deductibles-list/deductibles-list.component';
import { FinancialsListComponent } from '@app/components/financials-list/financials-list.component';
import { ScopeNamesEnum } from '@app/enums/scope-names.enum';
import { AuthToken } from '@app/models/auth-token.model';
import { DeductibleModel } from '@app/models/deductible.model';
import { Finanical } from '@app/models/finanical.model';
import { FooterLinkModel } from '@app/models/footer-link.model';
import { LearnToLiveModel } from '@app/models/learn-to-live.model';
import { MultiLingualFooterModel } from '@app/models/multilingual-footer.model';
import { PharmacyLinkType } from '@app/models/pharmacy-link-type';
import { PostLoginModel } from '@app/models/post-login.model';
import { ProfileInfo } from '@app/models/profile-response.model';
import { AlertService } from '@app/services/alert.service';
import { ConstantsService } from '@app/services/constants.service';
import { FooterService } from '@app/services/footer.service';
import { HeaderService } from '@app/services/header.service';
import { HomeService } from '@app/services/home.service';
import { IabService } from '@app/services/iab.service';
import { SwrveEventNames, SwrveService } from '@app/services/swrve.service';
import { SetLoader, SetMemberInfo, SetUserState, StopWelcomeVideoPlay } from '@app/store/actions/app.actions';
import { GetFamilyDeductibles, GetIndividualDeductibles } from '@app/store/actions/deductible.actions';
import { GetDependentList } from '@app/store/actions/dependent.actions';
import { FetchProfile } from '@app/store/actions/profile.action';
import { BANNER_TYPE } from '@app/store/constants/app.constants';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { DeductibleSelectors } from '@app/store/selectors/deductible.selectors';
import { ProfileSelectors } from '@app/store/selectors/profile.selectors';
import { RegisterSelectors } from '@app/store/selectors/register.selectors';
import { GlobalUtils } from '@app/utils/global.utils';
import { environment } from '@environments/environment';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { AppRate } from '@ionic-native/app-rate/ngx';
import { AppVersion } from '@ionic-native/app-version/ngx';
import { IonContent, IonSegment, IonSegmentButton, IonSlides, MenuController, NavController, Platform } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Select, Store } from '@ngxs/store';
import { forkJoin, Observable, Subject, Subscription } from 'rxjs';
import { distinctUntilChanged, filter, map, takeUntil, tap } from 'rxjs/operators';
import { EarnAndSaveService } from '../../services/earn-and-save/earn-and-save.service';
import { SsoService } from '../sso/sso.service';
import { lockOutMsg, MEMBER_LINKS, QUICK_ACCESS_LINKS, TRACK_WIDGETS } from './constants/home-constants';
import { HomePageAppInfoModel } from './home.model';
import { BenefitSearchCPCsList } from '@app/models/search.model';
import { PlanConfigService } from '@app/services/plan-config/plan-config-service';
import { ActivatedRoute } from '@angular/router';
import { SetSearchOnlyFlag, Search  } from '@app/store/actions/search.actions';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Navigate } from '@ngxs/router-plugin';
import {  IonInput  } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss'],
  providers: [
    /* For testing only! Remove or comment out to use real service. */
    // { provide: EarnAndSaveService, useClass: EarnAndSaveMockService }
  ]
})
export class HomePageComponent implements OnInit, OnDestroy {
  @Select(DeductibleSelectors.getOverallFamilyDeductibles) deductibles$: Observable<DeductibleModel[]>;
  @Select(DeductibleSelectors.loadingDeductibles) isLoadingDeductibles$: Observable<boolean>;
  @Select(AppSelectors.getPostLoginInfo) postLoginInfo$: Observable<PostLoginModel>;
  @Select(AppSelectors.getPharmacyLinks) pharmacyLinks$: Observable<PharmacyLinkType[]>;
  @Select(AppSelectors.getAuthToken) authToken$: Observable<AuthToken>;
  @SelectSnapshot(AppSelectors.getMedicareUserCheck) isMedicareUser: boolean;
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getPostLoginInfo) postLoginInfo: PostLoginModel;
  @SelectSnapshot(AppSelectors.getRefreshToken) refreshToken: string;
  @SelectSnapshot(AppSelectors.getSessionId) sessionId: string;
  @SelectSnapshot(RegisterSelectors.onVerifyScreen) redirectToVerify: boolean;

  @SelectSnapshot(DeductibleSelectors.hasFamily) hasFamily: boolean;
  @SelectSnapshot(DeductibleSelectors.hasFirstDollar) hasFirstDollar: boolean;
  @SelectSnapshot(AppSelectors.getLearnToLive) learnToLive: LearnToLiveModel;
  @SelectSnapshot(AppSelectors.getMemProfile) memProfile;

  @SelectSnapshot(AppSelectors.getFinancialsInfo) financialInfo: Finanical[];
  @Select(AppSelectors.isLoadingFinancial) isLoadingFinancial$: Observable<boolean>;
  @Select(AppSelectors.isSearchEnabled) isSearchEnabled$: Observable<boolean>;
  @SelectSnapshot(AppSelectors.getSearchableCpcs) searchablesCpcs: BenefitSearchCPCsList[];
  @Select(ProfileSelectors.getTeleHealthFlag) teleHealthFlag$: Observable<boolean>;

  @SelectSnapshot(DeductibleSelectors.subscriberHasFamily) subscriberHasFamily: boolean;
  @SelectSnapshot(DeductibleSelectors.getInitialName) initialMember: string;

  @SelectSnapshot(ProfileSelectors.getProfileInfo) profileInfo: ProfileInfo;

  @Select(AppSelectors.hasWelcomeVideo) hasWelcomeVideo$: Observable<boolean>;

  @ViewChild(IonContent) content: IonContent;
  @ViewChild('deductiblesListComponent') deductiblesListComponent: DeductiblesListComponent;
  @ViewChild('financialsListComponent') financialsListComponent: FinancialsListComponent;
  @ViewChild('headerSlides', { static: false }) headerSlides: IonSlides;
  @ViewChild('segmentSlides', { static: false }) segmentSlides: IonSlides;
  @ViewChildren(IonSegmentButton) myProgressTabButtons!: QueryList<IonSegmentButton>;

  ismobile: boolean;
  mobileViewPort = 991;
  showWelcomeKit = false;

  showLearnToLive = GlobalUtils.showLearnToLive;

  enableMedlook = true;
  isFitnessEnabled = false;
  isRegisteredUser: boolean;
  isAuthenticatedUser: boolean;
  isAnonymousUser: boolean;
  carouselItemDetails: [] = [];
  memberFirstName: string;
  showDoctorDrupal = false;
  showMedicationDrupal = false;
  showClaimsDrupal = false;
  showNurseLine = false;
  hasBlueGreen = false;
  ahealthyme = false;
  iswellnessRewardsProgramUser = false;

  memberInfo: HomePageAppInfoModel;
  isFinancialView = false;
  doctorData: any;
  medicationData: any;
  claimsData: any;
  isdependant = false;
  ismedicaremember = false;
  isSmartShopperUser = false;
  bannerImage: any = '';
  hasBqi = false;
  isFirstTime = true;
  authFitness = this.swrveEventNames.appClickHomeAuthenticatedFitness;
  unAuthFitness = this.swrveEventNames.appClickHomeAnonymousFitness;
  authAHealthyMe = this.swrveEventNames.appClickHomeAuthenticatedAHealthyMe;
  unAuthAHealthyMe = this.swrveEventNames.appClickHomeAnonymousAHealthyMe;
  homepageApiResponse: Observable<any>;
  homeNavigationApiResponse: any;
  homeHeroBannerResponse: any;
  faIcon2: any;
  faIcon3: any;
  faIcon4: any;
  faIcon5: any;
  homeDiscountsResponse: Observable<any>;
  featureUrl = this.constantsService.featureUrl;
  anonymousFeedback = this.constantsService.anonymousFeedback;
  blue365Url = this.constantsService.blue365Url;
  footerGlobalLinks: any;
  langTranslation: any;
  multiLingualFooter: MultiLingualFooterModel;
  langFooterText: any;
  drupalUrl = environment.drupalUrl;
  promoButtonText = '';
  promoButtonUrl = '';
  promoBodyText = '';
  promoBodySubTitle = '';
  isExternalLink = '';
  isMedicarePPO = '';
  isHomePageInActive = false;

  backButtonSubscription: Subscription;

  destroy$: Subject<boolean> = new Subject<boolean>();

  slideOpts = {
    initialSlide: 0,
    speed: 400,
    loop: false
  };
  slideOptsRecommendedContent = {
    initialSlide: 0,
    spaceBetween: 30,
    slidesPerView: 1.2,
    centeredSlidesBounds: true
  };
  activeSlide = 0;
  activeSegmentSlide = 0;
  quickLinks = QUICK_ACCESS_LINKS;
  memberLinks = MEMBER_LINKS;
  trackWidgets = TRACK_WIDGETS;
  lockOutMsg= lockOutMsg;
  brandFooter = [];
  medicalCovTile = [];
  dentalCovTile = [];
  visionCovTile = [];
  allCoveragePlans = [];
  testSlides = [1, 2, 3];
  footerLinks: FooterLinkModel[];
  isFinancialWidgetEnabled: boolean;

  public isEarnAndSaveWidgetEnabled$ = this.earnAndSaveService.isEarnAndSaveWidgetEnabledForCurrentUser$;
  public isMaximizePlanWidgetEnabled$ = this.earnAndSaveService.isMaximizePlanWidgetEnabledForCurrentUser$;

  public segment: string;
  recommendedForYouContent = [];
  isNewPersonalizedHubEnabled: boolean;
  internalRecommendedLink: any;

  allCoveredPlans:any;
  hasWelcomeVideo = false;
  isCDHEnabledUser: boolean;
  trimmedSearchText = '';
  curatedSearchVariable:boolean;
  keyword: string;
  searchForm: FormGroup;
  @ViewChild('searchInput', { static: false }) searchInput: IonInput;

  constructor(
    private router: Router,
    private store: Store,
    private location: Location,
    private constantsService: ConstantsService,
    private alertService: AlertService,
    private http: HttpClient,
    private titleCase: TitleCasePipe,
    private menu: MenuController,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames,
    private iabService: IabService,
    private ssoService: SsoService,
    private headerService: HeaderService,
    private platform: Platform,
    private footerService: FooterService,
    private androidpermissions: AndroidPermissions,
    private appRate: AppRate,
    private appVersion: AppVersion,
    private navCtrl: NavController,
    private homeService: HomeService,
    private earnAndSaveService: EarnAndSaveService,
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private planConfigService: PlanConfigService
  ) {
    this.isFitnessEnabled = environment.fitnessBenefits;
    this.isFinancialWidgetEnabled = environment.enableFinancialWidget;
    this.isNewPersonalizedHubEnabled = environment.enableNewPersonalizedHub;
    this.enableMedlook = !this.showLearnToLive;
    this.ismobile = window.innerWidth <= this.mobileViewPort;
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.ismobile = event.target.innerWidth <= this.mobileViewPort;
  }

  async getIndex() {
    this.activeSlide = await this.headerSlides.getActiveIndex();
  }

  async getSegmentSlideIndex(){
    this.activeSegmentSlide = await this.segmentSlides.getActiveIndex();
  }

  gotoSlide(i: number, slide: string) {
    if (slide  === 'header') {
      this.headerSlides.slideTo(i);
    }
    if (slide === 'segment') {
      this.segmentSlides.slideTo(i);
    }
  }

  slideNext(event: any, slide: string) {
    event.stopPropagation();
    if (slide  === 'header') {
      this.headerSlides.slideNext();
    }
    if (slide === 'segment') {
      this.segmentSlides.slideNext();
    }
  }

  slidePrev(event: any, slide: string) {
    event.stopPropagation();
    if (slide  === 'header') {
      this.headerSlides.slidePrev();
    }
    if (slide === 'segment') {
      this.segmentSlides.slidePrev();
    }
  }

  scrollToTop() {
    this.content?.scrollToTop(200);
  }

  ionViewWillEnter() {
    this.planConfigService.getCurrentPlanConfig$().subscribe(config => {
      this.isCDHEnabledUser = config != null? config.elligibility.isDigitalFirstCDH : false}); 
    this.showWelcomeKit = true;
    this.alertService.clearError();
    this.store.dispatch(new SetSearchOnlyFlag(true));
    if (this.keyword) {
      this.search();
      this.searchForm.patchValue({
        keyword: this.keyword
      });
    }
  }

  ionViewWillLeave() {
    this.showWelcomeKit = false;
    this.store.dispatch(new StopWelcomeVideoPlay(true));
  }

  ionViewDidEnter() {
    this.store.dispatch(new StopWelcomeVideoPlay(false));
    this.defaultMemberLinksSelection();
    this.scrollToTop();
    window.scrollTo(0, 0);
    this.getDeductible();
    this.getPlanCarouselDetails();
    this.taxFormDeepLink();
    this.brandBannerContent();
    this.backButtonSubscription = this.platform.backButton.subscribeWithPriority(10000, () => {
      const urlPath = this.router.routerState.snapshot.url;
      if (urlPath.includes('home')) {
        this.menu.isOpen().then(isOpen => {
          isOpen ? this.menu.close() : navigator['app'].exitApp();
        });
      } else {
        this.location.back();
      }
    });
    if (localStorage.getItem('LOCKED_OUT') && localStorage.getItem('LOCKED_OUT') === 'true') {
      this.alertService.setAlert(this.lockOutMsg, '', AlertType.Failure);
      localStorage.removeItem('LOCKED_OUT');
    }

    /*
     * Visibility of some of the "[name]'s Dashboard" tabs is controlled by
     * Observables -- so whenever the tabs change, default the selected content
     * to that of the first available tab.
     * This should account for any late tab initialization.
     */
    this.myProgressTabButtons.changes
      .pipe(
        takeUntil(this.destroy$),
        distinctUntilChanged((previous: QueryList<IonSegment>, current: QueryList<IonSegment>) => {
          const itemCount = previous.length;
          const previousItems = previous.toArray();
          const currentItems = current.toArray();
          for (let itemIndex = 0; itemIndex < itemCount; itemIndex++) {
            if (previousItems[itemIndex] !== currentItems[itemIndex]) {
              return false;
            }
          }
          return true;
        }),
        tap(() => {
          this.segment = this.myProgressTabButtons.first?.value;
        })
      )
      .subscribe();
  }

  private defaultMemberLinksSelection() {
    this.memberLinks.forEach((item, count) => {
      if (count === 0) {
        return (item.active = true);
      } else {
        return (item.active = false);
      }
    });
  }

  private brandBannerContent() {
    this.homeService.getBannerPromoContent(this.hasWelcomeVideo ? BANNER_TYPE.MEDICARE : BANNER_TYPE.DEFAULT).subscribe(response => {
      if (response?.[0]) {
        this.promoButtonText = response[0].ButtonText;
        this.promoBodySubTitle = this.hasWelcomeVideo ? response[0].Title : '';
        this.promoButtonUrl =
          response[0].isExternal === 'FALSE' ? response[0].APPButtonUrl.replace('internal:', '') : response[0].APPButtonUrl;
        this.promoBodyText = response[0].Body;
        this.isExternalLink = response[0].isExternal;
      }
    });
  }

  private getBrandFooter() {
    const userAge = Date.parse(this.profileInfo?.dob);
    const brandFooter1 = this.homeService.getBrandPromoFooter(0);
    const brandFooter3 = this.homeService.getBrandPromoFooter(2);
    const brandFooter4 = this.homeService.getBrandPromoFooter(3);
    this.brandFooter = [];
    forkJoin([brandFooter1, brandFooter3]).subscribe(response => {
      brandFooter4.subscribe(result => {
        if (result[0].Title !== '') {
          const userTypes = result[0].field_plan_type_export[0].plan_name.map(val => val.toLowerCase().trim());
          if (
            this.authToken?.scopename === ScopeNamesEnum.AV &&
            userAge > Date.parse(result[0].StartDateOfBirth) &&
            userAge < Date.parse(result[0].EndDateOfBirth) &&
            this.authToken?.userType?.toLowerCase() &&
            (userTypes.includes('all') || userTypes.includes(this.authToken?.userType?.toLowerCase()))
          ) {
            result[0].hasPsw = true;
            this.brandFooter.push(response[0], result, response[1]);
          } else {
            this.callSecondBlock(response);
          }
        } else {
          this.callSecondBlock(response);
        }
      });
    });
  }

  callSecondBlock(response) {
    const brandFooter2 = this.homeService.getBrandPromoFooter(1);
    brandFooter2.subscribe(res => {
      this.brandFooter.push(response[0], res, response[1]);
    });
  }

  openBannerUrl(url) {
    if (this.isExternalLink === 'FALSE') {
      this.router.navigateByUrl(url);
    } else {
      window.open(url);
    }
  }

  headerTab(index) {
    this.memberLinks.forEach((item, count) => {
      if (count === index) {
        return (item.active = true);
      } else {
        return (item.active = false);
      }
    });
  }

  private taxFormDeepLink() {
    if (localStorage.getItem('targetRoute') === '/tax-forms' && this.isAuthenticatedUser) {
      localStorage.removeItem('targetRoute');
      this.router.navigateByUrl('/tax-forms');
    }
  }

  toggleMenu() {
    this.router.navigate(['brand-home']);
  }

  quickLinksOpen(link, id) {
    if (id === 'ql-fad') {
      const isSapphireDigitalUser = this.postLoginInfo ? this.checkSapphireDigitalUser(this.postLoginInfo) : false;
      if (isSapphireDigitalUser) {
        this.sendSwrveEventsForIABClicks(this.unAuthFitness);
        this.ssoService.openSSO('fad');
      } else {
        this.router.navigate(['fad']);
      }
      return;
    } else if (id === 'ql-plan-documentsclaim') {
      sessionStorage.setItem('qHomeFlag', 'true');
      this.router.navigate([link]);
    } else {
      this.router.navigate([link]);
    }
  }
  
  ngOnInit() {
    // if(sessionStorage.getItem('isIPASelected')==='true') {
    //   sessionStorage.setItem('isIPASelected', "false");
    // }
    this.route.paramMap.pipe(takeUntil(this.destroy$)).subscribe(paramsMap => {
      this.keyword = paramsMap.get('keyword');
    });
    this.searchForm = this.fb.group({
      keyword: ['', [Validators.required]]
    });


    this.authToken$.pipe(takeUntil(this.destroy$)).subscribe(authToken => {
      this.entryTasks();
    });
    this.teleHealthFlag$.pipe(takeUntil(this.destroy$)).subscribe(teleHealthFlag => {
      this.memberLinks = MEMBER_LINKS.filter(link => link.id !== (teleHealthFlag ? 'ml-care' : 'ml-telehealth'));
    });
    this.hasWelcomeVideo$.pipe(takeUntil(this.destroy$)).subscribe(hasWelcomeVideo => {
      this.hasWelcomeVideo = hasWelcomeVideo;
      this.showUserBanner();
      this.brandBannerContent();
      this.scrollToTop();
    });
    this.setFooterLinks();
    this.setMultiLanguageFooter();
  }

  initialize() {
    this.homeService
      .getCarouselItemDetails()
      .pipe(takeUntil(this.destroy$))
      .subscribe(response => {
        this.carouselItemDetails = this.transformCarouselResponse(response);
      });

    // Home Page -- Promo Block Code
    this.homeService.loadArticle(1);
    this.homeService.loadArticle(2);
    this.homeService.loadArticle(3);

    this.homeService.getHomePageApiResponse().subscribe(
      response => {
        this.homepageApiResponse = this.transformPageApiResponse(Array.isArray(response) ? response[0] : response);
      },
      error => {
        console.error('error loading home ' + JSON.stringify(error, null, 2));
      }
    );

    this.homeService.getHomeNavigationResponse().subscribe(response => {
      this.homeNavigationApiResponse = Array.isArray(response) ? response[0] : response;
      if (this.homeNavigationApiResponse) {
        sessionStorage.setItem('find_a_doctor_link', this.homeNavigationApiResponse.APPTextUrl3 || '');
        sessionStorage.setItem('call_nurse_link_link', this.homeNavigationApiResponse.APPTextUrl2 || '');
      }
    });

    this.homeService.getHomeHeroBannerResponse().subscribe(response => {
      this.homeHeroBannerResponse = Array.isArray(response) ? response[0] : response;
      if (this.homeHeroBannerResponse) {
        const faClass2 = this.homeHeroBannerResponse.FontawesomeIconClass2.split(' ', 2);
        this.faIcon2 = [faClass2[0], faClass2[1].replace('fa-', '')];
        const faClass3 = this.homeHeroBannerResponse.FontawesomeIconClass3.split(' ', 2);
        this.faIcon3 = [faClass3[0], faClass3[1].replace('fa-', '')];
        const faClass4 = this.homeHeroBannerResponse.FontawesomeIconClass4.split(' ', 2);
        this.faIcon4 = [faClass4[0], faClass4[1].replace('fa-', '')];
        const faClass5 = this.homeHeroBannerResponse.FontawesomeIconClass5.split(' ', 2);
        this.faIcon5 = [faClass5[0], faClass5[1].replace('fa-', '')];
      }
    });

    this.homeService.getHomeDiscountsResponse().subscribe(response => {
      this.homeDiscountsResponse = Array.isArray(response) ? response[0] : response;
    });

    this.alertService.clearError();
    this.clearSessionItems();
    //this.getFooter();
    this.setGlobalFooter();
    this.accessFineLocation();
    //recommended for you
    if (this.isNewPersonalizedHubEnabled) {
      this.getRecommendedList();
      // this.getPlanCarouselDetails();
    }
  }

  private getDeductible() {
    this.deductibles$.pipe(takeUntil(this.destroy$)).subscribe(data => {
      if (data) {
        this.allCoveragePlans = [];
        const medicalCoverage = data.filter(
          item =>
            item.coverageType.toLowerCase() === 'medical' ||
            (item.coverageType.toLowerCase() !== 'dental' && item.coverageType.toLowerCase() !== 'vision')
        );
        const dentalCoverage = data.filter(item => item.coverageType.toLowerCase() === 'dental');
        const visionCoverage = data.filter(item => item.coverageType.toLowerCase() === 'vision');
        this.medicalTile(medicalCoverage);
        this.dentalTile(dentalCoverage);
        this.visionTile(visionCoverage);
      }
    });
  }

  goPlanPage() {
    this.router.navigate(['/myPlan']);
  }

  private getPlanCarouselDetails() {
    this.allCoveredPlans = this.searchablesCpcs;
  }

  private getDeductibleData(deductData) {
    const fdcMedCoverage = [],
      overallDeductibleMedCoverage = [],
      outOfPocketMedCoverage = [],
      itemTypeNotExist = [],
      overallBenefit = [];
    deductData.forEach(item => {
      if (item.type === 'First Coverage') {
        fdcMedCoverage.push(item);
      } else if (item.type === 'Overall Deductible') {
        overallDeductibleMedCoverage.push(item);
      } else if (item.type === 'Out-Of-Pocket Maximum') {
        outOfPocketMedCoverage.push(item);
      } else if (item.type === 'Overall Benefit') {
        overallBenefit.push(item);
      } else if (!item.type) {
        itemTypeNotExist.push(item);
      }
    });
    return { fdcMedCoverage, overallDeductibleMedCoverage, outOfPocketMedCoverage, itemTypeNotExist, overallBenefit };
  }

  private medicalTile(medicalData) {
    if (medicalData) {
      this.medicalCovTile = [];
      const {
        fdcMedCoverage,
        overallDeductibleMedCoverage,
        outOfPocketMedCoverage,
        itemTypeNotExist,
        overallBenefit
      } = this.getDeductibleData(medicalData);
      if (fdcMedCoverage?.length > 0 && fdcMedCoverage[0]?.contributed < 500) {
        this.medicalCovTile = fdcMedCoverage;
      } else if (overallDeductibleMedCoverage?.length > 0) {
        this.medicalCovTile = overallDeductibleMedCoverage;
      } else if (outOfPocketMedCoverage?.length > 0) {
        this.medicalCovTile = outOfPocketMedCoverage;
      } else if (overallBenefit?.length > 0) {
        this.medicalCovTile = overallBenefit;
      } else if (itemTypeNotExist?.length > 0) {
        this.medicalCovTile = itemTypeNotExist;
      } else {
        this.medicalCovTile = [];
      }
      if (this.medicalCovTile.length > 0) {
        this.allCoveragePlans.push(this.medicalCovTile[0]);
      }
    }
  }

  private dentalTile(dentalData) {
    if (dentalData) {
      this.dentalCovTile = [];
      const {
        fdcMedCoverage,
        overallDeductibleMedCoverage,
        outOfPocketMedCoverage,
        itemTypeNotExist,
        overallBenefit
      } = this.getDeductibleData(dentalData);
      if (fdcMedCoverage?.length > 0 && fdcMedCoverage[0]?.contributed < 500) {
        this.dentalCovTile = fdcMedCoverage;
      } else if (overallDeductibleMedCoverage?.length > 0) {
        this.dentalCovTile = overallDeductibleMedCoverage;
      } else if (outOfPocketMedCoverage?.length > 0) {
        this.dentalCovTile = outOfPocketMedCoverage;
      } else if (overallBenefit?.length > 0) {
        this.dentalCovTile = overallBenefit;
      } else if (itemTypeNotExist?.length > 0) {
        this.dentalCovTile = itemTypeNotExist;
      } else {
        this.dentalCovTile = [];
      }
      if (this.dentalCovTile.length > 0) {
        this.allCoveragePlans.push(this.dentalCovTile[0]);
      }
    }
  }

  private visionTile(visionData) {
    if (visionData) {
      this.visionCovTile = [];
      const {
        fdcMedCoverage,
        overallDeductibleMedCoverage,
        outOfPocketMedCoverage,
        itemTypeNotExist,
        overallBenefit
      } = this.getDeductibleData(visionData);
      if (fdcMedCoverage?.length > 0 && fdcMedCoverage[0]?.contributed < 500) {
        this.visionCovTile = fdcMedCoverage;
      } else if (overallDeductibleMedCoverage?.length > 0) {
        this.visionCovTile = overallDeductibleMedCoverage;
      } else if (outOfPocketMedCoverage?.length > 0) {
        this.visionCovTile = outOfPocketMedCoverage;
      } else if (overallBenefit?.length > 0) {
        this.visionCovTile = overallBenefit;
      } else if (itemTypeNotExist?.length > 0) {
        this.visionCovTile = itemTypeNotExist;
      } else {
        this.visionCovTile = [];
      }
      if (this.visionCovTile.length > 0) {
        this.allCoveragePlans.push(this.visionCovTile[0]);
      }
    }
  }

  async accessFineLocation() {
    const hasRequestedPermission = sessionStorage.getItem('hasRequestedPermisson');
    if (hasRequestedPermission === 'true') {
      sessionStorage.setItem('hasRequestedPermisson', 'true');
      if (this.platform.is('android')) {
        const hasPermission = await this.androidpermissions.checkPermission(this.androidpermissions.PERMISSION.ACCESS_FINE_LOCATION);
        if (!hasPermission) {
          this.androidpermissions.requestPermissions(this.androidpermissions.PERMISSION.ACCESS_FINE_LOCATION);
        }
      }
    }
  }

  //not called, line 366
  getFooter() {
    if (!this.homeService.globalFooterData) {
      this.footerService
        .getGlobalFooter()
        .pipe(
          filter((response: any) => response?.length),
          map(response => response[0])
        )
        .subscribe(data => {
          this.footerGlobalLinks = data;
          this.homeService.globalFooterData = data;
        });
    } else {
      this.footerGlobalLinks = this.homeService.globalFooterData;
    }
  }

  // get global footer links
  public setGlobalFooter(): void {
    if (!this.footerService.globalFooterData) {
      this.footerService.getGlobalBrandFooter().subscribe(data => {
        if (data && data.length) {
          this.footerGlobalLinks = data[0];
          this.footerService.globalFooterData = data[0];
        }
      });
    } else {
      this.footerGlobalLinks = this.footerService.globalFooterData;
    }
  }

  transformPageApiResponse(response: any) {
    return {
      ...response,
      MobileHeroBanner: this.constantsService.drupalUrl + '/' + response.MobileHeroBanner
    };
  }

  clearSessionItems() {
    sessionStorage.removeItem('medicationDetailRequest');
    sessionStorage.removeItem('medicationDependentMemberInfo');
  }

  checkSmartShopperUser(postLoginInfo: PostLoginModel) {
    return postLoginInfo.hasSS;
  }

  checkSapphireDigitalUser(postLoginInfo: any = {}) {
    return postLoginInfo.hasCI || postLoginInfo.hasSS || postLoginInfo.hasSSO;
  }

  entryTasks() {
    this.isFirstTime = false;
    //console.log(this.postLoginInfo, 'postLogin');
    this.isRegisteredUser = this.scopeName?.includes('REGISTERED');
    this.isAuthenticatedUser = this.scopeName?.includes('AUTHENTICATED');
    this.isAnonymousUser = !(this.isRegisteredUser || this.isAuthenticatedUser);
    this.alertService.clearError();
    if (this.scopeName === ScopeNamesEnum.ANV || this.scopeName === ScopeNamesEnum.AV) {
      this.memberFirstName = this.authToken?.firstName ? this.authToken.firstName : '';
    } else {
      //Show the alert for RV and RNV users
      this.alertService.setAlert(this.constantsService.registerNewMembers, 'Welcome New Members!', AlertType.Warning, 'registeredhomepage');
      this.memberFirstName = '';
    }
    if (
      this.scopeName?.includes('AUTHENTICATED') &&
      this.authToken?.migrationtype === 'NONE' &&
      this.authToken?.scopename !== ScopeNamesEnum.ANV
    ) {
      this.store.dispatch(new FetchProfile());
      this.loadHomePageInfo();
    }
    this.initialize();
    this.scrollToTop();
    if (this.memberFirstName) {
      const getFontSize = textLength => {
        const baseSize = 7;
        if (textLength > 10) {
          textLength = textLength > 15 ? baseSize - 1 : baseSize - 2;
        }
        let fontSize = Math.abs(textLength - baseSize) + 1;
        if (this.platform.is('mobile') || this.platform.is('mobileweb') || this.platform.width() <= '991') {
          if (textLength > 15) {
            fontSize = fontSize + 2;
          } else {
            fontSize = fontSize + 6;
          }
        }
        return `${fontSize}vw`;
      };
      const boxes = document.querySelectorAll<HTMLElement>('.banner-cnt-title span');
      boxes.forEach(box => {
        box.style.fontSize = getFontSize(box.textContent.length);
      });
    }
  }

  loadHomePageInfo() {
    this.store.dispatch([new GetDependentList()]);
    this.store.dispatch([new GetFamilyDeductibles(this.useridin, false)]).subscribe((data: any) => {
      if (
        !data[0].deductible.subscriberHasFamily &&
        data[0].deductible.subscriberHasFamily !== null &&
        data[0].deductible.subscriberHasFamily !== undefined
      ) {
        this.store.dispatch(new GetIndividualDeductibles(this.initialMember, 'MEDICAL'));
      }
    });
    //  this.store.dispatch(new SetLoader(true));
    this.homeService.getHomepageinfo(this.useridin).subscribe(
      (data: any) => {
        if (data) {
          if (data.ROWSET && !Array.isArray(data.ROWSET.ROW) && typeof data.ROWSET.ROW === 'object') {
            this.memberInfo = new HomePageAppInfoModel(this.titleCase).deserialize(data.ROWSET && data.ROWSET.ROW);
            this.isSmartShopperUser = this.postLoginInfo ? this.checkSmartShopperUser(this.postLoginInfo) : false;

            this.showNurseLine =
              this.memberInfo?.cerner?.hasCernerMedicare !== 'true' &&
              this.memberInfo?.hasBlueGreen !== 'true' &&
              this.memberInfo?.hasBQi !== 'true';
            this.hasBqi = this.memberInfo.hasBQi === 'true';
            this.hasBlueGreen = this.memberInfo.hasBlueGreen === 'true';

            this.ahealthyme = this.memberInfo?.wellnessVendorCd === 'C' || this.memberInfo?.cerner.hasCernerMedicare === 'true';

            // sessionStorage.setItem('isEE', this.memberInfo.isEE);
            this.iswellnessRewardsProgramUser =
              this.memberInfo?.wellnessVendorCd === 'VP' && this.memberInfo?.cerner.hasCernerMedicare === 'false';
            this.store.dispatch([new SetMemberInfo(this.memberInfo), new SetUserState(this.memberInfo.userState)]);

            if (this.memberInfo?.myclaims?.clmICN) {
              sessionStorage.setItem('claimId', this.memberInfo.myclaims.clmICN);
            }

            if (this.authToken && this.authToken.userType) {
              this.isMedicarePPO =
                this.authToken.userType.toLowerCase() === 'medicare' && JSON.parse(this.memberInfo.isPPO) ? 'true' : 'false';
              sessionStorage.setItem('isMedicarePPO', this.isMedicarePPO);
            }
          }
          this.hasFinancialsData();
          this.showUserBanner();
          this.showUserDataBlocks();
          this.getBrandFooter();
        }
      },
      error => this.store.dispatch(new SetLoader(false))
    );

    if (this.authToken?.unreadMsgCount && !this.headerService.unReadMsgCount) {
      this.headerService.unReadMsgCount = this.authToken.unreadMsgCount.toString();
    }
  }

  showUserBanner(): void {
    if (this.isMedicare()) {
      this.bannerImage = this.hasWelcomeVideo ? undefined : 'hero-medicare';
      this.ismedicaremember = true;
      this.store.dispatch(new FetchProfile());
    } else if (this.memberInfo?.hasDependents.toString() === 'false' && !this.isMedicare()) {
      this.bannerImage = 'hero-individual';
      this.isdependant = true;
    } else if (this.memberInfo?.hasDependents.toString() === 'true') {
      this.bannerImage = 'hero-family';
    } else {
      this.bannerImage = 'hero-family';
    }
  }

  isMedicare() {
    return this.authToken?.userType?.toLowerCase() === 'medicare' || this.authToken?.userType?.toLowerCase() === 'medex';
  }

  openInAppBrowser(url, ispsw = false) {
    if (!ispsw && url) {
      this.iabService.create(url);
    } else if (ispsw) {
      this.ssoService.openSSO('psw');
    }
  }

  openMemberLinks(url, isExternal, id) {
    if (id === 'ml-remote-doctor-visits') {
      const isSapphireDigitalUser = this.postLoginInfo ? this.checkSapphireDigitalUser(this.postLoginInfo) : false;
      if (isSapphireDigitalUser) {
        this.sendSwrveEventsForIABClicks(this.unAuthFitness);
        this.ssoService.openSSO('fad');
      } else {
        this.router.navigate(['fad']);
      }
      return;
    } else if (!isExternal) {
      this.router.navigate([url]);
    } else {
      this.openInAppBrowser(url);
    }
  }

  learntoLive() {
    this.ssoService.openSSO('Learn2Live');
  }

  openInAppBrowserSso(url: string, ssoLink: string, unAuthSwrveEvent: string, authSwrveEvent: string) {
    if (url.endsWith('fad')) {
      const isSapphireDigitalUser = this.postLoginInfo ? this.checkSapphireDigitalUser(this.postLoginInfo) : false;
      if (isSapphireDigitalUser) {
        this.sendSwrveEventsForIABClicks(authSwrveEvent);
        this.ssoService.openSSO('fad');
      } else {
        this.router.navigate(['fad']);
      }
      return;
    } else if (ssoLink === 'cerner') {
      if (this.memberInfo.cerner.hasCernerMedicare === 'true') {
        window.open(this.constantsService.cernerMedicareUrl, '_blank');
      } else if (this.memberInfo?.wellnessVendorCd === 'C' && this.memberInfo?.cerner.hasCernerMedicare === 'false') {
        this.sendSwrveEventsForIABClicks(authSwrveEvent);
        this.ssoService.openSSO('cerner');
      }
      return;
    }
    if (this.isAuthenticatedUser) {
      this.sendSwrveEventsForIABClicks(authSwrveEvent);
      this.ssoService.openSSO(ssoLink);
    } else {
      this.sendSwrveEventsForIABClicks(unAuthSwrveEvent);
      this.iabService.create(url);
    }
  }

  sendSwrveEventsForIABClicks(desctiption: string) {
    if (desctiption === 'Find_a_doctor') {
      if (this.isAuthenticatedUser) {
        this.swrveService.sendAppMessage(this.swrveEventNames.appClickHomeAuthenticatedFindADoctor);
      } else if (this.isRegisteredUser) {
        this.swrveService.sendAppMessage(this.swrveEventNames.appClickHomeRegisteredFindADoctor);
      } else if (this.isAnonymousUser) {
        this.swrveService.sendAppMessage(this.swrveEventNames.appClickHomeAnonymousFindADoctor);
      }
    }
  }

  transformCarouselResponse(response: any): [] {
    if (response?.length) {
      return response.map(item => {
        const carouselItem = new Image() as any;
        carouselItem.src = this.constantsService.drupalUrl + '/' + item.RegularImages;
        carouselItem.mobilesrc = this.constantsService.drupalUrl + '/' + item.MobileImages;
        carouselItem.text = item.ArticleText;
        carouselItem.isVideo = item.VideoUrl.length;
        carouselItem.VIdeoUrl = item.VideoUrl;
        carouselItem.urlLink = item.ArticleUrl;
        carouselItem.Title = item.Title;
        carouselItem.Body = item.Body;
        return carouselItem;
      });
    }
    return [];
  }

  nextFinanceInfo(e) {
    e.stopPropagation();
    this.financialsListComponent?.financialSlides?.slideNext();
  }

  previousFinanceInfo(e) {
    e.stopPropagation();
    this.financialsListComponent?.financialSlides?.slidePrev();
  }

  nextDeductible(e) {
    e.stopPropagation();
    this.deductiblesListComponent?.deductibleSlides.slideNext();
  }

  previousDeductible(e) {
    e.stopPropagation();
    this.deductiblesListComponent?.deductibleSlides.slidePrev();
  }

  hasFinancialsData(): boolean {
    const hasALG = this.memberInfo?.hasALG?.toString().toLowerCase();
    const hasHEQ = this.memberInfo?.hasHEQ?.toString().toLowerCase();
    const result = this.memberInfo && (hasALG === 'yes' || hasHEQ === 'yes' || hasHEQ === 'true' || hasALG === 'true');
    sessionStorage.setItem('hasALG', hasALG);
    sessionStorage.setItem('hasHEQ', hasHEQ);
    this.isFinancialView = result;
    return result;
  }

  showUserDataBlocks(): void {
    this.showMedicationDrupal = false;
    this.showDoctorDrupal = false;
    this.showClaimsDrupal = false;

    if (this.memberInfo) {
      if (this.memberInfo.mydoctors && !this.memberInfo.mydoctors.visitPrvName) {
        this.showDoctorDrupal = true;
        this.getDrupalContent(this.constantsService.drupalDoctorsUrl).subscribe(response => {
          this.doctorData = response[0];
        });
      }

      if (this.memberInfo?.mymedications && !this.memberInfo.mymedications.rxDrugName) {
        this.showMedicationDrupal = true;
        this.getDrupalContent(this.constantsService.drupalMedicationsUrl).subscribe(response => {
          this.medicationData = response[0];
        });
      }
      if (this.memberInfo.myclaims && !this.memberInfo.myclaims.clmICN) {
        this.showClaimsDrupal = true;
        this.getDrupalContent(this.constantsService.drupalClaimsUrl).subscribe(response => {
          this.claimsData = response[0];
        });
      }
    }
  }

  getDrupalContent(url): Observable<any> {
    return this.http.get(url).pipe(map(response => this.transformCarouselResponse(response)));
  }

  stopEventPropagation(event) {
    event.stopPropagation();
  }

  showDoctorDetails() {
    sessionStorage.setItem('providerName', this.memberInfo.mydoctors.visitPrvName);
    sessionStorage.setItem('providerNumber', this.memberInfo.mydoctors.visitPrvNum);
    if (this.memberInfo && this.memberInfo.mydoctors && this.memberInfo.mydoctors.visitDependentId) {
      sessionStorage.setItem('docDependentId', this.memberInfo.mydoctors.visitDependentId);
    }
    this.router.navigate([`/my-doctor/details`]);
  }

  handleMyFinancialClick() {
    if (this.isRegisteredUser) {
      this.router.navigate(['register/register-detail']);
    }
  }

  rateTheAppClick() {
    this.appRate.preferences.storeAppURL = {
      ios: '937789998',
      android: `market://details?id=${this.appVersion.getPackageName() || 'com.bcbsma.myblueredesign'}&hl=en_US`
    };
    this.appRate.promptForRating(true);
  }

  openSmartShopper() {
    if (this.checkSmartShopperUser(this.postLoginInfo)) {
      this.ssoService.openSSO('fad');
    }
  }

  navigatePharmacyLink(item: PharmacyLinkType) {
    if (item.isSSO && this.isAuthenticatedUser) {
      this.ssoService.openSSO(item.ssoType);
    } else if (item.isExternal) {
      this.iabService.create(item.url);
    } else {
      this.router.navigateByUrl(item.url);
    }
  }

  openFitnessURL() {
    if (this.isFitnessEnabled) {
      this.navCtrl.navigateForward('/fitness-and-weightloss');
    } else {
      window.open('https://myblue.bluecrossma.com/health-plan/fitness-reimbursement-weight-loss', '_blank');
    }
  }

  openWellnessRewardsProgram() {
    if (this.iswellnessRewardsProgramUser) {
      this.ssoService.openSSO('wellnessRewardsProgram_VP');
    }
  }

  goToVerify() {
    this.router.navigateByUrl('register/register-detail');
  }

  goToLogin() {
    this.router.navigateByUrl('login');
  }

  goToRegistration() {
    this.router.navigateByUrl('register');
  }

  getSearchResults() {
    console.log(true);
    if (this.searchForm.valid) {
      if (this.searchablesCpcs?.length) {
        this.keyword = this.searchForm.value.keyword.trim();
        this.searchForm.reset();
        this.store.dispatch(new Navigate(['/search/' + this.keyword]));
      }
    }
  }

  search() {
    this.store.dispatch(new Search(this.keyword));
  }


  ngOnDestroy(): void {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();

    if (this.backButtonSubscription) {
      this.backButtonSubscription.unsubscribe();
    }
  }

  // get footer links
  public setFooterLinks(): void {
    if (!this.footerService.footerLinksData) {
      this.footerService.getFooterLinks().subscribe(footerdata => {
        if (footerdata && footerdata.length) {
          this.footerLinks = footerdata;
          this.footerService.footerLinksData = footerdata;
        }
      });
    } else {
      this.footerLinks = this.footerService.footerLinksData;
    }
  }

  openUrlinNewWindow(url) {
    if (url) {
      window.open(url, '_blank');
    }
  }

  // get multiLanguage Footer Content MultiLingualFooterModel
  public setMultiLanguageFooter(): void {
    if (!this.footerService.multiLingualFooterData) {
      this.footerService.getMultiLingualFooter().subscribe(data => {
        if (data && data.length) {
          this.footerService.multiLingualFooterData = data;
          this.langTranslation = data;
          this.multiLingualFooter = this.langTranslation.find(lang => {
            return Object.values(lang).includes('English') ? lang : '';
          });
          this.langFooterText = this.multiLingualFooter.footertext;
        }
      });
    } else {
      this.langTranslation = this.footerService.multiLingualFooterData;
      this.multiLingualFooter = this.langTranslation.find(lang => {
        return Object.values(lang).includes('English') ? lang : '';
      });
      this.langFooterText = this.multiLingualFooter.footertext;
    }
  }

  // get selected Language for Footer Text
  public selectLang(link) {
    this.langFooterText = link.Footertext;
  }

  //recommended for you
  getRecommendedList() {
    this.homeService.getRecommendedForYouContent().subscribe(data => {
      this.recommendedForYouContent = data;
    });
  }
  openRecommendedLink(url: string, internal: string) {
    if (url) {
      if (internal != null && internal.toLowerCase() !== 'true') {
        window.open(url, '_blank');
      } else {
        this.internalRecommendedLink = url.split('/')[3];
        this.router.navigate(['/' + this.internalRecommendedLink]);
      }
    }
  }

  promoClick(evt) {
    const href = evt.target.getAttribute('href');
    if (href) {
      evt.preventDefault();
      this.router.navigate([href]);
    }
  }
}
