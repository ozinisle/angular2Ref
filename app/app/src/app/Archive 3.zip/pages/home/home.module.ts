import { NgModule } from '@angular/core';
import { FormsModule , ReactiveFormsModule} from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { AlertsModule } from '@app/components/alerts/alerts.module';
import { DeductibleModule } from '@app/components/deductible/deductible.module';
import { DeductiblesListModule } from '@app/components/deductibles-list/deductibles-list.module';
import { FinancialModule } from '@app/components/financial/financial.module';
import { FinancialsListModule } from '@app/components/financials-list/financials-list.module';
import { PromoCarouselModule } from '@app/components/promo/promo-carousel/promo-carousel.module';
import { PromoImagesModule } from '@app/components/promo/promo-images/promo-images.module';
import { SundaySkyVideoModule } from '@app/components/sunday-sky-video/sunday-sky-video.module';
import { CamelCaseModule } from '@app/pipes/camelcase/camel-case.module';
import { CasingForFilterModule } from '@app/pipes/casingForFilter/casing-for-filter.module';
import { ClaimIdModule } from '@app/pipes/claim-id/claim-id.module';
import { AppRate } from '@ionic-native/app-rate/ngx';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { NgxMaskModule } from 'ngx-mask';
import { SharedModule } from '../../shared/shared.module';
import { HomePageComponent } from './home-page.component';
import { HomeResolver } from './home.resolver';

const routes: Routes = [
  {
    path: '',
    component: HomePageComponent
  }
];

@NgModule({
  imports: [
    SharedModule,
    RouterModule.forChild(routes),
    DeductibleModule,
    AlertsModule,
    PromoCarouselModule,
    PromoImagesModule,
    CamelCaseModule,
    NgxMaskModule,
    CasingForFilterModule,
    ClaimIdModule,
    FinancialsListModule,
    DeductiblesListModule,
    FinancialModule,
    SundaySkyVideoModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [InAppBrowser, AppRate, HomeResolver],
  declarations: [HomePageComponent]
})
export class HomePageModule {}
