import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { MYBLUE } from '@app/app.constants';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Store } from '@ngxs/store';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { ClearState, SetLoader } from '../store/actions/app.actions';
import { AppSelectors } from '../store/selectors/app.selectors';
import { decryptPayload } from '../utils/app.utils';

@Injectable({ providedIn: 'root' })
export class HttpResponseInterceptor implements HttpInterceptor {
  @SelectSnapshot(AppSelectors.getAccessToken) token: string;
  @SelectSnapshot(AppSelectors.getCryptoToken) cryptoToken: any;

  constructor(private store: Store, private router: Router) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(
      map((event: HttpEvent<any>) => {
        if (event instanceof HttpResponse) {
          if (event.body.errormessage && event.status !== 200) {
            throw new HttpErrorResponse({
              error: event.body.errormessage,
              headers: event.headers,
              status: 500,
              statusText: 'ERROR',
              url: event.url
            });
          } else if (event.body.message || event.body.algmsg || event.body.heqmsg || event.body.lnmessage || event.body.ssomsg) {
            let decryptedBody = {...event.body};

            if (event.body.message) {
              decryptedBody = decryptPayload(event.body.message, this.cryptoToken);
            }
            if (event.body.algmsg) {
              decryptedBody.algmsg = decryptPayload(event.body.algmsg, this.cryptoToken);
            }
            if (event.body.heqmsg) {
              decryptedBody.heqmsg = decryptPayload(event.body.heqmsg, this.cryptoToken) ;
            }
            if (event.body.lnmessage) {
              decryptedBody.lnmessage = decryptPayload(event.body.lnmessage, this.cryptoToken) ;
            }
            if (event.body.ssomsg) {
              decryptedBody.ssomsg = decryptPayload(event.body.ssomsg, this.cryptoToken) ;
            }

            // MYBLUE.log('RESPONSE ' + JSON.stringify(decryptedBody, null, 2));
            return event.clone({
              body: decryptedBody
            });
          }
        }

        return event;
      }),
      catchError((error: HttpErrorResponse) => {
        MYBLUE.error('RESPONSE INTERCEPTOR ERROR: ', JSON.stringify(error, null, 2));
        this.store.dispatch(new SetLoader(false));

        if (error.status === 401) {
          this.store.dispatch(new ClearState(this.router.url !== '/login'));
        }
        return throwError(error);
      })
    );
  }
}
