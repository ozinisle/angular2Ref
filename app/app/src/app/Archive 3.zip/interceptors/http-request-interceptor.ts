import { HttpEvent, HttpHandler, HttpHeaders, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable } from 'rxjs';
import { v4 as uuid } from 'uuid';
import { AppSelectors } from '../store/selectors/app.selectors';
import { encryptPayload } from '../utils/app.utils';

@Injectable({
  providedIn: 'root'
})
export class TokenInterceptorService implements HttpInterceptor {
  @SelectSnapshot(AppSelectors.getAccessToken) token: string;
  @SelectSnapshot(AppSelectors.getCryptoToken) cryptoToken: any;

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (request.url.includes('verifyfpuser') || request.url.includes('verifyfunuser') || request.url.includes('verifyfunaccesscode')) {
      const newHeaders = new HttpHeaders({
        'Content-Type': 'application/json',
        uitxnid: 'APP_v5.0_' + uuid()
      });

      // MYBLUE.log('REQUEST ' + JSON.stringify(request, null, 2));
      const encryptedBody = encryptPayload(request.body, this.cryptoToken, false);
      const authRequest = request.clone({ headers: newHeaders, body: encryptedBody });

      return next.handle(authRequest);
    } else {
      if (this.token && request.url.includes('refreshtoken')) {
        const newHeaders = new HttpHeaders({
          'Content-Type': 'application/x-www-form-urlencoded',
          Authorization: 'Bearer ' + this.token,
          uitxnid: 'APP_v5.0_' + uuid()
        });
        const authRequest = request.clone({ headers: newHeaders });
        return next.handle(authRequest);
      } else if (this.token && (request.url.includes('getpreferences') || request.url.includes('getprogramgroups'))) {
        const newHeaders = new HttpHeaders({
          Authorization: `Bearer ${this.token}`,
          'Content-Type': 'application/json',
          uitxnid: 'APP_v5.0_' + uuid(),
          'Release-Version': 'D2'
        });
        const encryptedBody = encryptPayload(request.body, this.cryptoToken, false);
        const authRequest = request.clone({ headers: newHeaders, body: encryptedBody });

        return next.handle(authRequest);
      } else if (request.method === 'POST' && !request.url.endsWith('memberlogin') && !request.url.endsWith('registermem') && !request.url.includes('sdkmutualauth')) {
        if (request.body instanceof FormData) {
          const newHeaders = new HttpHeaders({
            Authorization: `Bearer ${this.token}`,
            uitxnid: 'APP_v5.0_' + uuid()
          });
          const authRequest = request.clone({ headers: newHeaders, body: request.body });
          return next.handle(authRequest);
        } else {
          const newHeaders = new HttpHeaders({
            Authorization: `Bearer ${this.token}`,
            'Content-Type': 'application/json',
            uitxnid: 'APP_v5.0_' + uuid()
          });
          const encryptedBody = encryptPayload(request.body, this.cryptoToken, false);
          const authRequest = request.clone({ headers: newHeaders, body: encryptedBody });

          return next.handle(authRequest);
        }
      } else if (request.url.includes('sdkmutualauth')) {
        const newHeaders = new HttpHeaders({
          Authorization: `Bearer ${this.token}`,
          'Content-Type': 'application/json',
           uitxnid: 'APP_v5.0_' + uuid()
        });
        const authRequest = request.clone({ headers: newHeaders });
        return next.handle(authRequest);
      } else if (request.url.endsWith('memberlogin')) {
        const newHeaders = new HttpHeaders({
          'Content-Type': 'application/json',
           uitxnid: 'APP_v5.0_' + uuid()
        });
        const authRequest = request.clone({ headers: newHeaders });
        return next.handle(authRequest);
      } else {
        return next.handle(request);
      }
    }
  }
}
