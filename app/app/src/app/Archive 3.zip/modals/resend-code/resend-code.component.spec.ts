import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { ResendCodeComponent } from './resend-code.component';
import { ModalController, IonContent, IonicModule } from '@ionic/angular';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NgxsModule } from '@ngxs/store';
import { RouterTestingModule } from '@angular/router/testing';

describe('ResendCodeComponent', () => {
  let component: ResendCodeComponent;
  let fixture: ComponentFixture<ResendCodeComponent>;

  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['dismiss']);

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [IonicModule, HttpClientTestingModule, RouterTestingModule, NgxsModule.forRoot()],
      providers: [
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        },
        IonContent
      ],
      declarations: [ResendCodeComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResendCodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
