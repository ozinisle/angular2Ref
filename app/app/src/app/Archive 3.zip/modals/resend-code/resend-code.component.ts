import { Component } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { AlertService } from '@app/services/alert.service';
import { ConstantsService } from '@app/services/constants.service';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { MyAccountService } from '@app/pages/my-account/my-account.service';
import { MY_ACCOUNT_CONSTANTS } from '@app/pages/my-account/my-account.constants';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AppService } from '@app/services/app.service';

@Component({
  selector: 'app-resend-code',
  templateUrl: './resend-code.component.html',
  styleUrls: ['./resend-code.component.scss']
})
export class ResendCodeComponent {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  constructor(
    private alertService: AlertService,
    private constants: ConstantsService,
    private appService: AppService,
    private myaccountservice: MyAccountService,
    public modalController: ModalController
  ) {}

  closeScreen() {
    this.modalController.dismiss({
      dismissed: true
    });
  }
  getCommId(): string {
    let commId;
    const funresponse = JSON.parse(sessionStorage.getItem('fun.funverifyuserResponse'));
    const fpresponse = JSON.parse(sessionStorage.getItem('fpw.fpverifyuserResponse'));
    const isValidRes = funresponse || fpresponse;
    if (isValidRes) {
      if (funresponse) {
        commId = funresponse.commType === 'MOBILE' ? this.useridin : funresponse.commValue;
      } else if (fpresponse) {
        commId = fpresponse.commType === 'MOBILE' ? this.useridin : fpresponse.commValue;
      } else {
        commId = this.useridin;
      }
    } else {
      commId = this.useridin;
    }
    return commId;
  }

  sendAccessCodeFUN() {
    this.myaccountservice.sendfunaccesscode().subscribe(res => {
      if (res['result'] === '0' || res['result'] === 0) {
        this.modalController.dismiss({
          dismissed: true
        });
        this.alertService.clearError();
        const userId = this.getCommId();
        const numberRegEx = new RegExp('^[0-9]{10}');
        return numberRegEx.test(userId)
          ? this.alertService.setAlert(
              MY_ACCOUNT_CONSTANTS.VerificationMsgSuccessForMobile,
              MY_ACCOUNT_CONSTANTS.Success,
              AlertType.Success
            )
          : this.alertService.setAlert(MY_ACCOUNT_CONSTANTS.VerificationResentMsgSuccess, MY_ACCOUNT_CONSTANTS.Success, AlertType.Success);
      } else {
        if (res['displaymessage']) {
          this.appService.handleError(res, this.constants.displayMessage);
        } else if (res['errormessage']) {
          this.appService.handleError(res, this.constants.displayMessage, true);
        } else {
          this.alertService.clearError();
          this.alertService.setAlert(MY_ACCOUNT_CONSTANTS.VerificationResentMsgSuccess, MY_ACCOUNT_CONSTANTS.Success, AlertType.Success);
        }
      }
    });
  }
}
