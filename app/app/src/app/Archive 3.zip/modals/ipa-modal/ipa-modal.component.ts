import { Component, OnInit } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { SetSelectedPlan } from '@app/store/actions/app.actions';
import { Select, Store } from '@ngxs/store';
import { ModalController, PopoverController } from '@ionic/angular';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { MemberPlan } from '@app/models/member-plan.model';
import { Observable } from 'rxjs';

@Component({
  selector: 'ipa-modal',
  templateUrl: './ipa-modal.component.html',
  styleUrls: ['./ipa-modal.component.scss']
})
export class IPAModalComponent implements OnInit {

  @SelectSnapshot(AppSelectors.isAuthenticatedUser) isAuthenticatedUser: string;
  @Select(AppSelectors.getSelectedPlan) selectedPlan$: Observable<MemberPlan>;
  @SelectSnapshot(AppSelectors.getSelectedPlan) selectedPlan: MemberPlan;
  @SelectSnapshot(AppSelectors.getPlansList) memberPlans: MemberPlan[];

  currentPlanInSelection: any;
  isFormSubmitted: false;
  switchPlanForm: FormGroup;
  showIPAForm = true;
  selectedPlanCurrent: any;
  hasOtherPlans = false;
  defaultSelectedcardMemId: string;
  selectedcardMemId: string;
  selectedRadioButton: any;

  constructor(
    private store: Store,
    private modalController: ModalController,
    private popoverController: PopoverController,
    private router: Router
  ) {}

  ngOnInit() {
    this.hasOtherPlans = this.memberPlans.some((data) => {
      return (data['activePlan'] === 'false' || !data['activePlan']) || (data['defaultPlan'] === 'false' || !data['defaultPlan']);
    });
  }

  radioGroupChange(event) {
    this.selectedcardMemId = event.detail.value;
  }

  async closeModal() {
    await this.modalController.dismiss();
  }

  onPlanChange(selectedPlan) {
    this.selectedPlanCurrent = selectedPlan;
  }

  get isSwitchPlanButtonDisabled() {
    return this.selectedPlanCurrent ?
       this.selectedPlanCurrent.cardMemId === this.selectedPlan.cardMemId || this.selectedPlanCurrent.futurePlan === 'true'
      : true;
  }

  planSelected(event) {
    this.popoverController.getTop().then((popover) => {
      if (popover) {
        popover.dismiss();
      }
    });
    this.store.dispatch(new SetSelectedPlan(this.selectedPlanCurrent, this.router.url));
    this.closeModal();
  }
}
