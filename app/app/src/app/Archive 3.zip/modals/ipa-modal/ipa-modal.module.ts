import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { AlertsModule } from '@app/components/alerts/alerts.module';
import { AppControlMessagesModule } from '@app/components/app-control-messages/app-control-messages.module';
import { ReactiveFormsModule } from '@angular/forms';
import { NgxMaskModule } from 'ngx-mask';
import { TextMaskModule } from 'angular2-text-mask';
import { AutofocusDirectiveModule } from '@app/directives/autofocus/autofocus.directive.module';
import { NumberOnlyDirectiveModule } from '@app/directives/number-only/number-only.directive.module';
import { IPAModalComponent } from './ipa-modal.component';
import { PreloadAllModules, RouterModule } from '@angular/router';
import { rootRoutes } from '../../app-routing.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  imports: [
    CommonModule,
    IonicModule,
    AlertsModule,
    AppControlMessagesModule,
    ReactiveFormsModule,
    NgxMaskModule,
    TextMaskModule,
    AutofocusDirectiveModule,
    NumberOnlyDirectiveModule,
    FontAwesomeModule,
    RouterModule.forRoot(rootRoutes, { onSameUrlNavigation: 'reload', preloadingStrategy: PreloadAllModules }),
  ],
  declarations: [IPAModalComponent]
})
export class IPAModalModule {}
