import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { IonicModule, ModalController } from '@ionic/angular';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';

import { NgxsModule, Store } from '@ngxs/store';
import { IPAModalComponent } from './ipa-modal.component';


describe('IPAModalComponent', () => {
  let component: IPAModalComponent;
  let fixture: ComponentFixture<IPAModalComponent>;
  let store: Store;
  let modalController: ModalController;
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ IPAModalComponent ],
      imports: [CommonModule, RouterTestingModule, IonicModule.forRoot(), NgxsSelectSnapshotModule.forRoot(), NgxsModule.forRoot([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
    store = TestBed.inject(Store);
    modalController = TestBed.inject(ModalController);
    fixture = TestBed.createComponent(IPAModalComponent);
    spyOn(store, 'selectSnapshot').and.returnValue([{cardMemId: '123455678',
        cardMemSuffix: 'abd',
        activePlan: 'false',
        defaultPlan: 'false',
        futurePlan: 'false',
        planType: 'Medical',
        planName: 'XXXX',
        planEffectiveDate: '01/01/2021',
        planEndDate: '12/31/2021'}]);
    component = fixture.componentInstance;
    component.selectedPlanCurrent = {};
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  xit('should call modal close', () => {
    const spyStore = spyOn(modalController, 'dismiss').and.callThrough();
    component.closeModal();
    expect(spyStore).toHaveBeenCalled();
  });
  it('should call Set Selected Plan Action', () => {
    const spyStore = spyOn(store, 'dispatch').and.callThrough();
    component.planSelected(undefined);
    expect(spyStore).toHaveBeenCalled();
  });
});
