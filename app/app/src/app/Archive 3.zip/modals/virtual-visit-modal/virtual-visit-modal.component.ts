import { Location } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { PopoverController } from '@ionic/angular';

@Component({
  selector: 'app-virtual-visit-modal',
  templateUrl: './virtual-visit-modal.component.html',
  styleUrls: ['./virtual-visit-modal.component.scss'],
})
export class VirtualVisitModalComponent implements OnInit {
  @Input() errorText: string;
  constructor(
    private popoverController: PopoverController,
    private location: Location,
  ) { }

  ngOnInit() {
  }

  close() {
    this.popoverController.dismiss();
    this.location.back();
  }

}
