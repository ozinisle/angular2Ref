import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VirtualVisitModalComponent } from './virtual-visit-modal.component';
import { IonicModule } from '@ionic/angular';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  declarations: [VirtualVisitModalComponent],
  imports: [CommonModule, IonicModule, FontAwesomeModule],
  exports: [VirtualVisitModalComponent]
})
export class VirtualVisitModalModule {}
