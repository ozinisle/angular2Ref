import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { ConsentModalComponent } from './consent-modal.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  declarations: [ConsentModalComponent],
  imports: [CommonModule, IonicModule, FontAwesomeModule]
})
export class ConsentModalModule {}
