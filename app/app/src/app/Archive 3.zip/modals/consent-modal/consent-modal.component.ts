import { Component } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { ProfileSelectors } from '@app/store/selectors/profile.selectors';
import { ModalController } from '@ionic/angular';
import { Store, Select } from '@ngxs/store';
import { SubmitConsent } from '@app/store/actions/preference.action';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-consent-modal',
  templateUrl: './consent-modal.component.html',
  styleUrls: ['./consent-modal.component.scss']
})
export class ConsentModalComponent {
  showSuccess = false;
  showFailure = false;
  isConsentScrolled = false;

  @Select(ProfileSelectors.modalSection) modalSection$: Observable<string>;
  @SelectSnapshot(ProfileSelectors.getConsentResponse) consentResponse: any;

  constructor(private modalCtrl: ModalController, private store: Store) {}

  onConsentScrolled($event) {
    const { target } = $event;
    if (target.offsetHeight + target.scrollTop >= target.scrollHeight) {
      this.isConsentScrolled = true;
    }
  }

  submitConsent() {
    this.store.dispatch(new SubmitConsent(true));
  }

  dismissModal() {
    this.modalCtrl.dismiss({ dismiss: true });
  }
}
