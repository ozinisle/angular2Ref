import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NotifyDemographicModalDisplayed } from '@app/store/actions/profile.action';
import { ModalController } from '@ionic/angular';
import { Store } from '@ngxs/store';
import { PreferenceService } from '@app/services/preference.service';

@Component({
  selector: 'app-about-me-modal',
  templateUrl: './about-me-modal.component.html',
  styleUrls: ['./about-me-modal.component.scss']
})
export class AboutMeModalComponent implements OnInit {
  public showRELAfterPrefModal = false;

  constructor(
    private router: Router,
    private modalController: ModalController,
    private store: Store,
    private preferenceService: PreferenceService
  ) { }

  ngOnInit() {
    this.store.dispatch(new NotifyDemographicModalDisplayed());
    this.showRELAfterPrefModal = this.preferenceService.showRELAfterPrefModal;
  }

  navigateToAboutMe() {
    this.modalController.dismiss();
    this.preferenceService.showRELAfterPrefModal = false;
    sessionStorage.setItem('toggleAboutMe', 'true');
    this.router.navigate(['/myprofile/about-me']);
  }

  close() {
    this.modalController.dismiss();
    this.preferenceService.showRELAfterPrefModal = false;
    this.preferenceService.phoneNumberVerificationSkipped = false;
  }

}
