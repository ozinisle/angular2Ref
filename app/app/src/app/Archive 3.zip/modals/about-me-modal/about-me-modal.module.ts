import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { AboutMeModalComponent } from './about-me-modal.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  declarations: [AboutMeModalComponent],
  imports: [CommonModule, IonicModule, FontAwesomeModule]
})
export class AboutMeModalModule {}
