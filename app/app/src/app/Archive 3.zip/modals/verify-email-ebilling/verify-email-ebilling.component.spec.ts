import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NgxsModule } from '@ngxs/store';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { VerifyEmailEbillingComponent } from './verify-email-ebilling.component';
import { IabService } from '@app/services/iab.service';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { AlertService } from '@app/services/alert.service';
import { ModalController, AngularDelegate, NavParams, IonicModule } from '@ionic/angular';
import { AlertsComponent } from '@app/components/alerts/alerts.component';

class MockNavParams {
  data = {};

  get(param) {
    return this.data[param];
  }
}

describe('JumpScreen Component Page', () => {
  let component: VerifyEmailEbillingComponent;
  let fixture: ComponentFixture<VerifyEmailEbillingComponent>;
  const modalSpy = jasmine.createSpyObj('Modal', ['present']);
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);
  modalCtrlSpy.create.and.callFake(() => {
    return modalSpy;
  });
  let modalController;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [IonicModule, HttpClientTestingModule, RouterTestingModule, NgxsModule.forRoot([]), NgxsSelectSnapshotModule.forRoot()],
      providers: [
        IabService,
        InAppBrowser,
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        },
        { provide: NavParams, useClass: MockNavParams },
        AlertService,
        ModalController,
        AngularDelegate
      ],
      declarations: [VerifyEmailEbillingComponent, AlertsComponent]
    }).compileComponents();
    modalController = TestBed.get(ModalController);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VerifyEmailEbillingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('Constructor', () => {
    beforeEach(() => {
      fixture = TestBed.createComponent(VerifyEmailEbillingComponent);
      component = fixture.componentInstance;
    });
    it('should create', () => {
      expect(component).toBeTruthy();
    });
  });
  describe('should check component methods', () => {
    it('should check modal controller method after dismiss method call', () => {
      const spy = spyOn(modalController, 'dismissModal').and.returnValue(null);
      component.dismissModal();
      expect(spy).toHaveBeenCalled();
    });

    it('should check modal controller method after closeModal method call', () => {
      const spy = spyOn(modalController, 'dismissModal').and.returnValue(null);
      component.dismissModal();
      expect(spy).toHaveBeenCalled();
    });
  });
});
