import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { VerifyEmailEbillingComponent } from '@app/modals/verify-email-ebilling/verify-email-ebilling.component';
import { AlertsModule } from '@app/components/alerts/alerts.module';
import { AppControlMessagesModule } from '@app/components/app-control-messages/app-control-messages.module';
import { ReactiveFormsModule } from '@angular/forms';
import { NgxMaskModule } from 'ngx-mask';
import { TextMaskModule } from 'angular2-text-mask';
import { AutofocusDirectiveModule } from '@app/directives/autofocus/autofocus.directive.module';
import { NumberOnlyDirectiveModule } from '@app/directives/number-only/number-only.directive.module';

@NgModule({
  imports: [
    CommonModule,
    IonicModule,
    AlertsModule,
    AppControlMessagesModule,
    ReactiveFormsModule,
    NgxMaskModule,
    TextMaskModule,
    AutofocusDirectiveModule,
    NumberOnlyDirectiveModule
  ],
  declarations: [VerifyEmailEbillingComponent]
})
export class VerifyEmailEbillingModule {}
