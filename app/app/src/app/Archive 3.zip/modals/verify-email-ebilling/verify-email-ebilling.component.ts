import { Component, ElementRef, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { MYBLUE } from '@app/app.constants';
import { AuthToken } from '@app/models/auth-token.model';
import { PostLoginModel } from '@app/models/post-login.model';
import { MY_ACCOUNT_CONSTANTS } from '@app/pages/my-account/my-account.constants';
import { FormGroupControlsModel, VerifyAccessCodeInputValidationResultModel } from '@app/pages/registration/models/registration.models';
import { AlertService } from '@app/services/alert.service';
import { ProfileService } from '@app/services/profile.service';
import { ValidationService } from '@app/services/validation.service';
import { ShowAboutMeModal } from '@app/store/actions/profile.action';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { PreferenceSelectors } from '@app/store/selectors/preference.selectors';
import { ProfileSelectors } from '@app/store/selectors/profile.selectors';
import { ModalController } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Select, Store } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';


@Component({
  templateUrl: './verify-email-ebilling.component.html',
  styleUrls: ['./verify-email-ebilling.component.scss']
})
export class VerifyEmailEbillingComponent implements OnInit {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getUserEmailAddress) emailAddress: string;
  @SelectSnapshot(AppSelectors.getMemProfile ) memProfile: any;
  @SelectSnapshot(ProfileSelectors.getProfileInfo) profile: any;
  @Select(ProfileSelectors .getMaskedVerifiable) maskedVerifiable$: Observable<string>;
  @Select(ProfileSelectors.getVerifyCategory) verifyCategory$: Observable<string>;
  @Select(ProfileSelectors.getPhoneVerification) phoneVerification$: Observable<boolean>;
  @SelectSnapshot(PreferenceSelectors.showRELModal) showRELModal: boolean;
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: AuthToken;
  @SelectSnapshot(AppSelectors.getPostLoginInfo) postLoginInfo: PostLoginModel;


  @ViewChild('accesscode1') accesscode1: ElementRef;
  @ViewChild('accesscode2') accesscode2: ElementRef;
  @ViewChild('accesscode3') accesscode3: ElementRef;
  @ViewChild('accesscode4') accesscode4: ElementRef;
  @ViewChild('accesscode5') accesscode5: ElementRef;
  @ViewChild('accesscode6') accesscode6: ElementRef;

  @Output() processCompleteEmitter: EventEmitter<boolean> = new EventEmitter<boolean>();

  verifyaccesscodeForm: FormGroup;
  isFormSubmitted: boolean;
  shiftKeyDown = false;
  accesscodeMask: Array<any>;
  location: string;
  maskedVerifiable: string;
  verifyCategory = '';
  isMyPillPackFlag = false;
  destroy$ = new Subject<void>();
  initialModalView: boolean;
  accessCodeSent: boolean;
  accessCodeSuccess: boolean;
  accessCodeError: boolean;
  accessCodeResent: boolean;
  accessCodeResentandEntered: boolean;
  phoneNumber: any;
  isEmailVerified: boolean;
  accessCodeEntered: boolean;
  registeredUserOnly = false;
  public verifyaccesscodeFormValidator: VerifyAccessCodeInputValidationResultModel = new VerifyAccessCodeInputValidationResultModel();

  constructor(
    private modalController: ModalController,
    private fb: FormBuilder,
    private validationService: ValidationService,
    private alertService: AlertService,
    private profileService: ProfileService,
    private store: Store
    ) {
    this.verifyaccesscodeForm = this.fb.group(
      {
        accesscode1: ['', [Validators.required]],
        accesscode2: ['', [Validators.required]],
        accesscode3: ['', [Validators.required]],
        accesscode4: ['', [Validators.required]],
        accesscode5: ['', [Validators.required]],
        accesscode6: ['', [Validators.required]]
      },
      {
        validator: this.validationService.accessCodeValidator()
      }
    );

    this.verifyaccesscodeForm.valueChanges.subscribe(accesscodes => {
      Object.keys(accesscodes).forEach((key, index) => {
        const itemValue = (accesscodes[key] ? accesscodes[key] : '').toString();
        if (itemValue.length > 1) {
          let currentIndex = index;
          itemValue.split('').forEach(character => {
            if (currentIndex < 6) {
              if (!accesscodes['accesscode' + (currentIndex + 1)] || index === currentIndex) {
                const accesscodekey = 'accesscode' + (currentIndex + 1);
                accesscodes[accesscodekey] = character;
                this.verifyaccesscodeForm.get(accesscodekey).setValue(character, { emitEvent: false });
                this[accesscodekey].nativeElement.focus();
              }
              currentIndex++;
            }
          });
        }
      });
    });
    this.accesscodeMask = this.validationService.accesscodeMask;
    this.phoneNumber = this.memProfile.phoneNumber;
    this.accessCodeError = false;
  }


  ngOnInit() {
    const userRole = this.authToken.scopename;
    this.registeredUserOnly = ['REGISTERED-AND-VERIFIED'].includes(userRole);
    this.maskedVerifiable = sessionStorage.getItem('maskedVerify');
    this.verifyCategory = sessionStorage.getItem('maskedVerifyPhone') === 'Y' ? 'Mobile Number' : 'Email';
    this.maskedVerifiable = this.maskEmailId(this.profile.emailAddress);
    this.initialModalView = true;
    this.sendcommchlaccesscode(this.emailAddress, '', this.useridin).subscribe(res => {
      if (res['commChannelType'] === 'EMAIL') {
        MYBLUE.log('success');
      } else {
        MYBLUE.log('error');
      }
    },
    err => {
        MYBLUE.log('error', err);
    })
  };

  private sendcommchlaccesscode(emailAddress, phoneNumber, useridin) {
    return this.profileService.sendcommchlaccesscode(emailAddress, phoneNumber, useridin);
  }

  resetFormValue() {
    this.verifyaccesscodeForm.setValue({
      accesscode1: '',
      accesscode2: '',
      accesscode3: '',
      accesscode4: '',
      accesscode5: '',
      accesscode6: ''
    });
  }

  onSubmit() {
    this.isFormSubmitted = true;
    this.alertService.clearError();
    const accessCode = [
      this.verifyaccesscodeForm.value.accesscode1,
      this.verifyaccesscodeForm.value.accesscode2,
      this.verifyaccesscodeForm.value.accesscode3,
      this.verifyaccesscodeForm.value.accesscode4,
      this.verifyaccesscodeForm.value.accesscode5,
      this.verifyaccesscodeForm.value.accesscode6
    ].join('');

    if (this.verifyaccesscodeForm.valid) {
      this.verifyCommChannelAccessCode(accessCode, this.emailAddress, this.phoneNumber, this.useridin).subscribe(res => {
        if (res['result'] === '0') {
          this.accessCodeSuccess = true;
          this.initialModalView = false;
          this.accessCodeResent = false;
          } else {
            this.initialModalView = false;
            this.accessCodeError = true;
            this.accessCodeSuccess = false;
          }
      },
      err => {
        this.initialModalView = false;
        this.accessCodeError = true;
        this.accessCodeSuccess = false;
      });
      this.resetFormValue();
    }
  }

  verifyCommChannelAccessCode(accessCode, emailAddress, phoneNumber, useridin) {
    return this.profileService.VerifyCommChlAccCode(accessCode, emailAddress, phoneNumber, useridin);
  }

  maskEmailId(userId: string): string {
    const sentMailId = JSON.parse(sessionStorage.getItem('sendCodeRes'));
    userId = sentMailId && sentMailId['commChannel'] ? sentMailId['commChannel'] : userId;
    return userId
      ? userId.replace(/^(.{3})(.*)(@.*)$/, (_, firstCharacter, charToMasked, domain) => {
          return `${firstCharacter}${charToMasked.replace(/./g, '*')}${domain}`;
        })
      : userId;
  }


  resendCommChannelAccessCode() {
    this.sendcommchlaccesscode(this.emailAddress, this.phoneNumber, this.useridin).subscribe(res => {
      if (res['commChannelType'] === 'EMAIL') {
        this.resetFormValue()
          this.initialModalView = true;
          this.accessCodeResent = true;
          this.accessCodeError = false;
        } else {
          this.accessCodeError = true;
        }
    },
    err => {
      this.initialModalView = false;
      this.accessCodeError = true;
      this.accessCodeSuccess = false;
    })
  }

  resetModalForm() {
    this.initialModalView = true;
    this.accessCodeError = false;
    this.accessCodeResent = false;
    this.resetFormValue();
  }

  onKeyDown(event) {
    if (event.keyCode === 16) {
      // if shift key is pressed block it
      this.shiftKeyDown = true;
    }
    if (this.shiftKeyDown || !this.isValidKeyPressed(event)) {
      return false;
    }
  }

  onKeyUp(event, previousElement, nextElement) {
    if (this.shiftKeyDown) {
      if (event.keyCode === 16) {
        this.shiftKeyDown = false;
      }
      return false;
    }

    if (event && event.target['value'] === '' && !this.isValidKeyPressed(event)) {
      return false;
    }

    if ((event.key === 'Backspace' || event.which === 37 || event.key === 'ArrowLeft') && previousElement) {
      previousElement.focus();
    }
    if (
      (event.key === 'ArrowRight' ||
        event.which === 39 ||
        (event.which >= 48 && event.which <= 57) ||
        (event.which >= 96 && event.which <= 105)) &&
      nextElement
    ) {
      setTimeout(() => nextElement.focus(), 100);
    }
  }

  private isValidKeyPressed(event): boolean {
    const key = event.key;
    if (this.verifyaccesscodeForm.valid) {
      this.accessCodeEntered = true;
    }
    return (
      key === 'Backspace' ||
      key === 'ArrowLeft' ||
      key === 'ArrowRight' ||
      (event.keyCode >= 48 && event.keyCode <= 57) ||
      (event.keyCode >= 96 && event.keyCode <= 105)
    );
  }

  selectBox(event: any) {
    const elem = event.target as HTMLInputElement;
    elem.focus();
    elem.select();
  }
  
  splitAndPlacePastedValues(event, materialForm): boolean {
    event.preventDefault();
    let pastedData = '';
    if (event.clipboardData) {
      pastedData = event.clipboardData.getData('text/plain');
    } else if (window['clipboardData']) {
      pastedData = window['clipboardData'].getData('Text');
    }

    pastedData = pastedData.replace(/\D/g, '');

    let pastedCharArr = pastedData.split('');

    if (pastedCharArr.length > 6) {
      pastedCharArr = pastedCharArr.splice(0, 6);
    }

    const accessCodeFields: NodeListOf<Element> = document.querySelectorAll('input.access-code');
    Object.keys(materialForm.controls).forEach((controlName, controlIndex) => {
      const pastedNumber: string = pastedCharArr[controlIndex];
      if (pastedNumber) {
        const formInputControl: FormControl = materialForm.get(controlName);
        // focus method does not work as such in ie11. hence requires a timeout block as fix/workaround for the same
        setTimeout(() => {
          (accessCodeFields[controlIndex] as HTMLInputElement).focus();
          formInputControl.setValue(pastedNumber);
        }, 10);
      } else {
        return false;
      }
    });

    this.getMatFormClass(materialForm);
    return true;
  }

  public getMatFormClass(materialForm: FormGroup): VerifyAccessCodeInputValidationResultModel {
    this.verifyaccesscodeFormValidator = new VerifyAccessCodeInputValidationResultModel();
    const controls: FormGroupControlsModel = materialForm.controls;
    const control = MY_ACCOUNT_CONSTANTS.controls;
    const accessCode1 = controls[control.accessCode1];
    const accessCode2 = controls[control.accessCode2];
    const accessCode3 = controls[control.accessCode3];
    const accessCode4 = controls[control.accessCode4];
    const accessCode5 = controls[control.accessCode5];
    const accessCode6 = controls[control.accessCode6];

    if (!(accessCode1 && accessCode2 && accessCode3 && accessCode4 && accessCode5 && accessCode6)) {
      return this.verifyaccesscodeFormValidator;
    }

    const controlErrors: ValidationErrors =
      accessCode1.errors || accessCode2.errors || accessCode3.errors || accessCode4.errors || accessCode5.errors || accessCode6.errors;

    const allTouched: boolean =
      accessCode1.touched &&
      accessCode2.touched &&
      accessCode3.touched &&
      accessCode4.touched &&
      accessCode5.touched &&
      accessCode6.touched;

    const errorFlag: boolean = controlErrors ? true : !allTouched;

    const hasRequiredErrorFlags: boolean =
      (accessCode1.errors && accessCode1.errors.required) ||
      (accessCode2.errors && accessCode2.errors.required) ||
      (accessCode3.errors && accessCode3.errors.required) ||
      (accessCode4.errors && accessCode4.errors.required) ||
      (accessCode5.errors && accessCode5.errors.required) ||
      (accessCode6.errors && accessCode6.errors.required);

    this.verifyaccesscodeFormValidator.isError = errorFlag;
    this.verifyaccesscodeFormValidator.hasErrors = hasRequiredErrorFlags;
  }
  dismissModal() {
    this.modalController.dismiss();
    if (this.postLoginInfo.showDemographicModel) {
      this.store.dispatch(new ShowAboutMeModal());
    }
  }
}
