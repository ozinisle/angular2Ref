import { Component, OnInit } from '@angular/core';
import { ModalController, NavParams } from '@ionic/angular';
import { Select } from '@ngxs/store';
import { FitnessSelectors } from '../../store/selectors/fitness.selectors';
import { Observable } from 'rxjs';
import { CERTIFICATIONS_ACKNOWLEDGEMENTS } from '../../pages/fwb/constants/fitness.constants';

@Component({
  selector: 'app-info-modal',
  templateUrl: './info-modal.component.html',
  styleUrls: ['./info-modal.component.scss']
})
export class InfoModalComponent implements OnInit {
  certificationstext = CERTIFICATIONS_ACKNOWLEDGEMENTS;

  @Select(FitnessSelectors.getEligibilityStatement) statement$: Observable<string>;

  title: string;

  constructor(private modalController: ModalController, private params: NavParams) {}

  ngOnInit() {
    this.title = this.params.data.header;
    if (this.title === 'Eligibility') {
    }
  }

  close() {
    this.modalController.dismiss();
  }
}
