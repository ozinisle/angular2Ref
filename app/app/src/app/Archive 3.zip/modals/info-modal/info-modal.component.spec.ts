import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { InfoModalComponent } from './info-modal.component';
import { IonicModule, ModalController, NavParams } from '@ionic/angular';

class MockNavParams {
  data = {};

  get(param) {
    return this.data[param];
  }
}

describe('InfoModalComponent', () => {
  let component: InfoModalComponent;
  let fixture: ComponentFixture<InfoModalComponent>;
  const modalSpy = jasmine.createSpyObj('Modal', ['present']);
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);
  modalCtrlSpy.create.and.callFake(() => {
    return modalSpy;
  });

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [IonicModule],
      providers: [
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        },
        { provide: NavParams, useClass: MockNavParams }
      ],
      declarations: [InfoModalComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InfoModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
