import { Component, OnInit } from '@angular/core';
import {ModalController, NavParams} from '@ionic/angular';

enum Status {
  Success = 'success',
  Error = 'error',
}

@Component({
  selector: 'app-file-upload-result-modal',
  templateUrl: './file-upload-result-modal.component.html',
  styleUrls: ['./file-upload-result-modal.component.scss'],
})
export class FileUploadResultModalComponent implements OnInit {

  title = 'something went wrong';
  subtitle = 'Try again';
  type: Status = Status.Success;

  status = Status;

  constructor(private modalController: ModalController, private navParams: NavParams) {
  }

  ngOnInit() {
    const myData = this.navParams.data;
    this.title = myData.title;
    this.subtitle = myData.subtitle;
    this.type = myData.type;
  }

  closeModal() {
    this.modalController.dismiss();
  }

  get buttonLabel(): string {
    return this.type === this.status.Error ? 'TRY AGAIN' : 'FINISH';
  }
}
