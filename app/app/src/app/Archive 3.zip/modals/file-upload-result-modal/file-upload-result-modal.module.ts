import { CommonModule } from '@angular/common';
import { FileUploadResultModalComponent } from '@app/modals/file-upload-result-modal/file-upload-result-modal.component';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { NgModule } from '@angular/core';
import { FontAwesomeLibraryModule } from '@app/fontawesome-library.module';

@NgModule({
  imports: [CommonModule, FontAwesomeLibraryModule, FormsModule, IonicModule],
  declarations: [FileUploadResultModalComponent]
})
export class FileUploadResultModalModule {}
