import { Component } from '@angular/core';
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { DatePipe, TitleCasePipe } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { IonicModule, ModalController, PopoverController, IonContent } from '@ionic/angular';
import { NgxsModule, Store } from '@ngxs/store';
import { SafePipeModule } from '@app/pipes/safe-html/safe-html.module';
import { AlertService } from '@app/services/alert.service';
import { ConstantsService } from '@app/services/constants.service';
import { ProfileService } from '@app/services/profile.service';
import { ValidationService } from '@app/services/validation.service';
import { PreferenceModalComponent } from './preference-modal.component';
import { NgxMaskModule } from 'ngx-mask';
import { TextMaskModule } from 'angular2-text-mask';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { AlertsComponent } from '@app/components/alerts/alerts.component';
import { PreferenceSelectionsModule } from '@app/components/preference-selections/preference-selections.module';
import { PreferenceVerifyChannelModule } from '@app/components/preference-verify-channel/preference-verify-channel.module';

@Component({ selector: 'test-blank', template: `` })
class BlankComponent {}

describe('PreferenceModalComponent', () => {
  let preferenceModalComponent: PreferenceModalComponent;
  let componentFixture: ComponentFixture<PreferenceModalComponent>;
  let store: Store;

  const modalSpy = jasmine.createSpyObj('Modal', ['present']);
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create', 'dismiss']);
  modalCtrlSpy.create.and.callFake(() => {
    return modalSpy;
  });
  modalCtrlSpy.dismiss.and.callFake(() => {});

  const popoverSpy = jasmine.createSpyObj('Popover', ['present']);
  const popoverCtrlSpy = jasmine.createSpyObj('PopoverController', ['create']);
  popoverCtrlSpy.create.and.callFake(() => {
    return popoverSpy;
  });

  const validationServiceSpy = jasmine.createSpyObj('ValidationService', ['accessCodeValidator']);
  validationServiceSpy.accessCodeValidator.and.callFake(() => {
    return true;
  });

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        IonicModule,
        FormsModule,
        NgxMaskModule.forRoot(),
        ReactiveFormsModule,
        RouterTestingModule.withRoutes([{ path: 'myprofile/communication-preferences', component: BlankComponent }]),
        HttpClientTestingModule,
        SafePipeModule,
        NgxsModule.forRoot([]),
        NgxMaskModule.forRoot(),
        TextMaskModule,
        NgxsSelectSnapshotModule.forRoot(),
        PreferenceSelectionsModule,
        PreferenceVerifyChannelModule
      ],
      declarations: [PreferenceModalComponent, AlertsComponent],
      providers: [
        ConstantsService,
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        },
        {
          provide: PopoverController,
          useValue: popoverCtrlSpy
        },
        DatePipe,
        TitleCasePipe,
        AlertService,
        ProfileService,
        ValidationService,
        IonContent
      ]
    }).compileComponents();
    store = TestBed.inject(Store);
  }));

  beforeEach(() => {
    componentFixture = TestBed.createComponent(PreferenceModalComponent);
    preferenceModalComponent = componentFixture.componentInstance;
    Object.defineProperty(preferenceModalComponent, 'programGroups', { writable: true });
    Object.defineProperty(preferenceModalComponent, 'profileInfo', { writable: true });
    Object.defineProperty(preferenceModalComponent, 'consentResponse', { writable: true });
    preferenceModalComponent.profileInfo = {
      emailAddress: 'joan.harris4@yopmail.com',
      phoneNumber: '2142342345',
      isVerifiedMobile: true,
      isVerifiedEmail: true,
      useridin: '',
      fullName: '',
      userState: '',
      dob: '',
      address1: '',
      address2: '',
      city: '',
      state: '',
      zip: '',
      phoneType: '',
      isEditableAddress: true,
      isDirectPay: true,
      isEmailOptedIn: true,
      isMobileOptedIn: true,
      hintQuestion: '',
      hintAnswer: '',
      gender: '',
      health: { allergies: [], conditions: [] },
      dependents: [],
      updatedEmailAddress: null,
      updatedPhoneNumber: null
    };
    preferenceModalComponent.ngOnInit();
    componentFixture.detectChanges();
  });

  it('should create', () => {
    expect(preferenceModalComponent).toBeTruthy();
  });

  it('should maskedVerifyPhone value Y should set verifyCategory to Phone Number ', () => {
    sessionStorage.setItem('maskedVerifyPhone', 'Y');
    preferenceModalComponent.ngOnInit();
    expect(preferenceModalComponent.verifyCategory).toEqual('Mobile Number');
  });

  it('should maskedVerifyPhone value N should set verifyCategory to Email ', () => {
    sessionStorage.setItem('maskedVerifyPhone', 'N');
    preferenceModalComponent.ngOnInit();
    expect(preferenceModalComponent.verifyCategory).toEqual('Email');
  });

  it('should maskedVerifyPhone Null should set verifyCategory to Email ', () => {
    sessionStorage.removeItem('maskedVerifyPhone');
    preferenceModalComponent.ngOnInit();
    expect(preferenceModalComponent.verifyCategory).toEqual('Email');
  });

  it('should verifyaccesscodeForm truthy ', () => {
    preferenceModalComponent.ngOnInit();
    expect(preferenceModalComponent.verifyaccesscodeForm).toBeTruthy();
  });

  it('should dismiss modal', () => {
    preferenceModalComponent.dismissModal();
    expect(modalCtrlSpy.dismiss).toHaveBeenCalled();
  });

  it('should navigateManageCommunication should dismiss modal', () => {
    preferenceModalComponent.navigatemanagecommunication();
    expect(modalCtrlSpy.dismiss).toHaveBeenCalled();
  });

  it('should resetFormValue should reset access code input fields', () => {
    preferenceModalComponent.resetFormValue();
    expect(preferenceModalComponent.verifyaccesscodeForm.value.accesscode1).toEqual('');
  });

  it('should call submitPrefernce', () => {
    const spy = spyOn(preferenceModalComponent.content, 'scrollToTop');
    preferenceModalComponent.submitPrefernce();
    expect(spy).toHaveBeenCalled();
    expect(preferenceModalComponent.submitPrefernce).toBeTruthy();
  });

  it('should verifyaccesscode invalid', () => {
    preferenceModalComponent.verifyAccessCode();
    expect(preferenceModalComponent.verifyaccesscodeForm.valid).toEqual(false);
  });

  it('should sendaccesscode should reset form', () => {
    spyOn(preferenceModalComponent, 'resetFormValue');
    componentFixture.detectChanges();
    preferenceModalComponent.sendAccessCode();
    expect(preferenceModalComponent.resetFormValue).toHaveBeenCalled();
  });

  it('should sendaccesscode should reset form', () => {
    spyOn(preferenceModalComponent, 'resetFormValue');
    componentFixture.detectChanges();
    preferenceModalComponent.sendAccessCode();
    expect(preferenceModalComponent.resetFormValue).toHaveBeenCalled();
  });

  it('should scroll toc', () => {
    const hostElement = componentFixture.nativeElement;
    componentFixture.detectChanges();
    const tocDiv: HTMLDivElement = hostElement.querySelector('.scroll-wrapper');
    spyOn(preferenceModalComponent, 'onConsentScrolled');
    componentFixture.detectChanges();
    tocDiv.dispatchEvent(new Event('scroll'));
    expect(preferenceModalComponent.onConsentScrolled).toHaveBeenCalled();
  });

  it('should dispatch verify email', () => {
    spyOn(store, 'dispatch');
    preferenceModalComponent.sendVerifyAccessCode();
    expect(store.dispatch).toHaveBeenCalled();
  });
});
