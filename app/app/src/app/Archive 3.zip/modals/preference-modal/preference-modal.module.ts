import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { PreferenceModalComponent } from '@app/modals/preference-modal/preference-modal.component';
import { AlertsModule } from '@app/components/alerts/alerts.module';
import { AppControlMessagesModule } from '@app/components/app-control-messages/app-control-messages.module';
import { ReactiveFormsModule } from '@angular/forms';
import { NgxMaskModule } from 'ngx-mask';
import { TextMaskModule } from 'angular2-text-mask';
import { AutofocusDirectiveModule } from '@app/directives/autofocus/autofocus.directive.module';
import { NumberOnlyDirectiveModule } from '@app/directives/number-only/number-only.directive.module';
import { PreferenceVerifyChannelModule } from '@app/components/preference-verify-channel/preference-verify-channel.module';
import { PreferenceSelectionsModule } from '@app/components/preference-selections/preference-selections.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  imports: [
    CommonModule,
    IonicModule,
    AlertsModule,
    AppControlMessagesModule,
    ReactiveFormsModule,
    NgxMaskModule,
    TextMaskModule,
    AutofocusDirectiveModule,
    NumberOnlyDirectiveModule,
    PreferenceVerifyChannelModule,
    PreferenceSelectionsModule,
    FontAwesomeModule
  ],
  declarations: [PreferenceModalComponent]
})
export class PreferenceModalModule {}
