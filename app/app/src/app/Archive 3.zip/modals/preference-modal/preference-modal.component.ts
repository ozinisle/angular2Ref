import { Component, ElementRef, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ModalController, IonContent } from '@ionic/angular';
import { ChangeDetectorRef } from '@angular/core';
import { takeUntil } from 'rxjs/operators';
import { Actions, ofActionDispatched, Select, Store } from '@ngxs/store';
import { CheckPreferenceServices, SubmitPreferences } from '@app/store/actions/preference.action';
import {
  VerificationCodeResent,
  VerifyAccessCode,
  VerifyEmail,
  VerifyPhone,
  SetSkipVerifyPhoneFlag
} from '@app/store/actions/profile.action';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { AlertService } from '@app/services/alert.service';
import { ValidationService } from '@app/services/validation.service';
import { PreferenceSelectors } from '@app/store/selectors/preference.selectors';
import { Observable, Subject } from 'rxjs';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { PreferenceCenterProgram } from '@app/models/preference.model';
import { VERIFICATION_CODE_RESENT_MSG, DEFAULT_PHONE_NUM } from '@app/store/constants/preference.constants';

import { ProfileSelectors } from '@app/store/selectors/profile.selectors';
import { PostLoginModel } from '@app/models/post-login.model';
import { PreferenceService } from '@app/services/preference.service';
import { PlanConfigService } from '@app/services/plan-config/plan-config-service';
import { MY_ACCOUNT_CONSTANTS } from '@app/pages/my-account/my-account.constants';
import { VerifyAccessCodeInputValidationResultModel, FormGroupControlsModel } from '@app/pages/registration/models/registration.models';

@Component({
  selector: 'app-preference-modal',
  templateUrl: './preference-modal.component.html',
  styleUrls: ['./preference-modal.component.scss']
})
export class PreferenceModalComponent implements OnInit, OnDestroy {
  @ViewChild('accesscode1') accesscode1: ElementRef;
  @ViewChild('accesscode2') accesscode2: ElementRef;
  @ViewChild('accesscode3') accesscode3: ElementRef;
  @ViewChild('accesscode4') accesscode4: ElementRef;
  @ViewChild('accesscode5') accesscode5: ElementRef;
  @ViewChild('accesscode6') accesscode6: ElementRef;

  @SelectSnapshot(AppSelectors.getPostLoginInfo) postLoginInfo: PostLoginModel;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @Select(ProfileSelectors.getVerifyCategory) verifyCategory$: Observable<string>;
  @SelectSnapshot(ProfileSelectors.getMaskedVerifiable) maskedVerifiable: Observable<string>;

  @SelectSnapshot(ProfileSelectors.getProfileInfo) profileInfo: any;
  @SelectSnapshot(PreferenceSelectors.getProgramGroups) programGroups: any;
  @SelectSnapshot(ProfileSelectors.getConsentResponse) consentResponse: any;
  @Select(ProfileSelectors.modalSection) modalSection$: Observable<string>;
  @SelectSnapshot(PreferenceSelectors.getPlanDocumentsSelectedFlag) isPlanDocumentsSelected: boolean;
  @SelectSnapshot(PreferenceSelectors.getHealthBenefitsSelectedFlag) isHealthBenefitsSelected: boolean;
  @SelectSnapshot(ProfileSelectors.isPhoneNumberRequired) isPhoneNumberRequired: boolean;
  @Select(PreferenceSelectors.getUserBouncedStatus) userChannelBounced$: Observable<string>;
  @Select(PreferenceSelectors.getPreferences) preferences: any;
  @SelectSnapshot(ProfileSelectors.isSkipVerifyPhone) isSkipVerifyPhone: boolean;
  @Select(PreferenceSelectors.showRELModal) showRELModal$: Observable<boolean>;

  @ViewChild(IonContent) content: IonContent;

  programList: PreferenceCenterProgram[];
  isConsentScrolled = false;
  verifyaccesscodeForm: FormGroup;
  shiftKeyDown: boolean;
  showPreference = true;
  verifyCategory = '';
  verifyOnlyFlow = false;
  destroy$ = new Subject<void>();
  updatePhoneForm: FormGroup;
  updateEmailForm: FormGroup;
  mask = {};
  emailHardBounced: boolean;
  smsBounced: boolean;
  isModelFlag = true;
  cdhFlagValue: boolean;

  authToken: any = JSON.parse(sessionStorage.getItem('authToken'));
  public verifyaccesscodeFormValidator: VerifyAccessCodeInputValidationResultModel = new VerifyAccessCodeInputValidationResultModel();
  existingPreferenceSelected = [];
  newPreferenceSelected = [];

  constructor(
    private modalCtrl: ModalController,
    private alertService: AlertService,
    private fb: FormBuilder,
    private validationService: ValidationService,
    private router: Router,
    private store: Store,
    private actions$: Actions,
    private changeRef: ChangeDetectorRef,
    private preferenceService: PreferenceService,
    private planConfigService: PlanConfigService
  ) {
    this.actions$.pipe(ofActionDispatched(VerificationCodeResent), takeUntil(this.destroy$)).subscribe(() => {
      this.alertService.setAlert(VERIFICATION_CODE_RESENT_MSG, '', AlertType.Success, 'preferenceModal');
    });
    this.store.dispatch(new CheckPreferenceServices(true));
    this.userChannelBounced$.pipe(takeUntil(this.destroy$)).subscribe(userChannelBounced => {
      if (userChannelBounced === 'Email') {
        this.emailHardBounced = true;
      } else if (userChannelBounced === 'SMS') {
        this.smsBounced = true;
      }
    });
  }

  ngOnInit() {
    this.planConfigService.getCurrentPlanConfig$().subscribe(planConfig => this.cdhFlagValue = planConfig.elligibility.isDigitalFirstCDH);
    this.checkIfUserHasBouncedChannel();
    this.verifyCategory = sessionStorage.getItem('maskedVerifyPhone') === 'Y' ? 'Mobile Number' : 'Email';
    this.verifyaccesscodeForm = this.fb.group(
      {
        accesscode1: ['', [Validators.required]],
        accesscode2: ['', [Validators.required]],
        accesscode3: ['', [Validators.required]],
        accesscode4: ['', [Validators.required]],
        accesscode5: ['', [Validators.required]],
        accesscode6: ['', [Validators.required]]
      },
      {
        validator: this.validationService.accessCodeValidator()
      }
    );
    this.showRELModal$.subscribe(closeModal => {
      if (closeModal) {
        this.alertService.clearError();
        this.dismissModal();
      }
    });
  }

  checkIfUserHasBouncedChannel() {
    this.userChannelBounced$.pipe(takeUntil(this.destroy$)).subscribe(userChannelBounced => {
      if (userChannelBounced === 'Email') {
        this.emailHardBounced = true;
      } else if (userChannelBounced === 'SMS') {
        this.smsBounced = true;
      }
    });
    this.changeRef.detectChanges();
  }

  onConsentScrolled($event) {
    const { target } = $event;
    if (target.offsetHeight + target.scrollTop >= target.scrollHeight) {
      this.isConsentScrolled = true;
    }
  }

  dismissModal() {
    this.modalCtrl.dismiss({ dismiss: true });
    this.verifyOnlyFlow = false;
  }

  get isButtonDisabled() {
    const hasEmailAddress = this.profileInfo?.updatedEmailAddress || this.profileInfo?.emailAddress;
    const phoneNumber = this.profileInfo?.updatedPhoneNumber || this.profileInfo?.phoneNumber;
    const hasPhoneNumber = !this.isPhoneNumberRequired || phoneNumber !== DEFAULT_PHONE_NUM;
    const isAllChannelsValid = hasEmailAddress && hasPhoneNumber;
    if (!isAllChannelsValid) {
      return true;
    } else {
      return this.consentResponse?.consentFlag !== 'Y'
        ? !this.isConsentScrolled || !this.isPlanDocumentsSelected || (this.cdhFlagValue && !this.isHealthBenefitsSelected)
        : !this.isPlanDocumentsSelected || (this.cdhFlagValue && !this.isHealthBenefitsSelected);
    }
  }

  submitPrefernce() {
    this.store.dispatch(new SubmitPreferences(true));
    let gotoVerification = false;
    const { isVerifiedEmail, isVerifiedMobile } = this.profileInfo;
    const phoneNumber = this.profileInfo.updatedPhoneNumber || this.profileInfo.phoneNumber;
    const hasPendingMobileVerification = !isVerifiedMobile && !this.isSkipVerifyPhone && phoneNumber && phoneNumber !== DEFAULT_PHONE_NUM;
    if (!isVerifiedEmail || !isVerifiedMobile || hasPendingMobileVerification) {
      gotoVerification = true;
    }
    let showRELModal = false;
    showRELModal = this.postLoginInfo.showDemographicModel && (!gotoVerification || this.preferenceService.phoneNumberVerificationSkipped);
    if (!showRELModal) {
      this.content.scrollToTop(7000);
    } else {
      //If REL Modal required close Pref Center Modal
      this.dismissModal();
    }
  }

  continueSubmitPrefernce() {
    this.store.dispatch(new SetSkipVerifyPhoneFlag(true));
    this.preferenceService.phoneNumberVerificationSkipped = true;
    this.submitPrefernce();
  }

  navigatemanagecommunication() {
    this.modalCtrl.dismiss({ dismiss: true });
    this.router.navigate(['/myprofile/communication-preferences']);
    this.verifyOnlyFlow = false;
  }

  isValidKeyPressed(event) {
    const key = event.key;
    return (
      key === 'Backspace' ||
      key === 'ArrowLeft' ||
      key === 'ArrowRight' ||
      (event.keyCode >= 48 && event.keyCode <= 57) ||
      (event.keyCode >= 96 && event.keyCode <= 105)
    );
  }
  onKeyDown(event) {
    if (event.keyCode === 16) {
      this.shiftKeyDown = true;
    }
    if (this.shiftKeyDown || !this.isValidKeyPressed(event)) {
      return false;
    }
  }

  onKeyUp(event, previousElement, nextElement) {
    if (this.shiftKeyDown) {
      if (event.keyCode === 16) {
        this.shiftKeyDown = false;
      }
      return false;
    }

    if (event && event.target['value'] === '' && !this.isValidKeyPressed(event)) {
      return false;
    }

    if ((event.key === 'Backspace' || event.which === 37 || event.key === 'ArrowLeft') && previousElement) {
      previousElement.focus();
    }
    if (
      (event.key === 'ArrowRight' ||
        event.which === 39 ||
        (event.which >= 48 && event.which <= 57) ||
        (event.which >= 96 && event.which <= 105)) &&
      nextElement
    ) {
      setTimeout(() => nextElement.focus(), 100);
    }
  }

  splitAndPlacePastedValues(event, materialForm): boolean {
    event.preventDefault();
    let pastedData = '';
    if (event.clipboardData) {
      pastedData = event.clipboardData.getData('text/plain');
    } else if (window['clipboardData']) {
      pastedData = window['clipboardData'].getData('Text');
    }

    pastedData = pastedData.replace(/\D/g, '');

    let pastedCharArr = pastedData.split('');

    if (pastedCharArr.length > 6) {
      pastedCharArr = pastedCharArr.splice(0, 6);
    }

    const accessCodeFields: NodeListOf<Element> = document.querySelectorAll('input.access-code');
    Object.keys(materialForm.controls).forEach((controlName, controlIndex) => {
      const pastedNumber: string = pastedCharArr[controlIndex];
      if (pastedNumber) {
        const formInputControl: FormControl = materialForm.get(controlName);
        // focus method does not work as such in ie11. hence requires a timeout block as fix/workaround for the same
        setTimeout(() => {
          (accessCodeFields[controlIndex] as HTMLInputElement).focus();
          formInputControl.setValue(pastedNumber);
        }, 10);
      } else {
        return false;
      }
    });

    this.getMatFormClass(materialForm);
    return true;
  }

  public getMatFormClass(materialForm: FormGroup): VerifyAccessCodeInputValidationResultModel {
    this.verifyaccesscodeFormValidator = new VerifyAccessCodeInputValidationResultModel();
    const controls: FormGroupControlsModel = materialForm.controls;
    const control = MY_ACCOUNT_CONSTANTS.controls;
    const accessCode1 = controls[control.accessCode1];
    const accessCode2 = controls[control.accessCode2];
    const accessCode3 = controls[control.accessCode3];
    const accessCode4 = controls[control.accessCode4];
    const accessCode5 = controls[control.accessCode5];
    const accessCode6 = controls[control.accessCode6];

    if (!(accessCode1 && accessCode2 && accessCode3 && accessCode4 && accessCode5 && accessCode6)) {
      return this.verifyaccesscodeFormValidator;
    }

    const controlErrors: ValidationErrors =
      accessCode1.errors || accessCode2.errors || accessCode3.errors || accessCode4.errors || accessCode5.errors || accessCode6.errors;

    const allTouched: boolean =
      accessCode1.touched &&
      accessCode2.touched &&
      accessCode3.touched &&
      accessCode4.touched &&
      accessCode5.touched &&
      accessCode6.touched;

    const errorFlag: boolean = controlErrors ? true : !allTouched;

    const hasRequiredErrorFlags: boolean =
      (accessCode1.errors && accessCode1.errors.required) ||
      (accessCode2.errors && accessCode2.errors.required) ||
      (accessCode3.errors && accessCode3.errors.required) ||
      (accessCode4.errors && accessCode4.errors.required) ||
      (accessCode5.errors && accessCode5.errors.required) ||
      (accessCode6.errors && accessCode6.errors.required);

    this.verifyaccesscodeFormValidator.isError = errorFlag;
    this.verifyaccesscodeFormValidator.hasErrors = hasRequiredErrorFlags;
  }

  selectBox(event: any) {
    const elem = event.target as HTMLInputElement;
    elem.focus();
    elem.select();
  }

  resetFormValue() {
    this.verifyaccesscodeForm.setValue({
      accesscode1: '',
      accesscode2: '',
      accesscode3: '',
      accesscode4: '',
      accesscode5: '',
      accesscode6: ''
    });
  }

  verifyAccessCode() {
    this.alertService.clearError();
    const accessCode = [
      this.verifyaccesscodeForm.value.accesscode1,
      this.verifyaccesscodeForm.value.accesscode2,
      this.verifyaccesscodeForm.value.accesscode3,
      this.verifyaccesscodeForm.value.accesscode4,
      this.verifyaccesscodeForm.value.accesscode5,
      this.verifyaccesscodeForm.value.accesscode6
    ].join('');
    if (this.verifyaccesscodeForm.valid) {
      this.store.dispatch(new VerifyAccessCode(accessCode, false, true));
      this.resetFormValue();
    }
  }

  sendAccessCode() {
    this.resetFormValue();
    this.alertService.clearError();
    this.verifyCategory$.pipe(takeUntil(this.destroy$)).subscribe(verifyCategory => {
      if (verifyCategory === 'Email') {
        this.store.dispatch(new VerifyEmail(this.profileInfo.updatedEmailAddress || this.profileInfo.emailAddress, true, true));
      } else {
        this.store.dispatch(new VerifyPhone(this.profileInfo.updatedPhoneNumber || this.profileInfo.phoneNumber, true, true));
      }
    });
  }

  sendVerifyAccessCode() {
    if (!this.profileInfo.isVerifiedEmail) {
      this.store.dispatch(new VerifyEmail(this.profileInfo.updatedEmailAddress || this.profileInfo.emailAddress, false, true, false));
    } else {
      let updatedPhoneNumber;
      if (this.profileInfo.updatedPhoneNumber) {
        updatedPhoneNumber = this.profileInfo.updatedPhoneNumber.replace(/\D/g, '');
      } else {
        updatedPhoneNumber = this.profileInfo.phoneNumber;
      }
      this.store.dispatch(new VerifyPhone(updatedPhoneNumber, false, true, false));
    }
    this.verifyOnlyFlow = true;
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  getDisplayChannelValue(profileInfo) {
    let displayValue = '';
    if (!profileInfo?.isVerifiedEmail) {
      displayValue = profileInfo?.updatedEmailAddress || profileInfo?.emailAddress;
      displayValue = 'Email: ' + displayValue;
    } else {
      displayValue = profileInfo?.updatedPhoneNumber || profileInfo?.phoneNumber;
      displayValue = this.maskPhoneNumber(displayValue);
      displayValue = 'Mobile: ' + displayValue;
    }
    return displayValue;
  }

  maskPhoneNumber(maskedPhoneNumber: string): string {
    const regex = /^(.{3})(.{3})(.{4})(.*)/;
    const str = maskedPhoneNumber;
    const subst = `($1) $2-$3`;
    maskedPhoneNumber = str.replace(regex, subst);
    return maskedPhoneNumber;
  }
}
