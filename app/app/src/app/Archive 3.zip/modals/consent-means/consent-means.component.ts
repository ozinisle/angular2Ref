import { Component } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-consent-means',
  templateUrl: './consent-means.component.html',
  styleUrls: ['./consent-means.component.scss']
})
export class ConsentMeansComponent {
  constructor(public modalController: ModalController) {}

  closeEmailModals() {
    this.modalController.dismiss({
      dismissed: true
    });
  }
}
