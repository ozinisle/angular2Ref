import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { ConsentMeansComponent } from './consent-means.component';
import { IonicModule, ModalController } from '@ionic/angular';

describe('ConsentMeansComponent', () => {
  let component: ConsentMeansComponent;
  let fixture: ComponentFixture<ConsentMeansComponent>;

  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['dismiss']);

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [IonicModule],
      providers: [
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        }
      ],
      declarations: [ConsentMeansComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(ConsentMeansComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should dismiss', () => {
    expect(component).toBeTruthy();
  });
});
