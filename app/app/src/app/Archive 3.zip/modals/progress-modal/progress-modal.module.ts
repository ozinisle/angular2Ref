import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { ProgressModalComponent } from './progress-modal.component';
import { FloorPipeModule } from '@app/pipes/floor/floor.pipe.module';

@NgModule({
  imports: [CommonModule, IonicModule, FloorPipeModule],
  declarations: [ProgressModalComponent]
})
export class ProgressModalModule {}
