import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { ProgressModalComponent } from './progress-modal.component';
import { FloorPipeModule } from '@app/pipes/floor/floor.pipe.module';
import { NgxsModule } from '@ngxs/store';
import { RouterTestingModule } from '@angular/router/testing';
import { IonContent, IonicModule } from '@ionic/angular';

describe('ProgressModalComponent', () => {
  let component: ProgressModalComponent;
  let fixture: ComponentFixture<ProgressModalComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [IonicModule, FloorPipeModule, RouterTestingModule, NgxsModule.forRoot([])],
      declarations: [ProgressModalComponent],
      providers: [IonContent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProgressModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
