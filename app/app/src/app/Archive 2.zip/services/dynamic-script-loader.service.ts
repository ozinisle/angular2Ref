import { Injectable } from '@angular/core';
import { environment } from '@environments/environment';

interface Scripts {
  name: string;
  src: string;
}

export const SCRIPT_STORE: Scripts[] = [
  {
    name: 'adobe-analytics',
    src: environment.dynamicTagLink
  },
  {
    name: 'livechat',
    src: environment.liveChatServerUrl + '/templates/chat/egain-chat.js'
  }
];

declare var document: any;

@Injectable({ providedIn: 'root' })
export class DynamicScriptLoaderService {
  private scripts: any = {};

  constructor() {
    SCRIPT_STORE.forEach((script: any) => {
      this.scripts[script.name] = {
        loaded: false,
        src: script.src
      };
    });
  }

  load(...scripts: string[]) {
    const promises: any[] = [];
    scripts.forEach(script => promises.push(this.loadScript(script)));
    return Promise.all(promises);
  }

  loadScript(name: string) {
    return new Promise((resolve, reject) => {
      if (!this.scripts[name].loaded) {
        const element = document.createElement('script'); //load script
        element.type = 'text/javascript';
        element.src = this.scripts[name].src;
        element.async = true;
        if (element.readyState) {
          // IE
          element.onreadystatechange = () => {
            if (element.readyState === 'loaded' || element.readyState === 'complete') {
              element.onreadystatechange = null;
              this.scripts[name].loaded = true;
              resolve({ script: name, loaded: true, status: 'Loaded' });
            }
          };
        } else {
          // Others
          element.onload = () => {
            this.scripts[name].loaded = true;
            resolve({ script: name, loaded: true, status: 'Loaded' });
          };
        }
        element.onerror = (error: any) => resolve({ script: name, loaded: false, status: 'Loaded' });
        document.getElementsByTagName('head')[0].appendChild(element);
      } else {
        resolve({ script: name, loaded: true, status: 'Already Loaded' });
      }
    });
  }
}
