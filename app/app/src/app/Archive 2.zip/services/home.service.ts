import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { ArticleModel } from '@app/pages/home/home.model';
import { ConstantsService } from '@app/services/constants.service';
import { publishReplay, refCount } from 'rxjs/operators';
import { MAX_TRANSACTIONS } from '@app/utils/finance.utils';
import { environment } from '@environments/environment';
import { BANNER_TYPE } from '@app/store/constants/app.constants';

@Injectable({ providedIn: 'root' })
export class HomeService {
  public article1$: BehaviorSubject<ArticleModel>;
  public article2$: BehaviorSubject<ArticleModel>;
  public article3$: BehaviorSubject<ArticleModel>;

  public article1: Observable<ArticleModel>;
  public article2: Observable<ArticleModel>;
  public article3: Observable<ArticleModel>;

  public articles: any;

  public globalFooterData: any;

  public financialData$: Observable<any>;

  // TODO: The amount of data mapping going on in this service is beyond ridiculous
  constructor(
    private http: HttpClient,
    private constants: ConstantsService,
    private constantsService: ConstantsService
  ) {
    this.article1$ = new BehaviorSubject(new ArticleModel(1));
    this.article2$ = new BehaviorSubject(new ArticleModel(2));
    this.article3$ = new BehaviorSubject(new ArticleModel(3));

    this.article1 = this.article1$.asObservable();
    this.article2 = this.article2$.asObservable();
    this.article3 = this.article3$.asObservable();

    this.articles = [];
    this.articles.push(this.article1);
    this.articles.push(this.article2);
    this.articles.push(this.article3);
  }

  getHomepageinfo(useridin) {
    const request = {
      useridin
    };
    return this.http.post(this.constants.homepageUrl, request);
  }

  loadArticle(number) {
    this.http.get(this.constants.promoBlocks[number - 1]).subscribe(item => {
      this[`article${number}$`]?.next(new ArticleModel(number).deserialize(item[0]));
    });
  }

  getCarouselItemDetails(): Observable<any> {
    return this.http.get(this.constantsService.drupalSliderUrl);
  }

  clearCache() {
    this.financialData$ = null;
  }

  getFinanceBalanceData(useridin): Observable<any> {
    if (!this.financialData$) {
      const isHeqTransactionsEnabled = environment.showFinancialTransactions;
      const request = {
        useridin,
        noOfTransactionsPerAccount: isHeqTransactionsEnabled ? MAX_TRANSACTIONS : 0,
      };
      this.financialData$ = this.http.post(this.constants.financeUrl, request)
      .pipe(
        publishReplay(1),
        refCount()
      );
    }
    return this.financialData$;
  }

  getHomePageApiResponse(): Observable<any> {
    return this.http.get(this.constantsService.drupalHomeContentsUrl);
  }

  setSessionLinks() {
    this.http.get(this.constantsService.drupalHomeNavigationUrl).subscribe(response => {
      const apiResponse = Array.isArray(response) ? response[0] : response;
      if (response) {
        sessionStorage.setItem('find_a_doctor_link', apiResponse.APPTextUrl3 || '');
        sessionStorage.setItem('call_nurse_link_link', apiResponse.APPTextUrl2 || '');
      }
    });
  }

  getHomeNavigationResponse(): Observable<any> {
    return this.http.get(this.constantsService.drupalHomeNavigationUrl);
  }

  getTermsPageResponse(): Observable<any> {
    return this.http.get(this.constantsService.drupalTermsPageUrl);
  }

  getConfidentialityPageResponse(): Observable<any> {
    return this.http.get(this.constantsService.drupalConfidentialityPageUrl);
  }

  getHomeHeroBannerResponse(): Observable<any> {
    return this.http.get(this.constantsService.drupalHomeHeroBannerUrl);
  }

  getHomeDiscountsResponse(): Observable<any> {
    return this.http.get(this.constantsService.drupalHomeDiscountsUrl);
  }

  getBannerPromoContent(bannerTyp?): Observable<any> {
    return this.http.get(this.constantsService.drupalBannerPromoContentUrl + (bannerTyp !== BANNER_TYPE.DEFAULT ? '?type=' + bannerTyp : ''));
  }

  getBrandPromoFooter(id): Observable<any> {
    return this.http.get(this.constantsService.brandFooter[id]);
  }

  getRecommendedForYouContent(): Observable<any> {
    return this.http.get(this.constantsService.drupalRecommendedUrl + '?tileids=78266,78271,78276');
  }

}
