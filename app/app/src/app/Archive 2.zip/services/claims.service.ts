import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { catchError, map } from 'rxjs/operators';
import {
  ClaimsSummaryRequestModel,
  ClaimsSummaryResponseModel,
  ClaimSummaryMetadata
} from '@app/pages/my-claims/models/claims-summary-data.model';
import {
  ClaimsSummaryRequestModelInterface,
  ClaimsSummaryResponseModelInterface
} from '@app/pages/my-claims/models/interfaces/claims-summary-data-model.interface';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { ConstantsService } from '@app/services/constants.service';
import { Observable, of } from 'rxjs';

export interface Config {
  eyeMedStartDate: string;
}

@Injectable({ providedIn: 'root' })
export class ClaimsService {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  constructor(private http: HttpClient, private constants: ConstantsService) { }

  getClaims(filterPaginationReqParams?: ClaimsSummaryRequestModelInterface): Observable<ClaimsSummaryResponseModelInterface> {
    let request: ClaimsSummaryRequestModelInterface = new ClaimsSummaryRequestModel();
    if (!filterPaginationReqParams) {
      request.useridin = this.useridin;
      const sortorder = 'Most Recent';
      request.summaryMetaData = new ClaimSummaryMetadata();
      request.summaryMetaData.sortOrder = sortorder;
    } else {
      request = filterPaginationReqParams;
    }
    return this.http.post<ClaimsSummaryResponseModel>(this.constants.claimsUrl, request);
  }

  /**
   * Return an observbable with the configuration from Drupal.
   * Map to an error if config is not returned in the content.
   */
  getConfig$(): Observable<Config> {
    return this.http.get<Array<any>>(this.constants.drupalConfigUrl  +
      '?random=' + this.generateRandomString(12))
      .pipe(map(response => {
        if (response != null && response.length > 0 && response[0].config != null) {
          return JSON.parse(response[0].config) as Config
        } else {
          throw new Error("Config is not returned with any value");
        }
      }));
  }

  /**
   * Return the start date to show EyeMed link.
   * If the date is not in the config or if there is an error
   * we fallback on the date from the constant service.
   */
  getEyeMedStartDate$(): Observable<Date> {
    return this.getConfig$()
      .pipe(map(config => {
        if (config.eyeMedStartDate
          && config.eyeMedStartDate !== ""
          && !isNaN(new Date(config.eyeMedStartDate).getDate())) {
          return new Date(config.eyeMedStartDate)
        } else {
          return this.constants.eyeMedStartDate;
        }
      }))
      .pipe(catchError(() => {
        return of(this.constants.eyeMedStartDate);
      }));
  }

  /**
   * Return boolean value if link needs to be displayed.
   */
  shouldDisplayEyemedLink$(userType: string): Observable<boolean> {
    if (userType && userType.toLowerCase() !== 'medicare') {
      return of(false);
    } else {
      return this.getEyeMedStartDate$().pipe(map(date => date < new Date()));
    }
  }

  /**
   * Return random string with set of characters.
  */
  generateRandomString(length: number): string {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
  }
}
