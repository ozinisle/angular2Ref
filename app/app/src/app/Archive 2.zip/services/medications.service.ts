import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Store } from '@ngxs/store';
import { Observable, of as observableOf } from 'rxjs';
import { map } from 'rxjs/operators';
import { GetMemBasicInfoRequestModel, GetMemBasicInfoResponseModel } from '@app/pages/my-medication/models/get-member-basic-info.model';
import {
  GetMemBasicInfoRequestModelInterface,
  GetMemBasicInfoResponseModelInterface
} from '@app/pages/my-medication/models/interfaces/get-member-basic-info-model.interface';
import { RecentRxRequestModel, RecentRxResponseModel } from '@app/pages/my-medication/models/recent-rx.model';
import { SetBasicMemberInfo } from '@app/store/actions/app.actions';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { ConstantsService } from '@app/services/constants.service';
import {
  DependentRecentRxRequestModelInterface
} from '@app/pages/my-medication/models/interfaces/dependant-recent-rx-model.interface';
import {
  DependentRecentRxRequestModel
  //DependentRecentRxResponseModel
} from '@app/pages/my-medication/models/dependant-recent-rx.model';
import { TitleCasePipe } from '@angular/common';
import { DependentModel } from '@app/models/dependent.model';
import { NavigationEnd, Router } from '@angular/router';

@Injectable({ providedIn: 'root' })
export class MedicationsService {
  @SelectSnapshot(AppSelectors.getBasicMemberInfo) basicMemInfo: any;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  currentUrl: string;
  previousUrl: string;

  constructor(private http: HttpClient,private router: Router, private store: Store, private constants: ConstantsService, private title: TitleCasePipe) {
    this.currentUrl = this.router.url;
    router.events.subscribe((event) => {
      if(event instanceof NavigationEnd){
        this.previousUrl = this.currentUrl;
        this.currentUrl = event.url;
      }
    })
  }
  
  getPreviousUrl() {
    return this.previousUrl;
  }

  setBasicMemInfo(basicMemInfo: GetMemBasicInfoResponseModelInterface): MedicationsService {
    this.store.dispatch(new SetBasicMemberInfo(basicMemInfo));
    return this;
  }

  getMemBasicInfo(): Observable<any> {
    if (this.basicMemInfo) {
      return observableOf(this.basicMemInfo);
    }
    const request: GetMemBasicInfoRequestModelInterface = new GetMemBasicInfoRequestModel();
    request.useridin = this.useridin;

    return this.http.post<any>(this.constants.getMemBasicInfoUrl, request).pipe(
      map(response => {
        if (response.result < 0) {
          return new GetMemBasicInfoResponseModel();
        } else {
          const basicInfo = new GetMemBasicInfoResponseModel();
          basicInfo.rxSummary = response.getMemBasicInfoResponse;
          this.store.dispatch(new SetBasicMemberInfo(basicInfo));
          return basicInfo as GetMemBasicInfoResponseModel;
        }
      })
    );
  }

  getMedications(): Observable<any> {
    const request = new RecentRxRequestModel();
    request.useridin = this.useridin;

    return this.http.post(this.constants.medicationsUrl, request).pipe(
      map((response: any) => {
        if (response?.result < 0) {
          return new RecentRxResponseModel();
        } else {
          response.rxSummary.map( medication => {
            medication['fullName'] = medication.memMiddleInitial
            ? [
                this.title.transform(this.basicMemInfo.rxSummary.memFirstName),
                ' ',
                this.title.transform(this.basicMemInfo.rxSummary.memMiddleInitial),
                ' ',
                this.title.transform(this.basicMemInfo.rxSummary.memLastName),
                ' (',
                this.title.transform(this.basicMemInfo.rxSummary.relationship),
                ')'
              ].join('')
            : [
                this.title.transform(this.basicMemInfo.rxSummary.memFirstName),
                ' ',
                this.title.transform(this.basicMemInfo.rxSummary.memLastName),
                ' (',
                this.title.transform(this.basicMemInfo.rxSummary.relationship),
                ')'
              ].join('');
          });
          return response as RecentRxResponseModel;
        }
      })
    );
  }

  getDependentMedications(dependent: DependentModel) {
    const dependentRecentRxReq: DependentRecentRxRequestModelInterface = new DependentRecentRxRequestModel();
    dependentRecentRxReq.useridin = this.useridin;
    dependentRecentRxReq.dependentId = dependent.depId;
    //let title: TitleCasePipe;
    return this.http.post(this.constants.depMedicationsUrl, dependentRecentRxReq).pipe(
      map((response: any) => {
        if (response?.result < 0) {
          return new RecentRxResponseModel();
        } else {
          response.rxSummary.map (medication => {
            medication.dependentId = dependent.depId
            medication.fullName = medication.memMiddleInitial
            ? [
                this.title.transform(dependent.firstName),
                ' ',
                this.title.transform(dependent.middleInitial),
                ' ',
                this.title.transform(dependent.lastName),
                ' (',
                this.title.transform(dependent.relationship),
                ')'
              ].join('')
            : [
                this.title.transform(dependent.firstName),
                ' ',
                this.title.transform(dependent.lastName),
                ' (',
                this.title.transform(dependent.relationship),
                ')'
              ].join('');
          })
          return response as RecentRxResponseModel;
        }
      })
    );
  }


}
