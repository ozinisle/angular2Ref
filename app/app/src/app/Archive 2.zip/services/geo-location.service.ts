import { Injectable } from '@angular/core';
import { Geolocation, Geoposition } from '@ionic-native/geolocation/ngx';
import { NativeGeocoder, NativeGeocoderResult } from '@ionic-native/native-geocoder/ngx';
import { from, Observable } from 'rxjs';
import { filter, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class GeoLocationService {

  constructor(private geoLocation: Geolocation, private geoCoder: NativeGeocoder) { }

  public getCurrentLocation(): Observable<Geoposition | PositionError> {
    return this.geoLocation.watchPosition().pipe(
      filter<Geoposition>((p) => p.coords !== undefined)
    );
  }

  public getLocationByCoordinates(latitude: number, longitude: number): Observable<NativeGeocoderResult[]> {
    return from(this.geoCoder.reverseGeocode(latitude, longitude));
  }

  public getLocationByZipcode(zipCode: string): Observable<NativeGeocoderResult> {
    if (zipCode) {
      return from(this.geoCoder.forwardGeocode(zipCode)).pipe(
        map(response => response?.length ? response[0] : undefined)
      );
    }
  }

}
