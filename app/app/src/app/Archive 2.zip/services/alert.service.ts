import { Injectable } from '@angular/core';
import { AlertType } from '../components/alerts/alert-type.model';
import { BehaviorSubject } from 'rxjs';

export interface IAlert {
  message: string;
  title: string;
  type: AlertType;
  cssIcon?: string;
  cssClass?: string;
}

@Injectable({ providedIn: 'root' })
export class AlertService {
  public alerts$: BehaviorSubject<{ [key: string]: IAlert }> = new BehaviorSubject<{ [key: string]: IAlert }>({});

  clearError(scope = 'component') {
    const alerts = this.alerts$.getValue();
    delete alerts[scope];
    this.alerts$.next(alerts);
  }

  setAlert(message, title = 'Error', type = AlertType.Success, scope = 'component') {
    if (message?.includes('1-888-772-1722') && typeof message === 'string') {
      message = message.replace(/1-888-772-1722/g, "<a href='tel:8887721722'>1-888-772-1722</a>");
    }
    if (message?.includes('Register Now') && typeof message === 'string') {
      message = message.replace(/Register Now/g, "<a id='register'>Register Now</a>");
    }
    const alert = {
      title: title,
      type: type,
      message: message,
      cssClass: this.getClass(type),
      cssIcon: this.getIcon(type)
    } as IAlert;

    const alerts = this.alerts$.getValue();
    alerts[scope] = alert;

    this.alerts$.next(alerts);
  }

  setAlertObj(alertObj: IAlert, scope = 'component') {
    const alerts = this.alerts$.getValue();
    alerts[scope] = alertObj;
    this.alerts$.next(alerts);
  }

  setAlertMessage(scope, message) {
    const alerts = this.alerts$.getValue();
    alerts[scope] = message;
    this.alerts$.next(alerts);
  }

  setError(message) {
    this.setAlert(message, '', AlertType.Failure);
  }

  hasError(scope) {
    return this.alerts$.getValue()[scope] != null;
  }

  getAllError() {
    return this.alerts$.getValue();
  }

  resetErrorObject() {
    this.alerts$.next({});
  }

  getIcon(type: AlertType) {
    switch (type) {
      case AlertType.Failure:
        return 'sentiment_dissatisfied';
      case AlertType.Success:
        return 'sentiment_satisfied';
      case AlertType.Warning:
        return 'sentiment_warning';
      case AlertType.Notification:
        return 'sentiment_notification';
    }
  }

  getClass(type: AlertType) {
    switch (type) {
      case AlertType.Failure:
        return 'alert-failure';
      case AlertType.Success:
        return 'alert-success';
      case AlertType.Warning:
        return 'alert-warning';
      case AlertType.Notification:
        return 'alert-notification';
    }
  }
}
