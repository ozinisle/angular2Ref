import { HttpClientTestingModule } from '@angular/common/http/testing';
import { inject, TestBed, waitForAsync } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';
import { ClaimsService } from './claims.service';
import { Config_EyeMedStartDate_ValidDate, Config_With_NULLValues } from '@testing/data/myclaims/claims/claims.data';
import { Config_With_EmptyArray, Config_With_Empty_Data } from '@testing/data/myclaims/claims/claims.data';
import { Config_With_Invalid_JSON, CONFIG_URL_INVALID_URL } from '@testing/data/myclaims/claims/claims.data';
import { ConstantsService } from './constants.service';

describe('ClaimsService', () => {
    beforeEach(waitForAsync(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule, IonicModule]
        }).compileComponents();
    }));
    it('should be created', inject([ClaimsService], (service: ClaimsService) => {
        expect(service).toBeTruthy();
    }));
    it('should get an observbable with the configuration from Drupal', waitForAsync(() => {
        const service: ClaimsService = TestBed.inject(ClaimsService);
        service.getConfig$().subscribe((response) => {
            expect(response[0].config).toEqual(Config_EyeMedStartDate_ValidDate[0].config);
        })
    }));
    it('Get an empty response from  drupal response', waitForAsync(() => {
        const service: ClaimsService = TestBed.inject(ClaimsService);
        service.getConfig$().subscribe((response) => {
            expect(response[0]).toEqual(Config_With_EmptyArray);
        })
    }));
    it('Get an empty eyeMedStartdate from  drupal response', waitForAsync(() => {
        const service: ClaimsService = TestBed.inject(ClaimsService);
        service.getConfig$().subscribe((response) => {
            expect(response[0].config).toEqual(Config_With_Empty_Data[0].config);
        })
    }));
    it('Get an null response from empty drupal response', waitForAsync(() => {
        const service: ClaimsService = TestBed.inject(ClaimsService);
        service.getConfig$().subscribe((response) => {
            expect(response[0]).toEqual(Config_With_NULLValues);
        })
    }));
    it('Check for invalid JSON', waitForAsync(() => {
        const service: ClaimsService = TestBed.inject(ClaimsService);
        service.getConfig$().subscribe((response) => {
            expect(response[0]).not.toEqual(Config_With_Invalid_JSON[0]);
        })
    }));
    it('verify eyemed date available in drupal response', waitForAsync(() => {
        const service: ClaimsService = TestBed.inject(ClaimsService);
        service.getEyeMedStartDate$().subscribe((response) => {
            expect(response[0]?.config.eyeMedStartDate).not.toBeNull();
        })
    }));
    it('verify eyemed date flag is true so that eyemed link needs to be displayed', waitForAsync(() => {
        const service: ClaimsService = TestBed.inject(ClaimsService);
        service.shouldDisplayEyemedLink$('medicare').subscribe((response) => {
            expect(response).toBeTrue();
        })
    }));
    it('verify eyemed date flag is false so that eyemend link should not be displayed', waitForAsync(() => {
        const service: ClaimsService = TestBed.inject(ClaimsService);
        service.shouldDisplayEyemedLink$('non-medicare').subscribe((response) => {
            expect(response).toBeFalse();
        })
    }));
    it('Check for future date validation', waitForAsync(() => {
        const service: ClaimsService = TestBed.inject(ClaimsService);
        service.shouldDisplayEyemedLink$('medicare').subscribe((response) => {
            expect(response[0].config.eyeMedStartDate).toBeFalse();
        })
    }));
    it('Check for Invalid date', waitForAsync(() => {
        const service: ClaimsService = TestBed.inject(ClaimsService);
        service.shouldDisplayEyemedLink$('medicare').subscribe((response) => {
            expect(response[0].config.eyeMedStartDate).toBeFalse();
        })
    }));
    it('Check for past Date validation', waitForAsync(() => {
        const service: ClaimsService = TestBed.inject(ClaimsService);
        service.shouldDisplayEyemedLink$('medicare').subscribe((response) => {
            expect(response[0].config.eyeMedStartDate).toBeTrue();
        })
    }));
    it('Check for Invalid url with response coming 404', waitForAsync(() => {
        const service: ClaimsService = TestBed.inject(ClaimsService);
        const constantService: ConstantsService = TestBed.inject(ConstantsService);
        constantService.drupalConfigUrl = CONFIG_URL_INVALID_URL;
        service.shouldDisplayEyemedLink$('medicare').subscribe((response) => {
            expect(response).not.toThrowError('404');
        })
    }));
});
