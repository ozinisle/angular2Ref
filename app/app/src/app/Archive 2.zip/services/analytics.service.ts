import { Injectable } from '@angular/core';
import { AdobeAnalytics } from '../enums/adobe-analytics';
import { AuthToken } from '@app/models/auth-token.model';
import { LogRocketService } from './logrocket.service';

declare var window: any;

/* tslint:disable */
@Injectable({
  providedIn: 'root'
})
export class AnalyticsService {
  authToken: AuthToken;

  // globals on name space
  public _waDataLayer: any = null;

  // locals
  private satellite: any = null;
  private waDataLayer: any = null;

  constructor(private logRocket: LogRocketService) {
    this.satellite = window._satellite;
    window._waDataLayer = {};
    this.waDataLayer = window._waDataLayer;
  }

  get swrveHandle(): any {
    const plugins = window['plugins'];
    return plugins && plugins.swrve ? plugins.swrve : null;
  }

  initializeAdobe(satteliteRef: any, authToken: AuthToken) {
    let userId = 'Anonymous';
    const userInfo = {
      firstName: null
    };
    this.satellite = satteliteRef;
    this.authToken = authToken;
    if (this.authToken == null) {
      return;
    }

    if (this.authToken && this.authToken.syntheticID) {
      this.waDataLayer.UID = this.authToken.syntheticID;
      userId = this.authToken.syntheticID;
      // userInfo.firstName = this.authToken.firstName;
    } else {
      this.waDataLayer.UID = 'Anonymous';
    }
    this.logRocket.identify(userId, userInfo);
    setTimeout(() => {
      if (this.satellite) {
        this.satellite.track(AdobeAnalytics.MBW_LOGIN);
        this.satellite.track(AdobeAnalytics.APP_BOOT);
        this.satellite.track(AdobeAnalytics.SWRV_BOOT);
      }
    }, 3000);
  }

  sendAnalytic(payload: string) {
    if (this.satellite) {
      this.satellite.track(payload);
    }
  }

  captureAPIErrorInAdobe(result: string, displaymessage: string, errormessage: string) {
    (window as any)._waDataLayer.errormessage = errormessage;
    (window as any)._waDataLayer.result = result;
    (window as any)._waDataLayer.displaymessage = displaymessage;
    setTimeout(() => {
      if ((window as any)._satellite) {
        (window as any)._satellite.track('errormessage');
      }
    }, 3000);
  }

  setUser(installedSwrvUserId: string) {
    let userId = '';
    const userInfo = {
      firstName: null
    };
    if (this.satellite) {
      if (this.authToken && this.authToken.syntheticID) {
        this.waDataLayer.UID = this.authToken.syntheticID;
        userId = this.authToken.syntheticID;
        userInfo.firstName = this.authToken.firstName;
        if (installedSwrvUserId) {
          this.registerSwrveUserId(installedSwrvUserId);
        }
      } else {
        this.waDataLayer.UID = 'Anonymous';
        userId = 'Anonymous';
        this.registerSwrveUserId(this.waDataLayer.UID);
      }
      if (this.logRocket) {
        this.logRocket.identify(userId, userInfo);
      }
    }

    setTimeout(() => {
      if (this.satellite) {
        this.satellite.track(AdobeAnalytics.MBW_LOGIN);
        this.satellite.track(AdobeAnalytics.APP_BOOT);
        this.satellite.track(AdobeAnalytics.SWRV_BOOT);
      }
    }, 3000);
  }

  registerSwrveUserId(installedSwrvUserId: string) {
    if (this.swrveHandle) {
      this.waDataLayer.SWRVE_USER_ID = installedSwrvUserId;
    }
  }
}
