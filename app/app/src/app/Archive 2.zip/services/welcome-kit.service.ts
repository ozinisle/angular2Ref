import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConstantsService } from '@app/services/constants.service';

@Injectable()
export class WelcomeKitService {
  constructor(private http: HttpClient,
    private constants: ConstantsService,
    ) {}

  getPwkVideo(userId: string) {
    const request = {
      useridin: userId
    };
    return this.http.post(this.constants.pwkVideoUrl, request);
  }

  getMedicareWK(userId: string) {
    const request = {
      useridin: userId
    };
    return this.http.post(this.constants.pwkUrl, request);
  }

  getMedicareWKDoc(userId: string) {
    const request = {
      useridin: userId
    };
    return this.http.post(this.constants.pwkDocUrl, request);
  }

  setMedicareWK(userId: string, seenMedicarePDF: number, seenMedicareVideo: number) {
    const request = {
      useridin: userId,
      seenMedicarePDF,
      seenMedicareVideo
    };
    return this.http.post(this.constants.setPwkUrl, request);
  }
}
