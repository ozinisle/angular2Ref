import { Injectable, NgZone } from '@angular/core';
import { environment } from '@environments/environment';
import { version } from '@environments/version';
import * as LRSetup from 'logrocket/setup';

@Injectable()
export class LogRocketService {
  private logRocket;

  constructor(private ngZone: NgZone) {}

  init() {
    this.ngZone.runOutsideAngular(() => {
      this.logRocket = LRSetup({
        sdkServer: environment.LogRocketEndPoint,
        ingestServer: environment.LogRocketEndPoint
      });
      this.logRocket.init(environment.LogRocketAppID, {
        dom: { baseHref: environment.logRocketBaseHref + version.appversion + '/' },
        console: {
          isEnabled: false
        }
      });
    });
  }

  identify(userId, userInfo) {
    if (this.logRocket) {
      this.logRocket.identify(userId, userInfo);
    }
  }
}
