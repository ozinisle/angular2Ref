import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MYBLUE } from '@app/app.constants';
import { AdobeAnalytics } from '../enums/adobe-analytics';
import { AnalyticsService } from './analytics.service';
import { ConstantsService } from './constants.service';

@Injectable({
  providedIn: 'root'
})
export class SwrveService {
  private endpointUrl: string = this.constantsService.updateSwrveIdUrl;

  constructor(private constantsService: ConstantsService, private http: HttpClient, private analyticsService: AnalyticsService) {}

  get swrveHandle(): any {
    const plugins = window['plugins'];
    return plugins && plugins.swrve ? plugins.swrve : null;
  }

  identifySwrveUserIdToBackend(id: string, cryptoToken: any) {
    if (this.swrveHandle == null) {
      return;
    }
    this.swrveHandle.getUserId(
      (userId: string) => {
        this.sendSwrveIdToBackend(userId, id, cryptoToken);
        this.analyticsService.setUser(userId);
        this.analyticsService.sendAnalytic(AdobeAnalytics.LOGIN);
      },
      failureResponse => {
        MYBLUE.error('Unable to optain Swrve User Id', failureResponse);
      }
    );
  }

  sendSwrveIdToBackend(swrveUserId: string, id: string, cryptoToken: any) {
    const payload = {
      useridin: id,
      memobject: [
        {
          memkeyname: 'swrveid',
          memkeyvalue: swrveUserId
        }
      ],
      key2id: cryptoToken.key2id
    };

    this.http.post(this.endpointUrl, payload).subscribe((response: any) => {});
  }

  identifyUserToSwrve(syntheticID: string) {
    if (this.swrveHandle == null) {
      return;
    }
    if (this.swrveHandle && this.swrveHandle.identify) {
      this.swrveHandle.identify(syntheticID);
    }
  }

  // name, event, success, fall
  sendAppMessage(event: string, payload: string = '') {
    if (this.swrveHandle == null) {
      return;
    }

    this.swrveHandle.event(event, payload);
  }
}

@Injectable({
  providedIn: 'root'
})
export class SwrveEventNames {
  public readonly appScreenContactUs: string = 'appScreen.ContactUs';
  public readonly appScreenForgotPassword: string = 'appScreen.ForgotPassword';
  public readonly appScreenForgotPasswordCreateNewPassword: string = 'appScreen.ForgotPassword.CreateNewPassword';
  public readonly appScreenForgotUsername: string = 'appScreen.ForgotUsername';
  public readonly appScreenForgotUsernameConfirmIdentity: string = 'appScreen.ForgotUsername.ConfirmIdentity';
  public readonly appScreenMigrationChangePassword: string = 'appScreen.MigrationChangePassword';
  public readonly appScreenMigrationComplete: string = 'appScreen.MigrationComplete';
  public readonly appScreenMigrationConfirmation: string = 'appScreen.MigrationConfirmation';
  public readonly appScreenMigrationStart: string = 'appScreen.MigrationStart';
  public readonly appScreenMigrationVerificationCode: string = 'appScreen.MigrationVerificationCode';
  public readonly appScreenMigrationVerificationCodeFailure: string = 'appScreen.MigrationVerificationCodeFailure';
  public readonly appScreenMigrationVerificationCodeSuccess: string = 'appScreen.MigrationVerificationCodeSuccess';
  public readonly appScreenMigrationVerificationEmailChanged: string = 'appScreen.MigrationVerificationEmailChanged';
  public readonly appScreenMyCards: string = 'appScreen.MyCards';
  public readonly appScreenMyClaims: string = 'appScreen.MyClaims';
  public readonly appScreenMyClaimsClaimDetails: string = 'appScreen.MyClaims.ClaimDetails';
  public readonly appScreenMyClaimsClaimForm: string = 'appScreen.MyClaims.ClaimForm';
  public readonly appScreenMyDoctors: string = 'appScreen.MyDoctors';
  public readonly appScreenMyMedications: string = 'appScreen.MyMedications';
  public readonly appScreenMyPlan: string = 'appScreen.MyPlan';
  public readonly appScreenSignIn: string = 'appScreen.SignIn';

  public readonly appScreenMyInbox: string = 'appScreen.MyInbox'; //
  public readonly appScreenMyInboxViewMessage: string = 'appScreen.MyInbox.ViewMessage'; //
  public readonly appScreenMyInboxViewMessageViewMessageDetails: string = 'appScreen.MyInbox.ViewMessage.ViewMessageDetails'; //
  public readonly appScreenMyInboxViewDocuments: string = 'appScreen.MyInbox.ViewDocuments'; //

  //1
  public readonly appScreenMyInboxViewDocumentsPlanDetailsLists: string = 'appScreen.MyInbox.ViewDocuments.PlanDetailsLists'; //
  //1.1
  public readonly appScreenMyInboxPlanDetailsListsBenefitLists: string = 'appScreen.MyInbox.PlanDetailsLists.BenefitLists'; //
  //1.1.1
  public readonly appScreenMyInboxBenefitListsOverallPlanLists: string = 'appScreen.MyInbox.BenefitLists.OverallPlanLists'; //
  //1.1.1.1.
  public readonly appScreenMyInboxBenefitListsDocumentsDetails: string = 'appScreen.MyInbox.BenefitLists.DocumentsLists'; //

  //1.1.2
  public readonly appScreenMyInboxBenefitListsDocumentsLists: string = 'appClappScreenick.MyInbox.BenefitLists.DocumentsLists'; //

  //2
  public readonly appScreenMyInboxViewDocumentsEobLists: string = 'appScreen.MyInbox.ViewDocuments.EobLists'; //

  public readonly appScreenMyInboxViewNotificationsAlerts: string = 'appScreen.MyInbox.ViewNotificationsalerts'; //
  public readonly appScreenMyInboxViewNotificationsAlertsViewNotificationsAlertsDetails: string =
    'appScreen.MyInboxViewNotificationsalertsViewNotificationsalertsDetails'; //

  // Brooks auth, Contact up, Header
  public readonly appClickAuthenticationSubmittedSSN: string = 'appClick.authentication.SubmittedSSN';
  public readonly appClickAuthenticationSubmittedMedicareID: string = 'appClick.authentication.appClickauthenticationSubmittedMedicareID';
  public readonly appClickAuthenticationSubmittedStudentID: string = 'appClick.authentication.SubmittedStudentID';
  public readonly appClickAuthenticationSubmittedToLexisNexis: string = 'appClick.authentication.SubmittedToLexisNexis';

  // dupes? asked business for clarification
  public readonly appClickContactUsBehavioralHealth8004442426: string = 'appClick.ContactUs.BehavioralHealth800-444-2426';

  public readonly appClickContactUsBlueCareNurseLine8882472583: string = 'appClick.ContactUs.BlueCareNurseLine888-247-2583';
  public readonly appClickContactUsMailServicePharmacy8008925119: string = 'appClick.ContactUs.MailServicePharmacy800-892-5119';
  public readonly appClickContactUsMain8002622583: string = 'appClick.ContactUs.Main800-262-2583';

  // anuj Home
  public readonly appClickHomeAnonymousContactUs: string = 'appClick.Homeanonymous.ContactUs';
  public readonly appClickHomeAnonymousFindADoctor: string = 'appClick.Homeanonymous.FindaDoctor';
  public readonly appClickHomeAuthenticatedContactUs: string = 'appClick.Homeauthenticated.ContactUs';
  public readonly appClickHomeAuthenticatedFindADoctor: string = 'appClick.Homeauthenticated.FindaDoctor';
  public readonly appClickHomeRegisteredContactUs: string = 'appClick.HomeRegistered.ContactUs';
  public readonly appClickHomeRegisteredFindADoctor: string = 'appClick.HomeRegistered.FindaDoctor';
  public readonly appClickMenuContactUs: string = 'appClick.Menu.ContactUs';
  public readonly appClickMenuFindaDoctor: string = 'appClick.Menu.FindaDoctor';

  //public  readonly appClickMenuFitness: string = 'appClick.Menu.Fitness';
  public readonly appClickHomeAnonymousFitness: string = 'appClick.Homeanonymous.Fitness';
  public readonly appClickHomeAuthenticatedFitness: string = 'appClick.Homeauthenticated.Fitness';
  public readonly appClickHomeAnonymousAHealthyMe: string = 'appClick.Homeanonymous.aHealthyMe';
  public readonly appClickHomeAuthenticatedAHealthyMe: string = 'appClick.Homeauthenticated.aHealthyMe';

  //UK Message Center
  public readonly appClickMessageCenterDeleteMessage: string = 'appClick.MessageCenter.DeleteMessage';

  // UK My Inbox
  public readonly appClickMenuMyInbox: string = 'appClick.Menu.MyInbox'; //
  public readonly appClickMyInboxViewMessage: string = 'appClick.MyInbox.ViewMessage'; //
  public readonly appClickMyInboxViewMessageViewMessageDetails: string = 'appClick.MyInbox.ViewMessage.ViewMessageDetails'; //

  public readonly appClickMyInboxViewDocuments: string = 'appClick.MyInbox.ViewDocuments'; //
  //1
  public readonly appClickMyInboxViewDocumentsPlanDetailsLists: string = 'appClick.MyInbox.ViewDocuments.PlanDetailsLists'; //
  //1.1
  public readonly appClickMyInboxPlanDetailsListsBenefitLists: string = 'appClick.MyInbox.PlanDetailsLists.BenefitLists'; //
  //1.1.1
  public readonly appClickMyInboxBenefitListsOverallPlanLists: string = 'appClick.MyInbox.BenefitLists.OverallPlanLists'; //
  //1.1.1.1.
  public readonly appClickMyInboxBenefitListsDocumentsDetails: string = 'appClick.MyInbox.BenefitLists.DocumentsLists'; //

  //1.1.2
  public readonly appClickMyInboxBenefitListsDocumentsLists: string = 'appClick.MyInbox.BenefitLists.DocumentsLists'; //

  //2
  public readonly appClickMyInboxViewDocumentsEobLists: string = 'appClick.MyInbox.ViewDocuments.EobLists'; //
  //2.1
  public readonly appClickMyInboxViewDocumentsEobDetails: string = 'appClick.MyInbox.ViewDocuments.EobDetails'; //

  public readonly appClickMyInboxViewNotificationsAlerts: string = 'appClick.MyInbox.ViewNotificationsAlerts'; //
  public readonly appViewNotificationsAlertsDetails: string = 'appClick.ViewNotificationsAlertsDetails';

  //Marcel My Cards
  public readonly appClickMyCardsDownloadCard: string = 'appClick.MyCards.DownloadCard';
  public readonly appClickMyCardsEmailCard: string = 'appClick.MyCards.EmailCard';
  //anuj Claims
  public readonly appClickMyClaimsSearch: string = 'appClick.MyClaims.Search';
  public readonly appClickMyClaimsViewClaim: string = 'appClick.MyClaims.ViewClaim';
  public readonly appClickMyClaimsClaimForm: string = 'appClick.MyClaims.ClaimForm';
  //My Doctors
  public readonly appClickMyDoctorsCall: string = 'appClick.MyDoctors.Call';
  public readonly appClickMyDoctorsMap: string = 'appClick.MyDoctors.Map';
  public readonly appClickMyDoctorsViewClaim: string = 'appClick.MyDoctors.ViewClaim';
  public readonly appClickMyDoctorsViewHistory: string = 'appClick.MyDoctors.ViewHistory';
  //UK My Medications
  public readonly appClickMyMedicationsCall: string = 'appClick.MyMedications.Call';
  public readonly appClickMyMedicationsMap: string = 'appClick.MyMedications.Map';
  public readonly appClickMyMedicationsViewHistory: string = 'appClick.MyMedications.ViewHistory';
  //Marcel MyPlan
  public readonly appScreenFADLandingScreen: string = 'appScreen.FaD.Landing';
  public readonly appScreenFADSearchResultScreen: string = 'appScreen.FaD.SearchResult';
  public readonly appScreenFADFacilityProfile: string = 'appScreen.FaD.FacilityProfile';
  public readonly appScreenFADDoctorProfile: string = 'appScreen.FaD.DoctorProfile';

  //KLO-2602 Login Authentication Status
  public readonly appScreenHomeAnonymous: string = 'appScreen.HomeAnonymous';
  public readonly appScreenHomeRegistered: string = 'appScreen.HomeRegistered';
  public readonly appScreenHomeAuthenticated: string = 'appScreen.HomeAuthenticated';

  //Personalized Welcome Kit
  public readonly appScreenWelcomeKit: string = 'appScreen.WelcomeKit';
}
