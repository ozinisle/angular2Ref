import { Injectable } from '@angular/core';
import { MYBLUE } from '@app/app.constants';
import { ScheduleContext } from '@app/models/telehealth.model';
import { VisitFailed, VisitStarted, VisitSuccess } from '@app/pages/guest-visit/store/actions/guest-visit.actions';
import { DeclineTransfer, PostVisitTransfer, SelectProvider, StartVisit, SuggestedTransfer, UpdatePatientAheadCount, VisitEnded, VisitValidationFailed } from '@app/pages/virtual-visit/store/actions/telehealth.actions';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { Plugins } from '@capacitor/core';
import { environment } from '@environments/environment';
import { Platform } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Store } from '@ngxs/store';
import {
  Address,
  AppointmentProvider,
  Consumer,
  ConsumerAllergy,
  ConsumerCondition,
  ConsumerDocument,
  ConsumerVitals,
  DeclineAndTransferVisitEndEvent,
  InitOptionsAndroid,
  InitOptionsIos,
  InitOptionsWeb,
  MatchmakingResultEvent,
  Medication,
  OptionalConsumerOptions,
  PatientsAheadCountChangedEvent,
  PaymentMethod,
  PaymentMethodRequest,
  Pharmacy,
  PluginEvent,
  PluginEventType,
  PostVisitTransferVisitEndEvent,
  Practice,
  Provider,
  ProviderDetails,
  StartGuestVisitOptions,
  SuggestedTransferEvent,
  TelehealthMailboxType,
  TelehealthMessageDraft,
  TelehealthMessageDraftOptions,
  TelehealthMessageOptions,
  UpdateConsumerOptions,
  VisitContext,
  VisitEndEvent,
  VisitEndReason,
  VisitSummary
} from 'amwell-plugin/';
import {
  BehaviorSubject,
  from,
  Observable
} from 'rxjs';
import {
  map,
  tap
} from 'rxjs/operators';


const { AmwellPlugin } = Plugins;

/*
 * Index:
 * - Initialization
 * - Authentication
 * - Consumer
 * - Legal Documents
 * - Practice
 * - Miscellaneous
 */
@Injectable({
  providedIn: 'root',
})
export class AmwellService {

  private initializeCall: Observable<boolean>;

  @SelectSnapshot(AppSelectors.getAppPackageName) bundleId: string;

  private isAuthenticatedSubject: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private isInitializedSubject: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private selectedPracticeSubject: BehaviorSubject<Practice> = new BehaviorSubject(null);
  private selectedProviderSubject: BehaviorSubject<Provider> = new BehaviorSubject(null);

  /**
   * An Observable that reports whether the user is authenticated with the telehealth SDK.
   */
  public get isAuthenticated$(): Observable<boolean> {
    return this.isAuthenticatedSubject.asObservable();
  }

  /**
   * An Observable that reports the initialization status of the Amwell SDK.
   */
  public get isInitialized$(): Observable<boolean> {
    return this.isInitializedSubject.asObservable();
  }

  public get selectedPractice$(): Observable<Practice> {
    return this.selectedPracticeSubject.asObservable();
  }

  /**
   * An Observable that reports the user's selected provider for an
   * on-demand or scheduled visit.
   */
  public get selectedProvider$(): Observable<Provider> {
    return this.selectedProviderSubject.asObservable();
  }
  /**
   * Constructor.
   */
   constructor(private platform: Platform,
    private store: Store) {

    AmwellPlugin.addListener(
      PluginEventType.MATCHMAKING_RESULT,
      (event: MatchmakingResultEvent) => {
        if (event?.provider) {
          this.store.dispatch([new SelectProvider({...event.provider, availableTimeSlots: [] }), new StartVisit()]);
        }
      },
    );
    AmwellPlugin.addListener(
      PluginEventType.VISIT_CHAT,
      (event: PluginEvent) => {
        MYBLUE.log(`Event ${PluginEventType.VISIT_CHAT} was fired.`, event);
      }
    );

    AmwellPlugin.addListener(
      PluginEventType.VISIT_FAILURE,
      (event: PluginEvent) => {
        MYBLUE.log('Event ${PluginEventType.VISIT_FAILURE} was fired.', event);
      }
    );

    AmwellPlugin.addListener(
      PluginEventType.VISIT_PATIENTS_AHEAD_COUNT_CHANGED,
      (event: PatientsAheadCountChangedEvent) => {
        MYBLUE.log(`Event ${PluginEventType.VISIT_PATIENTS_AHEAD_COUNT_CHANGED} was fired.`, event);
        if (event.eventType === PluginEventType.VISIT_PATIENTS_AHEAD_COUNT_CHANGED) {
          this.store.dispatch(new UpdatePatientAheadCount(event.count));
        }
      }
    );

    AmwellPlugin.addListener(
      PluginEventType.VISIT_POLL_FAILURE,
      (event: PluginEvent) => {
        MYBLUE.log(`Event ${PluginEventType.VISIT_POLL_FAILURE} was fired.`, event);
      }
    );

    AmwellPlugin.addListener(
      PluginEventType.VISIT_PROVIDER_ENTERED,
      (event: PluginEvent) => {
        if (event.eventType !== PluginEventType.EMPTY) {
          this.store.dispatch(new UpdatePatientAheadCount(0));
        }
      }
    );

    AmwellPlugin.addListener(
      PluginEventType.VISIT_RESPONSE,
      (event: PluginEvent) => {
        MYBLUE.log(`Event ${PluginEventType.VISIT_RESPONSE} was fired.`, event);
      }
    );

    AmwellPlugin.addListener(
      PluginEventType.VISIT_SUGGESTED_FIND_FIRST_AVAILABLE,
      (event: PluginEvent) => {
        MYBLUE.log(`Event ${PluginEventType.VISIT_SUGGESTED_FIND_FIRST_AVAILABLE} was fired.`, event);
        //TODO : Is there any action needed
        //this.visitSuggestFindFirstAvailableEventSubject.next(event);
      }
    );

    AmwellPlugin.addListener(
      PluginEventType.VISIT_SUGGESTED_TRANSFER,
      (event: SuggestedTransferEvent) => {
        MYBLUE.log(`Event ${PluginEventType.VISIT_SUGGESTED_TRANSFER} was fired.`, event);
        this.store.dispatch(new SuggestedTransfer(event.transfer));
      }
    );

    AmwellPlugin.addListener(
      PluginEventType.VISIT_VALIDATION_FAILURE,
      (event: PluginEvent) => {
        MYBLUE.log(`Event ${PluginEventType.VISIT_VALIDATION_FAILURE} was fired.`, event);
        this.store.dispatch(new VisitValidationFailed());
      }
    );

    AmwellPlugin.addListener(
      PluginEventType.VISIT_ENDED,
      (event: VisitEndEvent) => {
        MYBLUE.log(`Event ${PluginEventType.VISIT_ENDED} was fired.`, JSON.stringify(event));
        switch (event.reason) {
          case VisitEndReason.ASSISTANT_DECLINE_AND_TRANSFER:
          case VisitEndReason.PROVIDER_DECLINE_AND_TRANSFER:
             this.store.dispatch(new DeclineTransfer((event as DeclineAndTransferVisitEndEvent).transfer));
             break;
          case VisitEndReason.POST_VISIT_TRANSFER:
            this.store.dispatch(new PostVisitTransfer((event as PostVisitTransferVisitEndEvent).transfer))
            break;
          default:
            MYBLUE.log(`Event Reason .`, event.reason);
            this.store.dispatch(new VisitEnded(event.reason));
        }
      }
    );

    AmwellPlugin.addListener(
      PluginEventType.CONFERENCE_STARTED,
      (event: PluginEvent) => {
        MYBLUE.log(`Event ${PluginEventType.CONFERENCE_STARTED} was fired.`, JSON.stringify(event))
        if (event.eventType !== PluginEventType.EMPTY) {
          this.store.dispatch(new VisitStarted());
        }
      }
    );

    AmwellPlugin.addListener(
      PluginEventType.CONFERENCE_FAILED,
      (event: PluginEvent) => {
        MYBLUE.log(`Event ${PluginEventType.CONFERENCE_FAILED} was fired.`, JSON.stringify(event));
        if (event.eventType !== PluginEventType.EMPTY) {
          this.store.dispatch(new VisitFailed());
        }
      }
    );

    AmwellPlugin.addListener(
      PluginEventType.CONFERENCE_FINISHED,
      (event: PluginEvent) => {
        MYBLUE.log(`Event ${PluginEventType.CONFERENCE_FINISHED} was fired.`, JSON.stringify(event));
        if (event.eventType !== PluginEventType.EMPTY) {
          this.store.dispatch(new VisitSuccess());
        }
      }
    );
   }

  // ------------------------------
  //  Initialization
  // ------------------------------

  /**
   * Initializes the Amwell SDK if not already initialized.
   *
   * @returns An Observable that resolves to ```true``` upon success.
   */
  public initialize(launchUrl?: string): Observable<boolean> {

    let initParams:  InitOptionsAndroid | InitOptionsIos | InitOptionsWeb;

    if (this.platform.is('android')) {
      const androidParams: InitOptionsAndroid = {
        baseServiceUrl: environment.amwellBaseUrl,
        apiKey: environment.amwellAPIKey,
        launchUrl: launchUrl || '',
        // launchIntentData: '',
        // callerId: '',
      };
      initParams = androidParams;
    } else if (this.platform.is('ios')) {
      const iosParams: InitOptionsIos = {
        baseServiceUrl: environment.amwellBaseUrl,
        apiKey: environment.amwellAPIKey,
        bundleId: this.bundleId || environment.bundleId,
        launchUrl: launchUrl || '',
      };
      initParams = iosParams;
    } else {
      /* We're not planning on using the web SDK at this time. */
      const webParams: InitOptionsWeb = {
        baseServiceUrl: environment.amwellBaseUrl,
        apiKey: environment.amwellAPIKey
      };
      initParams = webParams;
    }
    MYBLUE.log("Init Params ", initParams);

    this.initializeCall = from(AmwellPlugin.initialize(initParams)).pipe(
      tap(() => this.isInitializedSubject.next(true)),
      map(() => true)
    );
    return this.initializeCall;
  }

  // ------------------------------
  //  Authentication
  // ------------------------------

  public authenticate(consumerAuthKey: string): Observable<boolean> {
    this.isAuthenticatedSubject.next(false);
    return from(AmwellPlugin.authenticate({ consumerAuthKey })).pipe(
      map((res) => res.value),
      tap((isAuthenticated) => this.isAuthenticatedSubject.next(isAuthenticated))
    );
  }

  // ------------------------------
  //  Consumer
  // ------------------------------

  // ------------------------------
  //  Legal Documents
  // ------------------------------

  public fetchLegalTextBody(legalTextId: string) {
    return from(AmwellPlugin.fetchLegalTextBody({ legalTextId })).pipe(
      map(res => res.value)
    );
  }

  public acceptOutstandingDisclaimer(): Observable<boolean> {
    return from(AmwellPlugin.acceptOutstandingDisclaimer()).pipe(map((res) => res.value));
  }

  public fetchOutstandingDisclaimer(): Observable<string | null> {
    return from(AmwellPlugin.fetchOutstandingDisclaimer()).pipe(map((res) => res.value));
  }

  public fetchEnrollmentDisclaimer(): Observable<string | null> {
    return from(AmwellPlugin.fetchEnrollmentDisclaimer()).pipe(map((res) => res.value));
  }

  public getPractices(): Observable<Practice[] | null> {
    return from(AmwellPlugin.fetchPractices()).pipe(map((res) => res.value));
  }

  public selectPractice(practice: Practice) {
    this.selectedPracticeSubject.next(practice);
  }

  // ------------------------------
  //  Medications
  // ------------------------------

  public findMedications(startingWith: string) {
    return from(AmwellPlugin.findMedications({ startingWith })).pipe(
      map(res => {
        return res.value;
      })
    );
  }

  public fetchProviderDetails(providerSourceId: string): Observable<ProviderDetails> {
    return from(AmwellPlugin.fetchProviderDetails({ providerSourceId })).pipe(
      map(res => res.value)
    );
  }
  // ------------------------------
  //  Practice
  // ------------------------------

  // ------------------------------
  //  Provider
  // ------------------------------

  public findProviders(practiceSourceId, stateCode): Observable<Provider[]> {
    return from(AmwellPlugin.findProviders({
      consumerSourceId: null,
      practiceSourceId,
      stateCode
    })).pipe(
      map(res => res.value)
    );
  }

  public findAppointmentProviders(practiceSourceId: string, stateCode: string, availableOnDate: string): Observable<AppointmentProvider[]> {
    return from(AmwellPlugin.findAppointmentProviders({
      consumerSourceId: null,
      practiceSourceId,
      stateCode,
      availableOnDate
    })).pipe(
      map(res => res.value)
    );
  }

  public findProviderAvailabilityByDate(providerSourceId: string, date: string): Observable<string[]> {
    return from(AmwellPlugin.fetchAppointmentProviderAvailability({
      providerSourceId,
      date
    })).pipe(
      map(res => res.value)
    );
  }

  public selectProvider(provider: Provider) {
    this.selectedProviderSubject.next(provider);
  }

  public buildVisitContext(
    practiceSourceId: string,
    providerSourceId: string,
    appointmentSourceId: string,
    consumerSourceId?: string
    ): Observable<VisitContext> {
    return from(
      AmwellPlugin.buildVisitContext({
        consumerSourceId,
        practiceSourceId,
        providerSourceId,
        appointmentSourceId
      }),
    ).pipe(
      map(res => res.value)
    );
  }

  public fetchConsumer(options?: OptionalConsumerOptions): Observable<Consumer> {
    return from(AmwellPlugin.fetchConsumer(options)).pipe(
      map(res => res.value)
    );
  }

  public fetchConsumerDependents(): Observable<Consumer[]> {
    return from(AmwellPlugin.fetchConsumerDependents()).pipe(
      map(res => res.value)
    );
  }

  public fetchConsumerContitions(options: OptionalConsumerOptions): Observable<ConsumerCondition[]> {
    return from(AmwellPlugin.fetchConsumerConditions(options)).pipe(
      map(res => res.value)
    );
  }

  public fetchConsumerAllergies(options: OptionalConsumerOptions): Observable<ConsumerAllergy[]> {
    return from(AmwellPlugin.fetchConsumerAllergies(options)).pipe(
      map(res => res.value)
    );
  }

  public fetchConsumerVitals(options: OptionalConsumerOptions): Observable<ConsumerVitals> {
    return from(AmwellPlugin.fetchConsumerVitals(options)).pipe(
      map(res => res.value)
    );
  }

  public addConsumerDocument(options: OptionalConsumerOptions): Observable<boolean> {
    return from(AmwellPlugin.addConsumerDocument(options)).pipe(
      map(res => res.value)
    );
  }

  public removeConsumerDocument(sourceId: string): Observable<boolean> {
    return from(AmwellPlugin.removeConsumerDocument({ sourceId })).pipe(
      map(res => res.value)
    );
  }

  public fetchConsumerDocuments(options: OptionalConsumerOptions): Observable<ConsumerDocument[]> {
    return from(AmwellPlugin.fetchConsumerDocuments(options)).pipe(
      map(res => res.value)
    );
  }

  public fetchConsumerMedications(options: OptionalConsumerOptions): Observable<Medication[]> {
    return from(AmwellPlugin.fetchConsumerMedications(options)).pipe(
      map(res => res.value)
    );
  }

  public updateConsumerAllergies(allergies: ConsumerAllergy[], consumerSourceId: string): Observable<boolean> {
    return from(AmwellPlugin.updateConsumerAllergies({ allergies, consumerSourceId })).pipe(
      map(res => res.value)
    );
  }

  public updateConsumerConditions(conditions: ConsumerCondition[], consumerSourceId: string): Observable<boolean> {
    return from(AmwellPlugin.updateConsumerConditions({ conditions, consumerSourceId })).pipe(
      map(res => res.value)
    );
  }

  public updateConsumerMedications(medications: Medication[], consumerSourceId: string): Observable<boolean> {
    return from(AmwellPlugin.updateConsumerMedications({ medications, consumerSourceId })).pipe(
      map(res => res.value)
    );
  }

  public updateConsumerVitals(vitals: ConsumerVitals, consumerSourceId: string): Observable<boolean> {
    return from(AmwellPlugin.updateConsumerVitals({ vitals, consumerSourceId })).pipe(
      map(res => res.value)
    );
  }

  //------------
  // Pharmacy
  //-----------

  public fetchConsumerPharmacy(): Observable<Pharmacy> {
    return from(AmwellPlugin.fetchConsumerPharmacy()).pipe(
      map(res => res.value)
    );
  }

  public fetchConsumerShippingAddress(): Observable<Address> {
    return from(AmwellPlugin.fetchConsumerShippingAddress()).pipe(
      map(res => res.value)
    );
  }

  public fetchConsumerPaymentMethod(): Observable<PaymentMethod> {
    return from(AmwellPlugin.fetchConsumerPaymentMethod()).pipe(
      map(res => res.value)
    );
  }

  public findEnrollmentStates(countryCode: string) {
    return from(AmwellPlugin.findEnrollmentStatesForCountry({
      countryCode
    })).pipe(
      map(res => res.value)
    );
  }

  public findPharmaciesWithZipCode(zipCode: string) {
    return from(AmwellPlugin.findPharmaciesWithZipCode({ zipCode })).pipe(
      map(res => {
        return res.value;
      })
    );
  }

  public findPharmaciesInRegion(latitude: number, longitude: number, radius: number) {
    return from(AmwellPlugin.findPharmaciesInRegion({ latitude, longitude, radius })).pipe(
      map(res => {
        return res.value;
      })
    );
  }

  public findShippingStatesForCountry(countryCode: string) {
    return from(AmwellPlugin.findShippingStatesForCountry({ countryCode })).pipe(
      map(res => {
        return res.value;
      })
    );
  }

  public updateConsumerPharmacy(pharmacyId: string): Observable<boolean> {
    return from(AmwellPlugin.updateConsumerPharmacy({ pharmacyId })).pipe(
      map(res => res.value)
    );
  }

  public updateConsumerShippingAddress(address: Address): Observable<boolean> {
    return from(AmwellPlugin.updateConsumerShippingAddress({ address })).pipe(
      map(res => res.value)
    );
  }
  // ------------------------------
  //  Payment
  // ------------------------------

  public applyCouponCode(couponCode: string) {
    return from(AmwellPlugin.applyCouponCode({ couponCode })).pipe(
      map(res => res.value)
    );
  }

  public updateConsumerPaymentMethod(paymentMethodRequest: PaymentMethodRequest): Observable<boolean> {
    return from(AmwellPlugin.updateConsumerPaymentMethod({ paymentMethodRequest })).pipe(
      map(res => res.value)
    );
  }

  //--------------------
  //  Visit
  //--------------------

  public buildVisit(visitContext) {
    return from(AmwellPlugin.buildVisit({visitContext })).pipe(
      map(res =>  res.value)
    );
  }

  public startVisit() {
    return from(AmwellPlugin.startVisit()).pipe(
      map(res => res.value)
    );
  }

  public acceptSuggestedTransfer() {
    return from(AmwellPlugin.acceptSuggestedTransfer()).pipe(
      map(res => res.value)
    );
  }

  public declineSuggestedTransfer(shouldStopSuggestions) {
    return from(AmwellPlugin.declineTransfer({shouldStopSuggestions})).pipe(
      map(res => res.value)
    );
  }

  public acceptDeclineAndTransfer() {
    return from(AmwellPlugin.acceptDeclineAndTransfer()).pipe(
      map(res => res.value)
    );
  }

  public acceptPostVisitTransfer() {
    return from(AmwellPlugin.acceptPostVisitTransfer()).pipe(
      map(res => res.value)
    );
  }

  public acceptSuggestedVisitTransfer() {
    return from(AmwellPlugin.acceptSuggestedTransfer()).pipe(
      map(res => res.value)
    );
  }

  public cancelVisit() {
    return from(AmwellPlugin.cancelVisit()).pipe(
      map(res => res.value)
    );
  }

  public fetchVisitSummary(): Observable<VisitSummary> {
    return from(AmwellPlugin.fetchVisitSummary()).pipe(
      map(res => res.value)
    );
  }

  public submitVisitFeedback(selectedOption: string) {
    return from(AmwellPlugin.submitVisitFeedback({
      selectedOption
    })).pipe(
      map(res => res.value)
    );
  }

  public shareVisitSummary(
    emails: string[],
    faxes: string[],
    isHipaaNoticeAccepted: boolean,
  ) {
    return from(AmwellPlugin.shareVisitSummary({
      emails,
      faxes,
      isHipaaNoticeAccepted
    })).pipe(
      map(res => res.value)
    );
  }

  public submitVisitRatings(providerRating: number, visitRating: number) {
    return from(AmwellPlugin.submitVisitRatings({
      providerRating,
      visitRating
    })).pipe(
      map(res => res.value)
    );
  }

  public startMatchmaking() {
    return from(AmwellPlugin.startMatchmaking()).pipe(map(res => res.value));
  }

  public fetchAppointemnts(consumerSourceId: string, startingFromDate: string) {
    return from(AmwellPlugin.findAppointments({
      consumerSourceId,
      startingFromDate
    })).pipe(map(res => res.value));
  }

  public bookAppointemnt(scheduleContext: ScheduleContext) {
    return from(AmwellPlugin.scheduleAppointment(scheduleContext)).pipe(map(res => res.value));
  }

  public cancelAppointemnt(appointmentSourceId: string) {
    return from(AmwellPlugin.cancelAppointment({
      appointmentSourceId
    })).pipe(map(res => res.value));
  }

  public fetchMailbox(mailboxType: TelehealthMailboxType) {
    return from(AmwellPlugin.fetchMailbox({mailboxType})).pipe(map(res => res.value));
  }

  public fetchMessage(options: TelehealthMessageOptions) {
    return from(AmwellPlugin.fetchMessage(options)).pipe(map(res => res.value));
  }

  public markMessageAsRead(options: TelehealthMessageOptions) {
    return from(AmwellPlugin.markMessageAsRead(options)).pipe(map(res => res.value));
  }

  public fetchMessageContacts() {
    return from(AmwellPlugin.fetchMessageContacts()).pipe(map(res => res.value));
  }

  public fetchMessageTopics() {
    return from(AmwellPlugin.fetchMessageTopics()).pipe(map(res => res.value));
  }

  public buildMessageDraft(options: TelehealthMessageDraftOptions) {
    return from(AmwellPlugin.buildMessageDraft(options)).pipe(map(res => res.value));
  }

  public sendMessage(draft: TelehealthMessageDraft) {
    return from(AmwellPlugin.sendMessage({draft})).pipe(map(res => res.value));
  }

  public addMessageDraftAttachment(messageDraftId: string) {
    return from(AmwellPlugin.addMessageDraftAttachment({messageDraftId})).pipe(
      map(res => res.value),
    );
  }

  public removeMessageDraftAttachment(messageDraftId: string) {
    return from(AmwellPlugin.removeMessageDraftAttachment({messageDraftId})).pipe(
      map(res => res.value),
    );
  }

  public getMessageAttachment(attachmentId: string) {
    return from(AmwellPlugin.viewMessageAttachment({attachmentId})).pipe(
      map(res => res.value),
    );
  }

  public deleteMessage(options: TelehealthMessageOptions) {
    return from(AmwellPlugin.deleteMessage(options)).pipe(
      map(res => res.value),
    );
  }

  public updateConsumer(options: UpdateConsumerOptions) {
    return from(AmwellPlugin.updateConsumer(options)).pipe(
      map(res => res.value),
    );
  }

  public startGuestVisit(options: StartGuestVisitOptions) {
    return from(AmwellPlugin.startGuestVisit(options)).pipe(
      map(res => res.value),
    );
  }
}
