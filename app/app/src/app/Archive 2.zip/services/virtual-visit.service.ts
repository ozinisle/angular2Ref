import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { CryptoModel } from '@app/models/crypto.model';
import { ConstantsService } from '@app/services/constants.service';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';

interface MutualAuthenticationResponse {
  result: number;
  errormessage: string;
  displaymessage: string;
  userAccessToken: string;
  sdkKey: string;
}

@Injectable({ providedIn: 'root' })
export class VirtualVisitService {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getCryptoToken) cryptoTokens: CryptoModel;

  constructor(private http: HttpClient, private constantsService: ConstantsService) {}

  updateEnrollment(disclaimerFlag: boolean) {
    const generatedRequest = {
      useridin: this.useridin,
      channelId: 'MOBILE',
      disclaimerFlag: disclaimerFlag,
    };
    return this.http.post(this.constantsService.telehealthUpdateEnrollmentUrl, generatedRequest);
  }

  public fetchConsumerAuthKey(): Observable<string> {
    const generatedRequest = {
      useridin: this.useridin,
      channel: 'MOBILE',
    };
    return this.http.post<MutualAuthenticationResponse>(this.constantsService.telehealthFetchConsumerAuthKeyUrl, generatedRequest).pipe(
      map((response) => {
        if (response.errormessage) {
          throw new Error(response.errormessage);
        }
        return response.userAccessToken;
      })
    );
  }
}
