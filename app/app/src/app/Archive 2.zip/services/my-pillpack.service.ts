import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { of as observableOf } from 'rxjs';
import { map } from 'rxjs/operators';
import { RecentRxRequestModel, RecentRxResponseModel } from '@app/pages/my-medication/models/recent-rx.model';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { ConstantsService } from './constants.service';
import { AppService } from '@app/services/app.service';

@Injectable({ providedIn: 'root' })
export class MyPillpackService {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  constructor(private http: HttpClient, private appService: AppService, private constants: ConstantsService) {}

  getVitaminsAndOTC(query: string) {
    const vitaminsAndOtcs = this.getVitaminsAndOTCLocalObject();
    const otcs = vitaminsAndOtcs ? JSON.parse(vitaminsAndOtcs).otcs : [];
    // tslint:disable-next-line:no-shadowed-variable
    const otcsr = otcs.filter(otcs => otcs.name.toLowerCase().indexOf(query.toLowerCase()) > -1);
    const otcsu = [];
    otcsr.forEach((item, index) => {
      if (otcsu.indexOf(item.name) === -1) {
        otcsu.push(item.name);
      }
    });

    return observableOf(otcsu);
  }

  getDiscountedVitaminsAndOTCs() {
    const vitaminsAndOtcs = this.getVitaminsAndOTCLocalObject();
    const otcs = vitaminsAndOtcs ? JSON.parse(vitaminsAndOtcs).otcs : [];
    // tslint:disable-next-line:no-shadowed-variable
    const otcsr = otcs.filter(otcs => otcs.isDiscounted === true);
    const otcsu = [];
    otcsr.forEach((item, index) => {
      if (otcsu.indexOf(item.name) === -1) {
        otcsu.push(item.name);
      }
    });
    return otcsu;
  }

  getSelectedVitaminsAndOTC(query: string, isDiscounted?: boolean) {
    const vitaminsAndOtcs = this.getVitaminsAndOTCLocalObject();
    let otcs = vitaminsAndOtcs ? JSON.parse(vitaminsAndOtcs).otcs : [];
    if (isDiscounted) {
      otcs = otcs.filter(otcs => otcs.name.toLowerCase() === query.toLowerCase() && otcs.isDiscounted === true);
    } else {
      otcs = otcs.filter(otcs => otcs.name.toLowerCase() === query.toLowerCase());
    }

    return otcs;
  }

  async createPharmacyUser() {
    const req = {
      useridin: this.useridin
    };

    return this.http.post(this.constants.createPharmacyUserUrl, req).toPromise();
  }

  async addMedications(req) {
    return this.http.post(this.constants.addMedicationsUrl, req).toPromise();
  }

  updatePharmacyUser(req: any) {
    return this.http.post(this.constants.updatePharmacyUserUrl, req);
  }

  async completePillPackHandoff(req) {
    return this.http.post(this.constants.completePillPackHandoff, req).toPromise();
  }

  getMedicationsForSelf() {
    const handleResponse = response => {
      if (response.result < 0) {
        return new RecentRxResponseModel();
      } else {
        return response.rxSummary as RecentRxResponseModel;
      }
    };

    const request = new RecentRxRequestModel();
    request.useridin = this.useridin;
    return this.http.post(this.constants.recentRxMedicationsUrl, request).pipe(map(handleResponse));
  }

  getVitaminsAndOTCLocalObject() {
    if (!sessionStorage.getItem('vitaminsAndOTCs')) {
      this.appService.getVitaminsAndOTCs(this.useridin).subscribe(response => {
        if (response) {
          sessionStorage.setItem('vitaminsAndOTCs', JSON.stringify(response));
          return sessionStorage.getItem('vitaminsAndOTCs');
        } else {
          return '';
        }
      });
    } else {
      return sessionStorage.getItem('vitaminsAndOTCs');
    }
  }
}
