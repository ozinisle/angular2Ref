import { Injectable } from '@angular/core';
import { ConstantsService } from './constants.service';
import { HeaderInboxUnreadMsgCountReponse } from '../models/header.model';

@Injectable({ providedIn: 'root' })
export class HeaderService {
  public inbox: HeaderInboxUnreadMsgCountReponse;
  public drupalsecureinquiry: string;

  constructor(private constants: ConstantsService) {
    this.inbox = new HeaderInboxUnreadMsgCountReponse();
    this.drupalsecureinquiry = this.constants.drupalsecureinquiry;
  }

  set unReadMsgCount(count: any) {
    sessionStorage.setItem('inboxUnreadMsgCount', count);
  }

  get unReadMsgCount() {
    return parseInt(sessionStorage.getItem('inboxUnreadMsgCount') || '0', 10);
  }
}
