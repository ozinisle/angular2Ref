import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ConstantsService } from './constants.service';
import { encryptPayload } from '../utils/app.utils';
import { CryptoModel } from '@app/models/crypto.model';
import { throwError as observableThrowError } from 'rxjs/internal/observable/throwError';
import { AlertService } from '@app/services/alert.service';
import { AnalyticsService } from '@app/services/analytics.service';
import { format, parse } from 'date-fns';
import { FormGroup } from '@angular/forms';
import { BenefitSearchResultResponse } from '@app/models/benefit-search-result';
import { BenefitSearchEnabledResponse } from '@app/models/search.model';
import { v4 as uuid } from 'uuid';

@Injectable({
  providedIn: 'root'
})
export class AppService {
  httpOptions: any;
  constructor(
    private http: HttpClient,
    private alertService: AlertService,
    private analyticsService: AnalyticsService,
    private constantsService: ConstantsService
  ) {
    this.httpOptions = {
      headers: new HttpHeaders({
        'release-version': 'D2'
      })
    };
  }

  getTokens(): Observable<any> {
    return this.http.get(this.constantsService.tokenbaseurl + this.constantsService.tokensEndPoint);
  }

  refreshTokens(body): Observable<any> {
    return this.http.post(this.constantsService.refreshtokenurl, body);
  }

  register(request, cryptoToken: CryptoModel): Observable<any> {
    return this.http.post(this.constantsService.registerUserUrl, encryptPayload(request, cryptoToken, false), {
      headers: new HttpHeaders({
        uitxnid: 'APP_v5.0_' + uuid()
      })
    });
  }

  login(request, cryptoToken): Observable<any> {
    return this.http.post(this.constantsService.loginUserUrl, encryptPayload(request, cryptoToken, false));
  }

  postLogin(id): Observable<any> {
    return this.http.post(this.constantsService.getpostloginUrl, { useridin: id });
  }

  logout(): Observable<any> {
    return this.http.post(this.constantsService.logoutUrl, null);
  }

  validateUsername(useridin: string, type: string, key2id: string): Observable<any> {
    return this.http.post(this.constantsService.checkUserId, { useridin: useridin, regType: type, key2id: key2id });
  }

  updateConsent(request): Observable<any> {
    return this.http.post(this.constantsService.updateConsent, request);
  }

  getVitaminsAndOTCs(id: string) {
    return this.http.post(this.constantsService.getVitaminsandOtcsUrl, { useridin: id });
  }

  getdrupalconsent(): Observable<any> {
    return this.http.get(this.constantsService.getDrupalConsent);
  }

  getConfidentiality() {
    return this.http.get(this.constantsService.confidentiality);
  }

  getTermsAndConditions() {
    return this.http.get(this.constantsService.termsAndConditions);
  }

  getMemberAuthInfo(id: string) {
    return this.http.post(this.constantsService.memAuthUrl, { useridin: id });
  }

  verifyAccessCode(request: any) {
    return this.http.post(this.constantsService.verifyAccessCodeUrl, request);
  }

  sendCode(request: any) {
    return this.http.post(this.constantsService.sendaccesscodeUrl, request);
  }

  handleError(response, errorCodes = null, errorMsg?: boolean) {
    const responseJson = response;
    if (errorMsg) {
      if (errorCodes[responseJson.errormessage]) {
        this.alertService.setAlertObj(errorCodes[responseJson.errormessage], 'component');
        this.analyticsService.captureAPIErrorInAdobe('', errorCodes[responseJson.errormessage], '');
      } else {
        this.alertService.setError(responseJson.errormessage);
        this.analyticsService.captureAPIErrorInAdobe('', errorCodes[responseJson.errormessage], '');
      }
    } else if (errorCodes && responseJson && errorCodes[responseJson.displaymessage]) {
      this.alertService.setAlertObj(errorCodes[responseJson.displaymessage], 'component');
      this.analyticsService.captureAPIErrorInAdobe('', errorCodes[responseJson.displaymessage], '');
    } else {
      if (errorMsg) {
        this.alertService.setAlertObj(errorCodes[responseJson.errormessage], 'component');
        this.analyticsService.captureAPIErrorInAdobe('', errorCodes[responseJson.errormessage], '');
      } else if (responseJson) {
        this.alertService.setError(responseJson.displaymessage);
        this.analyticsService.captureAPIErrorInAdobe('', errorCodes[responseJson.displaymessage], '');
      } else {
        this.alertService.setError('Unexpected error');
      }
    }
    return observableThrowError(responseJson);
  }

  /**
   * Takes a string date and returns the date in ISO format and UTC timezone
   * @param localDate date formated as MM/dd/yyyy
   * @returns
   */
  getUTCDate(localDate: any): string {
   const dateUTC = localDate + " +0000";
   const dateUTCParsed = parse(dateUTC , "MM/dd/yyyy xx", new Date());
   const dateISOFormat = dateUTCParsed.toISOString().split('T')[0];

   return dateISOFormat;
  }


  markFormGroupTouched(formGroup: FormGroup) {
    let myObjects;
    myObjects = Object.keys(formGroup.controls).map(itm => formGroup.controls[itm]);
    myObjects.forEach(control => {
      control.markAsTouched();
      control.markAsDirty();
      if (control.controls) {
        control.controls.forEach(c => this.markFormGroupTouched(c));
      }
    });
  }

  isSearchEnabled(useridin: string): Observable<BenefitSearchEnabledResponse> {
    const request = {
      useridin,
      effectiveDate: format(new Date(), 'yyyy-MM-dd')
    };
    return this.http.post<BenefitSearchEnabledResponse>(this.constantsService.isBenefitSearchEnabled, request);
  }

  doBenefitSearch(payload): Observable<BenefitSearchResultResponse> {
    return this.http.post(this.constantsService.benefitsKeywordSearch, payload) as Observable<BenefitSearchResultResponse>;
  }
}
