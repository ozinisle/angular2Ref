import { Injectable } from '@angular/core';
import { InAppBrowser, InAppBrowserObject, InAppBrowserOptions } from '@ionic-native/in-app-browser/ngx';
import { Platform } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})
export class IabService {
  constructor(private inAppBrowser: InAppBrowser, private platform: Platform) {}

  public create(url: string, fromHomePage?: boolean): InAppBrowserObject {
    const browserOptions: InAppBrowserOptions = {
      hideurlbar: 'yes',
      location: 'no'
    };

    return this.platform.is('ipad') && fromHomePage
      ? this.inAppBrowser.create(url, '_system', browserOptions)
      : this.inAppBrowser.create(url, '_blank', browserOptions);
  }
}
