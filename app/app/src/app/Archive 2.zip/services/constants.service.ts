import { Injectable } from '@angular/core';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { Alert } from '@app/components/alerts/alert.model';
import { environment } from '@environments/environment';
import { DropDownValue } from '../models/dropdown-value.model';

@Injectable({ providedIn: 'root' })
export class ConstantsService {
  getMemberPlans: string;
  switchPlanAPI: string;
  coverageEffectiveDateFormat: string;
  displayMessage: object;
  tokenbaseurl: string;
  logoutUrl: string;
  memAuthUrl: string;
  verifyAccessCodeUrl: string;
  authWithSsnUrl: string;
  updateMemAuthInfoUrl: string;
  getDemoGraphicInfo: string;
  getmemprofile: string;
  getmemprofileV2: string;
  getmempreference: string;
  getBenefitsTextUrl: string;
  checkUserId: string;
  sendaccesscodeUrl: string;
  sendfunaccesscodeUrl: string;
  updatememprofile: string;
  updatemempreference: string;
  loginUserUrl: string;
  registerUserUrl: string;
  refreshtokenurl: string;
  verifyUserUrl: string;
  verifyUserAuthUrl: string;
  verifyRestAccessCodeUrl: string;
  verifyResetUrl: string;
  userNameVerify: string;
  identityVerify: string;
  resetPwd: string;
  privacyUrl: string;
  termsAndConditions: string;
  confidentiality: string;
  authStudentIDUrl: string;
  authMedicareIDUrl: string;
  tokensEndPoint: string;
  changepassword: string;
  authLnUrl: string;
  validateLnAnsUrl: string;
  postdesinfoUrl: string;
  sendCommChlAccesscode: string;
  verfiyCommChlAccesscode: string;
  sendUpdateNotification: string;
  memlookupUrl: string;
  memacctmergeUrl: string;
  drupalUrl: string;
  drupalMedicationsUrl: string;
  drupalDoctorsUrl: string;
  drupalClaimsUrl: string;
  drupalSliderUrl: string;
  updateDemographicInfoUrl: string;
  drupalClaimsrUrl: string;
  drupalMyPlansListingUrl: string;
  drupalMyPlansInformationUrl: string;
  drupalMyPlansFPOUrl: string;
  drupalMyPlansDetails: string;
  drupalMyPlansDetailsTooltipUrl: string;
  drupalMyBenefitsUrl: string;
  drupalMyBenefitsDetailsUrl: string;
  drupalNoClaimsrUrl: string;
  drupalContentInactiveWithFinancialsUrl: string;
  drupalContentInactiveNoFinancialsUrl: string;
  drupalsecureinquiry: string;
  drupalFinancialInfoUrl: string;
  drupalBannerPromoContentUrl: string;
  eyeMedBaseUrl: string;
  eyeMedNavLink: string;
  cvsOtcLink: string;
  eyeMedStartDate: Date;
  states: Array<DropDownValue>;
  languages: Array<DropDownValue>;
  ethnicities: Array<DropDownValue>;
  races: Array<DropDownValue>;
  serviceUrl: string;
  serviceUrlV2: string;
  serviceUrlV3: string;
  serviceUrlDigitalClaim: string;
  financeUrl: string;
  cardfrontUrl: string;
  cardbackUrl: string;
  dependentsUrl: string;
  getCardPageurl: string;
  orderIdcardurl: string;
  dependentlistRestrictedUrl: string;
  getPlansBenefitsListUrl: string;
  getPlanBenefitServicesUrl: string;
  getBenefitsCoverageUrl: string;
  getPlanBenefitDetailsUrl: string;
  getBenefitEnhancedDetailsUrl: string;
  getLimitationTextUrl: string;
  getFillingTextUrl: string;
  getAuthReferralUrl: string;
  getCOBTextUrl: string;
  getEligibilityTextUrl: string;
  getWordSearchUrl: string;
  getBenefitCoverageUrl: string;
  claimsforproviderUrl: string;
  claimsUrl: string;
  depClaimsUrl: string;
  claimdetailsUrl: string;
  claimProcessingStatusUrl: string;
  benefitsLinkUrl: string;
  claimsdepdetailsUrl: string;
  medicationsUrl: string;
  getMemBasicInfoUrl: string;
  getRequestEstimateUrl: string;
  submitrequestestimatedetailsUrl: string;
  depMedicationsUrl: string;
  claimsdaterangeUrl: string;
  medicationsDetailsUrl: string;
  depMedicationsDetailsUrl: string;
  depedentFrontUrl: string;
  depedentBackUrl: string;
  cardFrontFamily: string;
  getfamilycards: string;
  postCardImageToPDF: string;

  homepageUrl: string;
  getCommPreferenceUrl: string;
  updateCommPreferenceUrl: string;
  dedcoUrl: string;
  myDoctorListUrl: string;
  myDoctorDetailsUrl: string;
  myDepDoctorListUrl: string;
  myDepDoctorDetailsUrl: string;
  myDoctorInvalidPCPId: string;
  drupalDedCoDiagnosisCodeUrl: string;
  drupalDedCofaclityNPIUrl: string;
  drupalDedCoserviceProviderNPItUrl: string;
  drupalDedCoTooltipUrl: string;
  drupalContentCampaignUrl1: string;
  drupalContentCampaignUrl2: string;
  drupalContentCampaignUrl3: string;
  drupalContentCampaignUrl4: string;
  drupalContentCampaignUrl5: string;
  drupalContentCampaignUrl6: string;
  drupalContentSecureCampaignUrl1: string;
  drupalContentSecureCampaignUrl2: string;
  drupalContentSecureCampaignUrl3: string;
  drupalContentSecureCampaignUrl4: string;
  drupalContentSecureCampaignUrl5: string;
  drupalContentSecureCampaignUrl6: string;
  promoBlocks: string[];
  // add/change pcp
  getMemPlanInfo: string;
  getMemPlanDependents: string;
  getCodes: string;
  getPCPInfo: string;
  changePCP: string;
  drupalHomeUrl: string;
  contactus: string;
  educationCenter: string;
  drupalPCPUrl: string;
  pcpTierInfoUrl: string;
  drupalRELUrl: string;

  // Message Center (Inbox)
  msgListingUrl: string;
  msgDetailUrl: string;
  updateMsgListingAndMemAlertsUrl: string;

  // Notifications & Alerts (Inbox)
  notificationsListingUrl: string;
  notificationsDetailUrl: string;
  updateNotificationsAlertsUrl: string;

  // Deductibels
  getfamilydeductiblesUrl: string;
  getindividualdeductiblesUrl: string;

  // Documents
  getDocumentsRiderInfo: string;
  getDocumentsPlanInfo: string;

  drupalTargetNoResultsUrl: string;

  // myaccount
  myaccountUrl: string;
  cernerEEUrl = 'https://healthyblue2.bluecrossma.com/dt/v2/bcbsmaeeindex.asp';
  cernerMedicareUrl = 'https://www.ahealthyme-medicare.com/dt/v2/bcbsmamoindex.asp';
  directPayUrl = 'https://www.bcbsmaebilling.com/ebilling/login.do?type=/images/bcbsma&brand=bcbsma';
  wellConnectionUrl = 'https://myblue.bluecrossma.com/health-plan/well-connection';
  // Home page
  featureUrl = 'https://myblue.bluecrossma.com/healthy-living';
  anonymousFeedback = 'https://engage.bluecrossma.com/forms/submit-feedback';
  blue365Url = 'https://myblue.bluecrossma.com/health-plan/blue365-discounts';
  wellnessRewardsProgram = 'https://www.join.virginpulse.com/wellness';
  getpostloginUrl: string;

  // geteob
  getEobLinkUrl: string;
  getEobListUrl: string;
  drupalHomeContentsUrl: string;
  drupalHomeNavigationUrl: string;
  drupalHomeHeroBannerUrl: string;
  drupalHomeDiscountsUrl: string;
  drupalConfidentialityPageUrl: string;
  drupalTermsPageUrl: string;

  // swrve
  updateSwrveIdUrl: string;
  programgroups: string;
  preferences: string;
  updatepreferences: string;
  getconsent: string;
  updateConsent: string;
  getDrupalConsent: string;

  // Pharmacy
  createPharmacyUserUrl: string;
  updatePharmacyUserUrl: string;
  addMedicationsUrl: string;
  completePillPackHandoff: string;
  pillpackSiteUrl: string;
  recentRxMedicationsUrl: string;
  getVitaminsandOtcsUrl: string;
  drupalCostShareAssistanceUrl: string;
  registerNewMembers: string;
  registerNewMembersLink: string;
  sendEmailConfig: {};
  getTaxForm: string;
  brandFooter: string[];
  reward360DealUrl: string;
  healthAction: string;
  identityProduction: string;
  isUnionBlueMember: string;

  isBenefitSearchEnabled: string;
  benefitsKeywordSearch: string;
  drupalSearchLastRefresh: string;

  drupalCostShareForClaimsUrl: string;
  drupalConfigUrl: string;

  drupalalMyCardsUrl: string;
  // too-soon
  drupalFutureEnrolleeUrl: string;
  drupalFutureEnrolleeDateToken: string;
  futureEnrolleeStartDateDisplayFormat: string;

  drupalAboutMe: string;
  drupalAboutMeLearnMore: string;
  notifydemographicsmodeldisplayed: string;
  telehealthUpdateEnrollmentUrl: string;
  telehealthFetchConsumerAuthKeyUrl: string;

  teleHealthWellConnectionUrl: string;

  getVitalsTeleHealthDetailsUrl: string;
  medlookupUrl: string;
  medlookupDetailUrl: string;
  medlookupStaticLinkUrl: string;
  medlookupFormularyAndTier: string;
  medlookupTierMapping: string;
  medLookUpPublicUrl = 'https://home.bluecrossma.com/medication/?icid=myblueglobalnav';

  optInOptOutSmsUrl: string;

  getCiAcBenefits: string;
  pwkVideoUrl: string;
  pwkUrl: string;
  pwkDocUrl: string;
  setPwkUrl: string;

  drupalRecommendedUrl: string;
  userClaimEndPoint: string;

  constructor() {
    this.serviceUrlDigitalClaim = environment.serviceUrlDigitalClaim;
    this.drupalRecommendedUrl = environment.drupalRecommendedDataUrl
    this.tokenbaseurl = environment.tokenbaseurl;
    this.serviceUrl = environment.serviceUrl;
    this.serviceUrlV2 = environment.serviceUrlV2;
    this.serviceUrlV3 = environment.serviceUrlV3;
    this.drupalHomeUrl = environment.drupalHomeUrl;
    this.privacyUrl = environment.privacyUrl;
    this.tokensEndPoint = environment.tokensEndPoint;
    this.drupalUrl = environment.drupalUrl;
    this.contactus = `${environment.contactus}?scopename=`;
    this.educationCenter = environment.educationCenter;
    this.drupalsecureinquiry = environment.drupalsecureinquiry;
    this.drupalBannerPromoContentUrl = `${this.drupalUrl}/page/myblue-banner`;
    this.isUnionBlueMember = `${this.drupalUrl}/page/blue-union`;
    this.getBenefitsTextUrl = `${this.serviceUrl}plans/getbenefittext`;
    this.drupalalMyCardsUrl = `${this.drupalUrl}/page/mycards`;

    this.optInOptOutSmsUrl = `${this.serviceUrl}/common/sendsms`;

    this.drupalTargetNoResultsUrl = `${this.drupalUrl}/page/mydoctors-nosearchresults`;

    this.getfamilydeductiblesUrl = `${this.serviceUrlV3}coinsurancedeductibles/getfamilydeductibles`;
    this.getindividualdeductiblesUrl = `${this.serviceUrlV3}coinsurancedeductibles/getindividualdeductibles`;
    this.getTaxForm = `${this.serviceUrl}taxforms/gettaxforms`;
    this.medicationsUrl = `${this.serviceUrl}medication/getrecentrx`;
    this.depMedicationsUrl = `${this.serviceUrl}medication/getdependentrecentrx`;
    this.medicationsDetailsUrl = `${this.serviceUrl}medication/getrxdetails`;
    this.depMedicationsDetailsUrl = `${this.serviceUrl}medication/getdependentrxdetails`;
    this.drupalDoctorsUrl = `${this.drupalUrl}/page/home-mydoctors`;
    this.drupalMedicationsUrl = `${this.drupalUrl}/page/home-mymedication`;
    this.drupalClaimsUrl = `${this.drupalUrl}/page/home-myclaims`;
    this.drupalSliderUrl = `${this.drupalUrl}/page/home-leaderboard-slider`;
    this.drupalClaimsrUrl = `${this.drupalUrl}/page/myclaims-listingpage`;
    this.drupalNoClaimsrUrl = `${this.drupalUrl}/page/myclaims-noclaimsresult`;
    this.drupalMyPlansListingUrl = `${this.drupalUrl}/page/planlistingspage`;
    this.drupalMyPlansInformationUrl = `${this.drupalUrl}/page/myplans-information`;
    this.drupalMyPlansFPOUrl = `${this.drupalUrl}/page/myplans-FPO-placeholder`;
    this.drupalMyPlansDetails = `${this.drupalUrl}/page/plan-details-page`;
    this.drupalMyPlansDetailsTooltipUrl = `${this.drupalUrl}/page/plandetails-hovertooltipcontent`;
    this.drupalMyBenefitsUrl = `${this.drupalUrl}/page/plan-benefits-page`;
    this.drupalMyBenefitsDetailsUrl = `${this.drupalUrl}/page/benefits-details-page`;
    this.drupalPCPUrl = `${this.drupalUrl}/page/mydoctors-change-add-pcp-screens`;
    this.drupalRELUrl = `${this.drupalUrl}/page/Information-hyperlink`;
    this.drupalDedCoDiagnosisCodeUrl = `${this.drupalUrl}/page/request-estimate-screen-diagnosis-code-1-tooltip`;
    this.drupalDedCofaclityNPIUrl = `${this.drupalUrl}/page/request-estimate-screen-facility-npi-tooltip`;
    this.drupalDedCoserviceProviderNPItUrl = `${this.drupalUrl}/page/request-estimate-screen-provider-npi-tooltip`;
    this.drupalDedCoTooltipUrl = `${this.drupalUrl}/page/mydeductible-and-co-insurance-screen`;
    this.drupalContentInactiveWithFinancialsUrl = `${this.drupalUrl}/page/homepage-inactive-with-myfinancials`;
    this.drupalContentInactiveNoFinancialsUrl = `${this.drupalUrl}/page/homepage-inactive`;
    this.drupalContentCampaignUrl1 = `${this.drupalUrl}/page/campaign1`;
    this.drupalContentCampaignUrl2 = `${this.drupalUrl}/page/campaign2`;
    this.drupalContentCampaignUrl3 = `${this.drupalUrl}/page/campaign3`;
    this.drupalContentCampaignUrl4 = `${this.drupalUrl}/page/campaign4`;
    this.drupalContentCampaignUrl5 = `${this.drupalUrl}/page/campaign5`;
    this.drupalContentCampaignUrl6 = `${this.drupalUrl}/page/campaign6`;
    this.drupalContentSecureCampaignUrl1 = `${this.drupalUrl}/globalsecure/securepage1`;
    this.drupalContentSecureCampaignUrl2 = `${this.drupalUrl}/globalsecure/securepage2`;
    this.drupalContentSecureCampaignUrl3 = `${this.drupalUrl}/globalsecure/securepage3`;
    this.drupalContentSecureCampaignUrl4 = `${this.drupalUrl}/globalsecure/securepage4`;
    this.drupalContentSecureCampaignUrl5 = `${this.drupalUrl}/globalsecure/securepage5`;
    this.drupalContentSecureCampaignUrl6 = `${this.drupalUrl}/globalsecure/securepage6`;
    this.drupalHomeContentsUrl = `${this.drupalUrl}/page/homepage/login-registration`;
    this.drupalHomeNavigationUrl = `${this.drupalUrl}/page/homepage/navigation-block`;
    this.drupalHomeHeroBannerUrl = `${this.drupalUrl}/page/home-authenticated/herobanner`;
    this.drupalHomeDiscountsUrl = `${this.drupalUrl}/page/homepage/section/my-discounts-rewards`;
    this.drupalTermsPageUrl = `${this.drupalUrl}/page/termsandconditions`;
    this.drupalConfidentialityPageUrl = `${this.drupalUrl}/page/privacypolicy`;
    this.promoBlocks = [
      this.drupalUrl + '/page/home-promoblock1',
      this.drupalUrl + '/page/home-promoblock2',
      this.drupalUrl + '/page/home-promoblock3'
    ];
    this.drupalFinancialInfoUrl = `${this.drupalUrl}/page/health-financial-plan`;

    this.registerUserUrl = `${this.serviceUrlV3}access/registermem`;
    this.loginUserUrl = `${this.serviceUrlV3}access/memberlogin`;
    this.logoutUrl = `${this.serviceUrl}access/logout`;
    this.checkUserId = `${this.serviceUrl}access/checkuserid`;
    this.memAuthUrl = `${this.serviceUrl}authentication/getmemauthinfo`;
    this.updateMemAuthInfoUrl = `${this.serviceUrl}authentication/updatememauthinfo`;
    this.authWithSsnUrl = `${this.serviceUrl}authentication/authwithssn`;
    this.authStudentIDUrl = `${this.serviceUrl}authentication/authwithstudentid`;
    this.authMedicareIDUrl = `${this.serviceUrl}authentication/authwithmbi`;
    this.authLnUrl = `${this.serviceUrl}authentication/authwithln`;
    this.validateLnAnsUrl = `${this.serviceUrl}authentication/validatelnanswers`;
    this.postdesinfoUrl = `${this.serviceUrl}authentication/postdestinationinfo`;
    this.sendaccesscodeUrl = `${this.serviceUrl}common/sendaccesscode`;
    this.verifyAccessCodeUrl = `${this.serviceUrl}common/verifyaccesscode`;
    this.sendCommChlAccesscode = `${this.serviceUrl}common/sendcommchlacccode`;
    this.verfiyCommChlAccesscode = `${this.serviceUrl}common/verifycommchlacccode`;
    this.sendUpdateNotification = `${this.serviceUrl}common/sendupdatenotification`;
    this.memlookupUrl = `${this.serviceUrl}usermigration/memlookup`;
    this.memacctmergeUrl = `${this.serviceUrl}usermigration/memacctmerge`;
    this.getMemberPlans = `${this.serviceUrl}plans/getmemberplans`;
    this.switchPlanAPI = `${this.serviceUrl}access/switchplan`;

    this.getDemoGraphicInfo = `${this.serviceUrlV2}profile/getdemographicinfo`;
    this.getmemprofile = `${this.serviceUrl}profile/getmemprofile`;
    this.getmemprofileV2 = `${this.serviceUrlV2}profile/getmemprofile`;
    this.getmempreference = `${this.serviceUrl}info/getmempreference`;
    this.updatememprofile = `${this.serviceUrl}profile/updatememprofile`;
    this.updatemempreference = `${this.serviceUrl}info/updatemempreference`;
    this.refreshtokenurl = `${this.serviceUrlV2}access/refreshtoken`;
    this.verifyUserUrl = `${this.serviceUrl}access/verifyfpuser`;
    this.verifyUserAuthUrl = `${this.serviceUrl}access/verifyfphintanswer`;
    this.verifyRestAccessCodeUrl = `${this.serviceUrl}access/verifyfunaccesscode`;
    this.verifyResetUrl = `${this.serviceUrl}access/verifyresetac`;
    this.userNameVerify = `${this.serviceUrl}access/verifyfunuser`;
    this.identityVerify = `${this.serviceUrl}access/verifyfunauthuser`;
    this.sendfunaccesscodeUrl = `${this.serviceUrl}access/resendaccesscode`;
    this.resetPwd = `${this.serviceUrl}access/resetpassword`;
    this.termsAndConditions = `${this.privacyUrl}termsandconditions`;
    this.confidentiality = `${this.privacyUrl}privacypolicy`;
    this.updateDemographicInfoUrl = `${this.serviceUrlV2}profile/updatedemographicinfo`;

    this.changepassword = `${this.serviceUrl}profile/changepassword`;
    this.financeUrl = `${this.serviceUrlV2}homepage/getfinancebalance`;
    this.cardfrontUrl = `${this.serviceUrl}cards/getcardfront`;
    this.cardbackUrl = `${this.serviceUrl}cards/getcardback`;
    this.dependentsUrl = `${this.serviceUrl}meminfo/getdependents`;
    this.depedentFrontUrl = `${this.serviceUrl}cards/getdepcardfront`;
    this.depedentBackUrl = `${this.serviceUrl}cards/getdepcardback`;
    this.cardFrontFamily = `${this.serviceUrl}cards/getcardfrontfamily`;
    this.getCardPageurl = `${this.serviceUrl}cards/getcardpage`;
    this.orderIdcardurl = `${this.serviceUrl}cards/orderidcard`;
    this.dependentlistRestrictedUrl = `${this.serviceUrl}meminfo/getdependentsrestricted`;
    this.getfamilycards = `${this.serviceUrl}cards/getfamilycards`;
    this.postCardImageToPDF = `${this.serviceUrl}cards/imagetopdf`;
    this.getPlansBenefitsListUrl = `${this.serviceUrl}plans/getplansbenefitslist`;
    this.getPlanBenefitServicesUrl = `${this.serviceUrl}plans/getplansbenefitsservices`;
    this.getBenefitsCoverageUrl = `${this.serviceUrl}plans/getsubscribercert`;
    this.getPlanBenefitDetailsUrl = `${this.serviceUrl}plans/getplanbenefitdetails`;
    this.getBenefitEnhancedDetailsUrl = `${this.serviceUrl}poe/benefitenhanceddetails`;
    this.getLimitationTextUrl = `${this.serviceUrl}plans/getlimitationtext`;
    this.getFillingTextUrl = `${this.serviceUrl}plans/getfillingtext`;
    this.getAuthReferralUrl = `${this.serviceUrl}plans/getauthreferral`;
    this.getCOBTextUrl = `${this.serviceUrl}plans/getcobtext`;
    this.getEligibilityTextUrl = `${this.serviceUrl}plans/geteligibilitytext`;
    this.getWordSearchUrl = `${this.serviceUrl}plans/getwordsearch`;
    this.getBenefitCoverageUrl = `${this.serviceUrl}plans/getbenefitcoverage`;
    this.eyeMedBaseUrl = environment.eyeMedBaseUrl;
    this.eyeMedNavLink = `${this.eyeMedBaseUrl}/visioncoverage`;
    // Condition to Display EyeMedLink after specified effective date -- 2021-01-01 in Production
    this.eyeMedStartDate = new Date('2021-01-01');
    this.claimsforproviderUrl = `${this.serviceUrl}claimsinfo/getclaimsforprovider`;
    // start : temporary code change kalagi01
    this.claimsUrl = `${this.serviceUrl}claims/getclaimssummary`;
    // end: temporary code change
    this.getEobListUrl = `${this.serviceUrl}eob/geteoblist`;
    this.getEobLinkUrl = `${this.serviceUrl}eob/geteoblink`;
    this.depClaimsUrl = `${this.serviceUrl}depclaimsinfo/getdepclaims`;
    this.claimdetailsUrl = `${this.serviceUrl}claims/getclaimdetails`;
    this.claimProcessingStatusUrl = `${this.serviceUrl}claims/getclaimprocessingstatus`;
    this.benefitsLinkUrl = `${this.serviceUrl}claims/getclaimbenefitslink`;
    this.claimsdepdetailsUrl = `${this.serviceUrl}depclaimsinfo/getdepclaimsforICN`;
    this.getMemBasicInfoUrl = `${this.serviceUrl}meminfo/getmembasicinfo`;

    this.getRequestEstimateUrl = `${this.serviceUrl}costestimate/getrequestestimatedetails`;
    this.submitrequestestimatedetailsUrl = `${this.serviceUrl}costestimate/submitrequestestimatedetails`;

    this.claimsdaterangeUrl = `${this.serviceUrl}claimsinfo/getclaimsfordaterange`;
    this.homepageUrl = `${this.serviceUrl}homepage/gethomepageinfo`;

    this.getCommPreferenceUrl = `${this.serviceUrl}preference/getcommstatus`;
    this.updateCommPreferenceUrl = `${this.serviceUrl}preference/updatecommstatuslatest`;

    this.dedcoUrl = `${this.serviceUrl}homepage/getdeductiblesandcoins`;
    this.myDoctorListUrl = `${this.serviceUrl}doctors/getrecentvisits`;
    this.myDoctorDetailsUrl = `${this.serviceUrl}doctors/getvisitdetails`;
    this.myDepDoctorListUrl = `${this.serviceUrl}doctors/getdependentrecentvisits`;
    this.myDepDoctorDetailsUrl = `${this.serviceUrl}doctors/getdependentvisitdetails`;
    this.myDoctorInvalidPCPId = '70010000ZP0745';
    this.pcpTierInfoUrl = 'http://www.bluecrossma.com/memberportal/disclaimer/ingenix/learn-more-about-provider-tiers3T.html';
    // add/change pcp
    this.getMemPlanInfo = `${this.serviceUrl}pcp/getmemplaninfo`;
    this.getMemPlanDependents = `${this.serviceUrl}pcp/getmemplandependents`;
    this.getCodes = `${this.serviceUrl}pcp/getcodes`;
    this.getPCPInfo = `${this.serviceUrl}pcp/getpcpinfo`;
    this.changePCP = `${this.serviceUrl}pcp/changepcp`;

    // Message Center (Inbox)
    this.msgListingUrl = `${this.serviceUrl}memnotifications/getinboxmessages`;
    this.msgDetailUrl = `${this.serviceUrl}memnotifications/getmessagedetail`;
    this.updateMsgListingAndMemAlertsUrl = `${this.serviceUrl}memnotifications/updatememalerts`;

    // Notifications & Alerts (Inbox)
    this.notificationsListingUrl = `${this.serviceUrl}memnotifications/getinboxmessages`;
    this.notificationsDetailUrl = `${this.serviceUrl}memnotifications/getmessagedetail`;
    this.updateNotificationsAlertsUrl = `${this.serviceUrl}alerts/updatealerts`;

    // Too Soon
    this.coverageEffectiveDateFormat = 'YYYY-MM-DD';

    // Documents
    this.getDocumentsRiderInfo = this.serviceUrl + +'plans/getsubscribercert';
    this.getDocumentsPlanInfo = this.serviceUrl + 'plans/getbenefittext';

    // swrve
    this.updateSwrveIdUrl = this.serviceUrl + 'profile/updateswrveid';

    // my account
    this.myaccountUrl = `${this.serviceUrl}homepage/myaccountinfo`;

    this.getpostloginUrl = `${this.serviceUrl}vitalslogin/getpostlogindetails`;

    //communication preferences
    this.programgroups = `${this.serviceUrl}preferencecenter/getprogramgroups`;
    this.preferences = `${this.serviceUrl}preferencecenter/getpreferences`;
    this.updatepreferences = `${this.serviceUrl}preferencecenter/updatepreferences`;
    this.getconsent = `${this.serviceUrl}preferencecenter/getconsentinfo`;
    this.updateConsent = `${this.serviceUrl}preferencecenter/updateconsentinfo`;
    this.getDrupalConsent = `${this.drupalUrl}/page/consentlang`;

    this.states = [new DropDownValue('KS', 'Kansas'), new DropDownValue('CA', 'California')];
    this.languages = [new DropDownValue('EN', 'English'), new DropDownValue('ES', 'Espanol')];
    this.races = [new DropDownValue('AMERICAN', 'American'), new DropDownValue('ASIAN', 'ASIAN')];
    this.ethnicities = [new DropDownValue('AMERICAN', 'American'), new DropDownValue('ASIAN', 'ASIAN')];
    this.reward360DealUrl = 'https://www.blue365deals.com/';
    this.healthAction = 'https://healthy-actions.com/';
    this.identityProduction = 'https://member.bluecrossma.com/pages/campaign1';

    // too-soon
    this.drupalFutureEnrolleeUrl = `${this.drupalUrl}/page/future-enrollee-app`;
    this.drupalFutureEnrolleeDateToken = '{date}';
    this.futureEnrolleeStartDateDisplayFormat = 'dddd, MMMM Do YYYY';

    // Pharmacy
    this.createPharmacyUserUrl = `${this.serviceUrl}pharmacy/createpharmacyuser`;
    this.updatePharmacyUserUrl = `${this.serviceUrl}pharmacy/updatepharmacyuser`;
    this.addMedicationsUrl = `${this.serviceUrl}pharmacy/createmedication`;
    this.completePillPackHandoff = `${this.serviceUrl}pharmacy/handoffpharmacyuser`;
    this.pillpackSiteUrl = 'https://www.pillpack.com';
    this.cvsOtcLink = 'https://www.cvs.com/otchs/bcbsma';
    this.recentRxMedicationsUrl = `${this.serviceUrl}pharmacy/getrecentrxwithvendorinfo`;
    this.getVitaminsandOtcsUrl = `${this.serviceUrl}pharmacy/getvitaminsandotc`;

    // user claims
    this.userClaimEndPoint = `${this.serviceUrlDigitalClaim}claims`;

    // Virtual visit
    this.telehealthUpdateEnrollmentUrl = `${this.serviceUrl}consumerenrollment/isconsumerenrolled`;

    //Amwell
    this.telehealthFetchConsumerAuthKeyUrl = `${this.serviceUrl}sdkmutualauth/token`;

    this.getVitalsTeleHealthDetailsUrl = `${environment.serviceUrlV2}consumerenrollment/gettelehealtheligibilitydetails`;

    this.teleHealthWellConnectionUrl = `${this.drupalUrl}/page/telehealth-wellconnection`;
    //this.teleHealthWellConnectionUrl = `${this.drupalUrl}/page/telehealth`

    this.isBenefitSearchEnabled = `${this.serviceUrl}poe/issearchenabled`;
    this.benefitsKeywordSearch = `${this.serviceUrl}poe/keywordsearch`;
    this.drupalCostShareAssistanceUrl = `${this.drupalUrl}/page/landing/costshare`;
    this.isBenefitSearchEnabled = `${this.serviceUrl}poe/issearchenabled`;
    this.brandFooter = [
      this.drupalUrl + '/page/brand-promoblock1',
      this.drupalUrl + '/page/brand-promoblock2',
      this.drupalUrl + '/page/brand-promoblock3',
      this.drupalUrl + '/page/brand-promoblock4'
    ];

    this.drupalCostShareForClaimsUrl = `${this.drupalUrl}/page/costshareclaims`;
    this.drupalSearchLastRefresh = `${this.drupalUrl}/page/last-refreshed-date`;

    this.drupalConfigUrl = `${this.drupalUrl}page/config`;
    this.medlookupUrl = `${this.serviceUrlV2}medlookup/medication`;
    this.medlookupDetailUrl = `${this.serviceUrl}medlookup/medicationdetails`;
    this.medlookupStaticLinkUrl = `${this.serviceUrl}medlookup/medicationpdflinks`;
    this.medlookupFormularyAndTier = `${this.serviceUrl}medlookup/getformularyandtier`;
    this.medlookupTierMapping = `${this.serviceUrl}medlookup/plantiermapping`;
    this.registerNewMembers =
      'Please proceed with registering now, however, it is possible you may experience a ' +
      'registration delay of up to a week as we update our systems. ' +
      'You can start using your new Blue Cross health plan and insurance card on the first day of ' +
      'your plan’s effective date even if you experience a registration issue. Thank you.';
    this.registerNewMembersLink = "<br> <u><a href='http://bcbsma.info/help'>Help with Sign in / Registration</a></u>";

    this.displayMessage = {
      "We couldn't find your information. Please re-register to create a new account": new Alert(
        "We couldn't find your information." +
          ' Please <a href="/register" href="javascript:void(0)" class="link-error">' +
          're-register to create a new account</a>.',
        '',
        AlertType.Failure
      ),
      'Sorry, the access code you entered does not match our records, please try again.': new Alert(
        "That code doesn't match. Please check it, and try again.",
        '',
        AlertType.Failure
      ),
      'User Found is undefined': new Alert('Username or password is incorrect.', '', AlertType.Failure),
      'ERROR DURING LOGIN OPERATION': new Alert('Username or password is incorrect.', '', AlertType.Failure),
      '[LDAP: error code 49 - Invalid Credentials]': new Alert('Username or password is incorrect.', '', AlertType.Failure),
      '[LDAP: error code 53 - Error, Account is locked]': new Alert(
        'Please call Member Service at , <a href="javascript:void(0)" ' +
          'class="black-text underline">866-822-0570</a> 8:00 AM - 9:00 PM ET, Monday - Friday.',
        'Your account is locked',
        AlertType.Failure
      ),
      'User already exist': new Alert(
        'An account already exists with this email. Please check your entries or sign in.',
        '',
        AlertType.Failure
      ),
      'ERROR DURING ADD USER OPERATION': new Alert(
        'An account already exists with this email. Please check your entries or sign in.',
        '',
        AlertType.Failure
      ),
      'Sorry, based on the information you have provided, we could not find your member record': new Alert(
        'Sorry, based on the information you have provided, we could not find your member record',
        '',
        AlertType.Failure
      ),
      'Sorry, the maximum authentication attempts limit has been reached.': new Alert(
        'Please call Member Service at , <a href="javascript:void(0)" ' +
          'class="black-text underline">866-822-0570</a> 8:00 AM - 9:00 PM ET, Monday - Friday.',
        'We cannot give you access at this time',
        AlertType.Failure
      ),
      'Fault: ErrorResponseCode': new Alert('Internal Server Error', '', AlertType.Failure),
      "Sorry we can't find user with that ID.Please try with correct user id.": new Alert(
        "Sorry, we can't find an account with that username. Please try again.",
        '',
        AlertType.Failure
      ),
      // tslint:disable-next-line:max-line-length
      'Sorry password is invalid.Password must have 8-16 character and have atleast 1 upper case,atleast 1 lower case,atleast 1 special char,atleast 1 number and no space.': new Alert(
        'Incorrect Username or Password. Please try again.',
        '',
        AlertType.Failure
      ),
      'Sorry User id already used.Please try other user id.': new Alert(
        'An account already exists with this email address.<a href="/login" ' +
          'class="link-error">Log in</a>  or try again with a new email.',
        '',
        AlertType.Failure
      ),
      'Sorry,System Error. Please try again later.': new Alert(
        'An account already exists with this mobile number.<a href="/login" ' +
          'class="link-error">Log in</a>  or try again a new mobile number.',
        'Error',
        AlertType.Failure
      ),
      'Invalid User Name or Date of Birth.  Please try again.': new Alert(
        "We couldn't find your information in our records. Please try again.",
        'Error',
        AlertType.Failure
      ),
      'No user found with that email address or mobile phone number.  Please try again.': new Alert(
        'The information you entered does not match our records. Please try again.' +
          'If you do not have a username <a href="/register" href="javascript:void(0)" class="link-error">Register Now</a>',
        'Error',
        AlertType.Failure
      ),
      // tslint:disable-next-line:max-line-length
      'We were unable to identify your account with the information provided. Please try again, or call Member Service at 1-888-772-1722, Monday through Friday, 8:00 a.m. to 6:00 p.m. ET.': new Alert(
        'We were unable to identify your account with the information provided. Please try again, or call Member Service at' +
          ' <a href="javascript:void(0)" ' +
          'class="black-text underline">1-888-772-1722</a> , Monday through Friday, 8:00 a.m. to 6:00 p.m. ET.',
        '',
        AlertType.Failure
      ),
      "We couldn't find your information. Please try again. If you don't have an account, Register Now.": new Alert(
        "We couldn't find your information. Please try again. If you don't have an account, " +
          '<a href="/register" href="javascript:void(0)" class="link-error">Register Now.</a>',
        '',
        AlertType.Failure
      )
    };

    // Communication preferences constants
    this.sendEmailConfig = { fad_provider_issues: 'FAD_MANDATE_CONFIG' };
    this.drupalAboutMe = `${this.drupalUrl}/page/aboutme`;
    this.drupalAboutMeLearnMore = `${this.drupalUrl}/page/aboutme-learnmore`;
    this.notifydemographicsmodeldisplayed = `${this.serviceUrl}profile/notifydemographicsmodeldisplayed`;
    this.getCiAcBenefits = `${this.drupalUrl}/page/benefits/ci-ac-benefits-`;
    this.pwkVideoUrl = `${this.serviceUrl}medicare/getMedicareWelcomeVideo`;
    this.pwkUrl = `${this.serviceUrl}medicare/getMedicareWKservice`;
    this.pwkDocUrl = `${this.serviceUrl}medicare/getMedicareDoc`;
    this.setPwkUrl = `${this.serviceUrl}medicare/setMedicareWKservice`;
  }

  REDIRECTION_URLS = {
    LOCKED_OUT: '../register/updatessn',
    SSN_MISMATCH: '../register/updatessn',
    DOB_NOT_FOUND: '../register/register-detail',
    MEMBER_NOT_FOUND: '../register/memberinfo'
  };

  API_INVALID_IDENTIFITERS = {
    dateOfBirth: 'MEM_DOB',
    firstName: 'MEM_FNAME',
    lastName: 'MEM_LNAME',
    memberId: 'MEM_NUM'
  };

  claimsFormCommercialUrl =
    'https://myblue.bluecrossma.com/sites/g/files/csphws1461/files/acquiadam-assets/SubscriberSubmitClaimForm7307.pdf';
  dentalClaimFormCommercialUrl =
    'https://myblue.bluecrossma.com/collateral/sites/g/files/csphws1571/files/acquiadam-assets/ADAForm2012BCBSMA.pdf';
  empClaimsFormCommercialUrl =
    'https://www.bluecrossma.org/sites/g/files/csphws1866/files/acquiadam-assets/000577374_BCBSMA_Employee_Claim_Form_Update.pdf';

}
