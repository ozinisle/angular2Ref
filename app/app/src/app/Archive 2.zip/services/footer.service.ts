import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FAD_CONSTANTS } from '@app/pages/fad/constants/fad.constants';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { environment } from '@environments/environment';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { FooterGlobalModel } from '../models/footer-global.model';
import {
  GetVitalsDataUpdatesRequestModel,
  GetVitalsDataUpdatesResponseModel,
  MultiLingualFooterModel
} from '../models/multilingual-footer.model';
import { FooterLinkModel } from '@app/models/footer-link.model';

@Injectable({ providedIn: 'root' })
export class FooterService {
  public footerLinksData: any;
  public multiLingualFooterData;
  public globalFooterData;

  @SelectSnapshot(AppSelectors.getFADHCCSFlag) hccsFlag: string;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  constructor(private http: HttpClient) {}

  getGlobalFooter(): Observable<FooterGlobalModel[]> {
    const targetUrl = environment.drupalUrl + '/page/app-footer';
    return this.http.get<FooterGlobalModel[]>(targetUrl);
  }

  getGlobalBrandFooter(): Observable<FooterGlobalModel[]> {
    const targetUrl = environment.drupalUrl + '/global/brand-footer';
    return this.http.get<FooterGlobalModel[]>(targetUrl);
  }

  getFooterLinks(): Observable<FooterLinkModel[]> {
    const targetUrl = environment.drupalUrl + '/api/menu_items/footermenu2?_format=json';
    return this.http.get<FooterLinkModel[]>(targetUrl);
  }

  getMultiLingualFooter(): Observable<MultiLingualFooterModel[]> {
    const targetUrl = environment.drupalUrl + '/multilingual-footer';
    return this.http.get<MultiLingualFooterModel[]>(targetUrl);
  }

  getFadDataUpdates(): Observable<GetVitalsDataUpdatesResponseModel> {
    const getVitalsDataUpdatesParams: GetVitalsDataUpdatesRequestModel = new GetVitalsDataUpdatesRequestModel();
    const authUserId = this.useridin;

    if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
      getVitalsDataUpdatesParams.useridin = authUserId;
    }
    if (this.hccsFlag !== null) {
      getVitalsDataUpdatesParams['hccsFlag'] = this.hccsFlag;
    }
    return this.http.post(FAD_CONSTANTS.urls.fadGetFadDataUpdates, getVitalsDataUpdatesParams).pipe(
      map(response => {
        return response as GetVitalsDataUpdatesResponseModel;
      })
    );
  }
}
