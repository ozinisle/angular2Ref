import { Observable, of } from 'rxjs';
import { PLAN_CONFIG } from './plan-config';

export interface AddtionalBenefits {
  benefitTitle: string;
  summaryContent: string;
  detailedContent: string;
}

export interface Ellibility {
  isDigitalFirstCDH?: boolean;
  isWelcomeKitEnabled?: boolean;
  hasCvsLink?: boolean;
}

export interface PlanConfig {
  uacc: string;
  coveragePackageCode: string;
  elligibility: Ellibility;
  additionalBenefits?: AddtionalBenefits[];
}

export class PlanConfigService {
  public constructor() {}

  public getCurrentPlanConfig$(): Observable<PlanConfig> {
    let uacc = '0000';
    if (sessionStorage.getItem('authToken')) {
      const authTokenDetailsJson = JSON.parse(sessionStorage.getItem('authToken'));
      uacc = authTokenDetailsJson.planInfo.groupUacc;
    }
    return this.getPlanConfigByUacc$(uacc);
  }

  public getPlanConfigByUacc$(uacc: string): Observable<PlanConfig> {
    let foundPlanConfig = PLAN_CONFIG.filter(obj => obj.uacc === uacc).pop();
    if (foundPlanConfig == null) {
      foundPlanConfig = {
        uacc: uacc,
        coveragePackageCode: null,
        elligibility: {}
      };
    }
    return of(foundPlanConfig);
  }

  public getPlanConfigByCoveragePackageCode$(cpc: string): Observable<PlanConfig> {
    let foundPlanConfig = PLAN_CONFIG.filter(obj => obj.coveragePackageCode === cpc).pop();
    if (foundPlanConfig == null) {
      foundPlanConfig = {
        uacc: null,
        coveragePackageCode: cpc,
        elligibility: {}
      };
    }
    return of(foundPlanConfig);
  }
}
