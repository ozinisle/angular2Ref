import { PlanConfig } from './plan-config-service';

export const PLAN_CONFIG: PlanConfig[] = [
  {
    uacc: '0315',
    coveragePackageCode: '176664',
    elligibility: {
      isDigitalFirstCDH: true
    },
    additionalBenefits: [
      {
        benefitTitle: 'Accident and Critical Illness Coverage',
        summaryContent: '...',
        detailedContent: '...'
      },
      {
        benefitTitle: 'SonicCare',
        summaryContent: '...',
        detailedContent: '...'
      },
      {
        benefitTitle: 'Toothpic',
        summaryContent: '...',
        detailedContent: '...'
      }
    ]
  },
  {
    coveragePackageCode: '176665',
    uacc: '0316',
    elligibility: {
      isDigitalFirstCDH: true,
    },
    additionalBenefits: [
      {
        benefitTitle: 'Accident and Critical Illness Coverage',
        summaryContent: '...',
        detailedContent: '...'
      },
      {
        benefitTitle: 'SonicCare',
        summaryContent: '...',
        detailedContent: '...'
      },
      {
        benefitTitle: 'Toothpic',
        summaryContent: '...',
        detailedContent: '...'
      }
    ]
  },
  {
    coveragePackageCode: '',
    uacc: '0084',
    elligibility: {
      isDigitalFirstCDH: false,
      isWelcomeKitEnabled: true,
      hasCvsLink: true,
    },
    additionalBenefits: []
  },
  {
    coveragePackageCode: '',
    uacc: '0086',
    elligibility: {
      isDigitalFirstCDH: false,
      isWelcomeKitEnabled: false,
      hasCvsLink: true,
    },
    additionalBenefits: []
  },
  {
    coveragePackageCode: '',
    uacc: '0261',
    elligibility: {
      isWelcomeKitEnabled: false,
    },
    additionalBenefits: []
  },
  {
    coveragePackageCode: '',
    uacc: '0249',
    elligibility: {
      isWelcomeKitEnabled: false,
    },
    additionalBenefits: []
  }
];
