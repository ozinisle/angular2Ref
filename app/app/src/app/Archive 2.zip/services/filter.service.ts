import { Injectable } from '@angular/core';
import { format } from 'date-fns';

@Injectable({ providedIn: 'root' })
export class FilterService {
  itemOrder;

  constructor() {
    this.itemOrder = [
      { category_id: 'Medical' },
      { category_id: 'Dental' },
      { category_id: 'Vision' },
      { category_id: 'Pharmacy' },
      { category_id: 'All visits' }
    ];
    this.itemOrder = this.itemOrder.map(p => p.category_id);
  }

  scrollToTop() {
    window.scrollTo(0, 0);
  }

  convertInputStringToDate(inputDateString: string) {
    if (inputDateString) {
      inputDateString = inputDateString.replace(/[/]/g, '');
      if (inputDateString.length >= 4) {
        inputDateString = inputDateString.substring(0, 2) + '/' + inputDateString.substring(2, 4) + '/' + inputDateString.substring(4);
      } else if (inputDateString.length >= 2) {
        inputDateString = inputDateString.substring(0, 2) + '/' + inputDateString.substring(2, 4);
      }
      return inputDateString;
    }
    return null;
  }

  getFormatDateString(date) {
    return format(new Date(date), 'P');
  }

  getMinimumFromDate() {
    const minFormDate = new Date();
    minFormDate.setFullYear(minFormDate.getFullYear() - 2);
    return minFormDate;
  }

  getDateCount(listOfDatesDiffInDays, dateSpan) {
    if (listOfDatesDiffInDays) {
      const filterList = listOfDatesDiffInDays.filter(item => item <= dateSpan);
      return filterList ? filterList.length : 0;
    }
    return 0;
  }

  getListItems(property: string, list, selectAllOptionIdentifier: string, sorting?: boolean) {
    const itemsCount = this.getPropertyValuesWithCount(property, list);
    const listItems = [];
    for (const key of Object.keys(itemsCount)) {
      listItems.push({
        value: key,
        selected: false,
        count: itemsCount[key]
      });
    }
    if (listItems && listItems.length > 1) {
      listItems.push({
        value: selectAllOptionIdentifier,
        selected: false,
        count: list.length
      });
    }
    if (sorting) {
      this.mapOrder(listItems, this.itemOrder, 'value');
    }
    return listItems;
  }

  mapOrder(array, order, key) {
    array.sort((a, b) => {
      const A = a[key],
        B = b[key];
      if (order.indexOf(A) > order.indexOf(B)) {
        return 1;
      } else {
        return -1;
      }
    });
    return array;
  }

  getPropertyValuesWithCount(property: string, list) {
    const itemsCount = {};
    for (const listItem of list) {
      const propertyValue = listItem[property];
      itemsCount[propertyValue] = itemsCount[propertyValue] ? itemsCount[propertyValue] + 1 : 1;
    }
    return itemsCount;
  }
}
