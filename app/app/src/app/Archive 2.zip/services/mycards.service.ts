import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Store } from '@ngxs/store';
import { Observable, of as observableOf } from 'rxjs';
import { map } from 'rxjs/operators';
import { GetMemBasicInfoRequestModel, GetMemBasicInfoResponseModel } from '@app/pages/my-medication/models/get-member-basic-info.model';
import {
  GetMemBasicInfoRequestModelInterface,
  GetMemBasicInfoResponseModelInterface
} from '@app/pages/my-medication/models/interfaces/get-member-basic-info-model.interface';
import { SetBasicMemberInfo } from '@app/store/actions/app.actions';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { ConstantsService } from './constants.service';

@Injectable({ providedIn: 'root' })
export class MyCardsService {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getBasicMemberInfo) basicMemInfo: any;

  constructor(private http: HttpClient, private store: Store, private constants: ConstantsService) {}

  getMemberFrontData$() {
    const request = {
      useridin: this.useridin
    };
    return this.http.post(this.constants.cardFrontFamily, request).pipe(
      map((response: any) => {
        if (response.result < 0) {
          return response;
        } else {
          if (response && response.error !== true) {
            if (response['fault'] && response['fault'].faultstring) {
              return;
            } else if (response && response['ROWSET'] && response['ROWSET'].totRows <= 1) {
              return [response['ROWSET'].ROWS];
            } else if (response && response['ROWSET']) {
              return response['ROWSET'].ROWS;
            }
          }
        }
      })
    );
  }

  getMemBasicInfo(): Observable<GetMemBasicInfoResponseModelInterface> {
    if (this.basicMemInfo) {
      return observableOf(this.basicMemInfo);
    }
    const request: GetMemBasicInfoRequestModelInterface = new GetMemBasicInfoRequestModel();
    request.useridin = this.useridin;

    return this.http.post<any>(this.constants.getMemBasicInfoUrl, request).pipe(
      map(response => {
        if (response.result < 0) {
          return new GetMemBasicInfoResponseModel();
        } else {
          const basicInfo = new GetMemBasicInfoResponseModel();
          basicInfo.rxSummary = response.getMemBasicInfoResponse;
          this.store.dispatch(new SetBasicMemberInfo(basicInfo));
          return basicInfo as GetMemBasicInfoResponseModel;
        }
      })
    );
  }

  getMemberBackData$() {
    const request = {
      useridin: this.useridin
    };
    return this.http.post<any>(this.constants.cardbackUrl, request).pipe(
      map(response => {
        if (response.result < 0) {
          return response;
        } else {
          if (response && response.error !== true) {
            if (response['fault'] && response['fault'].faultstring) {
              return;
            } else if (response && response['ROWSET'] && response['ROWSET'].totRows <= 1) {
              return [response['ROWSET'].ROWS];
            } else if (response && response['ROWSET']) {
              return response['ROWSET'].ROWS;
            }
          }
        }
      })
    );
  }

  getfamilycards() {
    const request = {
      useridin: this.useridin
    };
    return this.http.post<any>(this.constants.getfamilycards, request);
  }

  postPdfCardsInfo(postObject): Observable<any> {
    postObject.useridin = this.useridin;
    return this.http.post<any>(this.constants.postCardImageToPDF, postObject);
  }
}
