import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConstantsService } from './constants.service';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class DependentService {
  constructor(private http: HttpClient, private constantsService: ConstantsService) {}

  getDependents(id: string): Observable<any> {
    return this.http.post(this.constantsService.dependentsUrl, { useridin: id });
  }

  getDependentRecords(id: string, dependentId: number): Observable<any> {
    return this.http.post(this.constantsService.depMedicationsUrl, { useridin: id, dependentId: dependentId });
  }
}
