import { FetchRewardsResponse } from '../models/fetch-rewards-response.model';

export const MOCK_REWARDS_PROGRESS_RESPONSE: FetchRewardsResponse = {
  member: {
    id: '993663129',
    mdmId: '993663129',
    subNum: '993663129',
    firstName: 'zoe',
    lastName: 'paige',
    accountType: 'HSA'
  },
  incentives: [
    {
      source: 'MyBlue',
      target: 'HEQ',
      year: 2021,
      rewardAmount: 100,
      activityDescription: 'BlueFit Reward - Opted In and Registered MyBlue Account',
      activityCode: '2021_MYBLUE_ENGAGEMENT',
      transactions: [
        {
          id: '10000128004',
          amount: 100,
          status: 'COMPLETED',
          earnedDate: '2021-02-23T17:12:48Z',
          depositDate: '2021-02-23T17:12:48Z'
        }
      ]
    },
    {
      source: 'HEQ',
      target: 'HEQ',
      year: 2021,
      rewardAmount: 50,
      activityDescription: 'BlueFit Reward - Health Savings Optimizer Tool',
      activityCode: '2021_HEQ_OPTIMIZER',
      transactions: [
        {
          id: '10000128003',
          amount: 25,
          status: 'COMPLETED',
          earnedDate: '2021-02-25T17:12:48Z',
          depositDate: '2021-02-25T17:12:48Z'
        }
      ]
    },
    {
      source: 'HEQ',
      target: 'HEQ',
      year: 2021,
      rewardAmount: 50,
      activityDescription: 'BlueFit Reward - HSA Contribution',
      activityCode: '2021_HEQ_FIRST_DEPOSIT',
      transactions: [
        {
          id: '10000128002',
          amount: 50,
          status: 'COMPLETED',
          earnedDate: '2021-02-24T17:12:48Z',
          depositDate: '2021-02-24T17:12:48Z'
        }
      ]
    },
    {
      source: 'VP',
      target: 'HEQ',
      year: 2021,
      quarter: 1,
      numberOfLevels: 4,
      rewardAmount: 100,
      activityDescription: 'Q1 Quarterly Health Wellness Rewards',
      activityCode: 'Q1_WELLNESS',
      transactions: [
        {
          id: 1234567890,
          levelDetails: {
            level: 1,
            pointsEarned: 1000,
            pointsThreshold: 1000,
            pointsLeftToNextLevel: 0
          },
          amount: 10,
          status: 'COMPLETED',
          earnedDate: '2021-01-05T05:12:48Z',
          depositDate: '2021-01-05T05:12:48Z'
        },
        {
          id: 1234567891,
          levelDetails: {
            level: 2,
            pointsEarned: 5000,
            pointsThreshold: 5000,
            pointsLeftToNextLevel: 0
          },
          amount: 20,
          status: 'COMPLETED',
          earnedDate: '2021-01-25T05:12:48Z',
          depositDate: '2021-01-30T05:12:48Z'
        },
        {
          id: 1234567892,
          levelDetails: {
            level: 3,
            pointsEarned: 8500,
            pointsThreshold: 12000,
            pointsLeftToNextLevel: 3500
          },
          amount: 0,
          status: 'COMPLETED',
          earnedDate: '2021-02-15T05:12:48Z'
        }
      ]
    },
    {
      source: 'VP',
      target: 'HEQ',
      year: 2021,
      quarter: 2,
      numberOfLevels: 4,
      rewardAmount: 100,
      activityDescription: 'Q2 Quarterly Health Wellness Rewards',
      activityCode: 'Q2_WELLNESS',
      transactions: [
        {
          id: 1234567890,
          levelDetails: {
            level: 1,
            pointsEarned: 1000,
            pointsThreshold: 1000,
            pointsLeftToNextLevel: 0
          },
          amount: 10,
          status: 'COMPLETED',
          earnedDate: '2021-04-05T05:12:48Z',
          depositDate: '2021-04-05T05:12:48Z'
        },
        {
          id: 1234567891,
          levelDetails: {
            level: 2,
            pointsEarned: 5000,
            pointsThreshold: 5000,
            pointsLeftToNextLevel: 0
          },
          amount: 20,
          status: 'COMPLETED',
          earnedDate: '2021-04-25T05:12:48Z',
          depositDate: '2021-04-30T05:12:48Z'
        },
        {
          id: 1234567892,
          levelDetails: {
            level: 3,
            pointsEarned: 12000,
            pointsThreshold: 12000,
            pointsLeftToNextLevel: 0
          },
          amount: 30,
          status: 'COMPLETED',
          earnedDate: '2021-05-15T05:12:48Z',
          depositDate: '2021-05-20T05:12:48Z'
        },
        {
          id: 1234567893,
          levelDetails: {
            level: 4,
            pointsEarned: 18000,
            pointsThreshold: 18000,
            pointsLeftToNextLevel: 0
          },
          amount: 40,
          status: 'COMPLETED',
          earnedDate: '2021-05-15T05:12:48Z',
          depositDate: '2021-05-20T05:12:48Z'
        }
      ]
    },
    {
      source: 'VP',
      target: 'HEQ',
      year: 2021,
      quarter: 3,
      numberOfLevels: 4,
      rewardAmount: 100,
      activityDescription: 'Q3 Quarterly Health Wellness Rewards',
      activityCode: 'Q3_WELLNESS',
      transactions: [
        {
          id: 1234567890,
          levelDetails: {
            level: 1,
            pointsEarned: 1000,
            pointsThreshold: 1000,
            pointsLeftToNextLevel: 0
          },
          amount: 10,
          status: 'COMPLETED',
          earnedDate: '2021-07-05T05:12:48Z',
          depositDate: '2021-07-05T05:12:48Z'
        },
        {
          id: 1234567891,
          levelDetails: {
            level: 2,
            pointsEarned: 5000,
            pointsThreshold: 5000,
            pointsLeftToNextLevel: 0
          },
          amount: 20,
          status: 'COMPLETED',
          earnedDate: '2021-07-25T05:12:48Z',
          depositDate: '2021-07-30T05:12:48Z'
        },
        {
          id: 1234567892,
          levelDetails: {
            level: 3,
            pointsEarned: 12000,
            pointsThreshold: 12000,
            pointsLeftToNextLevel: 0
          },
          amount: 30,
          status: 'COMPLETED',
          earnedDate: '2021-08-15T05:12:48Z',
          depositDate: '2021-08-20T05:12:48Z'
        }
      ]
    },
    {
      source: 'VP',
      target: 'HEQ',
      year: 2021,
      quarter: 4,
      numberOfLevels: 4,
      rewardAmount: 100,
      activityDescription: 'Q4 Quarterly Health Wellness Rewards',
      activityCode: 'Q4_WELLNESS',
      transactions: [
        {
          id: 1234567890,
          levelDetails: {
            level: 1,
            pointsEarned: 1000,
            pointsThreshold: 1000,
            pointsLeftToNextLevel: 1000
          },
          amount: 0,
          status: 'COMPLETED',
          earnedDate: '2021-09-05T05:12:48Z',
          depositDate: '2021-09-05T05:12:48Z'
        }
      ]
    },
    {
      source: 'PHILLIPS',
      target: 'PHILLIPS',
      year: 2021,
      rewardAmount: 0.0,
      activityDescription: 'Free sonicare toothbrush',
      activityCode: 'FREE_TOOTHBRUSH',
      couponCode: 'fake_coupon_code'
    }
  ]
};
