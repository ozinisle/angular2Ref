import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { MOCK_REWARDS_PROGRESS_RESPONSE } from './mock-data/mock-api-response';
import { EarnAndSaveServiceContract } from './models/earn-and-save-service-contract.model';
import { FetchRewardsResponse } from './models/fetch-rewards-response.model';
import { RewardCode } from './models/reward-code.enum';
import { RewardSource } from './models/reward-source.enum';
import { RewardTransaction } from './models/reward-transaction.model';
import { SimpleRewardStatus } from './models/simple-reward-status.enum';
import { SimpleReward } from './models/simple-reward.model';
import { VirginPulseRewardTransaction } from './models/virgin-pulse-reward-transaction.model';
import { isVirginPulseReward } from './models/virgin-pulse-reward.model';

@Injectable({
  providedIn: 'root'
})
export class EarnAndSaveMockService implements EarnAndSaveServiceContract {
  private incentiveCodes: string[] = [RewardCode.FREE_TOOTHBRUSH];

  public isEarnAndSaveWidgetEnabledForCurrentUser$ = of(true);
  public isMaximizePlanWidgetEnabledForCurrentUser$ = of(true);

  fetchIncentives(): Observable<any[]> {
    return this.fetchRewardsRaw().pipe(
      map(response => {
        if (!response) {
          return null;
        }
        return response.incentives.filter(reward => this.incentiveCodes.includes(reward.activityCode));
      })
    );
  }

  fetchRewards(): Observable<SimpleReward[]> {
    return this.fetchRewardsRaw().pipe(
      map(response => {
        if (!response) {
          return null;
        }

        const now = new Date();
        const currentYear = now.getFullYear();
        const currentQuarter = Math.floor((now.getMonth() + 1) / 3) + 1;

        let rewards: SimpleReward[] = null;
        try {
          rewards = response.incentives
            /*
             * For now, we are omitting all Virgin Pulse quarterly rewards, and
             * prepending a single hard-coded reward.
             *
             * The code below to handle quarterly rewards is being left alone though,
             * so it won't have to be re-implemented later.
             */
            .filter(reward => reward.source !== RewardSource.VIRGIN_PULSE)
            /* Filter out coupons */
            .filter(reward => !this.incentiveCodes.includes(reward.activityCode))
            .map(reward => {
              /* ----------------------------------------
               * Calculate total amount of reward earned so far
               */
              let earnedAmount = 0;
              if (reward.transactions) {
                const transactionCount = reward.transactions.length;
                for (let transactionIndex = 0; transactionIndex < transactionCount; transactionIndex++) {
                  const transaction = reward.transactions[transactionIndex];
                  if (transaction.status === 'COMPLETED') {
                    earnedAmount += transaction.amount;
                  }
                }
              }

              /* ----------------------------------------
               * Calculate reward progress as a percentage
               */
              let progressPercent = 0;
              if (isVirginPulseReward(reward)) {
                const levelCount = reward.numberOfLevels;

                let overallProgress = 0;
                const levelThresholds = [];
                for (let levelNum = 1; levelNum <= levelCount; levelNum++) {
                  const levelTransactions = reward.transactions.filter(
                    transaction => transaction.levelDetails.level === levelNum && transaction.status === 'COMPLETED'
                  );
                  let mostRecentTransaction: VirginPulseRewardTransaction = null;
                  let mostRecentTransactionTime = 0;
                  levelTransactions.forEach(transaction => {
                    const compareTime = new Date(transaction.earnedDate).getTime();
                    if (!mostRecentTransaction || compareTime >= mostRecentTransactionTime) {
                      mostRecentTransactionTime = compareTime;
                      mostRecentTransaction = transaction;
                    }
                  });

                  if (mostRecentTransaction) {
                    const threshold = mostRecentTransaction.levelDetails.pointsThreshold;

                    const levelPointsTotal = levelThresholds.length ? threshold - levelThresholds[levelThresholds.length - 1] : threshold;

                    levelThresholds.push(threshold);

                    const levelPointsEarned = levelPointsTotal - mostRecentTransaction.levelDetails.pointsLeftToNextLevel;
                    const levelProgress = (levelPointsEarned / levelPointsTotal) * 100;

                    /* Each level accounts for an equal percentage of overall progress. */
                    overallProgress += levelProgress * (1 / levelCount);
                  }
                }
                progressPercent = overallProgress;
              } else {
                progressPercent = (earnedAmount / reward.rewardAmount) * 100;
              }

              let status = SimpleRewardStatus.IN_PROGRESS;
              if (progressPercent === 100) {
                status = SimpleRewardStatus.COMPLETED;
              } else if (isVirginPulseReward(reward) && reward.quarter < currentQuarter) {
                status = SimpleRewardStatus.EXPIRED;
              }

              /*
               * Strip current year out of reward codes so that
               * static icons and text don't break on Jan 1.
               */
              const code = reward.activityCode.replace(/^\d{4}_/, '') as RewardCode;

              const simpleReward: SimpleReward = {
                code,
                source: reward.source as RewardSource,
                status,
                year: reward.year,
                earnedAmount,
                maxAmount: reward.rewardAmount,
                progressPercent
              };

              if (progressPercent === 100 && reward.transactions) {
                let mostRecentTransaction: RewardTransaction = null;
                let mostRecentTransactionTime = 0;
                (reward.transactions as RewardTransaction[]).forEach(transaction => {
                  const compareTime = new Date(transaction.earnedDate).getTime();
                  if (!mostRecentTransaction || compareTime >= mostRecentTransactionTime) {
                    mostRecentTransactionTime = compareTime;
                    mostRecentTransaction = transaction;
                  }
                });
                simpleReward.completedAt = new Date(mostRecentTransaction.earnedDate);
              }

              if (isVirginPulseReward(reward)) {
                simpleReward.quarter = reward.quarter;
                if (currentYear < reward.year || currentQuarter < reward.quarter) {
                  simpleReward.status = SimpleRewardStatus.NOT_READY;
                }
                const enabledMonthIndex = (reward.quarter - 1) * 3;
                simpleReward.enabledOn = new Date(reward.year, enabledMonthIndex);

                if (simpleReward.status === SimpleRewardStatus.EXPIRED) {
                  /* Set completedAt for expired rewards to the last day of the quarter */
                  simpleReward.completedAt = new Date(reward.year, enabledMonthIndex + 4, 0);
                }
              }

              return simpleReward;
            })
            /* Sort by status (IN_PROGRESS -> COMPLETED/EXPIRED -> NOT_READY) */
            .sort((a, b) => {
              switch (a.status) {
                case SimpleRewardStatus.IN_PROGRESS:
                  switch (b.status) {
                    case SimpleRewardStatus.IN_PROGRESS:
                      return 0;
                    case SimpleRewardStatus.COMPLETED:
                    case SimpleRewardStatus.EXPIRED:
                    case SimpleRewardStatus.NOT_READY:
                      return -1;
                  }
                  break;

                case SimpleRewardStatus.COMPLETED:
                  switch (b.status) {
                    case SimpleRewardStatus.IN_PROGRESS:
                      return 1;
                    case SimpleRewardStatus.COMPLETED:
                    case SimpleRewardStatus.EXPIRED:
                      return 0;
                    case SimpleRewardStatus.NOT_READY:
                      return -1;
                  }
                  break;

                case SimpleRewardStatus.EXPIRED:
                  switch (b.status) {
                    case SimpleRewardStatus.IN_PROGRESS:
                      return 1;
                    case SimpleRewardStatus.COMPLETED:
                    case SimpleRewardStatus.EXPIRED:
                      return 0;
                    case SimpleRewardStatus.NOT_READY:
                      return -1;
                  }
                  break;

                case SimpleRewardStatus.NOT_READY:
                  switch (b.status) {
                    case SimpleRewardStatus.IN_PROGRESS:
                    case SimpleRewardStatus.COMPLETED:
                    case SimpleRewardStatus.EXPIRED:
                      return 1;
                    case SimpleRewardStatus.NOT_READY:
                      return 0;
                  }
                  break;
              }
            })
            /* Sort completed/expired by least recent -> most recent */
            .sort((a, b) => {
              if (
                [SimpleRewardStatus.COMPLETED, SimpleRewardStatus.EXPIRED].includes(a.status) === false ||
                [SimpleRewardStatus.COMPLETED, SimpleRewardStatus.EXPIRED].includes(b.status) === false
              ) {
                return 0;
              }
              if (a.completedAt > b.completedAt) {
                return 1;
              } else if (a.completedAt.getTime() === b.completedAt.getTime()) {
                return 0;
              } else {
                return -1;
              }
            })
            /* Move current quarter reward(s) to the start */
            .sort((a, b) => {
              if (a.quarter !== currentQuarter && b.quarter === currentQuarter) {
                return 1;
              } else if (a.quarter === currentQuarter && b.quarter !== currentQuarter) {
                return -1;
              }
              return 0;
            });
          /* Prepend hard-coded Virgin Pulse reward */
          rewards.unshift({
            source: RewardSource.VIRGIN_PULSE,
            code: RewardCode.VIRGIN_PULSE,
            status: SimpleRewardStatus.IN_PROGRESS,
            year: new Date().getFullYear(),
            earnedAmount: 0,
            maxAmount: 400.0,
            progressPercent: 0
          });
        } catch (e) {
          console.log(e);
        }
        return rewards;
      }) /* end map() */
    ); /* end pipe() */
  }

  fetchRewardsRaw(): Observable<FetchRewardsResponse> {
    const response = MOCK_REWARDS_PROGRESS_RESPONSE;
    response.incentives.map(reward => {
      reward.year = new Date().getFullYear();
      return reward;
    });
    return of(response);
  }
}
