import { Reward } from './reward.model';

export interface CouponReward extends Reward {
  couponCode: string;
}
