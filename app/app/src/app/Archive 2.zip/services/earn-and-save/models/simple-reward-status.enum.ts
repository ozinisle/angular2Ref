export enum SimpleRewardStatus {
  NOT_READY = 'NOT_READY',
  IN_PROGRESS = 'IN_PROGRESS',
  COMPLETED = 'COMPLETED',
  EXPIRED = 'EXPIRED'
}
