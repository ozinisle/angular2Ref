export interface VirginPulseRewardLevel {
  level: number;
  pointsEarned: number;
  pointsThreshold: number;
  pointsLeftToNextLevel: number;
}
