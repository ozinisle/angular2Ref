export enum RewardCode {
  /**
   * Temporary code for a single hard-coded reward that replaces the
   * Virgin Pulse quarterly rewards.
   */
  VIRGIN_PULSE = 'VIRGIN_PULSE',

  /* ------------------------------
   *  Rewards list items
   */
  Q1_WELLNESS = 'Q1_WELLNESS',
  Q2_WELLNESS = 'Q2_WELLNESS',
  Q3_WELLNESS = 'Q3_WELLNESS',
  Q4_WELLNESS = 'Q4_WELLNESS',
  HEQ_FIRST_DEPOSIT = 'HEQ_FIRST_DEPOSIT',
  HEQ_OPTIMIZER = 'HEQ_OPTIMIZER',
  MYBLUE_ENGAGEMENT = 'MYBLUE_ENGAGEMENT',

  /* ------------------------------
   *  Additional items
   */
  FREE_TOOTHBRUSH = 'FREE_TOOTHBRUSH'
}
