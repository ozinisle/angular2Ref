import { RewardTransaction } from './reward-transaction.model';

export interface Reward {
  source: string;
  target: string;
  year: number;
  rewardAmount: number;
  activityDescription: string;
  activityCode: string;
  transactions?: RewardTransaction[];
}
