import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Select } from '@ngxs/store';
import { BehaviorSubject, combineLatest, Observable, of } from 'rxjs';
import { filter, map, shareReplay, startWith, switchMap } from 'rxjs/operators';
import { v4 as uuid } from 'uuid';
import { environment } from '../../../environments/environment';
import { CdhGuard } from '../../guards/cdh.guard';
import { HasHadCoverageGuard } from '../../guards/has-had-coverage.guard';
import { SubscriberGuard } from '../../guards/subscriber.guard';
import { AppSelectors } from '../../store/selectors/app.selectors';
import { EarnAndSaveMockService } from './earn-and-save-mock.service';
import { FetchRewardsResponse } from './models/fetch-rewards-response.model';
import { SimpleReward } from './models/simple-reward.model';

@Injectable({
  providedIn: 'root'
})
export class EarnAndSaveService extends EarnAndSaveMockService {
  private apiResponse$: Observable<FetchRewardsResponse>;
  private refreshRewardsSubject: BehaviorSubject<boolean> = new BehaviorSubject(true);
  @Select(AppSelectors.getUserID) private useridin$: Observable<string>;
  @Select(AppSelectors.getAccessToken) private token$: Observable<string>;

  /**
   * Whether the "Earn and Save" widget should be shown for the current user.
   * Defaults to ```false``` if we don't yet have enough information to
   * know for sure.
   *
   * Note: This is a _hot_ Observable -- use rxjs operator take(1)
   * if you only need the current value.
   */
  public isEarnAndSaveWidgetEnabledForCurrentUser$: Observable<boolean>;

  /**
   * Whether the "Maximize Plan" widget should be shown for the current user.
   * Defaults to ```false``` if we don't yet have enough information to
   * know for sure.
   *
   * Note: This is a _hot_ Observable -- use rxjs operator take(1)
   * if you only need the current value.
   */
  public isMaximizePlanWidgetEnabledForCurrentUser$: Observable<boolean>;

  constructor(
    private cdhGuard: CdhGuard,
    private hasHadCoverageGuard: HasHadCoverageGuard,
    private http: HttpClient,
    private subscriberGuard: SubscriberGuard
  ) {
    super();

    this.apiResponse$ = combineLatest([this.useridin$, this.token$, this.refreshRewardsSubject]).pipe(
      filter(([useridin, token, refresh]) => !!useridin && !!token),
      switchMap(([useridin, token, refresh]) => {
        const options = {
          headers: new HttpHeaders({
            Authorization: `Bearer ${token}`,
            uitxnid: 'APP_v5.0_' + uuid()
          })
        };
        return this.http.get<FetchRewardsResponse>(environment.rewardsServiceUrl, options);
      }),
      map(result => {
        if (((result as unknown) as { error: any }).error) {
          return null;
        } else {
          return result;
        }
      }),
      shareReplay(1)
    );

    this.isEarnAndSaveWidgetEnabledForCurrentUser$ = combineLatest([
      of(environment.enableNewPersonalizedHub),
      this.cdhGuard.isCdhPlanMember$,
      this.hasHadCoverageGuard.hasHadCoverage$,
      this.subscriberGuard.isSubscriber$
    ]).pipe(
      map(([isFeatureEnabled, isCdhPlanMember, hasHadCoverage, isSubscriber]) => {
        return isFeatureEnabled && isCdhPlanMember && hasHadCoverage && isSubscriber;
      }),
      startWith(false)
    );

    this.isMaximizePlanWidgetEnabledForCurrentUser$ = combineLatest([
      of(environment.enableNewPersonalizedHub),
      this.cdhGuard.isCdhPlanMember$,
      this.hasHadCoverageGuard.hasHadCoverage$
    ]).pipe(
      map(([isFeatureEnabled, hasHadCoverage, isSubscriber]) => {
        return isFeatureEnabled && hasHadCoverage && isSubscriber;
      }),
      startWith(false)
    );
  }

  fetchRewards(): Observable<SimpleReward[]> {
    return super.fetchRewards();
  }

  fetchRewardsRaw(): Observable<FetchRewardsResponse> {
    return this.apiResponse$;
  }

  refreshRewards() {
    this.refreshRewardsSubject.next(true);
  }
}
