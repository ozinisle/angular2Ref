import { SHA256 } from 'crypto-js';
import { JSEncrypt } from 'jsencrypt';
import { EnvironmentEnum } from './environment.enum';

const PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MIGeMA0GCSqGSIb3DQEBAQUAA4GMADCBiAKBgGy6/CJt6Uw8w40WRccw1PEJIO8I
oMQhMQEiGwkWcpp07EPveQFUSEmoxTvcvnq8BDfWcBUbV9Vvy1xaLk80ZhVCt3f8
O+WmQkCTXqNFhRenPVd0mifAdVZ5nqXArra50FcJy0r0iuizl/tOAkhOeOe+c3A2
+FzhUJcqGNgdEJYjAgMBAAE=
-----END PUBLIC KEY-----`;

interface OverrideData {
  env?: EnvironmentEnum;
  override?: { [key: string]: string };
}

interface  EnvironmentConfig { [key: string]: string | number | boolean }

export interface EnvironmentConfigCommon extends EnvironmentConfig {
  apiBaseUrl: string;
}

/**
 * Logic to select the proper environment config at runtime
 * @author Olivier Merigon
 */
export class EnvironmentService<SpecificEnvironmentConfig extends EnvironmentConfigCommon> {
  private static readonly OVERRIDE_HTTP_PARAM = 'override';
  private static readonly OVERRIDE_SIG_HTTP_PARAM = 'overrideSig';

  private static readonly DEV_DOMAIN_REGEXP = '(dev.*devbcbsma\\.com)';
  private static readonly QA_DOMAIN_REGEXP = '(qa.*devbcbsma\\.com)|(msstimpersonationtest\\.bluecrossma\\.com)|localhost';
  private static readonly PERF_DOMAIN_REGEXP = 'member\\-stage\\.bluecrossma\\.com';
  private static readonly UAT_DOMAIN_REGEXP = '((.*uat.*)|msstimpersonationstage)\\.bluecrossma\\.com';
  private static readonly DEMO_DOMAIN_REGEXP = 'demo.*devbcbsma\\.com';

  public static readonly SESSION_STORAGE_PREFIX = 'environment.service.';

  private finalValues: SpecificEnvironmentConfig;
  private envToUse: EnvironmentEnum;
  private jsEncrypt: JSEncrypt;

  constructor() {
    this.jsEncrypt = new JSEncrypt({});
    this.jsEncrypt.setPublicKey(PUBLIC_KEY);
  }

  /**
   * Get param value from URL and store in session storage for later in case route changes.
   */
  private getOverrideFromHttpParamOrSession(): OverrideData {
    let override = sessionStorage.getItem(EnvironmentService.SESSION_STORAGE_PREFIX + EnvironmentService.OVERRIDE_HTTP_PARAM);
    if (override == null && window.URLSearchParams != null) {
      const urlParams = new URLSearchParams(window.location.search);
      const overrideFromUrl = urlParams.get(EnvironmentService.OVERRIDE_HTTP_PARAM);
      const overrideSig = urlParams.get(EnvironmentService.OVERRIDE_SIG_HTTP_PARAM);
      if (overrideFromUrl != null) {
        const isVerified = this.jsEncrypt.verify(overrideFromUrl, overrideSig, SHA256);
        if (isVerified) {
          sessionStorage.setItem(EnvironmentService.SESSION_STORAGE_PREFIX + EnvironmentService.OVERRIDE_HTTP_PARAM, overrideFromUrl);
          override = overrideFromUrl;
        } else {
          console.log('Override signature mismatched');
        }
      }
    }
    if (override != null) {
      const overrides: OverrideData = JSON.parse(override);
      return overrides;
    }
    return {};
  }

  /**
   * Determine environment to use based on domain name
   */
  private getEnvFromDomain(): EnvironmentEnum {
    const domainName = window.location.hostname;
    if (domainName.match(EnvironmentService.QA_DOMAIN_REGEXP)) {
      return EnvironmentEnum.QA;
    } else if (domainName.match(EnvironmentService.UAT_DOMAIN_REGEXP)) {
      return EnvironmentEnum.UAT;
    } else if (domainName.match(EnvironmentService.PERF_DOMAIN_REGEXP)) {
      return EnvironmentEnum.PERF;
    } else if (domainName.match(EnvironmentService.DEV_DOMAIN_REGEXP)) {
      return EnvironmentEnum.DEV;
    } else if (domainName.match(EnvironmentService.DEMO_DOMAIN_REGEXP)) {
      return EnvironmentEnum.DEMO;
    }
    return EnvironmentEnum.PROD;
  }

  /**
   * Apply the environment configuration dynamically
   * Hierarchy:
   * - env key from environment file
   * - HTTP 'env' param
   * - HTTP 'override' params
   * It will default to prod in case of issue to protect production.
   * @returns the environment config to use.
   */
  public initConfig(envToUse: EnvironmentEnum,
                  defaultValues: SpecificEnvironmentConfig,
                  allValues: { [key in EnvironmentEnum]?: Partial<SpecificEnvironmentConfig> }): SpecificEnvironmentConfig {
    const overrideData = this.getOverrideFromHttpParamOrSession();

    // Determine env to use from url param
    this.envToUse = overrideData.env;
    // If not passed as url param, determine if passed from app build
    if (this.envToUse == null) {
      this.envToUse = envToUse;
    }
    // If not passed from app build, check from web domain name
    if (this.envToUse == null) {
      this.envToUse = this.getEnvFromDomain();
    }

    const envConfig = allValues[this.envToUse];

    const httpOverrides = overrideData.override;
    this.finalValues = Object.assign({}, defaultValues, envConfig, httpOverrides);

    if (!this.isProdEnv()) {
      console.log('%cSelected config:', 'background: #222; color: #bada55', this.getEnv(), this.getAllConfig());
    }
    return this.finalValues;
  }

  public getConfig(featureName: keyof SpecificEnvironmentConfig): boolean | string | number {
    return this.finalValues[featureName];
  }

  public getAllConfig(): SpecificEnvironmentConfig {
    return this.finalValues;
  }

  public getEnv(): EnvironmentEnum {
    return this.envToUse;
  }

  public isProdEnv(): boolean {
    return this.getEnv() === EnvironmentEnum.PROD;
  }

  public isDemoEnv(): boolean {
    return this.getEnv() === EnvironmentEnum.DEMO;
  }

  public isNotDemoEnv(): boolean {
    return this.getEnv() !== EnvironmentEnum.DEMO;
  }
}
