export enum EnvironmentEnum {
  PROD = 'PROD',
  QA = 'QA',
  UAT = 'UAT',
  PERF = 'PERF',
  DEV = 'DEV',
  DEMO = 'DEMO'
}
