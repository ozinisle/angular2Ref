import { environment } from '@environments/environment';
import { Injectable } from '@angular/core';
import { PrivacyScreen } from '@capacitor-community/privacy-screen';
import { LogRocketService } from './logrocket.service';

@Injectable({
  providedIn: 'root'
})
export class InitService {
  constructor(private logRocketService: LogRocketService
  ) { }

  public initConfig() {

    if (environment.loadLogRocket) {
      this.logRocketService.init();
    }

    let privacyScreenConfigPromise;
    if (environment.privacyScreen) {
      privacyScreenConfigPromise = PrivacyScreen.enable();
    } else {
      privacyScreenConfigPromise = PrivacyScreen.disable();
    }

    return Promise.all([privacyScreenConfigPromise]);
  }
}
