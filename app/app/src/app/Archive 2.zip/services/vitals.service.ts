import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CryptoModel } from '@app/models/crypto.model';
import { ConstantsService } from '@app/services/constants.service';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';

@Injectable({ providedIn: 'root' })
export class VitalsService {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getCryptoToken) cryptoTokens: CryptoModel;

  constructor(private http: HttpClient, private constantsService: ConstantsService) {
  }

  getTelehealthInfo() {
    const request = {
      useridin : this.useridin
    }
    const url = this.constantsService.getVitalsTeleHealthDetailsUrl;
    return this.http.post(url, request);
  }

}
