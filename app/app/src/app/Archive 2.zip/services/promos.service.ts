import { Injectable } from '@angular/core';
import { IabService } from './iab.service';

@Injectable({ providedIn: 'root' })
export class PromosService {
  constructor(private iabService: IabService) {}

  openUrl(url, fromHomePage?: boolean) {
    if (url) {
      this.iabService.create(url, fromHomePage);
    }
  }
}
