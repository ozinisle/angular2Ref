import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConstantsService } from './constants.service';
import { IndividualDeductibleRequestModel } from '../pages/deductibles/models/individual-deductible-request.model';
import { AccumulatorModel } from '@app/pages/deductibles/models/accumulator.model';

@Injectable({ providedIn: 'root' })
export class DeductibleService {
  constructor(private http: HttpClient, private constants: ConstantsService) {}

  getFamilyDeductibles(id: string): Observable<any> {
    return this.http.post(this.constants.getfamilydeductiblesUrl, { useridin: id });
  }

  getIndividualDeductibles(request: IndividualDeductibleRequestModel): Observable<any> {
    return this.http.post(this.constants.getindividualdeductiblesUrl, request);
  }

  sortDeductiblesData(deductiblesData: any) {
    if (deductiblesData && deductiblesData.accums && deductiblesData.accums.length > 0) {
      deductiblesData.accums.forEach((accumItem: AccumulatorModel) => {
        if (accumItem.outOfPocket && accumItem.outOfPocket.length > 0) {
          accumItem.outOfPocket.sort(this.getSortedList('networkIndicatorForOutOfPocketMax'));
        }
        if (accumItem.overallDeductibles && accumItem.overallDeductibles.length > 0) {
          accumItem.overallDeductibles.sort(this.getSortedList('networkIndicatorForOverallDeductible'));
        }
      });
    }
  }

  private getSortedList(propertyName: string) {
    return (firstItem: any, secondItem: any) => {
      if (firstItem[propertyName] > secondItem[propertyName]) {
        return 1;
      } else if (firstItem[propertyName] < secondItem[propertyName]) {
        return -1;
      }
      return 0;
    };
  }
}
