import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of as observableOf } from 'rxjs';
import { mergeMap } from 'rxjs/operators';
import { ArticleModel } from '@app/pages/home/home.model';
import { GetDemographicInfoRequestModel, GetDemographicInfoResponseModel } from '@app/pages/my-profile/models/get-demographic-info.model';
import { GetMemberProfileRequestModel, GetMemberProfileResponseModel } from '@app/pages/my-profile/models/get-member-profile-request.model';
import { BaseDemographicInfoModel, MemberProfileGenericResponseModel } from '@app/pages/my-profile/models/member-profile-generics.model';
import {
  UpdateEmailProfileRequestModel,
  UpdateHandAProfileRequestModel,
  UpdateHealthInfoProfileRequestModel,
  UpdateMemberProfileRequestModel,
  UpdatePhoneProfileRequestModel
} from '@app/pages/my-profile/models/update-member-profile.model';
import { ConstantsService } from '@app/services/constants.service';
import { Store } from '@ngxs/store';
import { SetMemProfile } from '@app/store/actions/app.actions';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  editAddress = false;
  editEmail = false;
  editPhone = false;
  editHint = false;
  maskedVerify = '';
  private article1$: BehaviorSubject<ArticleModel>;
  article1: Observable<ArticleModel>;
  articles = [];
  commstatus: any;

  constructor(private http: HttpClient, private constants: ConstantsService, private store: Store) {
    this.article1$ = new BehaviorSubject(new ArticleModel(1));
    this.article1 = this.article1$.asObservable();
    this.articles = [];
    this.articles.push(this.article1);
  }

  setProfile(profile: GetMemberProfileResponseModel) {
    this.store.dispatch(new SetMemProfile(profile));
  }

  preferencePromo(url) {
    this.http.get(url).subscribe(item => {
      this[`article1$`].next(new ArticleModel(1).deserialize(item[0]));
    });
  }

  fetchProfileInfo(id): Observable<GetMemberProfileResponseModel> {
    this.editAddress = false;
    this.editEmail = false;
    this.editPhone = false;
    this.editHint = false;
    const request: GetMemberProfileRequestModel = new GetMemberProfileRequestModel();
    request.useridin = id;

    return this.http.post(this.constants.getmemprofile, request).pipe(
      mergeMap(res => {
        if (!(res as GetMemberProfileResponseModel).useridin) {
          const errorRsp: MemberProfileGenericResponseModel = res as MemberProfileGenericResponseModel;
          throw new Error(errorRsp.displaymessage);
        }
        this.store.dispatch(new SetMemProfile(res as GetMemberProfileResponseModel));
        return observableOf(res as GetMemberProfileResponseModel);
      })
    );
  }
  fetchProfileInfoV2(id) {
    this.editAddress = false;
    this.editEmail = false;
    this.editPhone = false;
    this.editHint = false;
    const request: GetMemberProfileRequestModel = new GetMemberProfileRequestModel();
    request.useridin = id;

    return this.http.post(this.constants.getmemprofileV2, request).pipe(
      mergeMap(res => {
        if (!(res as any).useridin) {
          const errorRsp: MemberProfileGenericResponseModel = res as MemberProfileGenericResponseModel;
          throw new Error(errorRsp.displaymessage);
        }
        return observableOf(res as any);
      })
    );
  }

  getDemoGraphicInfo(id): Observable<GetDemographicInfoResponseModel> {
    const request: GetDemographicInfoRequestModel = new GetDemographicInfoRequestModel();
    request.useridin = id;

    return this.http.post(this.constants.getDemoGraphicInfo, request).pipe(
      mergeMap(demographicInfoResponse => {
        if (!(demographicInfoResponse as GetDemographicInfoResponseModel)?.raceList) {
          const errorRsp: MemberProfileGenericResponseModel = demographicInfoResponse as MemberProfileGenericResponseModel;
          throw new Error(errorRsp.errormessage);
        }
        return observableOf(demographicInfoResponse as GetDemographicInfoResponseModel);
      })
    );
  }

  updatePassword(request, id: string, scopeName: string) {
    let updatePasswordReq: UpdateMemberProfileRequestModel;
    updatePasswordReq = Object.assign(request, {
      useridin: id,
      userState: scopeName
    });

    return this.http.post(this.constants.changepassword, updatePasswordReq);
  }

  updateProfile(updateProfileObj: UpdateMemberProfileRequestModel, editAddress, editEmail, editPhone, editHint, editHealthInfo = false) {
    const updateHandAProfileRequestModel = new UpdateHandAProfileRequestModel();
    const updateEmailProfileRequestModel = new UpdateEmailProfileRequestModel();
    const updatePhoneProfileRequestModel = new UpdatePhoneProfileRequestModel();
    const updateHealthInfoProfileRequestModel = new UpdateHealthInfoProfileRequestModel();

    // do data massaging:
    if (editAddress) {
      return this.http.post(this.constants.updatememprofile, updateProfileObj);
    }

    if (editEmail) {
      updateEmailProfileRequestModel.useridin = updateProfileObj.useridin;
      updateEmailProfileRequestModel.emailAddress = updateProfileObj.emailAddress;

      return this.http.post(this.constants.updatememprofile, updateEmailProfileRequestModel);
    }

    if (editPhone) {
      updatePhoneProfileRequestModel.useridin = updateProfileObj.useridin;
      updatePhoneProfileRequestModel.phoneNumber = updateProfileObj.phoneNumber;
      updatePhoneProfileRequestModel.phoneType = updateProfileObj.phoneType;

      return this.http.post(this.constants.updatememprofile, updatePhoneProfileRequestModel);
    }

    if (editHint) {
      updateHandAProfileRequestModel.useridin = updateProfileObj.useridin;
      updateHandAProfileRequestModel.hintAnswer = updateProfileObj.hintAnswer;
      updateHandAProfileRequestModel.hintQuestion = updateProfileObj.hintQuestion;

      return this.http.post(this.constants.updatememprofile, updateHandAProfileRequestModel);
    }

    if (editHealthInfo) {
      updateHealthInfoProfileRequestModel.useridin = updateProfileObj.useridin;
      updateHealthInfoProfileRequestModel.allergies = updateProfileObj.health.allergies + '';
      updateHealthInfoProfileRequestModel.conditions = updateProfileObj.health.conditions + '';
      return this.http.post(this.constants.updatememprofile, updateHealthInfoProfileRequestModel);
    }
  }

  updateDemographicInfo(demographicInfoRequest: BaseDemographicInfoModel): Observable<GetDemographicInfoResponseModel> {
    return this.http.post<GetDemographicInfoResponseModel>(this.constants.updateDemographicInfoUrl, demographicInfoRequest);
  }

  VerifyAccessCode(accesscode, commChannelType, commChannel, id: string) {
    const generatedRequest = {
      useridin: id,
      commChannel: commChannel,
      commChannelType: commChannelType,
      userIDToVerify: id,
      accesscode: accesscode
    };
    return this.http.post(this.constants.verifyAccessCodeUrl, generatedRequest);
  }

  VerifyCommChlAccCode(accesscode, email, mobile, id: string) {
    const generatedRequest = {
      useridin: id,
      email: email,
      mobile: mobile,
      userIDToVerify: id,
      accesscode: accesscode
    };

    return this.http.post(this.constants.verfiyCommChlAccesscode, generatedRequest);
  }

  sendaccesscode(commChannelType, commChannel, id) {
    const request = {
      useridin: id,
      commChannel: commChannel,
      commChannelType: commChannelType,
      userIDToVerify: id
    };
    return this.http.post<any>(this.constants.sendaccesscodeUrl, request);
  }

  sendcommchlaccesscode(email, mobile, id) {
    const request = {
      useridin: id,
      email: email,
      mobile: mobile,
      userIDToVerify: id
    };

    return this.http.post(this.constants.sendCommChlAccesscode, request);
  }

  sendUpdateNotification(request) {
    return this.http.post(this.constants.sendUpdateNotification, request);
  }

  maskPhoneNumber(userId: string): string {
    const regex = /^(.{3})(.{3})(.{4})(.*)/;
    let maskedUserId = userId
      ? userId.replace(/^(.*)(.{4})$/, (_, digitsToMasked, lastFourDigits) => {
          return `${digitsToMasked.replace(/./g, '*')}${lastFourDigits}`;
        })
      : userId;
    const str = maskedUserId;
    const subst = `$1-$2-$3`;
    maskedUserId = str.replace(regex, subst);
    return maskedUserId;
  }

  maskEmailId(userId: string): string {
    return userId
      ? userId.replace(/^(.{3})(.*)(@.*)$/, (_, firstCharacter, charToMasked, domain) => {
          return `${firstCharacter}${charToMasked.replace(/./g, '*')}${domain}`;
        })
      : userId;
  }

  notifyDemographicsModelDisplayed(useridin: string) {
    const payload = {
      useridin
    };
    return this.http.post<any>(this.constants.notifydemographicsmodeldisplayed, payload);
  }
}
