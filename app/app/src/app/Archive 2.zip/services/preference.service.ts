import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { BehaviorSubject, Observable } from 'rxjs';
import { ConstantsService } from './constants.service';
import { v4 as uuid } from 'uuid';

@Injectable({
  providedIn: 'root'
})
export class PreferenceService {
  @SelectSnapshot(AppSelectors.getCryptoToken) cryptoToken: any;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  httpOptions: any;
  showRELAfterPrefModal = false;
  phoneNumberVerificationSkipped = false;
  isEmailVerifiedFromEbillingModal$ = new BehaviorSubject<boolean>(false);


  isChannelEditCancelled = new BehaviorSubject<any>({
    channel: '',
    status: null
  });

  onCloseEditChannel = new BehaviorSubject<any>({
    channel: '',
    status: null
  });

  onChannelSaveClicked = new BehaviorSubject<any>({
    channel: '',
    status: null
  });

  isChannelEditCancelledObs = this.isChannelEditCancelled.asObservable();
  onCloseEditChannelObs = this.onCloseEditChannel.asObservable();
  onChannelSaveClickedObs = this.onChannelSaveClicked.asObservable();

  isEmailVerifiedFromEbillingModal = this.isEmailVerifiedFromEbillingModal$.asObservable();

  constructor(private http: HttpClient, private constantsService: ConstantsService) {
    this.httpOptions = {
      headers: new HttpHeaders({
        'release-version': 'D2'
      })
    };
  }

  getChannelEditObs() {
    return this.isChannelEditCancelledObs;
  }

  getCloseChannelEditObs() {
    return this.onCloseEditChannelObs;
  }

  getChannelSaveClicked() {
    return this.onChannelSaveClickedObs;
  }

  getProgramGroups(id): Observable<any> {
    return this.http.post(this.constantsService.programgroups, { useridin: id }, this.httpOptions);
  }

  getPreferences(id): Observable<any> {
    return this.http.post(this.constantsService.preferences, { useridin: id }, this.httpOptions);
  }

  updatePreferences(id, updatedItem): Observable<any> {
    return this.http.post(this.constantsService.updatepreferences, { useridin: id, preferences: updatedItem });
  }

  getConsent(id): Observable<any> {
    return this.http.post(this.constantsService.getconsent, { useridin: id });
  }

  updateConsent(request): Observable<any> {
    return this.http.post(this.constantsService.updateConsent, request);
  }

  eobOptInTextPreference(phoneNumber): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        uitxnid: 'APP_v5.0_' + uuid()
      })
    };
    const request: any = {
      useridin: this.useridin,
      destinationPhoneNumber: phoneNumber,
      params: {
        messagingServiceSid: 'TW_EOB_MESSAGING_SERVICE_SID',
        body: 'TW_EOB_OPT_IN_BODY'
      },
      key2id: this.cryptoToken.key2id
    };
    return this.http.post(this.constantsService.optInOptOutSmsUrl, request, httpOptions);
  }

  eobOptOutTextPreference(phoneNumber): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        uitxnid: 'APP_v5.0_' + uuid()
      })
    };
    const request: any = {
      useridin: this.useridin,
      destinationPhoneNumber: phoneNumber,
      params: {
        messagingServiceSid: 'TW_EOB_MESSAGING_SERVICE_SID',
        body: 'TW_EOB_OPT_OUT_BODY'
      },
      key2id: this.cryptoToken.key2id
    };
    return this.http.post(this.constantsService.optInOptOutSmsUrl, request, httpOptions);
  }
}
