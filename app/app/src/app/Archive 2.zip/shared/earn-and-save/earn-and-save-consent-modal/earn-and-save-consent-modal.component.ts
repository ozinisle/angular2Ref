import { Component, Input } from '@angular/core';
import { PopoverController } from '@ionic/angular';

@Component({
  selector: 'app-earn-and-save-consent-modal',
  templateUrl: './earn-and-save-consent-modal.component.html',
  styleUrls: ['./earn-and-save-consent-modal.component.scss']
})
export class EarnAndSaveConsentModalComponent {
  @Input() onConsent: () => {};

  constructor(private popoverController: PopoverController) {}

  dismissModal() {
    this.popoverController.dismiss();
  }

  onCallToActionClicked() {
    this.dismissModal();
    if (this.onConsent) {
      this.onConsent();
    }
  }
}
