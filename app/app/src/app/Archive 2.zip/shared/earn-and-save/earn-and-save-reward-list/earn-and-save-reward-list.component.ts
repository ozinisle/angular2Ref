import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { PopoverController } from '@ionic/angular';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { SsoService } from '../../../pages/sso/sso.service';
import { EarnAndSaveService } from '../../../services/earn-and-save/earn-and-save.service';
import { RewardCode } from '../../../services/earn-and-save/models/reward-code.enum';
import { SimpleRewardStatus } from '../../../services/earn-and-save/models/simple-reward-status.enum';
import { SimpleReward } from '../../../services/earn-and-save/models/simple-reward.model';
import { EarnAndSaveRewardModalComponent } from '../earn-and-save-reward-modal/earn-and-save-reward-modal.component';

@Component({
  selector: 'app-earn-and-save-reward-list',
  templateUrl: './earn-and-save-reward-list.component.html',
  styleUrls: ['./earn-and-save-reward-list.component.scss']
})
export class EarnAndSaveRewardListComponent implements OnInit, OnDestroy {
  private isDestroyed$ = new Subject<boolean>();

  public SimpleRewardStatus = SimpleRewardStatus;

  @Input() public filter: 'active' | 'inactive' = 'active';
  @Input() public isActive = true;
  @Input() public categoryText = '';
  @Input() public counterText = '';
  @Input() public headerLevel = 2;

  public rewards: SimpleReward[];
  public shouldShowError = false;

  // prettier-ignore
  constructor(
    private earnAndSaveService: EarnAndSaveService,
    private popoverController: PopoverController,
    private ssoService: SsoService,
  ) {}

  ngOnInit() {
    this.earnAndSaveService
      .fetchRewards()
      .pipe(takeUntil(this.isDestroyed$))
      .subscribe(
        rewards => {
          if (rewards) {
            if (this.filter === 'active') {
              this.rewards = rewards.filter(reward => reward.status !== SimpleRewardStatus.NOT_READY);
            } else {
              this.rewards = rewards.filter(reward => reward.status === SimpleRewardStatus.NOT_READY);
            }
          } else {
            this.shouldShowError = true;
          }
        },
        () => {
          this.shouldShowError = true;
        }
      );
  }

  ngOnDestroy() {
    this.isDestroyed$.next(true);
    this.isDestroyed$.complete();
  }

  async onRewardClick(rewardCode: string) {
    const selectedReward = this.rewards.find(reward => reward.code === rewardCode);
    if (!selectedReward) {
      return;
    }

    if (selectedReward.code === RewardCode.VIRGIN_PULSE) {
      this.ssoService.openSSO('wellnessRewardsProgram_VP');
      return;
    }

    const modal = await this.popoverController.create({
      component: EarnAndSaveRewardModalComponent,
      cssClass: 'earn-and-save-reward-modal',
      componentProps: { reward: selectedReward }
    });
    await modal.present();
  }

  public onReloadPageClick() {
    this.shouldShowError = false;
    this.earnAndSaveService.refreshRewards();
  }

  public rewardTrackByFn(index: number, reward: SimpleReward) {
    return reward.code;
  }
}
