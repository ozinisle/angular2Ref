import { Component, OnChanges, OnInit } from '@angular/core';
import { SsoService } from '@app/pages/sso/sso.service';
import { RewardCode } from '@app/services/earn-and-save/models/reward-code.enum';
import { NavParams, PopoverController } from '@ionic/angular';
import { RewardSource } from '../../../services/earn-and-save/models/reward-source.enum';
import { SimpleRewardStatus } from '../../../services/earn-and-save/models/simple-reward-status.enum';
import { SimpleReward } from '../../../services/earn-and-save/models/simple-reward.model';

@Component({
  selector: 'app-earn-and-save-reward-modal',
  templateUrl: './earn-and-save-reward-modal.component.html',
  styleUrls: ['./earn-and-save-reward-modal.component.scss']
})
export class EarnAndSaveRewardModalComponent implements OnInit, OnChanges {
  public RewardSource = RewardSource;
  public SimpleRewardStatus = SimpleRewardStatus;

  public currentQuarter = (new Date().getMonth() + 1) % 3;
  public currentYear = new Date().getFullYear();
  public reward: SimpleReward;
  targetLocation = {};
  public RewardCode = RewardCode;

  constructor(private navParams: NavParams, private popoverController: PopoverController, private ssoService: SsoService) {}

  public ngOnInit() {
    this.updateProgress();
  }

  public ngOnChanges() {
    this.updateProgress();
  }

  async callToActionClicked() {
    this.popoverController.dismiss();
    switch (this.reward?.source) {
      case RewardSource.VIRGIN_PULSE:
        this.ssoService.openSSO('wellnessRewardsProgram_VP');
        break;
      case RewardSource.HEQ:
        if (this.reward?.status === SimpleRewardStatus.COMPLETED) {
          this.targetLocation = {
            location: 'TRANSACTION',
            accountType: 'HSA',
            accountNumber: ''
          };
        } else if (this.reward?.code === RewardCode.HEQ_FIRST_DEPOSIT) {
          this.targetLocation = {
            location: 'CONTRIBUTION',
            accountType: 'HSA',
            accountNumber: ''
          };
        } else {
          this.targetLocation = {
            location: this.reward?.code === RewardCode.HEQ_OPTIMIZER ? 'OPTIMIZER' : '',
            accountType: 'HSA',
            accountNumber: ''
          };
        }
        this.ssoService.openSSO('heq');
        break;
      case RewardSource.BCBSMA:
        if (this.reward?.status === SimpleRewardStatus.COMPLETED) {
          this.targetLocation = {
            location: 'TRANSACTION',
            accountType: 'HSA',
            accountNumber: ''
          };
        }
        this.ssoService.openSSO('heq');
        break;
    }
    sessionStorage.setItem('targetHEQLocation', JSON.stringify(this.targetLocation));
  }

  public closeButtonClicked() {
    this.popoverController.dismiss();
  }

  private updateProgress() {
    this.reward = this.navParams?.get('reward') as SimpleReward;
  }
}
