import { Component, OnDestroy, OnInit } from '@angular/core';
import { MYBLUE } from '@app/app.constants';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { EarnAndSaveService } from '../../../services/earn-and-save/earn-and-save.service';
import { SimpleRewardStatus } from '../../../services/earn-and-save/models/simple-reward-status.enum';
import { SimpleReward } from '../../../services/earn-and-save/models/simple-reward.model';

@Component({
  selector: 'app-earn-and-save-widget',
  templateUrl: './earn-and-save-widget.component.html',
  styleUrls: ['./earn-and-save-widget.component.scss']
})
export class EarnAndSaveWidgetComponent implements OnInit, OnDestroy {
  private isDestroyed$ = new Subject<boolean>();

  public activeRewards: SimpleReward[];
  public shouldShowError = false;

  // prettier-ignore
  constructor(
    private earnAndSaveService: EarnAndSaveService,
  ) {}

  ngOnInit() {
    this.earnAndSaveService
      .fetchRewards()
      .pipe(takeUntil(this.isDestroyed$))
      .subscribe(
        rewards => {
          this.activeRewards = rewards.filter(reward => reward.status !== SimpleRewardStatus.NOT_READY);
        },
        error => {
          this.shouldShowError = true;
          MYBLUE.log(error);
        }
      );
  }

  ngOnDestroy() {
    this.isDestroyed$.next(true);
    this.isDestroyed$.complete();
  }
}
