import { Component, OnDestroy, OnInit } from '@angular/core';
import { MYBLUE } from '@app/app.constants';
import { SetLoader } from '@app/store/actions/app.actions';
import { NavController } from '@ionic/angular';
import { TranslocoService } from '@ngneat/transloco';
import { Select, Store } from '@ngxs/store';
import { forkJoin, from, Observable, Subject } from 'rxjs';
import { map, take, takeUntil } from 'rxjs/operators';
import { AlertType } from '../../../components/alerts/alert-type.model';
import { GetPlansBenefitsListResponseModelInterface } from '../../../pages/message-center/modals/interfaces/get-plans-benefits-list-models.interface';
import { PlanEntityInterface } from '../../../pages/my-plans/models/interfaces/plan-benefits-page-adapted-data-model.inteface';
import { PlanBenefitsListResponseModel } from '../../../pages/my-plans/models/plan-benefits-list.model';
import { GetPlanBenefitServicesRequestModel } from '../../../pages/my-plans/models/plans-benefits-service.model';
import { MyPlansService } from '../../../pages/my-plans/my-plans.service';
import { SsoService } from '../../../pages/sso/sso.service';
import { AlertService } from '../../../services/alert.service';
import { PlanConfigService } from '../../../services/plan-config/plan-config-service';
import { AppSelectors } from '../../../store/selectors/app.selectors';
import { SavingsItemTranslation } from './models/savings-item-translation.model';
import { SavingsItemType } from './models/savings-item-type.enum';
import { SavingsItem } from './models/savings-item.model';

@Component({
  selector: 'app-earn-and-save-savings-list',
  templateUrl: './earn-and-save-savings-list.component.html',
  styleUrls: ['./earn-and-save-savings-list.component.scss']
})
export class EarnAndSaveSavingsListComponent implements OnInit, OnDestroy {
  @Select(AppSelectors.getUserID) private userId$: Observable<string>;
  private isDestroyed$ = new Subject<boolean>();
  private savingsItemPartials: { [key in SavingsItemType]: Partial<SavingsItem> } = {
    TOOTHPIC: {
      icon: ['fas', 'tooth'],
      destination: 'https://member.toothpic.com/create-account?ci=onlinedentalvisit'
    },
    LEARN_TO_LIVE: {
      icon: ['fas', 'head-side-brain'],
      destination: '**special case**'
    },
    WELL_CONNECTION: {
      icon: ['fas', 'video-plus'],
      destination: '/virtual-visit'
    },
    FITNESS_REIMBURSEMENT: {
      icon: ['fas', 'weight'],
      destination: '/fitness-and-weightloss'
    },
    BLUE365: {
      icon: ['fas', 'hand-holding-usd'],
      destination: 'https://www.blue365deals.com/'
    },
    HOLISTIC_CARE: {
      icon: ['fas', 'hand-holding-heart'],
      destination: 'https://www.bluecrossma.org/myblue/find-care/care-options/find-holistic-care/find-alternative-care'
    },
    EMERGENCY_COVERAGE: {
      icon: ['fas', 'first-aid'],
      destination: '**special case**'
    },
    PILLPACK: {
      icon: ['fas', 'pills'],
      destination: '/my-pillpack/landing'
    }
  };

  public savingsItems: SavingsItem[];

  // prettier-ignore
  constructor(
    private alertService: AlertService,
    private myPlansService: MyPlansService,
    private navController: NavController,
    private planConfigService: PlanConfigService,
    private translocoService: TranslocoService,
    private ssoService: SsoService,
    private store: Store,
  ) {}

  public ngOnInit() {
    this.translocoService
      .selectTranslateObject<SavingsItemTranslation[]>('earnAndSave.savings')
      .pipe(takeUntil(this.isDestroyed$))
      .subscribe(
        translations => {
          MYBLUE.log(translations);
          const savingsTypes = Object.values(SavingsItemType);
          this.savingsItems = savingsTypes.map(savingsItemType => {
            return {
              savingsItemType,
              ...translations[savingsItemType],
              ...this.savingsItemPartials[savingsItemType]
            } as SavingsItem;
          });
        },
        error => {} /* noop: Savings list will remain hidden */
      );
  }

  public ngOnDestroy() {
    this.isDestroyed$.next(true);
    this.isDestroyed$.complete();
  }

  public savingsItemTrackByFn(index: number, savingsItem: SavingsItem) {
    return index;
  }

  public onSavingsItemClick(savingsItemType: SavingsItemType) {
    switch (savingsItemType) {
      case SavingsItemType.LEARN_TO_LIVE:
        this.ssoService.openSSO('Learn2Live');
        break;
      case SavingsItemType.EMERGENCY_COVERAGE:
        this.goToPlanBenefits();
        break;
      default:
        const savingsItem: SavingsItem = this.savingsItems.find(i => i.savingsItemType === savingsItemType);
        if (savingsItem.destination.startsWith('/')) {
          this.navController.navigateForward(savingsItem.destination);
        } else {
          window.open(savingsItem.destination, '_blank');
        }
        break;
    }
  }

  private goToPlanBenefits() {
    this.store.dispatch(new SetLoader(true));
    const today = new Date().toISOString().slice(0, 10);
    forkJoin([this.planConfigService.getCurrentPlanConfig$(), this.myPlansService.getPlansData(today), this.userId$.pipe(take(1))])
      .pipe(
        takeUntil(this.isDestroyed$),
        map(([currentPlan, plansData, userId]) => {
          if (plansData.result < 0) {
            this.alertService.clearError();
            this.alertService.setAlert(plansData.displaymessage, '', AlertType.Failure);
            throw new Error(plansData.displaymessage);
          }
          /*
           * The "myplans" section was built assuming the user would drill down
           * through the pages to get to the benefits page -- so we have to
           * duplicate the application state that would have resulted from
           * searching plans and then selecting a plan to view.
           */
          const typedPlansData = (plansData as any) as GetPlansBenefitsListResponseModelInterface;
          const currentPlanBenefits = typedPlansData.RowSet.osplinPlans.plans.find(
            plan => plan.coveragePackageCode === currentPlan.coveragePackageCode
          );
          const getPlanBenefitRequest = new GetPlanBenefitServicesRequestModel();
          getPlanBenefitRequest.coveragePackageCode = currentPlan.coveragePackageCode;
          getPlanBenefitRequest.planName = currentPlanBenefits.planName;
          getPlanBenefitRequest.useridin = userId;
          this.myPlansService.setPlanBenefitRequest(getPlanBenefitRequest);

          const transformedResponse = this.myPlansService.mapPlanBenefitsResponse(
            (typedPlansData as unknown) as PlanBenefitsListResponseModel
          );
          const planEntity: PlanEntityInterface = transformedResponse.find(
            transformedPlan => transformedPlan.coveragePackageCode === currentPlan.coveragePackageCode
          );
          this.myPlansService.setSelectedPlanEntity(planEntity);
          return from(this.navController.navigateForward('/myPlan/benefits'));
        })
      )
      .subscribe(
        () => {
          this.store.dispatch(new SetLoader(false));
        },
        error => {
          this.store.dispatch(new SetLoader(false));
          console.log(error);
        }
      );
  }
}
