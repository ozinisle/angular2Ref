import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { TranslocoModule } from '@ngneat/transloco';
import { FontAwesomeLibraryModule } from '../fontawesome-library.module';
import { DragToScrollComponent } from './components/drag-to-scroll/drag-to-scroll.component';
import { RadialProgressComponent } from './components/radial-progress/radial-progress.component';
import { EarnAndSaveConsentModalComponent } from './earn-and-save/earn-and-save-consent-modal/earn-and-save-consent-modal.component';
import { EarnAndSaveRewardListComponent } from './earn-and-save/earn-and-save-reward-list/earn-and-save-reward-list.component';
import { EarnAndSaveRewardModalComponent } from './earn-and-save/earn-and-save-reward-modal/earn-and-save-reward-modal.component';
import { EarnAndSaveSavingsListComponent } from './earn-and-save/earn-and-save-savings-list/earn-and-save-savings-list.component';
import { EarnAndSaveWidgetComponent } from './earn-and-save/earn-and-save-widget/earn-and-save-widget.component';
import { VdkButtonComponent } from './vdk/vdk-button/vdk-button.component';
import { VdkHrComponent } from './vdk/vdk-hr/vdk-hr.component';
import { VdkTabBarComponent } from './vdk/vdk-tab-bar/vdk-tab-bar.component';
import { VdkTabButtonComponent } from './vdk/vdk-tab-button/vdk-tab-button.component';

// prettier-ignore
const angular = [
  CommonModule,
  FormsModule,
  ReactiveFormsModule,
  RouterModule,
];

// prettier-ignore
const thirdParty = [
  FontAwesomeLibraryModule,
  IonicModule,
  TranslocoModule,
];

// prettier-ignore
const declarations = [
  DragToScrollComponent,
  EarnAndSaveConsentModalComponent,
  EarnAndSaveRewardListComponent,
  EarnAndSaveRewardModalComponent,
  EarnAndSaveSavingsListComponent,
  EarnAndSaveWidgetComponent,
  RadialProgressComponent,
  VdkButtonComponent,
  VdkHrComponent,
  VdkTabBarComponent,
  VdkTabButtonComponent,
];

// prettier-ignore
/**
 * Angular best practice 04-10
 * https://angular.io/guide/styleguide#shared-feature-module
 *
 * Home for custom and third-party declarables (components, directives,
 * pipes, etc.) that will be re-used and referenced by components declared
 * in other feature modules.
 *
 * A module that imports SharedModule does not need to (re)import any
 * of the modules in SharedModule's ```exports```.
 */
@NgModule({
  imports: [
    ...angular,
    ...thirdParty,
  ],
  declarations: [
    ...declarations,
  ],
  exports: [
    ...angular,
    ...thirdParty,
    ...declarations,
  ],
  providers: [
    /* -------------------------------------------------------------------------
     *   Avoid specifying singleton providers (services) in SharedModule.
     *   https://angular.io/guide/styleguide#shared-feature-module
     * -------------------------------------------------------------------------
     */
  ],
})
export class SharedModule { }
