import { Component, Input } from '@angular/core';

@Component({
  selector: 'vdk-tab-button',
  templateUrl: './vdk-tab-button.component.html',
  styleUrls: ['./vdk-tab-button.component.scss']
})
export class VdkTabButtonComponent {
  @Input() public selected: boolean;
}
