import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'vdk-hr',
  templateUrl: './vdk-hr.component.html',
  styleUrls: ['./vdk-hr.component.scss']
})
export class VdkHrComponent implements OnInit {
  @Input() public thickness: 'thick' | 'thin' = 'thick';
  @Input() public position: 'left' | 'right' = 'left';
  @Input() public color: 'blue' | 'orange' | 'grey' = 'blue';

  constructor() {}

  ngOnInit() {}
}
