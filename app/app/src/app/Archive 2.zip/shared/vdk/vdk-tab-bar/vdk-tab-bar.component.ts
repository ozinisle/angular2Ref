import { AfterViewInit, Component, QueryList, ViewChildren } from '@angular/core';
import { VdkTabButtonComponent } from '../vdk-tab-button/vdk-tab-button.component';

@Component({
  selector: 'vdk-tab-bar',
  templateUrl: './vdk-tab-bar.component.html',
  styleUrls: ['./vdk-tab-bar.component.scss']
})
export class VdkTabBarComponent implements AfterViewInit {
  @ViewChildren(VdkTabButtonComponent) tabButtons: QueryList<VdkTabButtonComponent>;

  constructor() {}

  ngAfterViewInit() {
    if (this.tabButtons.first) {
      this.tabButtons.first.selected = true;
    }
  }
}
