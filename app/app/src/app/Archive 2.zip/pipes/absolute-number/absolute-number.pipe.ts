import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'absoluteNumber'
})
export class AbsoluteNumberPipe implements PipeTransform {

  transform(value: any): any {
    if (!value || isNaN(value)) {
      return value;
    }
    return Math.abs(value);
  }

}
