import { NgModule } from '@angular/core';
import { ClaimIdPipe } from './claim-id.pipe';

@NgModule({
  declarations: [ClaimIdPipe],
  exports: [ClaimIdPipe]
})
export class ClaimIdModule {}
