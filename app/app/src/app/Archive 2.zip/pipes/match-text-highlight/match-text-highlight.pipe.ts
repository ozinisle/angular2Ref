import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'matchTextHighlight'
})
export class MatchTextHighlightPipe implements PipeTransform {
  constructor() {}

  transform(text: string, search): string {
    const resultText: string = text;

    if (search && search.replace) {
      let pattern = search.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, '\\$&');
      pattern = pattern
        .split(' ')
        .filter(t => {
          return t.length > 0;
        })
        .join('|');
      const regex: RegExp = new RegExp(pattern, 'gi');
      return search && text ? resultText.replace(regex, match => `<span class='highlight-matching-text'>${match}</span>`) : resultText;
    }
  }
}
