import { MatchTextHighlightPipe } from './match-text-highlight.pipe';

describe('MatchTextHighlightPipe', () => {
  it('create an instance', () => {
    const pipe = new MatchTextHighlightPipe();
    expect(pipe).toBeTruthy();
  });
});
