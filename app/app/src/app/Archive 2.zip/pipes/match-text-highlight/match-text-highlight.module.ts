import { NgModule } from '@angular/core';
import { MatchTextHighlightPipe } from '@app/pipes/match-text-highlight/match-text-highlight.pipe';

@NgModule({
  declarations: [MatchTextHighlightPipe],
  exports: [MatchTextHighlightPipe]
})
export class MatchTextHighlightModule {}
