import { NgModule } from '@angular/core';
import { AutoCompleteHighlightPipe } from '@app/pipes/auto-complete-highlight/auto-complete-highlight.pipe';

@NgModule({
  declarations: [AutoCompleteHighlightPipe],
  exports: [AutoCompleteHighlightPipe]
})
export class AutoCompleteHighlightModule {}
