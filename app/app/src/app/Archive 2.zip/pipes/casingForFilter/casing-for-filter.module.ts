import { NgModule } from '@angular/core';
import { CasingForFilterPipe } from './casing-for-filter.pipe';

@NgModule({
  declarations: [CasingForFilterPipe],
  exports: [CasingForFilterPipe]
})
export class CasingForFilterModule {}
