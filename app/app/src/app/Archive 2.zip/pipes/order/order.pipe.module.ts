import { OrderPipe } from './order.pipe';
import { NgModule } from '@angular/core';

@NgModule({
  declarations: [OrderPipe],
  exports: [OrderPipe]
})
export class OrderPipeModule {}
