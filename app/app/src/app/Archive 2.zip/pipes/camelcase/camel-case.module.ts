import { NgModule } from '@angular/core';
import { CamelCasePipe } from './camel-case.pipe';

@NgModule({
  declarations: [CamelCasePipe],
  exports: [CamelCasePipe]
})
export class CamelCaseModule {}
