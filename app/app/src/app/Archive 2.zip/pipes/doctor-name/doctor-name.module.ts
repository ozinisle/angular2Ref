import { NgModule } from '@angular/core';
import { DoctorNameFormatter } from '@app/pipes/doctor-name/doctor-name-formatter';

@NgModule({
  declarations: [DoctorNameFormatter],
  exports: [DoctorNameFormatter]
})
export class DoctorNameModule {}
