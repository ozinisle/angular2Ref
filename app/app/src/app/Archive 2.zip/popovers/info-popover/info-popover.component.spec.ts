import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { InfoPopoverComponent } from './info-popover.component';
import { NavParams, IonContent } from '@ionic/angular';

class MockNavParams {
  data = {};

  get(param) {
    return this.data[param];
  }
}

xdescribe('InfoPopoverComponent', () => {
  let component: InfoPopoverComponent;
  let fixture: ComponentFixture<InfoPopoverComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      providers: [{ provide: NavParams, useClass: MockNavParams }, IonContent],
      declarations: [InfoPopoverComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InfoPopoverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
