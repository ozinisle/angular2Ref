export class GetProgramGroups {
  static readonly type = '[PREFERENCE] GET PROGRAM GROUPS';
}

export class GetPreferences {
  static readonly type = '[PREFERENCE] GET PREFERENCE';
}

export class IsUserChannelBounced {
  static readonly type = '[PREFERENCE] IsUserChannelBounced';
}

export class UpdatePreferences {
  static readonly type = '[PREFERENCE] UPDATE PREFERENCES';
  constructor(public changedItem: any, public isFromModal = false, public isConsentOnly = false) {}
}

export class SwapPromo {
  static readonly type = '[PREFERENCE] SWAP PROMO';
  constructor() {}
}

export class SetPreferencePromo {
  static readonly type = '[PREFERENCE] SET PREFERENCE PROMO';
  constructor(public paperlessPromoFlg = false) {}
}

export class SetShowModalFlag {
  static readonly type = '[PREFERENCE] SET SHOW MODAL FLAG';
  constructor(public showModal: boolean) {}
}

export class CheckPreferenceServices {
  static readonly type = '[PREFERENCE] CHECK PREFERENCE SERVICES';
  constructor(public isFromModal?: any) {}
}

export class SubmitPreferences {
  static readonly type = '[PREFERENCE] SUBMIT PREFERENCES';
  constructor(public isFromModal = false) {}
}

export class SubmitConsent {
  static readonly type = '[PREFERENCE] SUBMIT CONSENT';
  constructor(public isFromModal = false) {}
}

export class UpdatePreferencesAndConsent {
  static readonly type = '[PREFERENCE] UPDATE PREFERENCES AND CONSENT';
  constructor(public isFromModal = false) {}
}

export class UpdatePreferenceSuccess {
  static readonly type = '[PREFERENCE] UPDATE PREFERENCES SUCCESS';
  constructor() {}
}

export class SavePreferencesSuccess {
  static readonly type = '[PREFERENCE] SAVE PREFERENCES SUCCESS';
}

export class SavePreferencesFailed {
  static readonly type = '[PREFERENCE] SAVE PREFERENCES FAILED';
}

export class UpdatePreferenceSelection {
  static readonly type = '[PREFERENCE] UPDATE PREFERENCE SELECTION';
  constructor(public programId: string, public channelId: string, public isPreferenceSelected: boolean) {}
}

export class PossibleNowServiceFailure {
  static readonly type = '[PREFERENCE] POSSIBLE NOW SERVICE FAILURE';
}

export class OptInTextPreference {
  static readonly type = '[PREFERENCE] OPT IN TEXT PREFERENCE';
}
