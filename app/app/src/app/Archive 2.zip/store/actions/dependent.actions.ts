export class GetDependentList {
  static readonly type = '[DEPENDENT] GET DEPENDENT LIST';
}
