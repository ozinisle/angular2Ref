import { BenefitModel } from '@app/pages/fwb/models/benefit-model';

export class GetBenefitsInfo {
  static readonly type = '[FITNESS] GET BENEFITS INFO';
}

export class SetSelectedBenefit {
  static readonly type = '[FITNESS] SET SELECTED BENEFIT';
  constructor(public benefit: BenefitModel) {}
}

export class SetReimbursement {
  static readonly type = '[FITNESS] SET REIMBURSEMENT';
  constructor(public reimbursement: string) {}
}

export class GetReimbursementForm {
  static readonly type = '[FITNESS] GET REIMBURSEMENT FORM';
}

export class SubmitReimbursementForm {
  static readonly type = '[FITNESS] SUBMIT REIMBURSEMENT FORM';
  constructor(public form: any, public benefitsInfo: any) {}
}

export class UploadReimbursementReceipt {
  static readonly type = '[FITNESS] UPLOAD REIMBURSEMENT RECEIPT';
  constructor(public base64Photo: string, public blob: Blob, public size: string, public bytes: number) {}
}

export class DeleteImage {
  static readonly type = '[FITNESS] DELETE IMAGE';
  constructor(public index: number) {}
}

export class ClearImages {
  static readonly type = '[FITNESS] CLEAR IMAGES';
}

export class ShowProgressModal {
  static readonly type = '[FITNESS] SHOW PROGRESS MODAL';
}

export class HideProgressModal {
  static readonly type = '[FITNESS] HIDE PROGRESS MODAL';
}
