import { RegType } from '@app/enums/reg-type.enum';
import { CryptoModel } from '@app/models/crypto.model';
import { LoginRequest } from '@app/models/login-request.model';

export class PreRegisterState {
  static readonly type = '[REGISTER] PREPARE REGISTRATION STATE';
  constructor(public request: LoginRequest) {}
}

export class Register {
  static readonly type = '[REGISTER] REGISTER';
  constructor(
    public loginData: LoginRequest,
    public regType: RegType,
    public cryptoTokens: CryptoModel,
    public code: string,
    public consentData: any
  ) {}
}

export class RegistrationError {
  static readonly type = '[REGISTER] REGISTRATION ERROR';
  constructor(public error: any) {}
}

export class CheckUsernameValidity {
  static readonly type = '[REGISTER] CHECK USERNAME VALIDITY';
  constructor(
    public loginData: LoginRequest,
    public regType: RegType,
    public cryptoTokens: CryptoModel,
    public navigate = false
  ) {}
}

export class SetFromRegistration {
  static readonly type = '[REGISTER] SET FROM REGISTRATION';
  constructor(public value: boolean) {}
}

export class VerifyANVUser {
  static readonly type = '[REGISTER] VERIFY ANV USER';
  constructor(public useridin: string, public code, public type?: RegType, public commChannelValue?: string) {}
}

export class SendCode {
  static readonly type = '[REGISTER] SEND CODE';
  constructor(public id: string) {}
}
