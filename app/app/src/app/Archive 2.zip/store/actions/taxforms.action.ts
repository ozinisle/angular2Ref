export class GetTaxForms {
  static readonly type = '[TAXFORM] GET TAX FORMS';
  constructor(public year: number) {}
}
