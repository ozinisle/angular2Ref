export class GetFamilyDeductibles {
  static readonly type = '[DEDUCTIBLE] GET FAMILY DEDUCTIBLES';
  constructor(public id: string, public detailsPage: boolean) {}
}

export class GetIndividualDeductibles {
  static readonly type = '[DEDUCTIBLE] GET INDIVIDUAL DEDUCTIBLES';
  constructor(public name: string, public type: string) {}
}

export class SetDeductiblesLoading {
  static readonly type = '[DEDUCTIBLE] SET DEDUCTIBLES LOADING';
  constructor(public isLoading: boolean) {}
}

export class SetErrorFlag {
  static readonly type = '[DEDUCTIBLE] GET ERROR FLAG';
  constructor(public isGotError: boolean) {}
}
