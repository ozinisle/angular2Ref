import { BenefitSearchResultItem } from '@app/models/benefit-search-result';

export class Search {
  static readonly type = '[SEARCH] PERFORM SEARCH';
  constructor(public keyword: string) {}
}

export class SetSearchOnlyFlag {
  static readonly type = '[SEARCH] SET SEARCH ONLY FLAG';
  constructor(public isSearchOnly: boolean) {}
}

export class FilterSearchResults {
  static readonly type = '[SEARCH] FILTER SEARCH RESULTS';
  constructor(public currentPlan: string) {}
}

export class FilterByProduct {
  static readonly type = '[SEARCH] FILTER BY PRODUCT TYPE';
  constructor(public productType: string) {}
}

export class ViewBenefitDetails {
  static readonly type = '[SEARCH] VIEW BENEFIT DETAILS';
  constructor(public resultRow: BenefitSearchResultItem) {}
}
