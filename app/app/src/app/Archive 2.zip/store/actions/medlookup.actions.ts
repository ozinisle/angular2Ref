export class GetMedlookupInfo {
  static readonly type = '[MEDLOOKUP] GET Medlookup teir Info';
  constructor() {}
}
