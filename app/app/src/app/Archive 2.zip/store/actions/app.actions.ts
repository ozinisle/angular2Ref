import { AuthToken } from '@app/models/auth-token.model';
import { LoginRequest } from '@app/models/login-request.model';
import { MemberPlan } from '@app/models/member-plan.model';
import { HomePageAppInfoModel } from '@app/pages/home/home.model';
import { GetMemberProfileResponseModel } from '@app/pages/my-profile/models/get-member-profile-request.model';

export class ClearState {
  static readonly type = '[APP] CLEAR STATE';
  constructor(public navToLogin: boolean = true, public clearAuth?: boolean) {}
}

export class ClearInterval {
  static readonly type = '[APP] CLEAR INTERVAL';
}

export class Login {
  static readonly type = '[APP] LOGIN';
  constructor(public request?: LoginRequest, public flag?: boolean, public redirectUrl?: string) {}
}

export class Logout {
  static readonly type = '[APP] LOGOUT';
}

export class PostLogin {
  static readonly type = '[APP] POST LOGIN';
  constructor(public redirectUrl?: string) {}
}

export class SetLoader {
  static readonly type = '[APP] SET LOADER';
  constructor(public show: boolean) {}
}

export class SetUserID {
  static readonly type = '[APP] SET USER TYPE';
  constructor(public useridin: string) {}
}

export class SetUserType {
  static readonly type = '[APP] SET USER TYPE';
  constructor(public userType: string) {}
}

export class SetMLEEligibility {
  static readonly type = '[APP] SET MLE ELIGIBILITY';
  constructor(public eligibility: string) {}
}

export class SetMLEIndicator {
  static readonly type = '[APP] SET MLE INDICATOR';
  constructor(public indicator: string) {}
}

export class SetUserState {
  static readonly type = '[APP] SET USER STATE';
  constructor(public userState: any) {}
}

export class SetScopeVerified {
  static readonly type = '[APP] SET SCOPE TO VERIFIED';
}

export class SetRTMSMode {
  static readonly type = '[APP] SET RTMS MODE';
}

export class SetBasicMemberInfo {
  static readonly type = '[APP] SET BASIC MEMBER INFO';
  constructor(public basicMemberInfo: any) {}
}

export class SetHCCSFlag {
  static readonly type = '[APP] SET HCCS FLAG';
  constructor(public hccsFlag: string) {}
}

export class SetSelectedPlan {
  static readonly type = '[APP] SET SELECTED PLAN';
  //TODO: Need to write a selectedPlan Modal once the response structure is finalized
  constructor(public selectedPlan: MemberPlan, public url: string) {}
}

export class CheckForDefaultPlanSwitch {
  static readonly type = '[APP] CHECK FOR DEFAULT PLAN SWITCH';
  constructor(public url: string) {}
}

export class SetIPAAuthToken {
  static readonly type = '[APP] SET IPA AUTH TOKEN';
  constructor(public authToken: AuthToken) {}
}

export class GetTokens {
  static readonly type = '[APP] GET TOKENS';
  constructor(public request?: LoginRequest, public isRegister = false, public isfadanonymous = false, public redirectUrl = null) {}
}

export class GetCryptoTokens {
  static readonly type = '[APP] GET CRYPTO TOKENS';
}

export class SetPostLogin {
  static readonly type = '[APP] SET POST LOGIN';
}

export class GetDrupalConsent {
  static readonly type = '[APP] GET DRUPAL CONSENT';
  constructor(public useridin?: string) {}
}

export class SetDeepLink {
  static readonly type = '[APP] SET DEEP LINK';
  constructor(public route: string) {}
}

export class GetMemAuthInfo {
  static readonly type = '[APP] GET MEM AUTH INFO';
  constructor(public shouldNavigate: boolean) {}
}

export class SetMemAuthInfo {
  static readonly type = '[APP] SET MEM AUTH INFO';
  constructor(public memberInfo: any) {}
}

export class UpdateConsent {
  static readonly type = '[APP] UPDATE CONSENT';
  constructor(public request: any) {}
}

export class ResetTokens {
  static readonly type = '[APP] RESET TOKENS';
}

export class SetMemProfile {
  static readonly type = '[APP] SET MEM PROFILE';
  constructor(public memProfile: GetMemberProfileResponseModel) {}
}

export class ShowIdleSessionModal {
  static readonly type = '[APP] SHOW IDLE SESSION MODAL';
}

export class ResetIdleWatch {
  static readonly type = '[APP] RESET IDLE WATCH';
}

export class StopIdleWatch {
  static readonly type = '[APP] STOP IDLE WATCH';
}

export class SessionSetup {
  static readonly type = '[APP] SESSION SETUP';
  constructor(public authToken: AuthToken) {}
}

export class SetMemberInfo {
  static readonly type = '[APP] SET MEMBER INFO';
  constructor(public memberInfo: HomePageAppInfoModel) {}
}

export class GetFinancialInfo {
  static readonly type = '[APP] GET FINANCIAL INFO';
}

export class IsSearchEnabled {
  static readonly type = '[APP] IS SEARCH ENABLED';
}

export class AppVersionInfo {
  static readonly type = '[APP] GET APP VERION INFO';
}

export class ShowEmailVerifyModal {
  static readonly type = '[APP] SHOW EMAIL VERIFY MODAL';
}

export class GetLocalTimeZone {
  static readonly type = '[APP] GET LOCAL TIMEZONE';
}

export class GetGeoLocation {
  static readonly type = '[APP] GET GEO LOCATION';
  constructor(public reset?: boolean) {}
}

export class GetGeoLocationDetails {
  static readonly type = '[APP] GET GEO LOCATION DETAILS';
  constructor() {}
}

export class StopWelcomeVideoPlay {
  static readonly type = '[APP] STOP WELCOME VIDEO PLAY';
  constructor(public stopWelcomeVideoPlay?: boolean) {}
}

export class GetPWKVideo {
  static readonly type = '[APP] GET WELCOME KIT VIDEO ';
  constructor() {}
}

export class GetPWKPdf {
  static readonly type = '[APP] STOP WELCOME KIT PDF';
  constructor() {}
}

export class GetPWKStatus {
  static readonly type = '[APP] STOP WELCOME KIT STATUS';
  constructor() {}
}

export class UpdatePWKSeenCounts {
  static readonly type = '[APP] UPDATE PWK SEEN COUNTS';
  constructor(public seenPwkVideoCount: number, public seenPwkPdfCount: number) {}
}