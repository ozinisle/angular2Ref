import { UpdateDemographicInfoRequestModel } from '@app/pages/my-profile/models/update-demographic-info.model';

export class FetchProfile {
  static readonly type = '[PROFILE] FETCH PROFILE';
  constructor(public forceFetch?: boolean) {}
}

export class UpdateProfile {
  static readonly type = '[PROFILE] UPDATE PROFILE';
  constructor(
    public payload: any,
    public editAddress: boolean,
    public editEmail: boolean,
    public editPhone: boolean,
    public editHint = false,
    public editHealth = false,
    public isFromModal = false
  ) {}
}

export class UpdateProfileSuccess {
  static readonly type = '[PROFILE] UPDATE PROFILE DONE';
}

export class UpdateProfileError {
  static readonly type = '[PROFILE] UPDATE PROFILE SUCCESS';
}

export class VerifyEmail {
  static readonly type = '[PROFILE] VERIFY EMAIL';
  constructor(public email: string, public isResend = false, public isFromModal = false, public fromContactFlag = false) {}
}

export class VerifyPhone {
  static readonly type = '[PROFILE] VERIFY PHONE';
  constructor(public phoneNumber: string, public isResend = false, public isFromModal = false, public fromContactFlag = false) {}
}

export class SetEmailVerification {
  static readonly type = '[PROFILE] SET EMAIL VERIFICATION';
  constructor(public emailVerification: boolean, public emailAddress?: string) {}
}

export class VerifyAccessCode {
  static readonly type = '[PROFILE] VERIFY ACCESS CODE';
  constructor(public accessCode: string, public isMyPillpack = false, public isFromModal = false) {}
}

export class VerificationCodeResent {
  static readonly type = '[PROFILE] VERIFICATION CODE RESENT';
}

export class VerificationCodeSent {
  static readonly type = '[PROFILE] VERIFICATION CODE SENT';
}

export class VerificationDone {
  static readonly type = '[PROFILE] VERIFICATION DONE';
}

export class SendNotification {
  static readonly type = '[PROFILE] SEND NOTIFICATION';
  constructor(public isEmailEdit: boolean, commChannel: string, commChannelType: string) {}
}

export class GetDemographicInfo {
  static readonly type = '[PROFILE] GET DEMOGRAPHIC INFO';
}

export class UpdateDemographicInfo {
  static readonly type = '[PROFILE] UPDATE DEMOGRAPHIC INFO';
  constructor(public payload: UpdateDemographicInfoRequestModel) {}
}

export class UpdateDemographicSuccess {
  static readonly type = '[PROFILE] UPDATE DEMOGRAPHIC INFO SUCCESS';
}

export class UpdatePassword {
  static readonly type = '[PROFILE] UPDATE PASSWORD';
  constructor(public payload: any) {}
}

export class UpdatePasswordSuccess {
  static readonly type = '[PROFILE] UPDATE PASSWORD SUCCESS';
}

export class GetConsent {
  static readonly type = '[PROFILE] GET CONSENT';
  constructor(public useridin: string, public isFromCheckModal = false) {}
}

export class GetConsentSuccessful {
  static readonly type = '[PROFILE] GET CONSENT SUCCESSFUL';
}

export class UpdateConsent {
  static readonly type = '[PROFILE] UPDATE CONSENT';
  constructor(public request: any, public isVerifyFlow = false) {}
}

export class UpdateConsentState {
  static readonly type = '[PROFILE] UPDATE CONSENT IN STATE';
  constructor(public consentFlag: string) {}
}

export class GetProfileDrupalConsent {
  static readonly type = '[PROFILE] GET DRUPAL CONSENT';
  constructor() {}
}

export class SetVerificationCategory {
  static readonly type = '[PROFILE] SET VERIFICATION CATEGORY';
  constructor(public verifyCategory: any) {}
}

export class CheckForModal {
  static readonly type = '[PROFILE] CHECK FOR MODAL';
  constructor() {}
}

export class ShowModal {
  static readonly type = '[PREFERENCE] SHOW  MODAL';
}

export class ShowConsentModal {
  static readonly type = '[PROFILE] SHOW  CONSENT MODAL';
}

export class SetUpdatePreferenceFlag {
  static readonly type = '[PROFILE] SET UPDATE PREFERENCE FLAG';
  constructor(public updatePreferenceFlag: boolean) {}
}

export class SetModalSection {
  static readonly type = '[PROFILE] SET MODAL SECTION';
  constructor(public modalSection: string) {}
}

export class SetUpdatedCommChannel {
  static readonly type = '[PROFILE] SET UPDATED COMM CHANNEL';
  constructor(public channelType: string, public channelValue: string) {}
}

export class ResetVerifyFlags {
  static readonly type = '[PROFILE] RESET VERIFY FLAGS';
}

export class SetPhoneNumberRequiredFlag {
  static readonly type = '[PROFILE] SET PHONE NUMBER REQUIRED FLAG';
  constructor(public isPhoneNumberRequired: boolean) {}
}

export class SetSkipVerifyPhoneFlag {
  static readonly type = '[PROFILE] SET SKIP VERIFY PHONE FLAG';
  constructor(public isSkipVerifyPhone: boolean) {}
}

export class InitAboutMeModal {
  static readonly type = '[PROFILE] INIT ABOUT ME MODAL';
}

export class VerifyEmailModal {
  static readonly type = '[PROFILE] VERIFY EMAIL MODAL';
}

export class ShowAboutMeModal {
  static readonly type = '[PROFILE] SHOW ABOUT ME MODAL';
}

export class NotifyDemographicModalDisplayed {
  static readonly type = '[PROFILE] NOTIFY DEMOGRAPHIC MODAL DISPLAYED';
}

export class TeleHealthInfo {
  static readonly type = '[TELEHEALTH] GET TELEHEALTH INFO';
}

export class TelehealthInfoLoaded {
  static readonly type = '[TELEHEALTH] TELEHEALTH INFO LOADED';
}

export class UpdateTeleHealthDisclaimerFlag {
  static readonly type = '[TELEHEALTH] UPDATE TELEHEALTH DISCLAIMER FLAG';
  constructor(public disclaimerFlag: boolean) {}
}
