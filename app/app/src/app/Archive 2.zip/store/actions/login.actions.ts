import { LoginRequest } from '@app/models/login-request.model';

export class SetUserName {
  static readonly type = '[LOGIN] SET USERNAME';
  constructor(public username: string) {}
}

export class SetRememberMe {
  static readonly type = '[LOGIN] SET REMEMBER ME';
  constructor(public rememberMe: boolean) {}
}

export class ShowPassword {
  static readonly type = '[LOGIN] SHOW PASSWORD';
  constructor(public showPassword: boolean) {}
}

export class SetBioData {
  static readonly type = '[LOGIN] SET BIODATA';
  constructor(public bioData: LoginRequest) {}
}
