import { DeductibleModel } from '@app/models/deductible.model';
import { AccumulatorModel } from '@app/pages/deductibles/models/accumulator.model';
import { OverallDeductibleModel } from '@app/pages/deductibles/models/overall-deductible.model';
import { CoinsuranceDeductibleModel } from '@app/pages/deductibles/models/coinsurance-deductible.model';
import { OutOfPocketDeductibleModel } from '@app/pages/deductibles/models/out-of-pocket-deductible.model';
import { OverallBenefitModel } from '@app/pages/deductibles/models/overall-benefit.model';
import { IndividualDeductibleRequestModel } from '@app/pages/deductibles/models/individual-deductible-request.model';


export const networkStatusMap = { Out: 'Out-of-Network', In: 'In-Network', 'In/Out': 'In-Network and Out-of-Network Combined' };
export const networkStatusMapBlueChoice = { Out: 'Self-Referred', In: 'PCP/Plan Approved', 'In/Out': 'PCP/Plan Approved and Self-Referred Combined' };

export const setOutOfPocketDeductibles = (
  deductiblesArray: DeductibleModel[],
  accumulators,
  planName,
  planStartDate,
  planEndDate,
  fullName,
  coverageType,
  networkstatus
) => {
  const outOfPocketArray =
    accumulators && accumulators.outOfPocket && accumulators.outOfPocket.length > 0 ? accumulators.outOfPocket : null;
  if (outOfPocketArray) {
    outOfPocketArray.forEach((deductible: OutOfPocketDeductibleModel) => {
      const planExists = !deductiblesArray.some((ded: DeductibleModel) => ded.planName === planName);
      deductiblesArray.push({
        showDates: planExists,
        planName: planName,
        isIndividual: null,
        networkStatus: networkstatus[deductible.networkIndicatorForOutOfPocketMax],
        totalAmount: Number(deductible.outOfPocketMax),
        contributed: Number(deductible.oopMaxContributed),
        contributedLabel: 'Contributed',
        remainingLabel: 'Remaining to Meet',
        remaining: Number(deductible.oopMaxRemainingToMeet),
        type: 'Out-Of-Pocket Maximum',
        startDate: planStartDate,
        endDate: planEndDate,
        memberName: fullName,
        limitations: deductible.oopMaxLimitationContent,
        exceptions: deductible.oopMaxExclusionExcep,
        coverageType
      });
    });
  }
};

export const setOverallDeductibles = (
  deductiblesArray: DeductibleModel[],
  accumulators: AccumulatorModel,
  planName: string,
  planStartDate: string,
  planEndDate: string,
  fullName: string,
  familyFilter: boolean,
  networkstatus,
  coverageType?: string,
  hasFirstDollar?: boolean,
  isDetailsPage?: boolean, 
) => {
  const overallDeductiblesArray =
    accumulators && accumulators.overallDeductibles && accumulators.overallDeductibles.length > 0 ? accumulators.overallDeductibles : null;

  if (overallDeductiblesArray) {
    overallDeductiblesArray.forEach((deductible: OverallDeductibleModel) => {
      if (hasFirstDollar && !familyFilter) {
        if (deductible.isFDCDollarsDeductible && Number(deductible.deductibleContributed) < 500) {
          deductiblesArray.unshift(createOverallModal(deductible, planName, fullName, planStartDate, planEndDate, true, coverageType, networkstatus));
          deductiblesArray.forEach((ded: DeductibleModel) => {
            if (!ded.isFirstCoverage && ded.planName === planName) {
              ded.showDates = false;
            }
          });
        } else if (deductible.isIndividualOverallDeductible || deductible.isFDCDollarsDeductible) {
          const planExists = !deductiblesArray.some((ded: DeductibleModel) => ded.planName === planName);
          deductiblesArray.push(createOverallModal(deductible, planName, fullName, planStartDate, planEndDate, planExists, coverageType, networkstatus));
        }
      } else if (
        (!familyFilter && isDetailsPage) ||
        (deductible.isFamilyOverallDeductible && familyFilter) ||
        (!familyFilter && deductible.isIndividualOverallDeductible)
      ) {
        const planExists = !deductiblesArray.some((ded: DeductibleModel) => ded.planName === planName);
        deductiblesArray.push(createOverallModal(deductible, planName, fullName, planStartDate, planEndDate, planExists, coverageType, networkstatus));
      }
    });

    if (!isDetailsPage && deductiblesArray.length > 1 && deductiblesArray[0].isFirstCoverage && deductiblesArray[0].contributed === 500) {
      deductiblesArray.push(deductiblesArray.shift());
      deductiblesArray[0].showDates = true;
      deductiblesArray[deductiblesArray.length - 1].showDates = false;
    }
  }
};

export const createOverallModal = (
  deductible: OverallDeductibleModel,
  planName: string,
  fullName: string,
  planStartDate: string,
  planEndDate: string,
  planExists: boolean,
  coverageType: string,
  networkstatus
) => {
  return {
    networkStatus: networkstatus[deductible.networkIndicatorForOverallDeductible],
    showDates: planExists,
    isIndividual: deductible.isIndividualOverallDeductible || deductible.isFDCDollarsDeductible,
    showHomePage: deductible.isFirstCoverage,
    type: deductible.isFDCDollarsDeductible ? 'First Coverage' : 'Overall Deductible',
    planName: planName,
    memberName: fullName,
    isFirstCoverage: deductible.isFirstCoverage,
    startDate: planStartDate,
    endDate: planEndDate,
    contributedLabel: deductible.isFDCDollarsDeductible ? 'Paid by Blue Cross' : 'Contributed',
    remainingLabel: deductible.isFDCDollarsDeductible ? 'Remaining' : 'Remaining to Meet',
    totalAmount: Number(deductible.overallDeductible),
    contributed: Number(deductible.deductibleContributed),
    remaining: Number(deductible.deductibleRemainingToMeet),
    limitations: deductible.overallDeductibleLimitationContent,
    exceptions: deductible.overallDeductibleExclusionExcep,
    coverageType: coverageType
  };
};

export const setCoinsuranceArray = (deductiblesArray: DeductibleModel[], accumulators, planName, planStartDate, planEndDate, fullName, coverageType, networkstatus) => {
  const coinsuranceArray =
    accumulators && accumulators.coinsurance && accumulators.coinsurance.length > 0 ? accumulators.coinsurance : null;
  if (coinsuranceArray) {
    coinsuranceArray.forEach((deductible: CoinsuranceDeductibleModel) => {
      const planExists = !deductiblesArray.some((ded: DeductibleModel) => ded.planName === planName);
      deductiblesArray.push({
        networkStatus: networkstatus[deductible.networkIndicatorForCoinsurance],
        showDates: planExists,
        planName: planName,
        type: 'Coinsurance',
        isIndividual: null,
        startDate: planStartDate,
        endDate: planEndDate,
        remainingLabel: 'Remaining',
        remaining: Number(deductible.coinsuranceRemainingMeet),
        contributed: Number(deductible.coinsuranceContributed),
        totalAmount: Number(deductible.coinsuranceMax),
        contributedLabel: 'Contributed',
        memberName: fullName,
        limitations: deductible.coinsuranceLimitationContent,
        exceptions: deductible.coinsuraneexclusionExcep,
        coverageType
      });
    });
  }
};

export const setOverallBenefitsArray = (
  deductiblesArray: DeductibleModel[],
  accumulators,
  planName,
  planStartDate,
  planEndDate,
  fullName,
  coverageType,
  networkStatus
) => {
  const overallBenefitArray =
    accumulators && accumulators.overallBenefit && accumulators.overallBenefit.length > 0 ? accumulators.overallBenefit : null;
  if (overallBenefitArray) {
    overallBenefitArray.forEach((deductible: OverallBenefitModel) => {
      const planExists = !deductiblesArray.some((ded: DeductibleModel) => ded.planName === planName);
      deductiblesArray.push({
        
        networkStatus: networkStatus[deductible.networkIndicatorOverallBenefit],
        showDates: planExists,
        planName: planName,
        isIndividual: null,
        type: 'Overall Benefit',
        startDate: planStartDate,
        endDate: planEndDate,
        remainingLabel: 'Remaining',
        remaining: Number(deductible.overallBenefitMaxRemainingToMeet),
        contributed: Number(deductible.overallBenefitMaxContributed),
        totalAmount: Number(deductible.overallBenefitMax),
        contributedLabel: 'Contributed',
        memberName: fullName,
        limitations: deductible.overallBenefitMaxLimitationContent,
        exceptions: deductible.overallBenefitexclusionExcep,
        coverageType
      });
    });
  }
};

export const setIndividualRequest = (selectedMember, userId) => {
  if (selectedMember) {
    return {
      coverageType: selectedMember.coverageType,
      memberSuffix: selectedMember.memSuffix !== '' ? selectedMember.memSuffix : selectedMember.loggedinUserSuffix,
      subscriberNo: selectedMember.subscriberNo,
      useridin: userId
    } as IndividualDeductibleRequestModel;
  }

  return null;
};

export const hasFirstDollarDeductible = (accumulators: AccumulatorModel) => {
  const overallDeductiblesArray = accumulators?.overallDeductibles?.length > 0 ? accumulators.overallDeductibles : null;
  return overallDeductiblesArray
    ? overallDeductiblesArray.some((deductible: OverallDeductibleModel) => deductible.isFDCDollarsDeductible)
    : false;
};

export const setDeductibles = (
  accums: AccumulatorModel[],
  deductibles: DeductibleModel[],
  fullName,
  familyFilter,
  hasFirstDollar,
  isDetailsPage
) => {
  accums.forEach((accumulator: AccumulatorModel) => {
    const planName = accumulator.planName;
    const planStartDate = accumulator.planStartDate;
    const planEndDate = accumulator.planEndDate;
    const coverageType = accumulator.coverageType;
    const networkstatus = accumulator.blueChoiceFlag ? networkStatusMapBlueChoice : networkStatusMap;

    if (accumulator.overallDeductibles || accumulator.coinsurance || accumulator.overallBenefit || accumulator.outOfPocket) {
      setOverallDeductibles(
        deductibles,
        accumulator,
        planName,
        planStartDate,
        planEndDate,
        fullName,
        familyFilter,
        networkstatus,
        coverageType,
        hasFirstDollar,
        isDetailsPage,
      );
      setOutOfPocketDeductibles(deductibles, accumulator, planName, planStartDate, planEndDate, fullName, coverageType, networkstatus);
      setCoinsuranceArray(deductibles, accumulator, planName, planStartDate, planEndDate, fullName, coverageType, networkstatus);
      setOverallBenefitsArray(deductibles, accumulator, planName, planStartDate, planEndDate, fullName, coverageType, networkstatus);
    } else {
      const planExists = deductibles.some((ded: DeductibleModel) => ded.planName === planName);
      deductibles.push({
        showDates: planExists,
        planName: planName,
        endDate: planEndDate,
        startDate: planStartDate,
        memberName: fullName,
        coverageType: coverageType
      });
    }
  });
};
