import { differenceInMilliseconds } from 'date-fns';
import { parse } from 'date-fns';
import { AppStateModel } from '../state/app.state';

export const getExpAccessTokenTime = (accessTokenExpiry): number => {
  //accessTokenExpiry format = "2021-Aug-06T03:54:30.463+00:00"
  const accessTokenExpires =  parse(accessTokenExpiry, "yyyy-MMM-dd'T'HH:mm:ss.SSSxxx", new Date('01/01/1990'));
  return differenceInMilliseconds(accessTokenExpires, (new Date().getTime() + 630000));
};

export const getUseridin = (state: AppStateModel): string => {
  let fadUseridin = '';
  const mleIndicator = state.mleIndicator;
  if (
    mleIndicator &&
    (mleIndicator === 'Y' || mleIndicator === 'lite' || mleIndicator === 'N') &&
    // @ts-ignore: Object is possibly 'null'.
    (state.authToken.scopename === this.constantsService['AUTHENTICATED_AND_VERIFIED'] ||
    // @ts-ignore: Object is possibly 'null'.
      state.authToken.scopename === this.constantsService['AUTHENTICATED_NOT_VERIFIED'])
  ) {
    fadUseridin = state.useridin;
  }
  return fadUseridin;
};
