import {
  createConsentObject,
  createPreferenceConsentObject,
  getCID,
  getPaperlessPromoFlag,
  extractProgramList,
  setFilterSelections,
  createPreferenceRequest
} from './preference-state.utils';

describe('PreferencesStateUtils', () => {
  it('should create  consent object ', () => {
    const consentData = { version: 2.0, body: '' };
    const userId = 'joan.harris1@yopmail.com';
    const consentObj = createConsentObject(consentData, userId);
    expect(consentObj.consentFlag).toEqual('Y');
    expect(consentObj.modalFlag).toEqual('Y');
    expect(consentObj.useridin).toEqual(userId);
    expect(consentObj.consentFlag).toEqual('Y');
    expect(consentObj.consentLanguageId).toEqual(consentData.version);
    expect(consentObj.consentTS).toEqual(consentObj.consentTS);
  });

  it('should create preferences consent object ', () => {
    const consentData = { version: 2.0, body: '' };
    const CID = 'EGRGAUIUGRURGAGJKF234234';
    const consentObj = createPreferenceConsentObject(consentData, '', CID, 'A', null);
    expect(consentObj.PreferenceType).toEqual('1');
    expect(consentObj.FilterID).toEqual('CONSENT_PAPERLESS_SOLICIT');
    expect(consentObj.CID).toEqual(CID);
    expect(consentObj.CustomerDate).toBeTruthy();
  });

  it('should extract Pref CID from Message', () => {
    const response = { message: { Preferences: [{ CID: 'ABC1231231231231' }] } };
    const CID = getCID(response);
    expect(CID).toEqual(response.message.Preferences[0].CID);
  });

  it('should extract Pref CID from Error Message', () => {
    const response = { errormessage: 'No Preference Available CID - ABCEFGHIJKLMNOPQRSTUVWXYZ012345678901234' };
    const CID = getCID(response);
    expect(CID).toEqual('ABCEFGHIJKLMNOPQRSTUVWXYZ012345678901234');
  });

  it('should get Paperless Promo Flag true', () => {
    const response = [{ CID: 'ABC1231231231231', PreferenceType: '1', FilterID: 'DOCS_PLAN_MAIL' }];
    const paperlessPromoFlag = getPaperlessPromoFlag(response);
    expect(paperlessPromoFlag).toEqual(true);
  });

  it('should get Paperless Promo Flag false', () => {
    const response = [{ CID: 'ABC1231231231231', PreferenceType: '2', FilterID: 'DOCS_PLAN_MAIL' }];
    const paperlessPromoFlag = getPaperlessPromoFlag(response);
    expect(paperlessPromoFlag).toEqual(false);
  });

  it('should extract program list', () => {
    const programGroups = {
      ProgramGroup: [
        {
          ID: 'Docs_Reqd',
          Name: 'Required Documents',
          Programs: [
            {
              ID: 'Documents_Plan',
              Name: 'Plan Documents',
              Description: '',
              DefaultLocaleID: 'en_US',
              ProgramType: 'Informational',
              DisplayOrder: 1010,
              CustomProperties: [
                { Key: 'DisplayBubbleIcon', Value: '<a href = url>icon</a>' },
                { Key: 'IsMultiSelect', Value: '0' },
                { Key: 'IsRequired', Value: '1' },
                { Key: 'IsRegulatory', Value: '1' }
              ],
              Locales: [{ ID: 'en_US', DisplayTags: [] }],
              Filters: [
                {
                  ChannelID: 'MAIL',
                  ProgramID: 'Documents_Plan',
                  ID: 'DOCS_PLAN_MAIL',
                  Name: 'Plan Documents - Mail',
                  Description: '',
                  DefaultPreferenceValue: 0,
                  DefaultLocaleID: 'en_US',
                  CustomProperties: [],
                  Locales: [{ ID: 'en_US', DisplayTags: [{ Key: 'Disclosure Text', Value: 'n/a' }] }],
                  FrequencyLocales: [],
                  PreferenceAttributes: []
                },
                {
                  ChannelID: 'SOLICIT',
                  ProgramID: 'Documents_Plan',
                  ID: 'DOCS_PLAN_ONLINE',
                  Name: 'Go Paperless - Plan Docs Online notify via \'Email"',
                  Description: '',
                  DefaultPreferenceValue: 1,
                  DefaultLocaleID: 'en_US',
                  CustomProperties: [{ Key: 'Related_Consent', Value: 'Consent_Paperless' }],
                  Locales: [{ ID: 'en_US', DisplayTags: [{ Key: 'Disclosure Text', Value: 'n/a' }] }],
                  FrequencyLocales: [],
                  PreferenceAttributes: []
                }
              ]
            }
          ]
        }
      ],
      CustomProperties: [{ Key: 'LOB', Value: 'Member' }, { Key: 'DisplayWeb', Value: 'True' }, { Key: 'DisplayAPP', Value: 'True' }]
    };
    const programList = extractProgramList(programGroups);
    expect(programList.length).toBeGreaterThan(0);
  });

  it('should set filter selections', () => {
    const programGroups = [
      {
        ID: 'Documents_Plan',
        displayName: 'Plan Documents',
        customProperties: [{ key: 'IsRequired', value: '1' }],
        filters: [
          { id: 'DOCS_PLAN_ONLINE', channelID: 'SOLICIT', selected: false },
          { id: 'DOCS_PLAN_SMS', channelID: 'SMS', selected: true },
          { id: 'DOCS_PLAN_MAIL', channelID: 'MAIL', selected: false }
        ]
      }
    ];
    const preferences = [
      {
        ProgramID: 'Documents_Plan',
        ChannelID: 'MAIL',
        UserID: 'BCMA_MYB_PC_MobApp',
        SourceID: 'BCMA_Pref_Centre_MYB_Mobile_App',
        LastModifiedDate: '5/29/2020 3:32:02 PM',
        FilterID: 'DOCS_PLAN_MAIL',
        CustomProperties: [],
        CID: 'EF6DF172AD384C389013BF7456F1CF9F8256F50A',
        PreferenceAttributes: [
          { Key: 'PS_Update_Type', Value: 'A' },
          { Key: 'PS_EventID', Value: '70b2ba20-caac-4087-89a2-feafc22a562c' },
          { Key: 'PS_SystemName', Value: 'MyBlue_PC_APP' },
          { Key: 'ConsentVerNo', Value: '2.0' }
        ],
        CustomerDate: '5/29/2020 3:31:55 PM'
      }
    ];
    const programList = setFilterSelections(programGroups, preferences);
    expect(programList[0].filters[0].selected).toEqual(false);
  });

  it('should create preferences consent object ', () => {
    const updatePreferenceInfo = { consentData: { version: 2.0, body: '' }, sessionId: 'S1' };
    const programList = [];
    const CID = 'EGRGAUIUGRURGAGJKF234234';
    const preferences = createPreferenceRequest(updatePreferenceInfo, programList, CID, 'A', null);
    expect(preferences).toBeTruthy();
  });
});
