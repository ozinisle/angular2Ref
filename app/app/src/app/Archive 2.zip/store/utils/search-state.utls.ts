import { BenefitSearchResultGroup } from '@app/models/benefit-search-result';

export function toTitleCase(text: string) {
    if (!text) {
        return text;
    }
    return text[0].toUpperCase() + text.substr(1);
}

export function filterSearchResultsByPlan(list: BenefitSearchResultGroup[], productType: string) {
    if (!list || !productType || productType === 'All Benefits') {
        return list;
    }
    return list.filter((plan) => plan.productType.toLowerCase() === productType.toLowerCase());
}
