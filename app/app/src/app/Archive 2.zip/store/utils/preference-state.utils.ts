import { format } from 'date-fns-tz';
import { formatDate } from '@angular/common';
import { Preference, PreferenceCenterProgram, PreferenceCenterFilter } from '@app/models/preference.model';
import { VerificationCodeSent, VerificationCodeResent } from '../actions/profile.action';


import { Navigate } from '@ngxs/router-plugin';
import {
  INVALID_PHONE_ERROR_CODES,
  MOBILE_NUMBER_ERROR_MSGS_SUFFIX,
  VERIFICATION_CODE_SENT_MSG,
  VALID_UPDATE_TYPES
} from '@app/store/constants/preference.constants';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { AlertService } from '@app/services/alert.service';

export const EDT_TZ_OFFSET = format(new Date(), 'xxx', { timeZone: 'America/New_York' });

export const PN_TS_FORMAT = 'M/d/yyyy h:m:s aa';

export const TS_LOCALE = 'en_US';
// export const isEmailDeliverable = null;

export const createPreferenceConsentObject = (consentObj, sessionid, prefCID, lastPrefUpdateType, lastPrefModifiedDate) => {
  const consent: any = {};
  consent.PreferenceType = '1';
  consent.FilterID = 'CONSENT_PAPERLESS_SOLICIT';
  consent.PreferenceAttributes = createPreferenceAttributes(consentObj, sessionid, lastPrefUpdateType, lastPrefModifiedDate);
  consent.CustomerDate =
    consentObj.consentFlag === 'Y' ? consentObj.consentTS : formatDate(new Date(), PN_TS_FORMAT, TS_LOCALE, EDT_TZ_OFFSET);
  consent.CID = prefCID;
  return consent;
};

export const createPreferenceAttributes = (data, sessionid, lastPrefUpdateType: string, lastPrefModifiedDate: string) => {
  const updateConsentType =
    lastPrefModifiedDate && VALID_UPDATE_TYPES.includes(lastPrefUpdateType)
      ? new Date(lastPrefModifiedDate).getDate() === new Date().getDate()
        ? lastPrefUpdateType
        : 'U'
      : 'A';
  return [
    {
      Key: 'PS_Update_Type',
      Value: updateConsentType
    },
    {
      Key: 'PS_EventID',
      Value: sessionid
    },
    {
      Key: 'PS_SystemName',
      Value: 'MyBlue_PC_APP'
    },
    {
      Key: 'ConsentVerNo',
      Value: data.version ? data.version : data.consentLanguageId
    }
  ];
};

export const getCID = response => {
  if (response.message) {
    return response.message.Preferences[0].CID;
  } else {
    return response.errormessage.slice(response.errormessage.length - 40);
  }
};

export const getPaperlessPromoFlag = res => {
  let value = [];
  // Gave == for preference type it can be both as a string and number
  // tslint:disable-next-line:triple-equals
  value = res && res.filter(item => item.PreferenceType == '1' && item.FilterID === 'DOCS_PLAN_MAIL');
  return value.length > 0;
};

export const createConsentObject = (consentData: any, useridin: string) => {
  const consentObj: any = {
    useridin: useridin,
    consentLanguageId: consentData.version || consentData.consentLanguageId,
    consentFlag: 'Y',
    consentTS: formatDate(new Date(), PN_TS_FORMAT, TS_LOCALE, EDT_TZ_OFFSET),
    modalFlag: 'Y'
  };
  if (consentData.body) {
    consentObj.consentLanguage = encodeURI(consentData.body);
  }
  return consentObj;
};

export const createPreferenceRequest = (
  updatePreferenceInfo: any,
  programList: PreferenceCenterProgram[],
  prefCID: string,
  lastPrefUpdateType: string,
  lastPrefModifiedDate: string
) => {
  let changedItem: Preference[] = [];
  let tempItem: any = {};
  let consent: any = {};
  const customerDate = formatDate(new Date(), PN_TS_FORMAT, TS_LOCALE, EDT_TZ_OFFSET);
  consent = createPreferenceConsentObject(
    updatePreferenceInfo.consentData,
    updatePreferenceInfo.sessionId,
    prefCID,
    lastPrefUpdateType,
    lastPrefModifiedDate
  );
  programList.map((program: PreferenceCenterProgram) => {
    program.filters.map((filter: PreferenceCenterFilter) => {
      tempItem = {};
      tempItem.PreferenceType = '';
      tempItem.FilterID = filter.id;
      tempItem.CustomerDate = customerDate;
      tempItem.PreferenceAttributes = createPreferenceAttributes(
        updatePreferenceInfo.consentData,
        updatePreferenceInfo.sessionId,
        lastPrefUpdateType,
        lastPrefModifiedDate
      );
      tempItem.CID = prefCID;
      if (filter.selected) {
        tempItem = { ...tempItem, PreferenceType: '1' };
      } else {
        tempItem = { ...tempItem, PreferenceType: '2' };
      }
      changedItem.push(tempItem);
    });
  });
  changedItem = [...changedItem, consent];
  return changedItem;
};

export const extractProgramList = (programGroups: any) => {
  const programList: PreferenceCenterProgram[] = [];
  let preferenceCenterProgram: PreferenceCenterProgram;
  if (programGroups && programGroups.ProgramGroup) {
    programGroups.ProgramGroup.map(group => {
      if (group.ID !== 'Consents_Available' && group.Programs[0]) {
        const filters: PreferenceCenterFilter[] = [];
        group.Programs[0].Filters.map((filter: any) => {
          filters.push({ id: filter.ID, channelID: filter.ChannelID, selected: false });
        });
        preferenceCenterProgram = {
          ID: group.Programs[0].ID,
          displayName: group.Programs[0].Name,
          customProperties: group.Programs[0].CustomProperties,
          filters: filters
        };
        group.Programs[0].Locales[0].DisplayTags.map((tag: any) => {
          preferenceCenterProgram = { ...preferenceCenterProgram, displayName: tag.Key === 'Name' ? tag.Value : '' };
        });
        programList.push(preferenceCenterProgram);
      }
    });
  }

  programList.forEach(program => {
    program.filters.forEach((filter, index) => {
      reOrderFilterArray(program, filter, index);
    });
  });
  return programList;
};

export const setFilterSelections = (programList: PreferenceCenterProgram[], preferences: any) => {
  programList.forEach(program => {
    program.filters.forEach((filter, index) => {
      filter.selected = false;
      preferences.forEach(channel => {
        if (filter.id === channel.FilterID && channel.PreferenceType === 1) {
          filter.selected = true;
        }
      });
    });
  });
  return programList;
};

export const isPlanDocumentSelected = (programList: PreferenceCenterProgram[], isCDHenabledUser: boolean) => {
  let planDocumentSelected = false;
  programList.forEach(program => {
    if (program.ID === 'Documents_Plan') {
      program.filters.forEach((filter, index) => {
        if (filter.selected && !(filter.channelID === 'MAIL' && isCDHenabledUser)) {
          planDocumentSelected = true;
        }
      });
    }
  });
  return planDocumentSelected;
};

export const isHealthBenefitSelected = (programList: PreferenceCenterProgram[]) => {
  let healthBenefitSelected = false;
  programList.forEach(program => {
    if (program.ID === 'Health_Benefits') {
      program.filters.forEach((filter, index) => {
        if (filter.selected) {
          healthBenefitSelected = true;
        }
      });
    }
  });
  return healthBenefitSelected;
};

export const reOrderFilterArray = (program: PreferenceCenterProgram, filter: PreferenceCenterFilter, index) => {
  filter.channelID === 'SOLICIT' || filter.channelID === 'EMAIL'
    ? program.filters.splice(0, 0, program.filters.splice(index, 1)[0])
    : filter.channelID === 'SMS'
    ? program.filters.splice(1, 0, program.filters.splice(index, 1)[0])
    : program.filters.splice(2, 0, program.filters.splice(index, 1)[0]);
};

export const sendVerificationCodeSucessMsg = (dispatch: any, alertService: AlertService, isResend: boolean, isFromModal: boolean) => {
  if (isResend) {
    dispatch(new VerificationCodeResent());
  } else {
    if (!isFromModal) {
      dispatch(new Navigate(['/myprofile/verify'])).subscribe(() => {
        alertService.setAlert(VERIFICATION_CODE_SENT_MSG, '', AlertType.Success);
      });
    } else {
      dispatch(new VerificationCodeSent());
      alertService.setAlert(VERIFICATION_CODE_SENT_MSG, '', AlertType.Success, 'preferenceModal');
    }
  }
};

export const sendVerificationCodeErrorMsg = (
  alertService: AlertService,
  result: number,
  errorMessage: string,
  isFromModal: boolean,
  isPreferanceView?: boolean,
  isPhoneNumberRequired?: boolean
) => {
  if (!isFromModal && !isPreferanceView) {
    alertService.setAlert(errorMessage, '', AlertType.Failure);
  } else {
    const component = isFromModal ? 'preferenceModal' : 'component';
    if (isPreferanceView && INVALID_PHONE_ERROR_CODES.indexOf(result) !== -1) {
      if (isPhoneNumberRequired) {
        alertService.setAlert(errorMessage + MOBILE_NUMBER_ERROR_MSGS_SUFFIX.WITH_MOBILE_PREF, '', AlertType.Failure, component);
      } else {
        alertService.setAlert(errorMessage + MOBILE_NUMBER_ERROR_MSGS_SUFFIX.WITHOUT_MOBILE_PREF, '', AlertType.Failure, component);
      }
    } else {
      alertService.setAlert(errorMessage, '', AlertType.Failure, component);
    }
  }
};

export const isMobilePreferenceSelected = programList => {
  let isMobilePref = false;
  programList.forEach(program => {
    program.filters.forEach(filter => {
      if (filter.channelID === 'SMS' && filter.selected && !isMobilePref) {
        isMobilePref = true;
      }
    });
  });
  return isMobilePref;
};

export const getLastPreferenceUpdates = (preferences: any) => {
  const lastPrefUpdates = { lastPrefUpdateType: null, lastPrefModifiedDate: null };
  preferences
    .filter(preference => preference.FilterID === 'DOCS_PLAN_ONLINE')
    .forEach(preference => {
      lastPrefUpdates.lastPrefModifiedDate = preference.LastModifiedDate ? preference.LastModifiedDate : null;
      preference.PreferenceAttributes.filter(preferenceAttribute => preferenceAttribute.Key === 'PS_Update_Type').forEach(
        preferenceAttribute => {
          lastPrefUpdates.lastPrefUpdateType = preferenceAttribute.Value;
        }
      );
    });
  return lastPrefUpdates;
};

export const hasConsentPreference = (preferences: any) => {
  return preferences.filter(preference => preference.FilterID === 'CONSENT_PAPERLESS_SOLICIT').length;
};

export const isUserChannelBounced = (preferences: any) => {
  let userChannelBounced;
  let reasonCD;
  preferences[0].PreferenceAttributes.forEach(element => {
    if (element.Key === 'CE_Type') {
      userChannelBounced = element.Value;
    }
    if (element.Key === 'Reason_Cd') {
      reasonCD = element.Value;
    }
  });
  if (userChannelBounced === 'SMS') {
    if (reasonCD === 'Temporary Error' || reasonCD === 'Permanent Error' || reasonCD === 'MobileScore') {
      userChannelBounced = 'SMS';
    } else {
      userChannelBounced = '';
    }
  }
  return userChannelBounced;
};
