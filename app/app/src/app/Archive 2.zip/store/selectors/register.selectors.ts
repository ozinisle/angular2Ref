import { Selector } from '@ngxs/store';
import { RegisterState, RegisterStateModel } from '@app/store/state/register.state';

export class RegisterSelectors {
  @Selector([RegisterState])
  static fromRegistration(state: RegisterStateModel): boolean {
    return state.fromRegistration;
  }

  @Selector([RegisterState])
  static onVerifyScreen(state: RegisterStateModel): boolean {
    return state.onVerifyScreen;
  }
}
