import { Selector } from '@ngxs/store';
import { LoginState, LoginStateModel } from '../state/login.state';
import { LoginRequest } from '../../models/login-request.model';

export class LoginSelectors {
  @Selector([LoginState])
  static getUsername(state: LoginStateModel): string {
    return state.username;
  }

  @Selector([LoginState])
  static getRememberMe(state: LoginStateModel): boolean {
    return state.rememberMe;
  }

  @Selector([LoginState])
  static showPassword(state: LoginStateModel): boolean {
    return state.showPassword;
  }

  @Selector([LoginState])
  static getBioData(state: LoginStateModel): LoginRequest {
    return state.bioData;
  }
}
