import { Selector } from '@ngxs/store';
import { TaxFormsModel } from '../../pages/message-center/tax-forms/models/tax-froms-models';
import { TaxFormModel, TaxFormsState } from '../state/taxforms.state';

export class TaxFormsSelectors {
  @Selector([TaxFormsState])
  static getTaxForms(state: TaxFormModel): TaxFormsModel[] {
    return state.taxforms;
  }
}
