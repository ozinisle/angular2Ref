import { formatDate } from '@angular/common';
import { RegType } from '@app/enums/reg-type.enum';
import { AuthToken } from '@app/models/auth-token.model';
import { DrupalConsentModel } from '@app/models/drupal-consent.model';
import { Finanical } from '@app/models/finanical.model';
import { MemberPlan } from '@app/models/member-plan.model';
import { PostLoginModel } from '@app/models/post-login.model';
import { PWKVideo } from '@app/models/welcome-kit.model';
import { HomePageAppInfoModel } from '@app/pages/home/home.model';
import { GetMemberProfileResponseModel } from '@app/pages/my-profile/models/get-member-profile-request.model';
import { EDT_TZ_OFFSET, PN_TS_FORMAT, TS_LOCALE } from '@app/store/utils/preference-state.utils';
import { getPharmacyLinkType } from '@app/utils/app.utils';
import { Selector } from '@ngxs/store';
import { AppState, AppStateModel } from '../state/app.state';
import { getUseridin } from '../utils/app-state.utils';

export class AppSelectors {
  @Selector([AppState])
  static getAuthToken(state: AppStateModel): AuthToken {
    return state.authToken;
  }

  @Selector([AppState])
  static isActiveUser(state: AppStateModel): string {
    return state.authToken.HasActivePlan;
  }

  /**
   * @returns Whether the current user has had plan coverage at some point
   * (does not have to be active coverage).
   */
  @Selector([AppState])
  static hasHadCoverage(state: AppStateModel): boolean {
    const coverageTimestamp = !state.postLoginInfo || !state.postLoginInfo.coverageEffecDt ? null : state.postLoginInfo.coverageEffecDt;
    const hasHadCoverage = coverageTimestamp && new Date(coverageTimestamp) < new Date();
    return hasHadCoverage;
  }

  @Selector([AppState])
  static getSelectedPlan(state: AppStateModel): any {
    return state.selectedPlan || (state.getPlansList.length > 0 ? state.getPlansList[0] : {});
  }

  @Selector([AppState])
  static isDefaultPlan(state: AppStateModel): boolean {
    return !state.selectedPlan || state.selectedPlan?.defaultPlan === 'true';
  }

  @Selector([AppState])
  static getPlansList(state: AppStateModel): MemberPlan[] {
    return state.getPlansList;
  }

  @Selector([AppState])
  static getAccessToken(state: AppStateModel): string {
    return state.authToken ? state.authToken.access_token : null;
  }

  @Selector([AppState])
  static getMedicareUserCheck(state: AppStateModel): boolean {
    return state?.authToken?.userType?.toLowerCase() === 'medicare' || false;
  }

  @Selector([AppState])
  static getDrupalConsent(state: AppStateModel): DrupalConsentModel {
    return state.drupalConsent;
  }

  @Selector([AppState])
  static getConsentObject(state: AppStateModel): any {
    return {
      consentLanguageId: state?.drupalConsent?.Version,
      consentLanguage: state?.drupalConsent?.Body,
      consentFlag: 'Y',
      consentTS: formatDate(new Date(), PN_TS_FORMAT, TS_LOCALE, EDT_TZ_OFFSET),
    };
  }

  @Selector([AppState])
  static getDeepLink(state: AppStateModel): string {
    return state.route;
  }

  @Selector([AppState])
  static getMemProfile(state: AppStateModel): GetMemberProfileResponseModel {
    return state.memProfile;
  }

  @Selector([AppState])
  static getMemZipCode(state: AppStateModel): string {
    return state.memProfile?.zip;
  }

  @Selector([AppState])
  static getRefreshToken(state: AppStateModel): string {
    return state.authToken ? state.authToken.refresh_token : null;
  }

  @Selector([AppState])
  static isAuthenticated(state: AppStateModel): boolean {
    return state.authToken != null;
  }

  @Selector([AppState])
  static getTokenExpiry(state: AppStateModel): string {
    return state.authToken.access_token_expires;
  }

  @Selector([AppState])
  static isUserScopeAuthenticated(state: AppStateModel): boolean {
    return (
      state.authToken &&
      (state.authToken.scopename === 'AUTHENTICATED_AND_VERIFIED' || state.authToken.scopename === 'AUTHENTICATED_NOT_VERIFIED')
    );
  }

  @Selector([AppState])
  static getLoaderState(state: AppStateModel): boolean {
    return state.showLoader;
  }

  @Selector([AppState])
  static getUserID(state: AppStateModel): string {
    return state.useridin;
  }

  @Selector([AppState])
  static getUserType(state: AppStateModel): string {
    return state.authToken.userType;
  }

  @Selector([AppState])
  static getUserState(state: AppStateModel): any {
    return state.userState;
  }

  @Selector([AppState])
  static getMLEIndicator(state: AppStateModel): string {
    return state.mleIndicator;
  }

  @Selector([AppState])
  static getMLEEligibility(state: AppStateModel): string {
    return state.mleEligibility;
  }

  @Selector([AppState])
  static getMemAuthInfo(state: AppStateModel): any {
    return state.memAuthInfo;
  }

  @Selector([AppState])
  static getHHCSFlag(state: AppStateModel): string {
    return state.hccsFlag;
  }

  @Selector([AppState])
  static getScopeName(state: AppStateModel): string {
    return state.authToken ? state.authToken.scopename : '';
  }

  @Selector([AppState])
  static isAuthenticatedUser(state: AppStateModel): boolean {
    return state.authToken.scopename?.includes('AUTHENTICATED');
  }

  @Selector([AppState])
  static getBasicMemberInfo(state: AppStateModel): any {
    return state.basicMemInfo;
  }

  @Selector([AppState])
  static getCryptoToken(state: AppStateModel): any {
    return state.cryptoTokens;
  }

  @Selector([AppState])
  static getRegType(state: AppStateModel): RegType {
    return state.regType;
  }

  @Selector([AppState])
  static getUserRegistrationType(state: AppStateModel): RegType {
    return state.useridin && state.useridin.indexOf('@') === -1 ? RegType.MOBILE : RegType.EMAIL;
  }

  @Selector([AppState])
  static getUnionBlueMemberInfo(state: AppStateModel): PostLoginModel {
    return state.postLoginInfo.isUnionBlueMember;
  }
  @Selector([AppState])
  static getPostLoginInfo(state: AppStateModel): PostLoginModel {
    return state.postLoginInfo;
  }

  @Selector([AppState])
  static getcommstatus(state: AppStateModel): any {
    return state.commstatus;
  }

  @Selector([AppState])
  static getSessionId(state: AppStateModel): string {
    return state.sessionId;
  }

  @Selector([AppState])
  static getPharmacyLinks(state: AppStateModel): any {
    let pharmacyLinks = null;
    if (state.postLoginInfo) {
      if (state.postLoginInfo.pharmacyLinks && state.postLoginInfo.pharmacyLinks.length > 0) {
        const servicePharmacyLinks = state.postLoginInfo.pharmacyLinks;
        const pharmacyLinkTypes = [];
        servicePharmacyLinks.forEach((pharmacyLink) => {
          const pharmacyLinkType = getPharmacyLinkType(pharmacyLink.text, pharmacyLink.url);
          if (pharmacyLinkType) {
            pharmacyLinkTypes.push(pharmacyLinkType);
          }
        });
        pharmacyLinks = pharmacyLinkTypes;
      }
    } else {
      pharmacyLinks = [];
    }
    return pharmacyLinks;
  }

  @Selector([AppState])
  static getFADHCCSFlag(state: AppStateModel): any {
    if (state.hccsFlag && getUseridin(state) !== '') {
      return state.hccsFlag !== 'false';
    } else if (state.hccsFlag && getUseridin(state) === '') {
      return null;
    } else {
      return state.hccsFlag;
    }
  }

  @Selector([AppState])
  static getHasNoAltAdd(state: AppStateModel): boolean {
    return state.hasNoAltAdd;
  }

  @Selector([AppState])
  static getLearnToLive(state: AppStateModel): PostLoginModel {
    return state.postLoginInfo.wellnessPrograms;
  }

  @Selector([AppState])
  static getFinancialsInfo(state: AppStateModel): Finanical[] {
    return state.financialInfo;
  }

  @Selector([AppState])
  static isLoadingFinancial(state: AppStateModel): boolean {
    return state.isLoadingFinancial;
  }

  @Selector([AppState])
  static getMemberInfo(state: AppStateModel): HomePageAppInfoModel {
    return state.memberInfo;
  }

  @Selector([AppState])
  static hasMedicalAccounts(state: AppStateModel): boolean {
    return state.hasMedicalAccounts;
  }

  @Selector([AppState])
  static isSearchEnabled(state: AppStateModel): boolean {
    return state.isSearchEnabled;
  }

  @Selector([AppState])
  static getSearchableCpcs(state: AppStateModel): any[] {
    return state.searchableCPCs;
  }

  @Selector([AppState])
  static getAppPackageName(state: AppStateModel): string {
    return state.packageName;
  }

  @Selector([AppState])
  static getLocalTimezone(state: AppStateModel): string {
    return state.localTimezone;
  }

  @Selector([AppState])
  static getEbilling(state: AppStateModel): boolean {
    return state.postLoginInfo.ebillingEligibility;
  }

  @Selector([AppState])
  static getGeoLocationState(state: AppStateModel): string {
    return state.currentLocationDetails?.administrativeArea;
  }

  @Selector([AppState])
  static getShowEmailVerifyMoalFlag(state: AppStateModel): boolean {
    return state.postLoginInfo.showEmailVerifyModal;
  }

  @Selector([AppState])
  static getUserEmailAddress(state: AppStateModel): string {
    return state.memProfile?.emailAddress;
  }

  @Selector([AppState])
  static isStopWelcomeVideoPlay(state: AppStateModel): boolean {
    return state.stopWelcomeVideoPlay;
  }

  @Selector([AppState])
  static getPwkPdfUrl(state: AppStateModel): string {
    return state.medicareWKPDF;
  }

  @Selector([AppState])
  static getPwkVideo(state: AppStateModel): PWKVideo {
    return state.pwkVideo;
  }

  @Selector([AppState])
  static hasNewPwkMessage(state: AppStateModel): boolean {
    return state.pwkStatus?.medicareDocExists && state.pwkStatus?.seenMedicarePDF === 0;
  }

  @Selector([AppState])
  static hasWelcomeVideo(state: AppStateModel): boolean {
    return state.pwkStatus?.medicareVideoExists && state.pwkVideo?.stream && state.pwkStatus?.seenMedicareVideo < 3;
  }

  @Selector([AppState])
  static hasWelcomePDF(state: AppStateModel): boolean {
    return state.pwkStatus?.medicareDocExists;
  }

  @Selector([AppState])
  static isPWKAvailable(state: AppStateModel): boolean {
    return this.getMedicareUserCheck(state) && (state.pwkStatus?.medicareDocExists || state.pwkStatus?.medicareVideoExists);
  }
}
