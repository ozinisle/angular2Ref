import { Selector } from '@ngxs/store';
import { DependentState, DependentStateModal } from '../state/dependent.state';
import { DependentModel } from '../../models/dependent.model';

export class DependentSelectors {
  @Selector([DependentState])
  static getDependentsList(state: DependentStateModal): DependentModel[] {
    return state.dependents;
  }
}
