import { Selector } from '@ngxs/store';
import { PreferenceState, PreferenceStateModel } from './../state/preference.state';

export class PreferenceSelectors {
  @Selector([PreferenceState])
  static getPrefResonses(state: PreferenceStateModel): any {
    return state.prefResponses;
  }

  @Selector([PreferenceState])
  static getPreferences(state: PreferenceStateModel) {
    return state.preferences;
  }

  @Selector([PreferenceState])
  static showRELModal(state: PreferenceStateModel) {
    return state.showRELModal;
  }

  @Selector([PreferenceState])
  static getUpdatePreferenceFailure(state: PreferenceStateModel) {
    return state.updatePreferenceFailure;
  }

  @Selector([PreferenceState])
  static getUpdatePreferenceSuccess(state: PreferenceStateModel) {
    return state.updatePreferenceSuccess;
  }

  @Selector([PreferenceState])
  static getProgramGroups(state: PreferenceStateModel) {
    return state.programGroups;
  }

  @Selector([PreferenceState])
  static getShowModalFlag(state: PreferenceStateModel) {
    return state.showModal;
  }

  @Selector([PreferenceState])
  static getUserBouncedStatus(state: PreferenceStateModel) {
    return state.isUserChannelBounced;
  }

  @Selector([PreferenceState])
  static getPaperlessPromoFlag(state: PreferenceStateModel) {
    return state.paperlessPromoFlag;
  }

  @Selector([PreferenceState])
  static getPlanDocumentsSelectedFlag(state: PreferenceStateModel) {
    return state.isPlanDocumentsSelected;
  }

  @Selector([PreferenceState])
  static getHealthBenefitsSelectedFlag(state: PreferenceStateModel) {
    return state.isHealthBenefitsSelected;
  }
}
