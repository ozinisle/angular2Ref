import { Selector } from '@ngxs/store';
import { MedlookupsModel } from '../../pages/med-lookup-search/models/search-results';
import { MedlookupState, MedlookupModel } from '../state/medlookup.state';

export class MedlookupSelectors {
  @Selector([MedlookupState])
  static getMedlookup(state: MedlookupModel): MedlookupsModel {
    return state.medlookup;
  }
}
