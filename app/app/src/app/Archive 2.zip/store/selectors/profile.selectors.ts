import { Selector } from '@ngxs/store';
import { ProfileState, ProfileStateModel } from './../state/profile.state';

export class ProfileSelectors {
  @Selector([ProfileState])
  static getProfileInfo(state: ProfileStateModel) {
    return state.profileInfo;
  }

  @Selector([ProfileState])
  static getVerifyCategory(state: ProfileStateModel) {
    return state.verifyCategory;
  }

  @Selector([ProfileState])
  static getMaskedVerifiable(state: ProfileStateModel) {
    return state.maskedVerifiable;
  }

  @Selector([ProfileState])
  static getPhoneVerification(state: ProfileStateModel) {
    return state.phoneVerification;
  }

  @Selector([ProfileState])
  static getVerificationResponse(state: ProfileStateModel) {
    return state.verificationResponse;
  }

  @Selector([ProfileState])
  static getDemographicInfo(state: ProfileStateModel) {
    return state.demoGraphicInfo;
  }

  @Selector([ProfileState])
  static getConsentResponse(state: ProfileStateModel) {
    return state.consentResponse;
  }

  @Selector([ProfileState])
  static getShowModalFlag(state: ProfileStateModel) {
    return state.showModal;
  }

  /**
   * Whether the current user is the primary subscriber of
   * their health plan (i.e., not a spouse or dependent).
   */
  @Selector([ProfileState])
  static isSubscriber(state: ProfileStateModel) {
    return state.profileInfo?.memberSuffix === '00';
  }

  @Selector([ProfileState])
  static isVerificationCompleted(state: ProfileStateModel) {
    return state.verificationCompleted;
  }

  @Selector([ProfileState])
  static modalSection(state: ProfileStateModel) {
    return state.modalSection;
  }

  @Selector([ProfileState])
  static isPhoneNumberRequired(state: ProfileStateModel) {
    return state.isPhoneNumberRequired;
  }

  @Selector([ProfileState])
  static isSkipVerifyPhone(state: ProfileStateModel) {
    return state.isSkipVerifyPhone;
  }

  @Selector([ProfileState])
  static getTeleHealthFlag(state: ProfileStateModel): boolean {
    return state.teleHealthDetails?.teleHealthEligible || false;
  }

  @Selector([ProfileState])
  static getTeleHealthDisclaimerFlag(state: ProfileStateModel): boolean {
    return state.teleHealthDetails?.disclaimerFlag;
  }

  @Selector([ProfileState])
  static getWellConnectionIndicatorFlag(state: ProfileStateModel): boolean {
    return state.teleHealthDetails?.wellConnectionIndicatorFlag;
  }
}
