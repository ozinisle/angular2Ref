import { Selector } from '@ngxs/store';
import { FITNESS_POPUP_HELP, WEIGHTLOSS_POPUP_HELP } from '@app/pages/fwb/constants/fitness.constants';
import { BenefitModel } from '@app/pages/fwb/models/benefit-model';
import { MemberModel } from '@app/pages/fwb/models/member-model';
import { PhotoModel } from '@app/pages/fwb/models/photo.model';
import { ReimbursementModel } from '@app/pages/fwb/models/reimbursement-model';
import { FitnessState, FitnessStateModel } from '../state/fitness.state';
import { cloneDeep } from 'lodash-es';

export class FitnessSelectors {
  @Selector([FitnessState])
  static getBenefits(state: FitnessStateModel): BenefitModel[] {
    return state.benefits;
  }

  @Selector([FitnessState])
  static getSelectedBenefit(state: FitnessStateModel): BenefitModel {
    return state.selectedBenefit;
  }

  @Selector([FitnessState])
  static getCoreBenefit(state: FitnessStateModel): BenefitModel {
    return state.coreBenefit;
  }

  @Selector([FitnessState])
  static getSelectedReimbursement(state: FitnessStateModel): ReimbursementModel {
    return state.selectedReimbursement;
  }

  @Selector([FitnessState])
  static getDefaultReimbursement(state: FitnessStateModel): string {
    if (state?.selectedReimbursement?.collateralName) {
      return state.selectedReimbursement.collateralName;
    } else {
      return state.benefits && state.benefits[0] && state.benefits[0].fitness
        ? state.benefits[0].fitness.collateralName
        : state.benefits[0].weightloss.collateralName;
    }
  }

  @Selector([FitnessState])
  static getMaskedEmail(state: FitnessStateModel): string {
    return state.maskedSubscriberEmail;
  }

  @Selector([FitnessState])
  static getMaskedMemberEmail(state: FitnessStateModel): string {
    return state.memberEmail && state.memberEmail !== '' ? state.memberEmail : null;
  }

  @Selector([FitnessState])
  static getEligibilityStatement(state: FitnessStateModel): string {
    return state.selectedReimbursement.collateralText;
  }

  @Selector([FitnessState])
  static isSubscriber(state: FitnessStateModel): boolean {
    return state.userSuffix === '00';
  }

  @Selector([FitnessState])
  static getHelpText(state: FitnessStateModel): string {
    if (state.selectedReimbursement.collateralName === 'Fitness') {
      return FITNESS_POPUP_HELP;
    } else {
      return WEIGHTLOSS_POPUP_HELP;
    }
  }

  @Selector([FitnessState])
  static getConfirmationNumber(state: FitnessStateModel): string {
    return state.confirmationNumber;
  }

  @Selector([FitnessState])
  static getSubscriberName(state: FitnessStateModel): MemberModel {
    return state.selectedBenefit.members[0];
  }

  @Selector([FitnessState])
  static getMembers(state: FitnessStateModel): MemberModel[] {
    return state.selectedBenefit.members;
  }

  @Selector([FitnessState])
  static getPhotos(state: FitnessStateModel): PhotoModel[] {
    return state.base64Photos;
  }

  @Selector([FitnessState])
  static getEligibility(state: FitnessStateModel): boolean {
    return state.notEligible;
  }

  @Selector([FitnessState])
  static hasMoreThanOneReimbursement(state: FitnessStateModel): boolean {
    return (
      state.benefits.length > 1 ||
      (state.benefits.length === 1 && state.benefits[0].fitness != null && state.benefits[0].weightloss != null)
    );
  }

  @Selector([FitnessState])
  static disablePhotoSubmit(state: FitnessStateModel): boolean {
    return state.disablePhotoSubmit;
  }

  @Selector([FitnessState])
  static getRemainingBenefits(state: FitnessStateModel): BenefitModel[] {
    const remainingBenefits = cloneDeep(state.benefits);

    remainingBenefits.map((benefit: BenefitModel) => {
      const keepFitness =
        benefit?.fitness && (state.selectedBenefit?.year !== benefit?.year || state.selectedReimbursement?.collateralName === 'Weightloss');

      const keepWeightLoss =
        benefit?.weightloss && (state.selectedBenefit?.year !== benefit?.year || state.selectedReimbursement?.collateralName === 'Fitness');

      if (!keepFitness) {
        delete benefit.fitness;
      }
      if (!keepWeightLoss) {
        delete benefit.weightloss;
      }
    });

    return remainingBenefits;
  }
}
