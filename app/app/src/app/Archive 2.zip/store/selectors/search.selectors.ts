import { Selector } from '@ngxs/store';
import { SearchState, SearchStateModel } from '@app/store/state/search.state';
import { BenefitSearchResultGroup } from '@app/models/benefit-search-result';

export class SearchSelectors {
  @Selector([SearchState])
  static searchResults(state: SearchStateModel): BenefitSearchResultGroup[] {
    return state.searchResults;
  }

  @Selector([SearchState])
  static isSearchOnly(state: SearchStateModel): boolean {
    return state.isSearchOnly;
  }

  @Selector([SearchState])
  static getSelectedProductType(state: SearchStateModel): string {
    return state.currentFilteredProductType;
  }

  @Selector([SearchState])
  static getPagedItems(state: SearchStateModel): BenefitSearchResultGroup[] {
    return state.pagedItems;
  }

  @Selector([SearchState])
  static getProductTypes(state: SearchStateModel): string[] {
    return state.productTypes;
  }
}
