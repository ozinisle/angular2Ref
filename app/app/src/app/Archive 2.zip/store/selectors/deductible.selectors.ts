import { Selector } from '@ngxs/store';
import { DeductibleModel } from '../../models/deductible.model';
import { DeductibleState, DeductibleStateModel } from '../state/deductible.state';
import { MemberDeductibleModel } from '../../pages/deductibles/models/member-deductible.model';

export class DeductibleSelectors {
  @Selector([DeductibleState])
  static getDeductibleState(state: DeductibleStateModel) {
    return state;
  }

  @Selector([DeductibleState])
  static getDeductibles(state: DeductibleStateModel): DeductibleModel[] {
    return state.deductibles;
  }

  @Selector([DeductibleState])
  static getErrorflag(state: any): string {
    return state.isGotError;
  }

  @Selector([DeductibleState])
  static getOverallDeductibles(state: DeductibleStateModel): DeductibleModel[] {
    return state.deductibles.filter(
      (d: DeductibleModel) =>
        ((d.type === 'Overall Deductible' || d.type === 'First Coverage') && state.hasFirstDollar) || !state.hasFirstDollar
    );
  }

  @Selector([DeductibleState])
  static getOverallFamilyDeductibles(state: DeductibleStateModel): DeductibleModel[] {
    return state.familyDeductibles.filter(
      (d: DeductibleModel) =>
        ((d.type === 'Overall Deductible' || d.type === 'First Coverage') && state.hasFirstDollar) || !state.hasFirstDollar
    );
  }

  @Selector([DeductibleState])
  static loadingDeductibles(state: DeductibleStateModel): boolean {
    return state.isLoading;
  }

  @Selector([DeductibleState])
  static getMembers(state: DeductibleStateModel): MemberDeductibleModel[] {
    return state.members;
  }

  @Selector([DeductibleState])
  static getCurrentMemberName(state: DeductibleStateModel): string {
    return state.memberName;
  }

  @Selector([DeductibleState])
  static getInitialName(state: DeductibleStateModel): string {
    return state.subscriberName;
  }

  @Selector([DeductibleState])
  static hasFamily(state: DeductibleStateModel): boolean {
    return state.hasFamily;
  }

  @Selector([DeductibleState])
  static subscriberHasFamily(state: DeductibleStateModel): boolean {
    return state.subscriberHasFamily;
  }

  @Selector([DeductibleState])
  static hasMedical(state: DeductibleStateModel): boolean {
    return state.hasMedical;
  }

  @Selector([DeductibleState])
  static hasDental(state: DeductibleStateModel): boolean {
    return state.hasDental;
  }

  @Selector([DeductibleState])
  static hasVision(state: DeductibleStateModel): boolean {
    return state.hasVision;
  }

  @Selector([DeductibleState])
  static hasFirstDollar(state: DeductibleStateModel): boolean {
    return state.hasFirstDollar;
  }
}
