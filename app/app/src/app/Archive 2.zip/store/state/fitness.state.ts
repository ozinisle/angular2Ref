import { HttpEvent } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {
  ERROR_CODES,
  ERROR_CODES_GETFWB,
  ERROR_CODES_NOT_ELIGIBLE,
  FITNESS_PDF_NAME,
  FITNESS_URL,
  WEIGHTLOSS_PDF_NAME,
  WEIGHTLOSS_URL
} from '@app/pages/fwb/constants/fitness.constants';
import { BenefitModel } from '@app/pages/fwb/models/benefit-model';
import { FitnessResponseModel } from '@app/pages/fwb/models/fitness-response.model';
import { PhotoModel } from '@app/pages/fwb/models/photo.model';
import { ReimbursementModel } from '@app/pages/fwb/models/reimbursement-model';
import { FitnessService } from '@app/pages/fwb/services/fitness.service';
import { buildSubmissionRequest } from '@app/utils/fitness.utils';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { FileTransfer } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import { Platform } from '@ionic/angular';
import { ImmutableContext } from '@ngxs-labs/immer-adapter';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Navigate } from '@ngxs/router-plugin';
import { Action, State, StateContext, Store } from '@ngxs/store';
import { cloneDeep } from 'lodash-es';
import { throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { SetLoader } from '../actions/app.actions';
import {
  ClearImages,
  DeleteImage,
  GetBenefitsInfo,
  GetReimbursementForm,
  HideProgressModal,
  SetReimbursement,
  SetSelectedBenefit,
  ShowProgressModal,
  SubmitReimbursementForm,
  UploadReimbursementReceipt
} from '../actions/fitness.actions';
import { DEFAULT_FITNESS_STATE } from '../constants/app.constants';
import { AppSelectors } from '../selectors/app.selectors';


export class FitnessStateModel {
  maskedSubscriberEmail: string;
  memberEmail: string;
  userSuffix: string;
  benefits: BenefitModel[];
  coreBenefit: BenefitModel;
  selectedBenefit: BenefitModel;
  selectedReimbursement: ReimbursementModel;
  confirmationNumber: string;
  base64Photos: PhotoModel[];
  blobPhotos: Blob[];
  notEligible: boolean;
  disablePhotoSubmit: boolean;
  currentType: string;
  groupName?: string;
  groupNumber?: string;
}

@State<FitnessStateModel>({
  name: 'fitness',
  defaults: DEFAULT_FITNESS_STATE
})
@Injectable()
export class FitnessState {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getCryptoToken) cryptoToken: any;

  constructor(
    private fitnessService: FitnessService,
    private store: Store,
    private platform: Platform,
    private fileOpener: FileOpener,
    private file: File,
    private transfer: FileTransfer
  ) {}

  @Action(GetBenefitsInfo)
  @ImmutableContext()
  getYear({ setState, getState, dispatch }: StateContext<FitnessStateModel>) {
    dispatch(new SetLoader(true));
    return this.fitnessService.getBenefitsInfo().pipe(
      catchError(e => {
        dispatch(new SetLoader(false));
        this.store.dispatch(new Navigate(['fitness-and-weightloss/reimbursement-error']));
        return throwError(e);
      }),
      tap((response: FitnessResponseModel) => {
        dispatch(new SetLoader(false));

        if (ERROR_CODES_NOT_ELIGIBLE.indexOf(response.result) !== -1) {
          setState((state: FitnessStateModel) => {
            state.notEligible = true;
            return state;
          });
        } else if (ERROR_CODES_GETFWB.indexOf(response.result) !== -1) {
          this.store.dispatch(new Navigate(['fitness-and-weightloss/reimbursement-error']));
        } else if (response.benefits) {
          setState((state: FitnessStateModel) => {
            state.benefits = response.benefits.map((b: BenefitModel) => b);
            state.benefits.sort((a, b) => (a.year > b.year ? 1 : -1));
            state.selectedBenefit = response.benefits && response.benefits.length ? response.benefits[0] : null;
            state.coreBenefit = cloneDeep(state.selectedBenefit);
            state.selectedReimbursement =
              response.benefits && response.benefits.length && response.benefits[0].fitness
                ? response.benefits[0].fitness
                : response.benefits[0].weightloss;
            state.maskedSubscriberEmail = response.subscriberMaskedEmail;
            state.memberEmail = response.memberEmail;
            state.groupNumber = response.benefits && response.benefits.length ? response.benefits[0].groupNumber : null;
            return state;
          });
        } else {
          this.store.dispatch(new Navigate(['fitness-and-weightloss/reimbursement-error']));
        }
      })
    );
  }

  @Action(SetSelectedBenefit)
  @ImmutableContext()
  setSelectedBenefit({ setState }: StateContext<FitnessStateModel>, { benefit }: SetSelectedBenefit) {
    setState((state: FitnessStateModel) => {
      state.selectedBenefit = benefit;
      if (state?.currentType) {
        state.selectedReimbursement = benefit[state?.currentType?.toLowerCase()];
      }
      return state;
    });
  }

  @Action(SetReimbursement)
  @ImmutableContext()
  setReimbursement({ getState, setState }: StateContext<FitnessStateModel>, { reimbursement }: SetReimbursement) {
    const benefits = cloneDeep(getState().benefits[0]);
    setState((state: FitnessStateModel) => {
      if (reimbursement?.toLowerCase()) {
        state.selectedReimbursement = benefits[reimbursement?.toLowerCase()];
        state.currentType = reimbursement ? reimbursement?.toLowerCase() : null;
      }
      return state;
    });
  }

  @Action(GetReimbursementForm)
  getReimbursementForm({ getState }: StateContext<FitnessStateModel>) {
    const reimbursement = getState().selectedReimbursement;

    if (!reimbursement.onlineSubmissionEligible) {
      // Download the file
      if (reimbursement.collateralName === 'Fitness') {
        this.openURL(FITNESS_URL, FITNESS_PDF_NAME);
      } else if (reimbursement.collateralName === 'Weightloss') {
        this.openURL(WEIGHTLOSS_URL, WEIGHTLOSS_PDF_NAME);
      }
    } else {
      this.store.dispatch(new Navigate(['fitness-and-weightloss/reimbursement-details']));
    }
  }

  @Action(SubmitReimbursementForm)
  submitReimbursementForm({ getState, patchState, dispatch }: StateContext<FitnessStateModel>, { form, benefitsInfo }: SubmitReimbursementForm) {
    const currentState = getState();
    const request = buildSubmissionRequest(form, this.useridin, currentState, benefitsInfo);
    const photos = getState().blobPhotos;

    if (photos.length === 0) {
      dispatch(new SetLoader(true));
    } else if (this.platform.is('cordova')) {
      dispatch(new ShowProgressModal());
    }

    return this.fitnessService.submitBenefitsInfo(request, photos).pipe(
      catchError(e => {
        dispatch([new HideProgressModal(), new SetLoader(false)]);
        return throwError(e);
      }),
      tap((response: HttpEvent<any> | any) => {
        // if (this.platform.is('cordova')) {
        //   const parsedResult = JSON.parse(response?.data);
        //   response = decryptPayload(parsedResult?.message, this.cryptoToken);
        // }

        dispatch([new HideProgressModal(), new SetLoader(false)]);

        if (response?.body?.confirmationNumber || response?.confirmationNumber) {
          const confirmationNumber = response?.body?.confirmationNumber ? response?.body?.confirmationNumber : response?.confirmationNumber;
          patchState({
            confirmationNumber: confirmationNumber,
            blobPhotos: [],
            base64Photos: []
          });

          if (ERROR_CODES.indexOf(response.result) !== -1) {
            this.store.dispatch(new Navigate(['fitness-and-weightloss/reimbursement-error']));
          } else {
            this.store.dispatch(new Navigate(['fitness-and-weightloss/reimbursement-success']));
          }
        }
      })
    );
  }

  @Action(UploadReimbursementReceipt)
  @ImmutableContext()
  uploadReimbursementReceipt(
    { setState }: StateContext<FitnessStateModel>,
    { base64Photo, blob, size, bytes }: UploadReimbursementReceipt
  ) {
    setState((state: FitnessStateModel) => {
      state.blobPhotos.push(blob);
      let totalBytes = 0;
      let hasError: boolean;
      state.base64Photos.forEach(photo => {
        totalBytes += photo.bytes;
      });
      totalBytes += bytes;
      hasError = totalBytes > 9000000;
      state.base64Photos.push({ src: base64Photo, size: size, bytes: bytes, error: hasError });
      state.disablePhotoSubmit = hasError;
      return state;
    });
  }

  @Action(DeleteImage)
  @ImmutableContext()
  deleteImage({ setState }: StateContext<FitnessStateModel>, { index }: DeleteImage) {
    setState((state: FitnessStateModel) => {
      state.base64Photos.splice(index, 1);
      state.blobPhotos.splice(index, 1);
      let totalBytes = 0;
      state.base64Photos.forEach(photo => {
        totalBytes += photo.bytes;
        photo.error = totalBytes > 9000000;
      });
      state.disablePhotoSubmit = totalBytes > 9000000;
      return state;
    });
  }

  openURL = (url: string, name: string) => {
    const path = this.file.dataDirectory;
    const transfer = this.transfer.create();

    if (this.platform.is('cordova')) {
      transfer.download(url, path + name).then(entry => {
        const appUrl = entry.toURL();
        this.fileOpener.open(appUrl, 'application/pdf');
      });
    } else {
      window.open(url, '_blank');
    }
  };

  @Action(ClearImages)
  clearImages({ patchState }: StateContext<FitnessStateModel>) {
    patchState({
      blobPhotos: [],
      base64Photos: [],
      disablePhotoSubmit: false
    });
  }
}
