import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Action, State, StateContext } from '@ngxs/store';
import { throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { FamilyDeductibleResponseModel } from '@app/pages/deductibles/models/family-deductible-response.model';
import { MemberDeductibleModel } from '@app/pages/deductibles/models/member-deductible.model';
import { hasFirstDollarDeductible, setDeductibles, setIndividualRequest } from '../utils/deductible-state.utils';
import { DeductibleService } from '@app/services/deductible.service';
import { GetFamilyDeductibles, GetIndividualDeductibles, SetDeductiblesLoading, SetErrorFlag } from '../actions/deductible.actions';
import { AppSelectors } from '../selectors/app.selectors';
import { SetLoader } from '../actions/app.actions';
import { DeductibleModel } from '@app/models/deductible.model';
import { AccumulatorModel } from '@app/pages/deductibles/models/accumulator.model';
import { DEFAULT_DEDUCTIBLES_STATE } from '../constants/app.constants';
import { Injectable } from '@angular/core';

export interface DeductibleStateModel {
  hasFamily: boolean;
  subscriberHasFamily: boolean;
  hasFirstDollar: boolean;
  hasMedical: boolean;
  hasDental: boolean;
  hasVision: boolean;
  coBundled: boolean;
  members: MemberDeductibleModel[];
  currentMember: MemberDeductibleModel;
  memberName: string;
  subscriberName: string;
  deductibles: DeductibleModel[];
  familyDeductibles: DeductibleModel[];
  isLoading: boolean;
  currentType: string;
  isGotError: boolean;
}

@State<DeductibleStateModel>({
  name: 'deductible',
  defaults: DEFAULT_DEDUCTIBLES_STATE
})
@Injectable()
export class DeductibleState {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  constructor(private deductibleService: DeductibleService) {}

  @Action(GetFamilyDeductibles)
  getFamilyDeductibles({ getState, patchState, dispatch }: StateContext<DeductibleStateModel>, { id, detailsPage }: GetFamilyDeductibles) {
    if (detailsPage) {
      dispatch(new SetLoader(true));
    } else {
      dispatch(new SetDeductiblesLoading(true));
    }
    patchState({
      deductibles: DEFAULT_DEDUCTIBLES_STATE.deductibles
    });
    return this.deductibleService.getFamilyDeductibles(id).pipe(
      catchError(e => {
        if (detailsPage) {
          dispatch(new SetLoader(false));
        } else {
          dispatch(new SetDeductiblesLoading(false));
        }
        return throwError(e);
      }),
      tap((response: FamilyDeductibleResponseModel) => {
        dispatch(new SetErrorFlag(false));
        if(response?.accums?.[0].result !== 0) {
          dispatch(new SetErrorFlag(true));
        }
        if (response?.accums?.[0]) {
          const loggedInMember = response.members ? response.members[0] : null;

          let hasMedical = false;
          let hasDental = false;
          let hasVision = false;

          if (response.members) {
            response.members.forEach((m: MemberDeductibleModel) => {
              if (m.coverageType.toLowerCase() === 'medical') {
                hasMedical = true;
              } else if (m.coverageType.toLowerCase() === 'dental') {
                hasDental = true;
              } else if (m.coverageType.toLowerCase() === 'vision') {
                hasVision = true;
              }
            });
          }
          this.deductibleService.sortDeductiblesData(response);
          const deductibles = [] as DeductibleModel[];
          const fullName = loggedInMember ? loggedInMember.name : 'Individual';
          let hasFirstDollar = false;

          response.accums.forEach((accumulator: AccumulatorModel) => {
            hasFirstDollar = hasFirstDollarDeductible(accumulator);
          });

          // TODO: CLEAN ALL THIS UP ONE DAY - API CLEAN UP WOULD BE BEST
          const familyFilter = hasFirstDollar && !detailsPage ? false : detailsPage ? true : response.hasFamily;

          setDeductibles(response.accums, deductibles, fullName, familyFilter, hasFirstDollar, detailsPage);

          patchState({
            hasFirstDollar: hasFirstDollar,
            hasFamily: response.hasFamily,
            hasMedical: hasMedical,
            hasDental: hasDental,
            hasVision: hasVision,
            currentMember: loggedInMember,
            members: response.members,
            deductibles: deductibles,
            memberName: detailsPage ? 'family' : fullName
          });

          //Defect 6447 cleaning up the patch work

          if (detailsPage) {
            dispatch(new SetLoader(false));
          } else {
            patchState({
              familyDeductibles: deductibles
            });

            if (getState().subscriberName == null) {
              patchState({
                subscriberName: detailsPage ? 'family' : fullName
              });
            }

            if (getState().subscriberHasFamily == null) {
              patchState({
                subscriberHasFamily: response.hasFamily
              });
            }
            dispatch(new SetDeductiblesLoading(false));
          }
        } else {
          dispatch(new SetErrorFlag(true));
        }
        if (detailsPage) {
          dispatch(new SetLoader(false));
        } else {
          dispatch(new SetDeductiblesLoading(false));
        }
      })
    );
  }

  @Action(GetIndividualDeductibles)
  getIndividualDeductibles(
    { getState, patchState, dispatch }: StateContext<DeductibleStateModel>,
    { name, type }: GetIndividualDeductibles
  ) {
    const selectedMember = getState()?.members?.find((m: MemberDeductibleModel) => m.name === name && m.coverageType === type );
    const request = setIndividualRequest(selectedMember, this.useridin);

    if (request && getState().deductibles?.length) {
      dispatch(new SetLoader(true));
      return this.deductibleService.getIndividualDeductibles(request).pipe(
        catchError(e => {
          dispatch(new SetLoader(false));
          return throwError(e);
        }),
        tap(response => {
          if (response.accums && response.accums[0]) {
            const deductibles = [];
            const fullName = selectedMember.name;

            let hasFirstDollar = false;
            this.deductibleService.sortDeductiblesData(response);

            response.accums.forEach((accumulator: AccumulatorModel) => {
              hasFirstDollar = hasFirstDollarDeductible(accumulator);
            });

            setDeductibles(response.accums, deductibles, fullName, false, hasFirstDollar, true);
            if (!getState().isGotError) {
              patchState({
                hasFamily: response.hasFamily,
                currentMember: selectedMember,
                deductibles: deductibles,
                memberName: fullName,
                currentType: type
              });
            } else {
              patchState({
                members: DEFAULT_DEDUCTIBLES_STATE.members,
                deductibles: DEFAULT_DEDUCTIBLES_STATE.deductibles,
                familyDeductibles: DEFAULT_DEDUCTIBLES_STATE.familyDeductibles
              });
            }
          } else {
            dispatch(new SetErrorFlag(true));
          }
          dispatch(new SetLoader(false));
        })
      );
    }
  }

  @Action(SetDeductiblesLoading)
  setLoading({ patchState }: StateContext<DeductibleStateModel>, { isLoading }: SetDeductiblesLoading) {
    patchState({
      isLoading: isLoading
    });
  }

  @Action(SetErrorFlag)
  setErrorflag({ patchState }: StateContext<any>, { isGotError }: any) {
    if (isGotError) {
      patchState({
        members: DEFAULT_DEDUCTIBLES_STATE.members,
        deductibles: DEFAULT_DEDUCTIBLES_STATE.deductibles,
        familyDeductibles: DEFAULT_DEDUCTIBLES_STATE.familyDeductibles
      });
    }
    patchState({
      isGotError
    })
  }
}
