import { Action, State, StateContext } from '@ngxs/store';
import { catchError, tap } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { GetDependentList } from '../actions/dependent.actions';
import { DependentService } from '@app/services/dependent.service';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AppSelectors } from '../selectors/app.selectors';
import { DependentModel } from '@app/models/dependent.model';
import { DEFAULT_DEPENDENTS_STATE } from '../constants/app.constants';
import { Injectable } from '@angular/core';

export class DependentStateModal {
  dependents: DependentModel[];
}
@State<DependentStateModal>({
  name: 'dependent',
  defaults: DEFAULT_DEPENDENTS_STATE
})
@Injectable()
export class DependentState {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  constructor(private dependantsService: DependentService) {}

  @Action(GetDependentList)
  getDependentList({ getState, patchState }: StateContext<DependentStateModal>) {
    if (getState().dependents) {
      return;
    }

    return this.dependantsService.getDependents(this.useridin).pipe(
      catchError(error => {
        return throwError(error);
      }),
      tap((response: any) => {
        let dependentList = null;
        if (response?.dependents?.length > 0) {
          dependentList = [];
          response.dependents.forEach((d: any) => {
            dependentList.push(d.dependent);
          });

          patchState({
            dependents: dependentList
          });
        }
      })
    );
  }
}
