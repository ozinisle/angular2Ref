import { DatePipe } from '@angular/common';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { MYBLUE } from '@app/app.constants';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { RegType } from '@app/enums/reg-type.enum';
import { AuthToken } from '@app/models/auth-token.model';
import { CryptoModel } from '@app/models/crypto.model';
import { DrupalConsentModel } from '@app/models/drupal-consent.model';
import { LoginResponse } from '@app/models/login-response.model';
import { MemberPlan } from '@app/models/member-plan.model';
import { BenefitSearchCPC } from '@app/models/search.model';
import { PWKStatus, PWKVideo } from '@app/models/welcome-kit.model';
import { HomePageAppInfoModel } from '@app/pages/home/home.model';
import { IntegratedPlanAccessService } from '@app/pages/integrated-plan-access/integrated-plan-access.service';
import { GetMemberProfileResponseModel } from '@app/pages/my-profile/models/get-member-profile-request.model';
import { AlertService } from '@app/services/alert.service';
import { AnalyticsService } from '@app/services/analytics.service';
import { AppService } from '@app/services/app.service';
import { GeoLocationService } from '@app/services/geo-location.service';
import { HomeService } from '@app/services/home.service';
import { PlanConfigService } from '@app/services/plan-config/plan-config-service';
import { SwrveService } from '@app/services/swrve.service';
import { WelcomeKitService } from '@app/services/welcome-kit.service';
import { CheckUsernameValidity, SetFromRegistration } from '@app/store/actions/register.actions';
import { RegisterSelectors } from '@app/store/selectors/register.selectors';
import { decryptPayload } from '@app/utils/app.utils';
import { transformFinanceChartData } from '@app/utils/finance.utils';
import { environment } from '@environments/environment';
import { AppVersion } from '@ionic-native/app-version/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { FileTransfer } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import { Geoposition } from '@ionic-native/geolocation/ngx';
import { NativeGeocoderResult } from '@ionic-native/native-geocoder/ngx';
import { LoadingController, NavController, Platform } from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { ImmutableContext } from '@ngxs-labs/immer-adapter';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Navigate } from '@ngxs/router-plugin';
import { Action, State, StateContext } from '@ngxs/store';
import { UserIdleService } from 'angular-user-idle';
import { format } from 'date-fns-tz';
import { of, Subject, throwError } from 'rxjs';
import { catchError, filter, map, tap } from 'rxjs/operators';
import { v4 as uuidv4 } from 'uuid';
import * as AppActions from '../actions/app.actions';
import {
  ClearInterval,
  ClearState,
  GetMemAuthInfo,
  IsSearchEnabled,
  ResetIdleWatch,
  SessionSetup,
  ShowIdleSessionModal,
  StopIdleWatch
} from '../actions/app.actions';
import { IsUserChannelBounced } from '../actions/preference.action';
import { CheckForModal, GetConsent, TeleHealthInfo } from '../actions/profile.action';
import { DEFAULT_APP_STATE, IPA_PAGES } from '../constants/app.constants';
import { getExpAccessTokenTime } from '../utils/app-state.utils';

export interface AppStateModel {
  showLoader: boolean;
  authToken: AuthToken;
  useridin: string;
  regType: RegType;
  mleIndicator: string;
  mleEligibility: string;
  hccsFlag: string;
  userState: any;
  basicMemInfo: any;
  cryptoTokens: CryptoModel;
  memAuthInfo: any;
  userType: string;
  drupalConsent: DrupalConsentModel;
  rtmsMode: boolean;
  postLoginInfo: any;
  firstTimeLogin: boolean;
  sessionId: string;
  hasNoAltAdd: boolean;
  route: string;
  memProfile: GetMemberProfileResponseModel;
  commstatus: any;
  memberInfo: HomePageAppInfoModel;
  financialInfo: any;
  isLoadingFinancial: boolean;
  hasMedicalAccounts: boolean;
  isSearchEnabled: boolean;
  searchableCPCs: BenefitSearchCPC[];
  packageName: string;
  currentLocation?: Geoposition;
  currentLocationDetails?: NativeGeocoderResult;
  localTimezone: string;
  selectedPlan: any;
  getPlansList: MemberPlan[];
  stopWelcomeVideoPlay: boolean;
  pwkVideo?: PWKVideo,
  pwkStatus?: PWKStatus,
  medicareWKPDF?: string
}

@State<AppStateModel>({
  name: 'app',
  defaults: DEFAULT_APP_STATE,
})
@Injectable()
export class AppState {
  @SelectSnapshot(RegisterSelectors.fromRegistration) fromRegistration: boolean;

  loader: HTMLIonLoadingElement;
  refreshTokenTimer: any;

  timezoneOffset = format(new Date(), 'xxx', { timeZone: 'America/New_York' });
  destroy$: Subject<boolean> = new Subject<boolean>();

  presentLoader = async () => {
    if (this.loader == null) {
      this.loader = await this.loadingController.create({
        animated: true,
        message: 'Loading ...',
        backdropDismiss: false,
        showBackdrop: true,
        keyboardClose: true,
      });
      await this.loader.present();
    }
  };

  dismissLoader = async () => {
    (await this.loader)
      ? this.loader
          .dismiss()
          .then(() => {
            this.loader = null;
            //Added as safe guard for forever spinner issue
            const loaderElement = document.getElementsByTagName('ion-loading')
            if (loaderElement?.length) {
              loaderElement.item(0).remove();
            }
          })
          .catch((e) => MYBLUE.error(e))
      : of(null);
  };

  constructor(
    private loadingController: LoadingController,
    private appService: AppService,
    private router: Router,
    private swrveService: SwrveService,
    private alertService: AlertService,
    private datePipe: DatePipe,
    private navCtrl: NavController,
    private userIdle: UserIdleService,
    private homeService: HomeService,
    private appVersion: AppVersion,
    private geoLocationService: GeoLocationService,
    private platform: Platform,
    private storage: Storage,
    private ipaService: IntegratedPlanAccessService,
    private welcomeKitService: WelcomeKitService,
    private fileOpener: FileOpener,
    private file: File,
    private transfer: FileTransfer,
    private analyticsService: AnalyticsService,
    private planConfigService: PlanConfigService
  ) {}

  @Action(AppActions.ClearState)
  clearState({ dispatch }: StateContext<AppStateModel>, { navToLogin, clearAuth }: AppActions.ClearState) {
    if (navToLogin) {
      this.navCtrl.navigateRoot(['home']);
    }
    if (!clearAuth) {
      dispatch(new ClearInterval());
    }
  }

  @Action(ClearInterval)
  clearInterval() {
    clearInterval(this.refreshTokenTimer);
  }

  @Action(AppActions.Logout)
  async logout({ dispatch }: StateContext<AppStateModel>) {
    dispatch([new StopIdleWatch(), new AppActions.ClearState(true)]);
    sessionStorage.clear();
    return this.appService.logout();
  }

  @Action(StopIdleWatch)
  stopWatch() {
    this.userIdle.stopWatching();
  }

  @Action(ResetIdleWatch)
  resetWatch() {
    this.userIdle.resetTimer();
  }

  @Action(AppActions.SetLoader)
  setLoader({ patchState, getState }: StateContext<AppStateModel>, { show }: AppActions.SetLoader) {
    if (show && !getState().showLoader) {
      this.presentLoader();
    } else if (!show && getState().showLoader) {
      setTimeout(() => this.dismissLoader() , 100);
    }
    patchState({
      showLoader: show,
    });
  }

  @Action(AppActions.SetMLEEligibility)
  setMLEEligibility({ patchState }: StateContext<AppStateModel>, { eligibility }: AppActions.SetMLEEligibility) {
    patchState({
      mleEligibility: eligibility,
    });
  }

  @Action(AppActions.SetMLEIndicator)
  setMLEEIndicator({ patchState }: StateContext<AppStateModel>, { indicator }: AppActions.SetMLEIndicator) {
    patchState({
      mleIndicator: indicator,
    });
  }

  @Action(AppActions.SetUserID)
  setUserID({ patchState }: StateContext<AppStateModel>, { useridin }: AppActions.SetUserID) {
    patchState({
      useridin: useridin,
    });
  }

  @Action(AppActions.SetUserType)
  setUserType({ patchState }: StateContext<AppStateModel>, { userType }: AppActions.SetUserType) {
    patchState({
      userType: userType,
    });
  }

  @Action(AppActions.SetUserState)
  setUserState({ patchState }: StateContext<AppStateModel>, { userState }: AppActions.SetUserState) {
    patchState({
      userState: userState,
    });
  }

  @Action(AppActions.SetScopeVerified)
  @ImmutableContext()
  setScopeToVerified({ getState, setState }: StateContext<AppStateModel>) {
    if (getState().authToken) {
      setState((state: AppStateModel) => {
        state.authToken.scopename = 'REGISTERED-AND-VERIFIED';
        return state;
      });
    }
  }

  @Action(AppActions.SetMemAuthInfo)
  setMemAuthInfo({ patchState }: StateContext<AppStateModel>, { memberInfo }: AppActions.SetMemAuthInfo) {
    patchState({
      memAuthInfo: memberInfo,
    });
  }

  @Action(AppActions.SetRTMSMode)
  setRTMSMode({ patchState }: StateContext<AppStateModel>) {
    patchState({
      rtmsMode: true,
    });
  }

  @Action(AppActions.SetHCCSFlag)
  setHCCSFlag({ patchState }: StateContext<AppStateModel>, { hccsFlag }: AppActions.SetHCCSFlag) {
    patchState({
      hccsFlag: hccsFlag,
    });
  }

  @Action(AppActions.SetSelectedPlan)
  SetSelectedPlan({ dispatch, getState, patchState }: StateContext<AppStateModel>, { selectedPlan, url }: AppActions.SetSelectedPlan) {
    patchState({
      selectedPlan: selectedPlan,
    });
    if (!selectedPlan) {
      selectedPlan = getState().getPlansList.length > 0 ? getState().getPlansList[0] : undefined;
    }
    if (selectedPlan) {
      this.ipaService.getSwitchPlanAPI(selectedPlan.cardMemId, selectedPlan.cardMemSuffix, getState().useridin, getState().authToken, getState().cryptoTokens).subscribe(
        (authToken: LoginResponse) => {
          if(authToken && authToken['result'] && authToken['result'] < 0){
            this.alertService.setAlert(authToken['displaymessage'], '', AlertType.Failure, 'ipa');
          } else if (authToken) {
            sessionStorage['authToken'] = JSON.stringify(authToken);
            sessionStorage.setItem('hasALG', authToken.isALG);
            sessionStorage.setItem('hasHEQ', authToken.isHEQ);
            patchState({
              authToken: authToken
            })
            dispatch(new AppActions.SetPostLogin());
            this.router.navigateByUrl('/loading', {skipLocationChange: true}).then(() => {
              dispatch(new Navigate([url]));
            });
          }
        }
      )
    }
  }

  @Action(AppActions.SetIPAAuthToken)
  SetIPAAuthToken({patchState}: StateContext<AppStateModel>, { authToken }: AppActions.SetIPAAuthToken) {
    patchState({
      authToken: authToken
    })
  }

  @Action(AppActions.CheckForDefaultPlanSwitch)
  checkForDefaultPlanSwitch({dispatch, getState }: StateContext<AppStateModel>, { url }: AppActions.CheckForDefaultPlanSwitch) {
      const selectedPlan = getState().selectedPlan ;
      if (selectedPlan && selectedPlan?.defaultPlan !== 'true') {
        const ipaPage = IPA_PAGES.filter( pageUrl => url.startsWith(pageUrl));
        if (!ipaPage.length) {
          const memberPlans = getState().getPlansList;
          dispatch(new AppActions.SetSelectedPlan(memberPlans[0], url));
          this.alertService.clearError('ipa');
        }
      }
  }

  @Action(AppActions.GetCryptoTokens)
  getCryptoTokens({ patchState, dispatch }: StateContext<AppStateModel>) {
    dispatch(new AppActions.SetLoader(true));
    return this.appService.getTokens().pipe(
      catchError((e) => {
        dispatch(new AppActions.SetLoader(false));
        return throwError(e);
      }),
      tap((response) => {
        patchState({
          cryptoTokens: response,
        });
        dispatch(new AppActions.SetLoader(false));
      })
    );
  }

  @Action(AppActions.GetTokens)
  getTokens(
    { getState, patchState, dispatch }: StateContext<AppStateModel>,
    { request, isRegister, isfadanonymous, redirectUrl }: AppActions.GetTokens
  ) {
    dispatch(new AppActions.SetLoader(true));
    return this.appService.getTokens().pipe(
      catchError((e) => {
        dispatch(new AppActions.SetLoader(false));
        return throwError(e);
      }),
      tap((cryptoTokens: CryptoModel) => {
        patchState({
          cryptoTokens: cryptoTokens,
          useridin: request.useridin,
          regType: request.regType,
        });
        this.homeService.clearCache();
        if (!isfadanonymous) {
          if (request && !isRegister) {
            dispatch(new AppActions.Login(request, false, redirectUrl));
          } else {
            dispatch(new CheckUsernameValidity(request, request.regType, cryptoTokens, true));
          }
        } else {
          dispatch(new AppActions.SetLoader(false));
        }
      })
    );
  }

  @Action(AppActions.Login)
  login({ getState, patchState, dispatch }: StateContext<AppStateModel>, { request, flag, redirectUrl }: AppActions.Login) {
    const cryptoTokens = getState().cryptoTokens;
    
    return this.appService.login(request, cryptoTokens).pipe(
      catchError((error) => {
        dispatch([new AppActions.SetLoader(false), new ClearState(false)]);
        MYBLUE.error(' LOGIN ERROR:: ' + JSON.stringify(error, null, 2));
        patchState({
          useridin: request.useridin,
        });

        if (error?.error?.displaymessage) {
          const displayMessage = error.error.displaymessage;
          this.alertService.setAlert(displayMessage, '', AlertType.Failure);
        }

        return throwError(error);
      }),
      map((authToken: LoginResponse) => {
        let getPlansList = [];
        if (authToken.memberPlans) {
           getPlansList = decryptPayload(authToken.memberPlans, getState().cryptoTokens)['plans']
        }
        patchState({
          authToken,
          getPlansList,
          useridin: request.useridin,
          sessionId: uuidv4()
        });

        if (request.useridin) {
          //this.swrveService.identifyUserToSwrve(authToken.syntheticID);
          this.swrveService.identifySwrveUserIdToBackend(request.useridin, getState().cryptoTokens);
        }

        dispatch(new SessionSetup(authToken));

        if (authToken.scopename === 'AUTHENTICATED-AND-VERIFIED') {
          if(sessionStorage.getItem("biometric") === "true" && !this.fromRegistration){
            const pBioData = {
              password: request.passwordin,
              userid: request.useridin
            };
            this.storage.set('pBioData', pBioData).catch((error: any) => console.error(error));
          }
          if (authToken.userType?.toLowerCase() === 'medicare') {
            dispatch(new AppActions.GetPWKStatus())
          }
          dispatch(new IsSearchEnabled());
          if (environment.telehealth) {
            dispatch(new TeleHealthInfo());
          }
        }


        if (this.fromRegistration) {
          const consentRequest = {
            useridin: request.useridin,
            consentLanguageId: getState()?.drupalConsent?.Version,
            consentLanguage: encodeURI(getState()?.drupalConsent?.Body),
            consentFlag: 'Y',
            consentTS: this.datePipe.transform(new Date(), 'M/d/yyyy h:m:s aa', this.timezoneOffset),
          };
          dispatch([new AppActions.UpdateConsent(consentRequest), new SetFromRegistration(false)]);
        }

        return dispatch(new AppActions.PostLogin(redirectUrl));
      })
    );
  }

  @Action(SessionSetup)
  sessionSetup({ dispatch }: StateContext<AppStateModel>, { authToken }: SessionSetup) {
    this.userIdle.startWatching();

    // Start watching when user idle is starting.
    const timerSub = this.userIdle.onTimerStart().subscribe();

    // Start watch when time is up.
    const timoutSub = this.userIdle.onTimeout().subscribe(() => {
      dispatch(new ShowIdleSessionModal());
      timerSub.unsubscribe();
      timoutSub.unsubscribe();
    });

    if (!this.refreshTokenTimer && authToken?.access_token && getExpAccessTokenTime(authToken?.access_token_expires) > 0) {
      this.refreshTokenTimer = setInterval(() => {
        dispatch(new AppActions.ResetTokens());
      }, getExpAccessTokenTime(authToken?.access_token_expires));
    }
  }

  @Action(AppActions.GetDrupalConsent)
  getDrupalConsent({ patchState }: StateContext<AppStateModel>) {
    return this.appService.getdrupalconsent().pipe(
      catchError((e) => {
        return throwError(e);
      }),
      tap((response) => {
        patchState({
          drupalConsent: response?.[0],
        });
      })
    );
  }

  @Action(AppActions.UpdateConsent)
  updateConsent({ dispatch }: StateContext<AppStateModel>, { request }: AppActions.UpdateConsent) {
    return this.appService.updateConsent(request).pipe(
      catchError((e) => {
        return throwError(e);
      }),
      tap((response) => {
        if (response) {
          dispatch(new GetConsent(request.useridin));
        }
      })
    );
  }

  @Action(AppActions.PostLogin)
  postLogin({ getState, patchState, dispatch }: StateContext<AppStateModel>, { redirectUrl }: AppActions.PostLogin) {
    const id = getState().useridin;
    return this.appService.postLogin(id).pipe(
      catchError((e) => {
        dispatch(new AppActions.SetLoader(false));
        return throwError(e);
      }),
      tap((response) => {
        if (response && response['result'] === -92754) {
          dispatch(new AppActions.SetLoader(false));
          dispatch([new StopIdleWatch(), new AppActions.ClearState(false)]);
          sessionStorage.clear();
          this.alertService.setAlert(response.displaymessage, '', AlertType.Failure);
        } else {
        dispatch(new AppActions.SetLoader(false));
        patchState({
          postLoginInfo: response,
          hasNoAltAdd: response?.repPayeeFalg?.toLowerCase() === 'false',
        });
        const scopeName = getState()?.authToken?.scopename;
        const isAuthenticated = scopeName?.includes('AUTHENTICATED');
        const firstTimeLogin = getState().firstTimeLogin;
        const route = getState().route;
        // If migration type is present, then forward to migration flow else for home or first-time.
        const authTokenMigrationType = getState()?.authToken?.migrationtype;
        if (authTokenMigrationType) {
          const migrationtype = getState()?.authToken?.migrationtype;
          const destinationURL = getState()?.authToken?.destinationURL;
          if (scopeName === 'AUTHENTICATED-NOT-VERIFIED') {
            this.router.navigate(['register/verification']);
          } else if (destinationURL && migrationtype === 'NONE') {
            this.router.navigate([destinationURL], { replaceUrl: true });
            dispatch(new CheckForModal());
            dispatch(new IsUserChannelBounced());
          } else if (migrationtype !== 'NONE') {
            this.router.navigate(['member-migration']);
          } else if (scopeName === 'REGISTERED-AND-VERIFIED') {
            dispatch(new GetMemAuthInfo(true));
          } else {
            if (redirectUrl) {
              this.router.navigate([redirectUrl], {queryParamsHandling: 'merge'});
            } else {
              this.router.navigateByUrl('home');
            }
            dispatch(new CheckForModal());
            dispatch(new IsUserChannelBounced());
          }
        } else if (isAuthenticated && firstTimeLogin) {
          patchState({
            firstTimeLogin: false,
          });
          this.navCtrl.navigateRoot('first-time');
        } else if (route) {
          dispatch(new AppActions.SetDeepLink(null));
          this.router.navigate([route]);
        }
        }
      })
    );
  }


  @Action(AppActions.ResetTokens)
  resetTokens({ getState, patchState }: StateContext<AppStateModel>) {
    const body = new URLSearchParams();
    body.set('grant_type', 'refresh_token');
    body.set('refresh_token', getState().authToken.refresh_token);
    return this.appService.refreshTokens(body.toString()).pipe(
      tap((refreshTokens) => {
        const updateRefreshTokenWithAuthToken = {
          ...getState().authToken,
          scopename: refreshTokens.scopename,
          access_token: refreshTokens.access_token,
          refresh_token: refreshTokens.refresh_token,
          issued: refreshTokens.issued,
          access_token_expires: refreshTokens.access_token_expires,
          refresh_token_expires: refreshTokens.refresh_token_expires
        };
        patchState({
          authToken: updateRefreshTokenWithAuthToken
        });
      })
    );
  }

  @Action(AppActions.SetPostLogin)
  setPostLogin({ getState, patchState, dispatch }: StateContext<AppStateModel>) {
    dispatch(new AppActions.SetLoader(true));
    const id = getState().useridin;
    return this.appService.postLogin(id).pipe(
      catchError((e) => {
        dispatch(new AppActions.SetLoader(false));
        return throwError(e);
      }),
      tap((response) => {
        patchState({
          postLoginInfo: response,
        });
        dispatch(new AppActions.SetLoader(false));
      })
    );
  }

  @Action(AppActions.SetBasicMemberInfo)
  setBasicMemberInfo({ patchState }: StateContext<AppStateModel>, { basicMemberInfo }: AppActions.SetBasicMemberInfo) {
    patchState({
      basicMemInfo: basicMemberInfo,
    });
  }

  @Action(AppActions.SetDeepLink)
  setDeepLink({ patchState }: StateContext<AppStateModel>, { route }: AppActions.SetDeepLink) {
    patchState({
      route: route,
    });
  }

  @Action(GetMemAuthInfo)
  getMemAuthInfo({ getState, patchState }: StateContext<AppStateModel>, { shouldNavigate }: GetMemAuthInfo) {
    const id = getState().useridin;
    return this.appService.getMemberAuthInfo(id).pipe(
      catchError((error) => {
        return throwError(error);
      }),
      tap((response: any) => {
        patchState({
          memAuthInfo: response?.ROWSET?.ROWS,
        });
        if (shouldNavigate) {
          this.navCtrl.navigateRoot('/register/register-detail');
        }
      })
    );
  }

  @Action(AppActions.SetMemProfile)
  setMemProfile({ patchState }: StateContext<AppStateModel>, { memProfile }: AppActions.SetMemProfile) {
    patchState({
      memProfile: memProfile
    });
  }

  @Action(AppActions.SetMemberInfo)
  setMemberInfo({ patchState }: StateContext<AppStateModel>, { memberInfo }: AppActions.SetMemberInfo) {
    patchState({
      memberInfo: memberInfo,
    });
  }

  @Action(AppActions.GetFinancialInfo)
  getFinancialInfo({ patchState, getState }: StateContext<AppStateModel>, {}: AppActions.SetMemProfile) {
    if (!getState().financialInfo?.length) {
      return this.homeService.getFinanceBalanceData(getState().useridin).pipe(
        catchError((e) => {
          patchState({
            isLoadingFinancial: false,
          });
          return throwError(e);
        }),
        tap((response) => {
          if (response?.heqAccounts || response?.algsAccounts) {
            patchState({
              financialInfo: transformFinanceChartData(response),
              hasMedicalAccounts: response.hasMedicalAccounts,
            });
          }
          patchState({
            isLoadingFinancial: false,
          });
        })
      );
    } else {
      patchState({
        isLoadingFinancial: false,
      });
    }
  }

  @Action(AppActions.IsSearchEnabled)
  isSearchEnabled({ patchState, getState }: StateContext<AppStateModel>) {
    if (getState().authToken.scopename === 'AUTHENTICATED-AND-VERIFIED') {
      const useridin = getState().useridin;
      return this.appService.isSearchEnabled(useridin).pipe(
        catchError((e) => {
          return throwError(e);
        }),
        tap((response) => {
          if (response.cpcCodeList) {
            const searchableCps = response.cpcCodeList?.searchableCPCs;
            const isSearchEnabled = searchableCps?.length > 0;
            patchState({
              searchableCPCs: searchableCps,
              isSearchEnabled,
            });
          } else {
            patchState({
              isSearchEnabled: true,
            });
          }
        })
      );
    }
  }

  @Action(AppActions.AppVersionInfo)
  getAppVersionInfo({ patchState }: StateContext<AppStateModel>) {
    this.appVersion?.getPackageName().then( packageName => patchState ({packageName}));
  }

  @Action(AppActions.GetLocalTimeZone)
  getLocalTimeZone({ patchState }: StateContext<AppStateModel>) {
    const localTimezone = format(new Date(), 'z');
    patchState({localTimezone})
  }

  @Action(AppActions.GetGeoLocation)
  getGeoLocation({ dispatch, getState, patchState }: StateContext<AppStateModel>, {reset }: AppActions.GetGeoLocation) {
    return this.geoLocationService.getCurrentLocation().pipe(
      tap((currentLocation: Geoposition) => {
        patchState({
          currentLocation
        });
        dispatch(new AppActions.GetGeoLocationDetails());
      })
    );
  }

  @Action(AppActions.GetGeoLocationDetails)
  getGeoLocationDetails({ getState, patchState }: StateContext<AppStateModel>) {
    if (getState().currentLocation && this.platform.is('cordova')) {
      this.geoLocationService.getLocationByCoordinates(getState().currentLocation.coords.latitude, getState().currentLocation.coords.longitude)
      .subscribe(
        locations => {
          if (locations?.length) {
            patchState({
              currentLocationDetails: locations[0]
            });
          }
        }
      );
    }
  }

  @Action(AppActions.StopWelcomeVideoPlay)
  stopWelcomeVideoPlay({ getState, patchState }: StateContext<AppStateModel>, { stopWelcomeVideoPlay }: AppActions.StopWelcomeVideoPlay) {
    patchState({
      stopWelcomeVideoPlay
    });
  }

  @Action(AppActions.GetPWKVideo)
  getPWKVideo({ getState, patchState }: StateContext<AppStateModel>) {
    this.welcomeKitService.getPwkVideo(getState().useridin).subscribe((pwkVideo: PWKVideo) => {
      patchState({
        pwkVideo
      })
    })
  }

  @Action(AppActions.GetPWKPdf)
  getPWKPdf({ dispatch, getState, patchState }: StateContext<AppStateModel>) {
    this.welcomeKitService.getMedicareWKDoc(getState().useridin).subscribe((response: any) => {
      if (response?.medicareWKPDF) {
        /* open pdf */
        const path = this.file.dataDirectory;
        const transfer = this.transfer.create();
        dispatch(new AppActions.SetLoader(true));
        transfer.download(response?.medicareWKPDF, path + 'myfile.pdf')
          .then(entry => {
            const appUrl = entry.toURL();
            this.fileOpener.open(appUrl, 'application/pdf').catch(e => MYBLUE.error('Error opening file', e));
            dispatch(new AppActions.SetLoader(false));
          })
          .catch(err => {
            MYBLUE.error(err);
            this.analyticsService.captureAPIErrorInAdobe('', 'Error getting Comman Digital PDF', err);
            dispatch(new AppActions.SetLoader(false));
          });
        patchState({
          medicareWKPDF: response?.medicareWKPDF
        })
      }
    })
  }

  @Action(AppActions.GetPWKStatus)
  getPWKStatus({ dispatch, getState, patchState }: StateContext<AppStateModel>) {
    this.planConfigService.getCurrentPlanConfig$().pipe(
      filter(planConfig => planConfig.elligibility.isWelcomeKitEnabled)
    ).subscribe(() => {
      this.welcomeKitService.getMedicareWK(getState().useridin).subscribe((pwkStatus: PWKStatus) => {
        patchState({
          pwkStatus
        });
        if (pwkStatus.medicareVideoExists) {
          dispatch([new AppActions.GetPWKVideo(), new AppActions.UpdatePWKSeenCounts(pwkStatus.seenMedicareVideo + 1, undefined)]);
        }
      })
    });
  }

  @Action(AppActions.UpdatePWKSeenCounts)
  updatePWKSeenCounts({ getState, patchState }: StateContext<AppStateModel>, {seenPwkPdfCount, seenPwkVideoCount}: AppActions.UpdatePWKSeenCounts) {
    const pwkStatus = {...getState().pwkStatus};
    pwkStatus.seenMedicarePDF = seenPwkPdfCount || pwkStatus.seenMedicarePDF;
    pwkStatus.seenMedicareVideo = seenPwkVideoCount || pwkStatus.seenMedicareVideo;
    this.welcomeKitService.setMedicareWK(getState().useridin, pwkStatus.seenMedicarePDF, pwkStatus.seenMedicareVideo).subscribe(response => {
      patchState({
        pwkStatus
      });
    });
  }

  handleUserVerification() {
    sessionStorage.setItem('isReqCode', 'true');
    sessionStorage.setItem('isUserLogginIn', 'true');
    this.router.navigate(['/register/verifyaccesscode']);
  }
}
