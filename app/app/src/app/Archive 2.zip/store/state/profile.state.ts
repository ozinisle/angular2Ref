import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Navigate } from '@ngxs/router-plugin';
import { Action, State, StateContext } from '@ngxs/store';
import { Injectable } from '@angular/core';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { ProfileInfo } from '@app/models/profile-response.model';
import {
  FetchProfile,
  UpdateProfile,
  VerifyPhone,
  UpdateProfileError,
  UpdateProfileSuccess,
  VerifyEmail,
  SetEmailVerification,
  SetVerificationCategory,
  VerifyAccessCode,
  VerificationDone,
  SendNotification,
  GetDemographicInfo,
  UpdateDemographicInfo,
  UpdateDemographicSuccess,
  UpdatePassword,
  UpdatePasswordSuccess,
  GetConsent,
  CheckForModal,
  ShowModal,
  SetUpdatePreferenceFlag,
  SetModalSection,
  SetUpdatedCommChannel,
  UpdateConsent,
  UpdateConsentState,
  ResetVerifyFlags,
  GetProfileDrupalConsent,
  SetPhoneNumberRequiredFlag,
  SetSkipVerifyPhoneFlag,
  ShowConsentModal,
  GetConsentSuccessful,
  InitAboutMeModal,
  ShowAboutMeModal,
  NotifyDemographicModalDisplayed,
  TeleHealthInfo,
  TelehealthInfoLoaded,
  UpdateTeleHealthDisclaimerFlag,
  VerifyEmailModal
} from '@app/store/actions/profile.action';
import { NavController } from '@ionic/angular';
import { catchError, map, tap, delay, mergeMap } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { LoginResponse } from '@app/models/login-response.model';
import { ProfileService } from '@app/services/profile.service';
import { SetLoader } from '@app/store/actions/app.actions';
import { ConstantsService } from '@app/services/constants.service';
import {
  ERROR_CODES_UPDATE_PROFILE,
  EDIT_ADDRESS_MSG,
  EDIT_EMAIL_MSG,
  EDIT_HEALTH_MSG,
  EDIT_HINT_MSG,
  EDIT_PHONE_MSG,
  VERIFIED_USER_SCOPES,
  COMM_CHANNEL_TYPE_MOBILE,
  COMM_CHANNEL_TYPE_EMAIL,
  SUCCESS_RESULT,
  VERIFIED_EMAIL_MSG,
  VERIFIED_PHONE_MSG,
  ERROR_CODE_VERIFY_CODE_EXP,
  VERIFY_CODE_EXPIRE_MSG,
  ERROR_CODE_COMM_ERR,
  ERROR_CODE_VERIFY_CODE_MISMATCH,
  COMM_ERR_MSG,
  CODE_MISMATCH_ERR_MSG,
  PASSWORD_CHANGED_MSG,
  PASSWORD_CRITERIA_ERR_MSG,
  USER_TYPE_MEDICATE,
  UPDATE_TYPE
} from '@app/store/constants/preference.constants';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { AlertService } from '@app/services/alert.service';
import {
  sendVerificationCodeSucessMsg,
  sendVerificationCodeErrorMsg,
  PN_TS_FORMAT,
  TS_LOCALE,
  EDT_TZ_OFFSET
} from '@app/store/utils/preference-state.utils';
import { formatDate, TitleCasePipe } from '@angular/common';
import { PreferenceService } from '@app/services/preference.service';
import { UpdatePreferencesAndConsent } from '@app/store/actions/preference.action';
import { AppService } from '@app/services/app.service';
import { PostLoginModel } from '@app/models/post-login.model';
import { TeleHealthDetails } from '@app/models/telehealth.model';
import { VitalsService } from '@app/services/vitals.service';
import { DEFAULT_PROFILE_STATE } from '../constants/app.constants';
import { PlanConfigService } from '@app/services/plan-config/plan-config-service';

export class ProfileStateModel {
  profileInfo?: ProfileInfo;
  consentResponse?: any;
  verifyCategory?: string;
  maskedVerifiable?: string;
  phoneVerification?: boolean;
  emailVerification?: boolean;
  verificationResponse?: any;
  demoGraphicInfo?: any;
  verificationCompleted?: boolean;
  fromContactFlag?: boolean;
  showModal?: boolean;
  updatePreferenceFlag?: boolean;
  modalSection?: string;
  verifyOnlyFlow?: boolean;
  isPhoneNumberRequired?: boolean;
  isSkipVerifyPhone?: boolean
  teleHealthDetails: TeleHealthDetails;
}

@State<ProfileStateModel>({
  name: 'profile',
  defaults: DEFAULT_PROFILE_STATE
})
@Injectable()
export class ProfileState {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: LoginResponse;
  @SelectSnapshot(AppSelectors.getSessionId) sessionId: LoginResponse;
  @SelectSnapshot(AppSelectors.getHasNoAltAdd) hasNoAltAdd: boolean;
  @SelectSnapshot(AppSelectors.isActiveUser) isActiveUser: string;
  @SelectSnapshot(AppSelectors.getPostLoginInfo) postLoginInfo: PostLoginModel;

  constructor(
    private alertService: AlertService,
    private constants: ConstantsService,
    private navCtrl: NavController,
    private preferenceService: PreferenceService,
    private profileService: ProfileService,
    private titleCase: TitleCasePipe,
    private appService: AppService,
    private vitalsService: VitalsService,
    private planConfigService: PlanConfigService
  ) {}

  @Action(FetchProfile)
  fetchProfile({ patchState }: StateContext<ProfileStateModel>) {
    return this.profileService.fetchProfileInfo(this.useridin).pipe(
      map(response => response as ProfileInfo),
      catchError(e => {
        return throwError(e);
      }),
      tap(response => {
        patchState({
          profileInfo: response
        });
      })
    );
  }

  @Action(UpdateProfile)
  updateProfile(
    { getState, patchState, dispatch }: StateContext<ProfileStateModel>,
    { payload, editAddress, editEmail, editPhone, editHint, editHealth, isFromModal }: any
  ) {
    dispatch(new SetLoader(true));
    return this.profileService.updateProfile(payload, editAddress, editEmail, editPhone, editHint, editHealth).pipe(
      catchError(e => {
        dispatch(new SetLoader(false));
        this.appService.handleError(e.error, this.constants.displayMessage);
        return throwError(e);
      }),
      tap((response: any) => {
        dispatch(new SetLoader(false));
        const { result } = response;
        if (result === -90129 || result === -90181) {
          this.alertService.setAlert(response.displaymessage, '', AlertType.Success);
        } else if (ERROR_CODES_UPDATE_PROFILE.indexOf(result) !== -1 || result !== 0) {
          this.alertService.setAlert(response.displaymessage, '', AlertType.Failure);
          dispatch(new UpdateProfileError());
        } else {
          let message;
          message = editAddress ? EDIT_ADDRESS_MSG : editEmail ? EDIT_EMAIL_MSG : EDIT_PHONE_MSG;
          message = editHealth ? EDIT_HEALTH_MSG : message;
          message = editHint ? EDIT_HINT_MSG : message;
          dispatch([new FetchProfile(), new UpdateProfileSuccess()]);
          if (!isFromModal) {
            if (editEmail) {
              dispatch(new VerifyEmail(payload.emailAddress));
              patchState({
                fromContactFlag: true
              });
            } else if (editPhone) {
              getState().updatePreferenceFlag ?
                  dispatch(new SetUpdatePreferenceFlag(false))
                  : dispatch(new VerifyPhone(payload.phoneNumber));
              patchState({
                fromContactFlag: true
              });
            } else {
              this.alertService.setAlert(message, '', AlertType.Success);
            }
          }
        }
      })
    );
  }
  @Action(VerifyPhone)
  verifyPhone(
    { patchState, getState, dispatch }: StateContext<ProfileStateModel>,
    { phoneNumber, isResend, isFromModal, fromContactFlag }: any
  ) {
    if (!phoneNumber && !getState().profileInfo.isVerifiedMobile) {
      phoneNumber = getState().profileInfo.phoneNumber;
    }
    const observable$ = VERIFIED_USER_SCOPES.includes(this.scopeName)
      ? this.profileService.sendcommchlaccesscode('', phoneNumber, this.useridin)
      : this.profileService.sendaccesscode(COMM_CHANNEL_TYPE_MOBILE, phoneNumber, this.useridin);
    dispatch(new SetLoader(true));
    if (getState().profileInfo.updatedPhoneNumber !== phoneNumber) {
      patchState({
        profileInfo: { ...getState().profileInfo, updatedPhoneNumber: phoneNumber }
      });
    }
    patchState({
      fromContactFlag: fromContactFlag
    });
    return observable$.pipe(
      catchError(e => {
        dispatch(new SetLoader(false));
        return throwError(e);
      }),
      tap((response: any) => {
        if (!response.result) {
          patchState({
            maskedVerifiable: this.profileService.maskPhoneNumber(phoneNumber),
            verifyCategory: 'Mobile Number'
          });
          dispatch(new SetModalSection('VAC'));
          sendVerificationCodeSucessMsg(dispatch, this.alertService, isResend, isFromModal);
        } else {
          sendVerificationCodeErrorMsg(
            this.alertService,
            response.result,
            response.displaymessage,
            isFromModal,
            !fromContactFlag,
            getState().isPhoneNumberRequired
          );
        }
        dispatch(new SetLoader(false));
      })
    );
  }

  @Action(VerifyEmail)
  verifyEmail({ patchState, getState, dispatch }: StateContext<ProfileStateModel>, { email, isResend, isFromModal, fromContactFlag }: any) {
    if (!email && !getState().profileInfo.isVerifiedEmail) {
      email = getState().profileInfo.emailAddress;
    }
    const observable$ = VERIFIED_USER_SCOPES.includes(this.scopeName)
      ? this.profileService.sendcommchlaccesscode(email, '', this.useridin)
      : this.profileService.sendaccesscode(COMM_CHANNEL_TYPE_EMAIL, email, this.useridin);

    if (getState().profileInfo.updatedEmailAddress !== email) {
      patchState({
        profileInfo: { ...getState().profileInfo, updatedEmailAddress: email }
      });
    }
    if (fromContactFlag) {
      patchState({
        fromContactFlag: fromContactFlag
      });
    }
    dispatch(new SetLoader(true));
    return observable$.pipe(
      catchError(e => {
        dispatch(new SetLoader(false));
        return throwError(e);
      }),
      tap((response: any) => {
        if (!response.result) {
          patchState({
            maskedVerifiable: this.profileService.maskEmailId(email),
            verifyCategory: 'Email'
          });
          dispatch(new SetModalSection('VAC'));
          sendVerificationCodeSucessMsg(dispatch, this.alertService, isResend, isFromModal);
        } else {
          sendVerificationCodeErrorMsg(this.alertService, response.result, response.displaymessage, isFromModal);
        }
        dispatch(new SetLoader(false));
      })
    );
  }

  @Action(SetEmailVerification)
  setEmailVerification({ patchState, getState }: StateContext<ProfileStateModel>, { emailVerification, emailAddress }: any) {
    if (emailAddress) {
      patchState({
        profileInfo: { ...getState().profileInfo, updatedEmailAddress: emailAddress }
      });
    }
    patchState({
      emailVerification
    });
  }

  @Action(SetUpdatePreferenceFlag)
  setUpdatePreferenceFlag({ patchState }: StateContext<ProfileStateModel>, { updatePreferenceFlag }: any) {
    patchState({
      updatePreferenceFlag
    });
  }

  @Action(SetVerificationCategory)
  setVerificationCategory({ patchState }: StateContext<ProfileStateModel>, { verifyCategory }: any) {
    patchState({
      verifyCategory: verifyCategory
    });
  }

  @Action(VerifyAccessCode)
  verifyAccessCode({ patchState, getState, dispatch }: StateContext<ProfileStateModel>, { accessCode, isMyPillpack, isFromModal }: any) {
    const isEmailVerifiable = getState().verifyCategory === 'Email';
    const emailAddress = getState().profileInfo.updatedEmailAddress
      ? getState().profileInfo.updatedEmailAddress
      : getState().profileInfo.emailAddress;
    const phoneNumber = getState().profileInfo.updatedPhoneNumber
      ? getState().profileInfo.updatedPhoneNumber
      : getState().profileInfo.phoneNumber;
    const commChannelType = isEmailVerifiable ? 'EMAIL' : 'MOBILE';
    const commChannel = isEmailVerifiable ? emailAddress : phoneNumber;
    const observable$ = VERIFIED_USER_SCOPES.includes(this.scopeName)
      ? this.profileService.VerifyCommChlAccCode(
          accessCode,
          isEmailVerifiable ? emailAddress : '',
          !isEmailVerifiable ? phoneNumber : '',
          this.useridin
        )
      : this.profileService.VerifyAccessCode(accessCode, commChannelType, commChannel, this.useridin);
    dispatch(new SetLoader(true));
    return observable$.pipe(
      catchError(e => {
        dispatch(new SetLoader(false));
        return throwError(e);
      }),
      tap((response: any) => {
        const emailVerification = getState().emailVerification;
        if (response.result === SUCCESS_RESULT) {
          if (emailVerification) {
            patchState({
              verificationCompleted: false
            });
            dispatch([new VerifyEmail(emailAddress, false, !!isFromModal), new SetEmailVerification(!emailVerification)]);
          } else {
            patchState({
              verificationCompleted: true
            });
            if (getState().updatePreferenceFlag) {
              dispatch(new UpdatePreferencesAndConsent(isFromModal));
            } else if (getState().verifyOnlyFlow && isFromModal) {
              dispatch(new SetModalSection('SUCCESS'));
            } else {
              const consentPayload = {
                useridin: this.useridin,
                consentLanguageId: null,
                consentLanguage: null,
                consentFlag: 'N',
                consentTS: formatDate(new Date(), PN_TS_FORMAT, TS_LOCALE, EDT_TZ_OFFSET),
                modalFlag: 'N'
              };
              dispatch(new UpdateConsent(consentPayload, true))
            }

            if (!isFromModal) {
              const message = isEmailVerifiable ? VERIFIED_EMAIL_MSG : VERIFIED_PHONE_MSG;
              this.alertService.setAlert(message, '', AlertType.Success);
              if (!isMyPillpack) {
                if (getState().fromContactFlag) {
                  dispatch(new Navigate(['/myprofile/contact-info'])).subscribe(() => {
                    this.alertService.setAlert(message, '', AlertType.Success);
                  });
                } else {
                  this.navCtrl.navigateBack('/myprofile').then(() => {
                    this.alertService.setAlert(message, '', AlertType.Success);
                  });
                }
                patchState({
                  verificationResponse: response
                });
              }
            }
          }
        } else {
          patchState({
            verificationCompleted: false
          });
          let msg: string;
          if (response.result === ERROR_CODE_VERIFY_CODE_EXP) {
            msg = VERIFY_CODE_EXPIRE_MSG;
          } else if (response.result === ERROR_CODE_COMM_ERR) {
            msg = COMM_ERR_MSG;
          } else if (response.result === ERROR_CODE_VERIFY_CODE_MISMATCH) {
            msg = CODE_MISMATCH_ERR_MSG;
          } else if (response.displaymessage) {
            msg = response.displaymessage;
          }
          if (msg) {
            if (!isFromModal) {
              this.alertService.setAlert(msg, '', AlertType.Failure);
            } else {
              this.alertService.setAlert(msg, '', AlertType.Failure, 'preferenceModal');
            }
          }
        }
        dispatch(new SetLoader(false));
      })
    );
  }

  @Action(SendNotification)
  sendNotification({ patchState }: StateContext<ProfileStateModel>, { isEmailEdit, commChannelType, commChannel }: any) {
    const notificationRequest = {
      useridin: this.useridin,
      commChannel: commChannel,
      commChannelType: commChannelType,
      templateKeyword: isEmailEdit ? 'UPDATENOTIFICATION_EMAIL' : 'UPDATENOTIFICATION_MOBILE',
      notificationParms: [
        {
          keyName: 'firstName',
          keyValue: this.authToken && this.authToken.firstName ? this.titleCase.transform(this.authToken.firstName) : ''
        },
        {
          keyName: 'myProfileURL',
          keyValue: window.location.origin + '/myprofile'
        },
        {
          keyName: 'updatedFields',
          keyValue: isEmailEdit ? ['Email'] : ['Phone Number']
        }
      ]
    };

    return this.profileService.sendUpdateNotification(notificationRequest).pipe(tap(() => {}));
  }

  // TODO: SPEAK ON THIS - POOR FLOW, SHOULD CALL THE SERVICE DIRECTLY AND CONDUCT ALL LOGIC IN TAP,  NOW DELAY IS NEEDED TO HIDE SPINNER
  @Action(GetDemographicInfo)
  getDemographicInfo({ patchState, dispatch }: StateContext<ProfileStateModel>) {
    dispatch(new SetLoader(true));
    return this.profileService.getDemoGraphicInfo(this.useridin).pipe(
      catchError(e => {
        dispatch(new SetLoader(false));
        return throwError(e);
      }),
      delay(200),
      tap(response => {
        dispatch(new SetLoader(false));
        patchState({
          demoGraphicInfo: response
        });
      })
    );
  }

  @Action(UpdateDemographicInfo)
  updateDemographicInfo({ dispatch }: StateContext<ProfileStateModel>, { payload }: any) {
    dispatch(new SetLoader(true));
    return this.profileService.updateDemographicInfo(payload).pipe(
      catchError(e => {
        dispatch(new SetLoader(false));
        return throwError(e);
      }),
      tap(() => {
        dispatch([new SetLoader(false), new UpdateDemographicSuccess()]);
      })
    );
  }

  @Action(UpdatePassword)
  updatePassword({ dispatch }: StateContext<ProfileStateModel>, { payload }: any) {
    const id = this.useridin;
    const scopename = this.scopeName;
    dispatch(new SetLoader(true));
    return this.profileService.updatePassword(payload, id, scopename).pipe(
      catchError(e => {
        dispatch(new SetLoader(false));
        this.alertService.setAlert(PASSWORD_CRITERIA_ERR_MSG, '', AlertType.Failure);
        return throwError(e);
      }),
      tap((response: any) => {
        if (response?.result < 0) {
          this.alertService.setAlert(response.displaymessage, '', AlertType.Failure, 'pwderror');
        } else {
          this.alertService.setAlert(PASSWORD_CHANGED_MSG, '', AlertType.Success, 'component');
        }
        dispatch([new SetLoader(false), new UpdatePasswordSuccess()]);
      })
    );
  }

  @Action(GetConsent)
  getConsent({ patchState, dispatch }: StateContext<ProfileStateModel>, { useridin, isFromCheckModal }: GetConsent) {
    return this.preferenceService.getConsent(useridin).pipe(
      catchError(e => {
        return throwError(e);
      }),
      tap(response => {
        patchState({
          consentResponse: response
        });
        if (response?.consentFlag !== 'Y') {
          dispatch(new GetProfileDrupalConsent());
        }
        if (isFromCheckModal) {
          dispatch(new GetConsentSuccessful());
        }
      })
    );
  }

  @Action(UpdateConsent)
  updateConsent({ patchState, dispatch }: StateContext<ProfileStateModel>, { request, isVerifyFlow }: any) {
    return this.planConfigService.getCurrentPlanConfig$().pipe(
      mergeMap(planConfig => this.preferenceService.updateConsent(request).pipe(
                                catchError(e => {
                                  return throwError(e);
                                }),
                                tap(response => {
                                  if (response.result === 0) {
                                    if (planConfig.elligibility.isDigitalFirstCDH) {
                                      sessionStorage.setItem('fromContactInfo', 'true');
                                    }
                                    patchState({
                                      consentResponse: request,
                                      showModal: request.consentFlag === 'N'
                                    });
                                    if (isVerifyFlow) {
                                      dispatch([new FetchProfile(), new VerificationDone(), new UpdateProfileSuccess()]);
                                    }
                                  }
                                })
                              ))
    );
  }

  @Action(UpdateConsentState)
  updateConsentState({ patchState, getState, dispatch }: StateContext<ProfileStateModel>, { consentFlag }: any) {
    patchState({
      consentResponse: { ...getState().consentResponse, consentFlag: consentFlag }
    });
    if (consentFlag !== 'Y' && !getState().consentResponse?.body) {
      dispatch(new GetProfileDrupalConsent());
    }
  }

  @Action(GetProfileDrupalConsent)
  getProfileDrupalConsent({ getState, patchState }: StateContext<ProfileStateModel>) {
    return this.appService.getdrupalconsent().pipe(
      catchError(e => {
        return throwError(e);
      }),
      tap(response => {
        patchState({
          consentResponse: {
            ...getState().consentResponse,
            version: response[0].Version,
            body: response[0].Body,
            text: response[0].ArticleText
          }
        });
      })
    );
  }

  @Action(ResetVerifyFlags)
  resetVerifyFlags({ getState, patchState }: StateContext<ProfileStateModel>) {
    let profileInfo = getState().profileInfo;
    if (!profileInfo.isVerifiedMobile && getState().isPhoneNumberRequired) {
      profileInfo = { ...profileInfo, isVerifiedMobile: true, phoneNumber: profileInfo.updatedPhoneNumber };
    }
    if (!profileInfo.isVerifiedEmail) {
      profileInfo = { ...profileInfo, isVerifiedEmail: true, emailAddress: profileInfo.updatedEmailAddress };
    }
    patchState({
      profileInfo: profileInfo
    });
  }

  @Action(CheckForModal)
  checkForModal({ dispatch, getState }: StateContext<ProfileStateModel>) {
    const isMedicare = this.authToken.userType && this.authToken.userType.toLowerCase() === USER_TYPE_MEDICATE;
    const showPreference = !this.hasNoAltAdd ? false : !isMedicare;
    if (this.scopeName === 'AUTHENTICATED-AND-VERIFIED' && showPreference) {
      const actions = [];
      actions.push(new FetchProfile());
      actions.push(new GetConsent(this.useridin, true));
      dispatch(actions);
    } else if (this.postLoginInfo.showEmailVerifyModal) {
      dispatch(new VerifyEmailModal());
    } else if (this.authToken.HasActivePlan === 'true') {
      dispatch(new InitAboutMeModal());
    }
  }

  @Action(GetConsentSuccessful)
  getConsentSuccessful({ dispatch, getState }: StateContext<ProfileStateModel>) {
    if (getState().consentResponse?.modalFlag !== 'Y') {
      if (this.authToken.HasActivePlan === 'true') {
        dispatch([new SetModalSection(null), new ShowModal()]);
      } else if (getState().consentResponse?.consentFlag !== 'Y') {
        dispatch(new ShowConsentModal());
      }
    } else if (this.authToken.HasActivePlan === 'true') {
      dispatch(new InitAboutMeModal());
    }

  }

  @Action(SetModalSection)
  setModalSection({ patchState }: StateContext<ProfileStateModel>, { modalSection }: any) {
    patchState({
      modalSection
    });
    if (modalSection === 'VAC') {
      patchState({
        verifyOnlyFlow: true
      });
    } else if (modalSection === 'SUCCESS' || modalSection === 'ERROR') {
      this.alertService.clearError('preferenceModal');
      this.alertService.clearError();
      patchState({
        verifyOnlyFlow: false
      });
    }
  }

  @Action(SetUpdatedCommChannel)
  setUpdatedCommChannel({ patchState, getState }: StateContext<ProfileStateModel>, { channelType, channelValue }: any) {
    switch (channelType) {
      case UPDATE_TYPE.EMAIL:
        patchState({
          profileInfo: { ...getState().profileInfo, updatedEmailAddress: channelValue }
        });
        if (channelValue) {
          patchState({
            profileInfo: { ...getState().profileInfo, isVerifiedEmail: false }
          });
        }
        break;
      case UPDATE_TYPE.PHONE:
        patchState({
          profileInfo: { ...getState().profileInfo, updatedPhoneNumber: channelValue }
        });
        if (channelValue) {
          patchState({
            profileInfo: { ...getState().profileInfo, isVerifiedMobile: false }
          });
        }
    }
  }

  @Action(SetPhoneNumberRequiredFlag)
  setPhoneNumberRequiredFlag({ patchState }: StateContext<ProfileStateModel>, { isPhoneNumberRequired }: any) {
    patchState({
      isPhoneNumberRequired
    });
  }

  @Action(SetSkipVerifyPhoneFlag)
  setSkipVerifyPhoneFlag({ patchState }: StateContext<ProfileStateModel>, { isSkipVerifyPhone }: any) {
    patchState({
      isSkipVerifyPhone
    });
  }

  @Action(InitAboutMeModal)
  initAboutMeModal({ dispatch }: StateContext<ProfileStateModel>) {
    if (this.postLoginInfo.showDemographicModel && this.isActiveUser === 'true') {
      dispatch(new ShowAboutMeModal());
    }
  }

  @Action(NotifyDemographicModalDisplayed)
  enotifyDemographicsModelDisplayed() {
    return this.profileService.notifyDemographicsModelDisplayed(this.useridin);
  }

  @Action(TeleHealthInfo)
  getTeleHealthInfo({ dispatch, getState, patchState }: StateContext<ProfileStateModel>) {
    if (!getState().teleHealthDetails?.loaded) {
      return this.vitalsService.getTelehealthInfo().subscribe((response: any) => {
        if (response) {
          sessionStorage.setItem('vitalsResponse', JSON.stringify(response));
          const teleHealthDetails = {
            teleHealthEligible: response.teleHealthEligible,
            disclaimerFlag: response.platformProvider?.details?.disclaimerFlag,
            wellConnectionIndicatorFlag: response.platformProvider?.name === 'Amwell' ? true : false,  
            loaded: true
          } 
          patchState ({teleHealthDetails});
        }
        dispatch(new TelehealthInfoLoaded());
      });
    } else {
      dispatch(new TelehealthInfoLoaded());
    }
  }

  @Action(UpdateTeleHealthDisclaimerFlag)
  updateTeleHealthDisclaimerFlag({ patchState, getState }: StateContext<ProfileStateModel>, {disclaimerFlag}: UpdateTeleHealthDisclaimerFlag) {
    const teleHealthDetails = {...getState().teleHealthDetails};
    teleHealthDetails.disclaimerFlag = disclaimerFlag;
    patchState ({teleHealthDetails});
  }


}
