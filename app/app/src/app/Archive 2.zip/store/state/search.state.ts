import { Injectable } from '@angular/core';
import { State, Action, StateContext } from '@ngxs/store';
import { DEFAULT_SEARCH_STATE } from '@app/store/constants/app.constants';
import { FilterByProduct, FilterSearchResults, Search, SetSearchOnlyFlag, ViewBenefitDetails } from '@app/store/actions/search.actions';
import { AppService } from '@app/services/app.service';
import { BenefitSearchResultGroup } from '@app/models/benefit-search-result';
import { filterSearchResultsByPlan, toTitleCase } from '../utils/search-state.utls';
import { MyPlansService } from '@app/pages/my-plans/my-plans.service';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AppSelectors } from '../selectors/app.selectors';
import { BenefitSearchCPC } from '@app/models/search.model';
import { Navigate } from '@ngxs/router-plugin';
import { SetLoader } from '../actions/app.actions';
import { CryptoModel } from '@app/models/crypto.model';
import { throwError } from 'rxjs';
import { catchError, tap, filter } from 'rxjs/operators';

export class SearchStateModel {
  keyword: string;
  isSearchOnly: boolean;
  searchResults: BenefitSearchResultGroup[];
  pagedItems: BenefitSearchResultGroup[];
  currentPage: number;
  currentFilteredProductType: string;
  productTypes: string[];
}

@State<SearchStateModel>({
  name: 'search',
  defaults: DEFAULT_SEARCH_STATE
})
@Injectable()
export class SearchState {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getSearchableCpcs) searchablesCpcs: BenefitSearchCPC[];
  @SelectSnapshot(AppSelectors.getCryptoToken) cryptoTokens: CryptoModel;

  constructor(private appService: AppService, private myPlanService: MyPlansService) {}

  @Action(Search)
  search({ dispatch, getState, patchState }: StateContext<SearchStateModel>, { keyword }) {
    const payload = {
      useridin: this.useridin,
      searchKeyword: keyword,
      searchableCPCs: this.searchablesCpcs,
      key2id: this.cryptoTokens.key2id
    };
    dispatch(new SetLoader(true));
    return this.appService.doBenefitSearch(payload).pipe(
      catchError(e => {
        return throwError(e);
      }),
      filter(response => response?.searchResults !== undefined),
      tap(response => {
        let productTypes = response.searchResults.filter(plan => plan.benefits?.length > 0).map(e => toTitleCase(e.productType));
        productTypes.unshift('All Benefits');
        productTypes = [...new Set(productTypes)];
        const formatted = response.searchResults
          .map(e =>
            e.benefits
              ? {
                  ...e,
                  benefits: e.benefits?.map(plan => ({
                    ...plan,
                    cpcCode: e.cpcCode,
                    productType: toTitleCase(e.productType),
                    planName: e.planName
                  }))
                }
              : null
          )
          .filter(n => n);
        patchState({
          keyword: keyword,
          isSearchOnly: false,
          searchResults: formatted,
          productTypes,
          currentFilteredProductType: 'All Benefits'
        });
        dispatch([new FilterSearchResults('All Benefits')]);
      })
    );
  }

  @Action(FilterSearchResults)
  filterSearchResults({ dispatch, getState, patchState }: StateContext<SearchStateModel>) {
    const searchResults = getState().searchResults;
    const productType = getState().currentFilteredProductType;
    const filtered = filterSearchResultsByPlan(searchResults, productType).reduce((acc, result) => {
      return acc.concat(result.benefits);
    }, []);
    patchState({
      pagedItems: filtered
    });
    setTimeout(() => {
      dispatch(new SetLoader(false));
    }, 300);
  }

  @Action(SetSearchOnlyFlag)
  setSearchOnlyFlag({ patchState }: StateContext<SearchStateModel>, { isSearchOnly }) {
    patchState({
      isSearchOnly
    });
    if (isSearchOnly) {
      patchState({
        searchResults: [],
        productTypes: [],
        currentFilteredProductType: ''
      });
    }
  }

  @Action(FilterByProduct)
  filterByProduct({ patchState, dispatch, getState }: StateContext<SearchStateModel>, { productType }) {
    patchState({
      currentFilteredProductType: productType
    });
    dispatch(new SetLoader(true));
    dispatch(new FilterSearchResults(productType));
  }

  @Action(ViewBenefitDetails)
  navigateToBenefitDetails({ dispatch, getState }: StateContext<SearchStateModel>, { resultRow }) {
    this.myPlanService.setPlanBenefitDetailsRequest({
      planName: resultRow.planName,
      coveragePackageCode: resultRow.cpcCode,
      cpcCode: resultRow.cpcCode,
      useridin: this.useridin,
      benefitCategoryID: resultRow.benefitCategoryID,
      benefitCategoryName: resultRow.benefitCategoryName
    });
    this.myPlanService.setServiceBenefitCategoryName(resultRow.benefitCategoryName);
    dispatch(new Navigate(['/myPlan/benefitdetails'], { keyword: getState().keyword }));
  }
}
