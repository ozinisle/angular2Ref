import { Injectable } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { RegType } from '@app/enums/reg-type.enum';
import { RegisterConstants } from '@app/pages/registration/constants/register-detail.error.constants';
import { AlertService } from '@app/services/alert.service';
import { AppService } from '@app/services/app.service';
import { ClearInterval, GetTokens, Login, SetLoader } from '@app/store/actions/app.actions';
import {
  CheckUsernameValidity,
  PreRegisterState,
  Register,
  RegistrationError,
  SendCode,
  SetFromRegistration,
  VerifyANVUser
} from '@app/store/actions/register.actions';
import { DEFAULT_REGISTER_STATE } from '@app/store/constants/app.constants';
import { Action, State, StateContext } from '@ngxs/store';
import { throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';

export class RegisterStateModel {
  fromRegistration: boolean;
  onVerifyScreen: boolean;
  error: any;
}

@State<RegisterStateModel>({
  name: 'register',
  defaults: DEFAULT_REGISTER_STATE
})
@Injectable()
export class RegisterState {
  constructor(private appService: AppService, private router: Router, private alertService: AlertService) {}

  @Action(PreRegisterState)
  prepareRegisterState({ dispatch }: StateContext<RegisterStateModel>, { request }: PreRegisterState) {
    dispatch([new ClearInterval(), new GetTokens(request, true)]);
  }

  @Action(Register)
  register(
    { getState, patchState, dispatch }: StateContext<RegisterStateModel>,
    { loginData, regType, code, cryptoTokens, consentData }: Register
  ) {
    dispatch(new SetLoader(true));

    const request = {
      useridin: regType === RegType.MOBILE ? loginData.useridin.replace(/\D/g, '') : loginData.useridin,
      passwordin: loginData.passwordin,
      accessCode: code,
      regType: regType,
      consentLanguageId: consentData.consentLanguageId,
      consentLanguage: encodeURI(consentData.consentLanguage),
      consentTS: consentData.consentTS,
      key2id: cryptoTokens.key2id
    };

    return this.appService.register(request, cryptoTokens).pipe(
      catchError(error => {
        dispatch(new SetLoader(false));
        if (error?.error?.displaymessage) {
          const displayMessage = error.error.displaymessage;
          this.alertService.setAlert(displayMessage, '', AlertType.Failure);
        }
        return throwError(error);
      }),
      tap(response => {
        if (response?.result === 0) {
          dispatch(new Login({ useridin: request.useridin, passwordin: request.passwordin }));
          patchState({
            fromRegistration: true
          });
        } else {
          this.handleApiError(response);
          dispatch(new RegistrationError(response));
        }
      })
    );
  }

  @Action(CheckUsernameValidity)
  checkUsernameValidity(
    { patchState, dispatch }: StateContext<RegisterStateModel>,
    { loginData, regType, cryptoTokens, navigate }: CheckUsernameValidity
  ) {
    return this.appService.validateUsername(loginData.useridin, regType, cryptoTokens?.key2id).pipe(
      catchError(error => {
        return throwError(error);
      }),
      tap(response => {
        if (response?.result === 0) {
          patchState({
            onVerifyScreen: true
          });

          dispatch(new SetLoader(false));

          if (navigate) {
            const navigationExtras: NavigationExtras = {
              state: {
                loginData: loginData
              }
            };
            this.router.navigate(['register/verification'], navigationExtras);
          }

          this.alertService.setAlert('Verification code sent!', '', AlertType.Success);
        } else {
          if (!(response['result'] === -93222 && response['errormessage'] === 'UserId already exist')) {
            this.handleApiError(response);
          }
          dispatch(new RegistrationError(response));
        }
      })
    );
  }

  @Action(RegistrationError)
  registrationError({ dispatch, patchState }: StateContext<RegisterStateModel>, { error }: RegistrationError) {
    dispatch(new SetLoader(false));
    patchState({
      error: error
    });
  }

  @Action(SetFromRegistration)
  setFromRegistration({ patchState }: StateContext<RegisterStateModel>, { value }: SetFromRegistration) {
    patchState({
      fromRegistration: value
    });
  }

  @Action(VerifyANVUser)
  verifyANVUser({ dispatch }: StateContext<RegisterStateModel>, { code, useridin, type, commChannelValue }: VerifyANVUser) {
    const request = {
      useridin: useridin,
      commChannel: commChannelValue ? commChannelValue : useridin,
      commChannelType: type ? type : useridin.includes('@') ? RegType.EMAIL : RegType.MOBILE,
      userIDToVerify: useridin,
      accesscode: code
    };
    return this.appService.verifyAccessCode(request).pipe(
      catchError(error => {
        return throwError(error);
      }),
      tap((response: any) => {
        if (response.result === '0') {
          this.router.navigate(['register/success']);
        } else {
          this.alertService.setAlert(response.displayMessage, '', AlertType.Failure);
        }
      })
    );
  }

  @Action(SendCode)
  sendCode({ dispatch }: StateContext<RegisterStateModel>, { id }: SendCode) {
    dispatch(new SetLoader(true));
    return this.appService.sendCode({ useridin: id }).pipe(
      catchError(error => {
        dispatch(new SetLoader(false));
        return throwError(error);
      }),
      tap((response: any) => {
        dispatch(new SetLoader(false));
      })
    );
  }

  handleApiError(response?) {
    let displayMessage: string;
    const errorMessage = response['errormessage'];
    if (errorMessage.indexOf('Exists') > 0 || errorMessage.indexOf('exist') > 0 || response['result'] === '-1') {
      displayMessage = RegisterConstants.userMismatchMsg;
    } else {
      displayMessage = response['displaymessage'];
    }
    this.alertService.setAlert(displayMessage, '', AlertType.Failure);
  }
}
