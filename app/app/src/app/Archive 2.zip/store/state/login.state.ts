import { Action, State, StateContext } from '@ngxs/store';
import { SetBioData, SetRememberMe, SetUserName, ShowPassword } from '../actions/login.actions';
import { DEFAULT_LOGIN_STATE } from '../constants/app.constants';
import { LoginRequest } from '../../models/login-request.model';
import { Injectable } from '@angular/core';

export class LoginStateModel {
  username: string;
  rememberMe: boolean;
  showPassword: boolean;
  bioData: LoginRequest;
}
@State<LoginStateModel>({
  name: 'login',
  defaults: DEFAULT_LOGIN_STATE
})
@Injectable()
export class LoginState {
  @Action(SetUserName)
  setUsername({ patchState }: StateContext<LoginStateModel>, { username }: SetUserName) {
    patchState({
      username: username
    });
  }

  @Action(SetRememberMe)
  setRememberMe({ getState, patchState }: StateContext<LoginStateModel>, { rememberMe }: SetRememberMe) {
    patchState({
      rememberMe: rememberMe
    });
  }

  @Action(ShowPassword)
  showPassword({ patchState }: StateContext<LoginStateModel>, { showPassword }: ShowPassword) {
    patchState({
      showPassword: showPassword
    });
  }

  @Action(SetBioData)
  setBioData({ patchState }: StateContext<LoginStateModel>, { bioData }: SetBioData) {
    patchState({
      bioData: bioData
    });
  }
}
