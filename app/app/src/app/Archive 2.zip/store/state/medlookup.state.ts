import { Action, State, StateContext, Store } from '@ngxs/store';
import { catchError, finalize, tap } from 'rxjs/operators';
import { GetMedlookupInfo } from '../actions/medlookup.actions';
import { DEFAULT_MEDLOOKUP_STATE } from '../constants/app.constants';
import { Injectable } from '@angular/core';
import { MedLookupSearchService } from '../../pages/med-lookup-search/med-lookup-search.service';
import { MedlookupsModel } from '@app/pages/med-lookup-search/models/search-results';
import { Navigate } from '@ngxs/router-plugin';
import { IabService } from '@app/services/iab.service';
import { throwError } from 'rxjs';
import { SetLoader } from '../actions/app.actions';

export class MedlookupModel {
  medlookup: MedlookupsModel;
}

@State<MedlookupModel>({
  name: 'medlookup',
  defaults: DEFAULT_MEDLOOKUP_STATE
})
@Injectable()
export class MedlookupState {
  npfUrl = 'https://home.bluecrossma.com/medication/national-preferred-formulary';
  constructor(private medLookupSearch: MedLookupSearchService, private iabService: IabService, private store: Store) {}
  @Action(GetMedlookupInfo)
  getMedlookupTier({ patchState, dispatch, getState }: StateContext<MedlookupModel>) {
    if (getState()?.medlookup) {
      if (getState()?.medlookup?.NPFFlag) {
        this.iabService.create(this.npfUrl);
      } else {
        this.store.dispatch(new Navigate(['med-lookup-search/']));
      }
    } else {
      dispatch(new SetLoader(true));
      return this.medLookupSearch.getformularyandtierInfo().pipe(
        tap(data => {
          dispatch(new SetLoader(false));
          patchState({
            medlookup: data
          });
          if (data?.NPFFlag) {
            this.iabService.create(this.npfUrl);
          } else {
            this.store.dispatch(new Navigate(['med-lookup-search/']));
          }
        }),
        catchError(err => {
          dispatch(new SetLoader(false));
          this.store.dispatch(new Navigate(['med-lookup-search/']));
          return throwError(err);
        }),
        finalize(() => {
          dispatch(new SetLoader(false));
        })
      );
    }
  }
}
