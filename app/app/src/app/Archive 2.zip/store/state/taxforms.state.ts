import { Action, State, StateContext } from '@ngxs/store';
import { catchError, tap } from 'rxjs/operators';
import { TaxFormsService } from '../../pages/message-center/services/tax-forms.service';
import { TaxFormsModel } from '../../pages/message-center/tax-forms/models/tax-froms-models';
import { SetLoader } from '../actions/app.actions';
import { GetTaxForms } from '../actions/taxforms.action';
import { DEFAULT_TAX_FORM_STATE } from '../constants/app.constants';
import { throwError } from 'rxjs';
import { Injectable } from '@angular/core';

export class TaxFormModel {
  taxforms: TaxFormsModel[];
}
@State<TaxFormModel>({
  name: 'taxforms',
  defaults: DEFAULT_TAX_FORM_STATE
})
@Injectable()
export class TaxFormsState {
  constructor(private taxFormsService: TaxFormsService) {}
  @Action(GetTaxForms)
  getTaxForms({ getState, patchState, setState, dispatch }: StateContext<TaxFormModel>, { year }: GetTaxForms) {
    dispatch(new SetLoader(true));
    return this.taxFormsService.getTaxFormsData(year).pipe(
      catchError(error => {
        dispatch(new SetLoader(false));
        const taxFormData = [];
        if (getState().taxforms) {
          getState().taxforms.forEach(taxData => {
            if (taxData.taxYear !== year && taxData.dataLoad === true) {
              taxFormData.push(taxData);
            }
          });
        }
        taxFormData.push({ taxYear: year, formData: [], dataLoad: false });
        patchState({
          taxforms: taxFormData
        });
        return throwError(error);
      }),
      tap(data => {
        const taxFormData = [];
        if (getState().taxforms) {
          getState().taxforms.forEach(taxData => {
            if (taxData.taxYear !== year && taxData.dataLoad === true) {
              taxFormData.push(taxData);
            }
          });
        }
        if (data['result'] < 1) {
          const memberRightsFlag =
            data['result'] === -95403 || data['result'] === -95404 || data['result'] === -95406 || data['result'] === -95407 ? true : false;

          taxFormData.push({
            taxYear: year,
            formData: [],
            dataLoad: true,
            displayMessage: data['displaymessage'],
            result: data['result'],
            memberRightsFlag: memberRightsFlag
          });
        } else {
          taxFormData.push({ taxYear: year, formData: data.forms, displayMessage: '', dataLoad: true, result: 1 });
        }
        patchState({
          taxforms: taxFormData
        });
        dispatch(new SetLoader(false));
      })
    );
  }
}
