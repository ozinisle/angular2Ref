import { Injectable } from '@angular/core';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { Preference } from '@app/models/preference.model';
import { ProfileInfo } from '@app/models/profile-response.model';
import { AlertService } from '@app/services/alert.service';
import { ConstantsService } from '@app/services/constants.service';
import { PreferenceService } from '@app/services/preference.service';
import { ProfileService } from '@app/services/profile.service';
import { SetLoader } from '@app/store//actions/app.actions';
import {
  CheckPreferenceServices,
  GetPreferences,
  GetProgramGroups,
  IsUserChannelBounced,
  PossibleNowServiceFailure,
  SetPreferencePromo,
  SetShowModalFlag,
  SubmitConsent,
  SubmitPreferences,
  SwapPromo,
  UpdatePreferences,
  UpdatePreferencesAndConsent,
  UpdatePreferenceSelection,
  UpdatePreferenceSuccess
} from '@app/store/actions/preference.action';
import {
  ResetVerifyFlags,
  SetPhoneNumberRequiredFlag,
  SetSkipVerifyPhoneFlag,
  UpdateConsent,
  UpdateProfile
} from '@app/store/actions/profile.action';
import { DEFAULT_PREFERENCES_STATE } from '@app/store/constants/app.constants';
import { ALERT_MSG, DEFAULT_PHONE_NUM, ERROR_CODES_ALTERNATE_ADDRESS } from '@app/store/constants/preference.constants';
import {
  createConsentObject,
  createPreferenceConsentObject,
  createPreferenceRequest,
  extractProgramList,
  getCID,
  getLastPreferenceUpdates,
  getPaperlessPromoFlag,
  hasConsentPreference,
  isHealthBenefitSelected,
  isMobilePreferenceSelected,
  isPlanDocumentSelected,
  isUserChannelBounced,
  setFilterSelections
} from '@app/store/utils/preference-state.utils';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Navigate } from '@ngxs/router-plugin';
import { Action, State, StateContext } from '@ngxs/store';
import { cloneDeep } from 'lodash-es';
import { throwError } from 'rxjs';
import { catchError, mergeMap, tap } from 'rxjs/operators';
import {
  FetchProfile,
  GetConsent,
  SetEmailVerification,
  SetModalSection,
  SetUpdatePreferenceFlag,
  UpdateProfileSuccess,
  VerifyEmail,
  VerifyPhone,
  CheckForModal
} from '../actions/profile.action';
import { AppSelectors } from '../selectors/app.selectors';
import { ProfileSelectors } from '../selectors/profile.selectors';
import { PostLoginModel } from '@app/models/post-login.model';
import { PlanConfigService } from '@app/services/plan-config/plan-config-service';

export class PreferenceStateModel {
  prefResponses: any;
  preferences: any;
  programGroups: any;
  paperlessPromoFlag: boolean;
  showModal: boolean;
  updatePreferenceInfo: any;
  prefCID: string;
  updatePreferenceSuccess: boolean;
  updatePreferenceFailure: boolean;
  isPlanDocumentsSelected: boolean;
  isHealthBenefitsSelected: boolean;
  isFromModal: boolean;
  lastPrefUpdateType: string;
  lastPrefModifiedDate: string;
  isUserChannelBounced: string;
  fetchedPreferences: any;
  newPreferences: any;
  showRELModal: boolean;
}

@State<PreferenceStateModel>({
  name: 'preference',
  defaults: DEFAULT_PREFERENCES_STATE
})
@Injectable()
export class PreferenceState {
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;
  @SelectSnapshot(AppSelectors.getSessionId) sessionId: string;
  @SelectSnapshot(AppSelectors.getHasNoAltAdd) hasNoAltAdd: boolean;
  @SelectSnapshot(AppSelectors.getPostLoginInfo) postLoginInfo: PostLoginModel;

  @SelectSnapshot(ProfileSelectors.getProfileInfo) profile: ProfileInfo;
  @SelectSnapshot(ProfileSelectors.getConsentResponse) consentResponse: any;
  @SelectSnapshot(ProfileSelectors.isSkipVerifyPhone) isSkipVerifyPhone: boolean;
  @SelectSnapshot(ProfileSelectors.getProfileInfo) profileInfo: any;

  constructor(
    private profileService: ProfileService,
    private preferenceService: PreferenceService,
    private alertService: AlertService,
    private constants: ConstantsService,
    private planConfigService: PlanConfigService
  ) {}

  @Action(GetProgramGroups)
  getProgramGroups({ patchState, dispatch }: StateContext<PreferenceStateModel>) {
    patchState({
      isPlanDocumentsSelected: false,
      isHealthBenefitsSelected: false
    });
    return this.preferenceService.getProgramGroups(this.useridin).pipe(
      catchError(e => {
        dispatch(new SetLoader(false));
        return throwError(e);
      }),
      tap(response => {
        if (response?.message) {
          const programList = extractProgramList(response?.message);
          patchState({
            programGroups: programList
          });
          dispatch(new GetPreferences());
        } else {
          dispatch(new PossibleNowServiceFailure());
        }
      })
    );
  }

  @Action(GetPreferences)
  getPreferences({ patchState, getState, dispatch }: StateContext<PreferenceStateModel>) {
    return this.planConfigService.getCurrentPlanConfig$().pipe(
      mergeMap(planConfig => this.preferenceService.getPreferences(this.useridin).pipe(
        catchError(e => {
          return throwError(e);
        }),
        tap(response => {
          sessionStorage.removeItem('isEmailSelected');
          sessionStorage.removeItem('isSmsSelected');
          if (response.message) {
            if (getState().programGroups) {
              const programList = cloneDeep(getState().programGroups);
              patchState({
                programGroups: setFilterSelections(programList, response.message.Preferences),
                fetchedPreferences: programList
              });
              const lastPrefUpdates = getLastPreferenceUpdates(response.message.Preferences);
              patchState({
                isPlanDocumentsSelected: isPlanDocumentSelected(programList, planConfig.elligibility.isDigitalFirstCDH),
                isHealthBenefitsSelected: isHealthBenefitSelected(programList),
                lastPrefUpdateType: lastPrefUpdates.lastPrefUpdateType,
                lastPrefModifiedDate: lastPrefUpdates.lastPrefModifiedDate
              });
              dispatch(new SetPhoneNumberRequiredFlag(isMobilePreferenceSelected(programList)));
            }
            const prefCID = getCID(response);
            patchState({
              paperlessPromoFlag: getPaperlessPromoFlag(response.message.Preferences),
              prefCID: prefCID
            });
            if (!hasConsentPreference(response.message.Preferences)) {
              const consentPreference = createPreferenceConsentObject(this.consentResponse, this.sessionId, prefCID, 'A', null);
              dispatch(new UpdatePreferences([consentPreference], false, true));
            }
          } else if (ERROR_CODES_ALTERNATE_ADDRESS.indexOf(response.result) !== -1) {
            const prefCID = getCID(response);
            sessionStorage.setItem('isSmsSelected', 'unSelected');
            sessionStorage.setItem('isEmailSelected', 'unSelected');
            const consentPreference = createPreferenceConsentObject(this.consentResponse, this.sessionId, prefCID, 'A', null);
            dispatch(new UpdatePreferences([consentPreference], false, true));
            patchState({
              prefCID: prefCID
            });
          } else {
            dispatch(new PossibleNowServiceFailure());
          }
          dispatch(new SetLoader(false));
        })
      )
      ));
  }

  @Action(UpdatePreferences)
  updatePreferences({ dispatch, patchState }: StateContext<PreferenceStateModel>, { changedItem, isFromModal, isConsentOnly }: any) {
    patchState({
      newPreferences: changedItem
    });
    return this.preferenceService.updatePreferences(this.useridin, changedItem).pipe(
      catchError(e => {
        return throwError(e);
      }),
      tap((response: any) => {
        if (!isConsentOnly) {
          if (!isFromModal) {
            if (response.result === 0) {
              dispatch([new Navigate(['/myprofile']), new UpdateProfileSuccess()]);
              setTimeout(() => this.alertService.setAlert(ALERT_MSG.success, '', AlertType.Success), 0);
              patchState({
                paperlessPromoFlag: getPaperlessPromoFlag(changedItem),
                updatePreferenceFailure: null
              });
              dispatch(new UpdatePreferenceSuccess());
            } else {
              patchState({
                updatePreferenceFailure: true
              });
              dispatch(new Navigate(['/myprofile']));
              setTimeout(() => this.alertService.setAlert(ALERT_MSG.error, '', AlertType.Failure), 0);
            }
          } else {
            if (response.result === 0) {
              patchState({
                paperlessPromoFlag: getPaperlessPromoFlag(changedItem),
                updatePreferenceFailure: null,
                showModal: false
              });
              dispatch(new UpdatePreferenceSuccess());
            } else {
              patchState({
                updatePreferenceFailure: true,
                showModal: false
              });
              dispatch([new SetModalSection('ERROR'), new SetLoader(false)]);
            }
          }
        }
      })
    );
  }

  @Action(IsUserChannelBounced)
  IsUserChannelBounced({ patchState }: StateContext<PreferenceStateModel>) {
    return this.preferenceService.getPreferences(this.useridin).pipe(
      catchError(e => {
        return throwError(e);
      }),
      tap(response => {
        if (response.message) {
          sessionStorage.removeItem('isEmailSelected');
          sessionStorage.removeItem('isSmsSelected');
          if (response.message.Preferences.length > 1) {
            response.message.Preferences.forEach(value => {
              if (value.PreferenceType === 2 && value.ProgramID === 'Documents_Plan' && value.ChannelID === 'SOLICIT') {
                sessionStorage.setItem('isEmailSelected', 'unSelected');
              }
              if (value.PreferenceType === 2 && value.ProgramID === 'Documents_Plan' && value.ChannelID === 'SMS') {
                sessionStorage.setItem('isSmsSelected', 'unSelected');
              }
            });
          } else {
            if (
              response.message.Preferences[0].PreferenceType === 1 &&
              response.message.Preferences[0].ProgramID === 'Consent_Paperless' &&
              response.message.Preferences[0].ChannelID === 'SOLICIT'
            ) {
              sessionStorage.setItem('isSmsSelected', 'unSelected');
              sessionStorage.setItem('isEmailSelected', 'unSelected');
            }
          }
          const channelBounced = isUserChannelBounced(response.message.Preferences);
          if (channelBounced === 'Email' || channelBounced === 'SMS') {
            patchState({
              isUserChannelBounced: channelBounced
            });
          }
          return channelBounced;
        }
      })
    );
  }

  @Action(SwapPromo)
  swapPromo({ getState, patchState, dispatch }: StateContext<PreferenceStateModel>) {
    //paperlessPromoFlag is boolean so have to do explicit undefined check.
    if (getState().paperlessPromoFlag !== null) {
      dispatch(new SetPreferencePromo(getState().paperlessPromoFlag));
    } else {
      return this.preferenceService.getPreferences(this.useridin).pipe(
        catchError(e => {
          return throwError(e);
        }),
        tap(response => {
          if (response.errormessage) {
            dispatch(new SetPreferencePromo(true));
          } else {
            patchState({
              paperlessPromoFlag: getPaperlessPromoFlag(response.message.Preferences)
            });
            dispatch(new SetPreferencePromo());
          }
        })
      );
    }
  }

  @Action(SetPreferencePromo)
  setPreferencePromo({ getState }: StateContext<PreferenceStateModel>, { paperlessPromoFlg }) {
    let fpoPreferenceUrl = null;
    const paperlessPromo = getState().paperlessPromoFlag ? getState().paperlessPromoFlag : paperlessPromoFlg;
    fpoPreferenceUrl = paperlessPromo
      ? this.constants.drupalUrl + '/page/preference-center'
      : this.constants.drupalUrl + '/page/home-promoblock2';

    this.profileService.preferencePromo(fpoPreferenceUrl);
  }

  @Action(SetShowModalFlag)
  setShowModalFlag({ patchState }: StateContext<PreferenceStateModel>, { showModalFlg }) {
    patchState({
      showModal: showModalFlg
    });
  }

  @Action(CheckPreferenceServices)
  checkPreferenceServices({ patchState, dispatch, getState }: StateContext<PreferenceStateModel>, { isFromModal }) {
    patchState({
      updatePreferenceFailure: null,
      isFromModal: isFromModal
    });
    const actions = [];
    actions.push(new SetLoader(true));
    actions.push(new FetchProfile());
    actions.push(new GetConsent(this.useridin));
    if (!getState().programGroups) {
      actions.push(new GetProgramGroups());
    } else {
      actions.push(new GetPreferences());
    }
    dispatch(actions);
  }

  @Action(SubmitPreferences)
  submitPreferences({ getState, patchState, dispatch }: StateContext<PreferenceStateModel>, { isFromModal }) {
    const { isVerifiedEmail, isVerifiedMobile } = this.profile;
    const phoneNumber = this.profile.updatedPhoneNumber || this.profile.phoneNumber;
    const hasPendingMobileVerification = !isVerifiedMobile && !this.isSkipVerifyPhone && phoneNumber && phoneNumber !== DEFAULT_PHONE_NUM;
    const updatePreferenceInfo = {
      consentData: this.consentResponse,
      sessionId: this.sessionId
    };
    patchState({
      updatePreferenceInfo: updatePreferenceInfo
    });
    dispatch(new SetUpdatePreferenceFlag(false));
    if (!isVerifiedEmail || hasPendingMobileVerification) {
      const actions = [];
      actions.push(new SetUpdatePreferenceFlag(true));
      if (!isVerifiedMobile && !this.isSkipVerifyPhone && phoneNumber && phoneNumber !== DEFAULT_PHONE_NUM) {
        actions.push(new VerifyPhone(phoneNumber, false, isFromModal));
        if (!isVerifiedEmail) {
          actions.push(new SetEmailVerification(true, this.profile.updatedEmailAddress));
        }
      } else if (!isVerifiedEmail) {
        actions.push(new VerifyEmail(this.profile.updatedEmailAddress, false, isFromModal));
        actions.push(new SetEmailVerification(false, this.profile.updatedEmailAddress));
      }
      dispatch(actions);
    } else {
      dispatch(new UpdatePreferencesAndConsent(isFromModal));
    }
  }

  @Action(UpdatePreferencesAndConsent)
  updatePreferencesAndConsent({ dispatch, getState }: StateContext<PreferenceStateModel>, { isFromModal }: any) {
    const updatePreferenceInfo = getState().updatePreferenceInfo;
    const preferences: Preference[] = createPreferenceRequest(
      updatePreferenceInfo,
      getState().programGroups,
      getState().prefCID,
      getState().lastPrefUpdateType,
      getState().lastPrefModifiedDate
    );
    this.alertService.clearError();
    if (this.isSkipVerifyPhone || this.profile.updatedPhoneNumber === DEFAULT_PHONE_NUM) {
      const request = {
        useridin: this.useridin,
        phoneNumber: this.profile.updatedPhoneNumber || this.profile.phoneNumber,
        phoneType: 'MOBILE'
      };
      dispatch([new SetUpdatePreferenceFlag(true), new SetSkipVerifyPhoneFlag(false)]);
      dispatch([new UpdateProfile(request, false, false, true, false, false, isFromModal)]);
    }
    dispatch([new SetLoader(true), new ResetVerifyFlags(), new UpdatePreferences(preferences, isFromModal)]);
  }

  @Action(UpdatePreferenceSuccess)
  updatePreferenceSuccess({ patchState, dispatch, getState }: StateContext<PreferenceStateModel>, {}: any) {
    const updatePreferenceInfo = getState().updatePreferenceInfo;
    const fetchedpreferences = getState().fetchedPreferences;
    const actions = [];
    if (this.consentResponse.consentFlag !== 'Y' || this.consentResponse.modalFlag !== 'Y') {
      const consentObject = createConsentObject(this.consentResponse, this.useridin);
      actions.push(new UpdateConsent(consentObject));
    }
    let changedPreferences;
    changedPreferences = getState().newPreferences;
    let newSMSPreferenceSelected = [];
    let oldSMSPreferenceSelected = [];
    const phoneNumber = this.profileInfo.phoneNumber;
    newSMSPreferenceSelected = changedPreferences.filter(el => el.FilterID === 'DOCS_PLAN_SMS');
    oldSMSPreferenceSelected = fetchedpreferences ? fetchedpreferences[0].filters.filter(el => el.channelID === 'SMS') : [];
    if (
      oldSMSPreferenceSelected.length > 0 &&
      newSMSPreferenceSelected.length > 0 &&
      oldSMSPreferenceSelected[0].selected === false &&
      newSMSPreferenceSelected[0].PreferenceType === '1'
    ) {
      this.preferenceService.eobOptInTextPreference(phoneNumber).subscribe(res => {
        return res;
      });
    } else if (
      oldSMSPreferenceSelected.length > 0 &&
      newSMSPreferenceSelected.length > 0 &&
      oldSMSPreferenceSelected[0].selected === true &&
      newSMSPreferenceSelected[0].PreferenceType === '2'
    ) {
      this.preferenceService.eobOptOutTextPreference(phoneNumber).subscribe(res => {
        return res;
      });
    }
    //Show Success Popup, only if Demographic model is not required
    let gotoVerification = false;
    const { isVerifiedEmail, isVerifiedMobile } = this.profileInfo;
    const mobileNumber = this.profileInfo.updatedPhoneNumber || this.profileInfo.phoneNumber;
    const hasPendingMobileVerification = !isVerifiedMobile && !this.isSkipVerifyPhone && mobileNumber && mobileNumber !== DEFAULT_PHONE_NUM;
    if (!isVerifiedEmail || !isVerifiedMobile || hasPendingMobileVerification) {
      gotoVerification = true;
    }
    let showRELModal = false;
    showRELModal =
      this.postLoginInfo.showDemographicModel &&
      (!gotoVerification || this.preferenceService.phoneNumberVerificationSkipped || !getState().showModal);
    if (!showRELModal) {
      actions.push(new SetModalSection('SUCCESS'), new SetLoader(false), new SwapPromo());
      dispatch(actions);
      patchState({
        programGroups: updatePreferenceInfo?.programList,
        updatePreferenceInfo: null
      });
    } else {
      patchState({
        programGroups: updatePreferenceInfo?.programList,
        updatePreferenceInfo: null,
        showRELModal: true
      });
      this.preferenceService.showRELAfterPrefModal = true;
      actions.push(new CheckForModal(), new SetLoader(false), new SwapPromo());
      dispatch(actions);
    }
  }

  @Action(UpdatePreferenceSelection)
  updatePreferenceSelection(
    { patchState, getState, dispatch }: StateContext<PreferenceStateModel>,
    { programId, channelId, isPreferenceSelected }
  ) {
    const programList = cloneDeep(getState().programGroups);
    let healthBenefitEmailSelected = false;
    let healthBenefitTextSelected = false;
    let healthBenefitValue = false;
    programList.forEach(program => {
      if (program.ID === programId) {
        program.filters.forEach(programFilter => {
          if (programFilter.channelID === channelId) {
            programFilter.selected = isPreferenceSelected;
          } else if (isPreferenceSelected && program.ID === 'Documents_Plan') {
            programFilter.selected = false;
          }
          if (program.ID === 'Documents_Plan' && programFilter.selected) {
            patchState({
              isPlanDocumentsSelected: true
            });
          } else if (program.ID === 'Health_Benefits') {
            if (programFilter.channelID === 'EMAIL') {
              healthBenefitEmailSelected = programFilter.selected;
            } else if (programFilter.channelID === 'SMS') {
              healthBenefitTextSelected = programFilter.selected;
            }
            healthBenefitValue = healthBenefitEmailSelected || healthBenefitTextSelected ? true : false;

            patchState({
              isHealthBenefitsSelected: healthBenefitValue
            });
          }
        });
      }
    });
    patchState({
      programGroups: programList
    });
    dispatch(new SetPhoneNumberRequiredFlag(isMobilePreferenceSelected(programList)));
  }

  @Action(PossibleNowServiceFailure)
  possibleNowServiceFailure({ getState, patchState }: StateContext<PreferenceStateModel>) {
    if (getState().isFromModal) {
      this.alertService.setAlert(ALERT_MSG.error, '', AlertType.Failure, 'preferenceModal');
    } else {
      this.alertService.setAlert(ALERT_MSG.error, '', AlertType.Failure);
    }
    patchState({
      isFromModal: false
    });
  }

  @Action(SubmitConsent)
  submitConsent({ dispatch, getState, patchState }: StateContext<PreferenceStateModel>, { isFromModal }) {
    const consentPreference = createPreferenceConsentObject(this.consentResponse, this.sessionId, getState().prefCID, 'A', null);
    dispatch(new UpdatePreferences([consentPreference], true, false));
  }
}
