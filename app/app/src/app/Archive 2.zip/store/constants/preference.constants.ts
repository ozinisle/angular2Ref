export const ERROR_CODES = [-94026, -94027, -94028, -94029, -94030, -94031, -94032, -94033, -94034, -94035];

export const ERROR_CODES_GETFWB = [-94000, -94001, -94002, -94003, -94004, -94005, -94006, -94007, -94011, -94012, -94013, -94015];

export const ERROR_CODES_ALTERNATE_ADDRESS = [-92914];

export const ERROR_CODES_UPDATE_PROFILE = [-90124, -90126];

export const VERIFIED_USER_SCOPES = ['AUTHENTICATED-AND-VERIFIED', 'REGISTERED-AND-VERIFIED'];
export const EDIT_ADDRESS_MSG = 'Your Mailing Address has been updated!';
export const EDIT_PHONE_MSG = 'Your Mobile number has been updated!';
export const EDIT_EMAIL_MSG = 'Your Email Address has been updated!';
export const EDIT_HEALTH_MSG = 'You have successfully updated your Health Information!';
export const EDIT_HINT_MSG = 'You have successfully updated your hint question and answer!';
export const VERIFY_CODE_EXPIRE_MSG = 'Your verification code has expired. Please request a new code.';
export const COMM_ERR_MSG =
  "We're currently experiencing technical difficulties. Please try again later, or call " +
  "<a href='te:18887721722'>1-888-772-1722 </a> for immediate assistance.";
export const CODE_MISMATCH_ERR_MSG = 'The access code you entered does not match our records. Please try again.';
export const PASSWORD_CRITERIA_ERR_MSG = "Your password didn't match the minimum criteria listed below.Please try again";
export const VERIFICATION_CODE_SENT_MSG = 'Verification code sent!.';
export const VERIFICATION_CODE_RESENT_MSG = 'Verification code resent! You may need to check your spam folder.';
export const VERIFIED_EMAIL_MSG = 'Verified your email successfully.';
export const VERIFIED_PHONE_MSG = 'Verified your mobile number successfully.';
export const PASSWORD_CHANGED_MSG = 'Success! Your password has been changed!';
export const USER_TYPE_MEDICATE = 'medicare';
export const COMM_CHANNEL_TYPE_MOBILE = 'MOBILE';
export const COMM_CHANNEL_TYPE_EMAIL = 'EMAIL';
export const ERROR_CODE_VERIFY_CODE_EXP = '-1';
export const ERROR_CODE_COMM_ERR = '-2';
export const ERROR_CODE_VERIFY_CODE_MISMATCH = '-4';
export const SUCCESS_RESULT = '0';

export const REQUIRED_CATEGORIES = ['Documents_Plan'];
export const TOOLTIP_DESCRIPTIONS = [
  'Explanation of Benefits, Summary of Health Plan Payments, Evidence of Coverage, Tax Documents, Plan Benefits and Updates, Mandated Notices.' +
    '\n\n Some communications are only available in certain channels.',
  'Routine Care Reminders, Helpful Wellness Tips, Relevant Health Condition-Related Information, Exclusive Member Perks and More.' +
    '\n\n Some communications are only available in certain channels.',
  'Important Company Updates, Industry Awards, Recognition, and More.\n\n Some communications are only available in certain channels.'
];
export const EMAIL_NOT_VERIFIED_LABEL =
  'After saving your preferences you will be asked verify your email address ' + 'or mobile number in order to receive communications.';
export const ERROR_TECHNICAL_MSG =
  "We're sorry. We are experiencing technical difficulties. " +
  'Please try again later, or if this is urgent, please contact customer care.';

export const EMAIL_PHONE_NOT_AVAILABLE = 'Before we can save your preferences, you must enter your email address or mobile number.';

export const EMAIL_NOT_DELIVERABLE_MESSAGE =
  'There is a problem with the email address you provided. To receive emails, you will need' +
  ' to verify your email address after saving your preferences.';

export const SMS_NOT_DELIVERABLE_MESSAGE =
  'There is a problem with the mobile number you provided. To receive text messages, you will ' +
  'need to verify this mobile number after saving your preferences.';

export const ADDRESS_MESSAGES = {
  required: 'You must enter a valid mailing address.',
  invalidCharacters: 'You must enter a valid mailing address.'
};

export const CITY_MESSAGES = {
  required: 'You must enter the city.',
  invalidCharacters: 'You must enter a valid city.'
};
export const ZIP_MESSAGES = {
  required: 'You must enter your ZIP code.',
  minlength: 'You must enter a valid ZIP code.'
};

export const MOBILE_MESSAGES = {
  required: 'You must enter a valid mobile number.',
  invalidNumber: 'You must enter a valid mobile number.',
  invalidMobile: 'You must enter a valid mobile number.'
};

export const EMAIL_MESSAGES = {
  required: 'You must enter a valid email  address.',
  invalidEmail: 'You must enter a valid email  address .'
};

export const ALERT_MSG = {
  emailVerifyText:
    'After saving your preferences you will be asked verify your email address ' + 'or mobile number in order to receive communications.',
  success: 'Thank you. Your selections have been saved.',
  error:
    "We're sorry. We are experiencing technical difficulties. Please try again later, or if this is urgent, " +
    'please contact customer care.'
};

export const CHANNEL_IDS = {
  EMAIL: 'EMAIL',
  SOLICIT: 'SOLICIT',
  SMS: 'SMS'
};

export const UPDATE_TYPE = {
  PHONE: 'phone',
  EMAIL: 'email'
};

export const NON_DIGIT_REGEX = /\D/g;

export const MOBILE_NUMBER_ERROR_MSGS_SUFFIX = {
  WITH_MOBILE_PREF: ' Please enter a valid mobile number or uncheck the Text option.',
  WITHOUT_MOBILE_PREF: ' Would you like to continue without signing up to receive text messages?  <a id="callback">Yes, Continue</a>'
};

export const INVALID_PHONE_ERROR_CODES = [-90329, -90333, -90339, -93122, -93123];

export const DEFAULT_PHONE_NUM = '0000000000';

export const VALID_UPDATE_TYPES = ['A', 'U'];
