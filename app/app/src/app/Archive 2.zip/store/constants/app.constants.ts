import { v4 as uuid } from 'uuid';


export const DEFAULT_FITNESS_STATE = {
  maskedSubscriberEmail: '',
  benefits: [],
  memberEmail: '',
  userSuffix: null,
  selectedBenefit: null,
  coreBenefit: null,
  selectedReimbursement: null,
  confirmationNumber: null,
  base64Photos: [],
  blobPhotos: [],
  notEligible: false,
  disablePhotoSubmit: false,
  currentType: null,
};

export const DEFAULT_LOGIN_STATE = {
  username: null,
  rememberMe: true,
  showPassword: false,
  bioData: null,
};

export const DEFAULT_REGISTER_STATE = {
  fromRegistration: false,
  onVerifyScreen: false,
  error: null,
};

export const DEFAULT_DEPENDENTS_STATE = {
  dependents: null,
};

export const DEFAULT_DEDUCTIBLES_STATE = {
  hasFamily: null,
  subscriberHasFamily: null,
  hasFirstDollar: false,
  hasMedical: false,
  hasDental: false,
  hasVision: false,
  coBundled: false,
  members: null,
  currentMember: null,
  memberName: null,
  subscriberName: null,
  deductibles: null,
  familyDeductibles: null,
  isLoading: false,
  currentType: 'MEDICAL',
  isGotError: false
};

export const DEFAULT_TAX_FORM_STATE = {
  taxforms: null,
};

export const DEFAULT_PREFERENCES_STATE = {
  prefResponses: null,
  preferences: null,
  programGroups: null,
  paperlessPromoFlag: null,
  showModal: false,
  updatePreferenceInfo: null,
  prefCID: null,
  updatePreferenceSuccess: false,
  updatePreferenceFailure: false,
  isPlanDocumentsSelected: false,
  isHealthBenefitsSelected: false,
  isFromModal: false,
  lastPrefUpdateType: 'A',
  lastPrefModifiedDate: null,
  isUserChannelBounced: '',
  fetchedPreferences: null,
  newPreferences: null,
  showRELModal: false
};

export const DEFAULT_APP_STATE = {
  showLoader: false,
  authToken: null,
  useridin: null,
  regType: null,
  mleIndicator: null,
  mleEligibility: null,
  hccsFlag: null,
  userState: null,
  dependentsList: null,
  userType: null,
  basicMemInfo: null,
  drupalConsent: null,
  cryptoTokens: null,
  memAuthInfo: null,
  rtmsMode: false,
  postLoginInfo: null,
  firstTimeLogin: true,
  hasNoAltAdd: null,
  sessionId: uuid(),
  getConsent: null,
  getConsentLogin: null,
  route: null,
  memProfile: null,
  commstatus: null,
  memberInfo: null,
  financialInfo: [],
  isLoadingFinancial: true,
  hasMedicalAccounts: false,
  isSearchEnabled: false,
  searchableCPCs: [],
  packageName: '',
  localTimezone: '',
  selectedPlan: null,
  getPlansList: [],
  stopWelcomeVideoPlay: false
};

export const CLEARED_APP_STATE = {
  cryptoTokens: null,
  authToken: null,
  memAuthInfo: null,
  sessionId: null,
  useridin: null,
  postLoginInfo: null,
  mleIndicator: null,
  basicMemInfo: null,
  regType: null,
  userType: null,
  dependentsList: null,
  firstTimeLogin: false,
  hccsFlag: null,
  rtmsMode: null,
  userState: null,
  mleEligibility: null,
  showLoader: false,
  route: null,
  fromRegistration: false,
  getConsent: null,
  memProfile: null,
  hasNoAltAdd: null,
  getConsentLogin: null,
  memberInfo: null,
  isSearchEnabled: false,
  searchableCPCs: [],
};

export const DEFAULT_SEARCH_STATE = {
  keyword: null,
  searchResults: null,
  pagedItems: null,
  isSearchOnly: true,
  currentFilteredProductType: 'All Benefits',
  currentPage: 1,
  pager: {},
  productTypes: [],
};

export const DEFAULT_PROFILE_STATE = {
  teleHealthDetails : {
    teleHealthEligible: false,
    disclaimerFlag: false,
    wellConnectionIndicatorFlag: false,
    loaded: false
  },
}

export const DEFAULT_TELEHEALTH_STATE = {
  consumerAuthKey: '',
  isAuthenticated: false,
  disclaimer: '',
  practices: [],
  providers: [],
  questionnaire: [],
  visitInfo: {},
  dependents: [],
  pharmacies: [],
  shippingAddressRequired: true,
  providerSearchKeyword: '',
  states: [],
  enrollmentStates: [],
  allergies: [],
  medications: [],
  conditions: [],
  isCouponCodeApplied: false,
  couponCode: '',
  patientsAheadCount: 0,
  isTransfer: false,
  isTransferCompleted: false,
  consumerDocuments: [],
  visitContext: {
    callbackNumber : '',
    consumerSourceId: '',
    guestEmails: [],
    legalText: [],
    topics: [],
    otherTopicText: '',
    triageQuestions: [],
    shouldCollectAllergies: false,
    shouldCollectConditions: false,
    shouldCollectMedications: false,
    shouldCollectVitals: false,
    shouldShowTriageQuestions: false,
    mayShareHealthHistory: false,
    isFirstAvailableVisit: false,
    providerName: ''
  },
  stateCode: undefined,
  isMinor: false,
  isNullified: false,
  appointments: [],
  message: undefined,
  deepLinkUrl: '',
  topics: [],
  contacts: [],
  isScheduleFlow : false
};

export const DEFAULT_MEDLOOKUP_STATE = {
  medlookup: null
};

export const IPA_PAGES = [
  '/myClaims',
  '/myPlan',
  '/loading',
  '/myClaims',
  '/my-medications',
  '/brandMyPlan',
  '/careCost',
  '/my-doctor',
  '/brand-my-medication',
  '/deductibles'
]

export enum BANNER_TYPE {
  DEFAULT = '',
  MEDICARE = 'medicare'
}
