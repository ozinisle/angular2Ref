import { getActionTypeFromInstance } from '@ngxs/store';
import { ClearState } from '../actions/app.actions';
import {
  CLEARED_APP_STATE,
  DEFAULT_APP_STATE,
  DEFAULT_DEDUCTIBLES_STATE,
  DEFAULT_DEPENDENTS_STATE,
  DEFAULT_FITNESS_STATE,
  DEFAULT_LOGIN_STATE,
  DEFAULT_PREFERENCES_STATE,
  DEFAULT_PROFILE_STATE,
  DEFAULT_REGISTER_STATE,
  DEFAULT_SEARCH_STATE,
  DEFAULT_TAX_FORM_STATE,
  DEFAULT_TELEHEALTH_STATE
} from '../constants/app.constants';

export function logoutPlugin(state, action, next) {
  if (getActionTypeFromInstance(action) === ClearState.type) {
    const shouldClearAuth = action?.clearAuth;

    state = {
      fitness: DEFAULT_FITNESS_STATE,
      app: shouldClearAuth ? CLEARED_APP_STATE : { ...DEFAULT_APP_STATE, ...{ firstTimeLogin: state.app.firstTimeLogin } },
      deductible: DEFAULT_DEDUCTIBLES_STATE,
      dependent: DEFAULT_DEPENDENTS_STATE,
      taxforms: DEFAULT_TAX_FORM_STATE,
      register: DEFAULT_REGISTER_STATE,
      preference: DEFAULT_PREFERENCES_STATE,
      profile: DEFAULT_PROFILE_STATE,
      search: DEFAULT_SEARCH_STATE,
      telehealth: DEFAULT_TELEHEALTH_STATE,
      login: shouldClearAuth
        ? DEFAULT_LOGIN_STATE
        : state.login.rememberMe
        ? state.login
        : state.login.bioData
        ? { ...DEFAULT_LOGIN_STATE, bioData: state.login.bioData, rememberMe: false }
        : { ...DEFAULT_LOGIN_STATE, rememberMe: false }
    };
  }

  return next(state, action);
}
