﻿import { Component, NgZone, OnDestroy } from '@angular/core';
import { NavigationStart, Router } from '@angular/router';
import { ScopeNamesEnum } from '@app/enums/scope-names.enum';
import { AboutMeModalComponent } from '@app/modals/about-me-modal/about-me-modal.component';
import { ConsentModalComponent } from '@app/modals/consent-modal/consent-modal.component';
import { PreferenceModalComponent } from '@app/modals/preference-modal/preference-modal.component';
import { LearnToLiveModel } from '@app/models/learn-to-live.model';
import { GetProgramGroups } from '@app/store/actions/preference.action';
import { ShowAboutMeModal, ShowConsentModal, ShowModal, VerifyEmailModal } from '@app/store/actions/profile.action';
import { PreferenceSelectors } from '@app/store/selectors/preference.selectors';
import { GlobalUtils } from '@app/utils/global.utils';
import { Plugins } from '@capacitor/core';
import { environment } from '@environments/environment';
import { Deeplinks } from '@ionic-native/deeplinks/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { AlertController, MenuController, ModalController, NavController, Platform, PopoverController } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Actions, ofActionSuccessful, Select, Store } from '@ngxs/store';
import { format } from 'date-fns-tz';
import { forkJoin, Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { MYBLUE } from './app.constants';
import { VerifyEmailEbillingComponent } from './modals/verify-email-ebilling/verify-email-ebilling.component';
import { AuthToken } from './models/auth-token.model';
import { PharmacyLinkType } from './models/pharmacy-link-type';
import { PostLoginModel } from './models/post-login.model';
import { SsoService } from './pages/sso/sso.service';
import { AnalyticsService } from './services/analytics.service';
import { DynamicScriptLoaderService } from './services/dynamic-script-loader.service';
import { HeaderService } from './services/header.service';
import { HomeService } from './services/home.service';
import { IabService } from './services/iab.service';
import { PlanConfigService } from './services/plan-config/plan-config-service';
import { SwrveEventNames, SwrveService } from './services/swrve.service';
import { AppVersionInfo, CheckForDefaultPlanSwitch, ClearState, GetLocalTimeZone, Logout, SetDeepLink, ShowIdleSessionModal } from './store/actions/app.actions';
import { AppSelectors } from './store/selectors/app.selectors';
const { SplashScreen } = Plugins;
const { App } = Plugins;

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnDestroy {
  @Select(AppSelectors.getAuthToken) authToken$: Observable<AuthToken>;
  @SelectSnapshot(AppSelectors.getScopeName) scopename: string;
  @SelectSnapshot(AppSelectors.getPostLoginInfo) postLoginInfo: PostLoginModel;
  @SelectSnapshot(PreferenceSelectors.getPrefResonses) responses: any;
  @SelectSnapshot(AppSelectors.getSessionId) sessionId: string;
  @SelectSnapshot(AppSelectors.getUserID) useridin: string;
  @SelectSnapshot(AppSelectors.getLearnToLive) learnToLive: LearnToLiveModel;
  @SelectSnapshot(AppSelectors.getMemAuthInfo) memAuthInfo: any;
  @SelectSnapshot(AppSelectors.getShowEmailVerifyMoalFlag) showEmailVerifyModal: boolean;

  destroy$: Subject<boolean> = new Subject<boolean>();

  showLearnToLive = GlobalUtils.showLearnToLive;

  homeNavigationApiResponse: any;
  isAuthenticatedUser = false;
  memberFirstName: string;
  submenu: any = {};
  estGreeting = '';
  callNurseLineNumber = '';
  isFitnessEnabled = false;
  authToken: AuthToken;
  requestEligible = false;
  AMWELL_DEEPLINK_PREFIX = '//americanwell.com'
  enableLiveChat: boolean = environment.enableLiveChat

  constructor(
    private menu: MenuController,
    private store: Store,
    private platform: Platform,
    private statusBar: StatusBar,
    private analyticsService: AnalyticsService,
    private dynamicScriptLoaderService: DynamicScriptLoaderService,
    private deepLinks: Deeplinks,
    private swrveService: SwrveService,
    private swrveEventNames: SwrveEventNames,
    private iabService: IabService,
    private ssoService: SsoService,
    private headerService: HeaderService,
    private homeService: HomeService,
    private ngZone: NgZone,
    private navCtrl: NavController,
    private router: Router,
    private actions$: Actions,
    private modalController: ModalController,
    private popoverController: PopoverController,
    private alertController: AlertController,
    private planConfigService: PlanConfigService
  ) {
    this.dynamicScriptLoaderService
      .load('adobe-analytics')
      .then(data => {
        this.analyticsService.initializeAdobe((window as any)._satellite, this.authToken);
      })
      .catch(error => MYBLUE.error('Analytics Service BCBSMA: adobe-analytics library load failed' + error));

    this.initializeApp();
    this.hideAllLayovers();

    const planConfig$ = this.planConfigService.getCurrentPlanConfig$();

    forkJoin([planConfig$, this.actions$.pipe(ofActionSuccessful(ShowModal), takeUntil(this.destroy$))]).subscribe(([planConfig, action]) => {
      if (this.authToken) {
          if (planConfig?.elligibility.isDigitalFirstCDH) {
            setTimeout(() => {
              if (sessionStorage.getItem('isEmailSelected') === 'unSelected' && sessionStorage.getItem('isSmsSelected') === 'unSelected') {
                this.showPreferenceModal();
              }
            }, 1000)
          } else {
            this.showPreferenceModal();
          }
          if (sessionStorage.getItem('fromContactInfo') && sessionStorage.getItem('fromContactInfo') === 'true' && planConfig?.elligibility.isDigitalFirstCDH) {
            sessionStorage.removeItem('fromContactInfo');
            this.showPreferenceModal();
          }
      }
    });

    this.actions$.pipe(ofActionSuccessful(VerifyEmailModal), takeUntil(this.destroy$)).subscribe(() => {
      if (this.authToken) {
        this.showVerifyEmailModal();
      }
    });

    this.actions$.pipe(ofActionSuccessful(ShowConsentModal), takeUntil(this.destroy$)).subscribe(() => {
      this.store.dispatch(new GetProgramGroups());
      this.showConsentModal();
    });

    this.actions$.pipe(ofActionSuccessful(ShowAboutMeModal), takeUntil(this.destroy$)).subscribe(() => {
      if (this.authToken) {
        this.showAboutMeModal();
      }
    });

    const UNAUTHENTICATED_ROUTES = [
      '/',
      '/login',
      '/confidentiality',
      '/terms-of-use',
      '/contact-us',
      '/whatsnew',
      '/register/register-detail',
      '/home',
      '/register/memberinfo',
      '/register/updatessn',
      '/register/securityanswers',
      '/register/updatessn',
      '/register/success',
      '/brand-home',
      '/brandMyPlan',
      '/brand-support',
      '/careCost',
      '/guest-visit',
      '/guest-visit',
      '/guest-visit/waiting-room',
      '/guest-visit/visit-exception',
      '/guest-visit/thank-you',
    ];

    const ANV_ROUTES = ['/register/verification', '/register/verification', '/register/success', '/'];
    this.router.events.pipe(takeUntil(this.destroy$)).subscribe((event: NavigationStart) => {
      if (event instanceof NavigationStart) {
        MYBLUE.warn('::: NavigationStart Event ::: ' + JSON.stringify(event.url, null, 2));
        if (this.scopename === 'REGISTERED-AND-VERIFIED' && UNAUTHENTICATED_ROUTES.indexOf(event.url) === -1) {
          this.router.navigate(['/register/register-detail']);
        } else if (this.scopename === 'AUTHENTICATED-NOT-VERIFIED' && ANV_ROUTES.indexOf(event.url) === -1) {
          this.router.navigate(['/register/verification']);
        } else if (event.url === '/first-time' && event.navigationTrigger === 'popstate') {
          this.router.navigate(['/home']);
        } else {
          this.store.dispatch(new CheckForDefaultPlanSwitch(event.url));
        }
        this.menu.close();
      }
    });

    this.isFitnessEnabled = environment.fitnessBenefits;

    this.authToken$.pipe(takeUntil(this.destroy$)).subscribe(token => {
      this.memberFirstName = '';

      if (token) {
        this.authToken = token;
        sessionStorage['authToken'] = JSON.stringify(this.authToken);
        this.isAuthenticatedUser = this.authToken.scopename === ScopeNamesEnum.ANV || this.authToken.scopename === ScopeNamesEnum.AV;

        if (this.authToken.unreadMsgCount) {
          this.headerService.unReadMsgCount = this.authToken.unreadMsgCount.toString();
        }

        this.requestEligible =
          this.authToken.HasActivePlan?.toLowerCase() === 'true' && this.authToken.userType?.toLowerCase() !== 'medicare';
      }
    });
    setTimeout(() => {
      this.handleRedirection();
    }, 1000);
  }

  initializeApp() {
    this.platform.ready().then(async () => {
      if (this.platform.is('cordova')) {
        App.addListener('appUrlOpen', (data: any) => {
          this.ngZone.run(() => {
            //Console log needed for troubleshooting deeplinks
            MYBLUE.log("appUrlOpen " + JSON.stringify(data));
            //Needed delay as startup deeplinks are gettimg routed to home page
            if (data.url.indexOf(this.AMWELL_DEEPLINK_PREFIX) !== -1) {
              setTimeout(() => this.router.navigate(['guest-visit'], { queryParams: { launchUrl: data.url } }), 1000);
            } else {
              const deepLinkURL = data.url.split(environment.urlScheme).pop();
              if (deepLinkURL) {
                setTimeout(() => this.router.navigateByUrl(deepLinkURL), 1000);
              }
            }
          });
        });
        this.statusBar.styleDefault();
        this.statusBar.backgroundColorByHexString('#1866a3');
        SplashScreen.hide();
        this.store.dispatch(new ClearState(true, true));
      }

      this.homeService.setSessionLinks();
      this.setGreeting();
      this.store.dispatch([new GetLocalTimeZone(), new AppVersionInfo()]);
    });
  }

  handleRedirection() {
    if (this.platform.is('desktop') && !this.isAuthenticatedUser) {
      this.router.navigate(['/login']);
    }
  }

  hideAllLayovers() {
    this.actions$.pipe(ofActionSuccessful(ShowIdleSessionModal), takeUntil(this.destroy$)).subscribe(async () => {
      const topModal = await this.modalController.getTop();
      if (topModal) {
        await topModal.dismiss();
      }

      const topPopover = await this.popoverController.getTop();
      if (topPopover) {
        await topPopover.dismiss();
      }

      this.idleAlert();
    });
  }

  async idleAlert() {
    this.store.dispatch(new Logout());
    const alert = await this.alertController.create({
      backdropDismiss: false,
      message: 'You are now logged out after 10 minutes of inactivity',
      buttons: [
        {
          text: 'Home',
          cssClass: 'secondary',
          handler: () => {
            alert.dismiss();
            this.router.navigateByUrl('/home');
          }
        },
        {
          text: 'Login Again',
          cssClass: 'secondary',
          handler: () => {
            alert.dismiss();
            this.router.navigateByUrl('/login');
          }
        }
      ]
    });
    await alert.present();
  }

  setGreeting() {
    const hour = Number(format(new Date(), 'h', { timeZone: 'America/New_York' }));
    const MORNING = 12;
    const AFTERNOON = 17;
    if (hour < MORNING) {
      this.estGreeting = 'Good morning';
    } else if (hour >= MORNING && hour < AFTERNOON) {
      this.estGreeting = 'Good afternoon';
    } else {
      this.estGreeting = 'Good evening';
    }
  }

  checkDeeplinks() {
    this.deepLinks
      .route({
        '/home': 'home',
        '/register': 'register',
        '/registerdetail': 'register/register-detail',
        '/login': 'login',
        '/whatsnew': 'whatsnew',
        '/myplan': 'myPlan',
        '/mydoctor': 'my-doctor',
        '/myclaims': 'myClaims',
        '/myinbox': 'myInbox',
        '/my-financial': 'my-financial',
        '/myprofile': 'myprofile',
        '/mycards': 'mycards',
        '/account': 'account',
        '/request-estimate': 'request-estimate',
        '/mydedco-app': 'deductibles',
        '/med-lookup-tool': 'med-lookup-tool',
        '/fad': 'fad',
        '/fitness-and-weightloss': 'fitness-and-weightloss',
        '/amwell_messages': 'amwell_messages',
        '/amwell_calendar': 'amwell_calendar'
      })
      .subscribe(
        match => {
          this.ngZone.run(() => {
            this.store.dispatch(new SetDeepLink(match.$route));
            this.navCtrl.navigateForward(match.$route);
          });
        },
        nomatch => {
          MYBLUE.error("Got a deeplink that didn't match", nomatch);
          this.store.dispatch(new SetDeepLink(null));
        }
      );
  }

  logOut() {
    sessionStorage.clear();
    this.store.dispatch(new Logout());
    this.menu.close();
  }

  goToLogin() {
    this.navCtrl.navigateRoot('login');
  }

  toggleSubmenu(menu: string) {
    if (!this.submenu[menu]) {
      this.submenu[menu] = false;
    }
    this.submenu[menu] = !this.submenu[menu];
    this.homeService.getHomeNavigationResponse().subscribe(response => {
      this.homeNavigationApiResponse = Array.isArray(response) ? response[0] : response;
      if (this.homeNavigationApiResponse) {
        this.callNurseLineNumber = this.homeNavigationApiResponse.APPTextUrl2 || '';
      }
    });
  }

  closeMenu() {
    this.menu.close();
  }

  checkSapphireDigitalUser(postLoginInfo: any = {}) {
    return this.postLoginInfo.hasCI || this.postLoginInfo.hasSS || this.postLoginInfo.hasSSO;
  }

  findADoctorClicked() {
    const isSapphireDigitalUser = this.postLoginInfo ? this.checkSapphireDigitalUser(this.postLoginInfo) : false;
    this.swrveService.sendAppMessage(this.swrveEventNames.appClickMenuFindaDoctor);
    if (isSapphireDigitalUser) {
      this.ssoService.openSSO('fad');
    } else {
      this.navCtrl.navigateForward('fad');
    }
  }

  wellConnectionClicked() {
    const url = 'https://myblue.bluecrossma.com/health-plan/well-connection';
    this.iabService.create(url);
  }

  contactUsClicked() {
    this.swrveService.sendAppMessage(this.swrveEventNames.appClickMenuContactUs);
  }

  openUrl() {
    this.iabService.create('http://20181129medication.test-bluecrossma.acsitefactory.com/?referer=mobile-app');
  }

  myInboxClicked() {
    this.swrveService.sendAppMessage(this.swrveEventNames.appClickMenuMyInbox);
  }

  navigate(item: PharmacyLinkType) {
    if (item.isSSO && this.isAuthenticatedUser) {
      this.ssoService.openSSO(item.ssoType);
    } else if (item.isExternal) {
      this.iabService.create(item.url);
    } else {
      this.navCtrl.navigateForward(item.url);
    }
  }

  goToLearnToLive() {
    this.ssoService.openSSO('Learn2Live');
  }

  async showPreferenceModal() {
    const modal = await this.modalController.create({
      component: PreferenceModalComponent,
      cssClass: 'preference-center-modal',
      keyboardClose: false,
      showBackdrop: true,
      backdropDismiss: false
    });
    await modal.present();
  }

  async showVerifyEmailModal() {
    const modal = await this.modalController.create({
      component: VerifyEmailEbillingComponent,
      cssClass: 'email-ebilling-modal',
      keyboardClose: false,
      showBackdrop: true,
      backdropDismiss: false
    });
    await modal.present();
  }

  async showConsentModal() {
    const modal = await this.modalController.create({
      component: ConsentModalComponent,
      cssClass: 'preference-center-modal',
      keyboardClose: false,
      showBackdrop: true,
      backdropDismiss: false
    });
    await modal.present();
  }

  async showAboutMeModal() {
    const modal = await this.modalController.create({
      component: AboutMeModalComponent,
      cssClass: 'rel-modal',
      keyboardClose: false,
      showBackdrop: true,
      backdropDismiss: false
    });
    await modal.present();
  }

  ngOnDestroy(): void {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }
}
