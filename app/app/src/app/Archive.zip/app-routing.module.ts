import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

export const rootRoutes: Routes = [
  {
    path: '',
    loadChildren: () => import('./pages/tabs/tabs.module').then(m => m.TabsPageModule)
  },
  {
    path: 'first-time',
    loadChildren: () => import('./pages/first-time/first-time.module').then(m => m.FirstTimeModule)
  }
];

@NgModule({
  declarations: [],
  imports: [RouterModule.forRoot(rootRoutes )],
  exports: [RouterModule]
})
export class AppRoutingModule {}
