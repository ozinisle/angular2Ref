export const MYBLUE = {
    log: console.log,
    warn: console.warn,
    error: console.error,
    table: console.table
}
