import { Finanical, TransactionInfo } from '@app/models/finanical.model';
import { LineChartOptions } from '@app/models/financial-chart/financial-chart.model';
// import { format } from 'date-fns';

export const MAX_TRANSACTIONS = 5;

export const transformFinanceChartData = (response: any): Finanical[] => {
  const finanicalDataList = [];

  response.heqAccounts?.reimbursementAccountInfo?.forEach(accountInfo =>
    finanicalDataList.push(transformChartData(accountInfo, true, false))
  );
  response.heqAccounts?.savingsAccountInfo?.forEach(accountInfo => finanicalDataList.push(transformChartData(accountInfo, true, true)));
  response.algsAccounts?.reimbursementAccountInfo?.forEach(accountInfo =>
    finanicalDataList.push(transformChartData(accountInfo, false, false))
  );
  response.algsAccounts?.savingsAccountInfo?.forEach(accountInfo => finanicalDataList.push(transformChartData(accountInfo, false, true)));

  return finanicalDataList;
};

const extractTransactions = (transactions: any[]) => {
  const noTransactions = new TransactionInfo();
  noTransactions.description = "No Recent Transaction";
  if (!transactions || !transactions.length) {
    return [];
  }
  if (transactions.length < MAX_TRANSACTIONS) {
    return transactions.concat(Array(MAX_TRANSACTIONS - transactions.length).fill(noTransactions));
  }
  return transactions;
}

export const transformChartData = (finanicalInfo: any, isHeqAccount: boolean, isSavingsAccount: boolean): Finanical => {
  const finanicalData = new Finanical();
  finanicalData.acountNumber = finanicalInfo.acountNumber
    ? finanicalInfo.acountNumber.substr(0, finanicalInfo.acountNumber.length - 4).replace(/[0-9]/g, '*') +
      finanicalInfo.acountNumber.substr(-4)
    : '';

  finanicalData.type = finanicalInfo.accountType || finanicalInfo.type || '';
  finanicalData.isSavingsAccount = isSavingsAccount;
  finanicalData.isHeqAccount = isHeqAccount;
   
  // the commented code below is not required because the dates are in the expected format 'yyyy-MM-dd'.
  // if (finanicalInfo.planStartDate) {
  //   finanicalData.planStartDate = finanicalInfo.planStartDate, 'yyyy-MM-dd';
  //   finanicalData.planEndDate = finanicalInfo.planEndDate, 'yyyy-MM-dd';
  // }

  if (finanicalInfo.planStartDate) {
    finanicalData.planStartDate = finanicalInfo.planStartDate;
    finanicalData.planEndDate = finanicalInfo.planEndDate;
  }

  finanicalData.chartOptions = getChartOptions(finanicalInfo, isSavingsAccount);
  finanicalData.transactions = isHeqAccount ? extractTransactions(finanicalInfo.transactions) : [];
  return finanicalData;
};

export const getChartOptions = (finanicalInfo, isSavingsAccount) => {
  return new LineChartOptions()
    .setHeaderText('Annual Election')
    .setHeaderText1(finanicalInfo.accountName)
    .setTotalValue(finanicalInfo.balanceAvailable)
    .setChartValue(isSavingsAccount ? finanicalInfo.investments : finanicalInfo.spent)
    .setAnnualElection(parseFloat(finanicalInfo.electionAmount))
    .setChartColor('#3DA148')
    .setChartBackgroundColor('#FFFFFF')
    .setChartOption1Text('Available')
    .setChartOption2Text(isSavingsAccount ? 'Investment' : 'Spent');
};
