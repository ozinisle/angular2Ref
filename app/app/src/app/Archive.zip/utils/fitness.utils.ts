import { AbstractControl, ValidatorFn } from '@angular/forms';
import { FitnessRequestModel } from '../pages/fwb/models/fitness-request';

export const buildSubmissionRequest = (form, userId, currentState, benefitsInfo) => {
  const reqMember = JSON.parse(JSON.stringify(form));
  reqMember.member.groupNumber = currentState.groupNumber;
  const benefitByYear = benefitsInfo.benefits.find(benefit => benefit.year === currentState.selectedBenefit.year);
  const request = {
    useridin: userId,
    claim: {
      year: currentState.selectedBenefit.year,
      type: currentState.selectedReimbursement.collateralName.toUpperCase(),
      forMember: reqMember.member,
      isEHB: currentState.selectedReimbursement.isEHB,
      totalAmount: form.totalAmount,
      collateralName: currentState.selectedReimbursement.collateralName === 'Fitness'
      ? (benefitByYear && benefitByYear.fitness ? benefitByYear.fitness.collateralName : "")
      : (benefitByYear && benefitByYear.weightloss ? benefitByYear.weightloss.collateralName : ""),
    },
    programInformation: {
      programName: form.programName,
      address: form.address,
      phoneNumber: form.phone.replace(/\D/g, ''),
      state: form.state,
      zip: form.zipcode
    }
  } as FitnessRequestModel;

  if (form.category) {
    request.claim['category'] = form.category;
  } else if (currentState.selectedReimbursement.isEHB === true) {
    request.claim.category = 'MONTHLY';
  }

  if (benefitByYear.cancelDate) {
    request.claim.planCancelDate = benefitByYear.cancelDate;
  }

  if (form.annualFeeAmount) {
    request.claim.annualFeeAmount = form.annualFeeAmount;
  } else {
    request.claim.annualFeeAmount = 0;
  }

  if (form.unitAmount) {
    request.claim.unitAmount = form.unitAmount;
  }

  if (form.subscriberAlternateEmail) {
    request.claim.subscriberAlternateEmail = form.subscriberAlternateEmail;
  }
  if (form.additionalEmail) {
    request.claim.memberAlternateEmail = form.additionalEmail;
  }

  return request;
};

export function amountWithinRange(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: boolean } | null => {
    if (control.value < 1 || control.value > 1000) {
      return { amount: true };
    }
    return null;
  };
}

export function amountWithinRangeOptional(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: boolean } | null => {
    if (control.value == null || control.value === 0) {
      return null;
    }
    if (control.value < 1 || control.value > 1000) {
      return { amount: true };
    }
    return null;
  };
}
