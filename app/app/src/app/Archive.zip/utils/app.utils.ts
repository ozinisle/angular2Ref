import * as crypto from 'crypto-js';
import { format } from 'date-fns-tz';

export const getRTMSMode = () => {
  const hour = Number(format(new Date(), 'H', { timeZone: 'America/New_York' }));
  const minute = Number(format(new Date(), 'm', { timeZone: 'America/New_York' }));
  const currentTime = parseFloat(parseFloat(`${hour}.${minute}`).toFixed(2));
  const result = currentTime >= 6 && currentTime <= 20;

  return result;
};

export const encryptPayload = (request: object, cryptoToken: any, isKey2NotReq = false) => {
  let message = '';
  let key1id = '';

  if (cryptoToken) {
    if (!isKey2NotReq) {
      request = { ...request, key2id: cryptoToken.key2id };
    }
    const key = crypto.PBKDF2(cryptoToken.key1phrase, crypto.enc.Hex.parse(cryptoToken.key1salt), {
      keySize: 128 / 32,
      iterations: 10000
    });
    const encryptedMessage = crypto.AES.encrypt(JSON.stringify(request), key, { iv: crypto.enc.Hex.parse(cryptoToken.key1iv) });
    message = encryptedMessage.ciphertext.toString(crypto.enc.Base64);
    key1id = cryptoToken.key1id;

    return { message: message, key1id: key1id };
  }
};

export const decryptPayload = (message: string, cryptoToken: any) => {
  let unencryptedMessage = '';
  if (cryptoToken) {
    const key = crypto.PBKDF2(cryptoToken.key2phrase, crypto.enc.Hex.parse(cryptoToken.key2salt), {
      keySize: 128 / 32,
      iterations: 10000
    });

    const decryptedMessage = crypto.AES.decrypt(message, key, { iv: crypto.enc.Hex.parse(cryptoToken.key2iv) });
    unencryptedMessage = decryptedMessage.words.length ? JSON.parse(decryptedMessage.toString(crypto.enc.Utf8)) : JSON.parse('{}');
    return unencryptedMessage;
  }
};

export const getPharmacyLinkType = (text: string, url: string) => {
  let icon: [string, string];
  let isSSO = false;
  let isExternal = false;
  let ssoType = '';

  if (text.includes('Sign Up for PillPack')) {
    url = 'my-pillpack/landing';
    icon = ["fas", "hand-holding-box"];
  } else if (text === 'My Medications') {
    url = 'my-medications';
    icon = ["fas", "pills"];
  } else if (text.includes('Express Scripts') || text.includes('90-Day Mail Order Pharmacy')) {
    isSSO = true;
    ssoType = 'expressscripts';
    icon = ["fas", "shipping-timed"];
    if (text.includes('Express Scripts')) {
      icon = ["fas", "files-medical"];
    }
  } else if (text.includes('Medication Lookup Tool')) {
    icon = ["fas", "prescription-bottle-alt"];
    isExternal = true;
  } else if (text.includes('Manage Your PillPack Account')) {
    isSSO = true;
    ssoType = 'pillpack';
    icon = ["fas", "hand-holding-box"];
    isExternal = true;
  } else if (text.includes('Cost-Share Assistance Program')) {
    icon = ["fas", "hand-holding-usd"];
  }
  return { label: text, icon: icon, url: url, isSSO: isSSO, ssoType: ssoType, isPhone: false, isExternal: isExternal };
};
