import { NgModule } from '@angular/core';
import { MatNativeDateModule } from '@angular/material/core';
import { MatCalendar, MatDatepickerModule } from '@angular/material/datepicker';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatListModule } from '@angular/material/list';

@NgModule({
  imports: [MatExpansionModule, MatFormFieldModule, MatListModule, MatDatepickerModule, MatNativeDateModule],
  exports: [MatExpansionModule, MatFormFieldModule, MatListModule, MatDatepickerModule, MatCalendar, MatNativeDateModule]
})
export class MaterialModule {}
