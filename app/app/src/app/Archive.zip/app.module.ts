import { DatePipe, TitleCasePipe } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { APP_INITIALIZER, NgModule } from '@angular/core';
import { MAT_LABEL_GLOBAL_OPTIONS } from '@angular/material/core';
import { PreloadAllModules, RouteReuseStrategy, RouterModule } from '@angular/router';
import { AlertsModule } from '@app/components/alerts/alerts.module';
import { AppControlMessagesModule } from '@app/components/app-control-messages/app-control-messages.module';
import { ChatModule } from '@app/components/chat/chat.modules';
import { ServiceFailureModalModule } from '@app/components/service-failure-modal/service-failure-modal.module';
import { MaterialModule } from '@app/material.module';
import { AboutMeModalModule } from '@app/modals/about-me-modal/about-me-modal.module';
import { ConsentMeansModalModule } from '@app/modals/consent-means/consent-means.module';
import { PreferenceModalModule } from '@app/modals/preference-modal/preference-modal.module';
import { ResendcodeModalModule } from '@app/modals/resend-code/resend-code.module';
import { environmentService } from '@environments/environment';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { AppVersion } from '@ionic-native/app-version/ngx';
import { CallNumber } from '@ionic-native/call-number/ngx';
import { Camera } from '@ionic-native/camera/ngx';
import { Deeplinks } from '@ionic-native/deeplinks/ngx';
import { EmailComposer } from '@ionic-native/email-composer/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';
import { FileTransfer } from '@ionic-native/file-transfer/ngx';
import { File } from '@ionic-native/file/ngx';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { Keyboard } from '@ionic-native/keyboard/ngx';
import { LocalNotifications } from '@ionic-native/local-notifications/ngx';
import { LocationAccuracy } from '@ionic-native/location-accuracy/ngx';
import { NativeGeocoder } from '@ionic-native/native-geocoder/ngx';
import { SmsRetriever } from '@ionic-native/sms-retriever/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { IonicRouteStrategy } from '@ionic/angular';
import { NGXS_PLUGINS } from '@ngxs/store';
import { TextMaskModule } from 'angular2-text-mask';
import { NgxCurrencyModule } from 'ngx-currency';
import { AppRoutingModule, rootRoutes } from './app-routing.module';
import { AppComponent } from './app.component';
import { BreadcrumbModule } from './components/breadcrumbs/breadcrumbs.module';
import { CoreModule } from './core/core.module';
import { TokenInterceptorService } from './interceptors/http-request-interceptor';
import { HttpResponseInterceptor } from './interceptors/http-response.interceptor';
import { ConsentModalModule } from './modals/consent-modal/consent-modal.module';
import { IPAModalModule } from './modals/ipa-modal/ipa-modal.module';
import { ProgressModalModule } from './modals/progress-modal/progress-modal.module';
import { VerifyEmailEbillingModule } from './modals/verify-email-ebilling/verify-email-ebilling.module';
import { HomeResolver } from './pages/home/home.resolver';
import { MyDoctorsPcpModule } from './pages/my-doctors-pcp/mydoctors-pcp.module';
import { ProfileModalComponent } from './pages/my-pillpack/profile-modal/profile-modal.component';
import { JumpScreenComponent } from './pages/sso/jump-screen/jump-screen.component';
import { SsoResolver } from './pages/sso/sso.resolver';
import { SsoService } from './pages/sso/sso.service';
import { EnvironmentService } from './services/environment/environment.service';
import { InitService } from './services/init.service';
import { LogRocketService } from './services/logrocket.service';
import { PlanConfigService } from './services/plan-config/plan-config-service';
import { ProfileService } from './services/profile.service';
import { SwrveEventNames, SwrveService } from './services/swrve.service';
import { WelcomeKitService } from './services/welcome-kit.service';
import { SharedModule } from './shared/shared.module';
import { logoutPlugin } from './store/ngxs-plugins/app.plugins';

export function init_app(initService: InitService) {
  return () => initService.initConfig();
}

@NgModule({
  declarations: [AppComponent, JumpScreenComponent, ProfileModalComponent],
  exports: [RouterModule],
  imports: [
    CoreModule,
    SharedModule,
    AppRoutingModule,
    MaterialModule,
    RouterModule.forRoot(rootRoutes, { onSameUrlNavigation: 'reload', preloadingStrategy: PreloadAllModules }),
    TextMaskModule,
    ProgressModalModule,
    PreferenceModalModule,
    IPAModalModule,
    MyDoctorsPcpModule,
    ConsentMeansModalModule,
    ResendcodeModalModule,
    NgxCurrencyModule,
    AlertsModule,
    BreadcrumbModule,
    AppControlMessagesModule,
    ConsentModalModule,
    AboutMeModalModule,
    ServiceFailureModalModule,
    VerifyEmailEbillingModule,
    ChatModule,
  ],
  providers: [
    Camera,
    DatePipe,
    TitleCasePipe,
    SsoResolver,
    SsoService,
    StatusBar,
    SmsRetriever,
    CallNumber,
    InAppBrowser,
    InitService,
    HomeResolver,
    { provide: HTTP_INTERCEPTORS, useClass: HttpResponseInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: TokenInterceptorService, multi: true },
    { provide: NGXS_PLUGINS, useValue: logoutPlugin, multi: true },
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    { provide: MAT_LABEL_GLOBAL_OPTIONS, useValue: { float: 'always' } },
    {
      provide: APP_INITIALIZER,
      useFactory: init_app,
      deps: [InitService],
      multi: true,
    },
    FileTransfer,
    File,
    FileOpener,
    EmailComposer,
    SwrveService,
    SwrveEventNames,
    Deeplinks,
    LocalNotifications,
    AndroidPermissions,
    Geolocation,
    NativeGeocoder,
    LocationAccuracy,
    ProfileService,
    Keyboard,
    AppVersion,
    LogRocketService,
    WelcomeKitService,
    { provide: EnvironmentService, useValue: environmentService },
    PlanConfigService,
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
