import { Directive, OnChanges, ElementRef, Input, SimpleChanges } from '@angular/core';

// TODO: Dont need this, should be done with shadow parts
@Directive({
  selector: '[removeSelectArrow]'
})
export class RemoveSelectArrowDirective implements OnChanges {
  @Input() removeSelectArrow: any;
  constructor(private el: ElementRef) {}
  ngOnChanges(changes: SimpleChanges): void {
    const shadow = this.el.nativeElement.shadowRoot;
    let display = 'block';
    if (changes.removeSelectArrow && changes.removeSelectArrow.currentValue) {
      display = 'none';
    }
    if (shadow) {
      try {
        shadow.querySelector('.select-icon').style.display = display;
      } catch (e) {}
    }
  }
}
