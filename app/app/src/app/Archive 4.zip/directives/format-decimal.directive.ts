import { Directive, ElementRef, HostBinding, KeyValueDiffers, OnInit } from '@angular/core';
import { CurrencyMaskConfig, CurrencyMaskDirective as BaseCurrencyMaskDirective, CurrencyMaskInputMode } from 'ngx-currency';

@Directive({
  selector: '[appCurrencyMask]',
})
export class CurrencyMaskDirective extends BaseCurrencyMaskDirective implements OnInit {
  // Force numeric keyboards on devices
  @HostBinding('inputmode') inputMode = 'decimal';

  // Provide the default options
  optionsTemplate: CurrencyMaskConfig = {
    align: 'left',
    allowNegative: false,
    allowZero: false,
    decimal: '.',
    inputMode: CurrencyMaskInputMode.FINANCIAL,
    min: 0,
    nullable: false,
    precision: 2,
    prefix: '',
    suffix: '',
    thousands: '',
  };

  constructor(protected element: ElementRef, protected keyValue: KeyValueDiffers) {
    super(null, element, keyValue);
    this.updateNativeElement();
  }

  ngOnInit(): void {
    super.ngOnInit();
    this.updateInputHandler();
  }

  updateInputHandler(): void {
    // The model change event may not exist on the input handler so we need to provide a default
    if (typeof this.inputHandler.getOnModelChange() !== 'function') {
      this.inputHandler.setOnModelChange(() => void 0);
    }

    // The raw value must be converted to a string so we need to override the property descriptor
    interface Private { inputService: { inputManager: unknown } }
    const instance = (this.inputHandler as unknown as Private).inputService.inputManager;
    const descriptor = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(instance), 'rawValue');
    Object.defineProperty(instance, 'rawValue', {
      ...descriptor,
      get(): string {
        return `${descriptor.get.call(this)}`;
      },
    });
  }

  updateNativeElement(): void {
    // The input manager will try to access these properties on the input so we need to provide them
    Object.defineProperties(this.element.nativeElement, {
      maxLength: {
        configurable: true,
        get: (): number => {
          return this.element.nativeElement.maxlength  ?? -1;
        },
      },
      selectionStart: {
        configurable: true,
        get: (): number => {
          return this.element.nativeElement.firstChild.selectionStart;
        },
      },
      selectionEnd: {
        configurable: true,
        get: (): number => {
          return this.element.nativeElement.firstChild.selectionEnd;
        },
      },
      setSelectionRange: {
        configurable: true,
        value: (start: number, end: number, direction?: string): void => {
          return this.element.nativeElement.firstChild.setSelectionRange(start, end, direction);
        },
      },
    });
  }
}
