import { NgModule } from '@angular/core';
import { NumberOnlyDirective } from '@app/directives/number-only/number-only.directive';

@NgModule({
  declarations: [NumberOnlyDirective],
  exports: [NumberOnlyDirective]
})
export class NumberOnlyDirectiveModule {}
