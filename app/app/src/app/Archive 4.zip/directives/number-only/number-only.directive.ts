import { Directive, HostListener } from '@angular/core';
import { NgControl } from '@angular/forms';

@Directive({
  selector: '[appNumberOnly]'
})
export class NumberOnlyDirective {
  private el: NgControl;
  constructor(private ngControl: NgControl) {
    this.el = this.ngControl;
  }

  // Listen for the input event to also handle copy and paste.
  @HostListener('input', ['$event.target.value', '$event'])
  onInput(value: string) {
    this.el.control.patchValue(value.replace(/[^0-9]/g, ''));
  }
}
