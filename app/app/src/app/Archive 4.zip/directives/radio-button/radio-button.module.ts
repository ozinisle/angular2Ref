import { NgModule } from '@angular/core';
import { RadioButtonDirective } from './radio-button.directive';

@NgModule({
  declarations: [RadioButtonDirective],
  exports: [RadioButtonDirective]
})
export class RadioDirectiveModule {}
