import { Directive, ElementRef, Input, OnChanges, SimpleChanges } from '@angular/core';

@Directive({
  selector: '[wordwrap]'
})
export class WordWrapDirective implements OnChanges {
  @Input() wordwrap: any;

  constructor(private el: ElementRef) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.wordwrap && changes.wordwrap.currentValue) {
      setTimeout(() => {
        const shadow = this.el.nativeElement.shadowRoot;
        if (shadow) {
          try {
            shadow.querySelector('.select-text').style.whiteSpace = 'normal';
          } catch (e) {}
        }
      }, 1000);
    }
  }
}
