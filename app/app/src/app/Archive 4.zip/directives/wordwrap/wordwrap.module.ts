import { NgModule } from '@angular/core';
import { WordWrapDirective } from '@app/directives/wordwrap/wordwrap.directive';

@NgModule({
  declarations: [WordWrapDirective],
  exports: [WordWrapDirective]
})
export class WordwrapModule {}
