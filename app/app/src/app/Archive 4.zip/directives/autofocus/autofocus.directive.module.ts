import { NgModule } from '@angular/core';
import { AutofocusDirective } from '@app/directives/autofocus/autofocus.directive';

@NgModule({
  declarations: [AutofocusDirective],
  exports: [AutofocusDirective]
})
export class AutofocusDirectiveModule {}
