import { NgModule } from '@angular/core';
import { ScrollTrackerDirective } from '@app/directives/scroll-track/scroll-tracker.directive';

@NgModule({
  declarations: [ScrollTrackerDirective],
  exports: [ScrollTrackerDirective]
})
export class ScrollTrackerModule {}
