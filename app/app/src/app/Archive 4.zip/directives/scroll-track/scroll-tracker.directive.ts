import { Directive, EventEmitter, HostListener, Output } from '@angular/core';

@Directive({
  selector: '[scrollTracker]'
})
export class ScrollTrackerDirective {
  @Output() onBottom = new EventEmitter();

  @HostListener('scroll', ['$event'])
  onScroll(event) {
    const tracker = event.target;
    const limit = tracker.scrollHeight - tracker.clientHeight;
    if (Math.floor(event.target.scrollTop) >= limit - 51) {
      this.onBottom.emit();
    }
  }
}
