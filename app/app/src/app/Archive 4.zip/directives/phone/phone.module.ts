import { NgModule } from '@angular/core';
import { PhoneDirective } from './phone.directive';

@NgModule({
  declarations: [PhoneDirective],
  exports: [PhoneDirective]
})
export class PhoneModule {}
