import { HttpClientModule } from '@angular/common/http';
import { NgModule, Optional, SkipSelf } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { IonicModule } from '@ionic/angular';
import { IonicStorageModule } from '@ionic/storage';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { NgxsReduxDevtoolsPluginModule } from '@ngxs/devtools-plugin';
import { NgxsRouterPluginModule } from '@ngxs/router-plugin';
import { NgxsStoragePluginModule } from '@ngxs/storage-plugin';
import { NgxsModule } from '@ngxs/store';
import { UserIdleModule } from 'angular-user-idle';
import { NgxMaskModule } from 'ngx-mask';
import { environment } from '../../environments/environment';
import { AppState } from '../store/state/app.state';
import { DeductibleState } from '../store/state/deductible.state';
import { DependentState } from '../store/state/dependent.state';
import { FitnessState } from '../store/state/fitness.state';
import { LoginState } from '../store/state/login.state';
import { MedlookupState } from '../store/state/medlookup.state';
import { PreferenceState } from '../store/state/preference.state';
import { ProfileState } from '../store/state/profile.state';
import { RegisterState } from '../store/state/register.state';
import { SearchState } from '../store/state/search.state';
import { TaxFormsState } from '../store/state/taxforms.state';
import { TranslocoRootModule } from '../transloco/transloco-root.module';

/**
 * Home for singletons that are used througout the application, such as:
 *   - Modules with providers (typically imported using ```forRoot()```)
 *   - HTTP interceptors
 */
@NgModule({
  imports: [
    BrowserAnimationsModule /* Keep this as first import */,
    HttpClientModule /* Keep this as second import */,
    IonicModule.forRoot({ persistConfig: true, _forceStatusbarPadding: false, hideCaretOnScroll: true, swipeBackEnabled: false }),
    IonicStorageModule.forRoot(),
    UserIdleModule.forRoot({ idle: environment.sessionTimeoutInSeconds, timeout: 2, ping: 1 }),
    NgxsModule.forRoot(
      [
        AppState,
        LoginState,
        RegisterState,
        FitnessState,
        TaxFormsState,
        DeductibleState,
        DependentState,
        ProfileState,
        PreferenceState,
        SearchState,
        MedlookupState
      ],
      {
        developmentMode: !environment.enableAngularProdMode
      }
    ),
    NgxsRouterPluginModule.forRoot(),
    NgxsSelectSnapshotModule.forRoot(),
    NgxsStoragePluginModule.forRoot(),
    NgxsReduxDevtoolsPluginModule.forRoot({ disabled: environment.enableAngularProdMode }),
    NgxMaskModule.forRoot({ showMaskTyped: true }),
    TranslocoRootModule
  ],
  exports: [],
  declarations: [],
  providers: [
    /* -------------------------------------------------------------------------
     * If a service is declared using @Injectable({ providedIn: 'root' }),
     * it does not need to be listed in the providers of any module.
     * -------------------------------------------------------------------------
     */
  ]
})
export class CoreModule {
  constructor(@Optional() @SkipSelf() parentModule: CoreModule) {
    if (parentModule) {
      throw new Error('CoreModule has already been loaded. Import it from AppModule only.');
    }
  }
}
