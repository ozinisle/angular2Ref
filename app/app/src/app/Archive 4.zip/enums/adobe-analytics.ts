export enum AdobeAnalytics {
  MBW_LOGIN = 'mbwLogin',
  APP_BOOT = 'appboot',
  SWRV_BOOT = 'swrvboot',
  LOGIN = 'login'
}
