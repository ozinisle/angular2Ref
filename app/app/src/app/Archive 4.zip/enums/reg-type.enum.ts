export enum RegType {
  EMAIL = 'EMAIL',
  MOBILE = 'MOBILE'
}
