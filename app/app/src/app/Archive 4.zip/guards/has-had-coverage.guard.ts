import { Injectable } from '@angular/core';
import { CanActivate, CanActivateChild, CanLoad, Router } from '@angular/router';
import { Select } from '@ngxs/store';
import { Observable } from 'rxjs';
import { take, tap } from 'rxjs/operators';
import { AppSelectors } from '../store/selectors/app.selectors';

/**
 * Route guard to determine if the current user has had plan coverage at some
 * point (does not have to be active coverage).
 *
 * All route guard checks redirect to "/home" if not allowed.
 *
 * Can also be injected as a Service. The Observable property ```hasHadCoverage$```
 * can be used to perform the check without redirecting.
 */
@Injectable({
  providedIn: 'root'
})
export class HasHadCoverageGuard implements CanLoad, CanActivate, CanActivateChild {
  /**
   * Whether the current user has had plan coverage at some point
   * (does not have to be active coverage).
   *
   * Note: This is a _hot_ Observable -- use rxjs operator take(1)
   * if you only need the current value.
   */
  @Select(AppSelectors.hasHadCoverage) public hasHadCoverage$: Observable<boolean>;

  constructor(private router: Router) {}

  canActivate(): Observable<boolean> {
    return this.confirmOrRedirect();
  }

  canActivateChild(): Observable<boolean> {
    return this.confirmOrRedirect();
  }

  canLoad(): Observable<boolean> {
    return this.confirmOrRedirect();
  }

  private confirmOrRedirect(): Observable<boolean> {
    return this.hasHadCoverage$.pipe(
      take(1),
      tap(hasHadCoverage => {
        if (!hasHadCoverage) {
          this.router.navigate(['/home']);
        }
      })
    );
  }
}
