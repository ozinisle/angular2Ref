import { Injectable } from '@angular/core';
import { CanActivate, CanActivateChild, CanLoad, Router } from '@angular/router';
import { combineLatest } from 'rxjs';
import { Observable } from 'rxjs/Observable';
import { map, take } from 'rxjs/operators';
import { EarnAndSaveService } from '../services/earn-and-save/earn-and-save.service';

/**
 * Route guard to determine if the "Earn and Save" page is enabled.
 * All route guard checks redirect to "/home" if not allowed.
 *
 * Can also be injected as a Service. The Observable property ```isPageEnabled$```
 * can be used to perform the check without redirecting.
 */
@Injectable({
  providedIn: 'root'
})
export class EarnAndSavePageGuard implements CanLoad, CanActivate, CanActivateChild {
  /**
   * Whether the "Earn and Save" page can be navigated to.
   *
   * Note: This is a _hot_ Observable -- use rxjs operator take(1)
   * if you only need the current value.
   */
  public get isPageEnabled$(): Observable<boolean> {
    return combineLatest([
      this.earnAndSaveService.isEarnAndSaveWidgetEnabledForCurrentUser$,
      this.earnAndSaveService.isMaximizePlanWidgetEnabledForCurrentUser$
    ]).pipe(
      map(([isEarnAndSaveWidgetEnabled, isMaximizePlanWidgetEnabled]) => {
        return isEarnAndSaveWidgetEnabled || isMaximizePlanWidgetEnabled;
      })
    );
  }

  constructor(private earnAndSaveService: EarnAndSaveService, private router: Router) {}

  canActivate(): Observable<boolean> {
    return this.confirmOrRedirect();
  }

  canActivateChild(): Observable<boolean> {
    return this.confirmOrRedirect();
  }

  canLoad(): Observable<boolean> {
    return this.confirmOrRedirect();
  }

  private confirmOrRedirect(): Observable<boolean> {
    return this.isPageEnabled$.pipe(
      take(1),
      map(isPageEnabled => {
        if (isPageEnabled) {
          return true;
        }
        this.router.navigate(['/home']);
        return false;
      })
    );
  }
}
