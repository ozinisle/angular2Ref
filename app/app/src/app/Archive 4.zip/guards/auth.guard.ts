import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { PostLoginModel } from '@app/models/post-login.model';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { isValid } from 'date-fns';

import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;
  @SelectSnapshot(AppSelectors.getScopeName) scopeName: string;
  @SelectSnapshot(AppSelectors.getUserState) userState: string;
  @SelectSnapshot(AppSelectors.getPostLoginInfo) postLoginInfo: PostLoginModel;

  isRegisteredUser: boolean;
  constructor(
    private router: Router) {}

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    const isAuthenticated = this.authToken != null;
    const scopeName = this.scopeName;
    this.isRegisteredUser = scopeName.includes('REGISTERED');
    if (isAuthenticated) {
      if (!this.hasMembershipStarted()) {
        this.router.navigate(['too-soon']);
        return false;
      }
      if (localStorage.getItem('targetRoute')) {
        localStorage.removeItem('targetRoute');
      }
      return true;
    } else {
      if (this.isRegisteredUser) {
        sessionStorage.clear();
        localStorage.setItem('targetRoute', state.url);
        this.router.navigate(['register']);
      } else {
        sessionStorage.clear();
        localStorage.setItem('targetRoute', state.url);
        this.router.navigate(['login'], { queryParams: { redirectURL: state.url } });
      }
      return false;
    }
  }

  /**
   * Get and parse the covergae effective date from post login details.
   * If not present or invalid returns null.
   */
  private getStartDate(): Date {
    const startDate =  new Date(this.postLoginInfo?.coverageEffecDt);
    if (isValid(startDate)) {
      //date format not needed for validation, Date is expected in return so can't return string format
      //const formattedstartDate = format(startDate, this.constants.coverageEffectiveDateFormat);
      return startDate;
    }
    return null;
  }

  /**
   * Check if the member has his coverage started.
   * If no coverage date was returned then we assume it has started for backward compatibility.
   */
  private hasMembershipStarted(): boolean {
    const startDate = this.getStartDate();
    if (startDate == null) {
      return true;
    }
    const currentDate = new Date();
    const hasStarted = startDate.getTime() <= currentDate.getTime();
    return hasStarted;
  }
}
