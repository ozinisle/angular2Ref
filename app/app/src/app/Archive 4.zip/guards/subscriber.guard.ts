import { Injectable } from '@angular/core';
import { CanActivate, CanActivateChild, CanLoad, Router } from '@angular/router';
import { Select } from '@ngxs/store';
import { Observable } from 'rxjs';
import { take, tap } from 'rxjs/operators';
import { ProfileSelectors } from '../store/selectors/profile.selectors';

/**
 * Route guard to determine if the current user is the primary subscriber of
 * their health plan (i.e., not a spouse or dependent).
 *
 * All route guard checks redirect to "/home" if not allowed.
 *
 * Can also be injected as a Service. The Observable property ```isSubscriber$```
 * can be used to perform the check without redirecting.
 */
@Injectable({
  providedIn: 'root'
})
export class SubscriberGuard implements CanLoad, CanActivate, CanActivateChild {
  /**
   * Whether the current user is the primary subscriber of their health plan
   * (i.e., not a spouse or dependent).
   *
   * Note: This is a _hot_ Observable -- use rxjs operator take(1)
   * if you only need the current value.
   */
  @Select(ProfileSelectors.isSubscriber) public isSubscriber$: Observable<boolean>;

  constructor(private router: Router) {}

  canActivate(): Observable<boolean> {
    return this.confirmOrRedirect();
  }

  canActivateChild(): Observable<boolean> {
    return this.confirmOrRedirect();
  }

  canLoad(): Observable<boolean> {
    return this.confirmOrRedirect();
  }

  private confirmOrRedirect(): Observable<boolean> {
    return this.isSubscriber$.pipe(
      take(1),
      tap(isSubscriber => {
        if (!isSubscriber) {
          this.router.navigate(['/home']);
        }
      })
    );
  }
}
