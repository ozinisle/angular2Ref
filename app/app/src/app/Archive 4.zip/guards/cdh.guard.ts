import { Injectable } from '@angular/core';
import { CanActivate, CanActivateChild, CanLoad, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map, take, tap } from 'rxjs/operators';
import { PlanConfigService } from '../services/plan-config/plan-config-service';

/**
 * Route guard to determine if the current user is enrolled in a
 * CDH (Consumer Driven Health) plan (does not have to be active coverage).
 *
 * All route guard checks redirect to "/home" if the current user is not enrolled
 * in a CDH plan.
 *
 * Can also be injected as a Service. The Observable property ```isCdhPlanMember$```
 * can be used to perform the check without redirecting.
 */
@Injectable({
  providedIn: 'root',
})
export class CdhGuard implements CanLoad, CanActivate, CanActivateChild {
  /**
   * Whether the current user is enrolled in a CDH (Consumer Driven Health) plan
   * (does not have to be active coverage).
   */
  public get isCdhPlanMember$(): Observable<boolean> {
    return this.planConfigService.getCurrentPlanConfig$().pipe(map((planConfig) => !!planConfig?.elligibility.isDigitalFirstCDH));
  }

  constructor(private planConfigService: PlanConfigService, private router: Router) {}

  canActivate(): Observable<boolean> {
    return this.confirmOrRedirect();
  }

  canActivateChild(): Observable<boolean> {
    return this.confirmOrRedirect();
  }

  canLoad(): Observable<boolean> {
    return this.confirmOrRedirect();
  }

  private confirmOrRedirect(): Observable<boolean> {
    return this.isCdhPlanMember$.pipe(
      take(1),
      tap((isCdhPlanMember) => {
        if (!isCdhPlanMember) {
          this.router.navigate(['/home']);
        }
      })
    );
  }
}
