import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { AlertsComponent } from './alerts.component';
import { SafePipeModule } from '@app/pipes/safe-html/safe-html.module';

@NgModule({
  imports: [CommonModule, IonicModule, SafePipeModule],
  exports: [AlertsComponent],
  declarations: [AlertsComponent]
})
export class AlertsModule {}
