import { AlertType } from './alert-type.model';
import { IAlert } from '@app/services/alert.service';

export class Alert implements IAlert {
  title: string;
  type: AlertType;
  message: string;
  slot: string;

  constructor(message, title = 'Alert', type = AlertType.Success, slot = '') {
    this.title = title;
    this.type = type;
    this.message = message;
    this.slot = slot;
  }
}
