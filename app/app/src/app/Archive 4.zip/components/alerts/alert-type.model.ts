export enum AlertType {
  Success,
  Warning,
  Failure,
  Notification
}
