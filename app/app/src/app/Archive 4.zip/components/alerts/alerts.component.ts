import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { AlertService, IAlert } from '@app/services/alert.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-alerts',
  templateUrl: './alerts.component.html',
  styleUrls: ['./alerts.component.scss']
})
export class AlertsComponent implements OnInit {
  @Input() scope: string;
  @Input() slot = '';
  @Output() callBack: EventEmitter<any> = new EventEmitter();

  alert$: Observable<{ [key: string]: IAlert }>;

  constructor(private alertService: AlertService, private router: Router) {}

  ngOnInit(): void {
    this.alert$ = this.alertService.alerts$.asObservable();
  }

  navigateInApp(event: any) {
    if (event?.target?.dataset?.routerLink) {
      this.router.navigateByUrl(event.target.dataset.routerLink);
    } else if (event.target.id === 'register') {
      this.router.navigateByUrl('register');
    } else if (event.target.id === 'callback') {
      this.callBack.emit();
    }
  }
}
