import { HttpClient } from '@angular/common/http';
import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { IabService } from '@app/services/iab.service';

@Component({
  selector: 'app-iab-block',
  templateUrl: './iab-click-block.component.html',
  styleUrls: ['./iab-click-block.component.scss']
})
export class IabClickBlockComponent implements OnInit {
  @Input() targetUrl: string;
  @ViewChild('contentDiv') contentDiv: ElementRef;
  contentData: string;

  constructor(private http: HttpClient, private iabService: IabService) {}

  ngOnInit() {
    this.http.get(this.targetUrl).subscribe(response => {
      this.prepareDrupalContent(response);
    });
  }

  prepareDrupalContent(response?) {
    if (response && response[0]) {
      this.contentData = response[0].ShortDescription ? response[0].ShortDescription : response[0].Body;
      this.addClickEventToAnchorTag();
    }
  }

  addClickEventToAnchorTag() {
    setTimeout(() => {
      const el = this.contentDiv.nativeElement.getElementsByTagName('a');
      if (el) {
        el[0].addEventListener('click', (e: any) => {
          e.preventDefault();
          e.stopPropagation();
          this.checkAnchorClick(e);
        });
      }
    }, 500);
  }

  checkAnchorClick($event: any) {
    if ($event && $event.target.href && $event.target.href.indexOf('http') > -1) {
      this.iabService.create($event.target.href);
    }
  }
}
