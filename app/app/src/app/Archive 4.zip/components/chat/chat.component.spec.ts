import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { mocks } from '@testing/constants/mocks.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { MyPlansService } from './../../pages/my-plans/my-plans.service';

import { ChatComponent } from './chat.component';
import { RouterTestingModule } from '@angular/router/testing';
import { AppState } from '@app/store/state/app.state';
import { Actions, NgxsModule } from '@ngxs/store';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { DatePipe } from '@angular/common';
import { AppVersion } from '@ionic-native/app-version/ngx';
import { GeoLocationService } from '@app/services/geo-location.service';
import { NativeGeocoder } from '@ionic-native/native-geocoder/ngx';
import { LocationAccuracy } from '@ionic-native/location-accuracy/ngx';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { DynamicScriptLoaderService } from '@app/services/dynamic-script-loader.service';

fdescribe('ChatComponent', () => {
  let component: ChatComponent;
  let fixture: ComponentFixture<ChatComponent>;
  let mockMyPlanService;
  mockMyPlanService = mocks.service.myPlansService;

  const authToken = {
    unreadMsgCount: '0',
    hasDependents: 'false',
    scopename: '',
    HasActivePlan: 'true',
    planTypes: {
      vision: 'false',
      medical: 'true',
      dental: 'false'
    },
    destinationURL: '',
    isALG: 'false',
    access_token: '',
    refresh_token: '',
    firstName: '',
    isHEQ: '',
    syntheticID: '',
    migrationtype: '',
    userType: 'medical',
    issued: '',
    access_token_expires: '',
    refresh_token_expires: ''
  };

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ChatComponent],
      imports: [IonicModule.forRoot(), HttpClientTestingModule,
        RouterTestingModule,

        HttpClientTestingModule,
      NgxsModule.forRoot([AppState]),
      NgxsSelectSnapshotModule.forRoot()
      ],
      providers: [HttpTestingController,
        DatePipe,
        { provide: MyPlansService, useValue: mockMyPlanService },
        Actions,
        AppVersion,
        GeoLocationService,
        Geolocation,
        NativeGeocoder,
        LocationAccuracy,
        DynamicScriptLoaderService
      ]
    }).compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(ChatComponent);
    component = fixture.componentInstance;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });



  it('should call ngOnInit', () => {
    component.isChatVisible = false;
    fixture = TestBed.createComponent(ChatComponent);
    component = fixture.componentInstance;
    Object.defineProperty(component, 'authToken', { writable: true });
    Object.defineProperty(component, 'userType', { writable: true });
    component.authToken = authToken;
    fixture.detectChanges();
    component.ngOnInit();
    expect(component.isChatVisible).toBeTruthy();
  });

  it('should call destroyChat on ngOnDestroy', () => {
    fixture = TestBed.createComponent(ChatComponent);
    component = fixture.componentInstance;
    Object.defineProperty(component, 'authToken', { writable: true });
    Object.defineProperty(component, 'userType', { writable: true });
    component.authToken = {};
    fixture.detectChanges();
    const spy = spyOn(component, 'destroyChat');
    component.ngOnDestroy();
    expect(spy).toHaveBeenCalled();
  });

  it('should check isChatVisible flag after calling  showAqua', () => {
    component.showAqua();
    expect(component.isChatVisible).toBeTruthy();
  });

  it('should check egainChatobject  after calling  getEgainDockChatObject', () => {
    const egainVal = component.getEgainDockChatObject();
    expect(egainVal).toEqual({});
  });

  it('should check isChatVisible flag after calling  destroyChat', () => {
    component.destroyChat();
    expect(component.isChatVisible).toBeFalsy();
  });

  it('should check destroyChat flag after calling resetChat ', () => {
    const spy = spyOn(component, 'destroyChat');
    component.resetChat();
    expect(spy).toHaveBeenCalled();
  });
});
