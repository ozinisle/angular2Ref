import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { format } from 'date-fns';
import { of, Subject } from 'rxjs';
import { map, takeUntil } from 'rxjs/operators';
import { MyPlansService } from '@app/pages/my-plans/my-plans.service';
import { DynamicScriptLoaderService } from '@app/services/dynamic-script-loader.service';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import * as chat from './utils/chat.utils';
import { Actions, ofActionSuccessful } from '@ngxs/store';
import { Logout, PostLogin } from '@app/store/actions/app.actions';
import { environment } from '@environments/environment';

@Component({
  selector: 'app-chat',
  template: '',
})
export class ChatComponent implements OnInit, OnDestroy {

  @SelectSnapshot(AppSelectors.getMemProfile) memProfile;
  @SelectSnapshot(AppSelectors.getAuthToken) authToken: any;
  isChatVisible: boolean = false;
  isChatPopepOut: boolean = false;
  destroy$ = new Subject<void>();
  timeout: any;

  static readonly config = {
    serverUrl: environment.liveChatServerUrl,
    entryPoint: environment.liveChatEntryPoint,
    template: 'bcbsmyblue',
  }

  constructor(
    private scripLoader: DynamicScriptLoaderService,
    private myplansService: MyPlansService,
    private actions$: Actions
  ) {
    this.actions$.pipe(ofActionSuccessful(Logout), takeUntil(this.destroy$)).subscribe(() => {
      this.resetChat();
    });
    this.actions$.pipe(ofActionSuccessful(PostLogin), takeUntil(this.destroy$)).subscribe(() => {
      if (chat.isChatActive() && !this.isChatVisible && this.authToken && this.authToken?.userType) {
        this.showAqua();
      }
    });
  }

  ngOnInit(): void {
    if (chat.isChatActive() && !this.isChatVisible && this.authToken && this.authToken?.userType) {
      this.showAqua();
    }
    this.timeout = setInterval(() => {
      if (!this.authToken || !this.authToken?.userType) {
        this.resetChat();
      }
    }, 10000)
  }

  ngOnDestroy(): void {
    if (!this.authToken || !this.authToken?.userType) {
      this.destroyChat();
    }
  }

  @HostListener('window:message', ['$event']) onMessage(event) {
    let data = chat.parseData(event.data);
    if (data.Method === 'RESET_CHAT') {
      this.resetChat()
    }

    if (data.Method === 'SET') {
      if (data.Key === 'egPopoutWindow' && data.Value === false && this.isChatPopepOut) {
        this.resetChat() // alow a reset coming from closing the popup window
      }

      if (data.Key === 'CUSTOM_CONFIRM_CLOSE') {
        const returnValue = confirm(data.Value)
        const iframeWin = document.getElementById("egain-chat-iframe") as HTMLIFrameElement
        const iframe = iframeWin.contentWindow;
        iframe.postMessage(returnValue + '', ChatComponent.config.serverUrl);
      }
    }

    if (data.Method === 'REMOVE') {
      if (data.Key === 'egChatInProgress') {
        this.resetChat()
      }
    }

    if (data.Method === 'POPOUT') {
      if (data.Key === 'POPOUT_START') {
        this.isChatPopepOut = true;
      }
    }
  }

  getPlansAccountNumber() {
    let accountNumber: string;
    if (!sessionStorage.getItem('accountNumber') && this.authToken && this.authToken?.userType) {
      const effectiveDate = format(new Date(), 'yyyy-MM-dd');
      return this.myplansService.getPlansData(effectiveDate).pipe(map(data => {
        if (data.result < 0) {
          sessionStorage.setItem('accountNumber', "");
          return '';
        } else {
          accountNumber = chat.getAccountDetatils(data["RowSet"]['osplinPlans'].plans);
          sessionStorage.setItem('accountNumber', accountNumber);
          return accountNumber
        }
      }
      ))
    } else {
      accountNumber = sessionStorage.getItem('accountNumber');
      return of(accountNumber);
    }
  }

  getEgainDockChatObject() {
    let egainDockChat = window['egainDockChat'] || {};
    window['egainDockChat'] = egainDockChat
    return egainDockChat;
  }

  showAqua() {
    this.getPlansAccountNumber().subscribe((accountNumber) => {
      this.isChatVisible = true;
      this.scripLoader.loadScript('livechat').then(() => this.loadAqua(accountNumber))
    })
  }

  loadAqua(accountNumber) {

    let egainDockChat = this.getEgainDockChatObject();

    egainDockChat.serverURL = ChatComponent.config.serverUrl;
    egainDockChat.EntryPointId = ChatComponent.config.entryPoint;
    egainDockChat.Locale = 'en-US';
    egainDockChat.Template = ChatComponent.config.template;
    egainDockChat.PostChatAttributes = true;
    egainDockChat.IntegratedEntryPoint = false;

    egainDockChat.Debug = true;

    egainDockChat.VChatParams = ''
    egainDockChat.VChatParams += '&wsname=' + encodeURIComponent(window.top.location.origin);
    egainDockChat.VChatParams += '&subActivity=Chat';
    egainDockChat.VChatParams += '&bcbsmaApp=true';

    egainDockChat.SetCustomerParameters = function (egainAttributeName, attributeValue) {
      if (!egainDockChat.SetParameter) {
        egainDockChat.CallQueue = egainDockChat.CallQueue || [];
        egainDockChat.CallQueue.push({ name: 'SetParameter', args: [egainAttributeName, attributeValue] });
      } else {
        egainDockChat.SetParameter(egainAttributeName, attributeValue);
      }
    };

    if (this.memProfile.fullName) {
      egainDockChat.SetCustomerParameters('fieldname_1', this.memProfile.fullName);
    }
    if (this.memProfile.emailAddress) {
      egainDockChat.SetCustomerParameters('fieldname_2', this.memProfile.emailAddress);
    }
    if (this.memProfile.subscriberId) {
      egainDockChat.SetCustomerParameters('fieldname_3', (this.memProfile.subscriberId as string).substring(0, 9));
    }
    const accountNumberVal = accountNumber ? accountNumber : '';
    egainDockChat.SetCustomerParameters('fieldname_4', accountNumberVal);

    if (!egainDockChat.launchChat) {
      egainDockChat.CallQueue = egainDockChat.CallQueue || [];
      egainDockChat.CallQueue.push({ name: 'launchChat', args: [] });
    } else {
      egainDockChat.launchChat();
    }

  }

  destroyChat() {

    if (this.isChatVisible) {
      let egainDockChat = this.getEgainDockChatObject();

      if (egainDockChat.iframeWrapper) {
        egainDockChat.iframeWrapper.remove()
      }
      this.isChatVisible = false;
    }

    localStorage.removeItem('egSessionId')
    localStorage.removeItem('egChatWindowState')
    localStorage.removeItem('egBadgeCount')
    localStorage.removeItem('EgainLastRequestId')
    localStorage.removeItem('egChatInProgress')
    localStorage.removeItem('egOffRecordBtnState')
    localStorage.removeItem('egChatStateBeforeUnload')
    localStorage.removeItem('isUnDockedChatInProgress')

  }

  resetChat() {

    this.destroyChat()

    if (chat.isChatActive() && this.authToken && this.authToken?.userType) {
      this.showAqua();
    }
  }

}
