import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreferenceSelectionsComponent } from './preference-selections.component';
import { NgxsModule } from '@ngxs/store';
import { IonicModule, PopoverController } from '@ionic/angular';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';

describe('PreferenceSelectionsComponent', () => {
  let component: PreferenceSelectionsComponent;
  let fixture: ComponentFixture<PreferenceSelectionsComponent>;

  const popoverSpy = jasmine.createSpyObj('Popover', ['present']);
  const popoverCtrlSpy = jasmine.createSpyObj('PopoverController', ['create']);
  popoverCtrlSpy.create.and.callFake(() => {
    return popoverSpy;
  });

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      providers: [
        {
          provide: PopoverController,
          useValue: popoverCtrlSpy
        }
      ],
      declarations: [PreferenceSelectionsComponent],
      imports: [IonicModule, NgxsModule.forRoot(), NgxsSelectSnapshotModule.forRoot()]
    }).compileComponents();

      fixture = TestBed.createComponent(PreferenceSelectionsComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    })
  );

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
