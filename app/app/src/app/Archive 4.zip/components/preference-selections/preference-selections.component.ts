import { Component, HostListener, Input } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { PreferenceSelectors } from '@app/store/selectors/preference.selectors';
import { UpdatePreferenceSelection } from '@app/store/actions/preference.action';
import { Store } from '@ngxs/store';
import { TooltipPopoverComponent } from '@app/components/tooltip-popover/tooltip-popover.component';
import {
  EMAIL_NOT_DELIVERABLE_MESSAGE,
  TOOLTIP_DESCRIPTIONS,
  SMS_NOT_DELIVERABLE_MESSAGE
} from '@app/store/constants/preference.constants';
import { PopoverController } from '@ionic/angular';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { ConstantsService } from '@app/services/constants.service';
import { AlertService } from '@app/services/alert.service';
import { AlertType } from '../alerts/alert-type.model';
import { PreferenceService } from '@app/services/preference.service';

@Component({
  selector: 'app-preference-selections',
  templateUrl: './preference-selections.component.html',
  styleUrls: ['./preference-selections.component.scss']
})
export class PreferenceSelectionsComponent {
  @SelectSnapshot(PreferenceSelectors.getProgramGroups) programGroups: any;
  @SelectSnapshot(AppSelectors.getUnionBlueMemberInfo) isUnionBlueMember: boolean;

  @Input() emailHardBounced: boolean;
  @Input() smsBounced: boolean;
  @Input() cdh: boolean;
  @Input() isModalPopup: boolean;
  popovers: boolean[] = [];
  fpoTargetUrl: string;
  mobileViewPort = 991;
  ismobile: boolean;
  isTextSelected: boolean;
  isEmailSelected: boolean;

  constructor(
    private store: Store,
    private popoverController: PopoverController,
    private constants: ConstantsService,
    private alertService: AlertService,
    private prefService: PreferenceService
  ) {
    this.fpoTargetUrl = this.constants.isUnionBlueMember;
    this.isTextSelected = false;
    this.isEmailSelected = false;
    if (this.emailHardBounced === true) {
      this.alertService.setAlert(EMAIL_NOT_DELIVERABLE_MESSAGE, '', AlertType.Failure, 'emailUndeliverable');
    }
    if (this.smsBounced === true) {
      this.alertService.setAlert(SMS_NOT_DELIVERABLE_MESSAGE, '', AlertType.Failure, 'smsBounced');
    }
    this.prefService.getChannelSaveClicked().subscribe(data => {
      if (data.channel === 'Email' && data.status === true) {
        this.emailHardBounced = false;
      } else if (data.channel === 'SMS' && data.status === true) {
        this.smsBounced = false;
      }
    });
    this.ismobile = window.innerWidth <= this.mobileViewPort;
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.ismobile = event.target.innerWidth <= this.mobileViewPort;
  }

  onChange(event: any) {
    if (event.target.name === 'Documents_Plan' && !event.target.checked) {
      event.target.checked = true;
    }
    if (event.target.name === 'Documents_Plan') {
      if (this.emailHardBounced === true || this.smsBounced === true) {
        if (event.detail.value === 'MAIL' && event.detail.checked === true) {
          if (this.emailHardBounced === true) {
            this.prefService.onCloseEditChannel.next({
              channel: 'Email',
              status: false
            });
            this.prefService.isChannelEditCancelled.next({
              channel: 'Email',
              status: false
            });
          } else if (this.smsBounced === true) {
            this.prefService.onCloseEditChannel.next({
              channel: 'SMS',
              status: false
            });
            this.prefService.isChannelEditCancelled.next({
              channel: 'SMS',
              status: false
            });
          }
          this.isTextSelected = false;
          this.isEmailSelected = false;
        }
        if (event.detail.value === 'SMS' && event.detail.checked === true) {
          this.prefService.onCloseEditChannel.next({
            channel: 'Email',
            status: true
          });
          this.prefService.isChannelEditCancelled.next({
            channel: 'Email',
            status: false
          });
          this.isTextSelected = true;
        }
        if (event.detail.value === 'SOLICIT' && event.detail.checked === true) {
          this.isEmailSelected = true;
          this.prefService.onCloseEditChannel.next({
            channel: 'SMS',
            status: true
          });
          this.prefService.isChannelEditCancelled.next({
            channel: 'SMS',
            status: false
          });
        }
      }
    }
    this.store.dispatch(new UpdatePreferenceSelection(event.target.name, event.target.value, event.target.checked));
  }

  async showTooltip($event, i: number) {
    const popover = await this.popoverController.create({
      component: TooltipPopoverComponent,
      event: $event,
      mode: 'ios',
      componentProps: {
        tooltipText: TOOLTIP_DESCRIPTIONS[i]
      }
    });
    await popover.present();
  }

  getRadioValue(filter) {
    if (filter.selected) {
      return filter.channelID;
    }
  }
}
