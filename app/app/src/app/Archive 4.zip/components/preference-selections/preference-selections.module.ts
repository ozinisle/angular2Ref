import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { PreferenceSelectionsComponent } from './preference-selections.component';
import { FpoLayoutModule } from '@app/components/fpo-layout/fpo-layout.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  imports: [CommonModule, IonicModule, FpoLayoutModule, FontAwesomeModule],
  exports: [PreferenceSelectionsComponent],
  declarations: [PreferenceSelectionsComponent]
})
export class PreferenceSelectionsModule {}
