import { Input } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PopoverController } from '@ionic/angular';
import { ServiceFailureModalInterface } from './service-failure-modal.interface';

@Component({
  selector: 'app-service-failure-modal',
  templateUrl: './service-failure-modal.component.html',
  styleUrls: ['./service-failure-modal.component.scss']
})
export class ServiceFailureModalComponent implements OnInit {
  @Input() data: ServiceFailureModalInterface;

  constructor(private popoverController: PopoverController, private router:Router) {}

  ngOnInit() {}

  retry() {
    this.popoverController.dismiss({ retry: true });
  }

  close() {
    this.popoverController.dismiss({ retry: false });
    this.router.navigate(['/home']);
  }

  navigateToContactInfo() {
    this.popoverController.dismiss({ retry: false });
    this.router.navigate(['/myprofile/contact-info']);
  }
}
