export interface ServiceFailureModalInterface {
  showRetry: boolean;
  title: string;
  description: string;
  ctaRetry: string;
  cta2Text: string;
  duplicateEmailError?: boolean;
}
