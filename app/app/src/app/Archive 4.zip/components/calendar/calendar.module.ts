import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { IonicModule } from '@ionic/angular';
import { CalendarComponent } from './calendar.component';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material/core';
import { BcbsmaPickDateAdapter, PICK_FORMATS } from './bcbs-pick-date-adapter'
import { FormsModule } from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';



@NgModule({
  declarations: [CalendarComponent],
  imports: [
    CommonModule,
    IonicModule,
    MatDatepickerModule,
    FormsModule,
    FontAwesomeModule
  ],
  exports : [
    CalendarComponent
  ],
  providers : [
    {provide: DateAdapter, useClass: BcbsmaPickDateAdapter},
    {provide: MAT_DATE_FORMATS, useValue: PICK_FORMATS}
  ]
})
export class CalendarModule { }
