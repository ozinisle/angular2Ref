import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.scss'],
})
export class CalendarComponent implements OnInit {

  @Input() minDate = new Date();
  @Input() selectedDate: Date;
  @Output() onDateChange = new EventEmitter();
  constructor() { }

  ngOnInit() {
    this.minDate = new Date();
    if ( !this.selectedDate) {
      this.selectedDate = this.minDate;
    }
  }

  dateChange(event) {
    this.onDateChange.emit(event);
  }
}
