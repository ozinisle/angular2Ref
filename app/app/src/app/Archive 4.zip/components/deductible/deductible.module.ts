import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { DeductibleComponent } from './deductible.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  imports: [CommonModule, IonicModule, FontAwesomeModule],
  exports: [DeductibleComponent],
  declarations: [DeductibleComponent]
})
export class DeductibleModule {}
