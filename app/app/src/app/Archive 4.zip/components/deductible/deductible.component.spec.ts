import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { DeductibleComponent } from './deductible.component';
import { IonContent, IonicModule } from '@ionic/angular';

describe('DeductibleComponent', () => {
  let component: DeductibleComponent;
  let fixture: ComponentFixture<DeductibleComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [IonicModule, RouterTestingModule],
      declarations: [DeductibleComponent],
      providers: [IonContent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeductibleComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
