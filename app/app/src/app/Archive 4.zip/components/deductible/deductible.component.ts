import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { DeductibleModel } from '@app/models/deductible.model';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { DeductibleSelectors } from '@app/store/selectors/deductible.selectors';
import { Router } from '@angular/router';

@Component({
  selector: 'app-deductible',
  templateUrl: './deductible.component.html',
  styleUrls: ['./deductible.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DeductibleComponent {
  @SelectSnapshot(DeductibleSelectors.subscriberHasFamily) hasFamily: boolean;
  @SelectSnapshot(DeductibleSelectors.hasFirstDollar) hasFirstDollar: boolean;

  @Input() deductibleInfo: DeductibleModel;
  @Output() goToDeductibleDetails = new EventEmitter();
  @Input() homePage: string;

  constructor(private router: Router) {}

  goToDetails() {
    if (this.deductibleInfo.totalAmount) {
      this.goToDeductibleDetails.emit();
    }
  }

  getProgressValue(deductibleData) {
    if (deductibleData.limitations === "$0.00 per plan year for Enhanced Benefits Tier"
     && deductibleData.exceptions === "Deductible does not apply to the Selected Standard Benefits Tier Hospitals.") {
      return 0;
    }
      return (deductibleData.contributed / deductibleData.totalAmount);
  }
  goDeductPage() {
      this.router.navigate(['deductibles']);
  }
}
