import { Component, ElementRef, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { PWKVideo } from '@app/models/welcome-kit.model';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { Platform } from '@ionic/angular';
import { Select } from '@ngxs/store';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
// import { Httpd, HttpdOptions } from '@ionic-native/httpd/ngx';

@Component({
  selector: 'app-sunday-sky-video',
  templateUrl: './sunday-sky-video.component.html',
  styleUrls: ['./sunday-sky-video.component.scss'],
})
export class SundaySkyVideoComponent implements OnInit, OnDestroy {
  sSkyPlayer: HTMLElement;
  @ViewChild('playerFrame') playerFrame: ElementRef;
  @Input() parentPage: string;
  @Select(AppSelectors.isStopWelcomeVideoPlay) stopPlay$: Observable<boolean>;
  pwkVideo: PWKVideo;
  @Select(AppSelectors.getPwkVideo) pwkVideo$: Observable<PWKVideo>;
  sundaySkyUrl = '';
  localServerUrl = '';
  destroy$ = new Subject<void>();
  constructor(
      private router: Router,
      private platform: Platform
    ) {
  }

  ngOnInit() {
    this.pwkVideo$.pipe(takeUntil(this.destroy$)).subscribe(pwkVideo => {
      this.pwkVideo = pwkVideo;
      if (this.pwkVideo?.programID) {
        this.sundaySkyUrl = '/assets/sundaysky/index.html?ProgramID=' + this.pwkVideo?.programID + '&SskyUrl=' + this.pwkVideo?.stream
                              + '&Poster=' + this.pwkVideo?.poster + '&path=' + this.router.url + '&stop=false&isIos=' + this.platform.is('ios');
        if (this.playerFrame?.nativeElement?.contentDocument) {
          this.playerFrame.nativeElement.src = this.sundaySkyUrl;
        }
      }
    });
    this.stopPlay$.pipe(takeUntil(this.destroy$)).subscribe(stopPlay => {
      this.sundaySkyUrl = '/assets/sundaysky/index.html?ProgramID=' + this.pwkVideo?.programID + '&SskyUrl=' + this.pwkVideo?.stream
                            + '&Poster=' + this.pwkVideo?.poster + '&path=' + this.router.url + '&stop=' + (this.parentPage !== this.router.url || stopPlay) 
                            + '&isIos=' + this.platform.is('ios');
      if (this.playerFrame?.nativeElement?.contentDocument) {
        this.playerFrame.nativeElement.src = this.sundaySkyUrl;
      }
    })
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

}
