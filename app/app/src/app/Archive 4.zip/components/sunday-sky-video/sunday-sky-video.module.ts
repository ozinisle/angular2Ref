import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { SundaySkyVideoComponent } from './sunday-sky-video.component';
import { SafePipeModule } from '@app/pipes/safe-pipe/safe-pipe.module';


@NgModule({
  imports: [CommonModule, IonicModule, FontAwesomeModule, SafePipeModule],
  declarations: [SundaySkyVideoComponent],
  exports: [SundaySkyVideoComponent],
})
export class SundaySkyVideoModule {}
