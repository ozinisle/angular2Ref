import { Component, Input } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ValidationService } from '@app/services/validation.service';

@Component({
  selector: 'app-password-control-messages',
  templateUrl: './password-control-messages.html',
  styleUrls: ['./password-control-messages.component.scss']
})
export class PasswordControlMessagesComponent {
  @Input() control: FormControl;
  @Input() password: string;
  @Input() isSubmitted: boolean;
  @Input() isBlurEvent: boolean;
  allowedSpecialCharters = '! @ # $ % ^ & * ( ) + ~ . , / [ ] { } -';
  constructor(private validation: ValidationService) {}

  get errorMessage() {
    return this.validation.passwordStatus(this.password);
  }
}
