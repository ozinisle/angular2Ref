import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { PasswordControlMessagesComponent } from './password-control-messages.component';

@NgModule({
  imports: [CommonModule, IonicModule],
  exports: [PasswordControlMessagesComponent],
  declarations: [PasswordControlMessagesComponent]
})
export class PasswordControlMessageModule {}
