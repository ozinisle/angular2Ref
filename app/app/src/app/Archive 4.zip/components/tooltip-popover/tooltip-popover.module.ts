import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { TooltipPopoverComponent } from '@app/components/tooltip-popover/tooltip-popover.component';

@NgModule({
  imports: [CommonModule, IonicModule],
  exports: [TooltipPopoverComponent],
  declarations: [TooltipPopoverComponent]
})
export class TooltipPopoverModule {}
