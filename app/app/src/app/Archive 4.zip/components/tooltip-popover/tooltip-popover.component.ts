import { Component, Input } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { ConsentMeansComponent } from '@app/modals/consent-means/consent-means.component';

@Component({
  selector: 'app-tooltip-popover',
  templateUrl: './tooltip-popover.component.html',
  styleUrls: ['./tooltip-popover.component.scss']
})
export class TooltipPopoverComponent {
  @Input() tooltipText: any;
  @Input() tooltipLink: any;

  constructor(public modalController: ModalController) {}

  async openConsentToReceiveCommunicationModal() {
    const modal = await this.modalController.create({
      component: ConsentMeansComponent,
      cssClass: 'select-modal',
      componentProps: {}
    });
    return await modal.present();
  }
}
