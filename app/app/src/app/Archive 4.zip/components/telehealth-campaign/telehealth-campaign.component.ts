import { HttpClient } from '@angular/common/http';
import { Component, OnDestroy, OnInit, Input } from '@angular/core';
import { environment } from '@environments/environment';
import { Image } from '@app/models/image.model';
import { AlertService } from '@app/services/alert.service';
import { ConstantsService } from '@app/services/constants.service';
import { IabService } from '@app/services/iab.service';
import { Campaign2ComponentInputModelInterface } from '@app/models/campaign-2.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-telehealth-campaign',
  templateUrl: './telehealth-campaign.component.html',
  styleUrls: ['./telehealth-campaign.component.scss']
})
export class TelehealthCampaignComponent implements OnInit, OnDestroy {
  @Input() componentInput: Campaign2ComponentInputModelInterface;

  fpoTargetUrl: string;
  public fpocontentData1: Image;
  public fpocontentData2: Image;
  public environment: object;

  public isShowWellConnectionImage = true;
  public isShowFindCareImage = true;

  teleHealthEligible: boolean;
  showWellConnectionButton: boolean;
  vitalResponse: any;

  constructor(
    private router: Router,
    private alertService: AlertService,
    private constants: ConstantsService,
    private http: HttpClient,
    private iabService: IabService
  ) {
    this.environment = environment;
    this.fpoTargetUrl = this.constants.teleHealthWellConnectionUrl;
  }

  ngOnInit() {
    this.http.get(this.fpoTargetUrl).subscribe(response => {
      this.fpocontentData1 = response[0];
      this.fpocontentData2 = response[1];
    });
    if (this.componentInput) {
      if (this.componentInput.isShowOnlyWellNessConnectionImage()) {
        this.isShowWellConnectionImage = true;
        this.isShowFindCareImage = false;
      } else if (this.componentInput.isShowOnlyFindCareImage()) {
        this.isShowWellConnectionImage = false;
        this.isShowFindCareImage = true;
      }
    }
    this.vitalResponse = JSON.parse(sessionStorage.getItem('vitalsResponse'));
    if(this.vitalResponse?.teleHealthEligible) {
      this.teleHealthEligible = true;
    }
    if(this.vitalResponse?.platformProvider?.name === "Amwell") {
      this.showWellConnectionButton = true;
    }
  }

  openUrl($event, url: string) {
    this.iabService.create(url);
  }

  navigateVirtualVisits() {
    this.router.navigate(['/virtual-visit']);
  }

  ngOnDestroy() {
    this.alertService.clearError();
  }
}
