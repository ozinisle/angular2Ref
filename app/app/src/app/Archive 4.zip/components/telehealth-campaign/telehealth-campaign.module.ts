import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { TelehealthCampaignComponent } from './telehealth-campaign.component';

@NgModule({
  imports: [CommonModule, IonicModule],
  exports: [TelehealthCampaignComponent],
  declarations: [TelehealthCampaignComponent]
})
export class TelehealthCampaignModule {}