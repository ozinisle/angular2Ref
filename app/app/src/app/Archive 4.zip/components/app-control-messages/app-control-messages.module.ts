import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { ControlMessagesComponent } from '@app/components/app-control-messages/app-control-messages.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  imports: [CommonModule, IonicModule, FontAwesomeModule],
  exports: [ControlMessagesComponent],
  declarations: [ControlMessagesComponent]
})
export class AppControlMessagesModule {}
