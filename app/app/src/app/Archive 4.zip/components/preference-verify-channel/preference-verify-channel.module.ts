import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { PreferenceVerifyChannelComponent } from './preference-verify-channel.component';
import { NgxMaskModule } from 'ngx-mask';
import { TextMaskModule } from 'angular2-text-mask';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AlertsModule } from '@app/components/alerts/alerts.module';
import { AppControlMessagesModule } from '../app-control-messages/app-control-messages.module';
import { AutofocusDirectiveModule } from '@app/directives/autofocus/autofocus.directive.module';
import { NumberOnlyDirectiveModule } from '@app/directives/number-only/number-only.directive.module';

@NgModule({
  imports: [
    CommonModule,
    IonicModule,
    NgxMaskModule,
    TextMaskModule,
    FormsModule,
    ReactiveFormsModule,
    AlertsModule,
    AppControlMessagesModule,
    AutofocusDirectiveModule,
    NumberOnlyDirectiveModule
  ],
  exports: [PreferenceVerifyChannelComponent],
  declarations: [PreferenceVerifyChannelComponent]
})
export class PreferenceVerifyChannelModule {}
