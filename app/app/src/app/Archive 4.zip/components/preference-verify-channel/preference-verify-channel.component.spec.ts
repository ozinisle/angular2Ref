import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule, IonContent } from '@ionic/angular';
import { PreferenceVerifyChannelComponent } from './preference-verify-channel.component';
import { UPDATE_TYPE } from '@app/store/constants/preference.constants';
import { Store, NgxsModule } from '@ngxs/store';
import { UpdateConsentState, SetUpdatedCommChannel } from '@app/store/actions/profile.action';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { ProfileState } from '@app/store/state/profile.state';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { DatePipe, TitleCasePipe } from '@angular/common';
import { AlertService } from '@app/services/alert.service';
import { ProfileService } from '@app/services/profile.service';
import { AppService } from '@app/services/app.service';
import { ValidationService } from '@app/services/validation.service';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxMaskModule } from 'ngx-mask';
import { AlertsComponent } from '@app/components/alerts/alerts.component';
import { ControlMessagesComponent } from '@app/components/app-control-messages/app-control-messages.component';
import { TextMaskModule } from 'angular2-text-mask';
import { SafePipeModule } from '@app/pipes/safe-html/safe-html.module';
import { SmsRetriever } from '@ionic-native/sms-retriever/ngx';
// import { Observable } from 'rxjs';

describe('PreferenceVerifyChannelComponent', () => {
  let component: PreferenceVerifyChannelComponent;
  let fixture: ComponentFixture<PreferenceVerifyChannelComponent>;
  let store: Store;
  // let actions$: Observable<any>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [PreferenceVerifyChannelComponent, ControlMessagesComponent, AlertsComponent],
      imports: [
        IonicModule,
        HttpClientTestingModule,
        RouterTestingModule,
        FormsModule,
        ReactiveFormsModule,
        TextMaskModule,
        SafePipeModule,
        NgxsModule.forRoot([ProfileState]),
        NgxsSelectSnapshotModule.forRoot(),
        NgxMaskModule.forRoot()
      ],
      providers: [
        DatePipe,
        SmsRetriever,
        TitleCasePipe,
        AlertService,
        ProfileService,
        AppService,
        ValidationService,
        IonContent,
        FormBuilder
      ]
    }).compileComponents();
    // actions$ = TestBed.inject(Actions);
    store = TestBed.inject(Store);
    fixture = TestBed.createComponent(PreferenceVerifyChannelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call UpdateConsentState', done => {
    store.dispatch(new UpdateConsentState('N'));
    const spyStore = spyOn(store, 'dispatch').and.callThrough();
    spyOn(store, 'selectSnapshot').and.returnValue({ isVerifiedMobile: true, phoneNumber: '3452342345' });

    component.onEdit(UPDATE_TYPE.PHONE);
    component.updatePhoneForm.setValue({
      phoneNumber: '234-567-1234',
      phoneType: 'MOBILE'
    });
    fixture.detectChanges();
    component.onUpdateProfile(UPDATE_TYPE.PHONE);
    expect(spyStore).toHaveBeenCalled();
  });

  it('should call SetUpdatedCommChannel', done => {
    store.dispatch(new SetUpdatedCommChannel(UPDATE_TYPE.PHONE, '2345671234'));
    const spyStore = spyOn(store, 'dispatch').and.callThrough();
    spyOn(store, 'selectSnapshot').and.returnValue({ isVerifiedMobile: true, phoneNumber: '3452342345' });

    component.onEdit(UPDATE_TYPE.PHONE);
    component.updatePhoneForm.setValue({
      phoneNumber: '234-567-1234',
      phoneType: 'MOBILE'
    });
    fixture.detectChanges();
    component.onUpdateProfile(UPDATE_TYPE.PHONE);
    expect(spyStore).toHaveBeenCalled();
  });
});
