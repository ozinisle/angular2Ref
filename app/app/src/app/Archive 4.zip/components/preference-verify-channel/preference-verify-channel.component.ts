import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { ProfileSelectors } from '@app/store/selectors/profile.selectors';
import { AlertService } from '@app/services/alert.service';
import { Store, Actions, ofActionCompleted } from '@ngxs/store';
import { ValidationService } from '@app/services/validation.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import {
  EMAIL_NOT_VERIFIED_LABEL,
  UPDATE_TYPE,
  NON_DIGIT_REGEX,
  EMAIL_PHONE_NOT_AVAILABLE,
  DEFAULT_PHONE_NUM,
  EMAIL_NOT_DELIVERABLE_MESSAGE,
  SMS_NOT_DELIVERABLE_MESSAGE
} from '@app/store/constants/preference.constants';
import { SetUpdatedCommChannel, SetPhoneNumberRequiredFlag } from '@app/store/actions/profile.action';
import { UpdateConsentState } from '@app/store/actions/profile.action';
import { takeUntil } from 'rxjs/operators';
import { GetPreferences } from '@app/store/actions/preference.action';
import { MOBILE_MESSAGES, EMAIL_MESSAGES } from '@app/store/constants/preference.constants';
import { AppService } from '@app/services/app.service';
import { AlertType } from '@app/components/alerts/alert-type.model';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { PreferenceService } from '@app/services/preference.service';

@Component({
  selector: 'app-preference-verify-channel',
  templateUrl: './preference-verify-channel.component.html',
  styleUrls: ['./preference-verify-channel.component.scss']
})
export class PreferenceVerifyChannelComponent implements OnInit, OnDestroy {
  @SelectSnapshot(ProfileSelectors.getProfileInfo) profileInfo: any;
  @SelectSnapshot(ProfileSelectors.isPhoneNumberRequired) isPhoneNumberRequired: boolean;
  @SelectSnapshot(AppSelectors.isActiveUser) isActiveUser: any;

  @Input() emailHardBounced: boolean;
  @Input() smsBounced: boolean;

  destroy$ = new Subject<void>();
  updatePhoneForm: FormGroup;
  updateEmailForm: FormGroup;
  showEdit = { email: false, phone: false };
  mask = {};
  mobileNumberMessages = MOBILE_MESSAGES;
  emailMessages = EMAIL_MESSAGES;
  isEditEmailChannelCancelled: boolean;
  isEditPhoneChannelCancelled: boolean;

  constructor(
    private alertService: AlertService,
    private store: Store,
    private validationService: ValidationService,
    private fb: FormBuilder,
    private actions$: Actions,
    private appService: AppService,
    private prefService: PreferenceService
  ) {}

  ngOnInit() {
    this.alertService.clearError('profileInfoAlert');
    this.showEdit.phone = false;
    this.showEdit.email = false;
    this.prefService.getCloseChannelEditObs().subscribe(data => {
      if (data.channel === 'Email' && data.status === true) {
        this.showEdit.email = false;
      } else if (data.channel === 'Email' && data.status === false) {
        this.showEdit.email = true;
      } else if (data.channel === 'SMS' && data.status === true) {
        this.showEdit.phone = false;
      } else if (data.channel === 'SMS' && data.status === false) {
        this.showEdit.phone = true;
      }
    });
    this.prefService.getChannelEditObs().subscribe(data => {
      if (data.channel === 'Email' && data.status === true) {
        this.isEditEmailChannelCancelled = true;
      } else if (data.channel === 'Email' && data.status === false) {
        this.isEditEmailChannelCancelled = false;
      } else if (data.channel === 'SMS' && data.status === true) {
        this.isEditPhoneChannelCancelled = true;
      } else if (data.channel === 'SMS' && data.status === false) {
        this.isEditPhoneChannelCancelled = false;
      }
    });
    this.actions$.pipe(ofActionCompleted(GetPreferences), takeUntil(this.destroy$)).subscribe(() => {
      this.validateEmailAndPhone();
    });
    this.actions$.pipe(ofActionCompleted(SetPhoneNumberRequiredFlag), takeUntil(this.destroy$)).subscribe(() => {
      this.validateEmailAndPhone();
    });
    if (this.emailHardBounced === true) {
      this.onEdit('email');
      this.alertService.setAlert(EMAIL_NOT_DELIVERABLE_MESSAGE, '', AlertType.Failure, 'emailUndeliverable');
    } else {
      this.cancelEdit('email');
    }
    if (this.smsBounced === true) {
      this.onEdit('phone');
      this.alertService.setAlert(SMS_NOT_DELIVERABLE_MESSAGE, '', AlertType.Failure, 'smsUndeliverable');
    } else {
      this.cancelEdit('phone');
    }
  }

  onChannelEdit(updateType: string) {
    switch (updateType) {
      case UPDATE_TYPE.EMAIL:
        this.showEdit.email ? this.cancelEdit('email') : this.onEdit('email');
        break;
      case UPDATE_TYPE.PHONE:
        this.showEdit.phone ? this.cancelEdit('phone') : this.onEdit('phone');
        break;
    }
  }

  onEdit(updateType: string) {
    this.alertService.setAlert(EMAIL_NOT_VERIFIED_LABEL, '', AlertType.Failure, 'communication');
    switch (updateType) {
      case UPDATE_TYPE.EMAIL:
        {
          this.showEdit.email = true;
          this.showEdit.phone = false;
          this.prefService.isChannelEditCancelled.next({
            channel: 'Email',
            status: false
          });
          this.updateEmailForm = this.fb.group({
            emailAddress: [
              this.profileInfo.updatedEmailAddress || this.profileInfo.emailAddress,
              [Validators.required, this.validationService.emailValidator()]
            ]
          });
          this.appService.markFormGroupTouched(this.updateEmailForm);
        }
        break;
      case UPDATE_TYPE.PHONE:
        {
          this.showEdit.phone = true;
          this.showEdit.email = false;
          this.prefService.isChannelEditCancelled.next({
            channel: 'SMS',
            status: false
          });
          this.mask = { mask: this.validationService.phoneMaskMobile, guide: false };
          this.updatePhoneForm = this.fb.group({
            phoneType: 'MOBILE',
            phoneNumber: [
              this.profileInfo?.updatedPhoneNumber || this.profileInfo?.phoneNumber || DEFAULT_PHONE_NUM,
              this.isPhoneNumberRequired
                ? [Validators.required, this.validationService.phoneValidator(), this.validationService.mobilePhoneValidator()]
                : []
            ]
          });
          this.appService.markFormGroupTouched(this.updatePhoneForm);
        }
        break;
    }
  }

  cancelEdit(updateType: string) {
    switch (updateType) {
      case UPDATE_TYPE.EMAIL:
        this.showEdit.email = false;
        this.prefService.isChannelEditCancelled.next({
          channel: 'Email',
          status: true
        });
        break;
      case UPDATE_TYPE.PHONE:
        if (!(this.profileInfo?.updatedPhoneNumber || this.profileInfo?.phoneNumber)) {
          this.store.dispatch(new SetUpdatedCommChannel(UPDATE_TYPE.PHONE, DEFAULT_PHONE_NUM));
        }
        this.showEdit.phone = false;
        this.prefService.isChannelEditCancelled.next({
          channel: 'SMS',
          status: true
        });
    }
  }

  onUpdateProfile(type: string) {
    let payload: any;
    this.store.dispatch(new UpdateConsentState('N'));
    switch (type) {
      case UPDATE_TYPE.PHONE:
        this.prefService.onChannelSaveClicked.next({
          channel: 'SMS',
          status: true
        });
        payload = Object.assign({}, this.updatePhoneForm.value);
        payload.phoneNumber = payload.phoneNumber.replace(NON_DIGIT_REGEX, '');
        if (!payload.phoneNumber) {
          payload.phoneNumber = DEFAULT_PHONE_NUM;
        }
        if (!this.profileInfo.isVerifiedMobile || this.profileInfo.phoneNumber !== payload.phoneNumber) {
          this.showEdit.phone = false;
          this.store.dispatch(new SetUpdatedCommChannel(UPDATE_TYPE.PHONE, payload.phoneNumber));
        }
        break;
      case UPDATE_TYPE.EMAIL:
        this.prefService.onChannelSaveClicked.next({
          channel: 'Email',
          status: true
        });
        payload = Object.assign({}, this.updateEmailForm.value);
        if (!this.profileInfo.isVerifiedEmail || this.profileInfo.emailAddress !== payload.emailAddress) {
          this.showEdit.email = false;
          this.store.dispatch(new SetUpdatedCommChannel(UPDATE_TYPE.EMAIL, payload.emailAddress));
        }
        break;
    }
  }

  get isSaveEmailDisabled() {
    return (
      !this.updateEmailForm.valid ||
      this.isActiveUser === 'false' ||
      (this.profileInfo?.updatedEmailAddress?.toLowerCase() || this.profileInfo?.emailAddress?.toLowerCase()) ===
        this.updateEmailForm.get('emailAddress').value?.toLowerCase()
    );
  }

  get isSaveMobileDisabled() {
    return (
      !this.updatePhoneForm.valid ||
      this.isActiveUser === 'false' ||
      (this.profileInfo?.updatedPhoneNumber || this.profileInfo?.phoneNumber) ===
        this.updatePhoneForm.get('phoneNumber').value?.replace(NON_DIGIT_REGEX, '')
    );
  }

  validateEmailAndPhone() {
    const emailAddress = this.profileInfo?.updatedEmailAddress || this.profileInfo?.emailAddress;
    const phoneNumber = this.profileInfo?.updatedPhoneNumber || this.profileInfo?.phoneNumber;
    if (!emailAddress) {
      this.onEdit('email');
      this.alertService.setAlert(EMAIL_PHONE_NOT_AVAILABLE, '', AlertType.Failure, 'profileInfoAlert');
    } else if (
      !phoneNumber ||
      (this.isPhoneNumberRequired && !this.isValidPhoneNumber(phoneNumber)) ||
      (this.showEdit.phone && !this.isPhoneNumberRequired)
    ) {
      if (!phoneNumber || this.showEdit.phone) {
        this.showEdit.phone = false;
        this.cancelEdit('phone');
      }
      this.onEdit('phone');
      this.alertService.setAlert(EMAIL_PHONE_NOT_AVAILABLE, '', AlertType.Failure, 'profileInfoAlert');
    } else if (this.profileInfo.isVerifiedEmail || this.profileInfo.isVerifiedMobile) {
      this.alertService.setAlert(EMAIL_NOT_VERIFIED_LABEL, '', AlertType.Failure, 'communication');
    }
  }

  isValidPhoneNumber(phoneNumber) {
    let isValidPhoneNum = /^\d{10}$/.test(phoneNumber);
    if (isValidPhoneNum) {
      const firstPart = phoneNumber && phoneNumber.replace(/[\(\)-]/g, '').slice(0, 3);
      if (firstPart && (firstPart.startsWith('1') || firstPart.startsWith('0'))) {
        isValidPhoneNum = false;
      } else {
        isValidPhoneNum = ['000', '555', '999'].indexOf(firstPart) === -1;
      }
    }
    return isValidPhoneNum;
  }

  ngOnDestroy() {
    this.showEdit.phone = false;
    this.showEdit.email = false;
    this.destroy$.next();
    this.destroy$.complete();
  }
}
