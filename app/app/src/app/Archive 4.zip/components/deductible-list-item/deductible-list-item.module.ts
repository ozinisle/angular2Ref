import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { DeductibleListItemComponent } from './deductible-list-item.component';

@NgModule({
  imports: [CommonModule, IonicModule],
  exports: [DeductibleListItemComponent],
  declarations: [DeductibleListItemComponent]
})
export class DeductibleListItemModule {}
