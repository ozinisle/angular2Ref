import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { DeductibleModel } from '../../models/deductible.model';

@Component({
  selector: 'app-deductible-list-item',
  templateUrl: './deductible-list-item.component.html',
  styleUrls: ['./deductible-list-item.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DeductibleListItemComponent {
  @Input() deductible: DeductibleModel;

  getProgressValue(deductibleData) {
    if (deductibleData.limitations === "$0.00 per plan year for Enhanced Benefits Tier"
     && deductibleData.exceptions === "Deductible does not apply to the Selected Standard Benefits Tier Hospitals.") {
      return 0;
    }
      return (deductibleData.contributed / deductibleData.totalAmount);
  }
}
