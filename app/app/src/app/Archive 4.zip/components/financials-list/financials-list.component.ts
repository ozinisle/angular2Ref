import { Component, OnInit, Input, ViewChild, AfterViewInit, ViewChildren, QueryList, Renderer2 } from '@angular/core';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { Select, Store } from '@ngxs/store';
import { IonSlide, IonSlides } from '@ionic/angular';
import { Finanical } from '@app/models/finanical.model';
import { Observable } from 'rxjs';
import { HomePageAppInfoModel } from '@app/pages/home/home.model';
import { Router } from '@angular/router';
import { GetFinancialInfo } from '@app/store/actions/app.actions';
import { delay, filter } from 'rxjs/operators';

@Component({
  selector: 'app-financials-list',
  templateUrl: './financials-list.component.html',
  styleUrls: ['./financials-list.component.scss']
})
export class FinancialsListComponent implements OnInit, AfterViewInit {
  @Input() isSlidesOnly = false;
  @Input() showTransactions = false;
  slideOpts: any = {
    autoHeight: false,
    pagination: false
  };

  @ViewChild('financialSlides', { static: false }) financialSlides: IonSlides;
  @ViewChildren('slides') slides: QueryList<IonSlide>;
  @SelectSnapshot(AppSelectors.getFinancialsInfo) financialInfo: Finanical[];
  @Select(AppSelectors.isLoadingFinancial) isLoadingFinancial$: Observable<boolean>;
  @SelectSnapshot(AppSelectors.getMemberInfo) memberInfo: HomePageAppInfoModel;
  @SelectSnapshot(AppSelectors.isAuthenticatedUser) isAuthenticatedUser: string;

  isFinancialView = false;

  isRegisteredUser = false;
  progressChartValue: number;

  activeSlide = 0;

  constructor(private router: Router, private store: Store, private renderer: Renderer2) {}

  ngOnInit() {
    if (this.isAuthenticatedUser && this.hasFinancialsData()) {
      this.store.dispatch(new GetFinancialInfo());
    }
    this.isLoadingFinancial$
      .pipe(
        filter(loading => !loading),
        delay(0)
      )
      .subscribe(() => {
        setTimeout(() => {
          this.financialSlides.ionSlideDidChange.subscribe(async () => {
            this.activeSlide = await this.financialSlides.getActiveIndex();
          });
          if (this.showTransactions) {
            let maxHeight = 0;
            this.slides.forEach((slide: any) => {
              maxHeight = slide.el.offsetHeight > maxHeight ? slide.el.offsetHeight : maxHeight;
            });
            if (maxHeight) {
              this.slides.forEach((slide: any) => {
                this.renderer.setStyle(slide.el, 'height', `${maxHeight}px`);
              });
            }
          }
        }, 1000);
      });
  }

  ngAfterViewInit() {}

  gotoSlide(i: number) {
    this.financialSlides.slideTo(i);
  }

  nextFinanceInfo(e) {
    e.stopPropagation();
    this.financialSlides.slideNext();
  }

  previousFinanceInfo(e) {
    e.stopPropagation();
    this.financialSlides.slidePrev();
  }

  goToVerify() {
    this.router.navigateByUrl('register/register-detail');
  }

  hasFinancialsData() {
    const hasALG = this.memberInfo?.hasALG?.toString().toLowerCase();
    const hasHEQ = this.memberInfo?.hasHEQ?.toString().toLowerCase();
    const result = this.memberInfo && (hasALG === 'yes' || hasHEQ === 'yes' || hasHEQ === 'true' || hasALG === 'true');
    this.isFinancialView = result;
    return result;
  }
}
