import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FinancialsListComponent } from './financials-list.component';
import { IonicModule } from '@ionic/angular';
import { FinancialModule } from '../financial/financial.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  declarations: [FinancialsListComponent],
  imports: [CommonModule, IonicModule, FinancialModule, FontAwesomeModule],
  exports: [FinancialsListComponent]
})
export class FinancialsListModule {}
