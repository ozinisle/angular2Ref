export interface BreadCrumb {
  label: string;
  url: any[];
  queryParams?:any;
}
