import { Component, Input, OnChanges, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { Capacitor } from '@capacitor/core';
import { BreadCrumb } from './breadcrumbs';
// import { MyDoctorsPcpService } from '../../../pages/mydoctors-pcp/mydoctors-pcp.service';

@Component({
  selector: 'app-breadcrumbs',
  templateUrl: './breadcrumbs.component.html',
  styleUrls: ['./breadcrumbs.component.scss']
})
export class BreadcrumbsComponent implements OnInit, OnChanges, OnDestroy {
  isMedicarePPO: boolean = false;
  breadcrumbs$: BreadCrumb[];
  routerEvents: any;
  @Input('breadCrumbs') breadCrumbs: BreadCrumb[];

  constructor(private activatedRoute: ActivatedRoute, private router: Router) {
    // this.isMedicarePPO = this.myDoctorsPcpService.memberInfo && this.myDoctorsPcpService.memberInfo.isMedicarePPO ? true : false;
  }
  ngOnChanges() {
    this.breadcrumbs$ = this.breadCrumbs;
  }
  ngOnDestroy() {
    if (this.routerEvents) {
      this.routerEvents.unsubscribe();
    }
  }
  ngOnInit() {
  if(Capacitor.isNative){
    this.breadcrumbs$ = [];
  
  } else {
    this.breadcrumbs$ = this.breadCrumbs;
    if (!(this.breadCrumbs && this.breadCrumbs.length)) {
      this.breadcrumbs$ = this.buildBreadCrumb(this.activatedRoute.root);
      this.routerEvents = this.router.events.subscribe((event: any) => {
        if (event instanceof NavigationEnd) {
          this.breadcrumbs$ = this.buildBreadCrumb(this.activatedRoute.root);
        }
      });
    }
  }
  
  }

  getLabel(param: string) {
    let Label = param;
    switch (param) {
      case 'claimdetails':
        Label = 'Claim Details';
        break;
      case 'claimstatusdetails':
        Label = 'Claim Status Details';
        break;
      case 'race':
        Label = 'Race Ethnicity Language';
        break;
      case 'updatePassword':
        Label = 'Update Password';
        break;
      case 'Add PCP':
        Label = this.isMedicarePPO ? 'Elect POC' : 'Elect PCP';
        break;
      case 'Update PCP':
        Label = this.isMedicarePPO ? 'Update POC' : 'Update PCP';
        break;
    }
    return Label;
  }

  openInAppBrowser(url) {
   
      this.router.navigate(url);
    
  }

  buildBreadCrumb(route: ActivatedRoute, urlArray: any[] = [], breadcrumbs: any[] = []): BreadCrumb[] {
    let newBreadCrumbs = JSON.parse(JSON.stringify(breadcrumbs));
    let newUrlArray = JSON.parse(JSON.stringify(urlArray));
    // skip the bread crumb if empty and home
    if (route.routeConfig && route.routeConfig.path) {
      const label = this.getLabel(route.routeConfig.data['breadcrumb']);
      const keys = Object.keys(route.snapshot.params);
      if (!urlArray.length) {
        newBreadCrumbs.push({
          label: 'Home',
          url: '/home',
          isActive: true
        });
      }
      if (!keys.length) {
        const routePaths = route.routeConfig.path;
        const path = !urlArray.length ? `/${routePaths}` : `${routePaths}`;
        newUrlArray.push(path);
        newBreadCrumbs.push({
          label: label,
          url: newUrlArray,
          isActive: true // !route.snapshot.component ? false : true
        });
      }
      Object.keys(route.snapshot.params).forEach((param, sIndex) => {
        const breadCrumbLabel = this.getLabel(route.snapshot.params[param]);
        newUrlArray = [...newUrlArray, route.snapshot.params[param]];
        newBreadCrumbs = [
          ...newBreadCrumbs,
          {
            label: breadCrumbLabel,
            url: newUrlArray,
            isActive: true
          }
        ];
      });
    }
    if (route.firstChild) {
      return this.buildBreadCrumb(route.firstChild, newUrlArray, newBreadCrumbs);
    }
    let finalbreadcrumb;
    const benefitsArray = [
      { label: 'Home', url: '/home', isActive: true },
      { label: 'My Plans', url: ['/myplans'], isActive: true },
      { label: 'Plan Details', url: ['/myplans', 'plandetails'], isActive: true },
      { label: 'Plan Benefits', url: ['/myplans', 'benefits'], isActive: true }
    ];
    newBreadCrumbs.forEach(res => {
      if (res.label === 'Plan Benefits') {
        finalbreadcrumb = benefitsArray;
      } else if (res.label === 'Benefit Details') {
        benefitsArray.push({ label: 'Benefit Details', url: ['/myplans', 'benefitdetails'], isActive: true });
        finalbreadcrumb = benefitsArray;
      } else {
        finalbreadcrumb = newBreadCrumbs;
      }
    });
    return finalbreadcrumb;
  }
}
