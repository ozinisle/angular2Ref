import { Component, Input, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { IabService } from '@app/services/iab.service';
import { PromosService } from '@app/services/promos.service';
import { PreferenceSelectors } from '@app/store/selectors/preference.selectors';
import { Select } from '@ngxs/store';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-promo-images',
  templateUrl: './promo-images.component.html',
  styleUrls: ['./promo-images.component.scss']
})
export class PromoImagesComponent implements OnInit, OnDestroy {
  @SelectSnapshot(PreferenceSelectors.getPreferences) preferences: any;
  @Input() images: any[];
  @Input() type: string;
  @Input() fromHomePage = false;
  imagesResponse: any[];
  carouselVideoSource = '';
  destroy$: Subject<boolean> = new Subject<boolean>();

  @Select(PreferenceSelectors.getPaperlessPromoFlag) getPaperlessPromoFlag$: any;

  constructor(
    private promoService: PromosService,
    private router: Router,
    private iabService: IabService,
    private cdRef: ChangeDetectorRef
  ) {}

  ngOnInit() {
    if (this.images) {
      this.imagesResponse = [];
      for (const image of this.images) {
        image.pipe(takeUntil(this.destroy$)).subscribe(response => {
          const currentItemIndex = this.imagesResponse.findIndex(img => img.Index === response.Index);
          if (currentItemIndex > -1) {
            this.imagesResponse[currentItemIndex] = response;
          } else {
            this.imagesResponse.push(response);
            if (response && response.ArticleText && response.ArticleText.includes('Well Connection')) {
              sessionStorage.setItem('well_connection_link', response.ArticleUrl);
            }
          }
          this.cdRef.detectChanges();
        });
      }
    }
  }

  handleUrl(url: string) {
    this.promoService.openUrl(url, this.fromHomePage);
  }

  openUrl(url) {
    let paperlessPromo;
    this.getPaperlessPromoFlag$.subscribe(res => {
      paperlessPromo = res;
    });

    if (this.type === 'preferencespromo') {
      if (paperlessPromo) {
        this.router.navigate(['myprofile/communication-preferences']);
      } else {
        this.handleUrl(url);
      }
    } else {
      this.promoService.openUrl(url, this.fromHomePage);
    }
  }

  openVideoModal(event, videoSourceUrl: string) {
    event.stopPropagation();
    this.carouselVideoSource = videoSourceUrl;
  }

  closeVideoModal() {
    this.carouselVideoSource = '';
  }
  openInAppBrowser(url) {
    this.iabService.create(url, this.fromHomePage);
  }

  ngOnDestroy(): void {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
  }
}
