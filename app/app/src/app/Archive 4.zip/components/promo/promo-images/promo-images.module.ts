import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { PromoImagesComponent } from './promo-images.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  imports: [CommonModule, IonicModule, FontAwesomeModule],
  exports: [PromoImagesComponent],
  declarations: [PromoImagesComponent]
})
export class PromoImagesModule {}
