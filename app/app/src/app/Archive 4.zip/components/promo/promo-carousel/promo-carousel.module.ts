import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { PromoCarouselComponent } from './promo-carousel.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  imports: [CommonModule, IonicModule, FontAwesomeModule],
  exports: [PromoCarouselComponent],
  declarations: [PromoCarouselComponent]
})
export class PromoCarouselModule {}
