import { Component, Input, ViewChild } from '@angular/core';
import { IonSlides } from '@ionic/angular';
import { Image } from '../../../models/image.model';
import { PromosService } from '../../../services/promos.service';

@Component({
  selector: 'app-promo-carousel',
  templateUrl: './promo-carousel.component.html',
  styleUrls: ['./promo-carousel.component.scss']
})
export class PromoCarouselComponent {
  @Input() carouselItems: Image[];
  @Input() fromHomePage: boolean;

  carouselVideoSource = '';

  @ViewChild('slides') slides: IonSlides;

  constructor(private promoService: PromosService) {}

  sliderOptions = { autoHeight: true };

  onPrev() {
    this.slides.isBeginning().then(isBeginning => {
      if (!isBeginning) {
        this.slides.slidePrev();
      }
    });
  }

  onNext() {
    this.slides.isEnd().then(isEnd => {
      if (!isEnd) {
        this.slides.slideNext();
      }
    });
  }

  openVideoModal(videoSourceUrl: string) {
    this.carouselVideoSource = videoSourceUrl;
  }

  closeVideoModal() {
    this.carouselVideoSource = '';
  }

  openUrl(url) {
    this.promoService.openUrl(url, this.fromHomePage);
  }
}
