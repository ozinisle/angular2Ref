import { Component, OnInit, Input } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { IabService } from '@app/services/iab.service';

@Component({
  selector: 'app-mass-gov-leave-component',
  templateUrl: './mass-gov-leave-component.component.html',
  styleUrls: ['./mass-gov-leave-component.component.scss']
})
export class MassGovLeaveComponent implements OnInit {
  @Input() href: string;

  constructor(public modalController: ModalController, private iabService: IabService) {}

  ngOnInit() {}

  closeModals() {
    this.modalController.dismiss({
      dismissed: true
    });
  }
  continue() {
    this.iabService.create(this.href);
  }
}
