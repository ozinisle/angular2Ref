import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { MassGovLeaveComponent } from '@app/components/mass-gov-leave-component/mass-gov-leave-component.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  imports: [CommonModule, IonicModule, FontAwesomeModule],
  exports: [MassGovLeaveComponent],
  declarations: [MassGovLeaveComponent]
})
export class MassGovLeaveModule {}
