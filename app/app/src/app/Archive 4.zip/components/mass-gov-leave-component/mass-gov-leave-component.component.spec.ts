import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { MassGovLeaveComponent } from './mass-gov-leave-component.component';
import { IonicModule, ModalController } from '@ionic/angular';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';

xdescribe('MassGovLeaveComponent', () => {
  let component: MassGovLeaveComponent;
  let fixture: ComponentFixture<MassGovLeaveComponent>;

  const modalSpy = jasmine.createSpyObj('Modal', ['present']);
  const modalCtrlSpy = jasmine.createSpyObj('ModalController', ['create']);
  modalCtrlSpy.create.and.callFake(() => {
    return modalSpy;
  });

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [IonicModule],
      providers: [
        InAppBrowser,
        {
          provide: ModalController,
          useValue: modalCtrlSpy
        }
      ],
      declarations: [MassGovLeaveComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MassGovLeaveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
