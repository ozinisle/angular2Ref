import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { TelehealthCampaignMobileComponent } from './telehealth-campaign-mobile.component';

@NgModule({
  imports: [CommonModule, IonicModule],
  exports: [TelehealthCampaignMobileComponent],
  declarations: [TelehealthCampaignMobileComponent]
})
export class TelehealthCampaignMobileModule {}
