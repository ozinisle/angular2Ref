import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { AlegeusLineChartComponent } from '@app/components/alegeus-line-chart/line-chart.component';

@NgModule({
  imports: [CommonModule, IonicModule],
  exports: [AlegeusLineChartComponent],
  declarations: [AlegeusLineChartComponent]
})
export class AlegeusLinechartModule {}
