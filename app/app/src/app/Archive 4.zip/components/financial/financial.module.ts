import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { AbsoluteNumberModule } from '@app/pipes/absolute-number/absolute-number.module';
import { IonicModule } from '@ionic/angular';
import { FinancialComponent } from './financial.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  imports: [CommonModule, IonicModule, AbsoluteNumberModule, FontAwesomeModule],
  exports: [FinancialComponent],
  declarations: [FinancialComponent]
})
export class FinancialModule {}
