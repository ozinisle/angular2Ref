import { ChangeDetectionStrategy, Component, Input, OnInit } from '@angular/core';
import { SsoService } from '@app/pages/sso/sso.service';
import { environment } from '@environments/environment';
import { Finanical } from '@app/models/finanical.model';

@Component({
  selector: 'app-financial',
  templateUrl: './financial.component.html',
  styleUrls: ['./financial.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class FinancialComponent implements OnInit {
  @Input() account: Finanical;
  @Input() showTransactions = false;

  progressChartValue: number;
  isHeqTransactionsEnabled: boolean;
  ismobile: boolean;
  mobileViewPort = 991;

  constructor(
    private ssoService: SsoService
  ) {
    this.isHeqTransactionsEnabled = environment.showFinancialTransactions;
    this.ismobile = window.innerWidth <= this.mobileViewPort;
  }

  ngOnInit() {
  }

  getProgressValue(financial) {
    return financial?.chartOptions?.totalValue / (financial?.chartOptions?.totalValue + financial?.chartOptions?.chartValue) || 0;
  }

  goToDetails(financial) {
    const impersonate = environment.impersonation;
    if (!impersonate) {
      if (financial.isHeqAccount) {
        this.ssoService.openSSO('heq');
      } else {
        this.ssoService.openSSO('alg');
      }
    }
  }
}
