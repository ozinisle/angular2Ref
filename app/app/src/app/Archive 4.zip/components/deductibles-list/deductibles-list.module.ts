import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { DeductiblesListComponent } from './deductibles-list.component';
import { DeductibleModule } from '../deductible/deductible.module';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [CommonModule, IonicModule, DeductibleModule, RouterModule],
  exports: [DeductiblesListComponent],
  declarations: [DeductiblesListComponent]
})
export class DeductiblesListModule {}
