import { Component, OnInit, ViewChild, Input, OnDestroy } from '@angular/core';
import { DeductibleSelectors } from '@app/store/selectors/deductible.selectors';
import { DeductibleModel } from '@app/models/deductible.model';
import { IonSlides } from '@ionic/angular';
import { SelectSnapshot } from '@ngxs-labs/select-snapshot';
import { Store, Select } from '@ngxs/store';
import { GetFamilyDeductibles } from '@app/store/actions/deductible.actions';
import { AppSelectors } from '@app/store/selectors/app.selectors';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-deductibles-list',
  templateUrl: './deductibles-list.component.html',
  styleUrls: ['./deductibles-list.component.scss']
})
export class DeductiblesListComponent implements OnInit, OnDestroy {
  @Input() isSlidesOnly = false;
  medicalCovTile = [];
  dentalCovTile = [];
  visionCovTile = [];
  destroy$ = new Subject<void>();

  @SelectSnapshot(AppSelectors.getUserID) useridin: string;

  @Select(DeductibleSelectors.getOverallFamilyDeductibles) deductibles$: Observable<DeductibleModel[]>;
  @SelectSnapshot(DeductibleSelectors.loadingDeductibles) isLoadingDeductibles: boolean;

  @ViewChild('deductibleSlides') public deductibleSlides: IonSlides;

  constructor(private store: Store) {
    this.store.dispatch(new GetFamilyDeductibles(this.useridin, false));
  }

  ngOnInit() {
    this.getDeductible();
  }

  nextSlide(e) {
    e.stopPropagation();
    this.deductibleSlides.slideNext();
  }

  previousSlide(e) {
    e.stopPropagation();
    this.deductibleSlides.slidePrev();
  }

  private getDeductible() {
    this.deductibles$.pipe(takeUntil(this.destroy$)).subscribe(data => {
      if (data) {
        const medicalCoverage = data.filter(
          item =>
            item.coverageType.toLowerCase() === 'medical' ||
            (item.coverageType.toLowerCase() !== 'dental' && item.coverageType.toLowerCase() !== 'vision')
        );
        const dentalCoverage = data.filter(item => item.coverageType.toLowerCase() === 'dental');
        const visionCoverage = data.filter(item => item.coverageType.toLowerCase() === 'vision');
        this.medicalTile(medicalCoverage);
        this.dentalTile(dentalCoverage);
        this.visionTile(visionCoverage);
      }
    });
  }

  private medicalTile(medicalData) {
    if (medicalData) {
      this.medicalCovTile = [];
      const fdcMedCoverage = medicalData.filter(item => item.type === 'First Coverage');
      const overallDeductibleMedCoverage = medicalData.filter(item => item.type === 'Overall Deductible');
      const outOfPocketMedCoverage = medicalData.filter(item => item.type === 'Out-Of-Pocket Maximum');
      const overallBenefit = medicalData.filter(item => item.type === 'Overall Benefit');
      const itemTypeNotExist = medicalData.filter(item => !item.type);
      if (fdcMedCoverage?.length > 0 && fdcMedCoverage[0]?.contributed < 500) {
        this.medicalCovTile = fdcMedCoverage;
      } else if (overallDeductibleMedCoverage?.length > 0) {
        this.medicalCovTile = overallDeductibleMedCoverage;
      } else if (outOfPocketMedCoverage?.length > 0) {
        this.medicalCovTile = outOfPocketMedCoverage;
      } else if (overallBenefit?.length > 0) {
        this.medicalCovTile = overallBenefit;
      } else if (itemTypeNotExist?.length > 0) {
        this.medicalCovTile = itemTypeNotExist;
      } else {
        this.medicalCovTile = [];
      }
    }
  }

  private dentalTile(dentalData) {
    if (dentalData) {
      this.dentalCovTile = [];
      const fdcMedCoverage = dentalData.filter(item => item.type === 'First Coverage');
      const overallDeductibleMedCoverage = dentalData.filter(item => item.type === 'Overall Deductible');
      const outOfPocketMedCoverage = dentalData.filter(item => item.type === 'Out-Of-Pocket Maximum');
      const itemTypeNotExist = dentalData.filter(item => !item.type);
      const overallBenefit = dentalData.filter(item => item.type === 'Overall Benefit');
      if (fdcMedCoverage?.length > 0 && fdcMedCoverage[0]?.contributed < 500) {
        this.dentalCovTile = fdcMedCoverage;
      } else if (overallDeductibleMedCoverage?.length > 0) {
        this.dentalCovTile = overallDeductibleMedCoverage;
      } else if (outOfPocketMedCoverage?.length > 0) {
        this.dentalCovTile = outOfPocketMedCoverage;
      } else if (overallBenefit?.length > 0) {
        this.dentalCovTile = overallBenefit;
      } else if (itemTypeNotExist?.length > 0) {
        this.dentalCovTile = itemTypeNotExist;
      } else {
        this.dentalCovTile = [];
      }
    }
  }

  private visionTile(visionData) {
    if (visionData) {
      this.visionCovTile = [];
      const fdcMedCoverage = visionData.filter(item => item.type === 'First Coverage');
      const overallDeductibleMedCoverage = visionData.filter(item => item.type === 'Overall Deductible');
      const outOfPocketMedCoverage = visionData.filter(item => item.type === 'Out-Of-Pocket Maximum');
      const itemTypeNotExist = visionData.filter(item => !item.type);
      const overallBenefit = visionData.filter(item => item.type === 'Overall Benefit');
      if (fdcMedCoverage?.length > 0 && fdcMedCoverage[0]?.contributed < 500) {
        this.visionCovTile = fdcMedCoverage;
      } else if (overallDeductibleMedCoverage?.length > 0) {
        this.visionCovTile = overallDeductibleMedCoverage;
      } else if (outOfPocketMedCoverage?.length > 0) {
        this.visionCovTile = outOfPocketMedCoverage;
      } else if (overallBenefit?.length > 0) {
        this.visionCovTile = overallBenefit;
      } else if (itemTypeNotExist?.length > 0) {
        this.visionCovTile = itemTypeNotExist;
      } else {
        this.visionCovTile = [];
      }
    }
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
