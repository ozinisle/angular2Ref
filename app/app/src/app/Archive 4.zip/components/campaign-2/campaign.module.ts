import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { Campaign2Component } from '@app/components/campaign-2/campaign-2.component';

@NgModule({
  imports: [CommonModule, IonicModule],
  exports: [Campaign2Component],
  declarations: [Campaign2Component]
})
export class CampaignModule {}
