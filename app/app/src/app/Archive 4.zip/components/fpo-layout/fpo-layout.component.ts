import { HttpClient } from '@angular/common/http';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { SsoService } from '@app/pages/sso/sso.service';
import { ConstantsService } from '@app/services/constants.service';
import { IabService } from '@app/services/iab.service';
import { environment } from '@environments/environment';
import { v4 as uuid } from 'uuid';

@Component({
  selector: 'app-fpo-layout',
  templateUrl: './fpo-layout.component.html',
  styleUrls: ['./fpo-layout.component.scss']
})
export class FpoLayoutComponent implements OnInit {
  @Input() targetUrl: string;
  @Input() toolTipdataPlans: object;
  @Input() isplandetails: boolean;
  @Input() displayCategory: string;
  @Input() layout = '';
  @Input() showTitle = false;
  @Output() closePullTextEmitter = new EventEmitter();
  @Input() benefitPage: boolean;
  @Input() hasCvsLinkFlag: boolean;
  fpocontentData: any;
  fontawesomeIcon: any;
  bodyContent = '';
  fpoVideoSourceUrl: string;
  drupalvideolayout: string;
  temp: string;
  applyButtonURL: string;
  enableOTCLink : boolean;

  constructor(
    private http: HttpClient,
    private router: Router,
    private iabService: IabService,
    private constantsService: ConstantsService,
    private ssoService: SsoService,
  ) {
    this.drupalvideolayout = uuid();
    this.enableOTCLink = environment.enableOTCLink;
  }

  ngOnInit() {
    if (this.toolTipdataPlans && this.isplandetails) {
      this.prepareDrupalContent(this.toolTipdataPlans);
    } else if (this.targetUrl) {
      this.http.get(this.targetUrl).subscribe(response => {
        this.prepareDrupalContent(response);
      });
    }
    this.temp = '#' + this.drupalvideolayout;
  }

  prepareDrupalContent(response?) {
    if (response && response[0]) {
      this.fpocontentData = response[0];
      this.fpocontentData.RegularImages = this.fpocontentData.RegularImages
        ? environment.drupalUrl  + '/' + this.fpocontentData.RegularImages
        : this.fpocontentData.RegularImages;
      this.fpocontentData.MobileImages = this.fpocontentData.MobileImages
        ? environment.drupalUrl  + '/' + this.fpocontentData.MobileImages
        : this.fpocontentData.MobileImages;

      if (this.fpocontentData.FontawesomeIconClass) {
        const faClass = this.fpocontentData.FontawesomeIconClass.split(" ", 2);
        this.fontawesomeIcon = [faClass[0], faClass[1].replace("fa-", "")];
      } else { this.fontawesomeIcon = ''; }



      let url: string = this.fpocontentData.AppstoreIcon;
      url = url.replace('<img src="', '').trim();
      this.fpocontentData.AppstoreIcon = '<img src="' + this.constantsService.drupalUrl  + '/' + url;
      url = this.fpocontentData.GoogleplayIcon;
      url = url.replace('<img src="', '').trim();
      this.fpocontentData.GoogleplayIcon = '<img src="' + this.constantsService.drupalUrl  + '/' + url;
      this.bodyContent = this.fpocontentData.Body.replace('<p>', '').replace('</p>', '');
      const thumbnail = this.fpocontentData.VideoThumbnailIcon;
      if (thumbnail) {
        this.fpocontentData.VideoThumbnailIconSrc = environment.drupalUrl;
      }
      this.applyButtonURL = this.fpocontentData.APPButtonUrl ? this.fpocontentData.APPButtonUrl : this.fpocontentData.ButtonUrl;
    }
  }

  openVideoModal(event) {
    event.stopPropagation();
    this.fpoVideoSourceUrl = this.fpocontentData.VideoUrl;
  }

  closeVideoModal() {
    this.fpoVideoSourceUrl = '';
  }

  openUrl(url: string) {
    if (url?.startsWith('internal:')) {
      const routingTarget = url.replace('internal:', '');
      this.router.navigate([routingTarget]);
    } else if (url) {
      this.iabService.create(url);
    }
  }

  navigateOTCLink(){
    this.ssoService.openSSO('otcCvsLink');
  }

  checkAnchorClick($event: any) {
    if ($event?.target?.href?.indexOf('http') > -1) {
      $event.preventDefault();
      this.iabService.create($event.target.href);
    }
  }
}
