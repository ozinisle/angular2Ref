import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { FpoLayoutComponent } from '@app/components/fpo-layout/fpo-layout.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

@NgModule({
  imports: [CommonModule, IonicModule, FontAwesomeModule],
  exports: [FpoLayoutComponent],
  declarations: [FpoLayoutComponent]
})
export class FpoLayoutModule {}
