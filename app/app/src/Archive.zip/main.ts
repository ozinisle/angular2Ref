import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { MYBLUE } from '@app/app.constants';
import { AppModule } from '@app/app.module';
import { EnvironmentService } from '@app/services/environment/environment.service';
import { environment } from '@environments/environment';
import { version } from '@environments/version';

// Display version number
console.log('%cBuild version:', 'background: #222; color: #bada55', `${version.build} (${version.appversion})`);

// Activate angular prod mode if needed
if (environment.enableAngularProdMode) {
  enableProdMode();
}

// Disable console logs if needed
if (!environment.enableconsolelog) {
  window.console.log = () => {};
  window.console.warn = () => {};
  window.console.error = () => {};

  MYBLUE.log = () => {};
  MYBLUE.warn = () => {};
  MYBLUE.error = () => {};
}

/**
 * Overide sessionStorage clear() to not clear all element in the session storage.
 * Indeed the environment service overrides are stored in the session storage and we
 * want to keep them.
 */
Storage.prototype.oldClear = Storage.prototype.clear;
Storage.prototype.clear = function() {
  // Save session element to keep
  const toKeep = {};
  for (const x in this) {
    if (x.startsWith(EnvironmentService.SESSION_STORAGE_PREFIX) && this.hasOwnProperty(x)) {
      toKeep[x] = this[x];
    }
  }
  // Clear the session
  Storage.prototype.oldClear.apply(this);
  // Restore in session the element to keep
  for (const x in toKeep) {
    if (toKeep.hasOwnProperty(x)) {
      this.setItem(x, toKeep[x]);
    }
  }
};

// Launch angular
platformBrowserDynamic().bootstrapModule(AppModule);
