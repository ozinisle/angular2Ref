setTimeout(()=>{
    var htmlElement = document.getElementById('ssoDiv');

    htmlElement.innerHTML =
    "<FORM METHOD='POST' ACTION='https://test.authsso.bluecrossma.com/s44314/heq'>" +
    "<INPUT TYPE='HIDDEN' NAME='NameValue' VALUE='c2baUGtIu+nfta4uPOZxOn6Anbl2eQ16mhprkWJuljKfKiOucO7aYc6Yev580wrQZ8cCP2hX7Yu+KU9VcxFTZEMaLU7Ec2/zWVPi5nezWhdOkBdhAbdWcSHNyNplfaOEKZEjyHaWtzVjXO8IQWEd4NGOyUT9uoQxnh0ubhhRsM61DvfC+yI0uxc7XhvsDlFkFAuSA5mxDlHYcqLII+LO3Y8wJFc8ZUDtTe1nw/sbZy7bzfnUy0lC2XYVst0e1ucaoh8BOECfszaWC/0iOndzKyo1jb7T3a3d+xfnakio69UWJG4nH8tNB1gSbKCXcIS/FES6KT3o2Vw/pokw2Xycyule/hAZPfZgF3k12oKZjOHm4WRCO3yZYwRC+ktQFwyrtDq4bDImqR4OeolLmIbDIb4Im5SFan0umh2yexBC2zTEE75+W3x+b5JBmO6uZ5AEriRWOjanxU+BBA8oJ6jRWv5b0T/BqD2JfBoIR0hyahyx6/2f9HjyvEQxFXq9y92dvgyiYbEByK96lo599+3K0u1eh6kzty07vrujCXiIcv3zXLvB59uvZpNCMUR9/2ZspOmMBcfzCxHR6uKBickPLOfPFNMCDIAF07VKgjl2tok='>" +
    "</FORM>";

    var currForm = htmlElement.children[0];currForm.submit();
}, 5000);
var logFunc =  function (){
 var htmlElement = document.getElementById('results');
 htmlElement.innerHTML = 'Hello';
}
