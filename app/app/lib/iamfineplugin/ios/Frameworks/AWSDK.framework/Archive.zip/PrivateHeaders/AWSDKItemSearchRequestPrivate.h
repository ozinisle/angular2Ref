//
//  AWSDKItemSearchRequestPrivate.h
//  AWSDK
//
//  Created by Caleb Lindsey on 5/14/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKDataObjectPrivate.h"

#import <AWSDK/AWSDKItemSearchRequest.h>

/**
 Represents a search request for fetching follow-up items, records, and reports.

 @since 6.2.0
 */
@interface AWSDKItemSearchRequest ()

- (nullable instancetype)initWithDictionary:(nonnull NSDictionary *)dict;

+ (nullable NSError *)validateSearchRequest:(nullable AWSDKItemSearchRequest *)searchRequest;

/**
 The number of items per search

 @since 6.2.0
 */
@property (nonatomic, readwrite) NSInteger pageSize;

/**
 The index of the initial item in the search

 @since 6.2.0
 */
@property (nonatomic, readwrite) NSInteger startIndex;

/**
 The earliest date of items in the search

 @since 6.2.0
 */
@property (nonatomic, nullable, readwrite) NSDate *startDate;

/**
 The latest date of items in the search

 @since 6.2.0
 */
@property (nonatomic, nullable, readwrite) NSDate *endDate;

@end
