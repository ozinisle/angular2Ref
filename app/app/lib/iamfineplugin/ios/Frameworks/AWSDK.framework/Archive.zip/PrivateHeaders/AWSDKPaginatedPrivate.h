//
//  AWSDKPaginatedPrivate.h
//  AWSDK
//
//  Created by Caleb Lindsey on 5/14/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKDataObjectPrivate.h"

#import <AWSDK/AWSDKPaginated.h>

// clang-format off
@protocol AWSDKItemSearchRequest;
// clang-format on

/**
 Represents a generic page of items.

 @since 6.2.0
 */
@interface AWSDKPaginated ()

/**
 The number of items per search

 @since 6.2.0
 */
@property (readonly) NSInteger limit;

/**
 The index of the initial item in the search

 @since 6.2.0
 */
@property (readonly) NSInteger startIndex;

/**
 The list of items returned by the search

 @since 6.2.0
 */
@property (nullable, readonly) NSArray<id<AWSDKDataObject>> *list;

/**
 The next page in the search if available

 @since 6.2.0
 */
@property (nullable, readonly) id<AWSDKItemSearchRequest> nextPage;

/**
 The previous page in the search if available

 @since 6.2.0
 */
@property (nullable, readonly) id<AWSDKItemSearchRequest> previousPage;

/**
 Returns true if the search has a next page

 @since 6.2.0
 */
@property (readonly) BOOL hasNextPage;

/**
 Returns true if the search has a previous page

 @since 6.2.0
 */
@property (readonly) BOOL hasPreviousPage;

@end
