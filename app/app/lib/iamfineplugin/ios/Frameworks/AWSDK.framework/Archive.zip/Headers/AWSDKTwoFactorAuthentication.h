//
//  AWSDKTwoFactorAuthentication.h
//  AWSDK
//
//  Created by Steve Trombley on 2/20/20.
//  Copyright © 2020 American Well. All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <AWSDK/AWSDKDataObject.h>
#import <AWSDK/AWSDKCompletionBlock.h>

/**
 An enum describing the configuration of two-factor authentication on the Amwell Home platform.

 @since 6.7.0
*/
typedef NS_ENUM(NSUInteger, AWSDKTwoFactorAuthenticationConfiguration) {

    /**
     Two-factor authentication is not enabled.
     @since 6.7.0
     */
    AWSDKTwoFactorAuthenticationConfigurationDisabled,
    /**
     Two-factor authentication is required.
     @since 6.7.0
     */
    AWSDKTwoFactorAuthenticationConfigurationRequired,
    /**
    Two-factor authentication is optional.
     @since 6.7.0
     */
    AWSDKTwoFactorAuthenticationConfigurationOptional
};

/**
 An enum describing the next action to be taken to complete two-factor authentication.

 @since 6.7.0
*/
typedef NS_ENUM(NSUInteger, AWSDKTwoFactorAuthenticationRequiredAction) {

    /**
     Two-factor authentication is disabled or complete.
     @since 6.7.0
     */
    AWSDKTwoFactorAuthenticationRequiredActionNone,
    /**
     Two-factor authentication login must be completed by requesting and then validating a verification code.
     @since 6.7.0
     */
    AWSDKTwoFactorAuthenticationRequiredActionLogin,
    /**
     Two-factor authentication must be set up by providing an SMS phone number or opting out. The process of setting up also completes authentication.
     @since 6.7.0
     */
    AWSDKTwoFactorAuthenticationRequiredActionSetup
};

@protocol AWSDKConsumerAuthentication;

/**
A second step is needed to complete authentication.

@since 6.7.0
*/
@protocol AWSDKTwoFactorAuthentication <AWSDKDataObject>

#pragma mark - Read-Only Properties
/**
 @name Read-Only Properties
 */

/**
 An enum indicating the next action needed to complete two-factor authentication.

 @since 6.7.0
 */
@property (readonly) AWSDKTwoFactorAuthenticationRequiredAction requiredAction;

/**
 An enum value describing if two-factor authentication is configured to be Required, Optional or Disabled.

 @since 6.7.0
 */
@property (readonly) AWSDKTwoFactorAuthenticationConfiguration configuration;

/**
 NSString with the last four digits of the phone number used for two-factor authentication, provided for display purposes. Will be null if setup is not complete.

 @since 6.7.0
 */
@property (readonly, nullable) NSString *phoneLastFourDigits;

/**
NSString with a token that can be used on subsequent authentication calls to skip two-factor authentication.

@since 6.7.0
*/
@property (readonly, nullable) NSString *trustDeviceToken;

/**
 Request that a verification code be sent via SMS to the two-factor authentication phone number.

 @param authentication A partially authenticated AWSDKConsumerAuthentication object.
 @param completion AuthenticationResultCompletionBlock containing an AWSDKConsumerAuthentication object or an error.

 @discussion This can be used to resend a verification code during setup or login.

 @exception AWSDKErrorCodeConsumerUnauthenticated                       The consumer is not authenticated.
 @exception AWSDKErrorCodeAuthenticationInvalidRequestForDevice         Two-factor authentication is either not available or already completed.
 @exception AWSDKErrorCodeTwoFactorAuthenticationInvalidPhoneNumber     The phone number for two-factor authentication is invalid.

 @since 6.7.0
*/
- (void)sendTwoFactorAuthenticationCode:(id<AWSDKConsumerAuthentication> _Nonnull)authentication completion:(AuthenticationResultCompletionBlock _Nonnull)completion;

/**
 Set up two-factor authentication. A verification code will be sent via SMS to the provided phone number. If an AWSDKConsumerAuthentication object is returned,
 the AWSDKTwoFactorAuthentication property, twoFactorAuthInfo, can be used to submit a verification code or request a new one.

 @param phoneNumber NSString representing the phone number that will receive verification codes for two-factor authentication.
 @param authentication A partially authenticated AWSDKConsumerAuthentication object.
 @param completion AuthenticationResultCompletionBlock containing an AWSDKConsumerAuthentication object or an error.

 @exception AWSDKErrorCodeConsumerUnauthenticated                       The consumer is not authenticated.
 @exception AWSDKErrorCodeAuthenticationInvalidRequestForDevice         Two-factor authentication is either not available or already completed.
 @exception AWSDKErrorCodeTwoFactorAlreadySetUp                         Two-factor authentication is already set up.
 @exception AWSDKErrorCodeTwoFactorAuthenticationInvalidPhoneNumber     The phone number for two-factor authentication is invalid.

 @since 6.7.0
*/
- (void)setupTwoFactorAuthenticationWithPhoneNumber:(NSString *_Nonnull)phoneNumber authentication:(id<AWSDKConsumerAuthentication> _Nonnull)authentication completion:(AuthenticationResultCompletionBlock _Nonnull)completion;

/**
 Opt-out of two-factor authentication.

 @param authentication A partially authenticated AWSDKConsumerAuthentication object.
 @param completion ConsumerResultCompletionBlock containing an AWSDKConsumer object or an error.

 @exception AWSDKErrorCodeConsumerUnauthenticated                       The consumer is not authenticated.
 @exception AWSDKErrorCodeAuthenticationInvalidRequestForDevice         Two-factor authentication is either not available or already completed.
 @exception AWSDKErrorCodeTwoFactorAlreadySetUp                         Two-factor authentication is already set up.
 @exception AWSDKErrorCodeAuthenticationRequired                        Two-factor authentication is required.

 @since 6.7.0
*/
- (void)optOutTwoFactorAuthentication:(id<AWSDKConsumerAuthentication> _Nonnull)authentication completion:(ConsumerResultCompletionBlock _Nonnull)completion;

/**
 Send a verification code to complete two-factor authentication. This will also complete two-factor authentication set up if successful.

 @param authCode NSString representing the verification code.
 @param rememberDevice BOOL set _TRUE_ to request a trusted device token that will allow the user to skip two-factor authentication on future authentication requests.
 @param authentication A partially authenticated AWSDKConsumerAuthentication object.
 @param completion ConsumerResultCompletionBlock containing the authenticated AWSDKConsumer if successful, or an error.

 @exception AWSDKErrorCodeConsumerUnauthenticated                       The consumer is not authenticated.
 @exception AWSDKErrorCodeAuthenticationInvalidRequestForDevice         Two-factor authentication is either not available or already completed.
 @exception AWSDKErrorCodeTwoFactorAuthenticationExpiredCode            The verification code for two-factor authentication has expired.
 @exception AWSDKErrorCodeTwoFactorAuthenticationMaxRetryReached        The maximum allowed attempts for entering verification code for two-factor authentication has been reached.
 @exception AWSDKErrorCodeTwoFactorAuthenticationInvalidCode            The verification code for two-factor authentication is invalid.

 @since 6.7.0
*/
- (void)validateTwoFactorAuthenticationCode:(NSString *_Nonnull)authCode rememberDevice:(BOOL)rememberDevice authentication:(id<AWSDKConsumerAuthentication> _Nonnull)authentication completion:(ConsumerResultCompletionBlock _Nonnull)completion;

@end
