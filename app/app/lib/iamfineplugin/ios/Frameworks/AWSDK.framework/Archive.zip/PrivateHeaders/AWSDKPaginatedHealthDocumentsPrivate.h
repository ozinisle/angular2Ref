//
//  AWSDKPaginatedHealthDocumentsPrivate.h
//  AWSDK
//
//  Created by Caleb Lindsey on 5/14/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKConsumerPrivate.h"
#import "AWSDKPaginatedPrivate.h"

#import <AWSDK/AWSDKPaginatedHealthDocuments.h>

/**
 Represents a page of AWSDKHealthDocuments.

 @since 6.2.0
 */
@interface AWSDKPaginatedHealthDocuments : AWSDKPaginated <AWSDKPaginatedHealthDocuments>

- (nullable instancetype)initWithDictionary:(nonnull NSDictionary *)dict withConsumer:(nonnull AWSDKConsumer *)consumer;

@end
