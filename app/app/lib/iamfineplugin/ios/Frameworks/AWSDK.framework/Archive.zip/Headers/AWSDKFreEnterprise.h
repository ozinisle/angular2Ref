//
//  AWSDKFreEnterprise.h
//  AWSDK
//
//  Created by Ofir Mantsur on 24/06/2019.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKFreBaseModel.h"
#import <AWSDK/AWSDKFreHealthPlan.h>
#import <AWSDK/AWSDKFrePractice.h>

/**
 The enterprise object from the FRE system.

 @since 5.3.0
 */
@protocol AWSDKFreEnterprise <AWSDKFreBaseModel>

/**
 The name of the AmWell platform installation.

 @since 5.3.0
 */
@property (nonatomic, readonly, nonnull) NSString *name;

/**
 The locale of the AmWell platform installation.

 @since 5.3.0
 */
@property (nonatomic, readonly, nullable) NSLocale *locale;

/**
 The user's state location by a state abbreviation, defined by ISO-3166.

 @since 5.3.0
 */
@property (nonatomic, readonly, nullable) NSString *stateAbbreviation;

/**
 Indicator that services offered by the platform are likely to be covered according to the health plan supplied by customer and the list of supported health plans configured on the enterprise.

 @since 5.3.0
 */
@property (nonatomic, readonly) BOOL likelyCovered;

/**
 The mobile sdk key of the AmWell platform.

 @since 5.3.0
 */
@property (nonatomic, readonly, nonnull) NSString *mobileSdkKey;

/**
 The logo image of the AmWell platform.

 @since 5.3.0
 */
@property (nonatomic, readonly, nullable) NSString *logoURL;

/**
 The AmWell platform URL.

 @since 5.3.0
 */
@property (nonatomic, readonly, nonnull) NSString *serverURL;

/**
 The installation id of the enterprise.

 @since 5.3.0
 */
@property (nonatomic, readonly, nonnull) NSString *installationId;

/**
 The health plans associated with the enterprise.

 @since 5.3.0
 */
@property (nonatomic, readonly, nullable) NSArray<AWSDKFreHealthPlan *> *healthPlans;

/**
 The practices associated with the enterprise.

 @since 5.3.0
 */
@property (nonatomic, readonly, nullable) NSArray<AWSDKFrePractice *> *practices;

@end

@interface AWSDKFreEnterprise : AWSDKFreBaseModel <AWSDKFreEnterprise>

+ (nullable NSArray<AWSDKFreEnterprise *> *)enterprisesFromFreResults:(nullable NSDictionary *)json;

@end
