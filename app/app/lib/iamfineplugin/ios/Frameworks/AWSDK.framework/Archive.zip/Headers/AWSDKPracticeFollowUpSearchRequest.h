//
//  AWSDKPracticeFollowUpSearchRequest.h
//  AWSDK
//
//  Created by Christopher Majoros on 9/22/20.
//  Copyright © 2020 American Well.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <Foundation/Foundation.h>
#import "AWSDKItemSearchOptions.h"
#import "AWSDKItemSearchRequest.h"

/**
 Represents a search request for fetching AWSDKPaginatedFollowUpItems.

 @since 6.6.0
 */
@interface AWSDKPracticeFollowUpSearchRequest : AWSDKItemSearchRequest

/**
 Initializes a new AWSDKPracticeFollowUpSearchRequest

 @param pageSize        The number of AWSDKPaginatedPracticeFollowUpItems per search.
 @param startIndex      The index of the initial AWSDKPracticeFollowUpItem in the search.
 @param resolved        Boolean indicating whether to search for resolved items.

 @since 6.6.0
 */
- (instancetype)initWithPageSize:(NSInteger)pageSize startIndex:(NSInteger)startIndex resolved:(BOOL)resolved;

/**
 The number of AWSDKPaginatedPracticeFollowUpItems per search.

 @since 6.6.0
*/
@property (nonatomic) NSInteger pageSize;

/**
 The index of the initial AWSDKPracticeFollowUpItem in the search.

 @since 6.6.0
 */
@property (nonatomic) NSInteger startIndex;

/**
 Boolean indicating whether to search for resolved items.

 @since 6.6.0
*/
@property (nonatomic) BOOL resolved;

@end
