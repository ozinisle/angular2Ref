//
//  AWSDKPaginatedPracticeFollowUpItems.h
//  AWSDK
//
//  Created by Christopher Majoros on 9/22/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKPracticeFollowUpSearchRequest.h"
#import "AWSDKPaginated.h"

// clang-format off
@protocol AWSDKPracticeFollowUpItem, AWSDKPracticeFollowUpSearchRequest;
// clang-format on

/**
 Represents a page of AWSDKPracticeFollowUpItems.

 @since 6.6.0
 */
@protocol AWSDKPaginatedPracticeFollowUpItems <AWSDKPaginated>

/**
 The list of AWSDKPracticeFollowUpItems returned by the search.

 @since 6.6.0
 */
@property (nullable, readonly) NSArray<id<AWSDKPracticeFollowUpItem>> *list;

/**
 The next page in the search if available.

 @since 6.6.0
 */
@property (nullable, readonly) AWSDKPracticeFollowUpSearchRequest *nextPage;

/**
 The previous page in the search if available.

 @since 6.6.0
 */
@property (nullable, readonly) AWSDKPracticeFollowUpSearchRequest *previousPage;

@end
