//
//  AWSDKIntakePrivate.h
//  AWSDK
//
//  Created by Caleb Lindsey on 8/13/20.
//  Copyright © 2020 American Well. All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKDataObjectPrivate.h"

#import <AWSDK/AWSDKIntake.h>

/**
 A collection of information provided by the consumer during intake.

 @since 6.4.0
 */
@interface AWSDKIntake : AWSDKDataObject <AWSDKIntake>

@end
