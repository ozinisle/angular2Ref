//
//  AWSDKIntake.h
//  AWSDK
//
//  Created by Caleb Lindsey on 8/13/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <AWSDK/AWSDKDataObject.h>
#import <Foundation/Foundation.h>

@protocol AWSDKAllergy, AWSDKCondition, AWSDKMedication, AWSDKVisitTopic;

/**
A collection of information provided by the consumer during intake.

@since 6.4.0
*/
@protocol AWSDKIntake <AWSDKDataObject>

/**
 A list of AWSDKAllergies provided by the consumer.

 @since 6.4.0
 */
@property (nonatomic, nullable, readonly) NSArray<id<AWSDKAllergy>> *allergies;

/**
 A list of AWSDKConditions provided by the consumer.

 @since 6.4.0
 */
@property (nonatomic, nullable, readonly) NSArray<id<AWSDKCondition>> *conditions;

/**
 A list of AWSDKMedications provided by the consumer.

 @since 6.4.0
 */
@property (nonatomic, nullable, readonly) NSArray<id<AWSDKMedication>> *medications;

/**
 A list of AWSDKVisitTopics provided by the consumer.

 @since 6.4.0
 */
@property (nonatomic, nullable, readonly) NSArray<id<AWSDKVisitTopic>> *topics;

@end
