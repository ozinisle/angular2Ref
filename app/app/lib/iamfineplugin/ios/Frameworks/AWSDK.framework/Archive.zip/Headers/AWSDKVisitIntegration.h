//
//  AWSDKVisitIntegration.h
//  AWSDK
//
//  Created by Caleb Lindsey on 3/25/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#ifndef AWSDKVisitIntegration_h
#define AWSDKVisitIntegration_h

#import <Foundation/Foundation.h>

/**
 This enumerated type is used to represent the integration type of an integration.

 @since 6.2.0
 */
typedef NS_ENUM(NSInteger, AWSDKVisitIntegrationType) {
    /**
     Undefined Type

     @since 6.2.0
     */
    AWSDKVisitIntegrationTypeUnknown = -1,

    /**
     Orbita Chat Integration

     @since 6.2.0
     */
    AWSDKVisitIntegrationTypeOrbita,
};

/**
 This enumerated type is used to represent the integration's current status.

 @since 6.2.0
 */
typedef NS_ENUM(NSInteger, AWSDKVisitIntegrationStatus) {
    /**
     Integration status is unknown

     @since 6.2.0
     */
    AWSDKVisitIntegrationStatusUnknown = -1,

    /**
     Integration was added but no action was taken

     @since 6.2.0
     */
    AWSDKVisitIntegrationStatusQueued = 0,

    /**
     Integration is ready to be started

     @since 6.2.0
     */
    AWSDKVisitIntegrationStatusReady,

    /**
     Integration is in progress

     @since 6.2.0
     */
    AWSDKVisitIntegrationStatusInProgress,

    /**
     Integration has been completed

     @since 6.2.0
     */
    AWSDKVisitIntegrationStatusCompleted,

    /**
     Interaction bailed on by the member (e.g. never completed and the member and provider never connected)

     @since 6.2.0
     */
    AWSDKVisitIntegrationStatusBailed,

    /**
     Interaction was interrupted because the provider started the engagement before it completed

     @since 6.2.0
     */
    AWSDKVisitIntegrationStatusInterrupted,

    /**
     There was an error communicating with the integration

     @since 6.2.0
     */
    AWSDKVisitIntegrationStatusError,

    /**
     Interaction was reset due to a transfer or speedpass

     @since 6.2.0
     */
    AWSDKVisitIntegrationStatusReQueued,
};

/**
 Represents an integration attached to an AWSDKVisit.

 @since 6.2.0
 */
@protocol AWSDKVisitIntegration

/**
 The integration's progress status

 @since 6.2.0
 */
@property (readonly) AWSDKVisitIntegrationStatus integrationStatus;

/**
 The integration's type

 @since 6.2.0
 */
@property (readonly) AWSDKVisitIntegrationType integrationType;

@end

#endif /* AWSDKVisitIntegration_h */
