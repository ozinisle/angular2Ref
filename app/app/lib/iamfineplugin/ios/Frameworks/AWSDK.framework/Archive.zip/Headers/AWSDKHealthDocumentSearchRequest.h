//
//  AWSDKHealthDocumentSearchRequest.h
//  AWSDK
//
//  Created by Caleb Lindsey on 4/27/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <Foundation/Foundation.h>
#import "AWSDKItemSearchOptions.h"
#import "AWSDKItemSearchRequest.h"

/**
 Represents a search request for fetching AWSDKPaginatedHealthDocuments.

 @since 6.2.0
 */
@protocol AWSDKHealthDocumentSearchRequest <AWSDKItemSearchRequest>

/**
 Creates a new AWSDKHealthDocumentSearchRequest instance.

 @param pageSize The number of AWSDKHealthDocuments per search.
 @param startIndex The index of the initial AWSDKHealthDocument in the search.
 @param sortAsc Whether or not the AWSDKHealthDocuments are sorted in ascending order.
 @param options An AWSDKItemSearchOptions object for setting additional parameters.

 @return AWSDKHealthDocumentSearchRequest instance.

 @since 6.2.0
*/
- (nullable instancetype)initWithPageSize:(NSInteger)pageSize startIndex:(NSInteger)startIndex sortAscending:(BOOL)sortAsc options:(nullable AWSDKItemSearchOptions *)options;

/**
 Creates a new AWSDKHealthDocumentSearchRequest instance with default values.

 @return AWSDKHealthDocumentSearchRequest instance.

 @since 6.2.0
*/
- (instancetype _Nonnull )init;

/**
 Whether or not the AWSDKHealthDocuments are sorted in ascending order.

 @note The default value is false.

 @since 6.2.0
 */
@property (nonatomic, readwrite) BOOL sortAsc;

@end
