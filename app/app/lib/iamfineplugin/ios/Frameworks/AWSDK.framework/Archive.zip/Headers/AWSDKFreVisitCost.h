//
//  AWSDKFreVisitCost.h
//  AWSDK
//
//  Created by Ofir Mantsur on 12/08/2019.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKFreBaseModel.h"

/**
 The visit cost associated with the practice.

 @since 5.3.0
 */
@protocol AWSDKFreVisitCost <AWSDKFreBaseModel>

/**
 The highest possible cost calculated per practice.

 @since 5.3.0
 */
@property (nonatomic, readonly, nullable) NSNumber *costHigh;

/**
 The lowest possible cost calculated per practice.

 @since 5.3.0
 */
@property (nonatomic, readonly, nullable) NSNumber *costLow;

@end

@interface AWSDKFreVisitCost : AWSDKFreBaseModel <AWSDKFreVisitCost>

+ (nullable AWSDKFreVisitCost *)visitCostFromFreResults:(nullable NSDictionary *)json;

@end
