//
//  AWSDKPaginatedVisitReports.h
//  AWSDK
//
//  Created by Caleb Lindsey on 4/27/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKPaginated.h"
#import "AWSDKVisitReport.h"
#import "AWSDKVisitReportSearchRequest.h"

/**
 Represents a page of AWSDKVisitReports.

 @since 6.2.0
 */
@protocol AWSDKPaginatedVisitReports <AWSDKPaginated>

/**
 The list of AWSDKVisitReports returned by the search

 @since 6.2.0
 */
@property (nullable, readonly) NSArray<id<AWSDKVisitReport>> *list;

/**
 The next page in the search if available

 @since 6.2.0
 */
@property (nullable, readonly) id<AWSDKVisitReportSearchRequest> nextPage;

/**
 The previous page in the search if available

 @since 6.2.0
 */
@property (nullable, readonly) id<AWSDKVisitReportSearchRequest> previousPage;

@end
