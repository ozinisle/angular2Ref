//
//  AWSDKOrbitaIntegration.h
//  AWSDK
//
//  Created by Caleb Lindsey on 4/15/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#ifndef AWSDKOrbitaIntegration_h
#define AWSDKOrbitaIntegration_h

#import "AWSDKOrbitaIntegrationConfig.h"
#import "AWSDKVisitIntegration.h"
#import <Foundation/Foundation.h>

/**
 Represents an Orbita integration attached to an AWSDKVisit.

 @since 6.2.0
 */
@protocol AWSDKOrbitaIntegration<AWSDKVisitIntegration>

/**
 The integration's configuration

 @since 6.2.0
 */
@property (readonly) id<AWSDKOrbitaIntegrationConfig> configuration;

@end

#endif /* AWSDKOrbitaIntegration_h */
