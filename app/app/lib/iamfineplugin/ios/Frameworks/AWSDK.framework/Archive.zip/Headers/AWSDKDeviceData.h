//
//  AWSDKDeviceData.h
//  AWSDK
//
// Created by Roey Honig on 6/28/2020.
// Copyright © 2020 American Well. All rights reserved.
//
// It is illegal to use, reproduce or distribute
// any part of this Intellectual Property without
// prior written authorization from American Well.
//

#import <Foundation/Foundation.h>
#import <AWSDK/AWSDKDataObject.h>
#import <AWSDK/AWSDKDeviceIntegration.h>

/**
Set of methods for retrieving information needed for pairing device with the App

@since 6.3.0
*/

@protocol AWSDKDeviceData <NSObject>

/**
 Getter method to the networkSsid property.

 @discussion This will return the network name of this device data

 @return NSString

 @since 6.3.0
 */
@property (nonatomic, readonly, nonnull) NSString *networkSSID;

/**
 Getter method to the networkPassword property.

 @discussion This will return the network password of this device data

 @return NSString

 @since 6.3.0
 */
@property (nonatomic, readonly, nonnull) NSString *networkPassword;

/**
 Getter method to the integration type property.

 @discussion This will return the integration type of this device data

 @return NSString

 @since 6.3.0
 */
@property (nonatomic, readonly) AWSDKDeviceIntegrationType integrationType;

@end

/**
Data model grouping together properties required for obtaining information regarding live stream device integration via the appropriate service

@since 6.3.0
*/

@interface AWSDKDeviceData : NSObject <AWSDKDeviceData>

/**
 @name Constructor
 */

/**
 Custom Init.

 @param name NSString - The name of the wifi network upon which, the consumer is pairing the device
 
 @param password NSString - The password of the wifi network upon which, the consumer is pairing the device
 
 @param type AWSDKDeviceIntegrationType - An enum for the individual different remote care device
 
 @return AWSDKDeviceData instance.

 @since 6.3.0
 */

+ (nonnull instancetype)deviceDataWithNetworkName:(NSString *_Nonnull)name networkPassword:(NSString *_Nonnull)password andIntegrationType:(AWSDKDeviceIntegrationType)type;

@end

