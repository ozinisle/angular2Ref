//
//  AWSDKFrePractice.h
//  AWSDK
//
//  Created by Ofir Mantsur on 21/07/2019.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKFreBaseModel.h"
#import <AWSDK/AWSDKFreVisitCost.h>

/**
 The practice associated with the enterprise.

 @since 5.3.0
 */
@protocol AWSDKFrePractice <AWSDKFreBaseModel>

/**
 The name of the practice.

 @since 5.3.0
 */
@property (nonatomic, readonly, nonnull) NSString *name;

/**
 The sourceId of the practice.

 @since 5.3.0
 */
@property (nonatomic, readonly, nonnull) NSString *sourceId;

/**
 The logo of the practice.

 @since 5.3.0
 */
@property (nonatomic, readonly, nullable) NSString *logoUrl;

/**
 The visit cost of the practice.

 @since 5.3.0
 */
@property (nonatomic, readonly, nullable) AWSDKFreVisitCost *visitCost;

@end

@interface AWSDKFrePractice : AWSDKFreBaseModel <AWSDKFrePractice>

+ (nullable NSArray<AWSDKFrePractice *> *)practicesFromFreResults:(nullable NSDictionary *)json;

@end
