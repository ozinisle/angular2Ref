//
//  AWSDKItemSearchOptions.h
//  AWSDK
//
//  Created by Caleb Lindsey on 6/17/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <AWSDK/AWSDKDataObject.h>

/**
 Options for specifying additional parameters on AWSDKItemSearchRequests.

 @since 6.2.0
 */
@interface AWSDKItemSearchOptions : AWSDKDataObject

#pragma mark - Constructor
/**
 @name Constructor
 */

/**
 Creates a new AWSDKItemSearchOptions instance.

 @return AWSDKItemSearchOptions instance.

 @since 6.2.0
 */
+ (nonnull instancetype)options;

#pragma mark - Read-Write Properties
/**
 @name Read-Write Properties
 */

/**
 NSDate representing the earliest date of items in the search.

 @since 6.2.0
 */
@property (nonatomic, readwrite, nullable) NSDate *startDate;

/**
 NSDate representing the latest date of items in the search.

 @since 6.2.0
 */
@property (nonatomic, readwrite, nullable) NSDate *endDate;

@end
