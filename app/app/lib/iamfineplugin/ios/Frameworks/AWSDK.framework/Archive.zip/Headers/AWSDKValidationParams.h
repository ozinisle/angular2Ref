//
//  AWSDKValidationParams.h
//  AWSDK
//
//  Created by Rolin Nelson on 10/26/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <Foundation/Foundation.h>

#pragma mark - Default Validation Values
/**
 Configurable values used for validating user input values.

 @note Values are used to validate user input data before sending to the platform.  The platform will perform additional validation on the data.

 @since 6.8.0
 */

@interface AWSDKValidationParams : NSObject

/**
 Minimum First Name length

 @since 6.8.0
 */
@property (class) NSInteger minFirstName;

/**
 Maximum First Name length

 @since 6.8.0
 */
@property (class) NSInteger maxFirstName;

/**
 Minimum Last  Name length

 @since 6.8.0
 */
@property (class) NSInteger minLastName;

/**
 Maximum Last Name length

 @since 6.8.0
 */
@property (class) NSInteger maxLastName;

/**
 Minimum Middle Initial length

 @since 6.8.0
 */
@property (class) NSInteger minMiddleInit;

/**
 Maximum Middle Initial length

 @since 6.8.0
 */
@property (class) NSInteger maxMiddleInit;

/**
 Minimum Temperature value

 @since 6.8.0
 */
@property (class) NSInteger minTemperature;

/**
 Maximum Temperature value

 @since 6.8.0
 */
@property (class) NSInteger maxTemperature;

/**
 Minimum Blood Pressure value

 @since 6.8.0
 */
@property (class) NSInteger minBloodPressure;

/**
 Maximum Blood Pressure value

 @since 6.8.0
 */
@property (class) NSInteger maxBloodPressure;

/**
 Email detector

 @note  When not specified, an NSDataDetector with type of NSTextCheckingTypeLink is used.

 @since 6.8.0
 */
@property (class) NSDataDetector *emailDataDetector;

/**
 Phone Number detector

 @note  When not specified, an NSDataDetector with type of NSTextCheckingTypePhoneNumber is used.

 @since 6.8.0
 */
@property (class) NSDataDetector *phoneDataDetector;

@end
