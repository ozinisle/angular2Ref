//
//  AWSDKFreRecommendationsResponse.h
//  AWSDK
//
//  Created by Ofir Mantsur on 13/08/2019.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKFreBaseModel.h"
#import "AWSDKFreEnterprise.h"

/**
 The recommendation response object that returns from the FRE system.

 @since 5.3.0
 */
@protocol AWSDKFreRecommendationsResponse <AWSDKFreBaseModel>

/**
 The request id associated with the response.

 @since 5.3.0
 */
@property (nonatomic, readonly, nullable) NSString *requestId;

/**
 The id for the use of tracking the cost polling request.

 @since 5.3.0
 */
@property (nonatomic, readonly, nullable) NSString *trackingId;

/**
 The enterprises list.

 @since 5.3.0
 */
@property (nonatomic, readonly, nullable) NSArray<AWSDKFreEnterprise *> *enterprises;

@end

@interface AWSDKFreRecommendationsResponse : AWSDKFreBaseModel <AWSDKFreRecommendationsResponse>

+ (nullable AWSDKFreRecommendationsResponse *)recommendationsResponseFromFreResults:(nullable NSDictionary *)json;

@end
