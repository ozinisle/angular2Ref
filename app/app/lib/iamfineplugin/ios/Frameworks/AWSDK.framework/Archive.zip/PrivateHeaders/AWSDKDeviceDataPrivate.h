//
//  AWSDKDeviceDataPrivate.h
//  AWSDK
//
// Created by Roey Honig on 6/28/2020.
// Copyright © 2020 American Well. All rights reserved.
//
// It is illegal to use, reproduce or distribute
// any part of this Intellectual Property without
// prior written authorization from American Well.
//

#import "AWSDKDataObjectPrivate.h"
#import "AWSDKDeviceData.h"
#import <AWCoreSDK/AWCoreSDK.h>
#import <AWSDK/AWSDKDeviceIntegration.h>

@interface AWSDKDeviceData ()

/**
Method used to create a new instance of AWSDKDeviceData from an equivalent Object called AWCoreLiveStreamDeviceData. This allows quickly sharing information related to the pairing process between the AWCore module and the AWSDK

@return AWSDKDeviceData.

@since 6.3.0
*/
- (nonnull instancetype)initWithAWCoreLiveStreamDeviceData:(AWCoreLiveStreamDeviceData *_Nonnull) aWCoreLiveStreamDeviceData;

@end


