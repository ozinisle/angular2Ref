//
//  AWSDKFollowUpItemSearchRequest.h
//  AWSDK
//
//  Created by Caleb Lindsey on 4/27/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <Foundation/Foundation.h>
#import "AWSDKFollowUpItemTypeFilter.h"
#import "AWSDKItemSearchOptions.h"
#import "AWSDKItemSearchRequest.h"

/**
 Represents a search request for fetching AWSDKPaginatedFollowUpItems.

 @since 6.2.0
 */
@protocol AWSDKFollowUpItemSearchRequest <AWSDKItemSearchRequest>

/**
 Creates a new AWSDKFollowUpItemSearchRequest instance.

 @param typeFilter The type of AWSDKFollowUpItems in the search.
 @param pageSize The number of AWSDKFollowUpItems per search.
 @param startIndex The index of the initial AWSDKFollowUpItem in the search.
 @param resolved The resolved state of AWSDKFollowUpItems in the search.
 @param options An AWSDKItemSearchOptions object for setting additional parameters.

 @return AWSDKFollowUpItemSearchRequest instance.

 @since 6.2.0
*/
- (nullable instancetype)initWithTypeFilter:(AWSDKFollowUpItemTypeFilter)typeFilter pageSize:(NSInteger)pageSize startIndex:(NSInteger)startIndex resolved:(BOOL)resolved options:(nullable AWSDKItemSearchOptions *)options;

/**
 Creates a new AWSDKFollowUpItemSearchRequest instance with the specified filter and default values.

 @param typeFilter The type of AWSDKFollowUpItems in the search.

 @return AWSDKFollowUpItemSearchRequest instance.

 @since 6.2.0
*/
- (nullable instancetype)initWithTypeFilter:(AWSDKFollowUpItemTypeFilter)typeFilter;

/**
 The type of AWSDKFollowUpItems in the search.

 @since 6.2.0
 */
@property (nonatomic, readwrite) AWSDKFollowUpItemTypeFilter typeFilter;

/**
 The resolved state of AWSDKFollowUpItems in the search.

 @since 6.2.0
 */
@property (nonatomic, readwrite) BOOL resolved;

@end
