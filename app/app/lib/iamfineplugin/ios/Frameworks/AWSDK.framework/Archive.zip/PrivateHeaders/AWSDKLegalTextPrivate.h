//
//  AWSDKLegalTextPrivate.h
//  AWSDK
//
//  Created by Steven Uy on 7/28/16.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKDataObjectPrivate.h"

#import <AWSDK/AWSDKLegalText.h>

// TODO: Refactor to LegalNotice
typedef void (^LegalTextResultCompletionBlock)(_Nullable id<AWSDKLegalText> legalText, NSError *_Nullable error);

/**
 A legal text for a visit. This may be a dislaimer or a different legal type.

 @note As of 2.0.0, AWSDKPrivacyDisclaimer was renamed to AWSDKLegalText.

 @since 2.0.0
 */
@interface AWSDKLegalText : AWSDKDataObject <AWSDKLegalText>
+ (nullable NSArray *)disclaimersFromArray:(nullable NSArray *)array;

@property BOOL accepted;

/**
Fetches the AWSDKLegalText

@discussion The formatted content should be displayed in UIWebView to be properly formatted.

@param link The REST resource link for the requested disclaimer.
@param completion LegalTextResultCompletionBlock containing the AWSDKLegalText, otherwise an NSError explaining any errors.

@since 6.7.0
*/
+ (void)fetchLegalText:(nonnull NSString *)link completion:(nullable LegalTextResultCompletionBlock)completion;

@end
