//
//  NSString+EnumParser.h
//  AWSDK
//
//  Created by Jeremiah.Possion on 4/14/17.
//  Copyright © 2018 American Well. All rights reserved.
//

#import "AWSDKErrorCode.h"
#import "AWSDKVisitDisposition.h"

#import <Foundation/Foundation.h>

#define AWSDKVDUnpublished (@"Unpublished")
#define AWSDKVDUnscheduled (@"Unscheduled")
#define AWSDKVDScheduled (@"Scheduled")
#define AWSDKVDParked (@"Parked")
#define AWSDKVDMemberCanceled (@"MemberCanceled")
#define AWSDKVDDeclined (@"Declined")
#define AWSDKVDProviderResponseTimeout (@"ProviderResponseTimeout")
#define AWSDKVDPreVisitScreening (@"PreVisitScreening")
#define AWSDKVDInProgress (@"InProgress")
#define AWSDKVDPostVisitConversation (@"PostVisitConversation")
#define AWSDKVDBailed (@"Bailed")
#define AWSDKVDProviderDisconnected (@"ProviderDisconnected")
#define AWSDKVDProviderWrapup (@"ProviderWrapup")
#define AWSDKVDConsultingProviderWrappedUp (@"ConsultingProviderWrappedUp")
#define AWSDKVDCompleted (@"Completed")
#define AWSDKVDError (@"Error")
#define AWSDKVDCollapseDeleted (@"CollapseDeleted")
#define AWSDKVDDeleted (@"Deleted")
#define AWSDKVDProviderCanceled (@"ProviderCanceled")
#define AWSDKVDMemberDisconnected (@"MemberDisconnected")
#define AWSDKVDExpired (@"Expired")

@interface NSString (EnumParser)

- (AWSDKErrorCode)awsdkErrorCodeFromString;
- (AWSDKVisitDisposition)toVisitDisposition;
+ (NSArray<NSString *> *)stringArrayFromVisitDisposition:(AWSDKVisitDisposition)dispositionMap;

@end
