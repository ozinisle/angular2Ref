//
//  AWSDKPaginatedPracticeFollowUpItemsPrivate.h
//  AWSDK
//
//  Created by Christopher Majoros on 9/22/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKPaginatedPrivate.h"

#import <AWSDK/AWSDKPaginatedPracticeFollowUpItems.h>

/**
 Represents a page of AWSDKPracticeFollowUpItems.

 @since 6.6.0
 */
@interface AWSDKPaginatedPracticeFollowUpItems : AWSDKPaginated <AWSDKPaginatedPracticeFollowUpItems>

@end
