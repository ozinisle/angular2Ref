//
//  AWSDKGenderIdentity.h
//  AWSDK
//
//  Created by Christopher Majoros on 12/4/19.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#ifndef AWSDKGenderIdentity_h
#define AWSDKGenderIdentity_h

#import <Foundation/Foundation.h>
#import <AWSDK/AWSDKBiologicalSex.h>

/**
 Represents a consumer's gender identity.

 @since 5.4.0
 */
@protocol AWSDKGenderIdentity

/**
 The key which uniquely identifies this gender identity on the platform.

 @since 5.4.0
 */
@property (nonnull, readonly) NSString *key;

/**
 The localized name of the gender identity.

 @since 5.4.0
 */
@property (nonnull, readonly) NSString *name;

/**
 The equivalent biological sex for comparison purposes.  Returns AWSDKBiologicalSexMale if the gender identity corresponds to the male sex, AWSDKBiologicalSexFemale
 if the gender identity corresponds to the female sex, or AWSDKBiologicalSexNotSet if there is no direct correspondence.

 @discussion When it is necessary to determine if the consumer's gender identity matches their biological sex, this property can be used to compare with the
 gender property on the AWSDKUser.

 @since 6.4.0
 */
@property (readonly) AWSDKBiologicalSex representedBiologicalSex;

@end

#endif  /* AWSDKGenderIdentity_h */
