//
//  AWSDKFreService.h
//  AWSDK
//
//  Created by Ofir Mantsur on 07/08/2019.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKFreBaseModel.h"

/**
 The service associated with the enterprise.

 @since 5.3.0
 */
@protocol AWSDKFreService <AWSDKFreBaseModel>

/**
 The name of the service associated with the FRE.

 @since 5.3.0
 */
@property (nonatomic, readonly, nullable) NSString *serviceName;

/**
 The id of the service associated with the FRE.

 @since 5.3.0
 */
@property (nonatomic, readonly, nonnull) NSString *serviceId;

@end

@interface AWSDKFreService : AWSDKFreBaseModel <AWSDKFreService>

+ (nullable NSArray<AWSDKFreService *> *)servicesFromFreResults:(nullable NSDictionary *)json;

@end
