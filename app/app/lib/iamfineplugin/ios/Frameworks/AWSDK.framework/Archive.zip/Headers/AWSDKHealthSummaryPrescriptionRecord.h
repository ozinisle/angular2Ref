//
//  AWSDKHealthSummaryPrescriptionRecord.h
//  AWSDK
//
//  Created by Caleb Lindsey on 10/6/20.
//  Copyright © 2020 American Well. All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <AWSDK/AWSDKDataObject.h>

/**
 A prescription record in a consumer's health summary.

 @since 6.6.0
 */
@protocol AWSDKHealthSummaryPrescriptionRecord <AWSDKHealthSummaryRecord>

#pragma mark - Read-Only Properties
/**
 @name Read-Only Properties
 */

/**
 BOOL True if prescription is to be dispensed as written by the provider.

 @since 6.6.0
 */
@property (nonatomic, readonly) BOOL dispenseAsWritten;

/**
 BOOL True if the provider directed the consumer to take the prescription as needed.

 @since 6.6.0
 */
@property (nonatomic, readonly) BOOL asNeeded;

/**
 BOOL True if the consumer should stop taking the prescription when directed by the provider.

 @since 6.6.0
 */
@property (nonatomic, readonly) BOOL stopWhenDirected;

/**
 NSString The dosage of the prescription the consumer was directed to take by the provider.

 @since 6.6.0
 */
@property (nonatomic, readonly, nullable) NSString *dosage;

/**
 NSString The duration that the consumer should take the prescription as directed by the provider.

 @since 6.6.0
 */
@property (nonatomic, readonly, nullable) NSString *duration;

/**
 NSString The frequency at which the consumer should take the prescription as directed by the provider.

 @since 6.6.0
 */
@property (nonatomic, readonly, nullable) NSString *frequency;

/**
 NSString The instructions the provider has given to the consumer for taking the prescription.

 @since 6.6.0
 */
@property (nonatomic, readonly, nullable) NSString *instructions;

/**
 NSString The quantity of the prescription to dispense.

 @since 6.6.0
 */
@property (nonatomic, readonly, nullable) NSString *quantityToDispense;

/**
 NSInteger The number of refills for the prescription.

 @since 6.6.0
 */
@property (nonatomic, readonly) NSInteger refillTotal;

/**
 NSString The measurement unit qualifier e.g. "Tablet", "Spray" etc.

 @since 6.6.0
 */
@property (nonatomic, readonly, nullable) NSString *measurementUnitQualifier;

/**
 NSString The name of the provider who is prescribing the medication.

 @since 6.6.0
 */
@property (nonatomic, readonly, nullable) NSString *prescribedBy;

@end
