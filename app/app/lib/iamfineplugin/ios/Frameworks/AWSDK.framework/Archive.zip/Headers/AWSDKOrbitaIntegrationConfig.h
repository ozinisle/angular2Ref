//
//  AWSDKOrbitaIntegrationConfig.h
//  AWSDK
//
//  Created by Caleb Lindsey on 4/16/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#ifndef AWSDKOrbitaIntegrationConfig_h
#define AWSDKOrbitaIntegrationConfig_h

#import <Foundation/Foundation.h>

/**
 Represents an Orbita configuration for an AWSDKOrbitaIntegration

 @since 6.2.0
 */
@protocol AWSDKOrbitaIntegrationConfig

/**
 The integrations source

 @since 6.2.0
 */
@property (nonnull, readonly) NSString *waitingRoomAIUrl;

/**
 The integrations url for checking reachability

 @since 6.2.0
 */
@property (nullable, readonly) NSString *waitingRoomStatusUrl;

@end

#endif /* AWSDKOrbitaIntegrationConfig_h */
