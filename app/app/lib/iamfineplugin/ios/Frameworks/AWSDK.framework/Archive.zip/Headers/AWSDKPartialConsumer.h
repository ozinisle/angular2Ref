//
//  AWSDKPartialConsumer.h
//  AWSDK
//
//  Created by Calvin Chestnut on 3/4/16.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <AWSDK/AWSDKCompletionBlock.h>
#import <AWSDK/AWSDKDataObject.h>

@protocol AWSDKState;

/**
 A partially registered consumer in the telehealth platform.

 @since 3.1.0
 */
@protocol AWSDKPartialConsumer <AWSDKDataObject>

/**
 Represents the email address used to register the user

 @since 4.1.0
 */
@property (nonnull, nonatomic, readonly) NSString *emailOnFile;

/**
 Completes registration on the telehealth platform.

 @param location    AWSDKState the consumer is located in.
 @param username        NSString existing username for the account.
 @param newUsername     Optional NSString new username for the account, which must be an email address.
 @param password        NSString existing password for the account.
 @param newPassword     Optional NSString new password for the account.  Required if a new username is supplied.
 @param completion  AuthenticationResultCompletionBlock containing the new AWSDKConsumer if the consumer has been registered, or AWSDKConsumerAuthentication object if the consumer is partially authenticated, otherwise _nil_ and an NSError with the failure reasons.

 @discussion Completes registration for a partially enrolled consumer.  The existing username and password must be supplied.  The location is also required.
 A new username and password are optional.  If the new username is not supplied, then enrollment is completed with the existing username.
 If a new username is supplied, then a new password is required.  To change the password without changing the username, the same name can be passed in the username and newUsername parameters.

 @since 6.7.0
 */
- (void)completeRegistrationWithLocation:(nonnull id<AWSDKState>)location
                                username:(nonnull NSString *)username
                             newUsername:(nullable NSString *)newUsername
                                password:(nonnull NSString *)password
                             newPassword:(nullable NSString *)newPassword
                              completion:(nonnull AuthenticationResultCompletionBlock)completion;

@end
