//
//  AWSDKEnrollmentServicePrivate.h
//  AWSDK
//
//  Created by Jeremiah.Possion on 1/30/17.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <AWSDK/AWSDKEnrollmentService.h>

/**
 Handles Consumer and Dependent enrollment and validation

 @since 3.0.0
 */
@interface AWSDKEnrollmentService ()

#pragma mark - Singleton
/**
 @name Singleton
 */

/**
 Singleton accessor for AWSDKVisitService.

 @return The main AWSDKVisitService instance

 @since 3.0.0
 */
+ (instancetype _Nonnull)sharedInstance;

#pragma mark - Private Methods
/**
 @name Private Methods
 */

/**
 Sends enrollment request to the Amwell Home platform using information from the AWSDKConsumerEnrollmentForm

 @param form            AWSDKConsumerEnrollmentForm containing information about the user to be registered
 @param acceptVersion   NSString with the version that will be sent as the Accept parameter on the REST request for backwards compatibility.
 @param completion      AuthenticationResultCompletionBlock containing the new AWSDKConsumer if the consumer is properly registered, or AWSDKConsumerAuthentication object
 if the new user is partially authenticated, otherwise _nil_ if there was an error and an optional NSError describing anything that went wrong.
 
 @since 6.7.0
 */
- (void)enrollUserWithEnrollmentForm:(AWSDKConsumerEnrollmentForm *_Nonnull)form acceptVersion:(NSString *_Nonnull)acceptVersion completion:(AuthenticationResultCompletionBlock _Nonnull)completion;
/**
Build a mutable dictionary of the parameters in a AWSDKDemographicForm shared between a consumer and a dependent

@param form             AWSDKDemographicForm containing information about the user to be registered

@since 6.7.0
*/
+ (NSMutableDictionary *_Nonnull)buildEnrollDictionaryFromForm:(AWSDKDemographicForm *_Nonnull)form;

/**
Build an NSError from an AWJSONResponse

@param response AWJSONResponse from which to build the error.

@since 6.7.0
*/
+ (NSError *_Nullable)buildEnrollErrorFromResponse:(AWJSONResponse *_Nonnull)response;

@end
