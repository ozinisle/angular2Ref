//
//  AWSDKFreBaseModel.h
//  AWSDK
//
//  Created by Ofir Mantsur on 23/10/2019.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <Foundation/Foundation.h>

/**
 Base model for the FRE objects.

 @since 5.3.0
 */
@protocol AWSDKFreBaseModel

/**
  Init method is unavailable.

 @return Attempting to use init will result in compiler error.

 @since 5.3.0
 */
- (nonnull instancetype)init __attribute__((unavailable("'init' is not available")));

/**
 New method is unavailable.

 @since 5.3.0
 */
+ (nonnull instancetype)new __attribute__((unavailable("'new' is not available")));

@end

@interface AWSDKFreBaseModel : NSObject

- (nonnull instancetype)init __attribute__((unavailable("'init' is not available")));

- (nonnull instancetype)new __attribute__((unavailable("'new' is not available")));

@end
