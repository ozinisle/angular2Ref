//
//  AWSDKOnlineVisitFollowUpItem.h
//  AWSDK
//
//  Created by Christopher Majoros on 8/18/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <AWSDK/AWSDKFollowUpItem.h>

// clang-format off
@protocol AWSDKProvider;
// clang-format on

/**
 Represents the details of an online follow up visit in detail and is more specific than AWSDKFollowUpItem.

 @since 6.4.0
 */
@protocol AWSDKOnlineVisitFollowUpItem <AWSDKFollowUpItem>

#pragma mark - Read-Only Properties
/**
 @name Read-Only Properties
 */

/**
 AWSDKProvider representing the provider that had the original visit with the consumer that did the referring.

 @since 6.4.0
 */
@property (nonatomic, readonly, nonnull) id<AWSDKProvider> referringProvider;

/**
 AWSDKProvider representing the provider that the consumer was referred to have a visit with.

 @since 6.4.0
 */
@property (nonatomic, readonly, nullable) id<AWSDKProvider> assignedProvider;

/**
 AWSDKProviderType representing the type or specialty of the provider being recommended for a follow up, exclusive of the assigned provider being set.

 @since 6.4.0
 */
@property (nonatomic, readonly, nullable) id<AWSDKProviderType> assignedSpecialty;

/**
 Dismisses an individual AWSDKOnlineVisitFollowUpItem.

 @param consumer        AWSDKConsumer consumer that owns the AWSDKOnlineVisitFollowUpItem.
 @param completion      GenericCompletionBlock containing _TRUE_ if the operation was successful, otherwise _FALSE_ and an NSError explaining the failure.

 @since 6.4.0
 */
- (void)dismiss:(nonnull id<AWSDKConsumer>)consumer completion:(nonnull GenericCompletionBlock)completion;

@end
