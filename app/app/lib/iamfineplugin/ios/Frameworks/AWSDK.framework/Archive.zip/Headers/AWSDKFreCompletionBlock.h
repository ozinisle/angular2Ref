//
//  AWSDKFreCompletionBlock.h
//  AWSDK
//
//  Created by Ofir Mantsur on 09/07/2019.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@protocol AWSDKFreHealthPlan;
@protocol AWSDKFreEnterprise;
@protocol AWSDKFreService;
@protocol AWSDKFreRecommendationsResponse;

// clang-format on
#pragma mark - Completion Blocks
/**
 @name Completion Blocks
 */

/**
Used for the initialization request, where an array of AWSDKHealthPlan and array of AWSDKFreService results are expected.

@discussion Will contain the expected array of AWSDKHealthPlan and AWSDKFreService results, otherwise an optional NSError if there are any problems with the request.

@param healthPlans The expected array of AWSDKHealthPlan objects.
@param services    The expected array of AWSDKFreService objects.
@param error       NSError explaining why the request failed.

@since 5.3.0
*/
typedef void (^FreInitializationCompletionBlock)(NSArray<id<AWSDKFreHealthPlan>> *_Nullable healthPlans, NSArray<id<AWSDKFreService>> *_Nullable services, NSError *_Nullable error);

/**
 Used for requests where an array of AWSDKFreRecommendation results are expected.

 @discussion Will contain the expected array of AWSDKFreHealthPlan results, otherwise an optional NSError if there are any problems with the request.

 @param healthPlans  The expected array of AWSDKFreHealthPlan objects.
 @param error        NSError explaining why the request failed.

 @since 5.3.0
 */
typedef void (^FreHealthPlansResultCompletionBlock)(NSArray<id<AWSDKFreHealthPlan>> *_Nullable healthPlans, NSError *_Nullable error);

/**
 Used for requests where an object of AWSDKFreRecommendationsResponse is expected.

 @discussion Will contain the expected array of AWSDKFreRecommendationsResponse results, otherwise an optional NSError if there are any problems with the request.

 @param recommendationsResponse The expected recommendation object.
 @param error                   NSError explaining why the request failed.

 @since 5.3.0
 */
typedef void (^FreRecommendationsResponseCompletionBlock)(id<AWSDKFreRecommendationsResponse> _Nullable recommendationsResponse, NSError *_Nullable error);
