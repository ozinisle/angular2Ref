//
//  AWSDKPracticeFollowUpItem.h
//  AWSDK
//
//  Created by Christopher Majoros on 9/23/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <AWSDK/AWSDKFollowUpItem.h>

// clang-format off
@protocol AWSDKProvider;
// clang-format on

/**
 Represents the details of a follow up with a given practice and is more specific than AWSDKFollowUpItem.

 @since 6.6.0
 */
@protocol AWSDKPracticeFollowUpItem <AWSDKFollowUpItem>

#pragma mark - Read-Only Properties
/**
 @name Read-Only Properties
 */

/**
 AWSDKProvider representing the provider that had the original visit with the consumer that did the referring.

 @since 6.6.0
 */
@property (nonatomic, readonly, nonnull) id<AWSDKProvider> referringProvider;

/**
 AWSDKPractice representing the practice that the consumer was referred to have a visit with.

 @since 6.6.0
 */
@property (nonatomic, readonly, nullable) id<AWSDKPractice> assignedPractice;

/**
 Dismisses an individual AWSDKPracticeFollowUpItem.

 @param consumer        AWSDKConsumer consumer that owns the AWSDKPracticeFollowUpItem.
 @param completion      GenericCompletionBlock containing _TRUE_ if the operation was successful, otherwise _FALSE_ and an NSError explaining the failure.

 @since 6.6.0
 */
- (void)dismiss:(nonnull id<AWSDKConsumer>)consumer completion:(nonnull GenericCompletionBlock)completion;

@end
