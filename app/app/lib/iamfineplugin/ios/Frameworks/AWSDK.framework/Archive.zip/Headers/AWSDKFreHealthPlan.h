//
//  AWSDKFreHealthPlan.h
//  AWSDK
//
//  Created by Ofir Mantsur on 26/06/2019.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKFreBaseModel.h"

/**
 The health plan object from the FRE system.

 @since 5.3.0
 */
@protocol AWSDKFreHealthPlan <AWSDKFreBaseModel>

/**
 The health plan name.

 @since 5.3.0
 */
@property (nonatomic, readonly, nonnull) NSString *healthPlanName;

/**
 The health plan qualifier.

 @since 5.3.0
 */
@property (nonatomic, readonly, nonnull) NSString *healthPlanQualifier;

@end

@interface AWSDKFreHealthPlan : AWSDKFreBaseModel <AWSDKFreHealthPlan>

+ (nullable NSArray<AWSDKFreHealthPlan *> *)healthPlansFromFreResults:(nullable NSDictionary *)json;

@end
