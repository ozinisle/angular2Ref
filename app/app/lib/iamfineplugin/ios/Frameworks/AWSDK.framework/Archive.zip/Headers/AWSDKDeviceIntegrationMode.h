//
//  AWSDKDeviceIntegrationMode.h
//  AWSDK
//
// Created by Roey Honig on 7/8/2020.
// Copyright © 2020 American Well. All rights reserved.
//
// It is illegal to use, reproduce or distribute
// any part of this Intellectual Property without
// prior written authorization from American Well.
//

/** List of device integration modes received from the Amwell telehealth platform indicating what device service is available according to the practice settings */
typedef NS_ENUM(NSUInteger, DeviceIntegrationMode) {
    
    /**
    Practice does not support any device integration during a visit

    @since 6.3.0
    */
    DISABLED,
    
    /**
    Practice supports TytoCare device live stream mode - allows the provider to gain real time medical information during the visit

    @since 6.3.0
    */
    TYTO_LIVESTREAM,
    
    /**
    Practice supports TytoCare device live store and forward mode - allows the provider to access pre-recorded medical artifacts, such as medical exams, the consumer recorded prior to starting the visit

    @since 6.3.0
    */
    TYTO_STOREANDFORWARD
};

