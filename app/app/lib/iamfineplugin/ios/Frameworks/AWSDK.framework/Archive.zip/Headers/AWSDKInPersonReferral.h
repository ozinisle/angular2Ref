//
//  AWSDKInPersonReferral.h
//  AWSDK
//
//  Created by Christopher Majoros on 8/4/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <AWSDK/AWSDKDataObject.h>

/**
 Details for an in-person referral.

 @since 6.4.0
 */
@protocol AWSDKInPersonReferral <AWSDKDataObject>

#pragma mark - Read-Only Properties
/**
 @name Read-Only Properties
 */

/**
 AWSDKAddress representing the address for the referral.

 @since 6.4.0
 */
@property (nonatomic, readonly, nullable) id<AWSDKAddress> address;

/**
 NSString representing the referral's unformatted phone number.

 @since 6.4.0
 */
@property (nonatomic, readonly, nullable) NSString *phoneNumber;

/**
 NSString representing the referred provider's name.

 @since 6.4.0
 */
@property (nonatomic, readonly, nullable) NSString *providerName;

/**
 NSString representing the referred facility.

 @since 6.4.0
 */
@property (nonatomic, readonly, nullable) NSString *facilityName;

@end
