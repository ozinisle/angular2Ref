//
//  AWSDKFreCostPollingServicePrivate.h
//  AWSDK
//
//  Created by Ofir Mantsur on 13/08/2019.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <AWSDK/AWSDKFreCompletionBlock.h>

@protocol AWSDKFreCostPollingService

/**
 Init method is unavailable.

 @since 5.3.0
 */
- (nonnull instancetype)init __attribute__((unavailable("Init is not available")));

/**
 New method is unavailable.

 @since 5.3.0
 */
+ (nonnull instancetype)new __attribute__((unavailable("New is not available")));

/**
Initialize a new instance of this class with the given dictionary.

@param params    A dictionary representing the object

@return the object

@since 5.3.0
*/
- (nonnull instancetype)initWithParams:(nonnull NSDictionary *)params;

/**
 Starts the cost polling mechanism for the "visitCost" element. Note that the completion block will be invoked each time until all data received.

 @param url NSString The url of the cost polling request.

 @since 5.3.0
 */
- (void)startCostPollingWithUrl:(nonnull NSString *)url completion:(nullable FreRecommendationsResponseCompletionBlock)completion;

/**
 Stops the cost polling mechanism and clears its objects.

 @since 5.3.0
 */
- (void)stopCostPolling;

@end

@interface AWSDKFreCostPollingService : NSObject

- (nonnull instancetype)init __attribute__((unavailable("Class for internal use only, init is not available")));
+ (nonnull instancetype)new __attribute__((unavailable("Class for internal use only, new is not available")));

- (nonnull instancetype)initWithParams:(nonnull NSDictionary *)params;
- (void)startCostPollingWithUrl:(nonnull NSString *)url completion:(nullable FreRecommendationsResponseCompletionBlock)completion;
- (void)stopCostPolling;

@end
