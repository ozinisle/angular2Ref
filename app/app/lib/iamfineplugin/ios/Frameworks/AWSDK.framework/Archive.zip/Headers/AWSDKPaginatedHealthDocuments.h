//
//  AWSDKPaginatedHealthDocuments.h
//  AWSDK
//
//  Created by Caleb Lindsey on 4/27/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKHealthDocumentSearchRequest.h"
#import "AWSDKPaginated.h"

// clang-format off
@protocol AWSDKHealthDocument;
// clang-format on

/**
 Represents a page of AWSDKHealthDocuments.

 @since 6.2.0
 */
@protocol AWSDKPaginatedHealthDocuments <AWSDKPaginated>

/**
 The list of AWSDKHealthDocuments returned by the search

 @since 6.2.0
 */
@property (nullable, readonly) NSArray<id<AWSDKHealthDocument>> *list;

/**
 The next page in the search if available

 @since 6.2.0
 */
@property (nullable, readonly) id<AWSDKHealthDocumentSearchRequest> nextPage;

/**
 The previous page in the search if available

 @since 6.2.0
 */
@property (nullable, readonly) id<AWSDKHealthDocumentSearchRequest> previousPage;

@end
