//
//  AWSDKVisitReportSearchRequest.h
//  AWSDK
//
//  Created by Caleb Lindsey on 4/27/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <Foundation/Foundation.h>
#import "AWSDKItemSearchOptions.h"
#import "AWSDKItemSearchRequest.h"
#import "AWSDKVisitDisposition.h"

/**
 Represents a search request for fetching AWSDKPaginatedVisitReports.

 @since 6.2.0
 */
@protocol AWSDKVisitReportSearchRequest <AWSDKItemSearchRequest>

/**
 Creates a new AWSDKVisitReportSearchRequest instance.

 @param dispositionMask The dispositions of AWSDKVisitReports in the search.
 @param pageSize The number of AWSDKVisitReports per search.
 @param startIndex The index of the initial AWSDKVisitReport in the search.
 @param scheduledOnly The scheduled status of AWSDKVisitReports in the search.
 @param options An AWSDKItemSearchOptions object for setting additional parameters.

 @return AWSDKVisitReportSearchRequest instance.

 @since 6.2.0
*/
- (nullable instancetype)initWithDispositionMask:(AWSDKVisitDisposition)dispositionMask pageSize:(NSInteger)pageSize startIndex:(NSInteger)startIndex scheduledOnly:(BOOL)scheduledOnly options:(nullable AWSDKItemSearchOptions *)options;

/**
 Creates a new AWSDKVisitReportSearchRequest instance with the specified disposition mask and default values.

 @param dispositionMask The dispositions of AWSDKVisitReports in the search.

 @return AWSDKVisitReportSearchRequest instance.

 @since 6.2.0
*/
- (nullable instancetype)initWithDispositionMask:(AWSDKVisitDisposition)dispositionMask;

/**
 The scheduled status of AWSDKVisitReports in the search.

 @since 6.2.0
 */
@property (nonatomic, readwrite) BOOL scheduledOnly;

/**
 The dispositions of AWSDKVisitReports in the search.

 @since 6.2.0
 */
@property (nonatomic, readwrite) AWSDKVisitDisposition dispositionMask;

@end
