//
//  AWSDKFollowUpItemTypeFilter.h
//  AWSDK
//
//  Created by Caleb Lindsey on 4/27/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#ifndef AWSDKFollowUpItemTypeFilter_h
#define AWSDKFollowUpItemTypeFilter_h

/**
 This enumerated type is used to filter an AWSDKFollowUpItemSearchRequest by item type.

 @since 6.2.0
 */
typedef NS_ENUM(NSInteger, AWSDKFollowUpItemTypeFilter) {
    /**
     Search all types

     @since 6.2.0
     */
    AWSDKFollowUpItemTypeFilterAll,

    /**
     Filter imaging referral types

     @since 6.2.0
     */
    AWSDKFollowUpItemTypeFilterImagingReferral,

    /**
     Filter lab referral types

     @since 6.2.0
     */
    AWSDKFollowUpItemTypeFilterLabReferral,

    /**
     Filter visit referral types

     @since 6.4.0
     */
    AWSDKFollowUpItemTypeFilterVisitReferral,

    /**
     Filter sick slip types

     @since 6.2.0
     */
    AWSDKFollowUpItemTypeFilterSickSlip,

    /**
     Filter all referral types including imaging, lab, and visit referrals

     @since 6.2.0
     */
    AWSDKFollowUpItemTypeFilterReferral,

    /**
     Filter appointment types

     @since 6.2.0
     */
    AWSDKFollowUpItemTypeFilterAppointment,
};

#endif /* AWSDKFollowUpItemTypeFilter_h */
