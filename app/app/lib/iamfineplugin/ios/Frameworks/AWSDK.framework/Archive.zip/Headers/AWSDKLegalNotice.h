//
//  AWSDKLegalNotice.h
//  AWSDK
//
//  Created by Eric Hilton on 10/23/20.
//  Copyright © 2020 American Well. All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#ifndef AWSDKLegalNotice_h
#define AWSDKLegalNotice_h

#import <Foundation/Foundation.h>

#import <AWSDK/AWSDKDataObject.h>

/**
 A legal notice for two-factor authentication.

 @since 6.7.0
 */
@protocol AWSDKLegalNotice <AWSDKDataObject>

#pragma mark - Read-Only Properties
/**
 @name Read-Only Properties
 */

/**
 NSString representing displayable title.

 @since 6.7.0
 */
@property (nonatomic, nonnull, readonly) NSString *title;

/**
 NSString that contains the content of the legal text.

 @since 6.7.0
 */
@property (nonatomic, nonnull, readonly) NSString *legalText;

@end

#endif /* AWSDKLegalNotice_h */
