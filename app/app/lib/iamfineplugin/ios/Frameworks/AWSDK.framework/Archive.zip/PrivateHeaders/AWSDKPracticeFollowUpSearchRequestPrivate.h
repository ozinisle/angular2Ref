//
//  AWSDKPracticeFollowUpSearchRequestPrivate.h
//  AWSDK
//
//  Created by Christopher Majoros on 9/22/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

@interface AWSDKPracticeFollowUpSearchRequest (Private)

+ (AWSDKPracticeFollowUpSearchRequest *)practiceFollowUpSearchRequestWithDictionary:(NSDictionary *)dictionary;

- (NSDictionary *)toParams;

@end
