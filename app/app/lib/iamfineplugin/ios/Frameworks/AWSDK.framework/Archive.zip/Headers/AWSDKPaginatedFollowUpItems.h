//
//  AWSDKPaginatedFollowUpItems.h
//  AWSDK
//
//  Created by Caleb Lindsey on 4/27/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKFollowUpItemSearchRequest.h"
#import "AWSDKPaginated.h"

// clang-format off
@protocol AWSDKFollowUpItem, AWSDKFollowUpItemSearchRequest;
// clang-format on

/**
 Represents a page of AWSDKFollowUpItems.

 @since 6.2.0
 */
@protocol AWSDKPaginatedFollowUpItems <AWSDKPaginated>

/**
 The list of AWSDKFollowUpItems returned by the search

 @since 6.2.0
 */
@property (nullable, readonly) NSArray<id<AWSDKFollowUpItem>> *list;

/**
 The next page in the search if available

 @since 6.2.0
 */
@property (nullable, readonly) id<AWSDKFollowUpItemSearchRequest> nextPage;

/**
 The previous page in the search if available

 @since 6.2.0
 */
@property (nullable, readonly) id<AWSDKFollowUpItemSearchRequest> previousPage;

@end
