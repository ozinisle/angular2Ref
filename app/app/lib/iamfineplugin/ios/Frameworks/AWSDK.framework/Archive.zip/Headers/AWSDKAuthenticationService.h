//
//  AWSDKAuthenticationService.h
//  AWSDK
//
//  Created by Jeremiah.Possion on 1/23/17.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <AWSDK/AWSDKCompletionBlock.h>
#import <AWSDK/AWSDKDataObject.h>

@protocol AWCoreGuestConsoleDelegate;

/**
 The Notification that is broadcast whenever the rotating auth token expires and the SDK requires reauthentication with user credentials to continue.

 @since 4.0.0
 */
extern NSString *_Nonnull const AWSDKConsumerDeauthenticatedNotification;

/**
 Service for authentication.

 @since 3.0.0
 */
@protocol AWSDKAuthenticationService <AWSDKDataObject>

#pragma mark - Consumer Authentication
/**
 @name Consumer Authentication
 */

/**
 Authenticates a consumer with the Amwell Home platform using their credentials.

 @discussion  Authentication via username/password or consumerAuthKey is required before any other action may be taken with a consumer. Authenticating will return an AWSDKConsumer instance for the specified consumer.

 @note Valid username and passwords are determined by the server configuration. By default the allowed special characters are "@", "#", and "$".

 @param username        NSString representing the consumer's username used to log into the telehealth platform.
 @param password        NSString representing the consumer's password used to log into the telehealth platform.
 @param consumerAuthKey NSString representing a shared unique identifier that matches a user on the Amwell Home platform to a user of your application. This value is optional, and if there's no value already associated to the consumer's account, then one will be randomly generated for the user upon successful authentication.
 @param completion      AuthenticationResultCompletionBlock containing an AWSDKConsumer or AWSDKPartialConsumer object upon successful login, otherwise an NSError which reports if any errors occurred during the authentication.

 @exception AWSDKErrorCodeValidationRequiredParameterMissing    Missing parameter.
 @exception AWSDKErrorCodeAuthenticationAccessDenied            The credentials didn't match a user on the telehealth platform.
 @exception AWSDKErrorCodeUpdateConsumerKeyFailed               Updating the consumer auth key failed.
 @exception AWSDKErrorCodePartiallyEnrolledUser                 The user is partially enrolled and needs to update their current state to proceed. See [AWSDKPartialConsumer completeRegistrationWithLocation:username:newUsername:password:newPassword:completion:] for more details.

 @since 3.0.0
 @deprecated 6.7.0
 @warning Deprecated as of 6.7.0, use authenticateConsumerWithUsername:password:twoFactorTrustDeviceToken:completion:
 */

+ (void)authenticateConsumerWithUsername:(nonnull NSString *)username
                                password:(nonnull NSString *)password
                         consumerAuthKey:(nullable NSString *)consumerAuthKey
                              completion:(nonnull AuthenticationResultCompletionBlock)completion __attribute__((deprecated("Deprecated as of 6.7.0, use authenticateConsumerWithUsername:password:twoFactorTrustDeviceToken:completion:")));

/**
 Authenticates a consumer with the Amwell Home platform using their credentials.

 @discussion  Authentication via username/password is required before any other action may be taken with a consumer. Authenticating will return an AWSDKConsumer instance for the
 specified consumer.

 @note Valid username and passwords are determined by the server configuration. By default the allowed special characters are "@", "#", and "$".

 @param username                    NSString representing the consumer's username used to log into the telehealth platform.
 @param password                    NSString representing the consumer's password used to log into the telehealth platform.
 @param twoFactorTrustDeviceToken   NSString representing the token provided on a previous two-factor authentication to skip two-factor authentication on subsequent logins.
 @param completion                  AuthenticationResultCompletionBlock containing an AWSDKConsumer, AWSDKPartialConsumer, or AWSDKConsumerAuthentication object upon successful login, otherwise an NSError which reports if any errors occurred during the authentication.

 @exception AWSDKErrorCodeValidationRequiredParameterMissing    Missing parameter.
 @exception AWSDKErrorCodeAuthenticationAccessDenied            The credentials didn't match a user on the telehealth platform.
 @exception AWSDKErrorCodePartiallyEnrolledUser                 The user is partially enrolled and needs to update their current state to proceed. See [AWSDKPartialConsumer completeRegistrationWithLocation:username:newUsername:password:newPassword:completion:] for more details.
 @exception AWSDKErrorCodeTwoFactorUnauthenticated              The user is partially authenticated and needs to complete two-factor authentication. See [AWSDKTwoFactorAuthentication.requiredAction] for more details.
 
 @since 6.7.0
 */
+ (void)authenticateConsumerWithUsername:(nonnull NSString *)username
                                password:(nonnull NSString *)password
               twoFactorTrustDeviceToken:(nullable NSString *)twoFactorTrustDeviceToken
                              completion:(nonnull AuthenticationResultCompletionBlock)completion;

/**
 Authenticates a consumer using a server to server connection given a token.

 @param token      NSString representing the security token used for authenticating.
 @param completion AuthenticationResultCompletionBlock containing the AWSDKConsumer or AWSDKPartialConsumer object for the specified consumer, otherwise an NSError which reports if any errors occurred
 during the authentication.

 @since 3.0.0
 */
+ (void)authenticateMutualAuthWithToken:(nonnull NSString *)token completion:(nonnull AuthenticationResultCompletionBlock)completion;

#pragma mark - Guest Authentication
/**
 @name Guest Authentication
 */

/**
 Authenticates a guest for a visit and provides an AWCoreVisitConsoleController to present for the guest visit.

 @param url        NSURL representing the url used to launch the application. This will be generated by the Amwell Home platform, and when passed to supportedFeatureForUrl will return
 AWSDKFeatureGuestInvite.
 @param email      NSString representing the email address the guest invite was sent to. This must match the email address entered by the consumer or provider when sending the invite. The email
 address and the url are used for authenticating the guest.
 @param name       NSString representing the guest display name in the visit.
 @param delegate   AWCoreGuestConsoleDelegate to send messages about the visit status to.
 @param completion VisitConsoleCompletionBlock containing an AWCoreVisitConsoleController if the guest is successfully authenticated, otherwise an NSError explaining any failures.

 @since 3.0.0
 */
+ (void)authenticateGuestWithURL:(nonnull NSURL *)url
                           email:(nonnull NSString *)email
                            name:(nonnull NSString *)name
                        delegate:(nonnull id<AWCoreGuestConsoleDelegate>)delegate
                      completion:(nonnull VisitConsoleCompletionBlock)completion;

#pragma mark - Authentication Help Methods
/**
 @name Authentication Help Methods
 */

/**
 Retrieves a forgotten username for the consumer.

 @discussion The last name and dob are used for validating the user's account. If no error is present in the StringResultCompletionBlock, then the request was successful. However, this does not
 confirm the existence of an account under the provided credentials. Note that if the consumer's username is not their email address, which may be the case for feed users, this method's
 StringResultCompletionBlock will contain _nil_ for both the result and the error. In this case the username is emailed to the user.

 @param lastName   NSString representing the last name of the user.
 @param dob        NSDate representing the user's date of birth in the UTC timeZone.
 @param completion StringResultCompletionBlock containing the user's partial username as a string such as "k***@a***.net" for "Ken.smith@americanwell.net", otherwise an NSError explaining what went
 wrong.

 @since 4.1.0
 */
+ (void)getUsernameForUserWithLastName:(nonnull NSString *)lastName dateOfBirth:(nonnull NSDate *)dob completion:(nonnull StringResultCompletionBlock)completion;

/**
 Request for the server to send an email to the email address on file that contains instructions to reset a consumer's password.

 @discussion The lastName, dob, and email are used for validating the user's account. The email will contain a link to take the consumer to a page on the web interface to enter a new password.

 @note Valid emails are determined by the server configuration. By default the following special characters are currently allowed: "@", "#", and "$".

 @param lastName   NSString representing the last name of the user.
 @param dob        NSDate representing the user's date of birth.
 @param email      NSString representing the user's email address.
 @param completion GenericCompletionBlock containing _TRUE_ if the network call was successful, otherwise _FALSE_ and an NSError explaining any errors.


 @since 4.1.0
 */
+ (void)resetPasswordWithLastName:(nonnull NSString *)lastName dateOfBirth:(nonnull NSDate *)dob email:(nonnull NSString *)email completion:(nullable GenericCompletionBlock)completion;

@end

/**
 Service for authentication.

 @since 3.0.0
 */
@interface AWSDKAuthenticationService : AWSDKDataObject <AWSDKAuthenticationService>
#pragma mark - Appledoc
+ (void)authenticateConsumerWithUsername:(nonnull NSString *)username
                                password:(nonnull NSString *)password
               twoFactorTrustDeviceToken:(nullable NSString *)twoFactorTrustDeviceToken
                              completion:(nonnull AuthenticationResultCompletionBlock)completion;
+ (void)authenticateMutualAuthWithToken:(nonnull NSString *)token completion:(nonnull AuthenticationResultCompletionBlock)completion;
+ (void)authenticateGuestWithURL:(nonnull NSURL *)url
                           email:(nonnull NSString *)email
                            name:(nonnull NSString *)name
                        delegate:(nonnull id<AWCoreGuestConsoleDelegate>)delegate
                      completion:(nonnull VisitConsoleCompletionBlock)completion;
+ (void)getUsernameForUserWithLastName:(nonnull NSString *)lastName dateOfBirth:(nonnull NSDate *)dob completion:(nonnull StringResultCompletionBlock)completion;
+ (void)resetPasswordWithLastName:(nonnull NSString *)lastName dateOfBirth:(nonnull NSDate *)dob email:(nonnull NSString *)email completion:(nullable GenericCompletionBlock)completion;
#pragma mark -
@end
