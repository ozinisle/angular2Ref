//
//  AWSDKPracticeFollowUpItemPrivate.h
//  AWSDK
//
//  Created by Christopher Majoros on 9/24/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKFollowUpItemPrivate.h"

#import <AWSDK/AWSDKPracticeFollowUpItem.h>

/**
 A follow-up item that the consumer has been suggested to schedule with another practice.

 @since 6.6.0
 */
@interface AWSDKPracticeFollowUpItem : AWSDKFollowUpItem<AWSDKPracticeFollowUpItem>

+ (NSArray<AWSDKPracticeFollowUpItem> *)arrayFromDictionary:(NSDictionary *)dict;

@end
