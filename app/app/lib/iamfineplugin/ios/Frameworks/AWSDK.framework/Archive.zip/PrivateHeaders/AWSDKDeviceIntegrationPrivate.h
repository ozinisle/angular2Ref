//
//  AWSDKDeviceIntegrationPrivatePrivate.h
//  AWSDK
//
//  Created by Stephen Ciauri on 12/10/18.
//  Copyright © 2018 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKDataObjectPrivate.h"
#import "AWSDKDeviceIntegration.h"
#import "AWSDKExamDataPrivate.h"

#import <Foundation/Foundation.h>

@interface AWSDKDeviceIntegration : AWSDKDataObject <AWSDKDeviceIntegration>

+ (NSArray<AWSDKDeviceIntegration *> *)deviceIntegrationsFromJSONArray:(NSArray<NSDictionary *> *)jsonArray;

- (AWSDKDeviceIntegrationPairingStatus)integrationStatusFromString:(NSString *)statusString;

@property (nonatomic, readwrite) NSArray<AWSDKExamData *> *examData;

@property (nonatomic, readwrite) NSURL *href;

@property (nonatomic, readwrite) AWSDKDeviceIntegrationType integrationType;

@property (nonatomic, readwrite) AWSDKDeviceIntegrationPairingStatus pairingStatus;

@property (nonatomic, readwrite) NSString *encryptedDeviceIntegrationAuditId;

@property (nonatomic, readwrite) BOOL isOnline;

@property (nonatomic, readwrite) BOOL isDevicePaired;

@property (nonatomic, readwrite) NSString *pairingCode;

@property (nonatomic, readwrite) NSString *applicationServerUrl;

@end
