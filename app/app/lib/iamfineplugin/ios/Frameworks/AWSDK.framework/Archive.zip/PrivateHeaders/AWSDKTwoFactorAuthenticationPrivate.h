//
//  AWSDKTwoFactorAuthenticationPrivate.h
//  AWSDK
//
//  Created by Steve Trombley on 2/20/20.
//  Copyright © 2020 American Well. All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKTwoFactorAuthentication.h"

@class AWSDKConsumerAuthentication;

@interface AWSDKTwoFactorAuthentication : AWSDKDataObject <AWSDKTwoFactorAuthentication>

@property (readwrite) AWSDKTwoFactorAuthenticationRequiredAction requiredAction;
@property (readwrite) AWSDKTwoFactorAuthenticationConfiguration configuration;
@property (readwrite, nullable) NSString *phoneLastFourDigits;
@property (readwrite, nullable) NSString *trustDeviceToken;

+ (AWSDKTwoFactorAuthentication *_Nonnull)twoFactorAuthenticationWithDictionary:(NSDictionary *_Nonnull)values;

+ (AWSDKTwoFactorAuthenticationRequiredAction)requiredActionFromString:(NSString *_Nullable)requiredActionString;
+ (AWSDKTwoFactorAuthenticationConfiguration)configurationFromString:(NSString *_Nullable)configurationString;

@end
