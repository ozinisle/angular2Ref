//
//  AWSDKPastProvidersSearchRequest.h
//  AWSDK
//
//  Created by Caleb Lindsey on 8/18/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKPastProvidersSearchRequest.h"

#import <AWSDK/AWSDKDataObject.h>
#import <Foundation/Foundation.h>

/**
 This enumerated type is used to search an AWSDKPractice by type.

 @since 6.4.0
 */
typedef NS_ENUM(NSInteger, AWSDKPracticeSearchType) {
    /**
     Include all practice types within the search

     @since 6.4.0
     */
    AWSDKPracticeSearchTypeAny,

    /**
     Search by on demand types

     @since 6.4.0
     */
    AWSDKPracticeSearchTypeOnDemand,

    /**
     Search by self schedule types

     @since 6.4.0
     */
    AWSDKPracticeSearchTypeSelfSchedule,
};

@protocol AWSDKPractice;

/**
 Represents a search request for fetching AWSDKProviders.

 @since 6.4.0
 */
@protocol AWSDKPastProvidersSearchRequest <AWSDKDataObject>

/**
 The maximum number of results for the search.

 @since 6.4.0
 */
@property (nonatomic, readwrite, nullable) NSNumber *maxResults;

/**
 The practice to search within.

 @since 6.4.0
 */
@property (nonatomic, readwrite, nullable) id<AWSDKPractice> practice;

/**
 The type of practice to search within.

 @note Defaults to AWSDKPracticeSearchTypeAny

 @since 6.4.0
 */
@property (nonatomic, assign, readwrite) AWSDKPracticeSearchType practiceSearchType;

@end

/**
Represents a search request for fetching AWSDKProviders.

@since 6.4.0
*/
@interface AWSDKPastProvidersSearchRequest : AWSDKDataObject <AWSDKPastProvidersSearchRequest>

/**
 Returns an AWSDKPastProvidersSearchRequest.

 @return instance of AWSDKPastProvidersSearchRequest.

 @since 6.4.0
 */
+ (nullable instancetype)request;

@end
