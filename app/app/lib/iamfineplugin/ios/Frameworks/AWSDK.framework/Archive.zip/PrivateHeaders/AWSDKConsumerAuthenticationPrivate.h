//
//  AWSDKConsumerAuthenticationPrivate.h
//  AWSDK
//
//  Created by Steve Trombley on 1/30/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKConsumerAuthentication.h"

#import "AWSDKConsumerPrivate.h"
#import "AWSDKLegalTextPrivate.h"
#import "AWSDKTwoFactorAuthenticationPrivate.h"
#import "BasicAuthCredentials.h"

@interface AWSDKConsumerAuthentication : AWSDKDataObject <AWSDKConsumerAuthentication>

// Exposed as Read-only
@property BOOL partiallyEnrolled;
@property BOOL systemGeneratedCredentials;
@property BOOL fullyAuthenticated;
@property (nonatomic) AWSDKLegalText *_Nullable outstandingDisclaimer;
@property (nonatomic) AWSDKTwoFactorAuthentication *_Nullable twoFactorAuthInfo;

// Not Exposed
@property (nonatomic) NSString *_Nonnull consumerAuthKey;
@property (nonatomic) id<NetworkCredentials> _Nonnull credentials;
@property (nonatomic) NSString *_Nullable encryptedID;
@property (nonatomic, readwrite) id<AWSDKConsumer> _Nullable consumer;

- (void)acceptOutstandingDisclaimer:(nullable GenericCompletionBlock)completion;

@end
