//
//  AWSDKOnlineVisitFollowUpItemPrivate.h
//  AWSDK
//
//  Created by Christopher Majoros on 8/18/20.
//  Copyright © 2020 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import "AWSDKFollowUpItemPrivate.h"

#import <AWSDK/AWSDKOnlineVisitFollowUpItem.h>

/**
 An online visit that the consumer has been suggested to schedule.

 @since 6.4.0
 */
@interface AWSDKOnlineVisitFollowUpItem : AWSDKFollowUpItem<AWSDKOnlineVisitFollowUpItem>

+ (NSArray<AWSDKOnlineVisitFollowUpItem> *)arrayFromDictionary:(NSDictionary *)dict;

@end
