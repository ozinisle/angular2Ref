//
//  AWSDKFreRecommendationsService.h
//  AWSDK
//
//  Created by Ofir Mantsur on 17/06/2019.
//  Copyright © 2019 American Well.
//  All rights reserved.
//
//  It is illegal to use, reproduce or distribute
//  any part of this Intellectual Property without
//  prior written authorization from American Well.
//

#import <AWSDK/AWSDKDemographicForm.h>
#import <AWSDK/AWSDKFreCompletionBlock.h>

/**
 Service handling the FRE related tasks.

 @since 5.3.0
 */

@protocol AWSDKFreRecommendationsService

/**
 Init method is unavailable.

 @since 5.3.0
 */
- (nonnull instancetype)init __attribute__((unavailable("'init' is not available, use sharedInstance instead")));

/**
 New method is unavailable.

 @since 5.3.0
 */
+ (nonnull instancetype)new __attribute__((unavailable("'new' is not available, use sharedInstance instead")));

/**
 The singleton's instance.

 @since 5.3.0
 */
+ (instancetype _Nonnull)sharedInstance;

#pragma mark - FreRecommendationsService Methods

/**
 Indicator whether initialization process was successful.
 
 @since 5.3.0
 */
- (BOOL)isFreInitialized;

/**
 "Clears" the service by creating a new instance.

 @since 5.3.0
 */
- (void)clear;

/**
Initialze the FRE server and returns a FreInitializationCompletionBlock, given a baseUrl and cfg id.

 @param freBaseUrl  NSString Representing the base url of the FREAWSDKFreRecommendationsService.h server.
 @param cfgId       NSString Representing the cfg identifier.
 @param completion  FreInitializationCompletionBlock Completion block containing an array of AWSDKFreHealthPlan and AWSDKFreService objects, otherwise an NSError which reports any errors that occurred.

 @exception AWSDKErrorCodeValidationRequiredParameterMissing    Parameter is missing or invalid.

 @since 5.3.0
 */
- (void)initializeFreWithBaseUrl:(nonnull NSString *)freBaseUrl cfgId:(nonnull NSString *)cfgId completion:(nullable FreInitializationCompletionBlock)completion;

/**
 Fetches an array of AWSDKFreRecommendation objects, given the inputs specified.

 @param requestId            NSString The request id.
 @param stateAbbreviation    NSString The state selected.
 @param healthPlanQualifier  NSString The specific FRE health plan selected.
 @param serviceId            NSString The selected service id.
 @param subscriberId         NSString The subscriber id of the user.
 @param suffix               NSString The suffix for the subscriber id that was set.
 @param demographicForm      AWSDKDemographicForm The user's demographics data.
 @param completion           FreRecommendationsResponseCompletionBlock Completion block containing an array of AWSDKFreRecommendation objects, otherwise an NSError which reports any errors that occurred.

 @exception AWSDKFreErrorCodeUninitialized   The FRE initialization process was not complete.
 @exception AWSDKFreErrorCodeInternalError   An unexpected internal error occurred.

 @since 5.3.0
 */
- (void)getRecommendationsWithRequestId:(nullable NSString *)requestId
                      stateAbbreviation:(nonnull NSString *)stateAbbreviation
                    healthPlanQualifier:(nullable NSString *)healthPlanQualifier
                              serviceId:(nullable NSString *)serviceId
                           subscriberId:(nullable NSString *)subscriberId
                                 suffix:(nullable NSString *)suffix
                        demographicForm:(nullable AWSDKDemographicForm *)demographicForm
                             completion:(nullable FreRecommendationsResponseCompletionBlock)completion;

/**
 Starts the cost recommendations tracking mechanism for the "visitCost" element. Note that the completion block will be invoked each time until its timer ends, or 3 consecutive request failures.

 @param trackingId  NSString The tracking cost id, which is a unique identifier returned from the getRecommendationsWithRequestId response.
 @param requestId   NSString The request id.
 @param completion  FreRecommendationsResponseCompletionBlock Completion block containing an array of AWSDKFreRecommendation objects, otherwise an NSError which reports any errors that occurred.

 @exception AWSDKFreErrorCodeUninitialized   The FRE initialization process was not complete.
 @exception AWSDKFreErrorCodeInternalError   An unexpected internal error occurred.

 @since 5.3.0
 */
- (void)getRecommendationsAdditionalDataWithTrackingId:(nonnull NSString *)trackingId
                                             requestId:(nullable NSString *)requestId
                                            completion:(nullable FreRecommendationsResponseCompletionBlock)completion;

/**
 Stops the recommendations tracking mechanism.

 @since 5.3.0
 */
- (void)stopRecommendationsAdditionalData;

@end
#pragma mark - Appledoc
@interface AWSDKFreRecommendationsService : NSObject

- (nonnull instancetype)init __attribute__((unavailable("Class for internal use only, init is not available")));
+ (nonnull instancetype)new __attribute__((unavailable("Class for internal use only, new is not available")));

+ (instancetype _Nonnull)sharedInstance;
- (BOOL)isFreInitialized;
- (void)clear;
- (void)initializeFreWithBaseUrl:(nonnull NSString *)freBaseUrl cfgId:(nonnull NSString *)cfgId completion:(nullable FreInitializationCompletionBlock)completion;
- (void)getRecommendationsWithRequestId:(nullable NSString *)requestId
                      stateAbbreviation:(nonnull NSString *)stateAbbreviation
                    healthPlanQualifier:(nullable NSString *)healthPlanQualifier
                              serviceId:(nullable NSString *)serviceId
                           subscriberId:(nullable NSString *)subscriberId
                                 suffix:(nullable NSString *)suffix
                        demographicForm:(nullable AWSDKDemographicForm *)demographicForm
                             completion:(nullable FreRecommendationsResponseCompletionBlock)completion;
- (void)getRecommendationsAdditionalDataWithTrackingId:(nonnull NSString *)trackingId
                                             requestId:(nullable NSString *)requestId
                                            completion:(nullable FreRecommendationsResponseCompletionBlock)completion;
- (void)stopRecommendationsAdditionalData;
@end
