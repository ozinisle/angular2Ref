//
//  AppointmentService.swift
//  AmwellPlugin
//
//  Created by Miraj, Kusum on 4/19/21.
//

import Foundation
import Capacitor
import AWSDK

class AppointmentService {
    var logService: LogService
    
    init(logService: LogService) {
        self.logService = logService
    }
    
    func findProviders(
        for consumer: AWSDKConsumer,
        _ practice: AWSDKPractice,
        _ state: AWSDKState,
        _ call: CAPPluginCall,
        _ completion: @escaping ([AWSDKProvider]) -> Void)
    {
        let appointmentDate = call.getString(Constants.Call.availableOnDate)
        self.logService.log("##: Appointment Date: \(String(describing: appointmentDate))")
        // set the providerSearchOptions
        let providerSearchOptions = AWSDKProviderSearchOptions()
        providerSearchOptions.consumer = consumer
        providerSearchOptions.state = state
        providerSearchOptions.practice = practice
        if let date = DateUtil.utcDate(from: appointmentDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'") {
            self.logService.log("##: Converted Appointment Date: \(date)")
            providerSearchOptions.appointmentDate = date
        } else {
            providerSearchOptions.nextAppointmentDate = true
        }
        
        let group = DispatchGroup()
        var providerJSON = [Any]()
        
        let fetchProviders: (AWSDKAvailableProviderSearchResults) -> Void = { availableProviderSearchResults in
            // validation
            guard availableProviderSearchResults.providerSearchResults.count >= 1 else {
                ResponseHelper.sendErrorResponse(
                    to: call,
                    with: "No providers found for selected date"
                )
                completion([])
                return
            }
            
            var providers = [AWSDKProvider]()
            // fetch provider details
            for searchResult in availableProviderSearchResults.providerSearchResults {
                group.enter()
                searchResult.fetchDetails { [weak self] provider, error in
                    guard let strongSelf = self else { return }
                    
                    if let error = error {
                        ResponseHelper.sendErrorResponse(to: call, error: error)
                        return
                    }
                    
                    guard let provider = provider else { return }
                    
                    // verify if provider's practice supports video
                    if let modalities = provider.practice?.availableModalities,
                       modalities.filter({ $0.code == .video }).count == 0 {
                        return
                    }
                    
                    let dates = strongSelf.getScheduleDates(searchResult.availableAppointmentSchedules)
                    providers.append(provider)
                    var json = ResponseHelper.getProviderJSON(from: provider, isDetail: false)
                    json[Constants.ScheduleAppointment.availableTimeSlots] = dates
                    providerJSON.append(json)
                    group.leave()
                }
                
                // send the response with all provider's details
                group.notify(queue: .main) {
                    ResponseHelper.sendResponse(to: call, providerJSON)
                    completion(providers)
                }
            }
        }
        
        AWSDKProviderService.fetchAvailableProviders(with: providerSearchOptions) { searchResults, error in
            guard let providerSearchResults = searchResults else {
                ResponseHelper.sendErrorResponse(to: call, with: "No Providers Found")
                completion([])
                return
            }
            
            fetchProviders(providerSearchResults)
        }
    }
    
    func scheduleAppointment(
        for consumer: AWSDKConsumer,
        _ provider: AWSDKProvider,
        _ call: CAPPluginCall,
        _ completion: @escaping () -> Void
    ) {
        guard let timeSlot = call.getString(Constants.Call.timeSlot) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Parameter timeSlot is required.")
            completion()
            return
        }
        
        self.logService.log("##: scheduleAppointment date string: \(timeSlot)")
        guard let date = DateUtil.utcDate(from: timeSlot, "yyyy-MM-dd'T'HH:mm:ss'Z'") else {
            ResponseHelper.sendErrorResponse(to: call, with: "Parameter timeSlot is invalid.")
            completion()
            return
        }
        
        self.logService.log("##: scheduleAppointment date string: \(timeSlot), Date: \(date)")
        let phoneNumber = call.getString(Constants.Call.phoneNumber)
        
        var reminderMinutes = 0
        if let reminderOption = call.getObject(Constants.Call.reminderOption),
           let minutes = reminderOption[Constants.ReminderOption.minutes] as? Int {
            reminderMinutes = minutes
        }
        
        let availableReminderOptions = AWSDKAppointment.availableReminderOptions
        let providerReminderOption = availableReminderOptions[0]
        
        var consumerReminderOption = availableReminderOptions[0]
        if let reminderOption = availableReminderOptions.first(where: { $0.minutes == reminderMinutes }) {
            consumerReminderOption = reminderOption
        }
        
        provider.fetchAvailableAppointments(on: date) { schedules, error in
            guard let schedules = schedules else {
                ResponseHelper.sendErrorResponse(to: call, with: "Provider schedules not found!")
                completion()
                return
            }
            
            if let practice = provider.practice,
               let schedule = schedules.first(where: { $0.scheduledStartTime?.compare(date) == ComparisonResult.orderedSame })
            {
                self.logService.log("##: Scheduling Now!!")
                consumer.scheduleAppointment(
                    with: provider,
                    in: practice,
                    with: schedule,
                    withPhoneNumber: phoneNumber,
                    withConsumerReminderOption: consumerReminderOption,
                    withProviderReminderOption: providerReminderOption,
                    withCompletion: { success, error in
                        ResponseHelper.handleResponse(
                            for: call,
                            success,
                            error,
                            alternateErrorMessage: "Schedule Appointment Failed."
                        )
                        completion()
                })
            } else {
                let error = NSError(
                    domain: "com.americanwell.awsdk.errordomain.sdk",
                    code: 404,
                    userInfo: ["message": "This appointment slot is no longer available. Please select a new time."]
                )
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion()
            }
        }
    }
    
    func findAppointmentBySourceID(for consumer: AWSDKConsumer, _ call: CAPPluginCall, _ completion: @escaping () -> Void) {
        guard let appointmentSourceID = call.getString(Constants.Call.appointmentSourceID) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Parameter appointmentSourceId is required.")
            completion()
            return
        }
        
        consumer.fetchAppointment(withSourceId: appointmentSourceID, completion: { appointmentProtocol, error in
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion()
                return
            }
            
            guard let appointmentProtocol = appointmentProtocol else {
                ResponseHelper.sendNULLResponse(to: call)
                completion()
                return
            }
            
            ResponseHelper.validateAndSend(
                ResponseHelper.getAppointmentJSON(appointmentProtocol, appointmentSourceID),
                to: call
            )
            completion()
        })
    }
    
    func findAppointments(for consumer: AWSDKConsumer, _ call: CAPPluginCall, _ completion: @escaping () -> Void) {
        guard let startingDate = call.getString(Constants.Call.startingFromDate) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Parameter startingFromDate is required.")
            return
        }
        
        let date = DateUtil.utcDate(from: startingDate, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
        consumer.getAppointmentsSince(date) { appointments, error in
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion()
                return
            }
            
            guard let appointments = appointments else {
                ResponseHelper.sendNULLResponse(to: call)
                completion()
                return
            }
            
            var appointmentsJSON = [Dictionary<String, Any>]()
            appointments.forEach { appointment in
                guard let sourceID = appointment.sourceId else { return }
                appointmentsJSON.append(ResponseHelper.getAppointmentJSON(appointment, sourceID))
            }
            
            ResponseHelper.validateAndSend(appointmentsJSON, to: call)
            completion()
        }
    }
    
    func cancelAppointment(with sourceID: String, for consumer: AWSDKConsumer, _ call: CAPPluginCall, _ completion: @escaping () -> Void) {
        consumer.fetchAppointment(withSourceId: sourceID) { appointment, error in
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion()
                return
            }
            
            guard let appointment = appointment else { return }
            
            appointment.cancel { success, error in
                ResponseHelper.handleResponse(for: call, success, error, alternateErrorMessage: "Cancel Appointment Failed.")
                completion()
            }
        }
    }
    
    func fetchAvailableAppointments(
        for provider: AWSDKProvider,
        on dateString: String,
        _ consumer: AWSDKConsumer,
        _ call: CAPPluginCall,
        _ completion: @escaping () -> Void)
    {
        let providerSearchOptions = AWSDKProviderSearchOptions()
        providerSearchOptions.consumer = consumer
        providerSearchOptions.appointmentDate = DateUtil.utcDate(from: dateString, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
        providerSearchOptions.practice = provider.practice
        
        AWSDKProviderService.fetchAvailableProviders(with: providerSearchOptions) { [weak self] providerSearchResult, error in
            guard let strongSelf = self else { return }
            
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion()
            }
            
            // validation
            guard let providerSearchResult = providerSearchResult,
                providerSearchResult.providerSearchResults.count >= 1 else {
                ResponseHelper.sendErrorResponse(
                    to: call,
                    error: ResponseHelper.getError(for: AWSDKErrorCode.errorCodeProviderNotFound)
                )
                completion()
                return
            }
            
            // send error if provider match is not found
            if providerSearchResult.providerSearchResults.first(where: { $0.sourceID == provider.sourceID }) == nil {
                ResponseHelper.sendErrorResponse(to: call, with: "Provider match not found.")
                completion()
            }
            
            providerSearchResult.providerSearchResults.forEach { providerSearchResult in
                if providerSearchResult.sourceID == provider.sourceID {
                    strongSelf.logService.log("##: Provider match found.")
                    let dates = strongSelf.getScheduleDates(providerSearchResult.availableAppointmentSchedules)
                    ResponseHelper.validateAndSend(dates, to: call)
                    completion()
                }
            }
        }
    }
    
    // MARK: - Private
    
    private func getScheduleDates(_ schedules: [AWSDKSchedule]) -> [String] {
        var dates = [String]()
        schedules.forEach { schedule in
            if let apptDate = schedule.scheduledStartTime {
               let date = DateUtil.ISODateString(from: apptDate)
                self.logService.log("##: schedules: \(apptDate)")
                self.logService.log("##: Updated schedules: \(date)")
                dates.append(date)
            }
        }
        
        return dates
    }
}
