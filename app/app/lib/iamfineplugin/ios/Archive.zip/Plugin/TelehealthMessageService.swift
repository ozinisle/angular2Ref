//
//  TelehealthMessageService.swift
//  AmwellPlugin
//
//  Created by Miraj, Kusum on 4/27/21.
//

import Foundation
import Capacitor
import AWSDK

class TelehealthMessageService {
    var logService: LogService
    
    init(logService: LogService) {
        self.logService = logService
    }
    
    func fetchMailbox(for consumer: AWSDKConsumer, _ call: CAPPluginCall, _ completion: @escaping (Dictionary<String, AWSDKMessage>?) -> Void) {
        guard let mailboxType = call.getString(Constants.Call.mailboxType) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Parameter mailboxType is required.")
            return
        }
        
        guard let mailbox = TelehealthMailboxType(rawValue: mailboxType) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Parameter mailboxType must be one of ['INBOX', 'SENT'].")
            return
        }
        
        let handleFetchMessageFolderResponse: (AWSDKMessageFolder?, Error?) -> Void = { messageFolder, error in
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion(nil)
            }
            
            guard let messageFolder = messageFolder else {
                ResponseHelper.sendErrorResponse(to: call, with: "Empty Message Folder")
                completion(nil)
                return
            }
            
            if let inboxFolder = messageFolder as? AWSDKMessageFolderInbox {
                let response = ResponseHelper.getInboxFolderJSON(inboxFolder)
                ResponseHelper.validateAndSend(response.json, to: call)
                completion(response.messages)
            } else if let sentFolder = messageFolder as? AWSDKMessageFolderSent {
                let response = ResponseHelper.getSentFolderJSON(sentFolder)
                ResponseHelper.validateAndSend(response.json, to: call)
                completion(response.messages)
            }
        }
        
        switch mailbox {
        case .inbox:
            consumer.fetchMessageInbox(with: getMessageFetchOptions(from: call)) { messageFolder, error in
                handleFetchMessageFolderResponse(messageFolder, error)
            }
        case .sent:
            consumer.fetchSentMessageFolder(with: getMessageFetchOptions(from: call)) { messageFolder, error in
                handleFetchMessageFolderResponse(messageFolder, error)
            }
        }
    }
    
    func markMessageRead(_ message: AWSDKInboxMessage, _ call: CAPPluginCall, _ completion: @escaping () -> Void) {
        message.markRead { success, error in
            ResponseHelper.handleResponse(for: call, success, error, alternateErrorMessage: "Unable to mark message as read")
            completion()
        }
    }
    
    func fetchMessageDetail(
        with message: AWSDKMessage,
        _ messageID: String,
        _ consumer: AWSDKConsumer,
        _ call: CAPPluginCall,
        _ completion: @escaping (AWSDKMessage?, [String: AWSDKAttachment]?) -> Void)
    {
        guard let mailboxType = call.getString(Constants.Call.mailboxType) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Parameter mailboxType is required.")
            return
        }
        
        message.fetch { messageDetail, error in
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion(nil, nil)
            }
            
            if let inboxMessageDetail = messageDetail as? AWSDKInboxMessageDetails,
               mailboxType == TelehealthMailboxType.inbox.rawValue
            {
                let response = ResponseHelper.getInboxMessageDetailJSON(inboxMessageDetail, messageID)
                ResponseHelper.validateAndSend(response.json, to: call)
                completion(messageDetail, response.info)
            } else if let sentMessageDetail = messageDetail as? AWSDKSentMessageDetails,
                mailboxType == TelehealthMailboxType.sent.rawValue
            {
                let response = ResponseHelper.getSentMessageDetailJSON(sentMessageDetail, messageID)
                ResponseHelper.validateAndSend(response.json, to: call)
                completion(messageDetail, response.info)
            }
        }
    }
    
    func fetchMessageTopics(_ call: CAPPluginCall, _ completion: @escaping ([AWSDKMessageTopicProtocol]?) -> Void) {
        AWSDKMessageTopic.fetchAvailableTopics { messageTopics, error in
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion(nil)
            }
            
            guard let messageTopics = messageTopics else {
                ResponseHelper.sendErrorResponse(to: call, with: "No Message Topics found.")
                completion(nil)
                return
            }
            
            ResponseHelper.validateAndSend(ResponseHelper.getMessageTopicJSON(for: messageTopics), to: call)
            completion(messageTopics)
        }
    }
    
    func fetchMessageContacts(for consumer: AWSDKConsumer, _ call: CAPPluginCall, _ completion: @escaping ([String: AWSDKContact]?) -> Void) {
        consumer.fetchMessageContacts { contacts, error in
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion(nil)
            }
            
            guard let contacts = contacts else {
                ResponseHelper.sendErrorResponse(to: call, with: "No Message Contacts found.")
                completion(nil)
                return
            }
            
            let response = ResponseHelper.getMessageContacts(contacts)
            ResponseHelper.validateAndSend(response.json, to: call)
            completion(response.info)
        }
    }
    
    func fetchMessageDraft(
        for consumer: AWSDKConsumer,
        with draftType: TelehealthMessageDraftType,
        _ message: AWSDKMessage?,
        _ call: CAPPluginCall,
        _ completion: @escaping ([String: AWSDKMessageDraftProtocol]?) -> Void)
    {
        let messageDraftResponse: (AWSDKMessageDraftProtocol?, Error?) -> Void = { draftProtocol, error in
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion(nil)
                return
            }
            
            guard let draft = draftProtocol else { return }
            
            let response = ResponseHelper.getMessageDraftJSON(draft, draftType: draftType.rawValue)
            ResponseHelper.validateAndSend(response.json, to: call)
            completion(response.info)
        }
        
        switch draftType {
        case .forward:
            guard let message = message else { return }
            AWSDKMessageDraft.createForwardDraft(for: message, from: consumer, completion: messageDraftResponse)
        case .reply:
            guard let message = message as? AWSDKInboxMessageDetails else { return }
            AWSDKMessageDraft.createReply(forMessage: message, from: consumer, completion: messageDraftResponse)
        case .new:
            AWSDKMessageDraft.createMessageDraft(from: consumer, completion: messageDraftResponse)
        }
    }
    
    func uploadAttachment(
        for draft: AWSDKMessageDraftProtocol,
        _ data: Data,
        _ mimeType: String,
        _ fileName: String,
        _ call: CAPPluginCall,
        _ completion: @escaping () -> Void)
    {
        draft.addAttachmentData(data, withMimeType: mimeType, withFilename: fileName) { success, error in
            if let error = error {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion()
                return
            }
            if let draftAttachment = draft.draftAttachment {
                self.logService.log("##: Attachmnt: \(draftAttachment.name)")
                let response = ResponseHelper.getMessageAttachmentsJSON([draftAttachment])
                ResponseHelper.validateAndSend(response.json[0], to: call)
                completion()
            }
        }
    }
    
    func uploadImageAttachment(
        for draft: AWSDKMessageDraftProtocol,
        _ imageURL: URL,
        _ call: CAPPluginCall,
        _ completion: @escaping () -> Void)
    {
        draft.addAttachment(fromPath: imageURL.path) { success, error in
            if let error = error {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion()
                return
            }
            if let draftAttachment = draft.draftAttachment {
                self.logService.log("##: Attachmnt: \(draftAttachment.name)")
                let response = ResponseHelper.getMessageAttachmentsJSON([draftAttachment])
                ResponseHelper.validateAndSend(response.json[0], to: call)
                completion()
            }
        }
    }
    
    // MARK: - Private
    
    private func getMessageFetchOptions(from call: CAPPluginCall) -> AWSDKMessageFetchOptions? {
        let messageOptions = AWSDKMessageFetchOptions()
        
        if call.getInt(Constants.Call.startIndex) == nil,
           call.getInt(Constants.Call.maxResults) == nil,
           call.getString(Constants.Call.since) == nil
        {
            return nil
        }
        
        if let startIndex = call.getInt(Constants.Call.startIndex) {
            messageOptions.startIndex = NSNumber(integerLiteral: startIndex)
        }
        
        if let maxResults = call.getInt(Constants.Call.maxResults) {
            messageOptions.maxResults = NSNumber(integerLiteral: maxResults)
        }
        
        let since = call.getString(Constants.Call.since)
        messageOptions.earliest = DateUtil.utcDate(from: since, "yyyy-MM-dd'T'HH:mm:ss'Z'")
        
        return messageOptions
    }
}

