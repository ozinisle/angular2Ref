//
//  ConsumerService.swift
//  AmwellPlugin
//
//  Created by Miraj, Kusum on 3/12/21.
//

import Foundation
import Capacitor
import AWSDK

class ConsumerService {
    private static let PHARMACY_MISSING_ERROR_CODE = 404
    
    var logService: LogService
    
    init(logService: LogService) {
        self.logService = logService
    }
    
    func fetchDetails(for consumer: AWSDKConsumer, _ call: CAPPluginCall) {
        self.logService.log("##: FetchConsumer")
        ResponseHelper.sendResponse(to: call, ResponseHelper.getConsumerJSON(from: consumer))
    }
    
    func fetchDependents(
        for consumer: AWSDKConsumer,
        _ call: CAPPluginCall,
        _ completion: @escaping ([AWSDKConsumer]) -> Void)
    {
        self.logService.log("##: FetchConsumerDependents")
        consumer.fetchDependents { dependents, error in
            if let error = error {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion([])
                return
            }
            
            guard let dependents = dependents else { return }
            
            var dependentArray = [Dictionary<String, Any>]()
            for dependent in dependents {
                dependentArray.append(ResponseHelper.getConsumerJSON(from: dependent))
            }
            
            ResponseHelper.sendResponse(to: call, dependentArray)
            completion(dependents)
        }
    }
    
    func fetchDocuments(
        for consumer: AWSDKConsumer,
        _ call: CAPPluginCall,
        _ completion: @escaping ([String: AWSDKHealthDocument]) -> Void)
    {
        self.logService.log("##: FetchConsumerDocuments")
        consumer.fetchHealthDocuments { healthDocuments, error in
            guard error == nil
            else {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion([:])
                return
            }

            guard let healthDocuments = healthDocuments,
                  healthDocuments.count > 0
            else {
                ResponseHelper.sendResponse(to: call, [])
                completion([:])
                return
            }
            
            let documentJSON = ResponseHelper.getHealthDocumentJSON(healthDocuments)
            ResponseHelper.validateAndSend(documentJSON.json, to: call)
            completion(documentJSON.documentDict)
        }
    }
    
    func update(_ consumer: AWSDKConsumer, _ call: CAPPluginCall, _ completion: @escaping (AWSDKConsumer?) -> Void) {
        guard let reminderTextsEnabled = call.getBool(Constants.Call.isAppointmentReminderTextsEnabled) else {
            completion(nil)
            return
        }
        
        let updateForm = AWSDKConsumerUpdateForm()
        updateForm.appointmentReminderTextPreference = reminderTextsEnabled ? .PreferenceEnabled : .PreferenceDisabled
        consumer.updateDemographics(with: updateForm) { consumer, error in
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion(nil)
                return
            }
            
            completion(consumer)
        }
    }
    
    // MARK: - Visit Intake
    
    func fetchAllergies(
        for consumer: AWSDKConsumer,
        _ call: CAPPluginCall,
        _ completion: @escaping ([AWSDKAllergy]) -> Void)
    {
        self.logService.log("##: FetchConsumerAllergies")
        consumer.fetchAllergies { allergies, error in
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion([])
                return
            }
            
            guard let allergies = allergies else {
                completion([])
                return
            }
            ResponseHelper.validateAndSend(ResponseHelper.getAllergyJSON(allergies), to: call)
            completion(allergies)
        }
    }
    
    func fetchConditions(
        for consumer: AWSDKConsumer,
        _ call: CAPPluginCall,
        _ completion: @escaping ([AWSDKCondition]) -> Void)
    {
        self.logService.log("##: FetchConsumerConditions")
        consumer.fetchConditions { conditions, error in
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion([])
                return
            }
            
            guard let conditions = conditions else {
                completion([])
                return
            }
            ResponseHelper.validateAndSend(ResponseHelper.getConditionJSON(conditions), to: call)
            completion(conditions)
        }
    }
    
    func fetchVitals(
        for consumer: AWSDKConsumer,
        _ call: CAPPluginCall,
        _ completion: @escaping (AWSDKConsumerVitals?) -> Void)
    {
        self.logService.log("##: FetchConsumerVitals")
        consumer.getVitals(nil) { consumerVitals, error in
            guard let vitals = consumerVitals else {
                completion(nil)
                return
            }
            
            ResponseHelper.validateAndSend(ResponseHelper.getVitalsJSON(vitals), to: call)
            completion(vitals)
        }
    }
    
    func fetchMedications(
        for consumer: AWSDKConsumer,
        _ call: CAPPluginCall,
        _ completion: @escaping ([AWSDKMedication]) -> Void)
    {
        self.logService.log("##: FetchConsumerMedications")
        consumer.fetchMedications { medications, error in
            guard let medications = medications else {
                completion([])
                return
            }
            
            ResponseHelper.validateAndSend(ResponseHelper.getMedicationJSON(medications), to: call)
            completion(medications)
        }
    }
    
    func updateConsumerAllergies(
        for consumer: AWSDKConsumer,
        _ consumerAllergies: [AWSDKAllergy],
        _ call: CAPPluginCall,
        _ completion: @escaping ([AWSDKAllergy]) -> Void)
    {
        self.logService.log("##: UpdateConsumerAllergies")
        guard let allergies = call.getArray(Constants.Call.allergies, JSResultBody.self) else { return }
        
        // extract the allergies where isCurrent is true
        let newAllergies = allergies.filter { allergy -> Bool in
            if let isCurrent = allergy[Constants.Allergy.isCurrent] as? Bool,
               isCurrent {
                return true
            }
            
            return false
        }
        
        // validation: return if no updates were made
        if newAllergies.count == 0 {
            ResponseHelper.sendSuccessResponse(to: call)
            completion([])
            return
        }
        
        // get the AWSDKAllergy object
        let matchedAllergies = consumerAllergies.filter { allergy -> Bool in
            for newAllergy in newAllergies {
                if let name = newAllergy[Constants.Allergy.name] as? String,
                   name == allergy.displayName
                {
                    return true
                }
            }
            
            return false
        }
        
        // Update the isCurrent value to true
        let updatedAllergies = matchedAllergies.map { allergy -> AWSDKAllergy in
            allergy.isCurrent = true
            return allergy
        }
        
        consumer.updateAllergies(updatedAllergies, withCompletion: { success, error in
            ResponseHelper.handleResponse(
                for: call,
                success,
                error,
                alternateErrorMessage: "Consumer allergies were not updated"
            )
            
            if success {
                completion(updatedAllergies)
            } else {
                completion([])
            }
        })
    }
    
    func updateConditions(
        for consumer: AWSDKConsumer,
        _ consumerConditions: [AWSDKCondition],
        _ call: CAPPluginCall,
        _ completion: @escaping ([AWSDKCondition]) -> Void)
    {
        self.logService.log("##: UpdateConsumerConditions")
        guard let conditions = call.getArray(Constants.Call.conditions, JSResultBody.self) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Conditions missing")
            completion([])
            return
        }

        // extract the conditions where isCurrent is true
        let newConditions = conditions.filter { condition -> Bool in
            if let isCurrent = condition[Constants.Condition.isCurrent] as? Bool,
               isCurrent {
                return true
            }

            return false
        }

        // validation: return if no updates were made
        if newConditions.count == 0 {
            ResponseHelper.sendSuccessResponse(to: call)
            completion([])
        }

        // get the AWSDKCondition object
        let matchedConditions = consumerConditions.filter { condition -> Bool in
            for newCondition in newConditions {
                if let name = newCondition[Constants.Condition.name] as? String,
                   name == condition.displayName
                {
                    return true
                }
            }

            return false
        }

        // Update the isCurrent value to true
        let updatedConditions = matchedConditions.map { condition -> AWSDKCondition in
            condition.isCurrent = true
            return condition
        }

        consumer.update(updatedConditions, withCompletion: { success, error in
            ResponseHelper.handleResponse(
                for: call,
                success,
                error,
                alternateErrorMessage: "Consumer conditions were not updated"
            )
            
            if success {
                completion(updatedConditions)
            } else {
                completion([])
            }
        })
    }

    func updateMedications(
        for consumer: AWSDKConsumer,
        _ medications: [AWSDKMedication],
        _ call: CAPPluginCall,
        _ completion: @escaping ([AWSDKMedication]) -> Void)
    {
        self.logService.log("##: UpdateConsumerMedications")
        guard let newMedications = call.getArray(Constants.Call.medications, JSResultBody.self) else { return }

        let updatedMedications = medications.filter { medication -> Bool in
            for newMedication in newMedications {
                if let name = newMedication[Constants.Medication.name] as? String,
                   name == medication.displayName {
                    return true
                }
            }

            return false
        }

        consumer.update(updatedMedications, withCompletion: { success, error in
            ResponseHelper.handleResponse(for: call, success, error, alternateErrorMessage: "Medications were not updated")
            
            if success {
                completion(updatedMedications)
            } else {
                completion([])
            }
        })
    }

    func updateConsumerVitals(for consumer: AWSDKConsumer, _ call: CAPPluginCall, _ completion: @escaping () -> Void) {
        self.logService.log("##: UpdateConsumerVitals")
        guard let vitals = call.getObject(Constants.Call.vitals) else { return }
        self.logService.log("##: Vitals \(vitals)")

        let vitalsForm = AWSDKConsumerVitalsForm.init()
        
        vitalsForm.systolicBloodPressure = bloodPressure(
            from: vitals[Constants.Vitals.bloodPressureSystolic],
            unit: UnitPressure.inchesOfMercury
        )
        vitalsForm.diastolicBloodPressure = bloodPressure(
            from: vitals[Constants.Vitals.bloodPressureDiastolic],
            unit: UnitPressure.inchesOfMercury
        )
        vitalsForm.temperature = temperature(from: vitals[Constants.Vitals.temperature], unit: UnitTemperature.fahrenheit)
        vitalsForm.weightMajor = weight(from: vitals[Constants.Vitals.weightMajor], UnitMass.pounds)
        vitalsForm.weightMinor = weight(from: vitals[Constants.Vitals.weightMinor], UnitMass.ounces)
        vitalsForm.heightMajor = height(from: vitals[Constants.Vitals.heightMajor], unit: UnitLength.feet)
        vitalsForm.heightMinor = height(from: vitals[Constants.Vitals.heightMinor], unit: UnitLength.inches)

        var error: NSError?
        vitalsForm.isValid(&error)
        if error?.localizedDescription == nil {
            self.logService.log("##: Vitals Form is VALID")
            consumer.updateVitals(vitalsForm, with: nil) { success, error  in
                ResponseHelper.handleResponse(for: call, success, error, alternateErrorMessage: "Vitals were not updated")
                completion()
            }
        } else {
            self.logService.log("## VITALS ERROR: \(String(describing: error?.localizedDescription))")
            ResponseHelper.sendErrorResponse(to: call, error: error)
            completion()
        }
    }
    
    @objc func addDocument(
        for consumer: AWSDKConsumer?,
        _ data: Data,
        _ mimeType: String,
        _ fileName: String,
        _ call: CAPPluginCall?,
        _ completion: @escaping ([String: AWSDKHealthDocument]?) -> Void)
    {
        consumer?.addHealthDocument(data, withMimeType: mimeType as String, withFilename: fileName, completion: { document, error in
            guard let call = call else {
                completion(nil)
                return
            }
            
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion(nil)
            }
            
            if let document = document {
                let documentJson = ResponseHelper.getHealthDocumentJSON([document])
                ResponseHelper.sendResponse(to: call, documentJson.json)
                completion(documentJson.documentDict)
            } else {
                ResponseHelper.sendErrorResponse(to: call, with: "File not found.")
                completion(nil)
            }
        })
    }
    
    @objc func addImageDocument(
        for consumer: AWSDKConsumer?,
        _ imageURL: URL,
        _ call: CAPPluginCall,
        _ completion: @escaping ([String: AWSDKHealthDocument]?) -> Void)
    {
        consumer?.addHealthDocument(fromPath: imageURL.path, completion: { document, error in
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                return
            }
            
            if let document = document {
                let documentJson = ResponseHelper.getHealthDocumentJSON([document])
                
                ResponseHelper.sendResponse(to: call, documentJson.json)
                completion(documentJson.documentDict)
            } else {
                ResponseHelper.sendErrorResponse(to: call, with: "File not found.")
                completion(nil)
            }
        })
    }
    
    // MARK: Pharmacy
    
    @objc func fetchPharmacy(
        for consumer: AWSDKConsumer,
        _ call: CAPPluginCall,
        _ completion: @escaping ([String: AWSDKPharmacy]) -> Void)
    {
        self.logService.log("##: FetchConsumerPharmacy")
        consumer.fetchPreferredPharmacy { pharmacy, error in
            if let error = error as NSError? {
                if error.code == ConsumerService.PHARMACY_MISSING_ERROR_CODE {
                    ResponseHelper.sendNULLResponse(to: call)
                } else {
                    ResponseHelper.sendErrorResponse(to: call, error: error)
                }
                
                completion([:])
                return
            }
            
            guard let pharmacy = pharmacy else {
                ResponseHelper.sendErrorResponse(to: call, with: "Failed to fetch pharmacy")
                completion([:])
                return
            }
            
            let pharmaciesJSON = ResponseHelper.getPharmacyJSON([pharmacy])
            ResponseHelper.validateAndSend(pharmaciesJSON.json[0], to: call)
            completion(pharmaciesJSON.pharmacies)
        }
    }
    
    @objc func updatePharmacy(
        for consumer: AWSDKConsumer,
        pharmacies: [String: AWSDKPharmacy],
        _ call: CAPPluginCall,
        _ completion: @escaping (() -> Void))
    {
        self.logService.log("##: UpdateConsumerPharmacy")
        guard let pharmacyID = call.getString(Constants.Call.pharmacyID) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Invalid Pharmacy ID")
            completion()
            return
        }
        
        if let pharmacy = pharmacies[pharmacyID] {
            consumer.updatePreferredPharmacy(pharmacy) { success, error in
                ResponseHelper.handleResponse(
                    for: call,
                    success,
                    error,
                    alternateErrorMessage: "Updating pharmacy failed!"
                )
                completion()
            }
        }
    }
    
    // MARK: - Shipping Address
    
    @objc func fetchShippingAddress(
        for consumer: AWSDKConsumer,
        _ call: CAPPluginCall,
        _ completion: @escaping (() -> Void))
    {
        self.logService.log("##: fetchConsumerShippingAddress")
        consumer.getShippingAddress { shippingAddress, error in
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion()
                return
            }
            
            if let address = ResponseHelper.getAddressJSON(for: shippingAddress) {
                ResponseHelper.validateAndSend(address, to: call)
            } else {
                ResponseHelper.sendNULLResponse(to: call)
            }
            
            completion()
        }
    }
    
    @objc func updateShippingAddress(
        for consumer: AWSDKConsumer,
        _ states: [AWSDKState],
        _ countries: [AWSDKCountry],
        _ call: CAPPluginCall,
        _ completion: @escaping (() -> Void))
    {
        self.logService.log("##: UpdateConsumerShippingAddress")
        guard let address = call.getObject(Constants.Call.address) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Address not found!")
            completion()
            return
        }
        
        if let newAddress = Model.getShippingAddress(from: address, states, countries) {
            consumer.updateShippingAddress(newAddress) { success, error in
                ResponseHelper.handleResponse(for: call, success, error, alternateErrorMessage: "Address not updated")
                completion()
            }
        }
    }
    
    // MARK: - Payment
    
    @objc func fetchPaymentMethod(
        for consumer: AWSDKConsumer,
        _ call: CAPPluginCall,
        _ completion: @escaping (() -> Void))
    {
        self.logService.log("##: fetchConsumerPaymentMethod")
        consumer.fetchPaymentMethod { paymentMethod, error in
            
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion()
                return
            }
            
            guard let paymentMethod = paymentMethod else {
                ResponseHelper.sendNULLResponse(to: call)
                completion()
                return
            }
            
            ResponseHelper.validateAndSend(ResponseHelper.getPaymentMethodJSON(paymentMethod), to: call)
            completion()
        }
    }
    
    @objc func updatePaymentMethod(
        for consumer: AWSDKConsumer,
        _ states: [AWSDKState],
        _ countries: [AWSDKCountry],
        _ call: CAPPluginCall,
        _ completion: @escaping (() -> Void))
    {
        self.logService.log("##: updateConsumerPaymentMethod")
        guard let paymentRequest = call.getObject("paymentMethodRequest") else {
            ResponseHelper.sendErrorResponse(to: call, with: "Payment method is missing!")
            completion()
            return
        }
        
        guard let address = paymentRequest[Constants.PaymentRequest.billingAddress] as? [String: Any],
              let name = paymentRequest[Constants.PaymentRequest.billingName] as? String,
              let month = paymentRequest[Constants.PaymentRequest.expirationMonth] as? NSNumber,
              let year = paymentRequest[Constants.PaymentRequest.expirationYear] as? NSNumber,
              let digits = paymentRequest[Constants.PaymentRequest.digits] as? String,
              let securityCode = paymentRequest[Constants.PaymentRequest.securityCode] as? String
        else {
            ResponseHelper.sendErrorResponse(to: call, with: "Payment method information incomplete")
            completion()
            return
        }
        
        guard let billingAddress = Model.getShippingAddress(from: address, states, countries) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Payment method information incomplete")
            completion()
            return
        }
        
        let paymentForm = AWSDKPaymentMethodForm()
        paymentForm.billingAddress = billingAddress
        paymentForm.billingName = name
        paymentForm.expMonth = month.stringValue
        paymentForm.expYear = year.stringValue
        paymentForm.cvvCode = securityCode
        paymentForm.cardNumber = digits
        if let cardType = AWSDKCreditCardType(forNumber: digits) {
            paymentForm.cardType = cardType
        }
        
        consumer.updatePaymentMethod(paymentForm) { paymentMethod, error in
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
            } else if let _ = paymentMethod {
                ResponseHelper.sendSuccessResponse(to: call)
            }
            
            completion()
        }
    }
    
    // MARK: Private
    
    private func weight(from value: Any?, _ unit: UnitMass) -> Measurement<UnitMass>? {
        if let stringValue = value as? String,
           let newValue = Double(stringValue)
        {
            return Measurement.init(value: newValue, unit: unit)
        } else if let doubleValue = value as? Double {
            return Measurement.init(value: doubleValue, unit: unit)
        }
        
        return nil
    }
    
    private func bloodPressure(from value: Any?, unit: UnitPressure) -> Measurement<UnitPressure>? {
        if let stringValue = value as? String,
           let newValue = Double(stringValue)
        {
            return Measurement.init(value: newValue, unit: unit)
        } else if let doubleValue = value as? Double {
            return Measurement.init(value: doubleValue, unit: unit)
        }
        
        return nil
    }
    
    private func height(from value: Any?, unit: UnitLength) -> Measurement<UnitLength>? {
        if let stringValue = value as? String,
           let newValue = Double(stringValue)
        {
            return Measurement.init(value: newValue, unit: unit)
        } else if let doubleValue = value as? Double {
            return Measurement.init(value: doubleValue, unit: unit)
        }
        
        return nil
    }
    
    private func temperature(from value: Any?, unit: UnitTemperature) -> Measurement<UnitTemperature>? {
        if let stringValue = value as? String,
           let newValue = Double(stringValue)
        {
            return Measurement.init(value: newValue, unit: unit)
        } else if let doubleValue = value as? Double {
            return Measurement.init(value: doubleValue, unit: unit)
        }
        
        return nil
    }
}
