//
//  AmwellService.swift
//  AmwellPlugin
//
//  Created by Miraj, Kusum on 3/15/21.
//

import Foundation
import Capacitor
import AWSDK

class AmwellService {
    static let defaultCountry = "US"
    static let AmwellSDKVersion = 6.8
    static let radiusMultiplier = 1609.344
    
    var logService: LogService
    
    init(logService: LogService) {
        self.logService = logService
    }
    
    //  MARK: - SDK Initiialize
    
    func initialize(_ call: CAPPluginCall, completion: @escaping () -> Void) {
        self.logService.log("##: Initialize")
        let url = call.getString(Constants.Initialize.baseServiceURL) ?? ""
        let apiKey = call.getString(Constants.Initialize.apiKey) ?? ""
        let bundleId = call.getString(Constants.Initialize.bundleID) ?? ""
        var params = [
            kAWSDKUrl: url,
            kAWSDKKey: apiKey,
            kAWSDKBundleID: bundleId
        ]

        if let launchUrl = call.getString(Constants.Initialize.launchURL) {
            params[kAWSDKLaunchURL] = launchUrl
        }
        
        AWSDKService.initialize(withLaunchParams: params) { success, error in
            ResponseHelper.handleResponse(for: call, success, error, alternateErrorMessage: "Initialization failed")
            completion()
        }
    }
    
    //  MARK: - Authentication
    
    func authenticate(_ call: CAPPluginCall, _ completion: @escaping (AWSDKConsumer?) -> Void) {
        self.logService.log("##: Authenticate")
        guard AWSDKService.isInitialized() else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.sdkNotInitialized)
            completion(nil)
            return
        }
        
        let consumerAuthKey = call.getString(Constants.Call.consumerAuthKey) ?? ""
        
        // TODO: Wrap this to catch runtime exceptions
        AWSDKAuthenticationService.authenticateMutualAuth(withToken: consumerAuthKey) { consumer, error in
            guard error == nil
            else {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion(nil)
                return
            }
            
            if let consumer = consumer as? AWSDKConsumer {
                ResponseHelper.sendSuccessResponse(to: call)
                completion(consumer)
            } else {
                ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotRegistered)
                completion(nil)
            }
        }
    }
    
    //  MARK: - Practice
    
    @objc func fetchPractices(for consumer: AWSDKConsumer, _ call: CAPPluginCall, completion: @escaping ([AWSDKPractice]) -> Void) {
        self.logService.log("##: fetchPractices")
        AWSDKPracticeService.fetchPractices(for: consumer) { practices, error in
            guard let practices = practices
            else {
                completion([])
                return
            }
            
            if let error = error {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion([])
                return
            }
            
            ResponseHelper.validateAndSend(ResponseHelper.getPracticeJSON(from: practices), to:call)
            completion(practices)
        }
    }
    
    //  MARK: - Provider
    
    func getProviderTypes(_ call: CAPPluginCall, _ completion: @escaping () -> Void) {
        self.logService.log("##: getProviderTypes")
        AWSDKProviderService.getProviderTypes(completion: { rawProviderTypes, error in
            if let error = error {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion()
                return
            }

            guard let unwrappedRawProviderTypes = rawProviderTypes else {
                completion()
                return
            }
            
            var serializedProviderTypes = [Any]()
            for rawProviderType in unwrappedRawProviderTypes {
                serializedProviderTypes.append([
                    Constants.Provider.name: rawProviderType.name
                ])
            }
            
            ResponseHelper.sendResponse(to: call, serializedProviderTypes)
            completion()
        })
    }
    
    func findProviders(
        _ call: CAPPluginCall,
        _ consumer: AWSDKConsumer,
        _ practices: [AWSDKPractice],
        _ completion: @escaping ([AWSDKProvider]) -> Void)
    {
        self.logService.log("##: FindProvider")
        let practiceSourceID = call.getString(Constants.Call.practiceSourceID)
        guard let stateCode = call.getString(Constants.Call.stateCode) else {
            ResponseHelper.sendErrorResponse(to: call, with: "State Code Missing")
            completion([])
            return
        }
        
        let countryCode = call.getString(Constants.Call.countryCode) ?? AmwellService.defaultCountry
        
        guard let countries = AWSDKEnrollmentService.countries,
            let country = countries.first(where: { $0.code == countryCode })
        else {
            ResponseHelper.sendErrorResponse(to: call, with: "Invalid Country Code")
            completion([])
            return
        }
        
        guard let enrollmentStates = country.enrollmentStates,
              let state = enrollmentStates.first(where: { $0.code == stateCode }) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Invalid State Code")
            completion([])
            return
        }
        
        // set the providerSearchOptions
        let providerSearchOptions = AWSDKProviderSearchOptions()
        providerSearchOptions.consumer = consumer
        providerSearchOptions.state = state
        providerSearchOptions.practice = practices.first(where: { practice in
            practice.sourceId == practiceSourceID
        })
        
        let group = DispatchGroup()
        var providerJSON = [Any]()
        
        let fetchProviders: ([AWSDKProviderSearchResult]) -> Void = { providerSearchResults in
            // validation
            guard providerSearchResults.count >= 1 else {
                ResponseHelper.sendErrorResponse(
                    to: call,
                    error: ResponseHelper.getError(for: AWSDKErrorCode.errorCodeProviderNotFound)
                )
                completion([])
                return
            }
            
            var providers = [AWSDKProvider]()
            // fetch provider details
            for searchResult in providerSearchResults {
                group.enter()
                searchResult.fetchDetails { provider, error in
                    if let error = error {
                        ResponseHelper.sendErrorResponse(to: call, error: error)
                        return
                    }
                    
                    guard let provider = provider else { return }
                    
                    providers.append(provider)
                    providerJSON.append(ResponseHelper.getProviderJSON(from: provider, isDetail: false))
                    group.leave()
                }
                
                // send the response with all provider's details
                group.notify(queue: .main) {
                    ResponseHelper.sendResponse(to: call, providerJSON)
                    completion(providers)
                }
            }
        }
        
        // Fetch the provider search results
        AWSDKProviderService.performProviderSearch(with: providerSearchOptions) { providerSearchResults, error in
            guard let providerSearchResults = providerSearchResults else {
                ResponseHelper.sendErrorResponse(to: call, with: "No Providers Found")
                completion([])
                return
            }
            
            fetchProviders(providerSearchResults)
        }
    }
    
    func getProviderDetails(_ provider: AWSDKProvider, _ call: CAPPluginCall) {
        ResponseHelper.validateAndSend(ResponseHelper.getProviderJSON(from: provider, isDetail: true), to: call)
    }
    
    func fetchProvider(with sourceID: String, _ completion: @escaping (AWSDKProvider?, Error?) -> Void) {
        AWSDKProviderService.fetchProviders(withSourceIds: [sourceID]) { providerSearchResults, error in
            if error != nil {
                completion(nil, error)
            }
            
            guard let providerSearchResults = providerSearchResults else {
                completion(nil, nil)
                return
            }
            
            providerSearchResults[0].fetchDetails { provider, error in
                if error != nil {
                    completion(nil, error)
                }
                
                completion(provider, nil)
            }
        }
    }
    
    // MARK: - Medication
    
    func findMedications(_ call: CAPPluginCall, _ completion: @escaping ([AWSDKMedication]) -> Void) {
        self.logService.log("##: findMedications")
        
        guard let searchString = call.getString(Constants.Call.searchMedication) else { return }
        AWSDKMedicationService.searchMedications(with: searchString) { medications, error in
            guard let medications = medications else {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                return
            }
            
            ResponseHelper.validateAndSend(ResponseHelper.getMedicationJSON(medications), to: call)
            completion(medications)
        }
    }
    
    func findPharmaciesWithZipCode(_ call: CAPPluginCall, _ completion: @escaping (Dictionary<String, AWSDKPharmacy>) -> Void) {
        self.logService.log("##: FindPharmaciesWithZipCode")
        guard let zipCode = call.getString(Constants.Call.zipCode) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Invalid/Missing Zipcode")
            completion([:])
            return
        }
        
        AWSDKPharmacyService.fetchPharmacies(withZipCode: zipCode) { pharmacies, error in
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion([:])
                return
            }
            
            guard let pharmaciesFound = pharmacies else {
                ResponseHelper.sendErrorResponse(to: call, with: "No pharmacies found under zipcode \(zipCode)")
                completion([:])
                return
            }
            
            let pharmaciesResponse = ResponseHelper.getPharmacyJSON(pharmaciesFound)
            
            ResponseHelper.validateAndSend(pharmaciesResponse.json, to: call)
            completion(pharmaciesResponse.pharmacies)
        }
    }
    
    func findPharmaciesInRegion(_ call: CAPPluginCall, _ completion: @escaping (Dictionary<String, AWSDKPharmacy>) -> Void) {
        self.logService.log("##: findPharmaciesInRegion")
        guard let latitude = call.getDouble(Constants.Call.latitude),
              let longitude = call.getDouble(Constants.Call.longitude),
              let radius = call.getDouble(Constants.Call.radius)
        else {
            ResponseHelper.sendErrorResponse(to: call, with: "Invalid/Missing coordinates")
            completion([:])
            return
        }
        
        let center = CLLocationCoordinate2DMake(CLLocationDegrees(latitude), CLLocationDegrees(longitude))
        let region = CLCircularRegion(center: center, radius: radius * AmwellService.radiusMultiplier, identifier: "")
        AWSDKPharmacyService.fetchPharmacies(with: region) { pharmacies, error in
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion([:])
                return
            }
            
            guard let pharmaciesFound = pharmacies else {
                ResponseHelper.sendErrorResponse(to: call, with: "No pharmacies found near coordinates")
                completion([:])
                return
            }
            
            let pharmaciesResponse = ResponseHelper.getPharmacyJSON(pharmaciesFound)
            
            ResponseHelper.validateAndSend(pharmaciesResponse.json, to: call)
            completion(pharmaciesResponse.pharmacies)
        }
    }
    
    //  MARK: - Miscellaneous
    
    func echo(_ call: CAPPluginCall) {
        let value = call.getString(Constants.Response.value) ?? ""
        ResponseHelper.sendResponse(to: call, value)
    }
    
    func fetchCreditCardTypes(_ call: CAPPluginCall) {
        self.logService.log("##: fetchCreditCardTypes")
        let ccTypes: [AWSDKCreditCardTypeProtocol] = AWSDKPaymentMethodForm.creditCardTypes
        let serializedTypes = ccTypes.compactMap { creditCard -> [String: Any]? in
            guard let type = CreditCardTypesNames.init(rawValue: creditCard.displayName) else {
                return nil
            }
            
            return [
                Constants.CreditCardTypes.type: creditCard.displayName,
                Constants.CreditCardTypes.cvvLength: creditCard.cvvLength,
                Constants.CreditCardTypes.regex: type.regex()
            ]
        }
        
        ResponseHelper.sendResponse(to: call, serializedTypes)
    }
    
    func fetchSupportedCountries(_ call: CAPPluginCall) {
        
    }
    
    func fetchCountries(_ call: CAPPluginCall) -> [AWSDKCountry] {
        self.logService.log("##: fetchCountries")
        guard let countries = AWSDKEnrollmentService.countries else {
            ResponseHelper.sendNULLResponse(to: call)
            return []
        }
        
        ResponseHelper.validateAndSend(ResponseHelper.getCountryJSON(countries), to: call)
        return countries
    }
    
    func fetchStatesForCountry(_ call: CAPPluginCall) -> (countries: [AWSDKCountry], states: [AWSDKState]) {
        self.logService.log("##: fetchStatesForCountry")
        return fetchStates(for: call)
    }
    
    func getSdkVersion(_ call: CAPPluginCall) {
        ResponseHelper.sendResponse(to: call, AmwellService.AmwellSDKVersion)
    }
    
    // MARK: - Private
    
    private func fetchStates(for call: CAPPluginCall) -> (countries: [AWSDKCountry], states: [AWSDKState]) {
        guard let countryCode = call.getString(Constants.Call.countryCode) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Country Code missing")
            return (countries: [], states: [])
        }
        
        guard let countries = AWSDKEnrollmentService.countries,
              let country = countries.first(where: { $0.code == countryCode }),
              let enrollmentStates = country.enrollmentStates
        else {
            ResponseHelper.sendErrorResponse(to: call, with: "No states found for the country code \(countryCode)")
            return (countries: [], states: [])
        }
        
        ResponseHelper.validateAndSend(ResponseHelper.getStatesJSON(enrollmentStates, for: country), to: call)
        return (countries: countries, states: enrollmentStates)
    }
}
