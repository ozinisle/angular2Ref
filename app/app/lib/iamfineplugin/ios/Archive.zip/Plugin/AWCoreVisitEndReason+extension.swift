//
//  AWCoreVisitEndReason+extension.swift
//  AmwellPlugin
//
//  Created by Miraj, Kusum on 3/25/21.
//

import Foundation
import AWSDK

extension AWCoreVisitEndReason {
    func title() -> String {
        switch self {
        case .assistantDecline:
            return Constants.VisitEndReason.assistantDecline
        case .assistantDeclineAndTransfer:
            return Constants.VisitEndReason.assistantDeclineAndTransfer
        case .backgroundTimeLimitExceeded:
            return Constants.VisitEndReason.backgroundTimeLimitExceeded
        case .consumerCancel:
            return Constants.VisitEndReason.memberCancel
        case .consumerDisconnectPostThreshold:
            return Constants.VisitEndReason.memberDisconnectPostThreshold
        case .consumerDisconnectPreThreshold:
            return Constants.VisitEndReason.memberDisconnectPreThreshold
        case .consumerEnd:
            return Constants.VisitEndReason.memberEnd
        case .consumerForcedDisconnect:
            return Constants.VisitEndReason.memberForcedDisconnect
        case .consumerIVRAuthFailed:
            return Constants.VisitEndReason.memberIVRAuthFailed
        case .consumerOutdialFailed:
            return Constants.VisitEndReason.consumerOutdialFailed
        case .consumerTransfer:
            return Constants.VisitEndReason.memberTransfer
        case .costCalculationFailed:
            return Constants.VisitEndReason.asyncCostCalculationException
        case .initiatorLogoutAfterStart:
            return Constants.VisitEndReason.initiatorStartAfterLogout
        case .initiatorLogoutPreVisit:
            return Constants.VisitEndReason.initiatorLogoutPreVisit
        case .permissionsError:
            return Constants.VisitEndReason.permissionsError
        case .postVisitTransfer:
            return Constants.VisitEndReason.postVisitTransfer
        case .providerBail:
            return Constants.VisitEndReason.providerBail
        case .providerDeclineAndTransfer:
            return Constants.VisitEndReason.providerDeclineAndTransfer
        case .providerEnd:
            return Constants.VisitEndReason.providerEnd
        case .providerLogout:
            return Constants.VisitEndReason.providerLogout
        case .providerDeclined:
            return Constants.VisitEndReason.providerDecline
        case .providerDisconnect:
            return Constants.VisitEndReason.providerDisconnect
        case .providerResponseTimeout:
            return Constants.VisitEndReason.providerResponseTimeout
        case .providerIVRAuthFailed:
            return Constants.VisitEndReason.providerIVRAuthFailed
        case .videoHostFailed:
            return Constants.VisitEndReason.videoHostFailed
        case .visitEnded:
            return Constants.VisitEndReason.visitEnded
        case .visitExpired:
            return Constants.VisitEndReason.visitExpired
        case .waitingRoomExpired:
            return Constants.VisitEndReason.waitingRoomExpired
        case .unknown:
            return Constants.VisitEndReason.unknown
        
            
        @unknown default:
            return Constants.VisitEndReason.unknown
        }
    }
}

