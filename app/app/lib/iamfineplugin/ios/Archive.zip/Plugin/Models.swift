//
//  Models.swift
//  AmwellPlugin
//
//  Created by Miraj, Kusum on 2/23/21.
//

import Foundation
import AWSDK

struct Model {
    static func getShippingAddress(from address: [String: Any], _ states: [AWSDKState], _ countries: [AWSDKCountry]) ->
        AWSDKAddressProtocol?
    {
        let addressObject = AWSDKAddress()
        guard let addressOne = address[Constants.Address.address1] as? String,
              let city = address[Constants.Address.city] as? String,
              let stateCode = address[Constants.Address.stateCode] as? String,
              let countryCode = address[Constants.Address.countryCode] as? String,
              let zipCode = address[Constants.Address.zipCode] as? String,
              let state = states.first(where: { $0.code == stateCode } ),
              let country = countries.first(where: { $0.code == countryCode })
        else {
            return nil
        }
        
        var addressTwo: String
        if let addr = address[Constants.Address.address2] as? String {
            addressTwo = addr
        } else {
            addressTwo = ""
        }
        
        addressObject.addressOne = addressOne
        addressObject.addressTwo = addressTwo
        addressObject.city = city
        addressObject.state = state
        addressObject.country = country
        addressObject.zip = zipCode
        return addressObject
    }
}


