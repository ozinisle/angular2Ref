//
//  DateUtil.swift
//  AmwellPlugin
//
//  Created by Miraj, Kusum on 4/20/21.
//

import Foundation

struct DateUtil {
    static func utcDateString(from date: Date) -> String? {
        let formatter = DateFormatter()
        formatter.timeZone = TimeZone(abbreviation: "UTC")
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss'Z'"
        return formatter.string(from: date)
    }
    
    static func ISODate(from stringDate: String) -> Date? {
        let dateFormatter = ISO8601DateFormatter()
        dateFormatter.formatOptions = .withFullDate
        return dateFormatter.date(from: stringDate)
    }
    
    static func ISODate(from date: Date) -> Date? {
        let dateFormatter = ISO8601DateFormatter()
        let stringValue = dateFormatter.string(from: date)
        return dateFormatter.date(from: stringValue)
    }
    
    static func ISODateString(from date: Date) -> String {
        let dateFormatter = ISO8601DateFormatter()
        return dateFormatter.string(from: date)
    }
    
    static func utcDate(from date: String?, _ dateFormat: String) -> Date? {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(abbreviation: "UTC")
        formatter.dateFormat = dateFormat
        
        guard let date = date,
            let utcDate = formatter.date(from: date) else { return nil }
        
        return utcDate
    }
}
