import Foundation
import Capacitor
import AWSDK
import os.log
import MobileCoreServices

/*
 * Index:
 * - Public API
 *   - Initialization
 *   - Authentication
 *   - Consumer
 *   - Legal documents
 *   - Practice
 *   - Provider
 *   - Miscellaneous
 * - Internal methods
 */
@objc(AmwellPlugin)
public class AmwellPlugin: CAPPlugin {
    typealias JSObject = [String:Any]
    
    // main account holder
    private var consumer: AWSDKConsumer?
    // currentConsumer can be member or a dependent
    private var currentConsumer: AWSDKConsumer?
    private var dependents: [AWSDKConsumer]?
    private var practices = [AWSDKPractice]()
    private var providers = [AWSDKProvider]()
    private var visitContext: AWSDKVisitContext?
    private var consumerAllergies = [AWSDKAllergy]()
    private var consumerConditions = [AWSDKCondition]()
    private var medications = [AWSDKMedication]()
    private var consumerVitals: AWSDKConsumerVitals?
    private var visitLegalTexts = [String: AWSDKLegalText]()
    private var documents = Dictionary<String, AWSDKHealthDocument>()
    private var pharmacies = Dictionary<String, AWSDKPharmacy>()
    private var call: CAPPluginCall?
    private var states: [AWSDKState]?
    private var countries: [AWSDKCountry]?
    private var visit: AWSDKVisit?
    private var console: AWCoreVisitConsoleController?
    private var suggestedTransfer: AWSDKVisitTransfer?
    private var forcedTransfer: AWSDKVisitTransfer?
    private var visitSummary: AWSDKVisitSummary?
    private var appointmentProviders: [AWSDKProvider]?
    private var messages = Dictionary<String, AWSDKMessage>()
    private var messageContacts = Dictionary<String, AWSDKContact>()
    private var messageDraft: [String: AWSDKMessageDraftProtocol]?
    private var messageTopics: [AWSDKMessageTopicProtocol]?
    private var attachmentInfo: [String: AWSDKAttachment]?
    private var messageDetail = [String: AWSDKMessage]()
    private var isConsumerAuthenticated: Bool {
        consumer?.consumerAuthKey != nil
    }
    private var uploadReason = DocumentUploadReason.unknown
    
    private var logService = LogService(isEnabled: false);
    private lazy var amwellService = AmwellService(logService: self.logService)
    private lazy var appointmentService = AppointmentService(logService: self.logService)
    private lazy var consumerService = ConsumerService(logService: self.logService)
    private lazy var legalDocumentService = LegalDocumentService(logService: self.logService)
    private lazy var messageService = TelehealthMessageService(logService: self.logService)
    private lazy var visitService = VisitService(logService: self.logService)
    
    
    // Called when the plugin is first constructed in the bridge
    @objc public override func load() {
        self.logService.log("##: Load called");
        
        ResponseHelper.logService = self.logService;
    }
    
    //  MARK: - Initialization
    
    /// Required call to initialize the telehealth provider's SDK.
    @objc func initialize(_ call: CAPPluginCall) {
        let enableLogging = call.getBool("enableLogging", false)
        if (enableLogging == true) {
            self.logService.enable();
            AWSDKLogService.enableNetworkLogs()
            AWSDKLogService.setConsoleLogLevel(.verbose)
            AWSDKService.enableDebugMode()
            AWSDKLogService.logDelegate = self
        }
        amwellService.initialize(call, completion: {})
    }
    
    //  MARK: - Authentication
    
    /// Signs in a user with the telehealth provider.
    @objc func authenticate(_ call: CAPPluginCall) {
        amwellService.authenticate(call) { [weak self] consumer in
            guard let strongSelf = self else { return }
            
            strongSelf.consumer = consumer
            strongSelf.currentConsumer = consumer
        }
    }
    
    //  MARK: - Consumer
    
    /// Retrieves the currently-authenticated consumer, or one of their dependents.
    @objc func fetchConsumer(_ call: CAPPluginCall) {
        guard let consumer = consumer, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        if let currentConsumer = getConsumer(with: call, consumer) {
            consumerService.fetchDetails(for: currentConsumer, call)
        }
    }
    
    /// Retrieves a collection of dependents of the currently-authenticated consumer.
    @objc func fetchConsumerDependents(_ call: CAPPluginCall) {
        guard let consumer = consumer, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        consumerService.fetchDependents(for: consumer, call) { [weak self] dependents in
            guard dependents.count > 0,
                  let strongself = self
            else { return }
            
            strongself.logService.log("##: Dependents found - \(dependents.count)")
            strongself.dependents = dependents
        }
    }
    
    /// Retrieves a collection of documents of a specified consumer.
    @objc func fetchConsumerDocuments(_ call: CAPPluginCall) {
        guard let consumer = consumer, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let currentConsumer = getConsumer(with: call, consumer) else { return }
        
        consumerService.fetchDocuments(for: currentConsumer, call) { [weak self] documents in
            guard let strongself = self else { return }
            
            strongself.documents = documents
        }
    }
    
    /// Retrieves a collection of allergies that might be current for a specified consumer.
    @objc func fetchConsumerAllergies(_ call: CAPPluginCall) {
        guard let consumer = consumer, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let currentConsumer = getConsumer(with: call, consumer) else { return }
        
        consumerService.fetchAllergies(for: currentConsumer, call) { [weak self] allergies in
            guard let strongSelf = self else { return }
            
            strongSelf.consumerAllergies = allergies
        }
    }
    
    /// Retrieves a collection of medical conditions that might be current for a specified consumer.
    @objc func fetchConsumerConditions(_ call: CAPPluginCall) {
        guard let consumer = consumer, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let currentConsumer = getConsumer(with: call, consumer) else { return }
        
        consumerService.fetchConditions(for: currentConsumer, call) {  [weak self] conditions in
            guard let strongSelf = self else { return }
            
            strongSelf.consumerConditions = conditions
        }
    }
    
    /// Retrieves the most recent vitals for a specified consumer.
    @objc func fetchConsumerVitals(_ call: CAPPluginCall) {
        guard let consumer = consumer, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let currentConsumer = getConsumer(with: call, consumer) else { return }
        
        consumerService.fetchVitals(for: currentConsumer, call) { [weak self] vitals in
            guard let strongSelf = self else { return }
            
            strongSelf.consumerVitals = vitals
        }
    }
    
    /// Retrieves a collection of medications of a specified consumer.
    @objc func fetchConsumerMedications(_ call: CAPPluginCall) {
        guard let consumer = consumer, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        medications.removeAll()
        guard let currentConsumer = getConsumer(with: call, consumer) else { return }
        
        consumerService.fetchMedications(for: currentConsumer, call) { [weak self] medications in
            guard let strongSelf = self else { return }
            
            strongSelf.medications.append(contentsOf: medications)
        }
    }
    
    @objc func updateConsumer(_ call: CAPPluginCall) {
        self.logService.log("##: updateConsumer")
        guard isConsumerAuthenticated,
            let consumer = consumer
        else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let sdkConsumer = getConsumer(with: call, consumer) else { return }
        consumerService.update(sdkConsumer, call) { [weak self] consumer in
            guard let strongSelf  = self,
                let consumer = consumer else { return }
            
            strongSelf.currentConsumer = consumer
            
            ResponseHelper.sendResponse(to: call, ResponseHelper.getConsumerJSON(from: consumer))
        }
    }
    
    /// Updates the allergies of a specified consumer.
    @objc func updateConsumerAllergies(_ call: CAPPluginCall) {
        guard let consumer = consumer, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let currentConsumer = getConsumer(with: call, consumer) else { return }
        
        consumerService.updateConsumerAllergies(for: currentConsumer, consumerAllergies, call) { [weak self] allergies in
            guard let strongSelf = self else { return }
            
            allergies.forEach { allergy in
                strongSelf.consumerAllergies.forEach { oldAllergy in
                    if oldAllergy.displayName == allergy.displayName {
                        oldAllergy.isCurrent = allergy.isCurrent
                    }
                }
            }
        }
    }
    
    /// Updates the medical conditions of a specified consumer.
    @objc func updateConsumerConditions(_ call: CAPPluginCall) {
        guard let consumer = consumer, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let currentConsumer = getConsumer(with: call, consumer) else { return }
        
        consumerService.updateConditions(for: currentConsumer, consumerConditions, call) { [weak self] conditions in
            guard let consumerConditions = self?.consumerConditions
            else { return }
            
            conditions.forEach { condition in
                consumerConditions.forEach { oldCondition in
                    if oldCondition.displayName == condition.displayName {
                        oldCondition.isCurrent = condition.isCurrent
                    }
                }
            }
        }
    }
    
    /// Updates the medications of a specified consumer.
    @objc func updateConsumerMedications(_ call: CAPPluginCall) {
        guard let consumer = consumer, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let currentConsumer = getConsumer(with: call, consumer) else { return }
        
        consumerService.updateMedications(for: currentConsumer, medications, call) { [weak self] _ in
            guard let strongSelf = self else { return }
            
            // clear the medications cache after updating
            strongSelf.medications.removeAll()
        }
    }
    
    /// Updates the vitals of the currently-authenticated consumer.
    @objc func updateConsumerVitals(_ call: CAPPluginCall) {
        guard let consumer = consumer, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let currentConsumer = getConsumer(with: call, consumer) else { return }
        
        consumerService.updateConsumerVitals(for: currentConsumer, call, {})
    }
    
    // MARK: - Files
    
    /// Attempts to upload a file to the telehealth provider and associate it with a specified consumer.
    @objc func addConsumerDocument(_ call: CAPPluginCall) {
        self.logService.log("##: AddConsumerDocument")
        guard let consumer = consumer, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        self.call = call
        currentConsumer = getConsumer(with: call, consumer)
        uploadReason = .visit
        showDocumentPickerActionSheet()
    }
    
    /// Attempts to remove a file from the telehealth provider that is associated with a specified consumer.
    @objc func removeConsumerDocument(_ call: CAPPluginCall) {
        self.logService.log("##: RemoveConsumerDocument")
        guard let sourceID = call.getString(Constants.Call.sourceID) else { return }
        
        if let document = documents[sourceID] {
            document.remove { [weak self] success, error in
                guard let strongSelf = self else { return }
                
                if error == nil,
                   success
                {
                    strongSelf.documents.removeValue(forKey: sourceID)
                }
                
                ResponseHelper.handleResponse(for: call, success, error, alternateErrorMessage: "Document removal failed!")
            }
        }
    }
    
    // MARK: - Pharmacy
    
    /// Retrieves the preferred pharmacy of the currently-authenticated consumer.
    @objc func fetchConsumerPharmacy(_ call: CAPPluginCall) {
        guard let consumer = consumer, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        consumerService.fetchPharmacy(for: consumer, call) { [weak self] pharmacies in
            guard let strongSelf = self else { return }
            
            pharmacies.forEach { (id, pharmacy) in
                strongSelf.pharmacies[id] = pharmacy
            }
        }
    }
    
    /// Updates the preferred pharmacy of the currently-authenticated consumer.
    @objc func updateConsumerPharmacy(_ call: CAPPluginCall) {
        guard let consumer = consumer, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        consumerService.updatePharmacy(for: consumer, pharmacies: pharmacies, call, {})
    }
    
    /// Finds pharmacies within a given postal code.
    @objc func findPharmaciesWithZipCode(_ call: CAPPluginCall) {
        guard isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        amwellService.findPharmaciesWithZipCode(call) { [weak self] pharmacies in
            guard let strongSelf = self else { return }
            
            strongSelf.pharmacies = pharmacies
        }
    }
    
    /// Finds pharmacies within a given coordinate-based region.
    @objc func findPharmaciesInRegion(_ call: CAPPluginCall) {
        guard isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        amwellService.findPharmaciesInRegion(call) { [weak self] pharmacies in
            guard let strongSelf = self else { return }
            
            strongSelf.pharmacies = pharmacies
        }
    }
    
    /// Retrieves the shipping address of the currently-authenticated consumer.
    @objc func fetchConsumerShippingAddress(_ call: CAPPluginCall) {
        guard let consumer = consumer, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        consumerService.fetchShippingAddress(for: consumer, call) {}
    }
    
    /// Updates the shipping address of the currently-authenticated consumer.
    @objc func updateConsumerShippingAddress(_ call: CAPPluginCall) {
        guard let consumer = consumer, isConsumerAuthenticated
        else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let states = states,
              let countries = countries
        else {
            return
        }
        
        consumerService.updateShippingAddress(for: consumer, states, countries, call) {}
    }
    
    /// Finds states that are valid for shipping addresses within a given country.
    @objc func findShippingStatesForCountry(_ call: CAPPluginCall) {
        guard isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        fetchStates(for: call)
    }
    
    //  MARK: - Legal Documents
    
    /// Fetches the new or updated telehealth provider Terms of Use for the currently-authenticated consumer.
    @objc func fetchOutstandingDisclaimer(_ call: CAPPluginCall) {
        guard let consumer = consumer else { return }
        
        legalDocumentService.fetchOutstandingDisclaimer(for: consumer, call, {})
    }
    
    /// Record the authenticated consumer's accpetance of any new or updated Terms of Use for the telehealth provider.
    @objc func acceptOutstandingDisclaimer(_ call: CAPPluginCall) {
        guard let consumer = consumer else { return }
        
        legalDocumentService.acceptOutstandingDisclaimer(for: consumer, call, {})
    }
    
    /// Fetches the HTML content of a legal document.
    @objc func fetchLegalTextBody(_ call: CAPPluginCall) {
        guard isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        legalDocumentService.fetchTextBody(for: visitLegalTexts, call, {})
    }
    
    /// Fetches the privacy policy for the telehealth platform. The consumer must accept this policy before enrolling.
    @objc func fetchEnrollmentDisclaimer(_ call: CAPPluginCall) {
        legalDocumentService.fetchEnrollmentDisclaimer(call, {})
    }
    
    //  MARK: - Practice
    
    /// Retrieves all practices available to the currently-authenticated consumer.
    @objc func fetchPractices(_ call: CAPPluginCall) {
        guard let consumer = consumer, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        amwellService.fetchPractices(for: consumer, call) { [weak self] practices in
            guard let strongSelf = self else { return }
            
            strongSelf.practices = practices
        }
    }
    
    //  MARK: - Provider
    
    /// Finds providers matching the provided search options.
    @objc func findProviders(_ call: CAPPluginCall) {
        self.logService.log("##: FindProvider")
        guard let consumer = consumer, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        amwellService.findProviders(call, consumer, practices) { [weak self] providers in
            guard let strongSelf = self else { return }
            
            strongSelf.providers = providers
        }
    }
    
    /// Attempts to retrieve extended details about a provider.
    @objc func fetchProviderDetails(_ call: CAPPluginCall) {
        self.logService.log("##: fetchProviderDetails")
        guard isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        let providerSourceID = call.getString(Constants.Call.providerSourceID)
        if let provider = providers.first(where: { $0.sourceID == providerSourceID }) {
            amwellService.getProviderDetails(provider, call)
        } else if let appointmentProviders = appointmentProviders,
            let provider = appointmentProviders.first(where: { $0.sourceID == providerSourceID })
        {
            amwellService.getProviderDetails(provider, call)
        }
    }
    
    /// Initiates a "Find First Available" (FFA) provider search.
    @objc func startMatchmaking(_ call: CAPPluginCall) {
        self.logService.log("##: startMatchmaking")
        guard let visit = visit, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        AWSDKVisitService.startFindFirstAvailableServiceWithVisit(visit: visit, delegate: self) { success, error in
            ResponseHelper.handleResponse(for: call, success, error, alternateErrorMessage: "Find First Available Failed")
            return
        }
        
        let emptyObject = [
            Constants.PluginEvent.eventType: Constants.VisitEvent.empty
        ]
        
        notifyListeners(Constants.Matchmaking.result, data: emptyObject, retainUntilConsumed: true)
    }
    
    /// Stops an in-progress matchmaking request.
    @objc func cancelMatchmaking(_ call: CAPPluginCall) {
        self.logService.log("##: cancelMatchmaking")
        guard let visit = visit, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        visit.consumer.cancelFindFirstAvailableRequest { success, error in
            ResponseHelper.handleResponse(for: call, success, error, alternateErrorMessage: "Cancel first available provider failed.")
        }
    }
    
    // MARK: - Payment
    
    /// Retrieves the payment method on file for the currently-authenticated consumer.
    @objc func fetchConsumerPaymentMethod(_ call: CAPPluginCall) {
        guard let consumer = consumer, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        consumerService.fetchPaymentMethod(for: consumer, call, {})
    }
    
    /// Updates the payment method on file for the currently-authenticated consumer.
    @objc func updateConsumerPaymentMethod(_ call: CAPPluginCall) {
        guard let consumer = consumer, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let states = states,
              let countries = countries
        else {
            ResponseHelper.sendErrorResponse(to: call, with: "Error processing address information")
            return
        }
        
        consumerService.updatePaymentMethod(for: consumer, states, countries, call, {})
    }
    
    /// Finds states that are valid for payment addresses within a given country.
    @objc func findPaymentStatesForCountry(_ call: CAPPluginCall) {
        guard isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        fetchStates(for: call)
    }
    
    /// Attempts to apply a coupon code to the current visit of the currently-authenticated consumer.
    @objc func applyCouponCode(_ call: CAPPluginCall) {
        self.logService.log("##: acceptDeclineAndTransfer")
        guard let visit = visit, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        visitService.applyCouponCode(for: visit, call) { success, errorMessage in
            guard success else {
                if !errorMessage.isEmpty {
                    ResponseHelper.sendErrorResponse(to: call, with: errorMessage)
                }
                return
            }
    
            ResponseHelper.validateAndSend(ResponseHelper.getCostJSON(visit.cost), to: call)
            return
        }
    }
    
    // MARK: - Medication
    
    /// Finds medications for a supplied user whose names start with a supplied string (must be at least 3 characters).
    @objc func findMedications(_ call: CAPPluginCall) {
        guard isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        amwellService.findMedications(call) { [weak self] medications in
            guard let strongSelf = self else { return }
            
            strongSelf.medications.append(contentsOf: medications)
        }
    }
    
    // MARK: - Visit
    
    /// Initializes an on-demand visit request object.
    @objc func buildVisitContext(_ call: CAPPluginCall) {
        guard let consumer = consumer, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }

        // consumer check happens inside the below method.
        visitService.createVisitContext(for: consumer, with: providers, dependents, practices, call) { [weak self] visitContext, legalTexts in
            guard let strongSelf = self,
                  let visitContext = visitContext,
                  let legalTexts = legalTexts
            else { return }
            
            strongSelf.visitLegalTexts = legalTexts
            strongSelf.visitContext = visitContext
        }
    }
    
    /// Updates the most recent VisitContext  with the supplied information, and then attempts to use that VisitContext to generate a Visit instance.
    @objc func buildVisit(_ call: CAPPluginCall) {
        self.logService.log("##: buildVisit")
        guard isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let visitContext = visitContext
        else {
            ResponseHelper.sendErrorResponse(to: call, with: "Invalid Visit Context")
            return
        }
        
        visitService.buildVisit(with: visitContext, call) { [weak self] visit in
            guard let strongSelf = self,
                  let visit = visit
            else { return }
            
            strongSelf.call = call
            strongSelf.visit = visit
            strongSelf.visit?.callbackDelegate = strongSelf
            strongSelf.visit?.delegate = strongSelf
        }
    }
    
    /// Confirms whether enough valid information has been provided to start a visit.
    @objc func validateVisitContext(_ call: CAPPluginCall) {
        self.logService.log("##: validateVisitContext")
        guard isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let visitContext = visitContext else {
            return
        }
        
        do
        {
            try AWSDKVisitService.isVisitContextValid(visitContext, cartMode: false)
        } catch (let error as NSError) {
            ResponseHelper.sendValidationErrorResponse(to: call, error, "Invalid VisitContext.")
            self.logService.log("##: Error: \n \(String(describing: error.userInfo[AWSDKValidationErrorsKey]))")
            return
        }
        
        call.resolve([Constants.Error.validationErrors: []])
    }
    
    /// Attempts to start a visit.
    @objc func startVisit(_ call: CAPPluginCall) {
        self.logService.log("##: startVisit")
        guard isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let visit = visit else {
            ResponseHelper.sendErrorResponse(to: call, with: "Invalid Visit")
            return
        }
        
        let emptyObject = [
            Constants.PluginEvent.eventType: Constants.VisitEvent.empty
        ]
        
        notifyListeners(Constants.VisitEvent.onChat, data: emptyObject, retainUntilConsumed: true)
        notifyListeners(Constants.VisitEvent.onFailure, data: emptyObject, retainUntilConsumed: true)
        notifyListeners(Constants.VisitEvent.onPatientsAheadCountChanged, data: emptyObject, retainUntilConsumed: true)
        notifyListeners(Constants.VisitEvent.onPollFailure, data: emptyObject, retainUntilConsumed: true)
        notifyListeners(Constants.VisitEvent.onProviderEntered, data: emptyObject, retainUntilConsumed: true)
        notifyListeners(Constants.VisitEvent.onResponse, data: emptyObject, retainUntilConsumed: true)
        notifyListeners(Constants.VisitEvent.onSuggestFindFirstAvailable, data: emptyObject, retainUntilConsumed: true)
        notifyListeners(Constants.VisitEvent.onSuggestedTransfer, data: emptyObject, retainUntilConsumed: true)
        notifyListeners(Constants.VisitEvent.onValidationFailure, data: emptyObject, retainUntilConsumed: true)
        notifyListeners(Constants.VisitEvent.onVisitEnded, data: emptyObject, retainUntilConsumed: true)
        
        visitService.start(visit, call) { _ in }
    }
    
    /// Determines what to do next after a provider or assistant has declined a visit and initiated a transfer to another provider.
    @objc func acceptDeclineAndTransfer(_ call: CAPPluginCall) {
        self.logService.log("##: acceptDeclineAndTransfer")
        guard isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let transfer = forcedTransfer else {
            ResponseHelper.sendErrorResponse(to: call, with: "No Visit Stored")
            return
        }
        
        accept(transfer, call)
    }
    
    /// Attempts to accept the most recent system-generated visit transfer suggestion.
    @objc func acceptSuggestedTransfer(_ call: CAPPluginCall) {
        self.logService.log("##: acceptSuggestedTransfer")
        guard let visit = visit, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        if let transfer = visit.suggestedTransfer {
            accept(transfer, call)
        }
    }
    
    /// Attempts to accept a transfer manually initiated by a provider at the end of a visit.
    @objc func acceptPostVisitTransfer(_ call: CAPPluginCall) {
        guard let forcedTransfer = forcedTransfer, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        accept(forcedTransfer, call)
    }
    
    /// Rejects the most recent visit transfer suggestion, and optionally disables future suggestions.
    @objc func declineTransfer(_ call: CAPPluginCall) {
        self.logService.log("##: declineTransfer")
        guard let visit = visit, isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let shouldStopSuggestions = call.getBool(Constants.Call.shouldStopSuggestions) else {
            return
        }
        
        guard let transfer = visit.suggestedTransfer else {
            return
        }
        
        transfer.dontSuggestTransferAgain = shouldStopSuggestions
        visitService.decline(transfer, call, {})
    }
    
    /// After completing a visit, this method will return a summary of the final details from the provider.
    @objc func fetchVisitSummary(_ call: CAPPluginCall) {
        self.logService.log("##: fetchVisitSummary")
        guard isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let visit = visit else {
            ResponseHelper.sendErrorResponse(to: call, with: "Visit not found")
            return
        }
        
        visitService.getSummary(for: visit, call) { [weak self] visitSummary in
            guard let strongSelf = self else { return }
            
            strongSelf.visitSummary = visitSummary
        }
    }
    
    /// Attempts to send the visit summary to one or more email addresses, one or more fax numbers or both.
    @objc func shareVisitSummary(_ call: CAPPluginCall) {
        self.logService.log("##: shareVisitSummary")
        guard isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let visitSummary = visitSummary else {
            ResponseHelper.sendErrorResponse(to: call, with: "Visit not found")
            return
        }
        
        visitService.sendSummaryToEmailsAndFaxNumberes(visitSummary, call, {})
    }
    
    /// Attempts to submit a consumer's feedback for a visit that has just ended.
    @objc func submitVisitFeedback(_ call: CAPPluginCall) {
        self.logService.log("##: submitVisitFeedback")
        guard isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let visitSummary = visitSummary else {
            ResponseHelper.sendErrorResponse(to: call, with: "Visit not found")
            return
        }
        
        visitService.submitVisitFeedback(visitSummary, call, {})
    }
    
    /// Attempts to submit a consumer's ratings for a visit that has just ended.
    @objc func submitVisitRatings(_ call: CAPPluginCall) {
        self.logService.log("##: submitVisitRatings")
        guard isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let visitSummary = visitSummary else {
            ResponseHelper.sendErrorResponse(to: call, with: "Visit Summary not found")
            return
        }
        
        visitService.rateProviderAndEngagement(for: visitSummary, call) { }
    }
    
    /// Attempts to cancel a visit while in the waiting room.
    @objc func cancelVisit(_ call: CAPPluginCall) {
        self.logService.log("##: submitVisitRatings")
        guard isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let visit = visit else {
            ResponseHelper.sendErrorResponse(to: call, with: "Visit not found")
            return
        }
        
        visitService.cancelPending(visit, call, {})
    }
    
    @objc func startGuestVisit(_ call: CAPPluginCall) {
        self.logService.log("##: startGuestVisit")
        
        guard let guestName = call.getString(Constants.Call.guestName) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Parameter guestName is required.")
            return
        }
        
        guard let guestEmail = call.getString(Constants.Call.guestEmail) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Parameter guestEmail is required.")
            return
        }
        
        guard let launchURL = AWSDKService.launchUrl() else {
            ResponseHelper.sendErrorResponse(to: call, with: "Launch URL not found.")
            return
        }
        
        let emptyObject = [
            Constants.PluginEvent.eventType: Constants.VisitEvent.empty
        ]
        
        notifyListeners(Constants.VisitEvent.conferenceStarted, data: emptyObject, retainUntilConsumed: true)
        notifyListeners(Constants.VisitEvent.conferenceFinished, data: emptyObject, retainUntilConsumed: true)
        notifyListeners(Constants.VisitEvent.conferenceFailed, data: emptyObject, retainUntilConsumed: true)
        
        AWSDKAuthenticationService.authenticateGuest(
            with: launchURL,
            email: guestEmail,
            name: guestName,
            delegate: self
        ) { [weak self] visitConsoleController, error in
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                return
            }
            
            guard let visitConsoleController = visitConsoleController else {
                ResponseHelper.sendErrorResponse(to: call, with: "Invalid Console Returned.")
                return
            }
            
            guard let strongSelf = self else { return }
            strongSelf.console = visitConsoleController
            ResponseHelper.sendSuccessResponse(to: call)
            DispatchQueue.main.async {
                strongSelf.bridge.viewController.present(visitConsoleController, animated: true, completion: {
                    // send the conferenceStarted event
                    let data = [Constants.PluginEvent.value: Constants.VisitEvent.conferenceStarted]
                    strongSelf.notifyListeners(Constants.VisitEvent.conferenceStarted, data: data, retainUntilConsumed: true)
                })
            }
        }
    }
    
    // MARK: - Appointment
    
    /// Finds providers availble for scheduled visits matching the provided search options.
    @objc func findAppointmentProviders(_ call: CAPPluginCall) {
        guard isConsumerAuthenticated,
            let currentConsumer = currentConsumer
        else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let practice = getPractice(from: call) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Practice cache not populated.")
            return
        }
        
        guard let state = getState(from: call) else { return }
        
        appointmentService.findProviders(for: currentConsumer, practice, state, call) { [weak self] appointmentProviders in
            guard let strongSelf = self else { return }
            
            if appointmentProviders.count > 0 {
                strongSelf.appointmentProviders = appointmentProviders
            }
        }
    }
    
    /// Attempts to schedule an appointment with a provider.
    @objc func scheduleAppointment(_ call: CAPPluginCall) {
        self.logService.log("##: scheduleAppointment")
        guard isConsumerAuthenticated,
            let consumer = consumer
        else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let sdkConsumer = getConsumer(with: call, consumer) else { return }
        guard let appointmentProvider = getAppointmentProvider(from: call) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Could not find provider in cache.")
            return
        }
        
        appointmentService.scheduleAppointment(for: sdkConsumer, appointmentProvider, call, {})
    }
    
    /// Finds a specific appointment.
    @objc func findAppointmentBySourceId(_ call: CAPPluginCall) {
        self.logService.log("##: findAppointmentBySourceId")
        guard isConsumerAuthenticated,
            let consumer = consumer
        else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let sdkConsumer = getConsumer(with: call, consumer) else { return }
        
        appointmentService.findAppointmentBySourceID(for: sdkConsumer, call, {})
    }
    
    /// Finds scheduled appointments.
    @objc func findAppointments(_ call: CAPPluginCall) {
        self.logService.log("##: findAppointments")
        guard isConsumerAuthenticated,
            let consumer = consumer
        else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let sdkConsumer = getConsumer(with: call, consumer) else { return }
        appointmentService.findAppointments(for: sdkConsumer, call, {})
    }
    
    /// Attempts to cancel an appointment with a provider.
    @objc func cancelAppointment(_ call: CAPPluginCall) {
        self.logService.log("##: cancelAppointment")
        guard isConsumerAuthenticated,
            let consumer = consumer
        else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let sdkConsumer = getConsumer(with: call, consumer) else { return }
        guard let sourceID = call.getString(Constants.Call.appointmentSourceID) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Parameter appointmentSourceId is required.")
            return
        }
        
        appointmentService.cancelAppointment(with: sourceID, for: sdkConsumer, call, {})
    }
    
    /// Returns time slots that a specified provider is availble for scheduled visits.
    @objc func fetchAppointmentProviderAvailability(_ call: CAPPluginCall) {
        self.logService.log("##: fetchAppointmentProviderAvailability")
        guard isConsumerAuthenticated,
            let consumer = consumer
        else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let sdkConsumer = getConsumer(with: call, consumer) else { return }
        guard let date = call.getString(Constants.Call.date) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Parameter date is required.")
            return
        }
        
        guard let provider = getAppointmentProvider(from: call) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Invalid providerSourceId.")
            return
        }
        
        appointmentService.fetchAvailableAppointments(for: provider, on: date, sdkConsumer, call, {})
    }
    
    // MARK: - Messaging
    
    /// Retrieves telehealth mailbox information for a specified consumer.
    @objc func fetchMailbox(_ call: CAPPluginCall) {
        self.logService.log("##: fetchMailbox")
        guard isConsumerAuthenticated,
            let consumer = consumer
        else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let sdkConsumer = getConsumer(with: call, consumer) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Could not determine consumer using provided consumerSourceId.")
            return
        }
        
        messageService.fetchMailbox(for: sdkConsumer, call, { [weak self] messages in
            guard let strongSelf = self,
                let messages = messages
            else { return }
            
            strongSelf.messages = messages
        })
    }
    
    /// Retrieves a full telehealth message.
    @objc func fetchMessage(_ call: CAPPluginCall) {
        self.logService.log("##: fetchMessage")
        guard isConsumerAuthenticated,
            let consumer = consumer
        else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let sdkConsumer = getConsumer(with: call, consumer) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Could not determine consumer using provided consumerSourceId.")
            return
        }
        
        guard let messageID = call.getString(Constants.Call.TelehealthMessageID) else {
            ResponseHelper.sendErrorResponse(to: call, with: "MessageId parameter missing.")
            return
        }
        
        if let message = messages[messageID] {
            messageService.fetchMessageDetail(with: message, messageID, sdkConsumer, call) { [weak self] messageDetail, attachmentInfo in
                guard let strongSelf = self else { return }
                strongSelf.logService.log("##: Message found: \(String(describing: messageDetail?.bodyPreview))")
                
                strongSelf.messageDetail[messageID] = messageDetail
                strongSelf.attachmentInfo = attachmentInfo
            }
        }
    }
    
    /// Creates a new draft message for telehealth secure messaging.
    @objc func buildMessageDraft(_ call: CAPPluginCall) {
        self.logService.log("##: fetchMessageContacts")
        guard isConsumerAuthenticated,
            let consumer = currentConsumer
        else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let draftType = call.getString(Constants.Call.draftType) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Parameter draftType is required.")
            return
        }
        
        guard let messageDraftType = TelehealthMessageDraftType(rawValue: draftType) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Parameter draftType must be one of [NEW, FORWARD, REPLY].")
            return
        }
        
        var message: AWSDKMessage?
        
        if messageDraftType == .forward || messageDraftType == .reply {
            guard let sourceID = call.getString(Constants.Call.sourceMessageID) else {
                ResponseHelper.sendErrorResponse(to: call, with: "Parameter sourceMessageId is required for draftType of NEW or REPLY")
                return
            }
            
            guard let messageFound = messageDetail[sourceID] else {
                ResponseHelper.sendErrorResponse(to: call, with: "Could not find mailbox message in cache.")
                return
            }
            
            message = messageFound
        }
        
        messageService.fetchMessageDraft(for: consumer, with: messageDraftType, message, call) { [weak self] draft in
            guard let strongSelf = self else { return }
            
            strongSelf.messageDraft = draft
        }
    }
    
    /// Retrieves a list of contacts that a consumer may send secure messages to within the telehealth platform.
    @objc func fetchMessageContacts(_ call: CAPPluginCall) {
        self.logService.log("##: fetchMessageContacts")
        guard isConsumerAuthenticated,
            let consumer = consumer
        else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let sdkConsumer = getConsumer(with: call, consumer) else { return }
        
        messageService.fetchMessageContacts(for: sdkConsumer, call) { [weak self] contacts in
            guard let strongSelf = self else { return }

            guard let contacts = contacts else { return }
            
            strongSelf.messageContacts = contacts
        }
    }
    
    @objc func fetchMessageTopics(_ call: CAPPluginCall) {
        self.logService.log("##: fetchMessageTopics")
        messageService.fetchMessageTopics(call, { [weak self] topics in
            guard let strongSelf = self else { return }
            
            strongSelf.messageTopics = topics
        })
    }
    
    /// Attempts to mark a telehealth secure inbox message as "read".
    @objc func markMessageAsRead(_ call: CAPPluginCall) {
        self.logService.log("##: markMessageAsRead")
        guard isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let messageID = call.getString(Constants.Call.TelehealthMessageID) else {
            ResponseHelper.sendErrorResponse(to: call, with: "MessageId parameter missing.")
            return
        }
        
        if let message = messages[messageID] as? AWSDKInboxMessage {
            messageService.markMessageRead(message, call, {})
        } else {
            ResponseHelper.sendSuccessResponse(to: call)
        }
    }
    
    /// Attempts to send a telehealth secure message.
    @objc func sendMessage(_ call: CAPPluginCall) {
        self.logService.log("##: sendMessage")
        guard isConsumerAuthenticated,
            let consumer = consumer
        else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let sdkConsumer = getConsumer(with: call, consumer) else { return }
        guard let draftInfo = call.getObject(Constants.Call.draft) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Parameter draft is required.")
            return
        }
        
        guard let draftID = draftInfo[Constants.MessageDraft.draftID] as? String else {
            ResponseHelper.sendErrorResponse(to: call, with: "Parameter draftID is required.")
            return
        }
        
        guard let newMessageDraft = messageDraft?[draftID] else {
            ResponseHelper.sendErrorResponse(to: call, with: "Could not find message draft matching draft.id in cache.")
            return
        }
        
        // Update recipient (for NEW/FORWARD)
        if newMessageDraft.recipient == nil {
            guard let recipientInfo = draftInfo[Constants.MessageDraft.recipient] as? [String: Any] else {
                ResponseHelper.sendErrorResponse(to: call, with: "Parameter draft.recipient is required.")
                return
            }
            
            guard let recipientID = recipientInfo[Constants.MessageContact.contactID] as? String else {
                ResponseHelper.sendErrorResponse(to: call, with: "Parameter draft.recipient.id is required.")
                return
            }
            
            guard let recipient = messageContacts[recipientID] else {
                ResponseHelper.sendErrorResponse(to: call, with: "Could not find contact matching draft.recipient.id in cache.")
                return
            }
            
            newMessageDraft.updateRecipient(recipient, withCompletion: { success, error in
                if error != nil {
                    ResponseHelper.sendErrorResponse(to: call, error: error)
                    return
                }
            })
        }
        
        // Update topic (for NEW)
        if newMessageDraft.topic == nil {
            guard let topicInfo = draftInfo[Constants.MessageDraft.topic] as? [String: String],
                  let topicName = topicInfo[Constants.MessageTopic.name]
            else {
                ResponseHelper.sendErrorResponse(to: call, with: "Parameter draft.topic is required for new message threads.")
                return
            }
            
            guard let topics = messageTopics,
                  let topic = topics.first(where: { $0.name == topicName })
            else {
                ResponseHelper.sendErrorResponse(to: call, with: "Could not find message topic matching draft.topic.name.")
                return
            }
            
            newMessageDraft.setTopic(topic) { success, error in
                if error != nil {
                    ResponseHelper.sendErrorResponse(to: call, error: error)
                    return
                }
            }
        }
        
        // update subject
        let subject = draftInfo[Constants.MessageDraft.subject] as? String ?? ""
        
        // update body
        guard let body = draftInfo[Constants.MessageDraft.body] as? String else {
            ResponseHelper.sendErrorResponse(to: call, with: "Parameter draft.body is required.")
            return
        }
        
        // Update health summary flag
        guard let healthFlag = draftInfo[Constants.MessageDraft.shouldShareHealthSummary] as? Bool else {
            ResponseHelper.sendErrorResponse(to: call, with: "Parameter draft.shouldShareHealthSummary is required.")
            return
        }
        
        newMessageDraft.subject = subject
        newMessageDraft.messageBody = body
        newMessageDraft.shareHealthSummary = healthFlag
        
        sdkConsumer.sendMessage(newMessageDraft) { success, error in
            ResponseHelper.handleResponse(for: call, success, error, alternateErrorMessage: "Failed to send message.")
        }
    }
    
    /// Allows the consumer to select a file to attach to a telehealth secure message draft in progress.
    @objc func addMessageDraftAttachment(_ call: CAPPluginCall) {
        self.logService.log("##: addMessageDraftAttachment")
        guard isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        self.call = call
        uploadReason = .mailAttachment
        showDocumentPickerActionSheet()
    }
    
    /// Attempts to delete a telehealth secure message.
    @objc func deleteMessage(_ call: CAPPluginCall) {
        self.logService.log("##: deleteMessage")
        guard isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let messageID = call.getString(Constants.Call.TelehealthMessageID),
              let message = messages[messageID] else {
            ResponseHelper.sendErrorResponse(to: call, with: "Could not find mailbox message in cache.")
            return
        }
        
        message.delete { success, error in
            ResponseHelper.handleResponse(for: call, success, error, alternateErrorMessage: "Failed to delete message.")
        }
    }
    
    /// Allows the consumer to remove any attachment from a telehealth secure message draft in progress.
    @objc func removeMessageDraftAttachment(_ call: CAPPluginCall) {
        self.logService.log("##: removeMessageDraftAttachment")
        guard isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let messageDraftID = call.getString(Constants.Call.messageDraftID),
              let newMessageDraft = messageDraft?[messageDraftID]
        else {
            ResponseHelper.sendErrorResponse(to: call, with: "Could not find message draft in cache.")
            return
        }
        
        newMessageDraft.clearAttachment()
        ResponseHelper.sendSuccessResponse(to: call)
    }
    
    /// Attempts to display a telehealth secure message attachment.
    @objc func viewMessageAttachment(_ call: CAPPluginCall) {
        self.logService.log("##: viewMessageAttachment")
        guard isConsumerAuthenticated else {
            ResponseHelper.sendErrorResponse(to: call, with: Constants.Error.consumerNotAuthenticated)
            return
        }
        
        guard let attachmentID = call.getString(Constants.Call.attachmentId),
              let attachment = attachmentInfo?[attachmentID]
        else {
            ResponseHelper.sendErrorResponse(to: call, with: "Parameter attachmentId is required.")
            return
        }
        
        attachment.fetch { data, error in
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                return
            }
            guard let data = data else { return }
            
            let fileName = attachment.name.components(separatedBy: ".")
            guard fileName.count >= 2,
                let pathExtension = fileName.last
            else {
                ResponseHelper.sendErrorResponse(to: call, with: "Invalid filename.")
                return
            }
            
            let directoryURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let fileURL = URL(fileURLWithPath: fileName[0], relativeTo: directoryURL).appendingPathExtension(pathExtension)
            do {
                try data.write(to: fileURL)
            } catch (let error) {
                self.logService.log(error.localizedDescription)
                ResponseHelper.sendErrorResponse(to: call, error: error)
            }
            
            ResponseHelper.sendResponse(to: call, fileURL.path)
        }
    }
    
    //  MARK: - Miscellaneous
    
    @objc func echo(_ call: CAPPluginCall) {
        amwellService.echo(call)
    }
    
    /// Retrieves details about credit card types supported by the telehealth platform.
    @objc func fetchCreditCardTypes(_ call: CAPPluginCall) {
        amwellService.fetchCreditCardTypes(call)
    }
    
    /// Returns information about countries supported by the telehealth platform.
    @objc func fetchSupportedCountries(_ call: CAPPluginCall) {
        countries = amwellService.fetchCountries(call)
    }
    
    /// Finds states that are valid for telehealth registration within a given country.
    @objc func findEnrollmentStatesForCountry(_ call: CAPPluginCall) {
        fetchStates(for: call)
    }
    
    /// Returns the current Amwell SDK version used by the plugin.
    @objc func fetchSdkVersion(_ call: CAPPluginCall) {
        amwellService.getSdkVersion(call)
    }
    
    @objc func fetchReminderOptions(_ call: CAPPluginCall) {
        self.logService.log("##: fetchReminderOptions")
        ResponseHelper.sendReminderOptions(call)
    }
    
    // MARK: - Private
    
    private func fetchStates(for call: CAPPluginCall) {
        let result = amwellService.fetchStatesForCountry(call)
        countries = result.countries
        states = result.states
    }
    
    private func accept(_ transfer: AWSDKVisitTransfer, _ call: CAPPluginCall) {
        guard let visit = visit else { return }
        
        visitService.accept(transfer, for: visit.consumer, call) { [weak self] visit, visitContext, legalTexts, transfer in
            guard let strongSelf = self else { return }
            
            strongSelf.visitContext = visitContext
            if let legalTexts = legalTexts {
                strongSelf.visitLegalTexts = legalTexts
            }
            
            strongSelf.visit = visit
            if visit != nil {
                strongSelf.visit?.delegate = strongSelf
                strongSelf.visit?.callbackDelegate = strongSelf
            }
            
            if let transfer = transfer {
                strongSelf.suggestedTransfer = transfer
            }
        }
    }
    
    private func getConsumer(with call: CAPPluginCall, _ member: AWSDKConsumer) -> AWSDKConsumer? {
        if let consumerSourceID = call.getString(Constants.Call.consumerSourceID) {
            self.logService.log("##: consumerID: \(consumerSourceID)")
            if consumerSourceID == member.sourceId {
                return member
            } else if let dependents = dependents,
               let dependent = dependents.first(where: { $0.sourceId == consumerSourceID })
            {
                currentConsumer = dependent
                 return dependent
            } else {
                ResponseHelper.sendErrorResponse(to: call, with: "Could not determine consumer using provided consumerSourceId.")
                return nil
            }
        }
        
        return member
    }
    
    private func getPractice(from call: CAPPluginCall) -> AWSDKPractice? {
        let practiceSourceID = call.getString(Constants.Call.practiceSourceID)
        return practices.first(where: { $0.sourceId == practiceSourceID })
    }
    
    private func getAppointmentProvider(from call: CAPPluginCall) -> AWSDKProvider? {
        guard let appointmentProviders = appointmentProviders else { return nil }
        
        guard let providerSourceID = call.getString(Constants.Call.providerSourceID) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Parameter providerSourceId is required.")
            return nil
        }
        
        return appointmentProviders.first(where: { $0.sourceID == providerSourceID })
    }
    
    private func getState(from call: CAPPluginCall) -> AWSDKState? {
        guard let stateCode = call.getString(Constants.Call.stateCode) else {
            ResponseHelper.sendErrorResponse(to: call, with: "State Code Missing")
            return nil
        }
        
        let countryCode = call.getString(Constants.Call.countryCode) ?? AmwellService.defaultCountry
        
        guard let countries = AWSDKEnrollmentService.countries,
            let country = countries.first(where: { $0.code == countryCode })
        else {
            ResponseHelper.sendErrorResponse(to: call, with: "Invalid Country Code")
            return nil
        }
        
        guard let enrollmentStates = country.enrollmentStates,
              let state = enrollmentStates.first(where: { $0.code == stateCode }) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Invalid State Code")
            return nil
        }
        
        return state
    }
    
    private func showDocumentPickerActionSheet() {
        let actionSheet = UIAlertController(
            title: Constants.LocalizedStrings.uploadDocumentTitle,
            message: Constants.LocalizedStrings.uploadDocumentMessage,
            preferredStyle: .actionSheet
        )
        actionSheet.addAction(UIAlertAction(title: "Photos Library", style: .default, handler: { action in
            DispatchQueue.main.async {
                let imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.allowsEditing = true
                imagePicker.sourceType = .photoLibrary
                self.bridge.viewController.present(imagePicker, animated: true, completion: nil)
            }
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Files", style: .default, handler: { action in
            let documentTypes = [kUTTypePNG as String,
                                 kUTTypePDF as String,
                                 kUTTypeGIF as String,
                                 kUTTypeJPEG as String,
                                 kUTTypeBMP as String,
                                 kUTTypeMPEG4 as String,
                                 kUTTypeMPEG as String,
                                 kUTTypeMovie as String,
                                 kUTTypeText as String,
                                 kUTTypePlainText as String
                                ]
            DispatchQueue.main.async {
                let documentPicker = UIDocumentPickerViewController(documentTypes: documentTypes, in: .import)
                documentPicker.delegate = self
                documentPicker.allowsMultipleSelection = false
                self.bridge.viewController.present(documentPicker, animated: true, completion: nil)
            }
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { action in
            guard let call = self.call else { return }
            ResponseHelper.sendNULLResponse(to: call)
            actionSheet.dismiss(animated: true, completion: nil)
        }))
        
        DispatchQueue.main.async {
            self.bridge.viewController.present(actionSheet, animated: true, completion: nil)
        }
    }
}

// MARK: AWSDKLogServiceDelegate

extension AmwellPlugin: AWSDKLogServiceDelegate {
    public func didReceiveLogMessage(_ message: String!) {
        self.logService.log("Message from AMWELL: \(message ?? "")")
    }
}

// MARK: UIImagePickerControllerDelegate

extension AmwellPlugin: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    public func imagePickerController(
        _ picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any])
    {
        guard let imageURL = info[.imageURL] as? URL else { return }
        
        guard let call = call else { return }
        
        if uploadReason == .mailAttachment {
            guard let draftID = call.getString(Constants.Call.messageDraftID),
                  let draft = messageDraft?[draftID]
            else {
                ResponseHelper.sendErrorResponse(to: call, with: "Parameter messageDraftId is required.")
                return
            }
            
            messageService.uploadImageAttachment(for: draft, imageURL, call, {})
        } else if uploadReason == .visit {
            consumerService.addImageDocument(for: currentConsumer, imageURL, call) { [weak self] imageInfo in
                guard let strongSelf = self,
                      let imageInfo = imageInfo
                else { return }
                
                for (key, value) in imageInfo {
                    strongSelf.documents.updateValue(value, forKey: key)
                }
            }
        }
        
        uploadReason = .unknown
        DispatchQueue.main.async {
            self.bridge.viewController.dismiss(animated: true)
        }
    }
    
    public func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        guard let call = call else { return }
        
        ResponseHelper.sendNULLResponse(to: call)
        DispatchQueue.main.async {
            self.bridge.viewController.dismiss(animated: true)
        }
    }
}

// MARK: - UIDocumentPickerDelegate

extension AmwellPlugin: UIDocumentPickerDelegate {
    public func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        let url = urls[0]
        let fileName = url.lastPathComponent
        let fileExtension = url.pathExtension
        guard let data = try? Data(contentsOf: url) else { return }
        
        guard let uti = UTTypeCreatePreferredIdentifierForTag(kUTTagClassFilenameExtension,
            fileExtension as CFString, nil)?.takeRetainedValue(),
            let mimeType = UTTypeCopyPreferredTagWithClass(uti, kUTTagClassMIMEType)?.takeRetainedValue()
        else {
            return
        }
        
        guard let call = call else { return }
        
        self.logService.log("##: didPickDocument \(fileName), \(fileExtension)")
        if uploadReason == .mailAttachment {
            guard let draftID = call.getString(Constants.Call.messageDraftID),
                  let draft = messageDraft?[draftID]
            else {
                ResponseHelper.sendErrorResponse(to: call, with: "Parameter messageDraftId is required.")
                return
            }
            
            messageService.uploadAttachment(for: draft, data, mimeType as String, fileName, call, {})
        } else if uploadReason == .visit {
            consumerService.addDocument(for: currentConsumer, data, mimeType as String, fileName, call) { [weak self] documentInfo in
                guard let strongSelf = self,
                      let documentInfo = documentInfo
                else { return }
                
                for (key, value) in documentInfo {
                    strongSelf.documents.updateValue(value, forKey: key)
                }
            }
        }
        
        uploadReason = .unknown
        DispatchQueue.main.async {
            self.bridge.viewController.dismiss(animated: true)
        }
    }
    
    public func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        guard let call = call else { return }
        
        ResponseHelper.sendNULLResponse(to: call)
        DispatchQueue.main.async {
            self.bridge.viewController.dismiss(animated: true)
        }
    }
}

// MARK: - AWSDKVisitDelegate

extension AmwellPlugin: AWSDKVisitDelegate {
    public func providerDidEnterVisit() {
        self.logService.log("##: providerDidEnterVisit")
        guard let visit = visit,
              let call = call
        else { return }
        
        let dataObject: [String: Any] = [
            Constants.PluginEvent.eventType: Constants.VisitEvent.onProviderEntered,
            Constants.Response.value: true
        ]
        
        notifyListeners(
            Constants.VisitEvent.onProviderEntered,
            data: dataObject,
            retainUntilConsumed: true
        )
        
        if visit.modality.code == AWSDKModalityCode.phone {
            // show phone visit instructions
        } else {
            AWSDKVisitService.createVisitConsole(for: visit) { [weak self] visitController, error in
                guard let strongSelf = self else { return }
                
                if let error = error {
                    ResponseHelper.sendErrorResponse(to: call, error: error)
                    return
                }
                
                guard let visitController = visitController else { return }
                
                strongSelf.console = visitController
                DispatchQueue.main.async {
                    strongSelf.bridge.viewController.present(visitController, animated: true, completion: {})
                }
                
            }
        }
    }
    
    public func visitDidComplete(_ visitSuccessful: Bool, with reason: AWCoreVisitEndReason) {
        self.logService.log("##: visitDidComplete - reason: \(reason.title())")
        guard let visit = visit else { return }
        
        var dataObject: [String: Any] = [
            Constants.VisitEndEvent.eventType: Constants.VisitEvent.onVisitEnded,
            Constants.VisitEndEvent.visitEndReason: reason.title()
        ]
        
        if reason == .assistantDeclineAndTransfer ||
            reason == .providerDeclineAndTransfer ||
            reason == .postVisitTransfer
        {
            if let forcedTransfer = visit.forcedTransfer {
                self.forcedTransfer = forcedTransfer
                let transferJSON = ResponseHelper.getTransferJSON(forcedTransfer)
                dataObject[Constants.PluginEvent.transfer] = transferJSON
            }
        }
        
        notifyListeners(Constants.VisitEvent.onVisitEnded, data: dataObject, retainUntilConsumed: true)
        if let console = console {
            console.dismiss(animated: true)
        }
    }
    
    public func patientsAheadOfConsumerDidChange() {
        guard let visit = visit else { return }
        
        self.logService.log("##: patientsAheadOfConsumerDidChange: \(visit.patientsAheadOfConsumer)")
        let dataObject: [String: Any] = [
            Constants.VisitEndEvent.eventType: Constants.VisitEvent.onPatientsAheadCountChanged,
            Constants.PluginEvent.count: visit.patientsAheadOfConsumer
        ]
        
        notifyListeners(
            Constants.VisitEvent.onPatientsAheadCountChanged,
            data: dataObject,
            retainUntilConsumed: true
        )
    }
    
    public func suggestedTransferDidChange(_ transfer: AWSDKSuggestedVisitTransfer) {
        self.logService.log("##: suggestedTransferDidChange")
        // if there is a forced transfer, ignore the suggested transfer
        if visit?.forcedTransfer != nil {
            return
        }
        
        self.suggestedTransfer = transfer
        let dataObject: [String: Any] = [
            Constants.VisitEndEvent.eventType: Constants.VisitEvent.onSuggestedTransfer,
            Constants.PluginEvent.transfer: ResponseHelper.getTransferJSON(transfer)
        ]
        
        notifyListeners(
            Constants.VisitEvent.onSuggestedTransfer,
            data: dataObject,
            retainUntilConsumed: true
        )
    }
    
    public func chatReportDidChange(_ newChatReport: AWSDKChatReport) {
        self.logService.log("##: chatReportDidChange")
        notifyListeners(
            Constants.VisitEvent.onChat,
            data: [Constants.Response.value: true],
            retainUntilConsumed: true
        )
    }
    
    public func visitUpdateDidFail(_ error: Error) {
        self.logService.log("##: visitUpdateDidFail")
        let newError = error as NSError
        let validationError = newError.userInfo[AWSDKValidationErrorsKey] ?? newError.userInfo
        let data = [
            Constants.Response.value: true,
            Constants.Response.error: validationError
        ] as [String : Any]
        
        notifyListeners(
            Constants.VisitEvent.onFailure,
            data: data,
            retainUntilConsumed: true
        )
        
        // if console exists, dismiss it and call cancelPendingVisit to stop polling.
    }
    
    public func visitDidSuggestFirstAvailableSearch() {
        self.logService.log("##: visitDidSuggestFirstAvailableSearch")
        notifyListeners(
            Constants.VisitEvent.onSuggestFindFirstAvailable,
            data: [Constants.Response.value: true],
            retainUntilConsumed: true
        )
    }
}

// MARK: - AWSDKCallbackDelegate

extension AmwellPlugin: AWSDKCallbackDelegate {
    public func callbackStatusDidChange(_ status: AWSDKCallbackStatus) {
        switch status {
        case .consumerUnreachable,
             .providerUnreachable,
             .timeout,
             .unknown:
            // retry callback
            guard let visit = visit else { return }
            
            AWSDKVisitService.retryCallback(visit) { success, error in
                
            }
            
        case .consumerFailed,
             .providerFailed,
             .connected:
            // end callback & proceed to show visit summary
            guard let visit = visit else { return }
            
            AWSDKVisitService.endCallback(visit) { success, error in
                
            }
        case .dialingConsumer,
             .dialingProvider,
             .queued,
             .requested:
            // no-op
            break
            
        default:
            break
        }
    }
}

// MARK: - AWSDKFindFirstAvailableDelegate

extension AmwellPlugin: AWSDKFindFirstAvailableDelegate {
    public func providerFound() {
        guard let visit = visit else { return }
        
        let data = [
            Constants.MatchmakingResult.provider: ResponseHelper.getProviderJSON(from: visit.provider, isDetail: false),
            Constants.MatchmakingResult.isListExhausted: false,
            Constants.MatchmakingResult.didRequestFail: false
        ] as [String : Any]
        
        notifyListeners(Constants.Matchmaking.result, data: data, retainUntilConsumed: true)
    }
    
    public func providerListExhausted() {
        let data = [
            Constants.MatchmakingResult.provider: NSNull(),
            Constants.MatchmakingResult.isListExhausted: true,
            Constants.MatchmakingResult.didRequestFail: false
        ] as [String : Any]
        
        notifyListeners(Constants.Matchmaking.result, data: data, retainUntilConsumed: true)
    }
    
    public func findFirstAvailableFailedWithError(_ error: Error?) {
        let data = [
            Constants.MatchmakingResult.provider: NSNull(),
            Constants.MatchmakingResult.isListExhausted: false,
            Constants.MatchmakingResult.didRequestFail: true
        ] as [String : Any]
        
        notifyListeners(Constants.Matchmaking.result, data: data, retainUntilConsumed: true)
    }
}

extension AmwellPlugin: AWCoreGuestConsoleDelegate {
    public func leftVisit(with reason: AWCoreVisitEndReason) {
        if reason == .visitEnded ||
            reason == .consumerEnd ||
            reason == .providerEnd ||
            reason == .consumerTransfer ||
            reason == .postVisitTransfer ||
            reason == .providerDeclineAndTransfer ||
            reason == .assistantDeclineAndTransfer
        {
            let dataObject = [
                Constants.PluginEvent.value: Constants.VisitEvent.conferenceFinished,
                Constants.VisitEndEvent.visitEndReason: reason.title()
                ]
            notifyListeners(Constants.VisitEvent.conferenceFinished, data: dataObject, retainUntilConsumed: true)
        } else {
            let dataObject = [
                Constants.PluginEvent.value: Constants.VisitEvent.conferenceFailed,
                Constants.VisitEndEvent.visitEndReason: reason.title()
                ]
            notifyListeners(Constants.VisitEvent.conferenceFailed, data: dataObject, retainUntilConsumed: true)
        }
        
        if let console = console {
            console.dismiss(animated: true)
        }
    }
}
