//
//  LegalDocumentService.swift
//  AmwellPlugin
//
//  Created by Miraj, Kusum on 3/15/21.
//

import Foundation
import Capacitor
import AWSDK

class LegalDocumentService {
    var logService: LogService
    
    init(logService: LogService) {
        self.logService = logService
    }
    
    func fetchOutstandingDisclaimer(
        for consumer: AWSDKConsumer,
        _ call: CAPPluginCall,
        _ completion: @escaping () -> Void)
    {
        self.logService.log("##: FetchOutstandingDisclaimer")
        guard let disclaimer = consumer.outstandingDisclaimer else {
            ResponseHelper.sendNULLResponse(to: call)
            completion()
            return
        }
        
        disclaimer.fetch { disclaimer, error in
            guard let disclaimer = disclaimer else { return }
            
            if let error = error {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion()
                return
            }
            
            ResponseHelper.sendResponse(to: call, disclaimer)
            completion()
        }
    }
    
    func acceptOutstandingDisclaimer(
        for consumer: AWSDKConsumer,
        _ call: CAPPluginCall,
        _ completion: @escaping () -> Void)
    {
        self.logService.log("##: acceptOutstandingDisclaimer")
        consumer.acceptDisclaimer { success, error in
            ResponseHelper.handleResponse(
                for: call,
                success,
                error,
                alternateErrorMessage: "Accept Disclaimer failed with no error."
            )
            completion()
        }
    }
    
    func fetchTextBody(
        for legalTexts: [String: AWSDKLegalText],
        _ call: CAPPluginCall,
        _ completion: @escaping () -> Void)
    {
        self.logService.log("##: FetchLegalTextBody")
        guard let legalTextID = call.getString(Constants.Call.legalTextID) else {
            ResponseHelper.sendErrorResponse(to: call, with: "Parameter legalTextId is required.")
            completion()
            return
        }
        
        if let legalText = legalTexts[legalTextID] {
            legalText.fetch { (text, error) in
                if error != nil {
                    ResponseHelper.sendErrorResponse(to: call, error: error)
                    completion()
                    return
                }
                
                guard let text = text else { return }
                
                ResponseHelper.sendResponse(to: call, text)
                completion()
            }
        } else {
            ResponseHelper.sendErrorResponse(to: call, with: "Legal text not found in cache.")
            completion()
        }
    }
    
    func fetchEnrollmentDisclaimer(_ call: CAPPluginCall, _ completion: @escaping () -> Void) {
        self.logService.log("##: fetchEnrollmentDisclaimer")
        AWSDKEnrollmentService.fetchEnrollmentPrivacyPolicy { policy, error in
            guard let policy = policy else {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion()
                return
            }
            
            ResponseHelper.sendResponse(to: call, policy)
            completion()
        }
    }
}
