//
//  LogService.swift
//  AmwellPlugin
//
//  Created by Coker, Eric on 5/27/21.
//

import Foundation

class LogService {
    private var isEnabled: Bool = false;
    
    init(isEnabled: Bool) {
        self.isEnabled = isEnabled;
    }
    
    func disable() {
        self.isEnabled = false;
    }
    
    func enable() {
        self.isEnabled = true;
    }
    
    func log(_ items: Any) {
        if (self.isEnabled) {
            print(items);
        }
    }
}
