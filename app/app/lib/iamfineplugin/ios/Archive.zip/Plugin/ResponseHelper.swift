//
//  ResponseHelper.swift
//  AmwellPlugin
//
//  Created by Miraj, Kusum on 2/23/21.
//

import Foundation
import Capacitor
import AWSDK

struct ResponseHelper {
    static let staticSelf = ResponseHelper()
    
    static let PHARMACY_RETAIL = "RETAIL"
    static let PHARMACY_MAIL_ORDER = "MAIL_ORDER"
    
    static var logService: LogService?
    
    // MARK: - Response
    
    static func sendErrorResponse(to call: CAPPluginCall, error: Error?) {
        guard let error = error as NSError? else {
            call.reject("Error")
            return
        }
        
        logService?.log("##: SendErrorResponse: \(error.debugDescription)")
        call.reject(error.localizedDescription, String(error.code), error)
    }
    
    static func sendErrorResponse(to call: CAPPluginCall, with message: String) {
        logService?.log("##: SendErrorResponse: \(message)")
        call.reject(message)
    }
    
    static func sendValidationErrorResponse(to call: CAPPluginCall, _ error: Error?, _ message: String) {
        guard let error = error as NSError? else {
            call.reject("Error")
            return
        }
        
        if let errorDict = error.userInfo[AWSDKValidationErrorsKey] as? [String: Int] {
            let validationErrorDict = errorDict.map { (key, value) -> [String : String] in
                return [
                    Constants.ValidationError.field: key,
                    Constants.ValidationError.errorCode: String(value)
                ]
            }
            
            call.reject(message, String(error.code), error, [Constants.Error.validationErrors: validationErrorDict])
        } else {
            call.reject(message, String(error.code), error, [:])
        }
    }
    
    static func sendSuccessResponse(to call: CAPPluginCall) {
        call.resolve([
            Constants.Response.value: true
        ])
    }
    
    static func sendResponse(to call: CAPPluginCall, _ value: Any) {
        logService?.log("##: SendResponse")
        call.resolve([
            Constants.Response.value: value
        ])
    }
    
    static func sendNULLResponse(to call: CAPPluginCall) {
        logService?.log("##: SendNULLResponse")
        call.resolve([
            Constants.Response.value: NSNull()
        ])
    }
    
    static func handleResponse(for call: CAPPluginCall, _ success: Bool, _ error: Error?, alternateErrorMessage: String) {
        logService?.log("##: HandleResponse")
        if error != nil {
            ResponseHelper.sendErrorResponse(to: call, error: error)
            return
        }
        
        if success {
            logService?.log("##: HandleResponse: success")
            ResponseHelper.sendSuccessResponse(to: call)
        } else {
            ResponseHelper.sendErrorResponse(to: call, with: alternateErrorMessage)
        }
    }
    
    static func validateAndSend(_ json: Any, to call: CAPPluginCall) {
        if JSONSerialization.isValidJSONObject(json) {
            logService?.log("##: Valid JSON\n \(json)")
            ResponseHelper.sendResponse(to: call, json)
        } else {
            logService?.log("##: Error in the JSON!!:\n \(json)")
            ResponseHelper.sendErrorResponse(
                to: call,
                error: getError(for: AWSDKErrorCode.errorCodeValidationMalformedJSON)
            )
        }
    }
    
    static func getError(for code: AWSDKErrorCode) -> NSError {
        NSError(domain: "com.americanwell.awsdk.errordomain.sdk", code: code.rawValue, userInfo: [:])
    }
    
    static func getFullName(from nameComponents: NSPersonNameComponents) -> String {
        var name = ""
         
        if let prefix = nameComponents.namePrefix {
            name = prefix + " "
        }
        
        if let givenName = nameComponents.givenName {
            name += givenName + " "
        }
        
        if let middleName = nameComponents.middleName {
            name += middleName + " "
        }
        
        if let familyName = nameComponents.familyName {
            name += familyName
        }
        
        return name
    }
    
    // MARK: - Consumer
    
    static func getConsumerJSON(from consumer: AWSDKConsumer) -> Dictionary<String, Any> {
        var consumerJson = [String: Any]()
        consumerJson[Constants.Consumer.fullName] = ResponseHelper.getFullName(from: consumer.nameComponents as NSPersonNameComponents)
        consumerJson[Constants.Consumer.isDependent] = consumer.isDependent()
        consumerJson[Constants.Consumer.sourceID] = consumer.sourceId ?? ""
        consumerJson[Constants.Consumer.sdkUserID] = consumer.sdkUserId ?? ""
        consumerJson[Constants.Consumer.stateOfLegalResidence] = consumer.stateOfLegalResidence.code
        consumerJson[Constants.Consumer.countryOfLegalResidence] = consumer.stateOfLegalResidence.country.code
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm'Z'"
        consumerJson[Constants.Consumer.dateOfBirth] = dateFormatter.string(from: consumer.dateOfBirth)
        consumerJson[Constants.Consumer.isAppointmentReminderTextsEnabled] = consumer.appointmentReminderTextsEnabled
        consumerJson[Constants.Consumer.phoneNumber] = consumer.phoneNumber
        return consumerJson
    }
    
    static func getAllergyJSON(_ allergies: [AWSDKAllergy]) -> [Dictionary<String, Any>] {
        var allergyJSON = [Dictionary<String, Any>]()
        
        for allergy in allergies {
            allergyJSON.append([
                Constants.Allergy.name: allergy.displayName,
                Constants.Allergy.isCurrent: allergy.isCurrent
            ])
        }
        
        return allergyJSON
    }
    
    static func getConditionJSON(_ conditions: [AWSDKCondition]) -> [Dictionary<String, Any>] {
        var conditionsJSON = [Dictionary<String, Any>]()
        
        for condition in conditions {
            conditionsJSON.append([
                Constants.Condition.name: condition.displayName,
                Constants.Condition.isCurrent: condition.isCurrent
            ])
        }
        
        return conditionsJSON
    }
    
    static func getVitalsJSON(_ vitals: AWSDKConsumerVitals) -> Dictionary<String, Any> {
        var vitalsJSON = Dictionary<String, Any>()
        
        if let diastolic = vitals.diastolicBloodPressure,
              let systolic = vitals.systolicBloodPressure,
              let temperature = vitals.temperature
        {
            vitalsJSON[Constants.Vitals.bloodPressureDiastolic] = String(Int(diastolic.value))
            vitalsJSON[Constants.Vitals.bloodPressureSystolic] = String(Int(systolic.value))
            vitalsJSON[Constants.Vitals.temperature] = String(temperature.value)
        }
        
        if let weightMajor = vitals.weightMajor,
           let weightMinor = vitals.weightMinor {
            vitalsJSON[Constants.Vitals.weightMajor] = weightMajor.value
            vitalsJSON[Constants.Vitals.weightMinor] = weightMinor.value
        }
        
        if let heightMajor = vitals.heightMajor,
           let heightMinor = vitals.heightMinor
        {
            vitalsJSON[Constants.Vitals.heightMajor] = heightMajor.value
            vitalsJSON[Constants.Vitals.heightMinor] = heightMinor.value
        }

        return vitalsJSON
    }
    
    
    static func getMedicationJSON(_ medications: [AWSDKMedication]) -> [Dictionary<String, Any>] {
        var medicationJSON = [Dictionary<String, Any>]()
        
        for medication in medications {
            medicationJSON.append([
                Constants.Medication.name: medication.displayName,
                Constants.Medication.description: medication.description
            ])
        }
        
        return medicationJSON
    }
    
    static func getHealthDocumentJSON(_ documents: [AWSDKHealthDocument]) ->
        (json:[Dictionary<String, Any>], documentDict: Dictionary<String, AWSDKHealthDocument>)
    {
        var documentsJSON = [Dictionary<String, Any>]()
        var healthDocuments = Dictionary<String, AWSDKHealthDocument>()
        
        let dateFormatter = ISO8601DateFormatter()
        
        for document in documents {
            var sourceID = document.sourceId ?? UUID().uuidString
            if sourceID == "-1" {
                sourceID = UUID().uuidString
            }
            documentsJSON.append([
                Constants.HealthDocument.name: document.name,
                Constants.HealthDocument.sourceId: sourceID,
                Constants.HealthDocument.uploadedAt: dateFormatter.string(from: document.uploadDate)
            ])
            healthDocuments[sourceID] = document
        }
        
        return (json:documentsJSON, documentDict:healthDocuments)
    }
    
    static func getPaymentMethodJSON(_ payment: AWSDKPaymentMethod) -> Dictionary<String, Any> {
        var paymentJSON = Dictionary<String, Any>()
        
        paymentJSON[Constants.PaymentMethod.billingAddress] = getAddressJSON(for: payment.billingAddress)
        paymentJSON[Constants.PaymentMethod.billingName] = payment.billingName
        paymentJSON[Constants.PaymentMethod.cardTypeCode] = payment.cardType
        paymentJSON[Constants.PaymentMethod.expirationMonth] = payment.expirationMonth
        paymentJSON[Constants.PaymentMethod.expirationYear] = payment.expirationYear
        paymentJSON[Constants.PaymentMethod.lastDigits] = payment.lastFourDigits
        paymentJSON[Constants.PaymentMethod.isExpired] = payment.isExpired
        
        return paymentJSON
    }
    
    // MARK: - Practice
    
    static func getPracticeJSON(from practices: [AWSDKPractice]) -> [Any] {
        var jsonArray = [Any]()
        for practice in practices {
            var jsonPractice = Dictionary<String, Any>()
            jsonPractice[Constants.Practice.practiceID] = "test-id"
            jsonPractice[Constants.Practice.name] = practice.name
            jsonPractice[Constants.Practice.subtitle] = practice.subtitle
            jsonPractice[Constants.Practice.sourceID] = practice.sourceId
            jsonPractice[Constants.Practice.welcomeMessage] = practice.welcomeMessage ?? NSNull()
            jsonPractice[Constants.Practice.hasOnDemandSpecialities] = practice.hasOnDemandSpecialties
            
            jsonArray.append(jsonPractice)
        }
        
        return jsonArray
    }
    
    // MARK: - Provider
    
    static func getProviderJSON(from provider: AWSDKProvider, isDetail: Bool) -> [String: Any] {
        var providerDict = [String: Any]()
        let availability: String
        switch provider.availability {
        case .Offline:
            availability = "OFFLINE"
        case .OnCall:
            availability = "ON_CALL"
        case .VideoAvailable:
            availability = "VIDEO_AVAILABLE"
        case .VideoBusy:
            availability = "VIDEO_BUSY"
        default:
            availability = "UNKNOWN"
        }
        providerDict[Constants.Provider.fullName] = ResponseHelper.getFullName(from: provider.nameComponents as NSPersonNameComponents)
        providerDict[Constants.Provider.providerID] = "test-id"
        providerDict[Constants.Provider.sourceID] = provider.sourceID
        providerDict[Constants.Provider.imageURL] = provider.imageUrl?.absoluteString
        providerDict[Constants.Provider.rating] = provider.rating
        providerDict[Constants.Provider.specialty] = [Constants.Provider.name: provider.specialty.name]
        providerDict[Constants.Provider.waitingRoomCount] = provider.waitingRoomCount
        providerDict[Constants.Provider.availability] = availability
        
        if isDetail {
            if let year = Int(provider.graduatingYear) {
                providerDict[Constants.ProviderDetails.graduatingYear] = NSNumber(value: year)
            } else {
                providerDict[Constants.ProviderDetails.graduatingYear] = NSNull()
            }
            
            providerDict[Constants.ProviderDetails.greeting] = provider.greeting
            providerDict[Constants.ProviderDetails.languagesSpoken] = getLanguagesJSON(provider.languagesSpoken)
            providerDict[Constants.ProviderDetails.schoolName] = provider.schoolName
            providerDict[Constants.ProviderDetails.yearsExperience] = provider.yearsExperience
        }
        
        return providerDict
    }
    
    static func getLanguagesJSON(_ languages: [AWSDKLanguage]) ->  [Dictionary<String, Any>] {
        var languagesJSON = [Dictionary<String, Any>]()
        languagesJSON = languages.map { [Constants.Language.name: $0.name] }
        
        return languagesJSON
    }
    
    // MARK: - Visit Context
    
    static func getVisitContextJSON(for consumer: AWSDKConsumer?, from visitContext: AWSDKVisitContext) ->
        (json:Dictionary<String, Any>, legalText:Dictionary<String, AWSDKLegalText>)?
    {
        guard let consumer = consumer else { return nil }
        
        var visitContextDict = Dictionary<String, Any>()
        
        if let provider = visitContext.provider {
            visitContextDict[Constants.VisitContext.providerName] =
                getFullName(from: provider.nameComponents as NSPersonNameComponents)
        } else {
            visitContextDict[Constants.VisitContext.providerName] = NSNull()
        }
        visitContextDict[Constants.VisitContext.consumerSourceID] = consumer.sourceId
        visitContextDict[Constants.VisitContext.guestEmails] = [] // this cannot be pre-populated
        visitContextDict[Constants.VisitContext.callbackNumber] = visitContext.callbackNumber ?? consumer.formattedPhoneNumber
        visitContextDict[Constants.VisitContext.topics] = getVisitTopicJSON(from: visitContext.visitTopics)
        visitContextDict[Constants.VisitContext.otherTopicText] = "" // this cannot be pre-populated
        visitContextDict[Constants.VisitContext.shouldShowTriageQuestions] = visitContext.showTriageQuestions
        visitContextDict[Constants.VisitContext.shouldCollectConditions] = visitContext.showConditionsQuestion
        visitContextDict[Constants.VisitContext.shouldCollectAllergies] = visitContext.showAllergiesQuestion
        visitContextDict[Constants.VisitContext.shouldCollectMedications] = visitContext.showMedicationsQuestion
        visitContextDict[Constants.VisitContext.shouldCollectVitals] = visitContext.showVitalsQuestion
        visitContextDict[Constants.VisitContext.mayShareHealthHistory] = visitContext.shareHealthHistory
        visitContextDict[Constants.VisitContext.isFirstAvailableVisit] = (visitContext.specialty != nil)
        
        var triageArray = [Dictionary<String, Any>]()
        for triage in visitContext.triageQuestions {
            triageArray.append([
                Constants.VisitTriage.question: triage.question,
                Constants.VisitTriage.response: triage.response ?? ""
            ])
        }
        
        visitContextDict[Constants.VisitContext.triageQuestions] = triageArray
        var legalTexts = [Dictionary<String, Any>]()
        var legalTextCache = Dictionary<String, AWSDKLegalText>()
        
        // per Amwell, we need to send only the first legal text
        let finalLegalText: [AWSDKLegalText] = [visitContext.legalText[0]]
        for text in  finalLegalText {
            let uuid = UUID().uuidString
            legalTexts.append([
                Constants.LegalText.textID: uuid,
                Constants.LegalText.entityType: text.type.rawValue,
                Constants.LegalText.isRequired: text.required,
                Constants.LegalText.isAccepted: false,
                Constants.LegalText.title: text.name
            ])
            
            legalTextCache[uuid] = text
        }
        visitContextDict[Constants.VisitContext.legalText] = legalTexts
        
        return (json: visitContextDict, legalText: legalTextCache)
    }
    
    static func getVisitTopicJSON(from topics: [AWSDKVisitTopic]?) -> [Dictionary<String, Any>] {
        var topicsArray = [Dictionary<String, Any>]()
        
        guard let topics = topics else { return topicsArray }
        
        topics.forEach { topic in
            topicsArray.append(
                [Constants.VisitTopic.title: topic.title ?? "",
                Constants.VisitTopic.description: topic.description,
                Constants.VisitTopic.isSelected: topic.selected]
            )
        }
        
        return topicsArray
    }
    
    // MARK: - Pharmacy
    
    static func getPharmacyJSON(_ pharmacies: [AWSDKPharmacy]) ->
        (json: [Dictionary<String, Any>], pharmacies: Dictionary<String, AWSDKPharmacy>)
    {
        var pharmacyJSON = [Dictionary<String, Any>]()
        var pharmacyDict = Dictionary<String, AWSDKPharmacy>()
        
        
        for pharmacy in pharmacies {
            let pharmacyID = UUID().uuidString
            pharmacyDict[pharmacyID] = pharmacy
            pharmacyJSON.append([
                Constants.Pharmacy.pharmacyID: pharmacyID,
                Constants.Pharmacy.distance: pharmacy.distance?.doubleValue ?? 0.0,
                Constants.Pharmacy.name: pharmacy.name,
                Constants.Pharmacy.type: pharmacy.isMailOrder ? PHARMACY_MAIL_ORDER : PHARMACY_RETAIL,
                Constants.Pharmacy.formattedPhone: pharmacy.formattedPhoneNumber,
                Constants.Pharmacy.address: getAddressJSON(for: pharmacy.address) ?? NSNull(),
                Constants.Pharmacy.formattedFax: pharmacy.formattedFaxNumber,
                Constants.Pharmacy.email: pharmacy.contactEmail
            ])
        }
        
        return (json: pharmacyJSON, pharmacies: pharmacyDict)
    }
    
    static func getAddressJSON(for address: AWSDKAddressProtocol?) -> [String: Any]? {
        guard let address = address,
              let state = address.state,
              let country = address.country
        else {
            return nil
        }
        let addressJSON = [
            Constants.Address.address1: address.addressOne ?? "",
            Constants.Address.address2: address.addressTwo ?? "",
            Constants.Address.city: address.city ?? "",
            Constants.Address.zipCode: address.zip ?? "",
            Constants.Address.stateCode: state.code,
            Constants.Address.countryCode: country.code
        ]
        
        return addressJSON
    }
    
    static func getStatesJSON(_ states: [AWSDKState], for country: AWSDKCountry) -> [Dictionary<String, Any>] {
        var statesJSON = [Dictionary<String, Any>]()
        states.forEach { state in
            statesJSON.append([
                Constants.State.code: state.code,
                Constants.State.name: state.name,
                Constants.State.country: [
                    Constants.Country.name: state.country.name,
                    Constants.Country.code: state.country.code
                ]
            ])
        }
        
        return statesJSON
    }
    
    static func getCountryJSON(_ countries: [AWSDKCountry]) -> [Dictionary<String, Any>] {
        var countriesJSON = [Dictionary<String, Any>]()
        for country in countries {
            countriesJSON.append([
                Constants.Country.name: country.name,
                Constants.Country.code: country.code
            ])
        }
        
        return countriesJSON
    }
    
    // MARK: - Visit
    
    static func getVisitJSON(_ visit: AWSDKVisit) -> [String: Any] {
        var visitJSON = [String: Any]()
        
        visitJSON[Constants.Visit.sourceID] = visit.sourceId
        visitJSON[Constants.Visit.requiresPaymentMethod] = !visit.cost.isFree()
        visitJSON[Constants.Visit.cost] = getCostJSON(visit.cost)
        visitJSON[Constants.Visit.provider] = getProviderJSON(from: visit.provider, isDetail: false)
        visitJSON[Constants.Visit.patientsAheadCount] = visit.patientsAheadOfConsumer
        
        return visitJSON
    }
    
    static func getCostJSON(_ cost: AWSDKCost) -> [String: Any] {
        var costJSON = [String: Any]()
        
        costJSON[Constants.Cost.canApplyCouponCode] = cost.canApplyCouponCode
        costJSON[Constants.Cost.couponCode] = cost.couponCode ?? NSNull()
        costJSON[Constants.Cost.deferredBillingText] = cost.deferredBillingText
        costJSON[Constants.Cost.deferredBillingWrapUpText] = cost.deferredBillingWrapUpText
        costJSON[Constants.Cost.expectedConsumerCopayCost] = Double(cost.expectedCopay)
        costJSON[Constants.Cost.extensionCost] = Double(cost.extensionCost)
        costJSON[Constants.Cost.paymentMessage] = cost.paymentMessage
        costJSON[Constants.Cost.proposedCouponCode] = cost.proposedCouponCode
        costJSON[Constants.Cost.hasCostChangedWithVisitTransfer] = cost.hasCostChangedWithVisitTransfer
        costJSON[Constants.Cost.isDeferredBillingInEffect] = cost.isBillingDeferred
        costJSON[Constants.Cost.isFree] = cost.isFree()
        
        return costJSON
    }
    
    static func getTransferJSON(_ transfer: AWSDKVisitTransfer) -> [String: Any] {
        var transerJSON = [String: Any]()
        
        transerJSON[Constants.Transfer.provider] = getProviderJSON(from: transfer.provider, isDetail: false)
        transerJSON[Constants.Transfer.quickTransferSupported] = transfer.quickTransferSupported
        return transerJSON
    }
    
    static func getVisitSummaryJSON(_ visitSummary: AWSDKVisitSummary) -> [String: Any] {
        var summaryJSON = [String: Any]()
        
        summaryJSON[Constants.VisitSummary.consumer] = getConsumerJSON(from: visitSummary.consumer)
        summaryJSON[Constants.VisitSummary.practiceName] = visitSummary.providerPractice
        summaryJSON[Constants.VisitSummary.providerFullName] = visitSummary.providerFullName()
        summaryJSON[Constants.VisitSummary.providerFirstName] = visitSummary.providerFirstName
        summaryJSON[Constants.VisitSummary.providerMiddleInitial] = visitSummary.providerMiddleInitial ?? ""
        summaryJSON[Constants.VisitSummary.providerLastName] = visitSummary.providerLastName
        summaryJSON[Constants.VisitSummary.providerSpecialty] =
            [Constants.ProviderType.name: visitSummary.providerSpecialty.name]
        summaryJSON[Constants.VisitSummary.providerNotes] = visitSummary.providerNotes ?? ""
        summaryJSON[Constants.VisitSummary.shippingAddress] = getAddressJSON(for: visitSummary.shippingAddress) ?? NSNull()
        
        if let pharmacy = visitSummary.pharmacy {
            summaryJSON[Constants.VisitSummary.pharmacy] = getPharmacyJSON([pharmacy]).json[0]
        } else {
            summaryJSON[Constants.VisitSummary.pharmacy] = NSNull()
        }
        
        summaryJSON[Constants.VisitSummary.diagnoses] = getDiagnosisJSON(visitSummary.diagnoses)
        summaryJSON[Constants.VisitSummary.procedures] = getProcedureJSON(visitSummary.procedures)
        summaryJSON[Constants.VisitSummary.hipaaNoticeText] = visitSummary.hipaaNoticeText
        summaryJSON[Constants.VisitSummary.additionalHipaaNoticeText] = visitSummary.additionalHipaaNoticeText
        summaryJSON[Constants.VisitSummary.feedbackQuestion] = getFeedbackQuestionJSON(visitSummary.feedbackQuestion)

        return summaryJSON
    }
    
    static func getDiagnosisJSON(_ diagnoses: [AWSDKVisitDiagnosis]) -> [Dictionary<String, Any>] {
        var diagnosisJSON = [Dictionary<String, Any>]()
        
        diagnoses.forEach { diagnosis in
            diagnosisJSON.append([
                Constants.VisitDiagnosis.displayName: diagnosis.displayName,
                Constants.VisitDiagnosis.description: diagnosis.diagnosisDescription,
                Constants.VisitDiagnosis.code: diagnosis.code // Int
            ])
        }
        
        return diagnosisJSON
    }
    
    static func getProcedureJSON(_ procedures: [AWSDKVisitProcedure]) -> [Dictionary<String, Any>] {
        var proceduresJSON = [Dictionary<String, Any>]()
        
        procedures.forEach { procedure in
            proceduresJSON.append([
                Constants.VisitProcedure.displayName: procedure.displayName,
                Constants.VisitProcedure.description: procedure.procedureDescription,
                Constants.VisitProcedure.code: procedure.code, // Int
                Constants.VisitProcedure.isBillable: procedure.billable
            ])
        }
        
        return proceduresJSON
    }
    
    static func getFeedbackQuestionJSON(_ feedbackQuestion: AWSDKFeedbackQuestion?) -> [String: Any] {
        var feedbackJSON = [String: Any]()
        
        if let feedbackQuestion = feedbackQuestion {
            feedbackJSON[Constants.VisitFeedbackQuestion.question] = feedbackQuestion.questionText
            feedbackJSON[Constants.VisitFeedbackQuestion.responseOptions] = feedbackQuestion.responseOptions
            feedbackJSON[Constants.VisitFeedbackQuestion.shouldShow] = true
        } else {
            feedbackJSON[Constants.VisitFeedbackQuestion.question] = ""
            feedbackJSON[Constants.VisitFeedbackQuestion.responseOptions] = []
            feedbackJSON[Constants.VisitFeedbackQuestion.shouldShow] = false
        }
        
        return feedbackJSON
    }
    
    // MARK: - Appointment
    
    static func getAppointmentScheduleJSON(from schedule: AWSDKSchedule) -> [String: Any] {
        var scheduleJSON = [String: Any]()
        
        scheduleJSON[Constants.VisitSchedule.visitDuration] = schedule.duration?.intValue
        scheduleJSON[Constants.VisitSchedule.allottedVisitDuration] = schedule.allotedDuration?.intValue
        if let cancelTime = schedule.cancelTime {
            scheduleJSON[Constants.VisitSchedule.canceledAt] = DateUtil.utcDateString(from: cancelTime)
        } else {
            scheduleJSON[Constants.VisitSchedule.canceledAt] = NSNull()
        }
        
        if let scheduledStartTime = schedule.scheduledStartTime {
            scheduleJSON[Constants.VisitSchedule.scheduledToStartAt] = DateUtil.utcDateString(from: scheduledStartTime)
        }
        
        if let startTime = schedule.startTime {
            scheduleJSON[Constants.VisitSchedule.startedAt] = DateUtil.utcDateString(from: startTime)
        } else {
            scheduleJSON[Constants.VisitSchedule.startedAt] = NSNull()
        }
        
        return scheduleJSON
    }
    
    static func getAppointmentJSON(_ appointment: AWSDKAppointmentProtocol, _ sourceID: String) -> [String: Any] {
        var appointmentJSON = [String: Any]()
        
        if let provider = appointment.provider {
            appointmentJSON[Constants.Appointment.provider] = getProviderJSON(from: provider, isDetail: true)
        } else {
            appointmentJSON[Constants.Appointment.provider] = NSNull()
        }
        
        appointmentJSON[Constants.Appointment.consumer] = getConsumerJSON(from: appointment.consumer)
        appointmentJSON[Constants.Appointment.practiceName] = appointment.practiceName
        appointmentJSON[Constants.Appointment.sourceID] = appointment.sourceId != nil ? appointment.sourceId : sourceID
        appointmentJSON[Constants.Appointment.checkInStatus] = appointment.status.stringValue()
        appointmentJSON[Constants.Appointment.noteToPatient] = appointment.note != nil ? appointment.note : NSNull()
        appointmentJSON[Constants.Appointment.topics] = getVisitTopicJSON(from: appointment.topic)
        appointmentJSON[Constants.Appointment.schedule] = getAppointmentScheduleJSON(from: appointment.schedule)
        appointmentJSON[Constants.Appointment.disposition] = appointment.disposition.stringValue()
        
        return appointmentJSON
    }
    
    static func sendReminderOptions(_ call: CAPPluginCall) {
        let reminderOptions = AWSDKAppointment.availableReminderOptions
        var optionsJSON = [Dictionary<String, Any>]()
        reminderOptions.forEach { reminderOption in
            optionsJSON.append([
                Constants.ReminderOption.label: reminderOption.label,
                Constants.ReminderOption.minutes: reminderOption.minutes
            ])
        }
        
        validateAndSend(optionsJSON, to: call)
    }
    
    // MARK: - Message Center
    
    static func getFolderMessagesJSON(
        _ messages: [AWSDKMessage],
        _ type: String) -> (json: [Dictionary<String, Any>], messages: Dictionary<String, AWSDKMessage>)
    {
        var messagesJSON = [Dictionary<String, Any>]()
        var messagesDictionary = Dictionary<String, AWSDKMessage>()
        
        messages.forEach { message in
            guard let sentDate = DateUtil.utcDateString(from: message.sent) else { return }
            let messageID = UUID().uuidString
            var messageDict: [String: Any] = [
                Constants.MessageInfo.messageID: messageID,
                Constants.MessageInfo.type: type,
                Constants.MessageInfo.senderName: message.senderName,
                Constants.MessageInfo.subject: message.subject,
                Constants.MessageInfo.topic: [Constants.MessageTopic.name: message.topic.name],
                Constants.MessageInfo.sentAt: sentDate,
                Constants.MessageInfo.bodyPreview: message.bodyPreview,
                Constants.MessageInfo.hasAttachment: message.hasAttachment,
                Constants.MessageInfo.recipientNames: message.recipients
            ]
            
            if type == TelehealthMailboxType.inbox.rawValue,
               let inboxMessage = message as? AWSDKInboxMessage
            {
                messageDict[Constants.InboxMessage.isReplied] = inboxMessage.isReplied
                messageDict[Constants.InboxMessage.isSystemNotification] = inboxMessage.isSystemNotification
                messageDict[Constants.InboxMessage.isUnread] = inboxMessage.isUnread
            }
            
            messagesJSON.append(messageDict)
            messagesDictionary[messageID] = message
        }
        
        return (json: messagesJSON, messages: messagesDictionary)
    }
    
    static func getInboxFolderJSON(
        _ messageFolder: AWSDKMessageFolderInbox) -> (json: [String: Any], messages: Dictionary<String, AWSDKMessage>)
    {
        var folderJSON = [String: Any]()
        
        let response = getFolderMessagesJSON(messageFolder.messages, TelehealthMailboxType.inbox.rawValue)
        folderJSON[Constants.Mailbox.type] = TelehealthMailboxType.inbox.rawValue
        folderJSON[Constants.Mailbox.updatedAt] = DateUtil.ISODateString(from: messageFolder.lastUpdated)
        folderJSON[Constants.Mailbox.messages] = response.json
        folderJSON[Constants.InboxFolder.unreadCount] = messageFolder.unread
        
        return (json: folderJSON, messages: response.messages)
    }
    
    static func getSentFolderJSON(
        _ messageFolder: AWSDKMessageFolderSent) -> (json: [String: Any], messages: Dictionary<String, AWSDKMessage>)
    {
        var folderJSON = [String: Any]()
        
        let response = getFolderMessagesJSON(messageFolder.messages, TelehealthMailboxType.sent.rawValue)
        folderJSON[Constants.Mailbox.type] = TelehealthMailboxType.sent.rawValue
        folderJSON[Constants.Mailbox.updatedAt] = DateUtil.ISODateString(from: messageFolder.lastUpdated)
        folderJSON[Constants.Mailbox.messages] = response.json
        
        return (json: folderJSON, messages: response.messages)
    }
    
    static func getMessageInfoJSON(_ message: AWSDKMessage, _ type: String) -> [String: Any] {
        var messageJSON = [String: Any]()
        
        guard let sentDate = DateUtil.utcDateString(from: message.sent) else {
            return messageJSON
        }
        
        messageJSON[Constants.MessageInfo.type] = type
        messageJSON[Constants.MessageInfo.senderName] = message.senderName
        messageJSON[Constants.MessageInfo.subject] = message.subject
        messageJSON[Constants.MessageInfo.topic] = [Constants.MessageTopic.name: message.topic.name]
        messageJSON[Constants.MessageInfo.sentAt] = sentDate
        messageJSON[Constants.MessageInfo.bodyPreview] = message.bodyPreview
        messageJSON[Constants.MessageInfo.hasAttachment] = message.hasAttachment
        messageJSON[Constants.MessageInfo.recipientNames] = message.recipients
        
        return messageJSON
    }
    
    static func getInboxMessageDetailJSON(
        _ message: AWSDKInboxMessageDetails,
        _ messageID: String) -> (json:[String: Any], info: [String: AWSDKAttachment])
    {
        var messageJSON = [String: Any]()
        
        guard let sentDate = DateUtil.utcDateString(from: message.sent) else {
            return (json: messageJSON, info: [String: AWSDKAttachment]())
        }
        
        let attachmentResponse = getMessageAttachmentsJSON(message.attachments)
        messageJSON[Constants.Message.messageID] = messageID
        messageJSON[Constants.Message.body] = message.messageBody
        messageJSON[Constants.Message.canReply] = message.canReply
        messageJSON[Constants.Message.attachments] = attachmentResponse.json
        messageJSON[Constants.Message.messageType] = TelehealthMailboxType.inbox.rawValue
        messageJSON[Constants.Message.senderName] = message.senderName
        messageJSON[Constants.Message.subject] = message.subject
        messageJSON[Constants.Message.topic] = [Constants.MessageTopic.name: message.topic.name]
        messageJSON[Constants.Message.sentAt] = sentDate
        messageJSON[Constants.Message.recipientNames] = message.recipients
        messageJSON[Constants.InboxMessage.isReplied] = message.isReplied
        messageJSON[Constants.InboxMessage.isSystemNotification] = message.isSystemNotification
        messageJSON[Constants.InboxMessage.isUnread] = message.isUnread
        
        return (json: messageJSON, info: attachmentResponse.info)
    }
    
    static func getSentMessageDetailJSON(
        _ message: AWSDKSentMessageDetails,
        _ messageID: String) -> (json:[String: Any], info: [String: AWSDKAttachment])
    {
        var messageJSON = [String: Any]()
        guard let sentDate = DateUtil.utcDateString(from: message.sent) else {
            return (json: messageJSON, info: [String: AWSDKAttachment]())
        }
        
        let attachmentResponse = getMessageAttachmentsJSON(message.attachments)
        messageJSON[Constants.Message.messageID] = messageID
        messageJSON[Constants.Message.body] = message.messageBody
        messageJSON[Constants.Message.canReply] = message.canReply
        messageJSON[Constants.Message.attachments] = attachmentResponse.json
        messageJSON[Constants.Message.messageType] = TelehealthMailboxType.sent.rawValue
        messageJSON[Constants.Message.senderName] = message.senderName
        messageJSON[Constants.Message.subject] = message.subject
        messageJSON[Constants.Message.topic] = [Constants.MessageTopic.name: message.topic.name]
        messageJSON[Constants.Message.sentAt] = sentDate
        messageJSON[Constants.Message.recipientNames] = message.allRecipients.map({ $0.name })
        
        return (json: messageJSON, info: attachmentResponse.info)
    }
    
    static func getMessageAttachmentsJSON(
        _ attachments: [AWSDKAttachment]) -> (json:[Dictionary<String, Any>], info: [String: AWSDKAttachment])
    {
        var attachmentsJSON = [Dictionary<String, Any>]()
        var attachmentInfo = [String: AWSDKAttachment]()
        
        attachments.forEach { attachment in
            let uuid = UUID().uuidString
            attachmentsJSON.append([
                Constants.MessageAttachment.attachmentID: uuid,
                Constants.MessageAttachment.name: attachment.name,
                Constants.MessageAttachment.size: attachment.size,
                Constants.MessageAttachment.mimeType: attachment.type
            ])
            
            attachmentInfo[uuid] = attachment
        }
        
        return (json: attachmentsJSON, info: attachmentInfo)
    }
    
    static func getMessageTopicJSON(for messageTopics: [AWSDKMessageTopicProtocol]) -> [Dictionary<String, Any>] {
        var topicsJSON = [Dictionary<String, Any>]()
        
        messageTopics.forEach { topic in
            topicsJSON.append([
                Constants.MessageTopic.name: topic.name
            ])
        }
        
        return topicsJSON
    }
    
    static func getMessageContacts(
        _ contacts: [AWSDKContact]) -> (json: [Dictionary<String, Any>], info: [String: AWSDKContact])
    {
        var contactsJSON = [Dictionary<String, Any>]()
        var contactsInfo = [String: AWSDKContact]()
        
        contacts.forEach { contact in
            let uuid = UUID().uuidString
            contactsJSON.append([
                Constants.MessageContact.name: contact.name,
                Constants.MessageContact.contactID: uuid
            ])
            
            contactsInfo[uuid] = contact
        }
        
        return (json: contactsJSON, info: contactsInfo)
    }
    
    static func getMessageDraftJSON(
        _ draft: AWSDKMessageDraftProtocol,
        draftType: String) -> (json:[String: Any], info: [String: AWSDKMessageDraftProtocol])
    {
        var draftJSON = [String: Any]()
        var draftInfo = [String: AWSDKMessageDraftProtocol]()
        
        let uuid = UUID().uuidString
        draftJSON[Constants.MessageDraft.draftID] = uuid
        draftJSON[Constants.MessageDraft.type] = draftType
        if let topic = draft.topic {
            draftJSON[Constants.MessageDraft.topic] = [Constants.MessageTopic.name: topic.name]
        } else {
            draftJSON[Constants.MessageDraft.topic] = NSNull()
        }
        
        draftJSON[Constants.MessageDraft.subject] = draft.subject ?? NSNull()
        draftJSON[Constants.MessageDraft.body] = draft.messageBody ?? NSNull()
        if let contact = draft.recipient {
            draftJSON[Constants.MessageDraft.recipient] = [
                Constants.MessageContact.contactID: UUID().uuidString,
                Constants.MessageContact.name: contact.name
            ]
        } else {
            draftJSON[Constants.MessageDraft.recipient] = NSNull()
        }
        draftInfo[uuid] = draft
        
        return (json:draftJSON, info: draftInfo)
    }
}

extension AWSDKAppointmentStatus {
    func stringValue() -> String {
        switch self {
        case .Early: return AppointmentCheckInStatus.early.rawValue
        case .Late: return AppointmentCheckInStatus.late.rawValue
        case .NoProvider: return AppointmentCheckInStatus.noProvider.rawValue
        case .OnTime: return AppointmentCheckInStatus.onTime.rawValue
        case .Other: return AppointmentCheckInStatus.other.rawValue
        @unknown default:
            return AppointmentCheckInStatus.other.rawValue
        }
    }
}

extension AWSDKVisitDisposition {
    func stringValue() -> String {
        switch self {
        case .completed:
            return VisitDisposition.completed.rawValue
        case .consultingProviderWrappedUp:
            return VisitDisposition.consultingProviderWrappedUp.rawValue
        case .consumerCanceled: return VisitDisposition.consumerCancelled.rawValue
        case .consumerDisconnected: return VisitDisposition.consumerDisconnected.rawValue
        case .deleted: return VisitDisposition.deleted.rawValue
        case .error: return VisitDisposition.error.rawValue
        case .expired: return VisitDisposition.expired.rawValue
        case .inVisit: return VisitDisposition.inVisit.rawValue
        case .parked: return VisitDisposition.parked.rawValue
        case .postVisit: return VisitDisposition.postVisit.rawValue
        case .preVisit: return VisitDisposition.preVisit.rawValue
        case .providerCanceled: return VisitDisposition.providerCancelled.rawValue
        case .providerDeclined: return VisitDisposition.providerDeclined.rawValue
        case .providerDisconnected: return VisitDisposition.providerDisconnected.rawValue
        case .providerWrapUp: return VisitDisposition.providerWrapUp.rawValue
        case .consultingProviderWrappedUp: return VisitDisposition.consultingProviderWrappedUp.rawValue
        case .providerResponseTimeout: return VisitDisposition.providerResponseTimeout.rawValue
        case .scheduled: return VisitDisposition.scheduled.rawValue
        case .unpublished: return VisitDisposition.unpublished.rawValue
        case .unscheduled: return VisitDisposition.unscheduled.rawValue
        default:
            return VisitDisposition.undefined.rawValue
        }
    }
}
