//
//  Constants.swift
//  AmwellPlugin
//
//  Created by Miraj, Kusum on 2/17/21.
//

import Foundation

enum Constants {
    
    enum Initialize {
        static let apiKey = "apiKey"
        static let bundleID = "bundleId"
        static let baseServiceURL = "baseServiceUrl"
        static let launchURL = "launchUrl"
    }
    
    enum Call {
        static let consumerAuthKey = "consumerAuthKey"
        static let practiceSourceID = "practiceSourceId"
        static let consumerSourceID = "consumerSourceId"
        static let providerSourceID = "providerSourceId"
        static let searchMedication = "startingWith"
        static let allergies = "allergies"
        static let conditions = "conditions"
        static let medications = "medications"
        static let vitals = "vitals"
        static let sourceID = "sourceId"
        static let legalTextID = "legalTextId"
        static let pharmacyID = "pharmacyId"
        static let zipCode = "zipCode"
        static let countryCode = "countryCode"
        static let address = "address"
        static let visitContext = "visitContext"
        static let shouldStopSuggestions = "shouldStopSuggestions"
        static let providerRating = "providerRating"
        static let visitRating = "visitRating"
        static let faxes = "faxes"
        static let emails = "emails"
        static let isHipaaNoticeAccepted = "isHipaaNoticeAccepted"
        static let selectedOption = "selectedOption"
        static let stateCode = "stateCode"
        static let latitude = "latitude"
        static let longitude = "longitude"
        static let radius = "radius"
        static let availableOnDate = "availableOnDate"
        static let timeSlot = "timeSlot"
        static let phoneNumber = "phoneNumber"
        static let reminderOption = "reminderOption"
        static let appointmentSourceID = "appointmentSourceId"
        static let startingFromDate = "startingFromDate"
        static let date = "date"
        static let draftType = "draftType"
        static let sourceMessageID = "sourceMessageId"
        static let mailboxType = "mailboxType"
        static let startIndex = "startIndex"
        static let maxResults = "maxResults"
        static let since = "since"
        static let TelehealthMessageID = "messageId"
        static let draft = "draft"
        static let isAppointmentReminderTextsEnabled = "isAppointmentReminderTextsEnabled"
        static let messageDraftID = "messageDraftId"
        static let attachmentId = "attachmentId"
        static let guestName = "guestName"
        static let guestEmail = "guestEmail"
    }
    
    enum Consumer {
        static let fullName = "fullName"
        static let isDependent = "isDependent"
        static let sourceID = "sourceId"
        static let sdkUserID = "sdkUserId"
        static let stateOfLegalResidence = "stateOfLegalResidence"
        static let countryOfLegalResidence = "countryOfLegalResidence"
        static let dateOfBirth = "dateOfBirth"
        static let isAppointmentReminderTextsEnabled = "isAppointmentReminderTextsEnabled"
        static let phoneNumber = "phoneNumber"
    }
    
    enum Practice {
        static let practiceID = "id"
        static let name = "name"
        static let subtitle = "subtitle"
        static let sourceID = "sourceId"
        static let welcomeMessage = "welcomeMessage"
        static let hasOnDemandSpecialities = "hasOnDemandSpecialties"
    }
    
    enum Provider {
        static let name = "name"
        static let fullName = "fullName"
        static let providerID = "id"
        static let imageURL = "imageUrl"
        static let rating = "rating"
        static let sourceID = "sourceId"
        static let specialty = "specialty"
        static let waitingRoomCount = "waitingRoomCount"
        static let availability = "availability"
    }
    
    enum ProviderType {
        static let name = "name"
    }
    
    enum ProviderDetails {
        static let graduatingYear = "graduatingYear"
        static let greeting = "greeting"
        static let languagesSpoken = "languagesSpoken"
        static let schoolName = "schoolName"
        static let yearsExperience = "yearsExperience"
    }
    
    enum Matchmaking {
        static let result = "MATCHMAKING_RESULT"
    }
    
    enum MatchmakingResult {
        static let provider = "provider"
        static let isListExhausted = "isListExhausted"
        static let didRequestFail = "didRequestFail"
    }
    
    enum ScheduleAppointment {
        static let availableTimeSlots = "availableTimeSlots"
    }
    
    enum Appointment {
        static let sourceID = "sourceId"
        static let consumer = "consumer"
        static let provider = "provider"
        static let practiceName = "practiceName"
        static let schedule = "schedule"
        static let noteToPatient = "noteToPatient"
        static let topics = "topics"
        static let checkInStatus = "checkInStatus"
        static let disposition = "disposition"
    }
    
    enum Language {
        static let name = "name"
    }
    
    enum Response {
        static let value = "value"
        static let error = "error"
    }
    
    enum CreditCardTypes {
        static let type = "type"
        static let cvvLength = "cvvLength"
        static let regex = "regex"
    }
    
    enum VisitContext {
        static let consumerSourceID = "consumerSourceId"
        static let providerName = "providerName"
        static let callbackNumber = "callbackNumber"
        static let guestEmails = "guestEmails"
        static let topics = "topics"
        static let otherTopicText = "otherTopicText"
        static let shouldShowTriageQuestions = "shouldShowTriageQuestions"
        static let triageQuestions = "triageQuestions"
        static let shouldCollectAllergies = "shouldCollectAllergies"
        static let shouldCollectConditions = "shouldCollectConditions"
        static let shouldCollectMedications = "shouldCollectMedications"
        static let shouldCollectVitals = "shouldCollectVitals"
        static let legalText = "legalText"
        static let mayShareHealthHistory = "mayShareHealthHistory"
        static let isFirstAvailableVisit = "isFirstAvailableVisit"
    }
    
    enum VisitTopic {
        static let title = "title"
        static let description = "description"
        static let isSelected = "isSelected"
    }
    
    enum VisitTriage {
        static let question = "question"
        static let response = "response"
    }
    
    enum VisitSchedule {
        static let startedAt = "startedAt"
        static let canceledAt = "canceledAt"
        static let visitDuration = "visitDuration"
        static let scheduledToStartAt = "scheduledToStartAt"
        static let allottedVisitDuration = "allottedVisitDuration"
    }
    
    enum Medication {
        static let name = "name"
        static let description = "description"
    }
    
    enum Allergy {
        static let name = "name"
        static let isCurrent = "isCurrent"
    }
    
    enum Condition {
        static let name = "name"
        static let isCurrent = "isCurrent"
    }
    
    enum Error {
        static let sdkNotInitialized = "SDK is not properly initialized."
        static let consumerNotRegistered = "Consumer is not fully registered."
        static let consumerNotAuthenticated = "Consumer not authenticated."
        static let validationErrors = "validationErrors"
    }
    
    enum Vitals {
        static let bloodPressureSystolic = "bloodPressureSystolic"
        static let bloodPressureDiastolic = "bloodPressureDiastolic"
        static let temperature = "temperature"
        static let weightMajor = "weightMajor"
        static let weightMinor = "weightMinor"
        static let heightMajor = "heightMajor"
        static let heightMinor = "heightMinor"
    }
    
    enum LegalText {
        static let textID = "id"
        static let entityType = "entityType"
        static let isRequired = "isRequired"
        static let isAccepted = "isAccepted"
        static let title = "title"
    }
    
    enum HealthDocument {
        static let name = "name"
        static let sourceId = "sourceId"
        static let uploadedAt = "uploadedAt"
    }
    
    enum Pharmacy {
        static let pharmacyID = "id"
        static let distance = "distance"
        static let name = "name"
        static let address = "address"
        static let type = "type"
        static let formattedPhone = "formattedPhone"
        static let formattedFax = "formattedFax"
        static let email = "email"
    }
    
    enum Address {
        static let address1 = "address1"
        static let address2 = "address2"
        static let city = "city"
        static let stateCode = "stateCode"
        static let countryCode = "countryCode"
        static let zipCode = "zipCode"
    }
    
    enum State {
        static let name = "name"
        static let code = "code"
        static let country = "country"
    }
    
    enum Country {
        static let code = "code"
        static let name = "name"
    }
    
    enum PaymentMethod {
        static let billingAddress = "billingAddress"
        static let billingName = "billingName"
        static let expirationMonth = "expirationMonth"
        static let expirationYear = "expirationYear"
        static let lastDigits = "lastDigits"
        static let cardTypeCode = "cardTypeCode"
        static let isExpired = "isExpired"
    }
    
    enum PaymentRequest {
        static let billingAddress = "billingAddress"
        static let billingName = "billingName"
        static let expirationMonth = "expirationMonth"
        static let expirationYear = "expirationYear"
        static let digits = "digits"
        static let securityCode = "securityCode"
    }
    
    enum Visit {
        static let sourceID = "sourceId"
        static let requiresPaymentMethod = "requiresPaymentMethod"
        static let cost = "cost"
        static let patientsAheadCount = "patientsAheadCount"
        static let provider = "provider"
    }
    
    enum Cost {
        static let canApplyCouponCode = "canApplyCouponCode"
        static let couponCode = "couponCode"
        static let deferredBillingText = "deferredBillingText"
        static let deferredBillingWrapUpText = "deferredBillingWrapUpText"
        static let expectedConsumerCopayCost = "expectedConsumerCopayCost"
        static let extensionCost = "extensionCost"
        static let paymentMessage = "paymentMessage"
        static let proposedCouponCode = "proposedCouponCode"
        static let hasCostChangedWithVisitTransfer = "hasCostChangedWithVisitTransfer"
        static let isDeferredBillingInEffect = "isDeferredBillingInEffect"
        static let isFree = "isFree"
    }
    
    enum Regex {
        static let master = "^((5[1-5])|(2[2-7]))((\\d{14})|(\\d{17}))$"
        static let visa = "^((4\\d{18})|(4\\d{15})|(4\\d{12}))$"
        static let discover = "^((6011\\d{15})|(6011\\d{12})|(65\\d{14}))$"
        static let amex = "^3[47]\\d{13}$"
    }
    
    enum PluginEvent {
        static let eventType = "eventType"
        static let count = "count"
        static let transfer = "transfer"
        static let value = "value"
    }
    
    enum VisitEvent {
        static let onProviderEntered = "VISIT_PROVIDER_ENTERED"
        static let onVisitEnded = "VISIT_ENDED"
        static let onPatientsAheadCountChanged = "VISIT_PATIENTS_AHEAD_COUNT_CHANGED"
        static let onSuggestedTransfer = "VISIT_SUGGESTED_TRANSFER"
        static let onSuggestFindFirstAvailable = "VISIT_SUGGESTED_FIND_FIRST_AVAILABLE"
        static let onChat = "VISIT_CHAT"
        static let onPollFailure = "VISIT_POLL_FAILURE"
        static let onValidationFailure = "VISIT_VALIDATION_FAILURE"
        static let onResponse = "VISIT_RESPONSE"
        static let onFailure = "VISIT_FAILURE"
        static let empty = "EMPTY"
        static let conferenceStarted = "CONFERENCE_STARTED"
        static let conferenceFinished = "CONFERENCE_FINISHED"
        static let conferenceFailed = "CONFERENCE_FAILED"
    }
    
    enum VisitEndEvent {
        static let eventType = "eventType"
        static let visitEndReason = "reason"
    }
    
    enum VisitEndReason {
        static let assistantDecline = "ASSISTANT_DECLINE"
        static let assistantDeclineAndTransfer = "ASSISTANT_DECLINE_AND_TRANSFER"
        static let providerDecline = "PROVIDER_DECLINE"
        static let providerDeclineAndTransfer = "PROVIDER_DECLINE_AND_TRANSFER"
        static let waitingRoomExpired = "WAITING_ROOM_EXPIRED"
        static let initiatorLogoutPreVisit = "INITIATOR_LOGOUT_PRE_VISIT"
        static let engagementExpired = "ENGAGEMENT_EXPIRED"
        static let memberDisconnectPreThreshold = "MEMBER_DISCONNECT_PRE_THRESHOLD"
        static let memberDisconnectPostThreshold = "MEMBER_DISCONNECT_POST_THRESHOLD"
        static let memberForcedDisconnect = "MEMBER_FORCED_DISCONNECT"
        static let memberCancel = "MEMBER_CANCEL"
        static let memberIVRAuthFailed = "MEMBER_IVR_AUTH_FAILED"
        static let memberEnd = "MEMBER_END"
        static let initiatorStartAfterLogout = "INITIATOR_LOGOUT_AFTER_START"
        static let providerEnd = "PROVIDER_END"
        static let providerBail = "PROVIDER_BAIL"
        static let providerDisconnect = "PROVIDER_DISCONNECT"
        static let providerResponseTimeout = "PROVIDER_RESPONSE_TIMEOUT"
        static let providerLogout = "PROVIDER_LOGOUT"
        static let providerIVRAuthFailed = "PROVIDER_IVR_AUTH_FAILED"
        static let asyncCostCalculationException = "ASYNC_COST_CALC_EXCEPTION"
        static let memberTransfer = "MEMBER_TRANSFER"
        static let backgroundTimeLimitExceeded = "BACKGROUND_TIME_LIMIT_EXCEEDED"
        static let consumerOutdialFailed = "MEMBER_OUT_DIAL_FAILED"
        static let permissionsError = "PERMISSIONS_ERROR"
        static let postVisitTransfer = "POST_VISIT_TRANSFER"
        static let videoHostFailed = "VIDEO_HOST_FAILED"
        static let visitEnded = "VISIT_ENDED"
        static let visitExpired = "VISIT_EXPIRED"
        static let unknown = "UNKNOWN"
    }
    
    enum VisitFailureEvent {
        static let eventType = "eventType"
        static let sdkError = "sdkError"
    }
    
    enum VisitTransferResponse {
        static let newVisitContext = "newVisitContext"
        static let newVisit = "newVisit"
        static let newDeclineAndTransfer = "newDeclineAndTransfer"
        static let newSuggestedTransfer = "newSuggestedTransfer"
    }
    
    enum Transfer {
        static let provider = "provider" 
        static let quickTransferSupported = "isQuick"
    }
    
    enum SdkError {
        static let errorReason = "errorReason"
        static let csrPhoneNumber = "csrPhoneNumber"
        static let httpResponseCode = "httpResponseCode"
        static let message = "message"
        static let suggestion = "suggestion"
    }
    
    enum SdErrorSuggestion {
        static let title = "title"
        static let description = "description"
        static let suggestion = "suggestion"
        static let sdkSuggestion = "sdkSuggestion"
    }
    
    enum ValidationError {
        static let field = "field"
        static let errorCode = "errorCode"
    }
    
    enum VisitSummary {
        static let consumer = "consumer"
        static let practiceName = "practiceName"
        static let providerFirstName = "providerFirstName"
        static let providerMiddleInitial = "providerMiddleInitial"
        static let providerLastName = "providerLastName"
        static let providerFullName = "providerFullName"
        static let providerSpecialty = "providerSpecialty"
        static let providerNotes = "providerNotes"
        static let shippingAddress = "shippingAddress"
        static let pharmacy = "pharmacy"
        static let diagnoses = "diagnoses"
        static let procedures = "procedures"
        static let hipaaNoticeText = "hipaaNoticeText"
        static let additionalHipaaNoticeText = "additionalHipaaNoticeText"
        static let feedbackQuestion = "feedbackQuestion"
    }
    
    enum VisitDiagnosis {
        static let displayName = "displayName"
        static let description = "description"
        static let code = "code"
    }
    
    enum VisitProcedure {
        static let displayName = "displayName"
        static let description = "description"
        static let code = "code"
        static let isBillable = "isBillable"
    }
    
    enum VisitFeedbackQuestion {
        static let question = "question"
        static let responseOptions = "responseOptions"
        static let shouldShow = "shouldShow"
    }
    
    enum ConsumerOptions {
        static let consumerSourceID = "consumerSourceId"
    }
    
    enum LocalizedStrings {
        static let uploadDocumentTitle = "Upload Document"
        static let uploadDocumentMessage = "Pick your document source"
    }
    
    enum ReminderOption {
        static let label = "label"
        static let minutes = "minutes"
    }
    
    enum MessageDraft {
        static let draftID = "id"
        static let type = "draftType"
        static let recipient = "recipient"
        static let subject = "subject"
        static let topic = "topic"
        static let body = "body"
        static let shouldShareHealthSummary = "shouldShareHealthSummary"
    }
    
    enum MessageContact {
        static let name = "name"
        static let contactID = "id"
    }
    
    enum Mailbox {
        static let type = "mailboxType"
        static let messages = "messages"
        static let updatedAt = "updatedAt"
    }
    
    enum InboxFolder {
        static let unreadCount = "unreadCount"
    }
    
    enum Message {
        static let messageID = "id"
        static let body = "body"
        static let attachments = "attachments"
        static let canReply = "canReply"
        static let messageType = "messageType"
        static let recipientNames = "recipientNames"
        static let senderName = "senderName"
        static let sentAt = "sentAt"
        static let subject = "subject"
        static let topic = "topic"
    }
    
    enum InboxMessage {
        static let isReplied = "isReplied"
        static let isSystemNotification = "isSystemNotification"
        static let isUnread = "isUnread"
    }
    
    enum MessageInfo {
        static let messageID = "id"
        static let type = "messageType"
        static let bodyPreview = "bodyPreview"
        static let hasAttachment = "hasAttachment"
        static let senderName = "senderName"
        static let recipientNames = "recipientNames"
        static let sentAt = "sentAt"
        static let subject = "subject"
        static let topic = "topic"
    }
    
    enum MessageTopic {
        static let name = "name"
    }
    
    enum MessageAttachment {
        static let attachmentID = "id"
        static let name = "name"
        static let size = "size"
        static let mimeType = "mimeType"
    }
}

enum CreditCardTypesNames: String {
    case master = "master"
    case visa = "visa"
    case discover = "discover"
    case amex = "amex"
    case unknown = "unknown"
    
    func regex() -> String {
        switch self {
        case .master: return Constants.Regex.master
        case .visa: return Constants.Regex.visa
        case .discover: return Constants.Regex.discover
        case .amex: return Constants.Regex.amex
        case .unknown: return ""
        }
    }
}

enum AppointmentCheckInStatus: String {
    case early = "EARLY"
    case onTime = "ON_TIME"
    case late = "LATE"
    case noProvider = "NO_PROVIDER"
    case other = "OTHER"
}

enum VisitDisposition: String {
    case completed = "COMPLETED"
    case consumerCancelled = "CONSUMER_CANCELED"
    case consultingProviderWrappedUp = "CONSULTING_PROVIDER_WRAPPED_UP"
    case consumerDisconnected = "CONSUMER_DISCONNECTED"
    case deleted = "DELETED"
    case error = "ERROR"
    case expired = "EXPIRED"
    case inVisit = "IN_VISIT"
    case parked = "PARKED"
    case postVisit = "POST_VISIT"
    case preVisit = "PRE_VISIT"
    case providerCancelled = "PROVIDER_CANCELED"
    case providerDeclined = "PROVIDER_DECLINED"
    case providerDisconnected = "PROVIDER_DISCONNECTED"
    case providerResponseTimeout = "PROVIDER_RESPONSE_TIMEOUT"
    case providerWrapUp = "PROVIDER_WRAP_UP"
    case providerWrappedUp = "PROVIDER_WRAPPED_UP"
    case scheduled = "SCHEDULED"
    case undefined = "UNDEFINED"
    case unpublished = "UNPUBLISHED"
    case unscheduled = "UNSCHEDULED"
}

enum TelehealthMailboxType: String {
    case inbox = "INBOX"
    case sent = "SENT"
}

enum TelehealthMessageDraftType: String {
    case new = "NEW"
    case reply = "REPLY"
    case forward = "FORWARD"
}

enum DocumentUploadReason {
    case visit
    case mailAttachment
    case unknown
}
