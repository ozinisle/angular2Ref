//
//  VisitService.swift
//  AmwellPlugin
//
//  Created by Miraj, Kusum on 3/12/21.
//

import Foundation
import Capacitor
import AWSDK

class VisitService {
    var logService: LogService
    
    init(logService: LogService) {
        self.logService = logService
    }
    
    func createVisitContext(
        for consumer: AWSDKConsumer,
        with providers: [AWSDKProvider],
        _ dependents: [AWSDKConsumer]?,
        _ practices: [AWSDKPractice],
        _ call: CAPPluginCall,
        _ completion: @escaping (AWSDKVisitContext?, [String: AWSDKLegalText]?) -> Void)
    {
        // sourceID for dependents
        let consumerSourceID = call.getString(Constants.Call.consumerSourceID)
        // create a VisitContext intended for matchmaking
        let practiceSourceID = call.getString(Constants.Call.practiceSourceID)
        // create the default on-demand visit
        let providerSourceID = call.getString(Constants.Call.providerSourceID)
        let appointmentSourceID = call.getString(Constants.Call.appointmentSourceID)
        
        self.logService.log("##: buildVisitContext")
        self.logService.log("##: consumer: \(consumerSourceID ?? ""), practice: \(practiceSourceID ?? ""), provider: \(providerSourceID ?? "")")
        // validations
        if practiceSourceID == nil && providerSourceID == nil && appointmentSourceID == nil {
            ResponseHelper.sendErrorResponse(to: call, with: "One of [practiceSourceId, providerSourceId, appointmentSourceID] must be provided.")
            completion(nil, nil)
            return
        }
        
        if (practiceSourceID != nil && (providerSourceID != nil || appointmentSourceID != nil))
            || (providerSourceID != nil && (practiceSourceID != nil || appointmentSourceID != nil))
            || (appointmentSourceID != nil && (practiceSourceID != nil || providerSourceID != nil)) {
            ResponseHelper.sendErrorResponse(to: call, with: "Only one of [practiceSourceId, providerSourceId, appointmentSourceID] may be provided.")
            completion(nil, nil)
            return
        }
        
        var currentConsumer = consumer
        if let consumerSourceID = consumerSourceID {
            if consumerSourceID == consumer.sourceId {
                self.logService.log("##: buildVisitContext for authenticated user")
                currentConsumer = consumer
            } else {
                if let dependents = dependents,
                    let dependent = dependents.first(where: { $0.sourceId == consumerSourceID })
                {
                    self.logService.log("##: buildVisitContext for dependent")
                    currentConsumer = dependent
                }
            }
        }
        
        let currentVisitContext: (AWSDKConsumer, AWSDKVisitContextProtocol?, Error?) -> Void = { sdkConsumer, visitContext, error in
            guard error == nil
            else {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion(nil, nil)
                return
            }
            
            guard let visitContext = visitContext as? AWSDKVisitContext else {
                ResponseHelper.sendErrorResponse(
                    to: call,
                    error: ResponseHelper.getError(for: AWSDKErrorCode.errorCodeInvalidVisitContext)
                )
                completion(nil, nil)
                return
            }
            
            if let modality = visitContext.practice.availableModalities.first(where: { $0.code == .video }){
                visitContext.selectedModality = modality
            }
            
            if visitContext.selectedModality.code == .undefined {
                ResponseHelper.sendErrorResponse(to: call, with: "Practice does not support video visits.")
                completion(nil, nil)
                return
            }
            
            if let visitJson = ResponseHelper.getVisitContextJSON(for: sdkConsumer, from: visitContext) {
                ResponseHelper.validateAndSend(visitJson.json, to: call)
                completion(visitContext, visitJson.legalText)
            }
        }
        
        // When practiceSourceId is provided, build a VisitContext for matchmaking.
        if practiceSourceID != nil {
            if let practice = practices.first(where: { $0.sourceId == practiceSourceID }) {
                if !practice.hasOnDemandSpecialties {
                    ResponseHelper.sendErrorResponse(to: call, with: "Practice does not support on-demand visits.")
                    completion(nil, nil)
                    return
                }
                
                practice.fetchSpecialties(for: currentConsumer) { onDemandSpecialties, error in
                    if error != nil {
                        ResponseHelper.sendErrorResponse(to: call, error: error)
                        completion(nil, nil)
                        return
                    }
                    
                    guard let specialties = onDemandSpecialties,
                          specialties.count > 0
                    else {
                        ResponseHelper.sendErrorResponse(to: call, with: "Consumer doesn't have access to any specialty")
                        completion(nil, nil)
                        return
                    }
                    
                    // We need only the first specialty to create the visit context
                    if currentConsumer.isDependent(), currentConsumer.authenticatedParent?.sourceId == consumer.sourceId {
                        AWSDKVisitContext.createVisitContext(
                            forDependent: currentConsumer,
                            parent: consumer,
                            specialty: specialties[0]
                        ) { visitContext, error in
                            currentVisitContext(currentConsumer, visitContext, error)
                        }
                    } else {
                        AWSDKVisitContext.createVisitContext(for: currentConsumer, specialty: specialties[0]) { visitContext, error in
                            currentVisitContext(currentConsumer, visitContext, error)
                        }
                    }
                }
                
            } else {
                ResponseHelper.sendErrorResponse(to: call, with: "Practice not found in cache.")
                completion(nil, nil)
                return
            }
        } else if providerSourceID != nil {
            let providerMatched = providers.first(where: { $0.sourceID == providerSourceID })
            
            guard let provider = providerMatched else { return }
            
            // When providerSourceID is provided, build a standard on-demand VisitContext
            if currentConsumer.isDependent(), currentConsumer.authenticatedParent?.sourceId == consumer.sourceId {
                AWSDKVisitContext.createVisitContext(
                    forDependent: currentConsumer,
                    parent: consumer,
                    provider: provider
                ) { visitContext, error in
                    currentVisitContext(currentConsumer, visitContext, error)
                }
            } else {
                AWSDKVisitContext.createVisitContext(for: currentConsumer, provider: provider) { visitContext, error in
                    currentVisitContext(currentConsumer, visitContext, error)
                }
            }
        } else if let appointmentSourceID = appointmentSourceID {
            // When appointmentSourceId is provided, build a VisitContext for an appointment.
            currentConsumer.fetchAppointment(withSourceId: appointmentSourceID) { appointment, error in
                if error != nil {
                    ResponseHelper.sendErrorResponse(to: call, error: error)
                    completion(nil, nil)
                }
                
                guard let appointment = appointment else {
                    ResponseHelper.sendErrorResponse(to: call, with: "Failed to find appointment.")
                    completion(nil, nil)
                    return
                }
                
                AWSDKVisitContext.createVisitContext(for: appointment) { visitContext, error in
                    currentVisitContext(currentConsumer, visitContext, error)
                }
            }
        }
    }
    
    func acceptLegalTexts( for visitContext: AWSDKVisitContext ,_ call: CAPPluginCall) {
        self.logService.log("##: acceptLegalTextsForVisit")
        visitContext.legalText.forEach { legalText in
            legalText.setAccepted()
        }
        
        ResponseHelper.sendSuccessResponse(to: call)
    }
    
    // MARK: - Waiting Room
    
    @objc func buildVisit(
        with visitContext: AWSDKVisitContext,
        _ call: CAPPluginCall,
        _ completion: @escaping (AWSDKVisit?) -> Void)
    {
        self.logService.log("##: buildVisit")
        
        guard let newVisitContext = call.getObject(Constants.Call.visitContext)
        else {
            ResponseHelper.sendErrorResponse(to: call, with: "Invalid Visit Context")
            return
        }
        
        // update the callback number
        if let callBackNumber = newVisitContext[Constants.VisitContext.callbackNumber] as? String {
            visitContext.updateCallbackNumber(callBackNumber) { _,_ in }
        }
        
        // accept the legal texts in visitContext
        if let legalTexts = newVisitContext[Constants.VisitContext.legalText] as? [Dictionary<String, Any>] {
            legalTexts.forEach { legalText in
                if let accepted = legalText[Constants.LegalText.isAccepted] as? Bool, accepted {
                    visitContext.legalText.forEach { $0.setAccepted() }
                }
            }
        }
        
        // update the guest emails
        if let guestEmails = newVisitContext[Constants.VisitContext.guestEmails] as? [String] {
            visitContext.updateVisitGuestEmails(guestEmails) { _,_ in }
        }

        // update mayShareHealthHistory
        if let sharedSummary = newVisitContext[Constants.VisitContext.mayShareHealthHistory] as? Bool {
            visitContext.shareHealthHistory = sharedSummary
        }
        
        // update the topics
        if let topics = newVisitContext[Constants.VisitContext.topics] as? [Dictionary<String, Any>] {
            topics.forEach { topic in
                if let title = topic[Constants.VisitTopic.title] as? String,
                   let isSelected = topic[Constants.VisitTopic.isSelected] as? Bool {
                    let updateTopic = visitContext.visitTopics?.first(where: { $0.title == title })
                    updateTopic?.selected = isSelected
                }
            }
        }
        
        // update otherTopicText
        if let topicText = newVisitContext[Constants.VisitContext.otherTopicText] as? String {
            visitContext.otherTopicText = topicText
        }
        
        // update triage questions
        if let triageQuestions = newVisitContext[Constants.VisitContext.triageQuestions] as? [Dictionary<String, Any>] {
            triageQuestions.forEach { triageQuestion in
                if let question = triageQuestion[Constants.VisitTriage.question] as? String,
                   let answer = triageQuestion[Constants.VisitTriage.response] as? String {
                    let updateTriageQuestion = visitContext.triageQuestions.first(where: { $0.question == question })
                    updateTriageQuestion?.response = answer
                }
            }
        }
        
        self.logService.log("Legal Text from visit context - \(visitContext.legalText[0].name), type: \(visitContext.legalText[0].type.rawValue)")
        
        // validate the visitContext
        do {
            try AWSDKVisitService.isVisitContextValid(visitContext, cartMode: false)
        } catch (let error as NSError) {
            ResponseHelper.sendValidationErrorResponse(to: call, error, "Invalid VisitContext.")
            self.logService.log("##: Error: \n \(String(describing: error.userInfo[AWSDKValidationErrorsKey]))")
            completion(nil)
        }
        
        // build visit
        AWSDKVisitService.createVisit(with: visitContext) { [weak self] visit, error in
            guard let strongSelf = self else { return }
            
            if error != nil {
                if !strongSelf.shouldBypassVisitError(for: error, visit) {
                    ResponseHelper.sendErrorResponse(to: call, error: error)
                    return
                }
            }
            
            guard let visit = visit else {
                ResponseHelper.sendErrorResponse(to: call, with: "Visit not created.")
                completion(nil)
                return
            }
            
            ResponseHelper.validateAndSend(ResponseHelper.getVisitJSON(visit), to: call)
            completion(visit)
        }
    }
    
    func applyCouponCode(for visit: AWSDKVisit, _ call: CAPPluginCall, completion: @escaping (Bool, String) -> Void) {
        guard let couponCode = call.getString("couponCode") else {
            completion(false, "Coupon Code Missing")
            return
        }
        
        if couponCode.isEmpty {
            completion(false, "Invalid Coupon Code")
            return
        }
        
        visit.applyCouponCode(couponCode) { success, error in
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion(false, "")
                return
            }
            
            completion(success, "")
        }
    }
    
    func start(_ visit: AWSDKVisit, _ call: CAPPluginCall, completion: @escaping (Bool) -> Void) {
        AWSDKVisitService.ready(toStart: visit) { success, error in
            if error != nil {
                ResponseHelper.sendValidationErrorResponse(to: call, error, "Visit information is incomplete")
                completion(false)
                return
            }
            
            AWSDKVisitService.start(visit) { _, _ in
                ResponseHelper.sendSuccessResponse(to: call)
                completion(true)
            }
        }
    }
    
    func fetchActiveVisit(for consumer: AWSDKConsumer, _ completion: @escaping (AWSDKVisit?, Error?) -> Void) {
        consumer.fetchActiveVisit { visit, error in
            completion(visit, error)
        }
    }
    
    // MARK: - Visit Transfer
    
    func accept(
        _ transfer: AWSDKVisitTransfer,
        for consumer: AWSDKConsumer,
        _ call: CAPPluginCall,
        _ completion: @escaping (AWSDKVisit?, AWSDKVisitContext?, Dictionary<String, AWSDKLegalText>?, AWSDKVisitTransfer?) -> Void)
    {
        transfer.accept { [weak self] result, error in
            guard let strongSelf = self else { return }
            
            // no provider available
            if let error = error as NSError? {
                // ignore the timeout error if visit's subscription's suppress charge is false
                if let visit = result as? AWSDKVisit,
                   !strongSelf.shouldBypassVisitError(for: error, visit)
                {
                    ResponseHelper.sendValidationErrorResponse(to: call, error, "Error in transfering visit")
                    completion(nil, nil, nil, nil)
                    return
                }
            }
            
            var transferJSON = [String: Any]()
            
            // provider is not eligible for quick transfer
            // take user to intake step with visitContext containing intake info
            if let visitContext = result as? AWSDKVisitContext,
               let visitContextJSON = ResponseHelper.getVisitContextJSON(for: consumer, from: visitContext)
            {
                if let modality = visitContext.practice.availableModalities.first(where: { $0.code == .video }) {
                    visitContext.selectedModality = modality
                }
                
                if visitContext.selectedModality.code == .undefined {
                    ResponseHelper.sendErrorResponse(to: call, with: "Provider's practice does not support video visits.")
                    completion(nil, nil, nil, nil)
                    return
                }
                
                transferJSON[Constants.VisitTransferResponse.newVisit] = NSNull()
                transferJSON[Constants.VisitTransferResponse.newVisitContext] = visitContextJSON.json
                transferJSON[Constants.VisitTransferResponse.newDeclineAndTransfer] = NSNull()
                transferJSON[Constants.VisitTransferResponse.newSuggestedTransfer] = NSNull()
                
                ResponseHelper.validateAndSend(transferJSON, to: call)
                // might want to return visitContext and legalTexts!
                completion(nil, visitContext, visitContextJSON.legalText, nil)
                return
            }
            
            // provider is eligible for quick transfer
            // SDK builds a visitContext and return a AWSDKVisit object
            if let visit = result as? AWSDKVisit {
                transferJSON[Constants.VisitTransferResponse.newVisit] = ResponseHelper.getVisitJSON(visit)
                transferJSON[Constants.VisitTransferResponse.newVisitContext] = NSNull()
                transferJSON[Constants.VisitTransferResponse.newSuggestedTransfer] = NSNull()
                if let forcedTransfer = visit.forcedTransfer {
                    transferJSON[Constants.VisitTransferResponse.newDeclineAndTransfer] =
                        ResponseHelper.getTransferJSON(forcedTransfer)
                } else {
                    transferJSON[Constants.VisitTransferResponse.newDeclineAndTransfer] = NSNull()
                }
                // return visit to transfer user to new waiting room
                ResponseHelper.validateAndSend(transferJSON, to: call)
                // might want to send visit object back
                completion(visit, nil, nil, nil)
                return
            }
            
            // if new provider goes offline but a different provider is available,
            // SDK returns a transfer object. Visit object's transfer property is updated
            // user can either accept or decline this new transfer
            if let newTransfer = result as? AWSDKVisitTransfer {
                transferJSON[Constants.VisitTransferResponse.newVisitContext] = NSNull()
                transferJSON[Constants.VisitTransferResponse.newVisit] = NSNull()
                transferJSON[Constants.VisitTransferResponse.newDeclineAndTransfer] = NSNull()
                transferJSON[Constants.VisitTransferResponse.newSuggestedTransfer] = ResponseHelper.getTransferJSON(newTransfer)
                
                ResponseHelper.validateAndSend(transferJSON, to: call)
                completion(nil, nil, nil, newTransfer)
                return
            }
        }
    }
    
    func decline(_ transfer: AWSDKSuggestedVisitTransfer, _ call: CAPPluginCall, _ completion: @escaping () -> Void) {
        transfer.declineTransfer { success, error in
            ResponseHelper.handleResponse(
                for: call,
                success,
                error,
                alternateErrorMessage: "Suggested transfer decline failed"
            )
            
            completion()
        }
    }
    
    // user accepts first available transfer
    func firstAvailableSearchSuggestion(for visit: AWSDKVisit, _ call: CAPPluginCall, _ completion: @escaping () -> Void) {
        visit.beginFirstAvailableTransferSearch { success, error in
            ResponseHelper.handleResponse(for: call, success, error, alternateErrorMessage: "")
            completion()
        }
    }
    
    // user declines the first available transfer; 
    func declineFirstAvailableTransfer(
        for visit: AWSDKVisit,
        dontAsk: Bool,
        _ call: CAPPluginCall,
        _ completion: @escaping () -> Void
    )
    {
        visit.declineFirstAvailableTransferSearch(dontAsk) { success, error in
            ResponseHelper.handleResponse(for: call, success, error, alternateErrorMessage: "")
            completion()
        }
    }
    
    // MARK: - Visit Summary
    
    func getSummary(for visit: AWSDKVisit, _ call: CAPPluginCall,  _ completion: @escaping (AWSDKVisitSummary?) -> Void) {
        visit.fetchSummary { visitSummary, error in
            if error != nil {
                ResponseHelper.sendErrorResponse(to: call, error: error)
                completion(nil)
                return
            }
            
            guard let visitSummary = visitSummary else {
                ResponseHelper.sendErrorResponse(to: call, with: "Invalid Visit Summary.")
                completion(nil)
                return
            }
            
            ResponseHelper.validateAndSend(ResponseHelper.getVisitSummaryJSON(visitSummary), to: call)
            completion(visitSummary)
        }
    }
    
    func rateProviderAndEngagement(
        for visitSummary: AWSDKVisitSummary,
        _ call: CAPPluginCall,
        _ completion: @escaping () -> Void)
    {
        let providerRating = call.getInt(Constants.Call.providerRating) ?? 0
        let engagementRating = call.getInt(Constants.Call.visitRating) ?? 0
        
        visitSummary.rateProvider(
            NSNumber(value: providerRating),
            engagement: NSNumber(value: engagementRating)
        ) { success, error in
            ResponseHelper.handleResponse(
                for: call,
                success,
                error,
                alternateErrorMessage: "Unable to update Provider & Engagement Rating"
            )
            
            completion()
        }
    }
    
    func sendSummaryToEmailAddresses(
        _ visitSummary: AWSDKVisitSummary,
        _ call: CAPPluginCall,
        _ completion: @escaping () -> Void)
    {
        let emailAddresses = call.getArray(Constants.Call.emails, String.self) ?? []
        
        visitSummary.send(toEmailAddresses: emailAddresses) { success, error in
            ResponseHelper.handleResponse(for: call, success, error, alternateErrorMessage: "Failed to update Email")
            completion()
        }
    }
    
    func sendSummaryToEmailsAndFaxNumberes(
        _ visitSummary: AWSDKVisitSummary,
        _ call: CAPPluginCall,
        _ completion: @escaping () -> Void)
    {
        let faxNumbers = call.getArray(Constants.Call.faxes, String.self) ?? []
        let emails = call.getArray(Constants.Call.emails, String.self) ?? []
        
        // don't send summary to emails & faxes if user has not accepted Hippa Notice
        if let isHippaNoticeAccepted = call.getBool(Constants.Call.isHipaaNoticeAccepted), !isHippaNoticeAccepted {
            ResponseHelper.sendSuccessResponse(to: call)
            completion()
            return
        }
        
        if faxNumbers.count == 0 {
            sendSummaryToEmailAddresses(visitSummary, call) {
                completion()
            }
            
            return
        }
        
        visitSummary.send(toEmailAddresses: emails, faxNumbers: faxNumbers) { success, error in
            ResponseHelper.handleResponse(for: call, success, error, alternateErrorMessage: "Failed to update Email")
            completion()
        }
    }
    
    func submitVisitFeedback(_ visitSummary: AWSDKVisitSummary, _ call: CAPPluginCall, _ completion: @escaping () -> Void) {
        guard let selectedOption = call.getString(Constants.Call.selectedOption) else {
            ResponseHelper.sendErrorResponse(to: call, with: "selectedOption for feedback missing")
            completion()
            return
        }
        
        if let option = visitSummary.feedbackQuestion.responseOptions.firstIndex(where: { $0 == selectedOption }) {
            visitSummary.feedbackQuestion.selectedOption = option
        } else {
            // a value of -1 means no answer was selected
            visitSummary.feedbackQuestion.selectedOption = -1
        }
        visitSummary.submitFeedbackQuestion { success, error in
            ResponseHelper.handleResponse(for: call, success, error, alternateErrorMessage: "Feedback question update failed")
            completion()
        }
    }
    
    func cancelPending(_ visit: AWSDKVisit, _ call: CAPPluginCall, _ completion: @escaping () -> Void) {
        AWSDKVisitService.cancelPendingVisit(visit) { success, error in
            ResponseHelper.handleResponse(for: call, success, error, alternateErrorMessage: "Cancel Pending Visit Failed.")
            completion()
        }
    }
    
    // MARK: - Private
    
    private func shouldBypassVisitError(for error: Error?, _ visit: AWSDKVisit?) -> Bool {
        if error != nil,
           let error = error as NSError?,
           let visit = visit
        {
            if error.code == AWSDKErrorCode.errorCodeTimeout.rawValue,
                ((visit.consumer.subscription?.healthPlan?.suppressCharge) != nil)
            {
                return true
            } else if error.code == AWSDKErrorCode.errorCodeValidationBadEligibilityInformation.rawValue ||
                error.code == AWSDKErrorCode.errorCodeValidationEligibilityException.rawValue ||
                error.code == AWSDKErrorCode.errorCodeInvalidValue.rawValue ||
                error.code == AWSDKErrorCode.errorCodeEligibilityInaccuratePrimarySubscriberInfo.rawValue ||
                error.code == AWSDKErrorCode.errorCodeEligibilityInaccurateDependentSubscriberInfo.rawValue
            {
                return true
            }
        }
        
        return false
    }
}
