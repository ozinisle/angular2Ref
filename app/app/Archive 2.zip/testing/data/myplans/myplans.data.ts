export const mockPlanBenefitServicesResponse = {
  planName: 'Blue Care Elect Preferred 80 with Copay',
  PlanBenefitFeatures: {
    deductibleText: {
      inNetworkAndOutOfNetworkCombined: [
        '$750 per member per calendar year',
        '$1,500 per family per calendar year',
        'Deductible does not apply to services with a copayment, in-network preventive health services and certain other services as noted.'
      ]
    },
    coinsuranceMaxText: {
      inNetworkAndOutOfNetworkCombined: [
        '$4,500 per member per calendar year',
        '$9,000 per family per calendar year',
        'Calculation includes deductible, copayments and coinsurance.'
      ]
    },
    lifetimeBenefitText: { inNetworkAndOutOfNetworkCombined: ['None'] }
  },
  planBenefits: [
    {
      planBenefitName: 'Ambulance Services',
      subcategory: [
        {
          planBenefitName: 'Emergency transport',
          memberCostText: {
            inNetwork: ['20% coinsurance (deductible does not apply)'],
            outOfNetwork: ['20% coinsurance (deductible does not apply)'],
            inNetworkAndOutOfNetworkCombined: ['None']
          }
        },
        {
          planBenefitName: 'Other medically necessary transport',
          memberCostText: {
            inNetwork: ['20% coinsurance after deductible'],
            outOfNetwork: ['40% coinsurance after deductible'],
            inNetworkAndOutOfNetworkCombined: ['None']
          }
        }
      ]
    },
    {
      planBenefitName: 'Cardiac Rehabilitation',
      memberCostText: {
        inNetwork: ['$20 copayment per visit'],
        outOfNetwork: ['40% coinsurance after deductible'],
        inNetworkAndOutOfNetworkCombined: ['None']
      }
    },
    {
      planBenefitName: 'Chiropractor Services',
      subcategory: [
        {
          planBenefitName: 'Diagnostic lab tests and x-rays',
          memberCostText: {
            inNetwork: ['No cost'],
            outOfNetwork: ['40% coinsurance after deductible'],
            inNetworkAndOutOfNetworkCombined: ['None']
          }
        },
        {
          planBenefitName: 'Outpatient medical care services',
          memberCostText: {
            inNetwork: ['$20 copayment per visit'],
            outOfNetwork: ['40% coinsurance after deductible'],
            inNetworkAndOutOfNetworkCombined: ['None']
          }
        }
      ]
    },
    {
      planBenefitName: 'Dialysis Services',
      memberCostText: {
        inNetwork: ['20% coinsurance after deductible'],
        outOfNetwork: ['40% coinsurance after deductible'],
        inNetworkAndOutOfNetworkCombined: ['None']
      }
    },
    {
      planBenefitName: 'Well Newborn Inpatient Care',
      memberCostText: {
        inNetwork: ['No cost'],
        outOfNetwork: ['40% coinsurance (deductible does not apply)'],
        inNetworkAndOutOfNetworkCombined: ['None']
      }
    }
  ]
};

export const mockPlanResponse = {
  RowSet: {
    osplinPlans: {
      plans: [
        {
          planName: 'Blue Care Elect Preferred 80 with Copay',
          coveragePackageCode: '127376',
          foundFlag: 'Y',
          pcpState: '',
          groupInfo: {
            group: [
              {
                groupName: 'OCEAN SPRAY  ACTIVE',
                groupNumber: '002324067',
                groupAnniversaryDay: '01',
                groupAnniversaryMonth: '01',
                subscriberId: '9811838410000',
                planEffectiveDt: '2020-01-01'
              }
            ]
          },
          osplinPlanMembers: {
            members: [
              {
                firstName: 'MICHAEL',
                lastName: 'STARK',
                memberId: '00',
                memberDOB: '1988-09-04',
                UACoverageCode: { medicalCoverageUA: { code: '0102', text: 'BLUE CARE ELECT PREFERRED' } }
              },
              {
                firstName: 'SHANNA',
                lastName: 'WOJCIECHOWSKI',
                memberId: '01',
                memberDOB: '1990-01-21',
                UACoverageCode: { medicalCoverageUA: { code: '0102', text: 'BLUE CARE ELECT PREFERRED' } }
              },
              {
                firstName: 'MICHAEL',
                lastName: 'WOJCIECHOWSKI',
                memberId: '11',
                memberDOB: '2007-02-28',
                UACoverageCode: { medicalCoverageUA: { code: '0102', text: 'BLUE CARE ELECT PREFERRED' } }
              },
              {
                firstName: 'BETTY',
                lastName: 'WOJCIECHOWSKI',
                memberId: '10',
                memberDOB: '2011-07-29',
                UACoverageCode: { medicalCoverageUA: { code: '0102', text: 'BLUE CARE ELECT PREFERRED' } }
              }
            ]
          }
        }
      ]
    }
  }
};
