export const mockSelectedVitaminsAndOTCResponse = [
  {
    count: 50,
    doseType: 'T',
    inPackets: true,
    isDiscounted: true,
    name: 'Acetaminophen',
    price: 6.5,
    rxcui: '1148399',
    size: '12 TABLETS',
    strength: '650 MG',
    upc: '49348092110'
  }
];

export const mockVitaminsAndOTC = ['Vitamin B-12 Tr', 'Acetaminophen', 'Iron', 'Vitamin B12', 'Vitamin B6'];

export const mockDiscountedVitaminsAndOTCs = ['Vitamin B-12 Tr', 'Acetaminophen', 'Iron', 'Vitamin B12', 'Vitamin B6'];

export const mockMedicationDetails = {
  name: 'Fish Oil',
  upc: '03160402840',
  strength: '500 MG',
  price: 14.99,
  count: 90,
  doseType: 'C',
  inPackets: true,
  isDiscounted: false,
  orderDetails: [{ strength: '500 MG', time: '04', minute: '45', mer: 'PM', orderCount: 5 }]
};