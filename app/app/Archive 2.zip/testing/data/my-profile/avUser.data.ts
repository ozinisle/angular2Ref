export let jasAVUserData = {
  getMemProfileApiResponse: {
    useridin: 'dannew11@yopmail.com',
    fullName: 'DAN INCE',
    userState: 'AUTHENTICATED-AND-VERIFIED',
    dob: '1958-08-22',
    address1: '66D EARLE ST BLDG 8',
    address2: '',
    city: 'QUINCY',
    state: 'MA',
    zip: '02169',
    emailAddress: 'dannew12@yopmail.com',
    phoneNumber: '2489794028',
    phoneType: 'MOBILE',
    isVerifiedEmail: false,
    isVerifiedMobile: false,
    isEditableAddress: true,
    isDirectPay: false,
    isEmailOptedIn: true,
    isMobileOptedIn: true,
    hintQuestion: 'Who was your favorite teacher?',
    hintAnswer: 'teacher',
    gender: 'M',
    health: {
      allergies: [],
      conditions: []
    },
    dependents: [
      {
        depId: '100001305',
        fullName: 'MILLER INCE',
        dob: '2006-11-06',
        gender: 'M',
        health: {
          allergies: [],
          conditions: []
        }
      }
    ]
  }
};
