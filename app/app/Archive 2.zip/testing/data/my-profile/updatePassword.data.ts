export let updatePassword_success_response = {
  result: 0,
  errormessage: '',
  displaymessage: ''
};
