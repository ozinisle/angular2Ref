export const homeServiceResponse = [
  {
    Title: 'Homepage Navigation Block',
    FontawesomeIconClass1: ["far","prescription-bottle-alt"],
    AnchorText1: 'Medication Lookup Tool',
    AnchorTextUrl1: 'https://home.bluecrossma.com/medication/',
    APPTextUrl1: 'https://home.bluecrossma.com/medication?referer=mobile-app',
    FontawesomeIconClass2: ["far","phone"],
    AnchorTex2: '24/7 Nurse Line',
    AnchorTextUrl2: 'tel:18882472583',
    APPTextUrl2: 'tel:18882472583',
    FontawesomeIconClass3: ["far","stethoscope"],
    AnchorTex3: 'Find a Doctor & Estimate Costs',
    AnchorTextUrl3: 'https://myblue.bluecrossma.com/health-plan/find-doctor-provider-dentist',
    APPTextUrl3: 'https://myblue.bluecrossma.com/app-fad'
  }
];
