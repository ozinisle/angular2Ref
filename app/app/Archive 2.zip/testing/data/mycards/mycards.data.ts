export const mockMemberFrontData = [
  {
    ProdDesc: 'BLUE CARE ELECT PREFERRED 80 WITH COPAY',
    OvCopay: 20,
    RowNum: 2,
    isDependent: false,
    BHCopay: 20,
    dispSuitcase: true,
    rxSpecified: true,
    rxBin: 'RxBin: 003858 PCN: A4',
    relationship: 'Subscriber',
    rxGRP: 'RxGRP: MASA',
    MemName: 'MICHAEL STARK',
    PrevCopay: 0,
    ERCopay: 150,
    MemServPh: '1-800-358-2227',
    hasDependents: true,
    MemSuff: '00',
    cardMemID: 'WAV981183841'
  },
  {
    ProdDesc: 'BLUE CARE ELECT PREFERRED 80 WITH COPAY',
    OvCopay: 20,
    RowNum: 4,
    isDependent: false,
    BHCopay: 20,
    dispSuitcase: true,
    rxSpecified: true,
    rxBin: 'RxBin: 003858 PCN: A4',
    relationship: 'Spouse',
    rxGRP: 'RxGRP: MASA',
    MemName: 'SHANNA WOJCIECHOWSKI',
    PrevCopay: 0,
    ERCopay: 150,
    MemServPh: '1-800-358-2227',
    hasDependents: true,
    MemSuff: '01',
    cardMemID: 'WAV981183841'
  },
  {
    ProdDesc: 'BLUE CARE ELECT PREFERRED 80 WITH COPAY',
    OvCopay: 20,
    RowNum: 3,
    isDependent: true,
    BHCopay: 20,
    dispSuitcase: true,
    rxSpecified: true,
    rxBin: 'RxBin: 003858 PCN: A4',
    relationship: 'Dependent',
    rxGRP: 'RxGRP: MASA',
    MemName: 'MICHAEL WOJCIECHOWSKI',
    PrevCopay: 0,
    ERCopay: 150,
    MemServPh: '1-800-358-2227',
    hasDependents: false,
    MemSuff: '11',
    cardMemID: 'WAV981183841'
  },
  {
    ProdDesc: 'BLUE CARE ELECT PREFERRED 80 WITH COPAY',
    OvCopay: 20,
    RowNum: 1,
    isDependent: true,
    BHCopay: 20,
    dispSuitcase: true,
    rxSpecified: true,
    rxBin: 'RxBin: 003858 PCN: A4',
    relationship: 'Dependent',
    rxGRP: 'RxGRP: MASA',
    MemName: 'BETTY WOJCIECHOWSKI',
    PrevCopay: 0,
    ERCopay: 150,
    MemServPh: '1-800-358-2227',
    hasDependents: false,
    MemSuff: '10',
    cardMemID: 'WAV981183841'
  }
];

export const mockMemberBackData = [
  { RowNum: 1, CopyLoc: 'Top', Copy: 'www.bluecrossma.com' },
  {
    RowNum: 2,
    CopyLoc: 'Para1',
    Copy:
      'Routine or Urgent Care: Contact your PCP. Emergencies: seek emergency care or call 911 or call the local emergency telephone number.  Call your PCP within 48 hours.'
  },
  {
    RowNum: 3,
    CopyLoc: 'Para2',
    Copy: 'This card is for identification only. It is not proof of membership, nor does it guarantee coverage.'
  },
  {
    RowNum: 4,
    CopyLoc: 'Para3',
    Copy:
      'To the Provider: submit claims to the Blue Cross and/or Blue Shield Plan servicing your area.  Be sure to include the three-letter prefix followed by the nine-digit number.'
  },
  {
    RowNum: 5,
    CopyLoc: 'Para4',
    Copy:
      'Member Service:1-800-358-2227|Provider Service:1-800-443-6657|24/7 Nurse Line:1-888-247-2583|Behavioral Health & Substance Abuse:1-800-444-2426'
  },
  {
    RowNum: 6,
    CopyLoc: 'Para5',
    Copy:
      'Blue Cross and Blue Shield of Massachusetts, Inc., an Independent Licensee of the Blue Cross and Blue Shield Association. administers claims payment only and does not assume financial risk for claims.'
  },
  {
    RowNum: 7,
    CopyLoc: 'Bottom',
    Copy: 'Express Scripts, Inc.  Pharmacy benefits administrator'
  }
];

export const mockMemBasicInfo = {
  rxSummary: {
    memFirstName: 'MICHAEL',
    memMiddleInitial: '',
    memLastName: 'STARK',
    subNum: '9811838410000',
    suffix: '00',
    hasDependents: true,
    relationship: 'Subscriber'
  }
};
