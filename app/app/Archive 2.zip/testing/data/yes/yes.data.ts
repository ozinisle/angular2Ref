export const mockgetPromoContentResponse = [
  {
    ArticleText: 'Medication Lookup Tool: Quickly and easily see which medications your plan covers.',
    ArticleUrl: '',
    Title: 'Medication Lookup Tool',
    RegularImages: ''
  }
];

export const mockClaimSummaryResponse = {
  queryCriteria: {
    hasMoreRecords: false,
    totalRecordCount: 5,
    scroll: { recordStartIndex: 1, recordEndIndex: 5 }
  },
  claimsSummary: [
    {
      claimNumber: '020198916414600',
      memberName: 'CAROL JAMES',
      claimStatus: 'Completed',
      savedAmount: 24206.04,
      owedAmount: 1750,
      dateOfService: '2020-01-20',
      providerName: 'PORTSMOUTH REGIONAL HOSP'
    }
  ]
};

export const mockSummaryAmounts = {
  summaryAmounts: [
    {
      year: 2020,
      outOfPocket: 2022.1,
      savedAmount: 25382.24,
      totalCost: 27404.34
    }
  ]
};
