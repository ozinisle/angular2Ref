export const mockmyMedicationservice = {
  getCurrentUserInfo: {
    isDependentUser: false,
    dependentMemberInfo: undefined
  },
  getMyMedicationDetailsRequest: {
    useridin: 'grace.mathisqa@yopmail.com',
    rxIncurredDate: '2013-03-19',
    ndcCd: '00603389121'
  },
  getMedicationDetails: {
    rxSummary: {
      memFirstName: 'GRACE',
      memMiddleInitial: '',
      memLastName: 'MATHIS',
      subNum: '0509272420000',
      suffix: '00',
      hasDependents: false,
      relationship: 'Subscriber',
      fullName: 'Grace Mathis (Subscriber)',
      filterName: 'Grace Mathis'
    }
  },
  getMemBasicInfo: {
    rxDetails: {
      genericName: 'Hydrocodone-Acetaminophen Tab 7.5-325 MG',
      pharmacy: {
        id: '70010002236544',
        name: 'STAR PHARMACY',
        phoneNumber: '617-782-1628',
        address: '370 WESTERN AVE',
        city: 'BRIGHTON',
        state: 'MA',
        zip: '02135'
      },
      copay: 39.99,
      lastFill: '2013-03-19',
      prescribingDoctor: 'PATTY M YOFFE MD',
      prescribingDoctorNumber: '70010000J03994',
      refillHistory: [{ date: '2013-03-19', claimNumber: '020182500026500' }]
    }
  }
};
