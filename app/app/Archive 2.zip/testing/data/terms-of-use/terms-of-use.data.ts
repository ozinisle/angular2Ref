export const mockgetTermsPageResponse = [
  {
    ArticleId: '11',
    Title: 'Terms of Use',
    ShortDescription: '',
    DisplayCategory: '',
    DisplayCategoryImage: '',
    Body:
      "<p><strong>Limitation of Liability </strong>IN NO EVENT SHALL Blue Cross Blue Shield of Massachusetts, Blue Cross Blue Shield of Massachusetts HMO Blue, Inc. (together, BCBSMA) OR ITS SUPPLIERS OR VENDORS BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL. PUNITIVE, INCIDENTAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES. OR ANY DAMAGES WHATSOEVER RESULTING FROM ANY LOSS OF USE, LOSS OF PROFITS, LITIGATION. OR ANY OTHER PECUNIARY LOSS, WHETHER BASED ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT LIABILITY, OR OTHERWISE, ARISING OUT OF OR IN ANY WAY CONNECTED WITH THIS APPLICATION OR THE PROVISION OF OR FAILURE TO MAKE AVAILABLE ANY SUCH PRODUCTS, GOODS. OR SERVICES, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.</p><p><strong>Copyright and Trademark </strong>All materials within this application, including the application's design, layout, and organization, are owned and copyrighted by BCBSMA or its suppliers or vendors, and are protected by U.S. and international copyrights. Blue Cross Blue Shield of Massachusetts HMO Blue, Inc. is a separate wholly controlled not-for-profit subsidiary of Blue Cross Blue Shield of Massachusetts, Inc.  Only personal use of such materials is permitted for our members, which means that you may access, download, or print such materials for your personal, non-commercial use only. Use of information or communications available on this application for any commercial or research related purpose is strictly prohibited. You agree that you will not use the information on this application for any purpose that is unlawful or prohibited by these terms, conditions, and notices. You agree not to change or delete any copyright or proprietary notice from materials downloaded from this application or any application accessible through this application.</p><p><strong>User Obligations  </strong>You may not use this application in any manner that may: adversely affect this application's resources or the availability of this application to others violate any local, state, national or international law, delete or revise any content on this application or, use this application to harass any other person or to collect or store personal information about other visitors. If you have a unique user identifier and/or password/PIN to access secure areas, you are responsible for protecting the identifier and/or password and for any unauthorized use by others, with or without your permission. Some parts of this application that are non-secure and public may allow you to post, or to e-mail to BCBSMA, materials or information (Visitor Content) or to access or use Visitor Content posted or e-mailed by other visitors to this application.  Visitor Content is not subject to BCBSMA’s Privacy Policy and is not subject to Federal rules concerning confidentiality of medical and health information (HIPAA).  By submitting Visitor Content, you consent to allowing other users of the app to view that information.  Do not use these features of the app if you don’t want personal health information to be displayed on the app for other users to access.  You grant us the unrestricted right to use or distribute, free of charge, any Visitor Content posted on this application.  You may not submit or post any material or information that is illegal, obscene, threatening, defamatory, invasive of privacy, or infringing of proprietary rights of any person or entity, or that contains software viruses, corrupted data, cancel bots, commercial solicitations, or mass mailings or any form of spam. You may not use a false e-mail address to impersonate any person or otherwise mislead as to the origin of any material or information you submit or post. BCBSMA may review, remove or edit any Visitor Content at its discretion. BCBSMA has no responsibility and assumes no liability for Visitor Content posted by you or by any other party. You are responsible for all software and equipment necessary to access and use this application, including all related expenses. Standard mobile phone carrier and data usage charges apply.</p><p>Depending on how you use the app, information about your personal health may be displayed on your phone and anyone with access to your phone may have access to this information.  Do not use these features of the app if you don’t want personal health information to be displayed on your phone.   Except for Visitor Content (as xdescribed above), all personal health information available through this app is subject to the BCBSMA Privacy Policy and BCBSMA Commitment to Confidentiality also in this section.</p><p>You are solely responsible for maintaining the confidentiality of any password or other security measure you use in connection with this application, and agree to notify BCBSMA immediately of any unauthorized use of your password or other security measure. BCBSMA reserves the right to change the terms of these terms and conditions at any time, for any reason with or without notice by posting new or amended terms on this application.</p>",
    CreatedAt: 'August 10, 2017',
    RegularImages: '',
    TabletImage: '',
    MobileImages: '',
    ThumbnailImage: '',
    ArticleUrl: '',
    ArticleText: '',
    APPArticleUrl: '',
    VideoUrl: '',
    VideoThumbnailIcon: '',
    FontawesomeIconUnicode: '',
    FontawesomeIconClass: '',
    AppstoreIcon: '',
    AppstoreIconUrl: '',
    GoogleplayIcon: '',
    GoogleplaystoreIconUrl: '',
    ButtonText: '',
    ButtonUrl: '',
    APPButtonUrl: '',
    PromoSlotDestination: '',
    Version: ''
  }
];
