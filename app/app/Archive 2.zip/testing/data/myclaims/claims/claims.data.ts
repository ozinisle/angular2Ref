export const CONFIG_URL_VALID='https://games.bluecrossma1.com/page/config';
export const CONFIG_URL_INVALID_URL='https://games.bluecrossma1.com/page/config';
export const Config_EyeMedStartDate_ValidDate = [{
    title: 'config',
    config: {
        eyeMedStartDate: '2021-01-01'
    }
}];
export const Config_With_NULLValues = [
    null,
    null
];
export const Config_With_EmptyArray = [];
export const Config_With_FutureEyemedState_Date = [{
    title: 'config',
    config: {
        eyeMedStartDate: '2023-01-01'
    }
}];
export const Config_With_PastEyeMedStart_Date = [{
    title: 'config',
    config: {
        eyeMedStartDate: '2019-01-01'
    }
}];
export const Config_With_Invalid_Date = [{
    title: 'config',
    config: {
        eyeMedStartDate: 'Invalid'
    }
}];
export const Config_With_Invalid_JSON = [{
    title: 'config',
    configuration: {
        eyeMedStartDate: '2021-01-01'
    }
}];
export const Config_With_Empty_Data = [{
    title: 'configtest',
    config: {}
}];
