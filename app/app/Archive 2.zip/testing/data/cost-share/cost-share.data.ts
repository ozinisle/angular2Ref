export const COST_SHARE = [{
    ArticleId: '21431',
    Links: [
        {
            fontawsomeclass: 'fa-file-alt',
            link: 'https://www.bluecrossma.org/',
            text: 'See Eligible Medications',
            group: undefined
        },
        {
            fontawsomeclass: 'fa-file-alt',
            link: 'https://www.bluecrossma.org/',
            text: 'Cost-Share Assistance Fact Sheet',
            group: undefined
        },
        {
            fontawsomeclass: 'fa-file-alt',
            link: 'https://www.bluecrossma.org/',
            text: 'Cost-Share Assistance FAQ',
            group: '107313021,107513021,087312042,107519012,067399041,087523042,087523041'
        },
        {
            fontawsomeclass: 'fa-link',
            link: 'tel:1-636-614-3128',
            text: 'Contact PillarRx',
            group: undefined
        }
    ],
    MobileImage: '/sites/games.bluecrossma.com/files/2020-04/BCBS_Corona_Hero_App_Final.jpg',
    RegularImage: '/sites/games.bluecrossma.com/files/2020-06/000306479%20Cost%20Share%20Assistance%20header.jpg',
    ShortDescription: '<p>We\’ve partnered with PillarRx Consulting, an independent company that administers the' +
    ' Cost-Share Assistance Program. This cost savings program uses coupons from manufacturers of medication to cover' +
    ' most or all of your out-of-pocket costs for eligible medications. If you’re taking an eligible medication, a Care ' +
    'Team Coordinator from PillarRx will call you to help you enroll. If you choose not to enroll, your out-of-pocket costs for' +
    ' an eligible medication will be higher.</p>',
    Title: 'Cost-Share Assistance Program'
  }];

  export const GETPLANS_POSITIVE_DATA = [{
    RowSet: [{
        osplinPlans: {
            plans: [{
                groupName: 'TJX UNI ACT HMO WOBURN MAINT',
                groupNumber: '107313021',
                groupAnniversaryDay: '01',
                groupAnniversaryMonth: '01',
                subscriberId: '0509527040000',
                planEffectiveDt: '2020-01-01',
                osplinMembers: [{
                    plan : [{
                        groupinfo : {
                            group :[111,222,333]
                        }
                    }]
                }],
                pcpState: '',
                planName: 'Network Blue'
            }]
        }
    }]
  }];

  export const GETPLANS_NEGATIVE_DATA = [{
    RowSet: [{
        osplinPlans: {
            plans: [{
                groupName: 'TEST PPO ASC GROUP 02',
                groupNumber: '521309540',
                groupAnniversaryDay: '01',
                groupAnniversaryMonth: '01',
                subscriberId: '0509354530000',
                planEffectiveDt: '2020-01-01',
                osplinMembers: [{}],
                pcpState: '',
                planName: 'Blue Care Elect Value Plus Option'
            },
            {
                groupName: 'DENTALBLUE',
                groupNumber: '521315165',
                groupAnniversaryDay: '01',
                groupAnniversaryMonth: '01',
                subscriberId: '0509354530000',
                planEffectiveDt: '2020-01-01',
                osplinMembers: [{}],
                pcpState: '',
                planName: 'Dental Blue Program 1'
            }]
        }
    }]
  }];


