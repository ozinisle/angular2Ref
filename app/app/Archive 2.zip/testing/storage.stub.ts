import { Observable } from 'rxjs';
export class MockStorage {
  set(key: string, value: any): Observable<any> {
    return new Observable(observer => {
      observer.next();
      observer.complete();
    });
  }
  get(key) {
    return new Promise<any>((resolve, reject) => resolve(true));
  }
}
