import { of } from 'rxjs/observable/of';
import { homeServiceResponse } from '../data/careCast/careCast.data';
import { mockgetTermsPageResponse } from '../data/terms-of-use/terms-of-use.data';
import { mockgetconfidentialityPageApiResponse } from '../data/confidentiality/confidentiality.data';
import { jasAVUserData } from '../data/my-profile/avUser.data';
import { updatePassword_success_response } from '../data/my-profile/updatePassword.data';
import { mockmyMedicationservice } from '../data/my-medication-details/my-medication-details.data';
import { mockgetPromoContentResponse, mockClaimSummaryResponse, mockSummaryAmounts } from '../data/yes/yes.data';
import { mockMemBasicInfo, mockMemberBackData, mockMemberFrontData } from '../data/mycards/mycards.data';
import {
  orderreplacement_service_getcard_success_response,
  orderreplacement_service_submitCard_success_response
} from '../data/orderreplacement/orderreplacement.service.data';
import {
  mockDiscountedVitaminsAndOTCs,
  mockSelectedVitaminsAndOTCResponse,
  mockVitaminsAndOTC
} from '../data/my-pillpack/my-pillpack.data';
import { mockPlanBenefitServicesResponse, mockPlanResponse } from '../data/myplans/myplans.data';
import { COST_SHARE } from '@testing/data/cost-share/cost-share.data';
export let mocks = Object.assign({
  service: {
    router: jasmine.createSpyObj(['navigateByUrl', 'navigate']),
    profileService: jasmine.createSpyObj(['getUserRole', 'setProfile', 'updatePassword', 'fetchProfileInfo', 'updateProfile']),
    validationService: jasmine.createSpyObj(['samePasswordValidator', 'checkConfirmPasswordValidator']),
    homeService: jasmine.createSpyObj([
      'getHomeNavigationResponse',
      'setSessionLinks',
      'getTermsPageResponse',
      'getConfidentialityPageResponse'
    ]),
    alertService: jasmine.createSpyObj(['clearError', 'setAlert']),
    myMedicationDetailsService: jasmine.createSpyObj([
      'setCurrentUserInfo',
      'getCurrentUserInfo',
      'setMyMedicationDetailsRequest',
      'getMyMedicationDetailsRequest',
      'getMedicationDetails'
    ]),
    medicationsService: jasmine.createSpyObj(['getMemBasicInfo']),
    constantsService: jasmine.createSpyObj(['displayMessage']),
    yearEndSummaryService: jasmine.createSpyObj(['getPromoContent', 'getClaimsSummary', 'getClaimsSummaryAmounts']),
    cardService: jasmine.createSpyObj(['getMemberFrontData$', 'getMemberBackData$', 'getMemBasicInfo']),
    orderreplacementService: jasmine.createSpyObj(['getCardPage', 'submitCard']),
    myPillpackService: jasmine.createSpyObj([
      'checkPharmacyUserCreated',
      'getDiscountedVitaminsAndOTCs',
      'getVitaminsAndOTC',
      'getSelectedVitaminsAndOTC'
    ]),
    ssoServise: jasmine.createSpyObj(['getSsoDetails']),
    myPlansService: jasmine.createSpyObj(['getPlanBenefitServices', 'getNetworkString', 'getStyledHtmlText', 'getPlansData']),
    costShareAssistService: jasmine.createSpyObj(['getCostShareDrupalContent','getCostShareContent','getGroupMembers','handleCostShareDrupal'])
  }
});
mocks.service.homeService.getHomeNavigationResponse.and.returnValue(of(homeServiceResponse));
mocks.service.homeService.setSessionLinks.and.returnValue(of(null));
mocks.service.homeService.getTermsPageResponse.and.returnValue(of(mockgetTermsPageResponse));
mocks.service.homeService.getConfidentialityPageResponse.and.returnValue(of(mockgetconfidentialityPageApiResponse));

mocks.service.profileService.getUserRole.and.returnValue(jasAVUserData.getMemProfileApiResponse.userState);
mocks.service.profileService.setProfile.and.returnValue(null);
mocks.service.profileService.fetchProfileInfo.and.returnValue(of(jasAVUserData.getMemProfileApiResponse));
mocks.service.profileService.updateProfile.and.returnValue(of(jasAVUserData.getMemProfileApiResponse));
mocks.service.profileService.updatePassword.and.returnValue(of(updatePassword_success_response));
mocks.service.profileService.authService = mocks.service.authService;
mocks.service.validationService.samePasswordValidator.and.returnValue(() => true);
mocks.service.validationService.checkConfirmPasswordValidator.and.returnValue(() => true);

mocks.service.alertService.clearError.and.returnValue(null);
mocks.service.alertService.setAlert.and.returnValue(null);
mocks.service.myMedicationDetailsService.getCurrentUserInfo.and.returnValue(of(mockmyMedicationservice.getCurrentUserInfo));
mocks.service.myMedicationDetailsService.getMyMedicationDetailsRequest.and.returnValue(
  of(mockmyMedicationservice.getMyMedicationDetailsRequest)
);
mocks.service.myMedicationDetailsService.getMedicationDetails.and.returnValue(of(mockmyMedicationservice.getMedicationDetails));
mocks.service.myMedicationDetailsService.setMyMedicationDetailsRequest.and.returnValue(null);
mocks.service.myMedicationDetailsService.setCurrentUserInfo.and.returnValue(null);
mocks.service.medicationsService.getMemBasicInfo.and.returnValue(of(mockmyMedicationservice.getMemBasicInfo));
mocks.service.yearEndSummaryService.getPromoContent.and.returnValue(of(mockgetPromoContentResponse));
mocks.service.yearEndSummaryService.getClaimsSummary.and.returnValue(of(mockClaimSummaryResponse));
mocks.service.yearEndSummaryService.getClaimsSummaryAmounts.and.returnValue(of(mockSummaryAmounts));
mocks.service.cardService.getMemberFrontData$.and.returnValue(of(mockMemberFrontData));
mocks.service.cardService.getMemberBackData$.and.returnValue(of(mockMemberBackData));
mocks.service.cardService.getMemBasicInfo.and.returnValue(of(mockMemBasicInfo));
mocks.service.orderreplacementService.getCardPage.and.returnValue(of(orderreplacement_service_getcard_success_response));
mocks.service.orderreplacementService.submitCard.and.returnValue(of(orderreplacement_service_submitCard_success_response));
mocks.service.myPillpackService.checkPharmacyUserCreated.and.returnValue({
  existingUser: true,
  partner: { id: '5d5fda40bb9b76195811176f' }
});
mocks.service.myPillpackService.getDiscountedVitaminsAndOTCs.and.returnValue(mockDiscountedVitaminsAndOTCs);
mocks.service.myPillpackService.getVitaminsAndOTC.and.returnValue(of(mockVitaminsAndOTC));
mocks.service.myPillpackService.getSelectedVitaminsAndOTC.and.returnValue(mockSelectedVitaminsAndOTCResponse);
mocks.service.myPillpackService.getSelectedVitaminsAndOTC.and.returnValue(mockSelectedVitaminsAndOTCResponse);
mocks.service.ssoServise.getSsoDetails.and.returnValue(of({ ssomsg: { samlUrl: 'sso/url', samlValue: 'sampleValue' } }));
mocks.service.myPlansService.getPlanBenefitServices.and.returnValue(of(mockPlanBenefitServicesResponse));
mocks.service.myPlansService.getNetworkString.and.returnValue(of(null));
mocks.service.myPlansService.getStyledHtmlText.and.returnValue(of(null));
mocks.service.myPlansService.getPlansData.and.returnValue(of(mockPlanResponse));
mocks.service.costShareAssistService.getCostShareDrupalContent.and.returnValue(of(COST_SHARE[0]));

export class NavMock {
  public pop(): any {
    return new Promise((resolve: any): void => {
      resolve();
    });
  }

  public push(): any {
    return new Promise((resolve: any): void => {
      resolve();
    });
  }

  public getActive(): any {
    return {
      instance: {
        model: 'something'
      }
    };
  }

  public setRoot(): any {
    return true;
  }

  public navigateRoot(): any {
    return new Promise((resolve: any): void => {
      resolve();
    });
  }

  public registerChildNav(nav: any): void {
    return;
  }
}
