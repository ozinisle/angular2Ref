const { exec } = require('child_process');
const semver = require('semver');

const REQUIRED_VERSION = '^12.3';

exec('xcodebuild -version', (error, stdout, stderr) => {
  if (error) {
    console.error('Could not determine Xcode version.');
    process.exit(1);
  }
  let currentVersion = stdout.split('Xcode ').join('').split("\n")[0];

  /*
   * The satisfies() method requires current version in the format 'x.x.x',
   * so pad the version array with minor/patch levels if missing.
   */
  currentVersion = currentVersion.split('.');
  while(currentVersion.length < 3) {
    currentVersion.push(0);
  }
  const currentSemVer = currentVersion.join('.');

  const isValid = semver.satisfies(currentSemVer, REQUIRED_VERSION);
  if (!isValid) {
    const red = '\x1b[31m';
    console.error(
      `${red}Xcode version satisfying ${REQUIRED_VERSION} is required,`
      + ` but the selected version is ${currentVersion}.`
      + `\n\nPlease select the correct version using the following terminal command (modify path as appropriate):`
      + `\nsudo xcode-select -s "/Applications/Xcode [VERSION].app/Contents/Developer"`
    );
    process.exit(1);
  }
});
