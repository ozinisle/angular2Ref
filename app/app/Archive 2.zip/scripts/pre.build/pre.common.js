
const config = require('./config.json');

function getAppVersion() {
    let version = config.version;
    return version;
}

function getBuildNumber() {
    let buildNumber = config.build;
    if (process.env.TAG != null && process.env.TAG !== '') {
        buildNumber = process.env.TAG;
    } else if (process.env.RELEASE != null && process.env.RELEASE != '') {
        buildNumber = process.env.RELEASE + "." + process.env.BUILD_NUMBER;;
    } 
    return buildNumber;
}

exports.getAppVersion = getAppVersion;
exports.getBuildNumber = getBuildNumber;