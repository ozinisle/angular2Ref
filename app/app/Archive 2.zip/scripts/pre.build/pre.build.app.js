// Required packages
const common = require('./pre.common.js');
const fs = require("fs");
const plist = require("plist");
const replace = require('replace-in-file');
const xmlpoke = require('xmlpoke');

const config = require('./config.json');
const capConfig = require('../../capacitor.config.json');
const androidCapConfig = require('../../android/app/src/main/assets/capacitor.config.json');
const iosCapConfig = require('../../ios/App/App/capacitor.config.json');
const packageFile = require('../../package.json');
const ionicConfig = require('../../ionic.config.json');
const plistParsedData = plist.parse(fs.readFileSync("./ios/App/App/Info.plist", 'utf8'));
const buildGradleFile = './android/app/build.gradle';
const applicationFile = './android/app/src/main/java/com/bluecrossma/BCBSMA/test/Application.java'
const mainActivityFile = './android/app/src/main/java/com/bluecrossma/BCBSMA/test/MainActivity.java';
const stringXml = './android/app/src/main/res/values/strings.xml';
const androidManifestXml = './android/app/src/main/AndroidManifest.xml';

const platform = process.env.CI_PLATFORM;
const env = process.env.BUILD_ENV;
const isAndroid = platform === 'android';
const isIOS = platform === 'ios';
const isProduction = env === 'production';
const appVersion = common.getAppVersion();
let configuration = config[env];
const pod = process.env.POD;
googleServicesFile = require(`../../android/app/${configuration.googleService}`);

const isAppflowBuild = !!process.env.CI_BUILD_NUMBER && process.env.CI_BUILD_NUMBER !== 'local';


function changeAppVersion(appversion) {
  if (isAndroid) {
    const appversionAndroid = {
      files: buildGradleFile,
      from: /versionName ((?:'|").*(?:'|"))/,
      to: `versionName "${appversion}"`,
      allowEmptyPaths: false,
    };
    replace.sync(appversionAndroid);
  } else if (isIOS) {
    plistParsedData["CFBundleShortVersionString"] = appversion;
  }
}

function changeAppPackageId(appPackageId) {
  const appid = pod && !isProduction ? `com.bluecrossma.BCBSMA.${pod}` : appPackageId;

  capConfig.appId = appid;
  if (isAndroid) {
    xmlpoke(stringXml, function (xml) {
      xml.set('/resources/string[@name="package_name"]', appid);
    });

    const manifest = {
      files: androidManifestXml,
      from: /\"com.*\.MainActivity\"/,
      to: `"${appid}.MainActivity"`,
      allowEmptyPaths: false,
    };
    replace.sync(manifest);

    xmlpoke(androidManifestXml, function (xml) {
      xml.set('/manifest/@package', appid);
    });

    const packageId = {
      files: buildGradleFile,
      from: /applicationId ((?:'|").*(?:'|"))/,
      to: `applicationId "${appid}"`,
      allowEmptyPaths: false,
    };
    replace.sync(packageId);

    const mainActivity = {
      files: mainActivityFile,
      from: /package\s*.*\s*/,
      to: `package ${appid};\n\n`,
      allowEmptyPaths: false,
    };
    replace.sync(mainActivity);

    const application = {
      files: applicationFile,
      from: /package\s*.*\s*/,
      to: `package ${appid};\n\n`,
      allowEmptyPaths: false,
    };
    replace.sync(application);

    androidCapConfig.appId = appid;
  } else if (isIOS) {
    plistParsedData["CFBundleIdentifier"] = appid;
    iosCapConfig.appId = appid;
  }
}

function changeAppName(appName) {
  capConfig.appName = appName;
  if (isAndroid) {
    xmlpoke(stringXml, function (xml) {
      xml.set('/resources/string[@name="app_name"]', appName);
      xml.set('/resources/string[@name="title_activity_main"]', appName);
    });

    androidCapConfig.appName = appName;
  } else if (isIOS) {
    plistParsedData["CFBundleDisplayName"] = appName;
    plistParsedData["CFBundleName"] = appName;
    iosCapConfig.appName = appName;
  }
}

function changeAppId(appId) {
  packageFile.cordova.plugins["cordova-plugin-ionic"].APP_ID = appId;
  ionicConfig.id = appId;
  if (isAndroid) {
    xmlpoke(stringXml, function (xml) {
      xml.set('/resources/string[@name="ionic_app_id"]', appId);
    });
  } else if (isIOS) {
    plistParsedData["IonAppId"] = appId
  }
}

function changeUrlScheme(urlScheme, urlScheme1) {
  if (isAndroid) {
    xmlpoke(stringXml, function (xml) {
      xml.set('/resources/string[@name="custom_url_scheme"]', urlScheme);
      xml.set('/resources/string[@name="custom_url_scheme_1"]', urlScheme1);
    });
  } else if (isIOS) {
    plistParsedData["CFBundleURLSchemes"] = urlScheme;
    if ( urlScheme1 ) {
      plistParsedData["CFBundleURLTypes"][0].CFBundleURLSchemes = [urlScheme, urlScheme1];
    } else {
      plistParsedData["CFBundleURLTypes"][0].CFBundleURLSchemes = [urlScheme];
    }
  }
}

function changeChannelName(channelName) {
  packageFile.cordova.plugins["cordova-plugin-ionic"].CHANNEL_NAME = channelName;
  if (isAndroid) {
    xmlpoke(stringXml, function (xml) {
      xml.set('/resources/string[@name="ionic_channel_name"]', channelName);
    });
  } else if (isIOS) {
    plistParsedData["IonChannelName"] = channelName;
  }
}

function changeUpdateMethod(updateMethod) {
  packageFile.cordova.plugins["cordova-plugin-ionic"].UPDATE_METHOD = updateMethod;
  if (isAndroid) {
    xmlpoke(stringXml, function (xml) {
      xml.set('/resources/string[@name="ionic_update_method"]', updateMethod);
    });
  } else if (isIOS) {
    plistParsedData["IonUpdateMethod"] = updateMethod;
  }
}

function changeSwrveAppId(swrveAppId) {
  if (isAndroid) {
    xmlpoke(stringXml, function (xml) {
      xml.set('/resources/string[@name="swrve_app_id"]', swrveAppId);
    });
  } else if (isIOS) {
    plistParsedData["swrveAppId"] = swrveAppId;
  }
}

function changeSwrveApiKey(swrveApiKey) {
  if (isAndroid) {
    xmlpoke(stringXml, function (xml) {
      xml.set('/resources/string[@name="swrve_api_key"]', swrveApiKey);
    });
  } else if (isIOS) {
    plistParsedData["swrveApiKey"] = swrveApiKey;
  }
}

function changeSwrveAppGroupIdentifier(swrveAppGroupIdentifier) {
  if (isIOS) {
    const groupIdentifier = pod && !isProduction ? `group.com.bluecrossma.BCBSMA.${pod}` : swrveAppGroupIdentifier;
    plistParsedData["swrveAppGroupIdentifier"] = groupIdentifier;
  }
}

function changePrivacyOnBackground(isprod) {
  capConfig.cordova.preferences.PrivacyOnBackground = isprod.toString();
}

function changeGoogleServices(isprod) {
  if(!isprod && pod) {
    googleServicesFile.client[0].client_info.android_client_info.package_name = `com.bluecrossma.BCBSMA.${pod}`;
  } 
}

function changeAppConfig() {
  console.log('[pre.build.app] Modifying APP configuration for env ' + env + ' and platform ' + platform);
  changeAppVersion(appVersion);
  changePrivacyOnBackground(isProduction);
  changeUrlScheme(configuration.urlScheme, configuration.urlScheme1);
  changeSwrveAppId(configuration.swrveAppId);
  changeSwrveApiKey(configuration.swrveApiKey);
  changeSwrveAppGroupIdentifier(configuration.swrveAppGroupIdentifier);
  changeGoogleServices(isProduction);
  if (!isAppflowBuild) {
    console.log('[pre.build.app] Non-Appflow build detected, modifying required configuration');
    const appPackageId = isAndroid ? configuration.androidAppPackageId : configuration.iosAppPackageId;
    changeAppPackageId(appPackageId);
    changeAppName(configuration.appName);
    changeAppId(configuration.appId);
    changeChannelName(configuration.channelName);
    changeUpdateMethod(configuration.updateMethod);
  }

  //capacitor.config.json
  fs.writeFileSync('./capacitor.config.json', JSON.stringify(capConfig, null, 2));

  //package.json
  fs.writeFileSync('./package.json', JSON.stringify(packageFile, null, 2));

  //ionic.config.json
  fs.writeFileSync('./ionic.config.json', JSON.stringify(ionicConfig, null, 2));

  if (isAndroid) {
    //Android capacitor.config.json
    fs.writeFileSync('./android/app/src/main/assets/capacitor.config.json', JSON.stringify(androidCapConfig, null, 2));
  
    //Replacing data in google-services.json file 
    fs.writeFileSync('./android/app/google-services.json', JSON.stringify(googleServicesFile, null, 2));
  }

  if (isIOS) {
    //info.plist
    const xmlData = plist.build(plistParsedData);
    fs.writeFileSync("./ios/App/App/Info.plist", xmlData);

    //IOS capacitor.config.json
    fs.writeFileSync('./ios/App/App/capacitor.config.json', JSON.stringify(iosCapConfig, null, 2));
  }
}

exports.changeAppConfig = changeAppConfig;