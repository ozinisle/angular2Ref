var replace = require('replace-in-file');
const fs = require('fs')

/**
 * Get all config from code and generate a JSON file in assets
 */
function generateEnvConfigFile() {
    const config = {};
    
    const data = fs.readFileSync('./src/environments/environment.config.ts', 'utf8');

    var reg = new RegExp(".*DEFAULT_VALUES:.*?(\\{.*?\\})", 's');
    const match = data.match(reg); 
    eval("var result = " + match[1]);
    config.DEFAULT = result;

    for (var i of ['PERF', 'DEV', 'QA', 'UAT', 'PROD']) {
        var reg = new RegExp(".*\\[EnvironmentEnum." + i + "\\]:\\s*({.*?})", 's');
        const match = data.match(reg);
        eval("var result = " + match[1]);
        config[i] = result;
    }
    const jsonData = JSON.stringify(config);
    const destination = "./src/assets/config.json"
    fs.writeFileSync(destination, jsonData);
    console.log('[pre.build.config] Config extract generated:', destination);
}

exports.generateEnvConfigFile = generateEnvConfigFile;
