const envConfig = require('./pre.build.envconfig.js');
const version = require('./pre.build.version.js');

console.log('[pre.build] !!!!!!!!! Running prebuild script !!!!!!!!!!!');
console.log(`[pre.build] BUILD_ENV = ${process.env.BUILD_ENV}`);
console.log(`[pre.build] CI_PLATFORM = ${process.env.CI_PLATFORM}`);
console.log(`[pre.build] BUILD_NUMBER = ${process.env.BUILD_NUMBER}`);
console.log(`[pre.build] RELEASE = ${process.env.RELEASE}`);

envConfig.generateEnvConfigFile();

if (process.env.CI_PLATFORM != null && process.env.CI_PLATFORM != "") {
    version.updateHamburgerVersionAndBuild();
    if (process.env.CI_PLATFORM == "ios" || process.env.CI_PLATFORM == "android") {
        const builApp = require('./pre.build.app.js');
        builApp.changeAppConfig();
    }
}
console.log('[pre.build] END Running prebuild script');