var replace = require('replace-in-file');
const fs = require('fs')
const common = require('./pre.common.js');

const VERSION_FILE = 'src/environments/version.ts';

function updateHamburgerVersionAndBuild() {
    const version = common.getAppVersion();
    const buildNumber = common.getBuildNumber();

    console.log(`[pre.build.version] Version: ${version}, build number: ${buildNumber}`);

    const optionsVersion = {
        files: VERSION_FILE,
        from: /{BUILD_VERSION}/g,
        to: version,
        allowEmptyPaths: false,
    };
    replace.sync(optionsVersion);
    
    const optionsTimestamp = {
        files: VERSION_FILE,
        from: /{BUILD_TIMESTAMP}/g,
        to: new Date().toISOString().slice(0, 10),
        allowEmptyPaths: false,
    };
    replace.sync(optionsTimestamp);
    
    const optionsBuildNumber = {
        files: VERSION_FILE,
        from: /{BUILD_NUMBER}/g,
        to: buildNumber,
        allowEmptyPaths: false,
    };
    replace.sync(optionsBuildNumber);
}

exports.updateHamburgerVersionAndBuild = updateHamburgerVersionAndBuild;
