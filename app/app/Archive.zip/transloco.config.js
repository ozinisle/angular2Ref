module.exports = {
  rootTranslationsPath: 'src/assets/i18n/',
  langs: ['en'],
  keysManager: {}
};