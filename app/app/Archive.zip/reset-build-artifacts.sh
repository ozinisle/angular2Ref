git checkout capacitor.config.json
git checkout ios/App/App.xcodeproj/project.pbxproj
git checkout ios/App/App/Info.plist
git checkout ios/App/App/capacitor.config.json
git checkout ios/App/Podfile
git checkout android/app/src/main/assets/capacitor.config.json
git checkout src/environments/version.ts
git checkout capacitor.config.json
git checkout android/app/build.gradle
git checkout android/app/src/main/assets/capacitor.config.json
git checkout android/app/src/main/res/values/strings.xml
git checkout android/app/src/main/res/xml/network_security_config.xml
git checkout android/app/src/main/AndroidManifest.xml
git status
