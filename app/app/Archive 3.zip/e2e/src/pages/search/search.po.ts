
import {AppPage} from '../../app.po'

export class SearchPage extends AppPage {

}
