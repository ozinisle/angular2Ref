import { SearchPage } from './search.po';
import { element, by, browser } from 'protractor';

describe('bcbsma App', () => {
  const page = new SearchPage();
  browser.driver.manage().window().maximize();

  it('should go to home page', () => {
    page.navigateTo('/');
    browser.sleep(1000);
  });
  it('should login', () => {
    page.navigateTo('/login');
    browser.sleep(2000);
    element(by.css('input[name="ion-input-0"]')).click();
    element(by.css('input[name="ion-input-0"]')).sendKeys('carolyn.bondqa@yopmail.com');
    element(by.css('input[name="ion-input-1"]')).click();
    element(by.css('input[name="ion-input-1"]')).sendKeys('Password1$');
    element(by.css('form>ion-button')).click();
    browser.sleep(5000);
  });
  it('should perform valid search', () => {
    page.navigateTo('/');
    browser.sleep(2000);
    element(by.css('.search-header-icons')).click();
    browser.sleep(1000);
    element(by.css('input[name="ion-input-0"]')).click();
    element(by.css('input[name="ion-input-0"]')).sendKeys('family');
    element(by.css('ion-button:last-of-type')).click();
    browser.sleep(2000);
  });

  it('should perform second valid search on search page', () => {
    element(by.css('input[name="ion-input-1"]')).click();
    element(by.css('input[name="ion-input-1"]')).sendKeys('plan');
    element.all(by.css('ion-button')).last().click();
    browser.sleep(5000);
  });

  it('should go to benefit details page', () => {
    // element(by.css('app-search:nth-of-type(3)>ion-content>ion-list:nth-of-type(1)>ion-item:nth-of-type(3)>ion-item-group>ion-item:nth-of-type(1)>ion-select')).click();
    // browser.sleep(2000);
    // element(by.css('button:nth-of-type(2)>span')).click();
    // browser.sleep(2000);
    // element(by.css('input[name="ion-input-4"]')).click();
    // browser.sleep(2000);
    // element(by.css('app-search:nth-of-type(3)>ion-content>ion-list:nth-of-type(1)>ion-item:nth-of-type(1)>form>ion-item')).click();
    // browser.sleep(2000);
    // element(by.css('input[name="ion-input-4"]')).sendKeys('plan');
    // browser.sleep(2000);
  });
  it('should perform no results search', () => {
    page.navigateTo('/search');
    browser.sleep(20000);
    element(by.css('input[name="ion-input-0"]')).clear();
    element(by.css('input[name="ion-input-0"]')).sendKeys('qwerty');
    element(by.css('ion-button:last-of-type')).click();
    browser.sleep(5000);
  });
  it('wait before completing the test run', () => {
    browser.sleep(10000);
  });
});
