import {AppPage} from '../../app.po'
import { element, by } from 'protractor';

export class LoginPage extends AppPage {
    getUserNameField() {
        return element(by.tagName('input')[0]);
    }
    getPasswordField() {
        return element(by.tagName('input')[1]);
    }
    getLoginButton() {
        return element(by.tagName('input')[2]);
    }
}
