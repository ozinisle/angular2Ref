import { browser, by, element } from 'protractor';

export class AppPage {
  navigateTo(page?: string) {
    return browser.get(page ? page : '/');
  }

  getAppRoot() {
    return element(by.css('app-root'));
  }
}
