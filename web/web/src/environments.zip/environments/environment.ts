import { EnvironmentConfig } from '../app/services/environement/environment.config';
import { EnvironmentService } from '../app/services/environement/environment.service';

export const environmentService = new EnvironmentService();
export const environment: EnvironmentConfig = environmentService.initConfig();

if (!environmentService.isProdEnv()) {
  console.log('%cSelected config:', 'background: #222; color: #bada55', environmentService.getEnv(), environmentService.getAllConfig());
}

export const version = {
  appversion: '{BUILD_VERSION}',
  timestamp: '{BUILD_TIMESTAMP}'
};
