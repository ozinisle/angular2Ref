import { PartialEnvironmentConfig } from '../app/services/environement/environment.config';

export const environmentUAT: PartialEnvironmentConfig = {
  uitxnid: true,
  dynamicTagLink: '//assets.adobedtm.com/launch-ENfd28d85532164d63933fc8f696980fe5-staging.min.js',
  screenNavigationSLA: 3000,
  tokenbaseurl: 'https://mobilememberstage.bluecrossma.com',
  /*
  tokensEndPoint: '/dglwebapi1_uat/mobilekeyservice/v1/gettokens',
  serviceUrl: 'https://bcbsma-uat.apigee.net/member/web/v1/',
  serviceUrlV2: 'https://bcbsma-uat.apigee.net/member/web/v2/',
  --------------------------------------------------------------
  */
  tokensEndPoint: '/dglwebapi1_uat/mobilekeyservice/v1/gettokens',
  serviceUrl: 'https://bcbsma-uat.apigee.net/member/web/v1/',
  serviceUrlV2: 'https://bcbsma-uat.apigee.net/member/web/v2/',
  serviceUrlV3: 'https://bcbsma-uat.apigee.net/member/web/v3/',
  privacyUrl: 'https://myblueapi.bluecrossma.com/page/',
  drupalTestUrl: 'https://games.bluecrossma.com',
  enableconsolelog: false,
  drupalHomeUrl: 'https://myblue.bluecrossma.com/',
  contactus: 'https://myblue.bluecrossma.com/contact-us',
  educationCenter: 'https://myblue.bluecrossma.com/health-plan/plan-education-center',
  drupalsecureinquiry: 'https://myblue.bluecrossma.com/form/inquiry',
  leafLetUrl: 'https://api.mapbox.com/',
  impersonation: false,
  ssoInboundAuthenticationUrl: 'https://bcbsma-uat.apigee.net/web/sso/inbound/authentication/',
  ssoInboundAuthUrl: 'https://bcbsma-uat.apigee.net/mock/sso/inbound/internalidp',
  ssoInboundAuthorize: 'https://bcbsma-uat.apigee.net/web/sso/inbound/',
  loadadrum: false,
  stripeLink: 'https://js.stripe.com/v3/',
  stripeKeyString: 'pk_test_gC5yvDgq6qs1LQ1xiYN5im0B',
  LogRocketAppID: 'bcbsma/internal-network-uat',
  LogRocketEndPoint: 'https://bcbsma-uat.apigee.net/member/web/v1/logrocket',
  loadLogRocket: true,
  eyeMedBaseUrl: 'https://memberuat.eyemedvisioncare.com',
  enrollServiceUrl: 'https://bcbsma-uat.apigee.net/enroll/web/v1/',
  rewardsServiceUrl: 'https://bcbsma-uat.apigee.net/digital/rewards/v1/my-rewards',
  displayVirtualVisit: true, //Wellconnection Telehealth feature flag
  featureVirginPulseSsoEnabled: false,
  enableNewPersonalizedHub: false
};
