// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --prod --env=prod` then `environment.prod.ts` will be used instead.

import { PartialEnvironmentConfig } from '../app/services/environement/environment.config';

export const environmentDEV: PartialEnvironmentConfig = {
  uitxnid: true,
  dynamicTagLink: '//assets.adobedtm.com/launch-ENfd28d85532164d63933fc8f696980fe5-staging.min.js',
  screenNavigationSLA: 3000,
  tokenbaseurl: 'https://mobilememberstage.bluecrossma.com',
  tokensEndPoint: '/memwebapi1_cde/mobilekeyservice/v1/gettokens',
  serviceUrl: 'https://bcbsma-dev.apigee.net/member/web/v1/',
  serviceUrlV2: 'https://bcbsma-dev.apigee.net/member/web/v2/',
  serviceUrlV3: 'https://bcbsma-dev.apigee.net/member/web/v3/',
  privacyUrl: 'https://myblueapi.bluecrossma.com/page/',
  drupalTestUrl: 'https://games.bluecrossma.com',
  enableconsolelog: true,
  drupalHomeUrl: 'https://myblue.bluecrossma.com/',
  contactus: 'https://myblue.bluecrossma.com/contact-us',
  educationCenter: 'https://myblue.bluecrossma.com/health-plan/plan-education-center',
  drupalsecureinquiry: 'http://20181010myblue.bluecrossma.acsitefactory.com/inquiry',
  leafLetUrl: 'https://api.mapbox.com/',
  impersonation: false,
  ssoInboundAuthenticationUrl: 'https://bcbsma-test.apigee.net/web/sso/inbound/authentication/',
  ssoInboundAuthUrl: 'https://bcbsma-test.apigee.net/mock/sso/inbound/internalidp',
  ssoInboundAuthorize: 'https://bcbsma-test.apigee.net/web/sso/inbound/',
  loadadrum: false,
  stripeLink: 'https://js.stripe.com/v3/',
  stripeKeyString: 'pk_test_gC5yvDgq6qs1LQ1xiYN5im0B',
  LogRocketAppID: 'bcbsma/internal-network-dev',
  LogRocketEndPoint: 'https://bcbsma-test.apigee.net/member/web/v1/logrocket',
  loadLogRocket: false,
  eyeMedBaseUrl: 'https://memberuat.eyemedvisioncare.com',
  enableAngularProdMode: false,
  enrollServiceUrl: 'https://bcbsma-test.apigee.net/enroll/web/v1/',
  rewardsServiceUrl: 'https://bcbsma-test.apigee.net/digital/rewards/v1/my-rewards',
  featureVirginPulseSsoEnabled: false,
  enableNewPersonalizedHub: false
};
