// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --prod --env=prod` then `environment.prod.ts` will be used instead.

import { PartialEnvironmentConfig } from '../app/services/environement/environment.config';

export const environmentDEMO: PartialEnvironmentConfig = {
  uitxnid: true,
  dynamicTagLink: '//assets.adobedtm.com/launch-ENb586d4bf049c44a487a019aced315add.min.js',
  screenNavigationSLA: 3000,
  tokenbaseurl: 'https://mobilemember.bluecrossma.com',
  tokensEndPoint: '/dglwebapi1/mobilekeyservice/v1/gettokens',
  serviceUrl: 'https://bcbsma-prod.apigee.net/member/web/v1/',
  serviceUrlV2: 'https://bcbsma-prod.apigee.net/member/web/v2/',
  serviceUrlV3: 'https://bcbsma-prod.apigee.net/member/web/v3/',
  privacyUrl: 'https://myblueapi.bluecrossma.com/page/',
  drupalTestUrl: 'https://myblueapi.bluecrossma.com',
  enableconsolelog: false,
  drupalHomeUrl: 'https://bcbsma.info/member',
  contactus: 'https://myblue.bluecrossma.com/contact-us',
  educationCenter: 'https://myblue.bluecrossma.com/health-plan/plan-education-center',
  drupalsecureinquiry: 'https://myblue.bluecrossma.com/form/inquiry',
  leafLetUrl: 'https://api.mapbox.com/',
  impersonation: false,
  ssoInboundAuthenticationUrl: 'https://bcbsma-prod.apigee.net/web/sso/inbound/authentication/',
  ssoInboundAuthUrl: 'https://bcbsma-prod.apigee.net/mock/sso/inbound/internalidp',
  ssoInboundAuthorize: 'https://bcbsma-prod.apigee.net/web/sso/inbound/',
  loadadrum: true,
  stripeLink: 'https://js.stripe.com/v3/',
  stripeKeyString: 'pk_live_ciPsaWkjHoAbYszoLlVedv06',
  LogRocketAppID: 'bcbsma/internal-network-prod',
  LogRocketEndPoint: 'https://bcbsma-prod.apigee.net/member/web/v1/logrocket',
  loadLogRocket: true,
  liveChatServerUrl: 'https://ciscochat.bluecrossma.com/system',
  liveChatEntryPoint: 1012,
  eyeMedBaseUrl: 'https://member.eyemedvisioncare.com',
  enrollServiceUrl: 'https://bcbsma-prod.apigee.net/enroll/web/v1/',
  rewardsServiceUrl: 'https://bcbsma-prod.apigee.net/digital/rewards/v1/my-rewards',
  displayVirtualVisit: true, //Wellconnection Telehealth feature flag
  featureVirginPulseSsoEnabled: false,
  enableNewPersonalizedHub: false
};
