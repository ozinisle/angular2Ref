import { ModuleWithProviders } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FakeRouteTargetComponent } from './fake-components';
export const fakeRoutes: Routes = [
    {
        path: '',
        redirectTo: '/login',
        pathMatch: 'full'
    },
    {
        path: 'fad',
        // canActivate: [AuthGuard, ScopeGuard],
        component: FakeRouteTargetComponent
    },
    {
        path: 'myclaims',
        component: FakeRouteTargetComponent
    },
    {
        path: 'myeobs',
        component: FakeRouteTargetComponent
    },
    {
        path: 'member-migration',
        component: FakeRouteTargetComponent
    },
    {
        path: 'myplans',
        component: FakeRouteTargetComponent
    },
    {
        path: 'mycards',
        component: FakeRouteTargetComponent
    },
    {
        path: 'mypreferences',
        component: FakeRouteTargetComponent
    },
    {
        path: 'mydedco',
        component: FakeRouteTargetComponent
    },
    {
        path: 'request-estimate',
        component: FakeRouteTargetComponent
    },
    {
        path: 'orderreplacement',
        component: FakeRouteTargetComponent
    },
    {
        path: 'mymedications',
        component: FakeRouteTargetComponent
    },
    {
        path: 'sso/vitals',
        component: FakeRouteTargetComponent
    },
    {
        path: 'sso/cerner',
        component: FakeRouteTargetComponent
    },
    {
        path: 'sso/alegeus',
        component: FakeRouteTargetComponent
    },
    {
        path: 'sso/heathequity',
        component: FakeRouteTargetComponent
    },
    {
        path: 'sso/connecture',
        component: FakeRouteTargetComponent
    },
    {
        path: 'sso/expressscript',
        component: FakeRouteTargetComponent
    },
    {
        path: 'mydoctors',
        component: FakeRouteTargetComponent
    },
    {
        path: 'register',
        component: FakeRouteTargetComponent
    },
    {
        path: 'login',
        component: FakeRouteTargetComponent
    },
    {
        path: 'account',
        component: FakeRouteTargetComponent
    },
    {
        path: 'myprofile',
        component: FakeRouteTargetComponent
    },
    {
        path: 'message-center',
        component: FakeRouteTargetComponent
    },
    {
        path: 'home',
        component: FakeRouteTargetComponent
    },
    {
        path: 'myaccount',
        component: FakeRouteTargetComponent
    },
    {
        path: 'vdk',
        component: FakeRouteTargetComponent
    },
    {
        path: 'notification-preferences',
        component: FakeRouteTargetComponent
    },
    {
        path: 'pages',
        component: FakeRouteTargetComponent
    },
    // {
    //   path: '404',
    //   component: NotfoundComponent
    // },
    {
        path: '**',
        component: FakeRouteTargetComponent
    }
];

export const fakeAppRouter: ModuleWithProviders = RouterModule.forRoot(fakeRoutes);
