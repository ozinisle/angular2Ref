import { HttpEventType } from '@angular/common/http';
import { of } from 'rxjs/observable/of';
import { FadDoctorRatingsResponseModel } from '../../app/pages/fad/modals/fad-doctor-profile-details.model';
import { GeneralError } from '../../app/shared/models/generic-app.model';
import { COST_SHARE } from '../data/cost-share/cost-share.data';
import { eob_resolver_mock_data } from '../data/eob/eob.component.data';
import { AuthenticatedUserComponentData } from '../data/landing/authenticated-user.component.data';
import { getFinanceBalanceData_response } from '../data/landing/getFinanceBalanceData';
import { homeLeaderBoardSlider_response } from '../data/landing/home-leaderboard-slider.data';
import { verifyfunauthuser_response } from '../data/my-account/confirm-identity/verifyfunauthuser.data';
import { verifyfpuser_response } from '../data/my-account/forgot-password/verifyfpuser.data';
import { verifyfunuser_response } from '../data/my-account/forgot-username/verifyfunuser.data';
import { verifyfphintanswer_response } from '../data/my-account/fp-confirm-identity/verifyfphintanswer.data';
import { jasAVUserData } from '../data/my-profile/avUser.data';
import { getDemographicInfo_response } from '../data/my-profile/getDemographicInfo.data';
import { updateDemographicInfo_success_response } from '../data/my-profile/updateDemographicInfo.data';
import { updatePassword_success_response } from '../data/my-profile/updatePassword.data';
import { getClaimBenefitsLink_response } from '../data/myClaims/getClaimBenefitsLink.data';
import { getclaimdetails_response } from '../data/myClaims/getclaimdetails.data';
import { getclaimprocessingstatus_response } from '../data/myClaims/getclaimprocessingstatus.data';
import { getclaimssummary_response } from '../data/myClaims/getclaimssummary.data';
import { myded_co_component_resolver_data } from '../data/myded-co/myded-co.component.data';
import { getDependents_response } from '../data/myMedications/getDependents.data';
import { authService_getTokens_response } from '../data/services/authService.data';
import { fpocontentService_mydedco_fetchContent_data } from '../data/services/fpocontentService.data';
import { consumerEnrollmentResponse } from '../data/well-connection/well-connection.component.data';
import { mockConstants } from './mocks.constants';

export let mocks = Object.assign({
  service: {
    fpocontentService: jasmine.createSpyObj(['fetchContent', 'generateRandomNum']),
    eobService: jasmine.createSpyObj(['getEobList', 'getEOBDocumentLink']),
    globalService: jasmine.createSpyObj([
      'setAdobe',
      'callSatellite',
      'clearMemberData',
      'fetchMemberData',
      'getPostLoginSessionObject',
      'setMemberData',
      'handleError',
      'handleLogin',
      'login',
      'isAuthenticated',
      'redirectionRoute',
      'getRedirectionPageUrl',
      'getUrlBasedUponLastAuthText',
      'getUrlWhenNoLogin',
      'isValidMemberIdEntered',
      'isValidNameEntered',
      'getUrlWhenMemberIdIsNull',
      'getUrlBasedUponLastAuthResult',
      'memAuth',
      'sendaccesscode',
      'markFormGroupTouched',
      'markFormGroupUnTouched',
      'logout',
      'onLogoutCallBack',
      'isMobile',
      'getConfidentiality',
      'getTermsAndConditions',
      'clearGlobalSessionDetails',
      'togglePasswordType',
      'groupBy',
      'getConsent',
      'getProgramGroups',
      'getPreferences',
      'updatePreferences',
      'updateConsent',
      'updateFADStatus',
      'fadLoaded$'
    ]),

    authService: jasmine.createSpyObj([
      'fetchSession',
      'getTokens',
      'persistSession',
      'getUpdatedTokens',
      'isAuthenticated',
      'getScopeName',
      'getAuthToken',
      'getRefreshToken',
      'getExpAccessTokenTime',
      'refreshToken',
      'authTokenInfoFromSession',
      'jwtContentTypeEncoded',
      'setDependentsList',
      'getDependentsList',
      'logout',
      'clearSession',
      'storeUserState',
      'fetchUserState',
      'setRtmsMode',
      'removeRtmsMode',
      'getRtmsMode',
      'getFadHccsFlag',
      'impersonation',
      'persistSession',
      'isUserActive',
      'hasMembershipStarted'
    ]),

    landingService: jasmine.createSpyObj([
      'loadArticle',
      'getCarouselItemDetails',
      'getFinanceBalanceData',
      'getFinanceBalancChartData',
      'transformChartData',
      'convertPositiveValue',
      'isHsaAccount',
      'transformChartDataNew',
      'getfinancialHeaderText',
      'transformFinanceChartData',
      'getHomepageinfo',
      'getDedcoInfo,',
      'getLineChartOptions',
      'heroBannerItemsDetails',
      'promoDetails'
    ]),

    alertService: jasmine.createSpyObj(['clearError', 'getAlert', 'setAlert', 'setAlertObj', 'setError']),

    myDedCoService: jasmine.createSpyObj([
      'getDeductiblesAndCoinsuranceInfo',
      'getIndividualDeductiblesAndCoinsuranceInfo',
      'getDependents',
      'sortDeductiblesData',
      'getSortedList'
    ]),

    myMedicationDetailsService: jasmine.createSpyObj([
      'setCurrentUserInfo',
      'getCurrentUserInfo',
      'setMyMedicationDetailsRequest',
      'getMyMedicationDetailsRequest',
      'getMedicationDetails'
    ]),

    authHttp: jasmine.createSpyObj([
      'get',
      'postWithCallBack',
      'post',
      'isAnyErrorModalAlreadyOpen',
      'isModalOpen',
      'showServiceErrorModalPopup',
      'handleError',
      'put',
      'delete',
      'encryptPostJwt',
      'uuid',
      'encryptPost',
      'CaptureAPIErrorInAdobe',
      'handleDecryptedResponse',
      'handleRequest',
      'encryptPayload',
      'decryptPayload',
      'hideSpinnerLoading',
      'showSpinnerLoading',
      'isArgument',
      'jwt',
      'login',
      'postlogin',
      'getRequestLoginOptionArgs',
      'getRequestOptionArgs',
      'sessionid'
    ]),

    validationService: jasmine.createSpyObj([
      'getValidatorErrorMessage',
      'samePasswordValidator',
      'checkConfirmPasswordValidator',
      'invalidPasswordValidatorWrapper',
      'invalidPasswordValidator',
      'emailDomainValidator',
      'passwordStatus',
      'mobileValidator',
      'mobileRegisterValidator',
      'phoneValidator',
      'spaceValidator',
      'noWhitespaceValidator',
      'emailValidator',
      'specialCharactersValidator',
      'trailingSpaceValidator',
      'hintAnswerValidator',
      'validateState',
      'alphaNumericValidator',
      'ssnValidator',
      'medicareNumberValidator',
      'dobValidator',
      'minAgeValidator',
      'inCorrectDynamicDateValidator',
      'duplicateProcedureAndDiagnosisCodeValidator',
      'inCorrectDynamicFirstNameValidator',
      'inCorrectDynamicLastNameValidator',
      'incorrectMemberIdValidator',
      'getAge',
      'dateValidator',
      'alphaStringValidator',
      'numberValidator',
      'focusFirstError',
      'focusFirstFiled',
      'accessCodeValidator',
      'studentIdValidator',
      'ninetyDaysValidator',
      'formatPhone',
      'clearErrorInControl',
      'clearApiErrorOnChange',
      'dobMask'
    ]),

    profileService: jasmine.createSpyObj([
      'getUserRole',
      'setProfile',
      'swapPromo',
      'verifyEmail',
      'verifyPhone',
      'extractPreferenceObject',
      'getProfile',
      'fetchProfileInfo',
      'updateProfile',
      'updateProfile2',
      'sendcommchlaccesscode',
      'sendaccesscode',
      'getDemoGraphicInfo',
      'updateDemographicInfo',
      'updatePassword',
      'profileDataChange',
      'profileDataChange$'
    ]),
    preferenceService: jasmine.createSpyObj(['updatePreferenceInfo', 'getConsent', 'getProgramGroups', 'isUnionBlueMember']),
    contactInformationService: jasmine.createSpyObj([
      'setDataChange',
      'getcommStatus',
      'updateCommStatus',
      'VerifyAccessCode',
      'VerifyCommChlAccCode',
      'sendaccesscode',
      'sendcommchlaccesscode'
    ]),

    constantsService: jasmine.createSpyObj(['displayMessage']),

    router: jasmine.createSpyObj(['navigateByUrl', 'navigate']),

    dependantsService: jasmine.createSpyObj([
      'clearDependantsList',
      'fetchDependentsList',
      'getDependentsList',
      'loadDependants',
      'setDependentList',
      'loadDependantRecords',
      'addDependentIdToRecords'
    ]),

    filterService: jasmine.createSpyObj([
      'scrollToTop',
      'customDateInputKeyDownEvent',
      'convertInputStringToDate',
      'getFormatDateString',
      'getMinimumFromDate',
      'compareStringField',
      'getDateCount',
      'selectAllOptions',
      'onSelectionChange',
      'unCheckSelectAllOption',
      'checkSelectAllOptionIfAllSelected',
      'getListItems',
      'mapOrder',
      'getPropertyValuesWithCount',
      'updateListItemsWithCount',
      'generateDependantString',
      'getSelectedItems',
      'uniqueArray'
    ]),

    changeDetectionRef: {},

    claimsService: jasmine.createSpyObj([
      'getClaims',
      'getClaimDetails',
      'getClaimProcessingStatus',
      'getBenefitsDocument',
      'setClaimDetails',
      'setClaimRecord',
      'getClaimsBenefitsLink'
    ]),

    medicationService: jasmine.createSpyObj(['getBasicMemInfo', 'setBasicMemInfo', 'getMemBasicInfo', 'getMedications']),

    detailsService: jasmine.createSpyObj([
      'setCurrentUserInfo',
      'getCurrentUserInfo',
      'setMyMedicationDetailsRequest',
      'getMyMedicationDetailsRequest',
      'getMedicationDetails'
    ]),

    bcbsmaerrorHandlerService: jasmine.createSpyObj(['setProdMode', 'logError', 'warn', 'handleHttpError', 'handleError', 'devLog']),

    fadDoctorProfileService: jasmine.createSpyObj([
      'getFadGetprofessionalprofileDetails',
      'getProfessionalratings',
      'getToolTipInfo',
      'getAcceptableReviewers'
    ]),

    fadReviewService: jasmine.createSpyObj(['getReviewQuestions', 'postReviewSubmitQuestions']),

    location: jasmine.createSpyObj(['back']),

    cardService: jasmine.createSpyObj([
      'getMemberFrontData$',
      'getMemBasicInfo',
      'getDependents$',
      'getDependentFrontData$',
      'getDependentBackData$',
      'getMemberBackData$',
      'drawCard',
      'onContactMouseHover',
      'onContactClick',
      'wrapText',
      'removeLeadingJunkChar'
    ]),
    myAccountService: jasmine.createSpyObj([
      'verifyUser',
      'verifyUserValid',
      'clearStorage',
      'verifyUserAuth',
      'resetPassword',
      'confirmIdentity',
      'hintQuestion',
      'funverifyuserResponse'
    ]),
    headerService: jasmine.createSpyObj(['getMenuItems', 'getESTTime']),

    preferenceModalService: jasmine.createSpyObj([
      'showPreference',
      'initiatePreference',
      'initiatePromo',
      'fetchPreferenceModalInfo',
      'showModal',
      'getConsentDrupal',
      'extractPreferenceDetails',
      'createConsentObject',
      'createPreferenceAttributes'
    ]),

    spinnerservice: jasmine.createSpyObj(['show', 'hide']),

    layoutService: jasmine.createSpyObj(['setPageMeta']),
    planService: jasmine.createSpyObj(['getPlansData']),
    selectionService: jasmine.createSpyObj([
      'getBenefitModelData',
      'checkAnnualFee',
      'submitForm',
      'getOverallBenefits',
      'getBenefitData',
      'getYear',
      'setBenefitData'
    ]),
    verifyEmailMobileService: jasmine.createSpyObj(['verifyEmail', 'verifyPhone']),
    costShareService: jasmine.createSpyObj(['getCostShareContent', 'getCostShareDrupalContent', 'getGroupNumbers']),
    fadSuggestAnEditDialogService: jasmine.createSpyObj(['getFadSuggestAnEditSubmitFeedback']),
    ssoInboundService: jasmine.createSpyObj(['authenticate']),
    wellConnectionService: jasmine.createSpyObj(['openVirtualVisit'])
  }
});

//#region
mocks.service.myDedCoService.getDeductiblesAndCoinsuranceInfo.and.returnValue(of(myded_co_component_resolver_data));

mocks.service.fpocontentService.fetchContent.and.returnValue(of(fpocontentService_mydedco_fetchContent_data));

mocks.service.eobService.getEobList.and.returnValue(of(eob_resolver_mock_data));
mocks.service.eobService.getEOBDocumentLink.and.returnValue();

mocks.service.fadDoctorProfileService.getAcceptableReviewers.and.returnValue(of(new FadDoctorRatingsResponseModel()));

mocks.service.dependantsService.fetchDependentsList.and.returnValue(getDependents_response);

mocks.service.authService = Object.assign(mocks.service.authService, AuthenticatedUserComponentData.authService);
mocks.service.authService.storeUserState.and.returnValue(null);
mocks.service.authService.getScopeName.and.returnValue(AuthenticatedUserComponentData.authService.methods.getScopeName);
mocks.service.authService.getDependentsList.and.returnValue(null);
mocks.service.authService.fetchUserState.and.returnValue('Active');
mocks.service.authService.getFadHccsFlag.and.returnValue('');
mocks.service.authService.impersonation.and.returnValue(false);
mocks.service.authService.isAuthenticated.and.returnValue(true);
mocks.service.authService.persistSession.and.returnValue(null);
mocks.service.authService.getTokens.and.returnValue(of(authService_getTokens_response));
mocks.service.authService.isUserActive.and.returnValue(true);
mocks.service.authService.hasMembershipStarted.and.returnValue(null);

mocks.service.landingService.getCarouselItemDetails.and.returnValue(of(homeLeaderBoardSlider_response));
mocks.service.landingService.loadArticle.and.returnValue(null);
mocks.service.landingService.getFinanceBalancChartData.and.returnValue(of(getFinanceBalanceData_response));
mocks.service.landingService.heroBannerItemsDetails.and.returnValue(of([{ ButtonText: '', isExternal: false, Body: '' }]));
mocks.service.landingService.promoDetails.and.returnValue(of([{ Title: '' }]));

mocks.service.claimsService.getClaims.and.returnValue(of(getclaimssummary_response));
mocks.service.claimsService.getClaimDetails.and.returnValue(of(getclaimdetails_response.success));
mocks.service.claimsService.claimRecord$ = of(null);
mocks.service.claimsService.getClaimsBenefitsLink.and.returnValue(of(getClaimBenefitsLink_response.success));
mocks.service.claimsService.getClaimProcessingStatus.and.returnValue(of(getclaimprocessingstatus_response.success));

mocks.service.alertService.clearError.and.returnValue(null);
mocks.service.alertService.setAlert.and.returnValue(null);

mocks.service.validationService = Object.assign(mocks.service.validationService, mockConstants.validationServiceAttributes);
mocks.service.validationService.emailValidator.and.returnValue(() => true);
mocks.service.validationService.phoneValidator.and.returnValue(() => true);
mocks.service.validationService.mobileValidator.and.returnValue(() => true);
mocks.service.validationService.invalidPasswordValidatorWrapper.and.returnValue(() => true);
mocks.service.validationService.samePasswordValidator.and.returnValue(() => true);
mocks.service.validationService.checkConfirmPasswordValidator.and.returnValue(() => true);
mocks.service.validationService.dateValidator.and.returnValue(() => true);
mocks.service.validationService.dobValidator.and.returnValue(() => true);
mocks.service.validationService.trailingSpaceValidator.and.returnValue(() => true);
mocks.service.validationService.specialCharactersValidator.and.returnValue(() => true);
mocks.service.validationService.validateState.and.returnValue(() => true);

mocks.service.router.navigate.and.returnValue(
  new Promise((resolve, reject) => {
    // do something asynchronous
    resolve();
  })
);

mocks.service.router.params = of(null);

mocks.service.profileService.getUserRole.and.returnValue(jasAVUserData.getMemProfileApiResponse.userState);
mocks.service.profileService.setProfile.and.returnValue(null);
mocks.service.profileService.getProfile.and.returnValue(jasAVUserData.getMemProfile_After_NgOnint);
mocks.service.profileService.fetchProfileInfo.and.returnValue(of(jasAVUserData.getMemProfileApiResponse));
mocks.service.profileService.updateProfile.and.returnValue(of(jasAVUserData.getMemProfileApiResponse));
mocks.service.profileService.updateProfile2.and.returnValue(of(jasAVUserData.getMemProfileApiResponse));
mocks.service.profileService.sendcommchlaccesscode.and.returnValue(of(new GeneralError()));
mocks.service.profileService.getDemoGraphicInfo.and.returnValue(of(getDemographicInfo_response));
mocks.service.profileService.updateDemographicInfo.and.returnValue(of(updateDemographicInfo_success_response));
mocks.service.profileService.updatePassword.and.returnValue(of(updatePassword_success_response));
mocks.service.profileService.authService = mocks.service.authService;
mocks.service.profileService.swapPromo.and.returnValue(null);
mocks.service.profileService.verifyEmail.and.returnValue(null);
mocks.service.profileService.verifyPhone.and.returnValue(null);
mocks.service.profileService.extractPreferenceObject.and.returnValue(of(jasAVUserData.getPreferences));
mocks.service.profileService.profileDataChange.and.returnValue(of(null));
mocks.service.profileService.profileDataChange$ = of(new Date().toString());

mocks.service.globalService.getPostLoginSessionObject.and.returnValue(
  AuthenticatedUserComponentData.globalService.getPostLoginSessionObject
);
mocks.service.globalService.memberData$ = of(null);
mocks.service.globalService.fadLoaded$ = of(null);
mocks.service.globalService.handleError.and.returnValue(null);
mocks.service.globalService.getConsent.and.returnValue(of(jasAVUserData.getConsentData));
mocks.service.globalService.updateConsent.and.returnValue(of({ result: 0 }));
mocks.service.globalService.getProgramGroups.and.returnValue(of(jasAVUserData.getProgramGroups));
mocks.service.globalService.getPreferences.and.returnValue(of(jasAVUserData.getPreferences));
mocks.service.globalService.updatePreferences.and.returnValue(of(jasAVUserData.getChangedPreferences));
mocks.service.globalService.updateFADStatus.and.returnValue(of({}));
mocks.service.authHttp.uuid.and.returnValue(AuthenticatedUserComponentData.authHttp.uuid);
mocks.service.authHttp.showSpinnerLoading.and.returnValue(AuthenticatedUserComponentData.authHttp.uuid);
mocks.service.authHttp.hideSpinnerLoading.and.returnValue(AuthenticatedUserComponentData.authHttp.uuid);
mocks.service.authHttp.handleRequest.and.returnValue({});
mocks.service.authHttp.handleDecryptedResponse.and.returnValue({ someDecryptedResponse: '' });
mocks.service.authHttp.encryptPost.and.returnValue(of({}));
mocks.service.authHttp.handleError.and.returnValue(null);
mocks.service.authHttp.get.and.returnValue(of(COST_SHARE));
mocks.service.authHttp.sessionid.and.returnValue(of(null));
mocks.service.authHttp.postlogin.and.returnValue(of(jasAVUserData.postLogin));

mocks.service.filterService.scrollToTop.and.returnValue(null);
mocks.service.filterService.customDateInputKeyDownEvent.and.returnValue(null);
mocks.service.filterService.convertInputStringToDate.and.returnValue(null);
mocks.service.filterService.getFormatDateString.and.returnValue(null);
mocks.service.filterService.getMinimumFromDate.and.returnValue(null);
mocks.service.filterService.compareStringField.and.returnValue(null);
mocks.service.filterService.getDateCount.and.returnValue(null);
mocks.service.filterService.selectAllOptions.and.returnValue(null);
mocks.service.filterService.onSelectionChange.and.returnValue(null);
mocks.service.filterService.unCheckSelectAllOption.and.returnValue(null);
mocks.service.filterService.checkSelectAllOptionIfAllSelected.and.returnValue(null);
mocks.service.filterService.getListItems.and.returnValue(null);
mocks.service.filterService.mapOrder.and.returnValue(null);
mocks.service.filterService.getPropertyValuesWithCount.and.returnValue(null);
mocks.service.filterService.updateListItemsWithCount.and.returnValue(null);
mocks.service.filterService.generateDependantString.and.returnValue(null);
mocks.service.filterService.getSelectedItems.and.returnValue(null);
mocks.service.filterService.uniqueArray.and.returnValue(null);

mocks.service.location.back.and.returnValue(null);

mocks.service.bcbsmaerrorHandlerService.logError.and.returnValue(null);
mocks.service.bcbsmaerrorHandlerService.handleHttpError.and.returnValue(null);

mocks.service.myAccountService.verifyUser.and.returnValue(of(verifyfpuser_response.success));
mocks.service.myAccountService.verifyUserValid.and.returnValue(of(verifyfunuser_response.success));
mocks.service.myAccountService.verifyUserAuth.and.returnValue(verifyfphintanswer_response);
mocks.service.myAccountService.resetPassword.and.returnValue(of(verifyfpuser_response.success));
mocks.service.myAccountService.confirmIdentity.and.returnValue(of(verifyfunauthuser_response.success));
mocks.service.myAccountService.confirmIdentity.and.returnValue(of(verifyfunauthuser_response.failure));
mocks.service.myAccountService.funverifyuserResponse.and.returnValue();

mocks.service.contactInformationService.setDataChange.and.returnValue(null);
mocks.service.contactInformationService.getcommStatus.and.returnValue(null);
mocks.service.contactInformationService.updateCommStatus.and.returnValue(null);
mocks.service.contactInformationService.VerifyCommChlAccCode.and.returnValue(null);
mocks.service.contactInformationService.sendaccesscode.and.returnValue(null);
mocks.service.contactInformationService.sendcommchlaccesscode.and.returnValue(null);

mocks.service.spinnerservice.setSubject.and.returnValue(null);
mocks.service.spinnerservice.show.and.returnValue(null);
mocks.service.spinnerservice.hide.and.returnValue(null);
mocks.service.spinnerservice.cssPropertyValueSupported.and.returnValue(null);

mocks.service.preferenceModalService.initiatePreference.and.returnValue(null);
mocks.service.preferenceModalService.showPreference.and.returnValue(false);
mocks.service.preferenceModalService.initiatePromo.and.returnValue({});

mocks.service.preferenceService.getConsent.and.returnValue(of(jasAVUserData.getConsentData));
mocks.service.preferenceService.updatePreferenceInfo.and.returnValue({});
mocks.service.preferenceService.getProgramGroups.and.returnValue(of(jasAVUserData.getProgramGroups));
mocks.service.preferenceService.isUnionBlueMember.and.returnValue(false);

mocks.service.layoutService.setPageMeta.and.returnValue(null);
mocks.service.planService.getPlansData.and.returnValue(null);

mocks.service.selectionService.getBenefitModelData.and.returnValue({ memberList: [] });
mocks.service.selectionService.checkAnnualFee.and.returnValue(true);
mocks.service.selectionService.submitForm.and.returnValue(of({ type: HttpEventType.Sent }));
mocks.service.selectionService.getOverallBenefits.and.returnValue({});
mocks.service.selectionService.getBenefitData.and.returnValue({});
mocks.service.selectionService.getYear.and.returnValue(of({ benefits: [] }));
mocks.service.selectionService.setBenefitData.and.returnValue({});

mocks.service.verifyEmailMobileService.verifyEmail.and.returnValue({});
mocks.service.verifyEmailMobileService.verifyPhone.and.returnValue({});
mocks.service.verifyEmailMobileService.preferenceModalVerification$ = of({});

mocks.service.costShareService.getCostShareContent.and.returnValue(of({ title: '', description: '', imageUrl: '', navLinks: [] }));
mocks.service.costShareService.getGroupNumbers.and.returnValue([]);
mocks.service.costShareService.getCostShareDrupalContent.and.returnValue(of([]));

mocks.service.headerService.getMenuItems.and.returnValue(of([{ absolute: '' }]));

mocks.service.fadSuggestAnEditDialogService.getFadSuggestAnEditSubmitFeedback.and.returnValue(of({}));
mocks.service.ssoInboundService.authenticate.and.returnValue(of({}));

mocks.service.wellConnectionService.openVirtualVisit.and.returnValue(of(consumerEnrollmentResponse.success));
// mocks.service.wellConnectionService.openVirtualVisit.and.returnValue(of(consumerEnrollmentResponse.failure));

