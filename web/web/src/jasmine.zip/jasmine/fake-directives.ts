import { Directive, Input } from '@angular/core';

@Directive({
  selector: '[routerLink]',
  host: { '(click)': 'onClick()' }
})
export class FakeRouterLinkDirectiveStub {
  @Input('routerLink') linkParams: any;
  navigatedTo: any = null;

  onClick() {
    this.navigatedTo = this.linkParams;
  }
}

@Directive({
  selector: '[parentFormField]',
  host: { '(click)': 'onClick()' }
})
export class FakeParentFormFieldDirectiveStub {
  @Input('parentFormField') parentFormField: any;
  parent: any = null;

  onClick() {
    this.parent = this.parentFormField;
  }
}

@Directive({
  selector: '[materializeParams]',
  host: { '(click)': 'onClick()' }
})
export class FakeMaterializeParamsDirectiveStub {
  @Input('materializeParams') materializeParams: any;
  parent: any = null;

  onClick() {
    this.parent = this.materializeParams;
  }
}

@Directive({
  selector: '[cellAspectRatio]',
  host: { '(click)': 'onClick()' }
})
export class FakeCellAspectRatioDirectiveStub {
  @Input('cellAspectRatio') cellAspectRatio: any;
  parent: any = null;

  onclick() {
    this.parent = this.cellAspectRatio;
  }
}

@Directive({
  selector: '[infiniteScrollUpDistance]',
  host: { '(click)': 'onClick()' }
})
export class FakeInfiniteScrollUpDistanceDirectiveStub {
  @Input('infiniteScrollUpDistance') infiniteScrollUpDistance: any;
  parent: any = null;

  onclick() {
    this.parent = this.infiniteScrollUpDistance;
  }
}

@Directive({
  selector: '[scrollWindow]',
  host: { '(click)': 'onClick()' }
})
export class FakeScrollWindowDirectiveStub {
  @Input('scrollWindow') scrollWindow: any;
  parent: any = null;

  onclick() {
    this.parent = this.scrollWindow;
  }
}

@Directive({
  selector: '[infiniteScroll] ',
  host: { '(click)': 'onClick()' }
})
export class FakeInfiniteScrollDirectiveStub {
  @Input('infiniteScroll') infiniteScroll: any;
  parent: any = null;

  onclick() {
    this.parent = this.infiniteScroll;
  }
}
@Directive({
  selector: '[infiniteScrollContainer]',
  host: { '(click)': 'onClick()' }
})
export class FakeInfiniteScrollContainerDirectiveStub {
  @Input('infiniteScrollContainer') infiniteScrollContainer: any;
  parent: any = null;

  onclick() {
    this.parent = this.infiniteScrollContainer;
  }
}
@Directive({
  selector: '[fromRoot]',
  host: { '(click)': 'onClick()' }
})
export class FakeFromRootDirectiveStub {
  @Input('fromRoot') fromRoot: any;
  parent: any = null;

  onclick() {
    this.parent = this.fromRoot;
  }
}
@Directive({
  selector: '[infiniteScrollDistance]',
  host: { '(click)': 'onClick()' }
})
export class FakeInfiniteScrollDistanceDirectiveStub {
  @Input('infiniteScrollDistance') infiniteScrollDistance: any;
  parent: any = null;

  onclick() {
    this.parent = this.infiniteScrollDistance;
  }
}
@Directive({
  selector: '[infiniteScrollThrottle]',
  host: { '(click)': 'onClick()' }
})
export class FakeInfiniteScrollThrottleDirectiveStub {
  @Input('infiniteScrollThrottle') infiniteScrollThrottle: any;
  parent: any = null;

  onclick() {
    this.parent = this.infiniteScrollThrottle;
  }
}
@Directive({
  selector: '[infiniteScrollDisabled]',
  host: { '(click)': 'onClick()' }
})
export class FakeInfiniteScrollDisabledDirectiveStub {
  @Input('infiniteScrollDisabled') infiniteScrollDisabled: any;
  parent: any = null;

  onclick() {
    this.parent = this.infiniteScrollDisabled;
  }
}
@Directive({
  selector: '(scrolled)',
  host: { '(click)': 'onClick()' }
})
export class FakescrolledDirectiveStub {
  @Input('scrolled') scrolled: any;
  parent: any = null;

  onclick() {
    this.parent = this.scrolled;
  }
}
@Directive({
  selector: '(scrolledUp)',
  host: { '(click)': 'onClick()' }
})
export class FakeScrolledUpDirectiveStub {
  @Input('scrolledUp') scrolledUp: any;
  parent: any = null;

  onclick() {
    this.parent = this.scrolledUp;
  }
}
