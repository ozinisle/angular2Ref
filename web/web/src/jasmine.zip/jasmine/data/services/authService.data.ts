export let authService_getTokens_response = {
  result: '0',
  key1id: '0319a06ea4ed45b796a7743349f7923b',
  key1salt: '1741d09cdb3ffcc0d188e7db5542fa942d0a701447a91be345b263bef9f46d2c',
  key1iv: '2d59b2da39c745ad27626fd5bb95d590',
  key1phrase: '98f54622dc6141f8a7ab191761d81c44',
  key2id: 'b19be734b0a846aa93cd0015eb300060',
  key2salt: '7c9773492db9e0b99f1f5e26028001ff4906a306be36c4b060639dd81d0257dc',
  key2iv: '2259cd533b8b9af66439ba27e2cc7fb7',
  key2phrase: '4bed9f3021f844c2b0de7f1cf84fcfce'
};
