export let fpocontentService_mydedco_fetchContent_data = [
  {
    ArticleId: '311',
    Title: 'My Deductible and Co-insurance screen',
    ShortDescription: '',
    DisplayCategory: '',
    DisplayCategoryImage: '',
    Body:
      '<p>To better understand your deductible and coinsurance, visit our Education Center <a href="https://myblue.bluecrossma.com/health-plan/plan-education-center">plan education center</a>  for definitions and explanations.</p>',
    CreatedAt: 'August 17, 2018',
    RegularImages: '',
    TabletImage: '',
    MobileImages: '',
    ThumbnailImage: '',
    ArticleUrl: '',
    ArticleText: '',
    APPArticleUrl: '',
    VideoUrl: '',
    VideoThumbnailIcon: '',
    FontawesomeIconUnicode: '',
    FontawesomeIconClass: '',
    AppstoreIcon: '',
    AppstoreIconUrl: '',
    GoogleplayIcon: '',
    GoogleplaystoreIconUrl: '',
    ButtonText: '',
    ButtonUrl: '',
    APPButtonUrl: '',
    PromoSlotDestination: '',
    Version: ''
  }
];
