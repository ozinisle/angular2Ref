export let myDoctors_pcp_service_getMemberPlanInfo_data = {
  fullName: 'CHARLES BROWN',
  suffix: '00',
  genderCode: 'M',
  DOB: '1944-10-11',
  plans: [
    {
      planName: 'NETWORK BLUE OPTIONS DEDUCTIBLE',
      effectiveDate: '2018-01-01',
      cancelDate: '',
      groupNumber: '511300595',
      hasDependents: true,
      isTIR: true,
      isTRB: false,
      isNEHP: false
    }
  ]
};

export let myDoctors_pcp_service_getChangePCPReasonInfo_data = {
  codes: [
    {
      order: 0,
      code: 'D',
      text: 'Appointment Availability'
    },
    {
      order: 1,
      code: 'H',
      text: 'Current PCP Request I Find New PCP'
    },
    {
      order: 2,
      code: 'F',
      text: 'Difficulty Getting Referrals'
    },
    {
      order: 3,
      code: 'A',
      text: 'Hours/Location Inconvenient'
    },
    {
      order: 4,
      code: 'K',
      text: 'Language/Facility Barriers'
    },
    {
      order: 5,
      code: 'J',
      text: 'New Member - First Selection of PCP'
    },
    {
      order: 6,
      code: 'C',
      text: 'Office Staff Relationship'
    },
    {
      order: 7,
      code: 'I',
      text: 'Other'
    },
    {
      order: 8,
      code: 'B',
      text: 'Physician Relationship'
    },
    {
      order: 9,
      code: 'G',
      text: 'Quality of Care Could be Improved'
    },
    {
      order: 10,
      code: 'E',
      text: 'Wait Time During Visits'
    }
  ]
};

export let myDoctors_pcp_service_update_pcp_abstract_value = {
  active: true,
  doctorList: [
    {
      rowId: '3',
      claimId: '020187645740700',
      providerPhone: '508-679-7385',
      providerNumber: '70010000K08343',
      providerType: 'Physician',
      providerName: 'M ANIS   RAHMAN MD',
      memberFirstName: 'CHARLES',
      memberLastName: 'BROWN',
      memberMiddleInitial: '',
      memberRelationship: 'Subscriber',
      providerSpeciality: 'Internal Medicine',
      dateOfservice: '2018-08-21',
      isAllowedChangePCP: true,
      isPCP: true,
      isRequiredPCP: true,
      pcpId: '70010000K08343',
      currUser: true,
      mem_name: 'CHARLES BROWN'
    },
    {
      rowId: '2',
      claimId: '020187645766700',
      providerPhone: '413-582-0330',
      providerNumber: '70010000J26578',
      providerType: 'Physician',
      providerName: 'GREGORY B PARK MD',
      memberFirstName: 'CHARLES',
      memberLastName: 'BROWN',
      memberMiddleInitial: '',
      memberRelationship: 'Subscriber',
      providerSpeciality: 'Internal Medicine',
      dateOfservice: '2018-08-07',
      isAllowedChangePCP: true,
      isPCP: false,
      isRequiredPCP: true,
      pcpId: '70010000K08343',
      currUser: true,
      mem_name: 'CHARLES BROWN'
    },
    {
      rowId: '4',
      claimId: '020187645760200',
      providerPhone: '413-567-5533',
      providerNumber: '70010000P08668',
      providerType: 'Physician',
      providerName: 'RANDI E KLEIN LICSW',
      memberFirstName: 'CHARLES',
      memberLastName: 'BROWN',
      memberMiddleInitial: '',
      memberRelationship: 'Subscriber',
      providerSpeciality: 'Internal Medicine',
      dateOfservice: '2018-07-30',
      isAllowedChangePCP: true,
      isPCP: false,
      isRequiredPCP: true,
      pcpId: '70010000K08343',
      currUser: true,
      mem_name: 'CHARLES BROWN'
    },
    {
      rowId: '5',
      claimId: '020187645753700',
      providerPhone: '413-794-0000',
      providerNumber: '70012222005611',
      providerType: 'Physician',
      providerName: 'BAYSTATE MEDICAL CENTER INC',
      memberFirstName: 'CHARLES',
      memberLastName: 'BROWN',
      memberMiddleInitial: '',
      memberRelationship: 'Subscriber',
      providerSpeciality: 'Internal Medicine',
      dateOfservice: '2018-02-21',
      isAllowedChangePCP: true,
      isPCP: false,
      isRequiredPCP: true,
      pcpId: '70010000K08343',
      currUser: true,
      mem_name: 'CHARLES BROWN'
    },
    {
      rowId: '1',
      claimId: '020187645747200',
      providerPhone: '413-783-3100',
      providerNumber: '70010000J12046',
      providerType: 'Physician',
      providerName: 'STEVEN T BERGER MD',
      memberFirstName: 'CHARLES',
      memberLastName: 'BROWN',
      memberMiddleInitial: '',
      memberRelationship: 'Subscriber',
      providerSpeciality: 'Internal Medicine',
      dateOfservice: '2018-01-22',
      isAllowedChangePCP: true,
      isPCP: false,
      isRequiredPCP: true,
      pcpId: '70010000K08343',
      currUser: true,
      mem_name: 'CHARLES BROWN'
    }
  ],
  selectedDoctor: {
    rowId: '3',
    claimId: '020187645740700',
    providerPhone: '508-679-7385',
    providerNumber: '70010000K08343',
    providerType: 'Physician',
    providerName: 'M ANIS   RAHMAN MD',
    memberFirstName: 'CHARLES',
    memberLastName: 'BROWN',
    memberMiddleInitial: '',
    memberRelationship: 'Subscriber',
    providerSpeciality: 'Internal Medicine',
    dateOfservice: '2018-08-21',
    isAllowedChangePCP: true,
    isPCP: true,
    isRequiredPCP: true,
    pcpId: '70010000K08343',
    currUser: true,
    mem_name: 'CHARLES BROWN'
  },
  memberInfo: {
    memFirstName: 'CHARLES',
    memMiddleInitial: '',
    memLastName: 'BROWN',
    subNum: '0508996660000',
    suffix: '00',
    hasDependents: true,
    relationship: 'Subscriber'
  },
  memberPCP: {
    isRequiredPCP: true,
    hasPCP: true,
    pcpId: '70010000K08343'
  }
};
