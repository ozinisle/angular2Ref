export let verifyfunuser_response = {
  success: {
    original: {
      webNonMigratedUser: 'KAJ/v85Ppxdv7taU/RQjMA==',
      isAuthenticated: 'KAJ/v85Ppxdv7taU/RQjMA==',
      userId: 'EryiKamqlZh7Jj6jpU4lZeb/0geyZw6N5gNHl0uEX/0=',
      commType: 'e/2jpnkx94x0su2AGjLHfg==',
      commValue: 'EryiKamqlZh7Jj6jpU4lZeb/0geyZw6N5gNHl0uEX/0='
    },
    decrypted: {
      webNonMigratedUser: 'KAJ/v85Ppxdv7taU/RQjMA==',
      isAuthenticated: 'KAJ/v85Ppxdv7taU/RQjMA==',
      userId: 'EryiKamqlZh7Jj6jpU4lZeb/0geyZw6N5gNHl0uEX/0=',
      commType: 'e/2jpnkx94x0su2AGjLHfg==',
      commValue: 'EryiKamqlZh7Jj6jpU4lZeb/0geyZw6N5gNHl0uEX/0='
    }
  }
  // failure:{}
};
