export let verifyfpuser_response = {
  success: {
    original: {
      result: '0',
      errormessage: '',
      displaymessage: '',
      message:
        'hQldaPiQE6qb4znqw1tkEeO6HxtXM+UwvaXXQYo12oq+IlcMFLlDCmjgTL5ljq5LxRQglExjEO775SAWRc3JPHBHqtIQ7TPIS4o2eesg1TDOHQsgpKZOI/x1hZDfMNAaZ7rfrXzFl26sHKeKqHoffjl4lLssThJAvgCzs1MR+xz6cf1Jd5dW7tbSovExKt9ubP8JReT/TLnn1PCEDTTg7+uOiZIXpKIuJgeNTsPHNXtDkE/ok50hYYnQkIHZnDfLyvfRLEjtgCswbhO8pGFooy9uo4y7v8Xwoz9Xphmpb1fA1CzPFPkKVBAOxKJ/4MtCp9kx7TwnYUILD5jyc6ZvdBK7sibyjE6pSoxBSqTE0YbSlcWFP0Xo+sKDuzIN7FcdbbILlwz+zk1hLvstyG9Z2ngUHKj7F2Pu9P7a8bdgd0M='
    },
    decrypted: {
      userId: 'iTISCs5ywfQyqkeiJbfzosoayVEz/fbqZCBrwbEYfGE=',
      webNonMigratedUser: '26UQTKIBgAzObhcgJWdZFA==',
      isAuthenticated: 'scxfnPhfWQqpaUSYzACwgQ==',
      hintQuestion: 'CHXC2EiNCfAhprEuXJxoNr5BtnjFU23O1Zq7RiBxxUM=',
      commType: 'vDKIL29woEq0YsZ/rhitcA==',
      commValue: '83UyQD7BT/ocHsCjqB1wdgK1n8Ihh5z3YMwE865+naI='
    }
  }
};
