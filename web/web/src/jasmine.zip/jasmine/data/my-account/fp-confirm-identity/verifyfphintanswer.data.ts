export let verifyfphintanswer_response = {
  original: {
    result: 0,
    errormessage: '',
    displaymessage: ''
  }
};
