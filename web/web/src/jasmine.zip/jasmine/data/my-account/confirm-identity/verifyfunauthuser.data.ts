export let verifyfunauthuser_response = {
  success: {
    result: 0,
    errormessage: '',
    displaymessage: ''
  },
  failure: {
    result: '-1',
    errormessage: '',
    displaymessage: ''
  }
};
