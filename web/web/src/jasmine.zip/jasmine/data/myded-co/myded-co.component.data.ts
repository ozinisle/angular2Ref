export let myded_co_component_resolver_data = {
  breadcrumb: 'Deductible & Co-insurance',
  dedcoList: [
    {
      hasFamily: 'True',
      members: [
        {
          coverageType: 'MEDICAL',
          futureEffFlag: 'FALSE',
          hasDependentsFlg: 'TRUE',
          loggedinUserSuffix: '00',
          subscriberNo: '050745419',
          hasActivePLanFlg: 'TRUE',
          cobundledPlanFlag: 'False',
          name: 'MICHEL BARTLETT',
          planName: 'HMO BLUE NE OPTIONS DEDUCTIBLE',
          planEffDate: '2009-02-09',
          memSuffix: ''
        },
        {
          coverageType: 'MEDICAL',
          futureEffFlag: 'FALSE',
          hasDependentsFlg: '',
          loggedinUserSuffix: '',
          subscriberNo: '050745419',
          hasActivePLanFlg: 'TRUE',
          cobundledPlanFlag: 'False',
          name: 'BUTCHER BARTLETT',
          planName: 'HMO BLUE NE OPTIONS DEDUCTIBLE',
          planEffDate: '2009-02-09',
          memSuffix: '01'
        },
        {
          coverageType: 'MEDICAL',
          futureEffFlag: 'FALSE',
          hasDependentsFlg: '',
          loggedinUserSuffix: '',
          subscriberNo: '050745419',
          hasActivePLanFlg: 'TRUE',
          cobundledPlanFlag: 'False',
          name: 'BURDETTE BARTLETT',
          planName: 'HMO BLUE NE OPTIONS DEDUCTIBLE',
          planEffDate: '2009-02-09',
          memSuffix: '10'
        },
        {
          coverageType: 'MEDICAL',
          futureEffFlag: 'FALSE',
          hasDependentsFlg: '',
          loggedinUserSuffix: '',
          subscriberNo: '050745419',
          hasActivePLanFlg: 'TRUE',
          cobundledPlanFlag: 'False',
          name: 'ASH BARTLETT',
          planName: 'HMO BLUE NE OPTIONS DEDUCTIBLE',
          planEffDate: '2013-01-01',
          memSuffix: '11'
        },
        {
          coverageType: 'MEDICAL',
          futureEffFlag: 'FALSE',
          hasDependentsFlg: '',
          loggedinUserSuffix: '',
          subscriberNo: '050745419',
          hasActivePLanFlg: 'TRUE',
          cobundledPlanFlag: 'False',
          name: 'SHERI BARTLETT',
          planName: 'HMO BLUE NE OPTIONS DEDUCTIBLE',
          planEffDate: '2015-10-15',
          memSuffix: '12'
        },
        {
          coverageType: 'MEDICAL',
          futureEffFlag: 'FALSE',
          hasDependentsFlg: '',
          loggedinUserSuffix: '',
          subscriberNo: '050745419',
          hasActivePLanFlg: 'TRUE',
          cobundledPlanFlag: 'False',
          name: 'BRANDON BARTLETT',
          planName: 'HMO BLUE NE OPTIONS DEDUCTIBLE',
          planEffDate: '2009-02-09',
          memSuffix: '13'
        }
      ],
      accums: [
        {
          result: 0,
          displaymessage: '',
          errormessage: '',
          coverageType: 'Medical',
          benefitName: '0228',
          planTypeFlag: '127',
          planName: 'HMO Blue NE Options Deductible',
          healthPlanTypeDescription: 'Medical',
          cobundledPlanFlag: 'False',
          blueChoiceFlag: 'False',
          planStartDate: '2019-01-01',
          planEndDate: '2019-12-31',
          outOfPocket: [
            {
              outOfPocketMax: '10900.00',
              oopMaxContributed: '25.00',
              oopMaxRemainingToMeet: '10875.00',
              oopMaxExclusionExcep:
                'Calculation includes deductible, copayments and coinsurance (accumulation for medical benefits and prescription drug benefits is separate).',
              oopMaxLimitationContent: '$10900.00 per family per plan year for medical benefits'
            }
          ]
        }
      ]
    }
  ]
};
