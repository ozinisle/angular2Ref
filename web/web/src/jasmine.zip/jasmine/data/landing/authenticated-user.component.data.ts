export let AuthenticatedUserComponentData = {
  globalService: {
    getPostLoginSessionObject: {
      hasSS: false,
      hasSSO: false,
      hasCI: false,
      phoneNumbers: [
        {
          text: 'Call Member Service: ',
          number: '800-262-2583'
        },
        {
          text: 'TTY: ',
          number: '711'
        },
        {
          text: 'Talk to a Nurse:',
          number: '888-247-2583'
        },
        {
          text: 'Talk to a Doctor',
          number: ''
        },
        {
          text: 'Send a Message',
          number: ''
        }
      ],
      isCPDPEnrolled: false,
      isCPDPHandedoff: false,
      isCPDPPromotion: true,
      isKYMember: false,
      pharmacyLinks: [
        {
          text: 'My Medications',
          url: '/mymedications'
        },
        {
          text: 'Medication Lookup Tool',
          url: 'https://home.bluecrossma.com/medication/?icid=myblueglobalnav'
        },
        {
          text: 'PillPack',
          url: '/my-pillpack/landing'
        }
      ]
    }
  },

  authService: {
    impersonate: false,
    authRestartScreen: '/register/register-detail',

    basicMemInfo: null,

    cryptoToken: {
      key1id: '1acb32154a234a89bef52e71ec457fc7',
      key1iv: '79b8027fa8fc527a423f118aabea97df',
      key1phrase: '44f4289ecef5431cbbede6e9c5def299',
      key1salt: 'd293d5961554759cc3649efe4dda74c049deffd9ee87a94ade6b6fd349ae530a',
      key2id: 'ce6a5e57065c4f80a5762c75bd6c8fe6',
      key2iv: 'c1bf28d16380ecc44fc908f223d7b06b',
      key2phrase: 'b29e3b00ee6948658aefb817ac0512f9',
      key2salt: 'fa01c547a93f7328d5fac1d582685aa217d6669274ab82c2672ab6e88f2aedcb',
      result: '0'
    },
    dependentsList: null,

    isSubscriber: false,
    refreshTimer: 131,
    tokenError: false,

    useridin: 'Dannew11@yopmail.com',
    authToken: {
      HasActivePlan: 'true',
      access_token: 'RJwaGr1rpjfQ5AHjloau063XUFBC',
      access_token_expires: '2019-Oct-09T10:12:18.167+00:00',
      destinationURL: null,
      firstName: 'DAN',
      hasDependents: 'true',
      isALG: 'false',
      isHEQ: 'false',
      issued: '2019-Oct-09T09:57:19.167+00:00',
      migrationtype: 'NONE',
      userType: 'MEDEX',
      planTypes: {
        vision: 'false',
        medical: 'true',
        dental: 'false'
      },
      refresh_count: null,
      refresh_token: 'iBEJNIW8ryuAvwIpX0INOzNP8qiw6LCy',
      refresh_token_expires: '2019-Oct-25T13:02:54.864+00:00',
      scopename: 'AUTHENTICATED-AND-VERIFIED',
      syntheticID: '2DD0288F24372DC0DE4C33A78B6430E026EF7EB5',
      unreadMsgCount: '0'
    },
    planTypes: {
      dental: 'false',
      medical: 'true',
      vision: 'false'
    },
    refresh_count: null,
    refresh_token: 'a7d6qc4Y8JzO9KWgOxy4aYbudpnKVeEM',
    refresh_token_expires: '2019-Oct-09T10:27:18.167+00:00',
    scopename: 'AUTHENTICATED-AND-VERIFIED',
    syntheticID: '2DD0288F24372DC0DE4C33A78B6430E026EF7EB5',
    unreadMsgCount: '0',
    userType: 'MEMBER',
    methods: {
      getScopeName: 'AUTHENTICATED-AND-VERIFIED'
    }
  },

  authHttp: {
    uuid: 'f5f9dabf-bee6-4026-854d-6c992673f5e0'
  },

  methods: {
    transformCauroselResponse: [
      {
        src: '#', // "https://games.bluecrossma.com/sites/g/files/csphws1736/files/2019-04/Rotating%20Banner%20-%20MyBlue%20-%20Prescriptions%20for%20Healthy%20Living_1140x405.jpg",
        mobilesrc: '#', // "https://games.bluecrossma.com/sites/g/files/csphws1736/files/2019-04/Rotating%20Banner%20-%20MyBlue%20-%20Prescriptions%20for%20Healthy%20Living_1140x405.jpg",
        text:
          'When a Dorchester woman joined Dot Rx, she gained access to a peer coach and healthy resources in her neighborhood. Learn more about the program.',
        isVideo: 0,
        VIdeoUrl: '',
        urlLink: '#', // "https://aboutus.bluecrossma.com/annual-report-2018/in-our-communities/prescriptions-for-healthy-living",
        Title: 'leaderboardslider1',
        Body: ''
      },
      {
        src: '#', // "https://games.bluecrossma.com/sites/g/files/csphws1736/files/2019-08/MyBlue-slider.png",
        mobilesrc: '#', // "https://games.bluecrossma.com/sites/g/files/csphws1736/files/2019-08/MyBlue-slider.png",
        text: 'With new ways to get reimbursed, your reward is closer than you think!',
        isVideo: 0,
        VIdeoUrl: '',
        urlLink: '#', // "https://myblue.bluecrossma.com/health-plan/fitness-reimbursement-weight-loss",
        Title: 'leaderboardslider2 ',
        Body: '<p>We want to reward you for making healthy choices. That’s why we offer two reimbursement programs.</p>'
      }
    ]
  }
};
