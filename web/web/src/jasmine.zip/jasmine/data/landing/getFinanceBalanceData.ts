export let getFinanceBalanceData_response = {
    "algsAccounts":{
       "reimbursementAccountInfo":[
          {
             "flexAcctId":"0000008275",
             "accountType":"HRA",
             "planStartDate":"2019-01-01",
             "planEndDate":"2019-12-31",
             "accountName":"Health Reimbursement Arrangement",
             "balanceAvailable":1000,
             "spent":0,
             "electionAmount":1000
          },
          {
             "flexAcctId":"0000008269",
             "accountType":"DFS",
             "planStartDate":"2019-01-01",
             "planEndDate":"2019-12-31",
             "accountName":"Dependent Care Flexible Spending Account",
             "balanceAvailable":0,
             "spent":0,
             "electionAmount":500
          },
          {
             "flexAcctId":"0000008268",
             "accountType":"FSA",
             "planStartDate":"2019-01-01",
             "planEndDate":"2019-12-31",
             "accountName":"Flexible Spending Account",
             "balanceAvailable":1000,
             "spent":0,
             "electionAmount":1000
          }
       ],
       "savingsAccountInfo":[
 
       ]
    },
    "heqAccounts":{
       "reimbursementAccountInfo":[
          {
             "type":"DCRA",
             "planStartDate":"2020-01-01",
             "planEndDate":"2020-12-31",
             "accountName":"Dependant Care Reimbursement Account",
             "electionAmount":5000,
             "spent":0,
             "balanceAvailable":2307.72
          },
          {
             "type":"FSA",
             "planStartDate":"2020-01-01",
             "planEndDate":"2020-12-31",
             "accountName":"Flexible Spending Account",
             "electionAmount":250,
             "spent":0,
             "balanceAvailable":250
          },
          {
             "type":"HRA",
             "planStartDate":"2020-01-01",
             "planEndDate":"2020-12-31",
             "accountName":"Health Reimbursement Arrangement",
             "electionAmount":1000,
             "spent":103.34,
             "balanceAvailable":896.66
          }
       ],
       "savingsAccountInfo":[
 
       ]
    }
 }