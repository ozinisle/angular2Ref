export let homeLeaderBoardSlider_response = [
  {
    ArticleId: '166',
    Title: 'leaderboardslider1',
    DisplayCategory: '',
    ShortDescription: '',
    Body: '',
    CreatedAt: 'June 28, 2018',
    RegularImages:
      '/sites/g/files/csphws1736/files/2019-04/Rotating%20Banner%20-%20MyBlue%20-%20Prescriptions%20for%20Healthy%20Living_1140x405.jpg',
    TabletImage:
      '/sites/g/files/csphws1736/files/2019-04/Rotating%20Banner%20-%20MyBlue%20-%20Prescriptions%20for%20Healthy%20Living_1140x405.jpg',
    MobileImages:
      '/sites/g/files/csphws1736/files/2019-04/Rotating%20Banner%20-%20MyBlue%20-%20Prescriptions%20for%20Healthy%20Living_1140x405.jpg',
    ThumbnailImage: '',
    DisplayCategoryImage: '',
    ArticleUrl: 'https://aboutus.bluecrossma.com/annual-report-2018/in-our-communities/prescriptions-for-healthy-living',
    ArticleText:
      'When a Dorchester woman joined Dot Rx, she gained access to a peer coach and healthy resources in her neighborhood. Learn more about the program.',
    APPArticleUrl: 'https://aboutus.bluecrossma.com/annual-report-2018/in-our-communities/prescriptions-for-healthy-living',
    VideoUrl: ''
  },
  {
    ArticleId: '171',
    Title: 'leaderboardslider2 ',
    DisplayCategory: '',
    ShortDescription: '',
    Body: '<p>We want to reward you for making healthy choices. That’s why we offer two reimbursement programs.</p>',
    CreatedAt: 'June 28, 2018',
    RegularImages: '/sites/g/files/csphws1736/files/2019-08/MyBlue-slider.png',
    TabletImage: '/sites/g/files/csphws1736/files/2019-08/MyBlue-slider.png',
    MobileImages: '/sites/g/files/csphws1736/files/2019-08/MyBlue-slider.png',
    ThumbnailImage: '',
    DisplayCategoryImage: '',
    ArticleUrl: 'https://myblue.bluecrossma.com/health-plan/fitness-reimbursement-weight-loss',
    ArticleText: 'With new ways to get reimbursed, your reward is closer than you think!',
    APPArticleUrl: 'https://myblue.bluecrossma.com/health-plan/fitness-reimbursement-weight-loss',
    VideoUrl: ''
  }
];
