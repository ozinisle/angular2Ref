export let gethomepageinfo_response = {
  ROWSET: {
    ROW: {
      USER_ID: '',
      systemTimeStamp: '2019-10-09 04:35.47',
      hasDependents: 'true',
      userState: 'Active',
      userType: 'MEMBER',
      memMedexFlag: 'false',
      memMedicareFlag: 'false',
      hasHEQ: 'false',
      hasALG: 'false',
      hasSS: 'false',
      hasSSO: 'false',
      cerner: {
        hasCernerMedicare: 'false'
      },
      hasBQi: 'false',
      hasBlueGreen: 'false',
      myclaims: {
        clmICN: '020181721502700',
        clmFrstName: 'MILLER',
        clmMidInit: '',
        clmLastName: 'INCE',
        clmrelationship: 'Dependent',
        clmDOS: '07/19/2018',
        clmLastDOS: '07/19/2018',
        clmPrvName: "KLEIN'S SHOPRITE PHARMACY",
        clmCoveredAmt: '103.02',
        clmYouOweAmt: '20.76',
        clmPaymtStatus: 'Paid',
        clmStatus: 'Completed'
      },
      unreadMessageCount: '0',
      mydoctors: {
        visitFrstName: 'DAN',
        visitMidInit: '',
        visitLastName: 'INCE',
        visitDependentId: '',
        visitPrvNum: '70010000J49053',
        visitSvcDate: '04/16/2018',
        visitLastSvcDate: '04/16/2018',
        visitPrvName: 'MARK H SELESNICK MD',
        visitSpec: 'FAMILY PRACTICE                    ',
        visitPhone: '781-826-8065'
      },
      mymedications: {
        rxFrstName: 'DAN',
        rxMidInit: '',
        rxLastName: 'INCE',
        rxrelationship: 'Subscriber',
        rxDependentId: '',
        rxDrugName: 'Rosuvastatin Calcium Tab 40 MG',
        rxStrength: '40 MG',
        rxPrescPhone: '617-782-1628',
        rxDispPrvNum: '70010002236544',
        rxDispPrvName: 'STAR PHARMACY',
        rxCoPay: '10',
        rxLastFillDate: '04/02/2018',
        rxNDCCode: '00310075430',
        rxIncurredDate: '04/02/2018'
      },
      isAllowedChangePCP: 'false',
      hasPCP: 'false',
      isRequiredPCP: 'false'
    }
  }
};
