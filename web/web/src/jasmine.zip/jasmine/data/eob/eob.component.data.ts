export let eob_resolver_mock_data = [
  {
    eobMetaData: {
      hasMoreRecords: false,
      totalRecordCount: 5,
      recordStartIndex: 1,
      recordEndIndex: 5,
      sortOrder: 'Most Recent',
      sourceCache: false
    },
    filtersMetaData: {
      memberTypeMetaData: {
        memberTypeMetaList: [
          {
            memberName: 'MICHEL BARTLETT',
            memberCount: 5
          }
        ]
      },
      dateMetaData: {
        dateMetaList: [
          {
            dateRange: 'Last 30 Days'
          },
          {
            dateRange: 'Last 60 Days'
          },
          {
            dateRange: 'Last 90 Days'
          },
          {
            dateRange: 'Year To Date'
          }
        ]
      }
    },
    eobRecords: [
      {
        ServicingPlanCode: '700',
        nascoSubscriberNumber: '050745419',
        controlPlanCode: '700',
        claimID: '020181350147300',
        eobClaimID: '20181350147300',
        providerName: 'JOHN J OCONNELL MD',
        serviceStartDate: '2018-10-04',
        serviceEndDate: '2018-10-05',
        eobStatementDate: '2020-02-03'
      },
      {
        ServicingPlanCode: '700',
        nascoSubscriberNumber: '050745419',
        controlPlanCode: '700',
        claimID: '026181350068400',
        eobClaimID: '26181350068400',
        providerName: 'JOHN J OCONNELL MD',
        serviceStartDate: '2018-10-01',
        serviceEndDate: '2018-10-16',
        eobStatementDate: '2020-02-03'
      },
      {
        ServicingPlanCode: '700',
        nascoSubscriberNumber: '050745419',
        controlPlanCode: '700',
        claimID: '020181350152000',
        eobClaimID: '20181350152000',
        providerName: 'JOHN J OCONNELL MD',
        serviceStartDate: '2018-07-25',
        serviceEndDate: '2018-07-25',
        eobStatementDate: '2020-02-03'
      },
      {
        ServicingPlanCode: '700',
        nascoSubscriberNumber: '050745419',
        controlPlanCode: '700',
        claimID: '020181350048500',
        eobClaimID: '20181350048500',
        providerName: 'SARAH A FLETCHER NP',
        serviceStartDate: '2018-04-01',
        serviceEndDate: '2018-04-02',
        eobStatementDate: '2020-02-03'
      },
      {
        ServicingPlanCode: '700',
        nascoSubscriberNumber: '050745419',
        controlPlanCode: '700',
        claimID: '026181350048600',
        eobClaimID: '26181350048600',
        providerName: 'STEVEN B WEINSIER MD',
        serviceStartDate: '2018-02-01',
        serviceEndDate: '2018-06-01',
        eobStatementDate: '2020-02-03'
      }
    ]
  }
];
