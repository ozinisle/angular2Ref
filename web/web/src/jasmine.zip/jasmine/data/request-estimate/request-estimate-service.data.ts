export let request_estimate_service_getMemBasicInfo = {
  getMemBasicInfoResponse: {
    memFirstName: 'MICHEL',
    memMiddleInitial: '',
    memLastName: 'BARTLETT',
    subNum: '0507454190000',
    suffix: '00',
    hasDependents: true,
    relationship: 'Subscriber'
  }
};
