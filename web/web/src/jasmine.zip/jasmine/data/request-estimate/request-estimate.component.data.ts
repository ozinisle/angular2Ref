export let request_estimate_resolver_data = {
  breadcrumb: 'Request Written Estimate',
  memberInfo: [
    {
      rxSummary: {
        memFirstName: 'MICHEL',
        memMiddleInitial: '',
        memLastName: 'BARTLETT',
        subNum: '0507454190000',
        suffix: '00',
        hasDependents: true,
        relationship: 'Subscriber'
      }
    },
    {
      dependents: [
        {
          dependent: {
            depId: 300006022,
            firstName: 'SHERI',
            lastName: 'BARTLETT',
            middleInitial: '',
            relationship: 'Dependent',
            memNum: '050745419000012',
            cardId: 'MTN050745419',
            suffix: '12'
          }
        },
        {
          dependent: {
            depId: 300006020,
            firstName: 'ASH',
            lastName: 'BARTLETT',
            middleInitial: '',
            relationship: 'Dependent',
            memNum: '050745419000011',
            cardId: 'MTN050745419',
            suffix: '11'
          }
        }
      ]
    }
  ]
};
