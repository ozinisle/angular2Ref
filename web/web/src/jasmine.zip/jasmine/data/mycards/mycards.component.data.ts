export let mycardscomponentResolverData = [
  [
    {
      ProdDesc: 'HMO BLUE NE OPTIONS DEDUCTIBLE',
      OvCopay: 20,
      RowNum: 5,
      isDependent: false,
      BHCopay: 20,
      dispSuitcase: false,
      rxSpecified: true,
      rxBin: 'RxBin: 003858 PCN: A4',
      relationship: 'Subscriber',
      rxGRP: 'RxGRP: MASA',
      MemName: 'MICHEL BARTLETT',
      PrevCopay: 0,
      ERCopay: 150,
      MemServPh: '1-800-358-2227',
      hasDependents: true,
      MemSuff: '00',
      cardMemID: 'MTN050745419'
    },
    {
      ProdDesc: 'HMO BLUE NE OPTIONS DEDUCTIBLE',
      OvCopay: 20,
      RowNum: 4,
      isDependent: false,
      BHCopay: 20,
      dispSuitcase: false,
      rxSpecified: true,
      rxBin: 'RxBin: 003858 PCN: A4',
      relationship: 'Spouse',
      rxGRP: 'RxGRP: MASA',
      MemName: 'BUTCHER BARTLETT',
      PrevCopay: 0,
      ERCopay: 150,
      MemServPh: '1-800-358-2227',
      hasDependents: true,
      MemSuff: '01',
      cardMemID: 'MTN050745419'
    },
    {
      ProdDesc: 'HMO BLUE NE OPTIONS DEDUCTIBLE',
      OvCopay: 20,
      RowNum: 2,
      isDependent: false,
      BHCopay: 20,
      dispSuitcase: false,
      rxSpecified: true,
      rxBin: 'RxBin: 003858 PCN: A4',
      relationship: 'Dependent',
      rxGRP: 'RxGRP: MASA',
      MemName: 'BRANDON BARTLETT',
      PrevCopay: 0,
      ERCopay: 150,
      MemServPh: '1-800-358-2227',
      hasDependents: false,
      MemSuff: '13',
      cardMemID: 'MTN050745419'
    },
    {
      ProdDesc: 'HMO BLUE NE OPTIONS DEDUCTIBLE',
      OvCopay: 20,
      RowNum: 3,
      isDependent: false,
      BHCopay: 20,
      dispSuitcase: false,
      rxSpecified: true,
      rxBin: 'RxBin: 003858 PCN: A4',
      relationship: 'Dependent',
      rxGRP: 'RxGRP: MASA',
      MemName: 'BURDETTE BARTLETT',
      PrevCopay: 0,
      ERCopay: 150,
      MemServPh: '1-800-358-2227',
      hasDependents: false,
      MemSuff: '10',
      cardMemID: 'MTN050745419'
    },
    {
      ProdDesc: 'HMO BLUE NE OPTIONS DEDUCTIBLE',
      OvCopay: 20,
      RowNum: 1,
      isDependent: true,
      BHCopay: 20,
      dispSuitcase: false,
      rxSpecified: true,
      rxBin: 'RxBin: 003858 PCN: A4',
      relationship: 'Dependent',
      rxGRP: 'RxGRP: MASA',
      MemName: 'ASH BARTLETT',
      PrevCopay: 0,
      ERCopay: 150,
      MemServPh: '1-800-358-2227',
      hasDependents: false,
      MemSuff: '11',
      cardMemID: 'MTN050745419'
    },
    {
      ProdDesc: 'HMO BLUE NE OPTIONS DEDUCTIBLE',
      OvCopay: 20,
      RowNum: 6,
      isDependent: true,
      BHCopay: 20,
      dispSuitcase: false,
      rxSpecified: true,
      rxBin: 'RxBin: 003858 PCN: A4',
      relationship: 'Dependent',
      rxGRP: 'RxGRP: MASA',
      MemName: 'SHERI BARTLETT',
      PrevCopay: 0,
      ERCopay: 150,
      MemServPh: '1-800-358-2227',
      hasDependents: false,
      MemSuff: '12',
      cardMemID: 'MTN050745419'
    }
  ],
  [
    {
      RowNum: 1,
      CopyLoc: 'Top',
      Copy: 'www.bluecrossma.com'
    },
    {
      RowNum: 2,
      CopyLoc: 'Para1',
      Copy: 'Routine or Urgent Care: Contact your PCP.'
    },
    {
      RowNum: 3,
      CopyLoc: 'Para2',
      Copy: 'This card is for identification only. It is not proof of membership, nor does it guarantee coverage.'
    },
    {
      RowNum: 4,
      CopyLoc: 'Para3',
      Copy: 'To the Provider:'
    },
    {
      RowNum: 5,
      CopyLoc: 'Para4',
      Copy: 'Member Service:1-800-358-2227|Provider Service:1-800-443-6657'
    },
    {
      RowNum: 6,
      CopyLoc: 'Para5',
      Copy: 'Blue Cross and Blue Shield of Massachusetts, Inc.'
    },
    {
      RowNum: 7,
      CopyLoc: 'Bottom',
      Copy: 'Express Scripts, Inc.  Pharmacy benefits administrator'
    }
  ],
  {
    rxSummary: {
      memFirstName: 'MICHEL',
      memMiddleInitial: '',
      memLastName: 'BARTLETT',
      subNum: '0507454190000',
      suffix: '00',
      hasDependents: true,
      relationship: 'Subscriber'
    }
  }
];
