export let mockcardcomponentSingleCardData = {
  cardType: 'Medical',
  memberCardFrontData: {
    ProdDesc: 'ADVANTAGE BLUE',
    OvCopay: 20,
    RowNum: 1,
    isDependent: false,
    BHCopay: 20,
    dispSuitcase: true,
    rxSpecified: true,
    rxBin: 'RxBin: 003858 PCN: A4',
    relationship: 'Subscriber',
    rxGRP: 'RxGRP: MASA',
    MemName: 'DAN INCE',
    PrevCopay: 0,
    ERCopay: 150,
    MemServPh: '1-800-358-2227',
    hasDependents: true,
    MemSuff: '00',
    cardMemID: 'XXP050881571'
  },
  memberCardBackData: [
    {
      RowNum: 5,
      CopyLoc: 'Para4',
      Copy: 'Member Service:1-800-358-2227|Provider Service:1-800-443-6657'
    }
  ]
};
