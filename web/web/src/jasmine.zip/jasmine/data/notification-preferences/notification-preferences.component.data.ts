export let notification_preferences_resolver_data = {
  breadcrumb: 'Notification Preferences',
  pageTitle: 'Notification Preferences',
  commstatus: {
    commstatus: {
      preferences: [
        {
          memKeyName: 'UserState',
          memKeyValue: 'AUTHENTICATED-AND-VERIFIED'
        },
        {
          memKeyName: 'MemEmailAddress',
          memKeyValue: 'charles_changepcp_dep@yopmail.com'
        },
        {
          memKeyName: 'IsVerifiedEmail',
          memKeyValue: 'false'
        },
        {
          memKeyName: 'MemPhoneNumber',
          memKeyValue: '2489955515'
        },
        {
          memKeyName: 'MemPhoneType',
          memKeyValue: 'MOBILE'
        },
        {
          memKeyName: 'IsVerifiedMobile',
          memKeyValue: 'false'
        },
        {
          memKeyName: 'EmailOptInStatus',
          memKeyValue: 'true'
        },
        {
          memKeyName: 'MobileOptInStatus',
          memKeyValue: 'false'
        }
      ]
    }
  }
};
