export let myaccount_resolver_data = [
  {
    accountinforesponse: [
      {
        hasActivePlan: 'true',
        planName: 'HMO BLUE NE OPTIONS DEDUCTIBLE',
        subscriberId: '050745419000000',
        groupName: 'TEST HMO NEHP PREMIUMGROUP 48',
        planType: '',
        groupNumber: '521309706',
        hasRx: 'true',
        planEffectiveDate: '02/09/2009',
        esi: {
          hasESI: 'true',
          hasESIMedex: 'false'
        }
      }
    ]
  }
];
