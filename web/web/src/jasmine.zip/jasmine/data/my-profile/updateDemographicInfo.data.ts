export let updateDemographicInfo_success_response = {
  result: 0,
  errormessage: '',
  displaymessage: ''
};
