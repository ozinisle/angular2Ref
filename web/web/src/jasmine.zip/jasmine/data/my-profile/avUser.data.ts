import { environment } from '../../../environments/environment';

export let jasAVUserData = {
  getMemProfileApiResponse: {
    useridin: 'dannew11@yopmail.com',
    fullName: 'DAN INCE',
    userState: 'AUTHENTICATED-AND-VERIFIED',
    dob: '1958-08-22',
    address1: '66D EARLE ST BLDG 8',
    address2: '',
    city: 'QUINCY',
    state: 'MA',
    zip: '02169',
    emailAddress: 'dannew12@yopmail.com',
    phoneNumber: '2489794028',
    phoneType: 'MOBILE',
    isVerifiedEmail: false,
    isVerifiedMobile: false,
    isEditableAddress: true,
    isDirectPay: false,
    isEmailOptedIn: true,
    isMobileOptedIn: true,
    hintQuestion: 'Who was your favorite teacher?',
    hintAnswer: 'teacher',
    gender: 'M',
    health: {
      allergies: [],
      conditions: []
    },
    dependents: [
      {
        depId: '100001305',
        fullName: 'MILLER INCE',
        dob: '2006-11-06',
        gender: 'M',
        health: {
          allergies: [],
          conditions: []
        }
      }
    ]
  },
  getMemProfile_After_NgOnint: {
    useridin: 'dannew11@yopmail.com',
    fullName: 'DAN INCE',
    userState: 'AUTHENTICATED-AND-VERIFIED',
    dob: '1958-08-22',
    address1: '66D EARLE ST BLDG 8',
    address2: '',
    city: 'QUINCY',
    state: 'MA',
    zip: '02169',
    emailAddress: 'dannew12@yopmail.com',
    phoneNumber: '2489794028',
    phoneType: 'MOBILE',
    isVerifiedEmail: false,
    isVerifiedMobile: false,
    isEditableAddress: true,
    isDirectPay: false,
    isEmailOptedIn: true,
    isMobileOptedIn: true,
    hintQuestion: 'Who was your favorite teacher?',
    hintAnswer: 'teacher',
    gender: 'M',
    health: {
      allergies: [],
      conditions: []
    },
    dependents: [
      {
        depId: '100001305',
        fullName: 'MILLER INCE',
        dob: '2006-11-06',
        gender: 'M',
        health: {
          allergies: [],
          conditions: []
        }
      }
    ]
  },
  authToken: {
    access_token: 'qX6KplFdEZGGF8N3y3Q6a8uf0z9X',
    access_token_expires: '2019-Sep-24T09:23:24.275+00:00',
    scopename: 'AUTHENTICATED-AND-VERIFIED',
    refresh_token: '6MXAr2IbrVS2QXoN3Zl687CcrWeWT5Pc',
    HasActivePlan: 'true',
    migrationtype: 'NONE',
    userType: 'MEMBER',
    destinationURL: null,
    issued: '2019-Sep-24T09:08:25.275+00:00',
    isALG: 'false',
    isHEQ: 'false',
    planTypes: {
      vision: 'false',
      medical: 'true',
      dental: 'false'
    },
    hasDependents: 'true',
    unreadMsgCount: '0',
    refresh_token_expires: '2019-Sep-24T09:38:24.275+00:00',
    refresh_count: null,
    firstName: 'DAN',
    syntheticID: '2DD0288F24372DC0DE4C33A78B6430E026EF7EB5'
  },
  postLogin: {
    hasSSO : false,
    hasCI : true,
    hasSS : false
  },
  authHttp: {
    uuid: 'f5f9dabf-bee6-4026-854d-6c992673f5e0'
  },
  commPreferenceService: {
    editEmail: false,
    editPhone: false,
    maskedVerify: ''
  },
  constantsService: {
    drupalTestUrl: environment.drupalTestUrl,
    contactus: `${environment.contactus}?scopename=`,
    displayMessage: {},
    getmemprofile: `${environment.serviceUrl}profile/getmemprofile`
  },
  validationService: {
    dobMask: [{}, {}, '/', {}, {}, '/', {}, {}, {}, {}],
    phoneMask: [{}, {}, {}, '-', {}, {}, {}, '-', {}, {}, {}, {}],
    phoneMaskRegister: ['(', {}, {}, {}, ')', {}, {}, {}, '-', {}, {}, {}, {}],
    ssnMask: [{}, {}, {}, {}],
    memIdMask: [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
    suffixMask: [{}, {}],
    accesscodeMask: [{}, {}, {}, {}, {}, {}],
    studentIdMask: [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
    medicareNumberMask: [{}, {}, {}, {}, '-', {}, {}, {}, '-', {}, {}, {}, {}],
    zipMask: [{}, {}, {}, {}, {}],
    numericMask: [{}],
    alphaNumericMask: [{}],
    numeric5Mask: [{}, {}, {}, {}, {}],
    numeric10Mask: [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
    API_INVALID_IDENTIFITERS: {
      dateOfBirth: 'MEM_DOB',
      firstName: 'MEM_FNAME',
      lastName: 'MEM_LNAME',
      memberId: 'MEM_NUM'
    },
    config: {
      minlength: 'Minimum length is requiredLength characters'
    },
    emailRegex: {},
    hintAnswerRegex: {},
    mobileRegex: {},
    mobileRegexRegister: {},
    ssnRegex: {},
    medicareNumberRegex: {},
    alphaStringRegex: {},
    numberRegex: {},
    studentIdRegex: {},
    alphaNumericRegex: {},
    specialCharactersRegex: {},
    trailingSpaceRegex: {}
  },

  getPreferences: {
    Preferences : [
      {
        CID: '5F2186704EDAB310A47255E0FA7B2587347183D5',
        ChannelID: 'MAIL',
        CustomerDate: '5/27/2020 7:49:00 AM',
        FilterID: 'DOCS_PLAN_MAIL',
        LastModifiedDate: '5/26/2020 10:19:03 PM',
        PreferenceAttributes: [
          {
            Key: 'PS_Update_Type', Value: 'U'
          },
          {
            Key: 'PS_EventID', Value: '86d3aa13-2394-4922-a742-553063ccf567'
          },
          {
            Key: 'PS_SystemName', Value: 'MyBlue_PC_WEB'
          },
          {
            Key: 'ConsentVerNo', Value: '2.0'
          }
        ],
        PreferenceType: 2,
        ProgramID: 'Documents_Plan',
        SourceID: 'BCMA_Pref_Centre_MYB_Web_Portal',
        UserID: 'BCMA_MYB_PC_Web'
      },
      {
        CID: '5F2186704EDAB310A47255E0FA7B2587347183D5',
        ChannelID: 'EMAIL',
        CustomerDate: '5/27/2020 7:49:00 AM',
        FilterID: 'BC_NEWS_EMAIL',
        LastModifiedDate: '5/26/2020 10:19:03 PM',
        PreferenceAttributes: [
          {
            Key: 'PS_Update_Type', Value: 'U'
          },
          {
            Key: 'PS_EventID', Value: '86d3aa13-2394-4922-a742-553063ccf567'
          },
          {
            Key: 'PS_SystemName', Value: 'MyBlue_PC_WEB'
          },
          {
            Key: 'ConsentVerNo', Value: '2.0'
          }
        ],
        PreferenceType: 1,
        ProgramID: 'BC_News',
        SourceID: 'BCMA_Pref_Centre_MYB_Web_Portal',
        UserID: 'BCMA_MYB_PC_Web'
      },
      {
        CID: '5F2186704EDAB310A47255E0FA7B2587347183D5',
        ChannelID: 'EMAIL',
        CustomerDate: '5/27/2020 7:49:00 AM',
        FilterID: 'HLTH_BENEFITS_EMAIL',
        LastModifiedDate: '5/26/2020 10:19:03 PM',
        PreferenceAttributes: [
          {
            Key: 'PS_Update_Type', Value: 'U'
          },
          {
            Key: 'PS_EventID', Value: '86d3aa13-2394-4922-a742-553063ccf567'
          },
          {
            Key: 'PS_SystemName', Value: 'MyBlue_PC_WEB'
          },
          {
            Key: 'ConsentVerNo', Value: '2.0'
          }
        ],
        PreferenceType: 1,
        ProgramID: 'Health_Benefits',
        SourceID: 'BCMA_Pref_Centre_MYB_Web_Portal',
        UserID: 'BCMA_MYB_PC_Web'
      },
      {
        CID: '5F2186704EDAB310A47255E0FA7B2587347183D5',
        ChannelID: 'SMS',
        CustomerDate: '5/27/2020 7:49:00 AM',
        FilterID: 'DOCS_PLAN_SMS',
        LastModifiedDate: '5/26/2020 10:19:03 PM',
        PreferenceAttributes: [
          {
            Key: 'PS_Update_Type', Value: 'U'
          },
          {
            Key: 'PS_EventID', Value: '86d3aa13-2394-4922-a742-553063ccf567'
          },
          {
            Key: 'PS_SystemName', Value: 'MyBlue_PC_WEB'
          },
          {
            Key: 'ConsentVerNo', Value: '2.0'
          }
        ],
        PreferenceType: 2,
        ProgramID: 'Documents_Plan',
        SourceID: 'BCMA_Pref_Centre_MYB_Web_Portal',
        UserID: 'BCMA_MYB_PC_Web'
      },
      {
        CID: '5F2186704EDAB310A47255E0FA7B2587347183D5',
        ChannelID: 'SMS',
        CustomerDate: '5/27/2020 7:49:00 AM',
        FilterID: 'HLTH_BENEFITS_SMS',
        LastModifiedDate: '5/26/2020 10:19:03 PM',
        PreferenceAttributes: [
          {
            Key: 'PS_Update_Type', Value: 'U'
          },
          {
            Key: 'PS_EventID', Value: '86d3aa13-2394-4922-a742-553063ccf567'
          },
          {
            Key: 'PS_SystemName', Value: 'MyBlue_PC_WEB'
          },
          {
            Key: 'ConsentVerNo', Value: '2.0'
          }
        ],
        PreferenceType: 2,
        ProgramID: 'Health_Benefits',
        SourceID: 'BCMA_Pref_Centre_MYB_Web_Portal',
        UserID: 'BCMA_MYB_PC_Web'
      },
      {
        CID: '5F2186704EDAB310A47255E0FA7B2587347183D5',
        ChannelID: 'SOLICIT',
        CustomerDate: '5/27/2020 7:49:00 AM',
        FilterID: 'DOCS_PLAN_ONLINE',
        LastModifiedDate: '5/26/2020 10:19:03 PM',
        PreferenceAttributes: [
          {
            Key: 'PS_Update_Type', Value: 'U'
          },
          {
            Key: 'PS_EventID', Value: '86d3aa13-2394-4922-a742-553063ccf567'
          },
          {
            Key: 'PS_SystemName', Value: 'MyBlue_PC_WEB'
          },
          {
            Key: 'ConsentVerNo', Value: '2.0'
          }
        ],
        PreferenceType: 1,
        ProgramID: 'Documents_Plan',
        SourceID: 'BCMA_Pref_Centre_MYB_Web_Portal',
        UserID: 'BCMA_MYB_PC_Web'
      },
      {
        CID: '5F2186704EDAB310A47255E0FA7B2587347183D5',
        ChannelID: 'SOLICIT',
        CustomerDate: '5/27/2020 7:49:00 AM',
        FilterID: 'CONSENT_PAPERLESS_SOLICIT',
        LastModifiedDate: '5/26/2020 10:19:03 PM',
        PreferenceAttributes: [
          {
            Key: 'PS_Update_Type', Value: 'U'
          },
          {
            Key: 'PS_EventID', Value: '86d3aa13-2394-4922-a742-553063ccf567'
          },
          {
            Key: 'PS_SystemName', Value: 'MyBlue_PC_WEB'
          },
          {
            Key: 'ConsentVerNo', Value: '2.0'
          }
        ],
        PreferenceType: 1,
        ProgramID: 'Consent_Paperless',
        SourceID: 'BCMA_Pref_Centre_MYB_Web_Portal',
        UserID: 'BCMA_MYB_PC_Web'
      },
    ]
  },

  getProgramGroups: {
    message: {
      ProgramGroup: [
          {
            ID: 'Docs_Reqd',
            Name: 'Required Documents',
            ProgramGroups: [],
            Programs: [
              {
                DefaultLocaleID: 'en_US',
                DisplayOrder: 1010,
                Filters: [
                  {
                    ChannelID: 'SOLICIT',
                    DefaultLocaleID: 'en_US',
                    DefaultPreferenceValue: 1,
                    ID: 'DOCS_PLAN_ONLINE',
                    Name: 'Go Paperless - Plan Docs Online notify via Email',
                    ProgramID: 'Documents_Plan',
                    selected: true
                  },
                  {
                    ChannelID: 'SMS',
                    DefaultLocaleID: 'en_US',
                    DefaultPreferenceValue: 0,
                    ID: 'DOCS_PLAN_SMS',
                    Name: 'Go Paperless - Plan Docs notifications via Text/SMS',
                    ProgramID: 'Documents_Plan',
                    selected: false
                  },
                  {
                    ChannelID: 'MAIL',
                    DefaultLocaleID: 'en_US',
                    DefaultPreferenceValue: 0,
                    ID: 'DOCS_PLAN_MAIL',
                    Name: 'Plan Documents - Mail',
                    ProgramID: 'Documents_Plan',
                    selected: false
                  }
                ],
                Locales: [
                  {
                    ID: 'en_US',
                    DisplayTags: [
                      {
                        Key: 'DisplayInUI',
                        Value: 'True'
                      },
                      {
                        Key: 'Name',
                        Value: 'Plan Documents'
                      }
                    ]
                  }
                ],
                ProgramType: 'Informational',
                displayName: 'Plan Documents',
                Name: 'Plan Documents'
              },
            ],
          },
          {
            ID: 'Consents_Available',
            Name: 'Available Consents',
            ProgramGroups: [],
            Programs: [
              {
                DefaultLocaleID: 'en_US',
                DisplayOrder: 1010,
                Filters: [
                  {
                    ChannelID: 'SOLICIT',
                    DefaultLocaleID: 'en_US',
                    DefaultPreferenceValue: 0,
                    ID: 'CONSENT_PAPERLESS_SOLICIT',
                    Name: 'Paperless Consent (s/b T&C) SOLICIT',
                    ProgramID: 'Consent_Paperless'
                  },
                ],
                Locales: [
                ],
                ProgramType: 'Consent',
                Name: 'Paperless Consent'
              },
            ],
          },
          {
            ID: 'Health_Wellness',
            Name: 'Health and Wellness',
            ProgramGroups: [],
            Programs: [
              {
                DefaultLocaleID: 'en_US',
                DisplayOrder: 1010,
                Filters: [
                  {
                    ChannelID: 'EMAIL',
                    DefaultLocaleID: 'en_US',
                    DefaultPreferenceValue: 1,
                    ID: 'HLTH_BENEFITS_EMAIL',
                    Name: 'Health and Benefits Email',
                    ProgramID: 'Health_Benefits',
                    selected: true
                  },
                  {
                    ChannelID: 'SMS',
                    DefaultLocaleID: 'en_US',
                    DefaultPreferenceValue: 0,
                    ID: 'HLTH_BENEFITS_SMS',
                    Name: 'Health and Benefits Text/SMS',
                    ProgramID: 'Health_Benefits',
                    selected: false
                  },
                ],
                Locales: [
                  {
                    ID: 'en_US',
                    DisplayTags: [
                      {
                        Key: 'DisplayInUI',
                        Value: 'True'
                      },
                      {
                        Key: 'Name',
                        Value: 'Manage Health & Maximize Benefits'
                      }
                    ]
                  }
                ],
                ProgramType: 'Informational',
                displayName: 'Manage Health & Maximize Benefits',
                Name: 'Health and Benefits'
              },
            ],
          },
          {
            ID: 'BC_News_Info',
            Name: 'Blue Cross News & Information',
            ProgramGroups: [],
            Programs: [
              {
                DefaultLocaleID: 'en_US',
                DisplayOrder: 1010,
                Filters: [
                  {
                    ChannelID: 'EMAIL',
                    DefaultLocaleID: 'en_US',
                    DefaultPreferenceValue: 1,
                    ID: 'BC_NEWS_EMAIL',
                    Name: 'BlueCross News - Email',
                    ProgramID: 'BC_NEWS',
                    selected: true
                  },
                ],
                Locales: [
                  {
                    ID: 'en_US',
                    DisplayTags: [
                      {
                        Key: 'DisplayInUI',
                        Value: 'True'
                      },
                      {
                        Key: 'Name',
                        Value: 'Blue Cross News'
                      }
                    ]
                  }
                ],
                ProgramType: 'Marketing',
                displayName: 'Blue Cross News',
                Name: 'Blue Cross News'
              },
            ],
          }
        ]
    }
  },

  getChangedPreferences: [
    {
      PreferenceType: '1',
      FilterID: 'DOCS_PLAN_ONLINE',
      CustomerDate: '2/21/2020 5:4:5 PM',
      PreferenceAttributes: [
        {
          Key: 'PS_Update_Type',
          Value: 'A'
        },
        {
          Key: 'PS_EventID',
          Value: '95891352-e75e-4234-8126-d82e9bf2aa40'
        },
        {
          Key: 'PS_SystemName',
          Value: 'MyBlue_PC_WEB'
        },
        {
          Key: 'ConsentVerNo',
          Value: '2.0'
        }
      ],
      CID: '74362C99D448EA3F8F9D759F2D1E5BF369DD1421'
    },
    {
      PreferenceType: '2',
      FilterID: 'DOCS_PLAN_SMS',
      CustomerDate: '2/21/2020 5:4:5 PM',
      PreferenceAttributes: [
        {
          Key: 'PS_Update_Type',
          Value: 'A'
        },
        {
          Key: 'PS_EventID',
          Value: '89e82b22-74de-45ca-92c6-1f7066eb8cf5'
        },
        {
          Key: 'PS_SystemName',
          Value: 'MyBlue_PC_WEB'
        },
        {
          Key: 'ConsentVerNo',
          Value: '2.0'
        }
      ],
      CID: '74362C99D448EA3F8F9D759F2D1E5BF369DD1421'
    },
    {
      PreferenceType: '2',
      FilterID: 'DOCS_PLAN_MAIL',
      CustomerDate: '2/21/2020 5:4:5 PM',
      PreferenceAttributes: [
        {
          Key: 'PS_Update_Type',
          Value: 'A'
        },
        {
          Key: 'PS_EventID',
          Value: '23273519-e6c1-45a3-bd3a-9b12e81b91a0'
        },
        {
          Key: 'PS_SystemName',
          Value: 'MyBlue_PC_WEB'
        },
        {
          Key: 'ConsentVerNo',
          Value: '2.0'
        }
      ],
      CID: '74362C99D448EA3F8F9D759F2D1E5BF369DD1421'
    },
    {
      PreferenceType: '2',
      FilterID: 'HLTH_BENEFITS_EMAIL',
      CustomerDate: '2/21/2020 5:4:5 PM',
      PreferenceAttributes: [
        {
          Key: 'PS_Update_Type',
          Value: 'A'
        },
        {
          Key: 'PS_EventID',
          Value: 'a0081694-2139-47e2-b2d6-307f7a0ff0c9'
        },
        {
          Key: 'PS_SystemName',
          Value: 'MyBlue_PC_WEB'
        },
        {
          Key: 'ConsentVerNo',
          Value: '2.0'
        }
      ],
      CID: '74362C99D448EA3F8F9D759F2D1E5BF369DD1421'
    },
    {
      PreferenceType: '2',
      FilterID: 'HLTH_BENEFITS_SMS',
      CustomerDate: '2/21/2020 5:4:5 PM',
      PreferenceAttributes: [
        {
          Key: 'PS_Update_Type',
          Value: 'A'
        },
        {
          Key: 'PS_EventID',
          Value: '84c87a7a-5a48-4563-baa5-64b2e95c4435'
        },
        {
          Key: 'PS_SystemName',
          Value: 'MyBlue_PC_WEB'
        },
        {
          Key: 'ConsentVerNo',
          Value: '2.0'
        }
      ],
      CID: '74362C99D448EA3F8F9D759F2D1E5BF369DD1421'
    },
    {
      PreferenceType: '2',
      FilterID: 'BC_NEWS_EMAIL',
      CustomerDate: '2/21/2020 5:4:5 PM',
      PreferenceAttributes: [
        {
          Key: 'PS_Update_Type',
          Value: 'A'
        },
        {
          Key: 'PS_EventID',
          Value: 'd568e32b-11d5-481d-92cb-a5a01418ae1e'
        },
        {
          Key: 'PS_SystemName',
          Value: 'MyBlue_PC_WEB'
        },
        {
          Key: 'ConsentVerNo',
          Value: '2.0'
        }
      ],
      CID: '74362C99D448EA3F8F9D759F2D1E5BF369DD1421'
    },
    {
      PreferenceType: '1',
      FilterID: 'CONSENT_PAPERLESS_SOLICIT',
      PreferenceAttributes: [
        {
          Key: 'PS_Update_Type',
          Value: 'A'
        },
        {
          Key: 'PS_EventID',
          Value: '408d892a-7044-4a46-b33b-4f80c94c78ba'
        },
        {
          Key: 'PS_SystemName',
          Value: 'MyBlue_PC_WEB'
        },
        {
          Key: 'ConsentVerNo',
          Value: '2.0'
        }
      ],
      CustomerDate: '02/19/2020 07:59:50 PM',
      CID: '74362C99D448EA3F8F9D759F2D1E5BF369DD1421'
    }
  ],

  getConsentData: {
    consentFlag: 'Y',
    consentLanguageId: '2.0',
    consentTS: '05/27/2020 07:49:01 AM',
    modalFlag: 'Y'
  }
};
