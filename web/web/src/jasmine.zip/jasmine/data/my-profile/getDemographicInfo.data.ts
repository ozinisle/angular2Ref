export let getDemographicInfo_response = {
  useridin: 'dannew11@yopmail.com',
  agree: false,
  race1: '',
  race2: '',
  ethnicity1: '',
  ethnicity2: '',
  latinoOrigin: '',
  primaryLang: '',
  lastupdate_ts: '',
  memberId: 'XXP050881571',
  subscriberId: '0508815710000',
  memberDOB: '1958-08-22',
  memberGender: 'M',
  memberFirstName: 'DAN',
  raceList: [
    {
      code: 'R1',
      description: 'American Indian/Alaska Native'
    },
    {
      code: 'R2',
      description: 'Asian'
    },
    {
      code: 'R3',
      description: 'Black/African American'
    },
    {
      code: 'R4',
      description: 'Native Hawaiian or other Pacific Islander'
    },
    {
      code: 'R9',
      description: 'Other Race'
    },
    {
      code: 'DK',
      description: 'Prefer Not to Answer'
    },
    {
      code: 'UNKNOW',
      description: 'Unknown/not specified'
    },
    {
      code: 'R5',
      description: 'White'
    }
  ],
  languageList: [
    {
      code: '799',
      description: 'African Languages (please specify)'
    },
    {
      code: '777',
      description: 'Arabic'
    },
    {
      code: '601',
      description: 'Cape Verdean Creole'
    },
    {
      code: '708',
      description: 'Chinese (please specify)'
    },
    {
      code: '600',
      description: 'English'
    },
    {
      code: '620',
      description: 'French'
    },
    {
      code: '607',
      description: 'German'
    },
    {
      code: '637',
      description: 'Greek'
    },
    {
      code: '623',
      description: 'Haitian Creole'
    },
    {
      code: '778',
      description: 'Hebrew'
    },
    {
      code: '663',
      description: 'Hindi'
    },
    {
      code: '619',
      description: 'Italian'
    },
    {
      code: '723',
      description: 'Japanese'
    },
    {
      code: '724',
      description: 'Korean'
    },
    {
      code: '997',
      description: 'Other Language (please specify)'
    },
    {
      code: '656',
      description: 'Persian'
    },
    {
      code: '645',
      description: 'Polish'
    },
    {
      code: '629',
      description: 'Portuguese'
    },
    {
      code: '998',
      description: 'Prefer Not to answer'
    },
    {
      code: '639',
      description: 'Russian'
    },
    {
      code: '625',
      description: 'Spanish'
    },
    {
      code: '742',
      description: 'Tagalog'
    },
    {
      code: '999',
      description: 'Unavailable'
    },
    {
      code: '671',
      description: 'Urdu'
    },
    {
      code: '728',
      description: 'Vietnamese'
    }
  ],
  ethnicityList: [
    {
      code: '2060-2',
      description: 'African'
    },
    {
      code: '2058-6',
      description: 'African American'
    },
    {
      code: '2028-9',
      description: 'Asian'
    },
    {
      code: '2029-7',
      description: 'Asian Indian'
    },
    {
      code: 'BRAZIL',
      description: 'Brazilian'
    },
    {
      code: '2033-9',
      description: 'Cambodian'
    },
    {
      code: 'CVERDN',
      description: 'Cape Verdean'
    },
    {
      code: 'CARIBI',
      description: 'Caribbean Island'
    },
    {
      code: '2155-0',
      description: 'Central American (not otherwise specified)'
    },
    {
      code: '2034-7',
      description: 'Chinese'
    },
    {
      code: '2169-1',
      description: 'Colombian'
    },
    {
      code: '2182-4',
      description: 'Cuban'
    },
    {
      code: '2184-0',
      description: 'Dominican'
    },
    {
      code: 'EASTEU',
      description: 'Eastern European'
    },
    {
      code: '2108-9',
      description: 'European'
    },
    {
      code: '2036-2',
      description: 'Filipino'
    },
    {
      code: '2157-6',
      description: 'Guatemalan'
    },
    {
      code: '2071-9',
      description: 'Haitian'
    },
    {
      code: '2158-4',
      description: 'Honduran'
    },
    {
      code: '2039-6',
      description: 'Japanese'
    },
    {
      code: '2040-4',
      description: 'Korean'
    },
    {
      code: '2041-2',
      description: 'Laotian'
    },
    {
      code: '2148-5',
      description: 'Mexican, Mexican American, Chicano'
    },
    {
      code: '2118-8',
      description: 'Middle Eastern'
    },
    {
      code: 'OTHER',
      description: 'Other Ethnicity'
    },
    {
      code: 'PORTUG',
      description: 'Portuguese'
    },
    {
      code: 'DK',
      description: 'Prefer Not to answer'
    },
    {
      code: '2180-8',
      description: 'Puerto Rican'
    },
    {
      code: 'RUSSIA',
      description: 'Russian'
    },
    {
      code: '2161-8',
      description: 'Salvadoran'
    },
    {
      code: '2165-9',
      description: 'South American (not otherwise specified)'
    },
    {
      code: 'UNKNOW',
      description: 'Unknown/not specified'
    },
    {
      code: '2047-9',
      description: 'Vietnamese'
    }
  ],
  latinoOriginList: [
    {
      code: 'N',
      description: 'No, I am NOT of Hispanic/Latino/Spanish origin'
    },
    {
      code: 'U',
      description: 'Prefer not to answer'
    },
    {
      code: 'U',
      description: 'Unknown/Not specified'
    },
    {
      code: 'Y',
      description: 'Yes, I am of Hispanic/Latino/Spanish origin'
    }
  ]
};
