export let getmemprofile_encoded_response = {
  result: 0,
  errormessage: '',
  displaymessage: '',
  message:
    'O93ZLjcTnqFVn2iLuOOsj4PLhOXrTUY8mzIEIEl0sJ651YKFeCpb6ScQPuTsCUl3Ase/uYg5P8oTopWljo0jnGhLWC4ePd416ND3iexiH6+T+WOcRw2Tk4/BWL6B5DhC/Ay6gysZjJ5lWPhbjtWZxV+1VEylSWKshO2mtRUpTyxlc/5l/MNHyEEEi4ZhOEf4qKOzu0JvPGePgjExb++blKZBTZMb07ipy+lG+zdfyAI97c9Iojjj7suvPv2ZNo7BDdfLTd4Q/TOy6Ilq16/IzXYCC22H+3oaYVneiGEbGV4gWlEY3VdS+wJSZ6dSasEH+dR05pMRpiKJGmyPqddVOHsg9LJ6veS1zvtLXC8NPLKh+oFj+k7EMA7Xk2cxoUyCAhBMXD+/QychrhwFKciSuIja8rezIMOUtMF+ZZmMbIpu6m8Erao9TwlJ3TsO1cVYlJt2VIMpKlfvJAadiMEbAbXcLIyZgZekzqI1aCYE4AVMk2PPP7r5g22Xh2ddgTVEFKyb6r/1OMO/g3r0tDNIYnc5RVe8+jbjgJXIdAiOusiOzrlotNScWYuOFaM4NP1o6y85OQDZS6r39RlosaLF8ApBwlJ/vKDvo/2ppa47mrcY4CegwMvE3nupd4jLbU0OIv7V1XeX3jM7c/Qir56lFb4U1zKu2Qk4YMQrZ9Ibmzb3cmhbHVqLb45SBcHHJPE1e75ega9g7CQJLuz0iGfxpU+9W/2N6L93MsT7AzaqMClTy3qfvXL1JY2karDIE9wskibMHzNHaUn/G8Uf7ipNdVTGryTgmFV36lqFyMkUgY4EeGeOEqhBdhZW/FBvIHRpr49/Gzedq9FnikNnpbNA1uNAs2iMFcqTt3yrcV7p74TPOd9BEZSEKbk0fMJjkHhCgaxZOeuCRAN0WAEak3d6HaWBPYoXfXEX6xxMDV6/Pqc='
};

export let getmemprofile_dencoded_response = {
  useridin: 'dannew11@yopmail.com',
  fullName: 'DAN INCE',
  userState: 'AUTHENTICATED-AND-VERIFIED',
  dob: '1958-08-22',
  address1: '66D EARLE ST BLDG 8',
  address2: '',
  city: 'QUINCY',
  state: 'MA',
  zip: '02169',
  emailAddress: 'dannew12@yopmail.com',
  phoneNumber: '2489794028',
  phoneType: 'MOBILE',
  isVerifiedEmail: false,
  isVerifiedMobile: false,
  isEditableAddress: true,
  isDirectPay: false,
  isEmailOptedIn: true,
  isMobileOptedIn: true,
  hintQuestion: 'Who was your favorite teacher?',
  hintAnswer: 'teacher',
  gender: 'M',
  health: {
    allergies: [],
    conditions: []
  },
  dependents: [
    {
      depId: '100001305',
      fullName: 'MILLER INCE',
      dob: '2006-11-06',
      gender: 'M',
      health: {
        allergies: [],
        conditions: []
      }
    }
  ]
};
