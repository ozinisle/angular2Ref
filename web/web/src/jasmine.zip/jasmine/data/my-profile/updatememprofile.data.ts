export let updatemem_success_response = {
  result: -90129,
  errormessage: '',
  displaymessage: 'Your request has been submitted. It could take up to 48 hours for the change to appear in MyBlue.'
};
