export let orderreplacement_service_getcard_error_response = {
  result: '-1',
  errormessage: 'You are accessing secure API system. Please provide valid security credentials required for this system.',
  displaymessage: 'You are accessing secure API system. Please provide valid security credentials required for this system.',
  error: true
};

export let orderreplacement_service_getcard_success_response = {
  SubscriberAddress: {
    NameLine_1: 'CHARLES  BROWN',
    NameLine_2: '',
    Address_Line1: '5647 PSGAME STREETS',
    Address_Line2: '',
    City: 'QUINCY',
    State: 'MA',
    Zip: '02169',
    Zip_4: ''
  },
  MemberDetails: [
    {
      MemberID: '00',
      MEMBFirstName: 'CHARLES',
      MEMBLastName: 'BROWN',
      Relationship: 'subscriber',
      PlanType: 'medical',
      PlanName: 'Network Blue Options Deductible',
      MaterialDistributionIndicator: '2',
      IDcardDistributionIndicator: 'H',
      IDcardLastprocessDate: '2019-10-24',
      RequestIDcardEligibilityIndicator: 'false',
      DateEligibilityIndicator: 'false',
      GroupNumber: '511300595',
      SubscriberNumber: '0508996660000',
      ReturnErrorCode: ''
    },
    {
      MemberID: '01',
      MEMBFirstName: 'JONATHAN',
      MEMBLastName: 'BROWN',
      Relationship: 'Spouse',
      PlanType: 'medical',
      PlanName: 'Network Blue Options Deductible',
      MaterialDistributionIndicator: '2',
      IDcardDistributionIndicator: 'H',
      IDcardLastprocessDate: '2019-09-19',
      RequestIDcardEligibilityIndicator: 'true',
      DateEligibilityIndicator: 'true',
      GroupNumber: '511300595',
      SubscriberNumber: '0508996660000',
      ReturnErrorCode: ''
    },
    {
      MemberID: '10',
      MEMBFirstName: 'JAMES',
      MEMBLastName: 'BROWN',
      Relationship: 'Dependent',
      PlanType: 'medical',
      PlanName: 'Network Blue Options Deductible',
      MaterialDistributionIndicator: '2',
      IDcardDistributionIndicator: 'H',
      IDcardLastprocessDate: '2019-09-19',
      RequestIDcardEligibilityIndicator: 'true',
      DateEligibilityIndicator: 'true',
      GroupNumber: '511300595',
      SubscriberNumber: '0508996660000',
      ReturnErrorCode: ''
    },
    {
      MemberID: '11',
      MEMBFirstName: 'DOMINIC',
      MEMBLastName: 'BROWN',
      Relationship: 'Dependent',
      PlanType: 'medical',
      PlanName: 'Network Blue Options Deductible',
      MaterialDistributionIndicator: '2',
      IDcardDistributionIndicator: 'H',
      RequestIDcardEligibilityIndicator: 'true',
      DateEligibilityIndicator: 'true',
      GroupNumber: '511300595',
      SubscriberNumber: '0508996660000',
      ReturnErrorCode: ''
    }
  ]
};

export let orderreplacement_service_submitCard_success_response = {
  resultSet: [
    {
      result: '0',
      errorMessage: '01',
      displayMessage: '',
      memberID: '01',
      subscriberNumber: '0508996660000'
    },
    {
      result: '0',
      errorMessage: '10',
      displayMessage: '',
      memberID: '10',
      subscriberNumber: '0508996660000'
    }
  ]
};
