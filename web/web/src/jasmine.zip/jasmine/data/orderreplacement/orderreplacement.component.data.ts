export let orderreplacement_component_resolver_data = {
  SubscriberAddress: {
    NameLine_1: 'CHARLES  BROWN',
    NameLine_2: '',
    Address_Line1: '5647 PSGAME STREETS',
    Address_Line2: '',
    City: 'QUINCY',
    State: 'MA',
    Zip: '02169',
    Zip_4: ''
  },
  MemberDetails: [
    {
      MemberID: '00',
      MEMBFirstName: 'CHARLES',
      MEMBLastName: 'BROWN',
      Relationship: 'subscriber',
      PlanType: 'medical',
      PlanName: 'Network Blue Options Deductible',
      MaterialDistributionIndicator: '2',
      IDcardDistributionIndicator: 'H',
      IDcardLastprocessDate: '2019-10-24',
      RequestIDcardEligibilityIndicator: 'false',
      DateEligibilityIndicator: 'false',
      GroupNumber: '511300595',
      SubscriberNumber: '0508996660000',
      ReturnErrorCode: ''
    },
    {
      MemberID: '01',
      MEMBFirstName: 'JONATHAN',
      MEMBLastName: 'BROWN',
      Relationship: 'Spouse',
      PlanType: 'medical',
      PlanName: 'Network Blue Options Deductible',
      MaterialDistributionIndicator: '2',
      IDcardDistributionIndicator: 'H',
      IDcardLastprocessDate: '2019-09-19',
      RequestIDcardEligibilityIndicator: 'true',
      DateEligibilityIndicator: 'true',
      GroupNumber: '511300595',
      SubscriberNumber: '0508996660000',
      ReturnErrorCode: ''
    },
    {
      MemberID: '10',
      MEMBFirstName: 'JAMES',
      MEMBLastName: 'BROWN',
      Relationship: 'Dependent',
      PlanType: 'medical',
      PlanName: 'Network Blue Options Deductible',
      MaterialDistributionIndicator: '2',
      IDcardDistributionIndicator: 'H',
      IDcardLastprocessDate: '2019-09-19',
      RequestIDcardEligibilityIndicator: 'true',
      DateEligibilityIndicator: 'true',
      GroupNumber: '511300595',
      SubscriberNumber: '0508996660000',
      ReturnErrorCode: ''
    },
    {
      MemberID: '11',
      MEMBFirstName: 'DOMINIC',
      MEMBLastName: 'BROWN',
      Relationship: 'Dependent',
      PlanType: 'medical',
      PlanName: 'Network Blue Options Deductible',
      MaterialDistributionIndicator: '2',
      IDcardDistributionIndicator: 'H',
      RequestIDcardEligibilityIndicator: 'true',
      DateEligibilityIndicator: 'true',
      GroupNumber: '511300595',
      SubscriberNumber: '0508996660000',
      ReturnErrorCode: ''
    }
  ]
};
