export let getclaimprocessingstatus_response = {
  success: {
    statusRecord: {
      claimId: '020181721502100',
      claimStatus: 'Completed',
      dateOfService: '2017-02-22',
      firstDateOfService: '2017-02-22',
      lastDateOfService: '2017-02-22',
      recievedDate: '2017-02-22',
      completedDate: '2017-02-26'
    }
  },
  failure: {
    result: '-1',
    errormessage: 'You are accessing secure API system. Please provide valid security credentials required for this system.',
    displaymessage: 'You are accessing secure API system. Please provide valid security credentials required for this system.',
    error: true
  }
};
