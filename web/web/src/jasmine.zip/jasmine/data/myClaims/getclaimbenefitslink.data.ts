export let getClaimBenefitsLink_response = {
  failure: {
    displaymessage:
      "We're experiencing technical difficulties. Please try again later. For immediate assistance, call 1-888-772-1722.(-90200)",
    errormessage: 'Claim Process Date is empty in the input message.',
    result: -90200
  },
  success: {
    result: 0,
    eobLink: 'mockEobLink'
  }
};
