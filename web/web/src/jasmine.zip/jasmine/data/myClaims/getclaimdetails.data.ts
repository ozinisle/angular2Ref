export let getclaimdetails_response = {
  failure: {
    result: '-1',
    errormessage: 'You are accessing secure API system. Please provide valid security credentials required for this system.',
    displaymessage: 'You are accessing secure API system. Please provide valid security credentials required for this system.',
    error: true
  },
  success: {
    memberName: 'MILLER INCE',
    memberType: 'Dependent',
    medicareFlag: false,
    medexFlag: false,
    claimId: '020181721502500',
    eobClaimId: '20181721502500',
    claimStatus: 'Completed',
    claimStatusDescription: 'Complete',
    providerName: "KLEIN'S SHOPRITE PHARMACY",
    providerAddress: {
      address1: '2101 ROCK SPRING RD',
      address2: '',
      city: 'FOREST HILL',
      state: 'MD',
      zipcode: '21050',
      phone: '4104208224    ',
      text: ''
    },
    amountCovered: 103.02,
    amountOwed: 20.76,
    dateOfService: '2018-07-19',
    firstDateOfService: '2018-07-19',
    lastDateOfService: '2018-07-19',
    visitType: 'Medical',
    planName: 'OUTOFSCOPE',
    claimTotals: {
      amountCharged: 34.34,
      amountAllowed: 6.92,
      amountCoveredByBCBS: 0,
      amountCoveredByOthers: 0,
      coPayments: 6.92,
      appliedToDeductible: 0,
      coinsurance: 0,
      amountNotCovered: 0,
      amountOwed: 6.92
    },
    claimServiceLines: [
      {
        amountCharged: 34.34,
        amountAllowed: 6.92,
        amountCoveredByBCBS: 0,
        amountCoveredByOthers: 0,
        coPayments: 0,
        appliedToDeductible: 0,
        coinsurance: 0,
        amountNotCovered: 0,
        amountOwed: 6.92
      }
    ],
    directPayIndicator: false
  }
};
