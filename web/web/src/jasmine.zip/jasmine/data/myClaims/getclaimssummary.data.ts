export let getclaimssummary_response = [
  {
    summaryMetaData: {
      totalRecordCount: 14,
      hasMoreRecords: false,
      sortOrder: 'Most Recent'
    },
    filtersMetadata: {
      dateMetaData: {
        dateMetaList: [
          {
            dateRange: 'All dates',
            dateCount: 14
          }
        ]
      },
      memberTypeMetaData: {
        memberTypeMetaList: [
          {
            memberName: 'DAN INCE',
            memberCount: 8
          },
          {
            memberName: 'MILLER INCE',
            memberCount: 6
          }
        ]
      },
      providerMetaData: {
        providerMetaList: [
          {
            providerName: 'MARY C WHITMAN MD',
            providerCount: 1
          },
          {
            providerName: "KLEIN'S SHOPRITE PHARMACY",
            providerCount: 12
          },
          {
            providerName: 'MEDSTAR EMS INC',
            providerCount: 1
          }
        ]
      },
      visitTypeMetaData: {
        visitTypeMetaList: [
          {
            visitType: 'Medical',
            visitTypeCount: 7
          },
          {
            visitType: 'Pharmacy',
            visitTypeCount: 7
          }
        ]
      },
      claimStatusMetaData: {
        claimStatusMetaList: [
          {
            status: 'Completed',
            statusCount: 14
          }
        ]
      }
    },
    memberRecord: [
      {
        memberName: 'MILLER INCE',
        memberType: 'Dependent',
        providerName: "KLEIN'S SHOPRITE PHARMACY",
        claimId: '020181721502700',
        claimStatus: 'Completed',
        amountCovered: 103.02,
        amountOwed: 20.76,
        dateOfService: '2018-07-19',
        firstDateOfService: '2018-07-19',
        lastDateOfService: '2018-07-19',
        visitType: 'Medical'
      },
      {
        memberName: 'MILLER INCE',
        memberType: 'Dependent',
        providerName: "KLEIN'S SHOPRITE PHARMACY",
        claimId: '020181721502500',
        claimStatus: 'Completed',
        amountCovered: 103.02,
        amountOwed: 20.76,
        dateOfService: '2018-07-19',
        firstDateOfService: '2018-07-19',
        lastDateOfService: '2018-07-19',
        visitType: 'Medical'
      },
      {
        memberName: 'MILLER INCE',
        memberType: 'Dependent',
        providerName: "KLEIN'S SHOPRITE PHARMACY",
        claimId: '020181721499100',
        claimStatus: 'Completed',
        amountCovered: 103.02,
        amountOwed: 20.76,
        dateOfService: '2018-07-19',
        firstDateOfService: '2018-07-19',
        lastDateOfService: '2018-07-19',
        visitType: 'Medical'
      },
      {
        memberName: 'MILLER INCE',
        memberType: 'Dependent',
        providerName: "KLEIN'S SHOPRITE PHARMACY",
        claimId: '020181721498900',
        claimStatus: 'Completed',
        amountCovered: 103.02,
        amountOwed: 20.76,
        dateOfService: '2018-07-19',
        firstDateOfService: '2018-07-19',
        lastDateOfService: '2018-07-19',
        visitType: 'Medical'
      },
      {
        memberName: 'DAN INCE',
        memberType: 'Subscriber',
        providerName: "KLEIN'S SHOPRITE PHARMACY",
        claimId: '020181721498400',
        claimStatus: 'Completed',
        amountCovered: 103.02,
        amountOwed: 20.76,
        dateOfService: '2018-07-19',
        firstDateOfService: '2018-07-19',
        lastDateOfService: '2018-07-19',
        visitType: 'Medical'
      },
      {
        memberName: 'DAN INCE',
        memberType: 'Subscriber',
        providerName: 'MEDSTAR EMS INC',
        claimId: '020185664545100',
        claimStatus: 'Completed',
        amountCovered: 9000,
        amountOwed: 194.97,
        dateOfService: '2018-07-01',
        firstDateOfService: '2018-07-01',
        lastDateOfService: '2018-07-01',
        visitType: 'Medical'
      },
      {
        memberName: 'DAN INCE',
        memberType: 'Subscriber',
        providerName: 'MARY C WHITMAN MD',
        claimId: '020185664545100',
        claimStatus: 'Completed',
        amountCovered: 1698,
        amountOwed: 90,
        dateOfService: '2018-07-01',
        firstDateOfService: '2018-07-01',
        lastDateOfService: '2018-07-01',
        visitType: 'Medical'
      },
      {
        memberName: 'DAN INCE',
        memberType: 'Subscriber',
        providerName: "KLEIN'S SHOPRITE PHARMACY",
        claimId: '020181721502000',
        claimStatus: 'Completed',
        amountCovered: 103.02,
        amountOwed: 20.76,
        dateOfService: '2017-02-22',
        firstDateOfService: '2017-02-22',
        lastDateOfService: '2017-02-22',
        visitType: 'Pharmacy'
      },
      {
        memberName: 'DAN INCE',
        memberType: 'Subscriber',
        providerName: "KLEIN'S SHOPRITE PHARMACY",
        claimId: '020181721501900',
        claimStatus: 'Completed',
        amountCovered: 103.02,
        amountOwed: 20.76,
        dateOfService: '2017-02-22',
        firstDateOfService: '2017-02-22',
        lastDateOfService: '2017-02-22',
        visitType: 'Pharmacy'
      },
      {
        memberName: 'DAN INCE',
        memberType: 'Subscriber',
        providerName: "KLEIN'S SHOPRITE PHARMACY",
        claimId: '020181721498500',
        claimStatus: 'Completed',
        amountCovered: 103.02,
        amountOwed: 20.76,
        dateOfService: '2017-02-22',
        firstDateOfService: '2017-02-22',
        lastDateOfService: '2017-02-22',
        visitType: 'Pharmacy'
      },
      {
        memberName: 'DAN INCE',
        memberType: 'Subscriber',
        providerName: "KLEIN'S SHOPRITE PHARMACY",
        claimId: '020181721498300',
        claimStatus: 'Completed',
        amountCovered: 103.02,
        amountOwed: 20.76,
        dateOfService: '2017-02-22',
        firstDateOfService: '2017-02-22',
        lastDateOfService: '2017-02-22',
        visitType: 'Pharmacy'
      },
      {
        memberName: 'MILLER INCE',
        memberType: 'Dependent',
        providerName: "KLEIN'S SHOPRITE PHARMACY",
        claimId: '020181721502600',
        claimStatus: 'Completed',
        amountCovered: 103.02,
        amountOwed: 20.76,
        dateOfService: '2017-02-22',
        firstDateOfService: '2017-02-22',
        lastDateOfService: '2017-02-22',
        visitType: 'Pharmacy'
      },
      {
        memberName: 'MILLER INCE',
        memberType: 'Dependent',
        providerName: "KLEIN'S SHOPRITE PHARMACY",
        claimId: '020181721499000',
        claimStatus: 'Completed',
        amountCovered: 103.02,
        amountOwed: 20.76,
        dateOfService: '2017-02-22',
        firstDateOfService: '2017-02-22',
        lastDateOfService: '2017-02-22',
        visitType: 'Pharmacy'
      },
      {
        memberName: 'DAN INCE',
        memberType: 'Subscriber',
        providerName: "KLEIN'S SHOPRITE PHARMACY",
        claimId: '020181721502100',
        claimStatus: 'Completed',
        amountCovered: 103.02,
        amountOwed: 20.76,
        dateOfService: '2017-02-22',
        firstDateOfService: '2017-02-22',
        lastDateOfService: '2017-02-22',
        visitType: 'Pharmacy'
      }
    ],
    directPayIndicator: false
  }
];
