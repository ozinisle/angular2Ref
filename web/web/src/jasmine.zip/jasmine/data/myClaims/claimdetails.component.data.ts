export let claimDetails_component_data = {
  claimsRecord_sessionStorage: null,
  authToken_sessionStorage: {
    access_token: 'iD2VDMC0G7o7jwIunbOd0c9NownP',
    access_token_expires: '2019-Oct-14T09:35:51.775+00:00',
    scopename: 'AUTHENTICATED-AND-VERIFIED',
    refresh_token: 'A1reN7H0iprXA4jazyr89WIaAepmFj0R',
    HasActivePlan: 'true',
    migrationtype: 'NONE',
    userType: 'MEMBER',
    destinationURL: null,
    issued: '2019-Oct-14T09:20:52.775+00:00',
    isALG: 'false',
    isHEQ: 'false',
    planTypes: { vision: 'false', medical: 'true', dental: 'false' },
    hasDependents: 'true',
    unreadMsgCount: '0',
    refresh_token_expires: '2019-Oct-14T09:50:51.775+00:00',
    refresh_count: null,
    firstName: 'DAN',
    syntheticID: '2DD0288F24372DC0DE4C33A78B6430E026EF7EB5'
  }
};
