export let getDependents_response = {
  dependents: [
    {
      dependent: {
        depId: 100001305,
        firstName: 'MILLER',
        lastName: 'INCE',
        middleInitial: '',
        relationship: 'Dependent',
        memNum: '050881571000010',
        cardId: 'XXP050881571',
        suffix: '10'
      }
    }
  ]
};
