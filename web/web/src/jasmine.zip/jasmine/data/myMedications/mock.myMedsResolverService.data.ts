export let mockMyMedsResolverServiceData = {
  breadcrumb: 'My Medication',
  medsInfo: {
    MemBasicInfo: {
      rxSummary: {
        memFirstName: 'DAN',
        memMiddleInitial: '',
        memLastName: 'INCE',
        subNum: '0508815710000',
        suffix: '00',
        hasDependents: true,
        relationship: 'Subscriber'
      }
    },
    MedRecords: [
      {
        rxSummary: [
          {
            genericName: 'Rosuvastatin Calcium Tab 40 MG',
            pharmacy: {
              id: '70010002236544',
              name: 'STAR PHARMACY',
              phoneNumber: '617-782-1628'
            },
            copay: 10,
            lastFill: '2018-04-02',
            prescribingDoctor: 'PATTY M YOFFE MD',
            ndcCd: '00310075430',
            rxIncurredDate: '2018-04-02'
          },
          {
            genericName: 'Albuterol Sulfate Inhal Aero 108 MCG/ACT (90MCG Base Equiv)',
            pharmacy: {
              id: '70010002235287',
              name: 'CVS',
              phoneNumber: '413-567-8961'
            },
            copay: 10,
            lastFill: '2018-04-01',
            prescribingDoctor: 'MARTHA H MCLOUGHLIN MD',
            ndcCd: '59310057922',
            rxIncurredDate: '2018-04-01'
          },
          {
            genericName: 'Sildenafil Citrate Tab 100 MG',
            pharmacy: {
              id: '70010000712972',
              name: 'CVS',
              phoneNumber: '860-621-1996'
            },
            copay: 10,
            lastFill: '2018-03-31',
            prescribingDoctor: 'THOMAS J SAVINELLI',
            ndcCd: '00093534356',
            rxIncurredDate: '2018-03-31'
          },
          {
            genericName: 'Tadalafil Tab 20 MG',
            pharmacy: {
              id: '70010002224842',
              name: 'CVS',
              phoneNumber: '413-532-3299'
            },
            copay: 10,
            lastFill: '2018-02-25',
            prescribingDoctor: 'HENRY E SIMKIN MD',
            ndcCd: '00002446430',
            rxIncurredDate: '2018-02-25'
          },
          {
            genericName: 'Albuterol Sulfate Inhal Aero 108 MCG/ACT (90MCG Base Equiv)',
            pharmacy: {
              id: '70010000713392',
              name: 'CVS',
              phoneNumber: '860-829-0800'
            },
            copay: 10,
            lastFill: '2018-02-24',
            prescribingDoctor: 'JASONL LEE',
            ndcCd: '59310057922',
            rxIncurredDate: '2018-02-24'
          },
          {
            genericName: 'Naproxen Tab 375 MG',
            pharmacy: {
              id: '70010002226620',
              name: 'CVS',
              phoneNumber: '413-786-4100'
            },
            copay: 10,
            lastFill: '2018-02-23',
            prescribingDoctor: 'ROXANNE R SPRAGUE PAC',
            ndcCd: '65162018910',
            rxIncurredDate: '2018-02-23'
          }
        ]
      },
      {
        rxSummary: [
          {
            genericName: 'Albuterol Sulfate Inhal Aero 108 MCG/ACT (90MCG Base Equiv)',
            pharmacy: {
              id: '70010002235287',
              name: 'CVS',
              phoneNumber: '413-567-8961'
            },
            copay: 10,
            lastFill: '2018-03-27',
            prescribingDoctor: 'MARTHA H MCLOUGHLIN MD',
            ndcCd: '59310057922',
            rxIncurredDate: '2018-03-27',
            MemberInfo: 'Miller Ince (Dependent)',
            dependentId: 100001305
          },
          {
            genericName: 'Cyclobenzaprine HCl Tab 10 MG',
            pharmacy: {
              id: '70010000712833',
              name: 'STOP AND SHOP',
              phoneNumber: '860-741-2230'
            },
            copay: 10,
            lastFill: '2018-03-25',
            prescribingDoctor: 'HOWARD RO MD',
            ndcCd: '43547040011',
            rxIncurredDate: '2018-03-25',
            MemberInfo: 'Miller Ince (Dependent)',
            dependentId: 100001305
          },
          {
            genericName: 'Benzonatate Cap 100 MG',
            pharmacy: {
              id: '70010000719344',
              name: 'STOP AND SHOP',
              phoneNumber: '860-652-9208'
            },
            copay: 10,
            lastFill: '2018-02-19',
            prescribingDoctor: 'LAURA R SIEVERING',
            ndcCd: '67877057301',
            rxIncurredDate: '2018-02-19',
            MemberInfo: 'Miller Ince (Dependent)',
            dependentId: 100001305
          },
          {
            genericName: 'Tobramycin-Dexamethasone Ophth Susp 0.3-0.1%',
            pharmacy: {
              id: '70010002241812',
              name: 'WALGREENS',
              phoneNumber: '413-586-1190'
            },
            copay: 10,
            lastFill: '2018-02-18',
            prescribingDoctor: 'BARRY R JACOBS MD',
            ndcCd: '61314064705',
            rxIncurredDate: '2018-02-18',
            MemberInfo: 'Miller Ince (Dependent)',
            dependentId: 100001305
          },
          {
            genericName: 'Naproxen Tab 500 MG',
            pharmacy: {
              id: '70010002226389',
              name: 'CVS',
              phoneNumber: '413-562-5181'
            },
            copay: 10,
            lastFill: '2018-02-17',
            prescribingDoctor: 'MICHAEL GILLIS PA',
            ndcCd: '65162019050',
            rxIncurredDate: '2018-02-17',
            MemberInfo: 'Miller Ince (Dependent)',
            dependentId: 100001305
          }
        ]
      }
    ]
  }
};
