export let consumerEnrollmentResponse = {
  success: {
    result: 0,
    errormessage: '',
    displaymessage: '',
    isConsumerEnrolled: true
  },
};



