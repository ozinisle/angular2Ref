import { async, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { YesGuard } from '../../../../../app/shared/utils/yes.guard';
import { mocks } from '../../../../constants/mocks.service';
import { MockRouter } from '../../../../mock-classes/mock-router.class';

describe('YesGuard', () => {
  describe('canActivate', () => {
    let guard: YesGuard;
    let router;
    let mockRouter;

    beforeEach(async(() => {
      mockRouter = mocks.service.router;
      router = new MockRouter();
      guard = new YesGuard(router);

      TestBed.configureTestingModule({
        providers: [YesGuard, { provide: Router, useValue: mockRouter }]
      });
      guard = TestBed.get(YesGuard);
    }));

    it('should allowed canActivate if return true', () => {
      // act

      const canActivateGuard = guard.canActivate();

      // assert

      expect(canActivateGuard).toBeTruthy();
    });

    it('should call the sessionStorage.getItem', () => {
      // act
      const sessionResult = spyOn(sessionStorage.__proto__, 'getItem');
      const result = guard.canActivate();

      // assert
      expect(sessionResult).toHaveBeenCalledTimes(1);
    });

    xit('should redirect to home page if !sessionStorage.getItem("userState")', () => {
      spyOn(router, 'navigate');

      // act
      const userState = spyOn(sessionStorage.__proto__, 'getItem').and.returnValue(false);
      guard.canActivate();

      // assert
      if (userState) {
        expect(router.navigate).toHaveBeenCalledWith(['home']);
      }
    });
  });
});
