import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { inject, TestBed } from '@angular/core/testing';
import { Store } from '@ngrx/store';
import { LoadingSpinnerService } from '../../../../../app/core/components/loading-spinner';
import { ImpersonationRequest } from '../../../../../app/shared/models/impersonationRequest.model';
import { AuthHttp } from '../../../../../app/shared/services/auth-http.service';
import { AuthService, ConstantsService } from '../../../../../app/shared/shared.module';
import { mocks } from '../../../../constants/mocks.service';
import { MockStore } from '../../../../mock-classes/mock-store.class';

describe('AuthHttp', () => {
  let mockAuthService;
  let mockConstantsService;
  let mockSpinnerService;
  const mockStore = new MockStore();

  beforeEach(() => {
    mockAuthService = mocks.service.authService;
    mockConstantsService = mocks.service.constantsService;
    mockSpinnerService = mocks.service.spinnerService;

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        HttpTestingController,
        { provide: AuthService, useValue: mockAuthService },
        { provide: ConstantsService, useValue: mockConstantsService },
        { provide: LoadingSpinnerService, useValue: mockSpinnerService },
        { provide: Store, useValue: mockStore },
        AuthHttp
      ]
    });
  });

  it('should be created', inject([AuthHttp], (service: AuthHttp) => {
    expect(service).toBeTruthy();
  }));

  describe('methods', () => {
    describe('impersonation', () => {
      xit('should have called this.authService.getTokens() method', inject([AuthHttp], (service: AuthHttp) => {
        // arrange
        const request = new ImpersonationRequest();

        // act
        service.impersonation(request);

        // assert
        expect(mockAuthService.getTokens).toHaveBeenCalled();
      }));
    });
  });
});
