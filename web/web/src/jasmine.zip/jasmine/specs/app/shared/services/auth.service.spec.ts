import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { inject, TestBed } from '@angular/core/testing';
import { AlertService, AuthService, ConstantsService } from '../../../../../app/shared/shared.module';
import { environment } from '../../../../../environments/environment';
import { mocks } from '../../../../constants/mocks.service';

describe('AuthService', () => {
  let mockConstantsService;
  let mockAlertService;

  beforeEach(() => {
    mockConstantsService = mocks.service.constantsService;
    mockAlertService = mocks.service.alertService;

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        HttpTestingController,
        { provide: AlertService, useValue: mockAlertService },
        AuthService,
        ConstantsService
      ]
    });
  });

  it('should be created', inject([AuthService], (service: AuthService) => {
    expect(service).toBeTruthy();
  }));

  it('should have initialized this.impersonate to false by default', inject([AuthService], (service: AuthService) => {
    expect(service.impersonate).toBeFalsy();
  }));

  describe('methods', () => {
    describe('impersonation', () => {
      it('should have updated this.impersonate to environment.impersonation', inject([AuthService], (service: AuthService) => {
        // act
        service.impersonation();

        // assert
        expect(service.impersonate).toBe(environment.impersonation);
      }));
      it('should return the value of environment.impersonation', inject([AuthService], (service: AuthService) => {
        // act
        const result = service.impersonation();

        // assert
        expect(result).toBe(environment.impersonation);
      }));
    });
  });
});
