import { SafePipe } from '../../../../../app/shared/pipes/safe.pipe';
import { TestBed, async } from '@angular/core/testing';
import { DomSanitizer, BrowserModule } from '@angular/platform-browser';

describe('SafePipe', () => {
  const domSanitizer = {
    sanitize: (ctx: any, val: string) => val,
    bypassSecurityTrustHtml: (val: string) => val,
    bypassSecurityTrustStyle : (val: string) => val,
    bypassSecurityTrustScript: (val: string) => val,
    bypassSecurityTrustUrl: (val: string) => val,
    bypassSecurityTrustResourceUrl: (val: string) => val
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        BrowserModule
      ],
      providers: [
        {
          provide: DomSanitizer,
          useValue: domSanitizer
        }
      ],
      declarations: [ SafePipe ],
    })
      .compileComponents();
  }));
  it('create an instance', () => {
    const pipe = new SafePipe(domSanitizer);
    expect(pipe).toBeTruthy();
  });
});
