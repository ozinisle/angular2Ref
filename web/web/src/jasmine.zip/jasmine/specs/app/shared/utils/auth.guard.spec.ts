import { async, TestBed } from '@angular/core/testing';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';
import { AuthService } from '../../../../../app/shared/shared.module';
import { AuthGuard } from '../../../../../app/shared/utils/auth.guard';
import { mocks } from '../../../../constants/mocks.service';
import { MockRouter } from '../../../../mock-classes/mock-router.class';

describe('AuthGuard', () => {
  describe('canActivate', () => {
    let guard: AuthGuard;
    let router;
    let mockRouter;
    let mockAuthService;

    beforeEach(async(() => {
      mockAuthService = mocks.service.authService;
      mockRouter = mocks.service.router;
      router = new MockRouter();
      guard = new AuthGuard(router, mockAuthService);

      TestBed.configureTestingModule({
        providers: [AuthGuard, { provide: AuthService, useValue: mockAuthService }, { provide: Router, useValue: mockRouter }]
      });
      guard = TestBed.get(AuthGuard);

      let store = {};

      spyOn(localStorage, 'getItem').and.callFake(
        (key: string) => {
          return store[key] || null;
        }
      );
      spyOn(localStorage, 'removeItem').and.callFake((key: string): void => {
        delete store[key];
      });
      spyOn(localStorage, 'setItem').and.callFake((key: string, value: string): string => {
        return (store[key] = value as string);
      });
      spyOn(localStorage, 'clear').and.callFake(() => {
        store = {};
      });
    }));

    it('should called this.authService.isAuthenticated', () => {
      // arrange
      const next = {
        parent: {
          routeConfig: { path: '' }
        }
      } as ActivatedRouteSnapshot;

      // act
      guard.canActivate(next, {} as RouterStateSnapshot);

      // assert

      expect(mockAuthService.isAuthenticated).toHaveBeenCalled();
    });

    it('should return true if isAuthenticated==true', () => {
      // arrange
      const next = {
        parent: {
          routeConfig: { path: '' }
        }
      } as ActivatedRouteSnapshot;

      // act
      const isAuthenticated = mockAuthService.isAuthenticated();
      guard.canActivate(next, {} as RouterStateSnapshot);

      // assert

      expect(isAuthenticated).toBeTruthy();
    });

    it('should call the localStorage.setItem', () => {
      // arrange
      const next = {
        parent: {
          routeConfig: { path: '' }
        }
      } as ActivatedRouteSnapshot;

      // act
      // let settargetRoute = spyOn(localStorage.__proto__, 'setItem');
      const isAuthenticated = mockAuthService.isAuthenticated();
      guard.canActivate(next, {} as RouterStateSnapshot);

      // assert
      if (isAuthenticated) {
        expect(localStorage.getItem('targetRoute')).toBe(null);
      }
    });

    xit('should call the localStorage.getItem', () => {
      // arrange
      const next = {
        parent: {
          routeConfig: { path: '' }
        }
      } as ActivatedRouteSnapshot;

      // act
      const isAuthenticated = mockAuthService.isAuthenticated();

      guard.canActivate(next, {} as RouterStateSnapshot);

      // assert
      if (isAuthenticated) {
        expect(localStorage.getItem).toHaveBeenCalled();
      }
    });

    it('should call the localStorage.removeItem', () => {
      // arrange
      const next = {
        parent: {
          routeConfig: { path: '' }
        }
      } as ActivatedRouteSnapshot;

      // act
      // let removetargetRoute = spyOn(localStorage.__proto__, 'removeItem');
      const isAuthenticated = mockAuthService.isAuthenticated();
      guard.canActivate(next, {} as RouterStateSnapshot);

      // assert
      if (isAuthenticated) {
        expect(localStorage.removeItem('targetRoute')).toBeUndefined();
      }
    });
    describe('isAuthenticated is false', () => {
      beforeEach(() => {
        mockAuthService.isAuthenticated.and.returnValue(false);
        TestBed.overrideProvider(mockAuthService, { useValue: mockAuthService });
        // TestBed.compileComponents();
        TestBed.get(AuthGuard);
      });

      it('should redirect to login page if isAuthenticated==false', () => {
        // arrange

        const next = {
          parent: {
            routeConfig: { path: 'login' }
          }
        } as ActivatedRouteSnapshot;

        spyOn(sessionStorage.__proto__, 'clear');
        spyOn(router, 'navigate');

        // act

        spyOn(sessionStorage.__proto__, 'setItem').and.returnValue('testroute');
        const isAuthenticated = mockAuthService.isAuthenticated();
        guard.canActivate(next, {} as RouterStateSnapshot);

        // assert
        if (isAuthenticated) {
          expect(router.navigate).toHaveBeenCalledWith(['login']);
        }
      });

      it('should clear the sessionStorage if isAuthenticated==false', () => {
        // arrange
        const next = {
          parent: {
            routeConfig: { path: '' }
          }
        } as ActivatedRouteSnapshot;
        spyOn(router, 'navigate');
        spyOn(sessionStorage.__proto__, 'clear');

        // act

        spyOn(sessionStorage.__proto__, 'setItem').and.returnValue('testroute');
        const isAuthenticated = mockAuthService.isAuthenticated();
        guard.canActivate(next, {} as RouterStateSnapshot);

        // assert
        if (isAuthenticated) {
          expect(sessionStorage.__proto__.clear).toHaveBeenCalled();
        }
      });
      afterAll(() => {
        mockAuthService.isAuthenticated.and.returnValue(false);
        TestBed.overrideProvider(mockAuthService, { useValue: mockAuthService });
        TestBed.get(AuthGuard);
      });
    });
  });
});
