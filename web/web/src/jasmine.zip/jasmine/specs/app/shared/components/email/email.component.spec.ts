import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { EmailComponent } from '../../../../../../app/shared/components/email/email.component';
xdescribe('EmailComponent', () => {
  let component: EmailComponent;
  let fixture: ComponentFixture<EmailComponent>;
  beforeEach(() => {
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA]
    });
    fixture = TestBed.createComponent(EmailComponent);
    component = fixture.componentInstance;
    component.parentForm =  this.fb.group({
      email : '',
      additionalemail : ''
    });
    component.emailAddress = {emailAddress : 'a@a.com', title : '', editable: true, formName : '', hide: false};
    component.emailAddresses = [component.emailAddress];
    component.isMedicare = false;
    fixture.detectChanges();
  });
  it('can load instance', () => {
    expect(component).toBeTruthy();
  });
  it('emailAddresses defaults to: []', () => {
    expect(component.emailAddresses).toEqual([]);
  });
  describe('ngOnInit', () => {
    it('makes expected calls', () => {
      spyOn(component, 'transformEmail').and.callThrough();
      component.ngOnInit();
      expect(component.transformEmail).toHaveBeenCalled();
    });
  });
  describe('ToggleEdit', () => {
    it('makes expected calls', () => {
      spyOn(component, 'addEmail').and.callThrough();
      component.toggleEdit();
      expect(component.addEmail).toHaveBeenCalled();
    });
  });
});
