import { inject, TestBed } from '@angular/core/testing';
import { ConstantsService } from '../../../../../app/shared/shared.module';
import { environment } from '../../../../../environments/environment';

describe('ConstantsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ConstantsService]
    });
  });

  it('should have defined this.serviceUrl to environment.serviceUrl', inject([ConstantsService], (service: ConstantsService) => {
    expect(service.serviceUrl).toBe(environment.serviceUrl);
  }));

  it('should have defined this.serimpersonationUserUrlviceUrl to ${this.serviceUrl}access/impermemberlogin', inject(
    [ConstantsService],
    (service: ConstantsService) => {
      expect(service.impersonationUserUrl).toBe(`${service.serviceUrl}access/impermemberlogin`);
    }
  ));
});
