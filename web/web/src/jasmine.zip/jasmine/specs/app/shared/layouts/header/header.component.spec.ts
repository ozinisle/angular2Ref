import { DatePipe, TitleCasePipe } from '@angular/common';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { StorageServiceModule } from 'angular-webstorage-service';
import { HeaderService } from '../../../../../../app/shared/layouts/header/header.service';
import { CamelcasePipe } from '../../../../../../app/shared/pipes/camelcase/camelcase.pipe';
import { CasingForFilterPipe } from '../../../../../../app/shared/pipes/casingForFilter/casingForFilter.pipe';
import { ClaimidPipe } from '../../../../../../app/shared/pipes/claimid/claimid.pipe';
import { HomedatePipe } from '../../../../../../app/shared/pipes/date/date.pipe';
import { YyyymmddTommddyyyyPipe } from '../../../../../../app/shared/pipes/date/yyyymmdd-to-mmddyyyy.pipe';
import { PhonePipe } from '../../../../../../app/shared/pipes/phone/phone.pipe';
import { GlobalService } from '../../../../../../app/shared/services/global.service';
import { AlertService, AuthService, ConstantsService } from '../../../../../../app/shared/shared.module';
import { mocks } from '../../../../../constants/mocks.service';
import { gethomepageinfo_response } from '../../../../../data/landing/home-page-info.data';
import {
  FakeFinancialChartComponent,
  FakeInactiveHomePageFpoLayoutComponent,
  FakeLineChartComponent,
  FakePromoBlocksComponent,
  FakePromoCarouselComponent,
  FakePromoImagesComponent,
  FakeSpinnerComponent,
  FakeSpinnertimeoutComponent
} from '../../../../../fake-components';
import { FakeMaterializeParamsDirectiveStub, FakeRouterLinkDirectiveStub } from '../../../../../fake-directives';

import { LandingService } from '../../../../../../app/pages/landing/landing.service';
import { MyMedicationDetailsService } from '../../../../../../app/pages/medications/myMedicationDetails/my-medication-details.service';
import { MyDedCoService } from '../../../../../../app/pages/myded-co/myded-co.service';
import { HeaderComponent } from '../../../../../../app/shared/layouts/header/header.component';
import { AuthHttp } from '../../../../../../app/shared/services/auth-http.service';
import { AuthenticatedUserComponentData } from '../../../../../data/landing/authenticated-user.component.data';
import { MockRouter } from '../../../../../mock-classes/mock-router.class';
import { ProfileService } from '../../../../../../app/shared/services/myprofile/profile.service';
import { DependantsService } from '../../../../../../app/shared/services/dependant.service';

// to take care of [routerLink] is not a known attribe of a tag error
xdescribe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;

  const mockAuthService = mocks.service.authService;
  const mockGlobalService = mocks.service.globalService;
  const mockRouter = mocks.service.router;
  const mockAuthHttp = mocks.service.authHttp;
  let mockActivatedRoute;
  const mockLandingService = mocks.service.landingService;
  const mockAlertService = mocks.service.alertService;
  const mockMyDedCoService =  mocks.service.myDedCoService;
  const mockMyMedicationDetailsService = mocks.service.myMedicationDetailsService;
  const mockMyHeaderService = mocks.service.headerService;
  const mockProfileService = mocks.service.profileService;
  const mockDependentService = mocks.service.dependantsService;

  beforeEach(async(() => {
    mockActivatedRoute = {
      snapshot: {
        data: {
          memberInfo: gethomepageinfo_response
        }
      }
    };

    TestBed.configureTestingModule({
      imports: [FormsModule, ReactiveFormsModule, StorageServiceModule], // necessary compiler to identify ngModel
      declarations: [
        YyyymmddTommddyyyyPipe,
        CamelcasePipe,
        PhonePipe,
        HomedatePipe,
        CasingForFilterPipe,
        ClaimidPipe,
        HeaderComponent,
        FakeRouterLinkDirectiveStub,
        FakePromoImagesComponent,
        FakeFinancialChartComponent,
        FakeInactiveHomePageFpoLayoutComponent,
        FakeSpinnertimeoutComponent,
        FakeLineChartComponent,
        FakeSpinnerComponent,
        FakePromoCarouselComponent,
        FakeMaterializeParamsDirectiveStub,
        FakePromoBlocksComponent
      ],

      providers: [
        { provide: AuthService, useValue: mockAuthService },
        { provide: GlobalService, useValue: mockGlobalService },
        { provide: Router, useValue: mockRouter },
        { provide: AuthHttp, useValue: mockAuthHttp },
        TitleCasePipe,
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        ConstantsService,
        { provide: LandingService, useValue: mockLandingService },
        DatePipe,
        { provide: MyDedCoService, useValue: mockMyDedCoService },
        { provide: MyMedicationDetailsService, useValue: mockMyMedicationDetailsService },
        { provide: HeaderService, useValue: mockMyHeaderService },
        { provide: Router, useClass: MockRouter },
        { provide: ProfileService, useValue : mockProfileService}
      ]
    }).compileComponents();
  }));

  describe('constructor', () => {
    // assert constructor contents
    beforeEach(() => {
      fixture = TestBed.createComponent(HeaderComponent);
      component = fixture.componentInstance;
    });
    it('should create', () => {
      expect(component).toBeTruthy();
    });
  });

  describe('getMyPharmacyMenu method check', () => {
    beforeEach(() => {
      fixture = TestBed.createComponent(HeaderComponent);
      component = fixture.componentInstance;
      spyOn(sessionStorage.__proto__, 'getItem').and.returnValue(
        JSON.stringify(AuthenticatedUserComponentData.globalService.getPostLoginSessionObject)
      );
      spyOn(sessionStorage.__proto__, 'removeItem').and.returnValue(null);

      fixture.detectChanges();
    });

    it('Check Medication Lookup Tool link', () => {
      expect(component.getMyPharmacyMenu()[1].text).toEqual('Medication Lookup Tool');
      expect(component.getMyPharmacyMenu()[1].url).toEqual('https://home.bluecrossma.com/medication/?icid=myblueglobalnav');
    });

    it('Check PillPack link', () => {
      expect(component.getMyPharmacyMenu()[2].text).toEqual('PillPack');
      expect(component.getMyPharmacyMenu()[2].url).toEqual('/my-pillpack/landing');
    });
  });
  describe('Express Script link check', () => {
    beforeEach(() => {
      fixture = TestBed.createComponent(HeaderComponent);
      component = fixture.componentInstance;
      const getPostLoginSessionObject = {
        hasSS: false,
        hasSSO: false,
        hasCI: false,
        phoneNumbers: [
          {
            text: 'Call Member Service: ',
            number: '800-262-2583'
          },
          {
            text: 'TTY: ',
            number: '711'
          },
          {
            text: 'Talk to a Nurse:',
            number: '888-247-2583'
          },
          {
            text: 'Talk to a Doctor',
            number: ''
          },
          {
            text: 'Send a Message',
            number: ''
          }
        ],
        isCPDPEnrolled: false,
        isCPDPHandedoff: false,
        isCPDPPromotion: true,
        isKYMember: false,
        pharmacyLinks: [
          {
            text: 'My Medications',
            url: '/mymedications'
          },
          {
            text: 'Medication Lookup Tool',
            url: 'https://home.bluecrossma.com/medication/?icid=myblueglobalnav'
          },
          {
            text: 'Express Script',
            url: '/sso/expressscript'
          }
        ]
      };

      spyOn(sessionStorage.__proto__, 'getItem').and.returnValue(JSON.stringify(getPostLoginSessionObject));
      spyOn(sessionStorage.__proto__, 'removeItem').and.returnValue(null);

      fixture.detectChanges();
    });
    it('Check Express Script link', () => {
      expect(component.getMyPharmacyMenu()[2].text).toEqual('Express Script');
      expect(component.getMyPharmacyMenu()[2].url).toEqual('/sso/expressscript');
    });
  });

  describe('navigate Pharmacy Link method check', () => {
    it('should opened navigate Pharmacy Link with sso/link', () => {
      // arrange
      const spyWindowOpen = spyOn(window, 'open');
      fixture = TestBed.createComponent(HeaderComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      component.navigatePharmacyUrl('sso/link');
      // assert
      expect(spyWindowOpen).toHaveBeenCalledWith('sso/link');
    });

    it('should opened navigate Pharmacy Link with MyPillPack  ', () => {
      // arrange
      fixture = TestBed.createComponent(HeaderComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      component.navigatePharmacyUrl('/my-pillpack/landing');
      // assert
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/my-pillpack/landing'], { queryParams: { icid: 'PillPack Global' } });
    });

    it('should opened navigate Pharmacy Link as staring with / ', () => {
      // arrange
      fixture = TestBed.createComponent(HeaderComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      component.navigatePharmacyUrl('/');
      // assert
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/']);
    });
  });
});
