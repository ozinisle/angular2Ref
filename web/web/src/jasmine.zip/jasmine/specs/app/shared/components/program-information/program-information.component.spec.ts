import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ProgramInformationComponent } from '../../../../../../app/shared/components/program-information/program-information.component';


xdescribe('ProgramInformationComponent', () => {
  let component: ProgramInformationComponent;
  let fixture: ComponentFixture<ProgramInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ProgramInformationComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProgramInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
