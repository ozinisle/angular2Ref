import { inject, TestBed } from '@angular/core/testing';
import { MyPillpackService } from '../../../../../../app/shared/services/mypillpack';

describe('MyPillpackService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MyPillpackService]
    });
  });

  xit('should be created', inject([MyPillpackService], (service: MyPillpackService) => {
    expect(service).toBeTruthy();
  }));
});
