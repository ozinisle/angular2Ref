import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { inject, TestBed } from '@angular/core/testing';
import { CostShareService } from '../../../../../../app/pages/cost-share/cost-share.service';
import { MyplansService } from '../../../../../../app/pages/myplans/myplans.service';
import { AuthService } from '../../../../../../app/shared/services/auth.service';
import { ConstantsService } from '../../../../../../app/shared/services/constants.service';
import { environment } from '../../../../../../environments/environment';
import { COST_SHARE, GETPLANS_POSITIVE_DATA } from '../../../../../data/cost-share/cost-share.data';
import moment = require('moment');

describe('CostShareService', () => {
  let mockConstantsService;
  let mockCostShareService;
  let mockPlanDataService;
  let mockAuthService;
  beforeEach(() => {
    TestBed.configureTestingModule({
        imports: [HttpClientTestingModule],
      providers: [
        HttpTestingController,
          { provide: ConstantsService, useValue: mockConstantsService},
          { provide: CostShareService, useValue: mockCostShareService},
          { provide: MyplansService, useValue: mockPlanDataService},
          { provide: AuthService, useValue: mockAuthService}
          
      ]
    });
  });
  it('should be created', inject([CostShareService], (service: CostShareService) => {
    expect(service).toBeTruthy();
  }));
  it('drupalContentApi', inject([ConstantsService], (service: ConstantsService) => {
    expect(service.drupalCostShareAssistanceUrl).toBe(`${environment.drupalTestUrl}/page/landing/costshare`);
  }));
  
  it('getCostShareDrupalContent should return data',() =>{
     mockCostShareService.getCostShareDrupalContent().subscribe((res) =>{
        expect(res).toEqual(COST_SHARE[0]);
     })
  });

  it('verify group number are available in drupal response' ,() => {
    mockCostShareService.getCostShareDrupalContent().subscribe((response) => {
      response[0].Links.map((linkValues) =>{
        !expect(linkValues.group).toBeNull();
      })
    })
  });
  it('planDataServiceApi', inject([MyplansService], (service: MyplansService) =>{
    expect(service.getPlansData(moment().format('YYYY-MM-DD'))).toBeTruthy();
  }));
  it('getPlansData should return data',() =>{
    mockPlanDataService.getPlansData(moment().format('YYYY-MM-DD')).subscribe((res) =>{
      expect(res).toBe(GETPLANS_POSITIVE_DATA);
    })
  });
  it('getGroupNumbers should return data', () =>{
    const userGroupNumbers : string[] = mockCostShareService.getGroupNumbers(GETPLANS_POSITIVE_DATA);
    userGroupNumbers.map((groupNumber) =>{
      expect(groupNumber).toEqual('107313021');
    });
  });
  
  
    
  

});
