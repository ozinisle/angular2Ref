import { async, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { PillGuard } from '../../../../../app/shared/utils/pill.guard';
import { mocks } from '../../../../constants/mocks.service';
import { MockRouter } from '../../../../mock-classes/mock-router.class';

describe('PillGuard', () => {
  describe('canActivate', () => {
    let guard: PillGuard;
    let router;
    let mockRouter;

    beforeEach(async(() => {
      mockRouter = mocks.service.router;
      router = new MockRouter();
      guard = new PillGuard(router);

      TestBed.configureTestingModule({
        providers: [PillGuard, { provide: Router, useValue: mockRouter }]
      });
      guard = TestBed.get(PillGuard);
    }));

    it('should allowed canActivate if return true', () => {
      // act

      const canActivateGuard = guard.canActivate();

      // assert

      expect(canActivateGuard).toBeTruthy();
    });

    it('should call the sessionStorage.getItem', () => {
      // act
      const sessionResult = spyOn(sessionStorage.__proto__, 'getItem');
      const result = guard.canActivate();

      // assert
      expect(sessionResult).toHaveBeenCalledTimes(1);
    });

    xit('should redirect to home page if !sessionStorage.getItem("userState")', () => {
      spyOn(router, 'navigate');

      // act

      const userState = spyOn(sessionStorage.__proto__, 'getItem');
      debugger;
      guard.canActivate();

      // assert
      if (userState) {
        expect(router.navigate).toHaveBeenCalledWith(['home']);
      }
    });
  });
});
