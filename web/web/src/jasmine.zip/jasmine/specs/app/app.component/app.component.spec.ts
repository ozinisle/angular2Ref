import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NavigationEnd, NavigationStart, Router, RouterEvent } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { ReplaySubject } from 'rxjs';
import { AppComponent } from '../../../../app/app.component';
import { LoadingSpinnerModule, LoadingSpinnerService } from '../../../../app/core/components/loading-spinner';
import { PreferenceModalService } from '../../../../app/pages/preference-modal/preference-modal.service';
import { AuthHttp } from '../../../../app/shared/services/auth-http.service';
import { LayoutService } from '../../../../app/shared/services/layout.service';
import { StorageService } from '../../../../app/shared/services/storage.service';
import { AuthService } from '../../../../app/shared/shared.module';
import { mocks } from '../../../constants/mocks.service';
import { FakeAppmodalsComponent } from '../../../fake-components';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;

  let mockRouter;
  let mockLayoutService;
  let mockAuthHttpService;
  let mockSpinnerService;
  let mockStorageService;
  let mockAuthService;
  let mockPreferenceModalService;
  const eventSubject = new ReplaySubject<RouterEvent>(1);

  mockPreferenceModalService = mocks.service.preferenceModalService;
  mockLayoutService = mocks.service.layoutService;
  mockAuthHttpService = mocks.service.authHttp;
  mockAuthService = mocks.service.authService;
  mockSpinnerService = mocks.service.spinnerservice;
  mockStorageService = mocks.service.storageservice;
  mockRouter = {
    naivgate: jasmine.createSpy('navigate'),
    events: eventSubject.asObservable(),
    url: '/app',
    routeReuseStrategy: {
      shouldReuseRoute: false
    },
    routerState: {
      snapshot: {
        root: null
      }
    }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, LoadingSpinnerModule, RouterTestingModule],
      providers: [
        { provide: Router, useValue: mockRouter },
        { provide: LayoutService, useValue: mockLayoutService },
        { provide: AuthHttp, useValue: mockAuthHttpService },
        { provide: AuthService, useValue: mockAuthService },
        { provide: PreferenceModalService, useValue: mockPreferenceModalService },
        { provide: LoadingSpinnerService, useValue: mockSpinnerService },
        { provide: StorageService, useValue: mockStorageService }
      ],
      declarations: [FakeAppmodalsComponent, AppComponent],
      schemas: [NO_ERRORS_SCHEMA]
    });

    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
  });

  describe('constructor', () => {
    it('should exist', () => {
      expect(component).toBeDefined();
    });
    it('should create component', () => {
      expect(component).toBeTruthy();
    });
  });

  describe('ngOnInit', () => {
    beforeEach(() => {
      mockAuthService.getScopeName.and.callFake(() => {
        return 'REGISTERED-NOT-VERIFIED';
      });
    });
    it('should call ngOnInit', () => {
      spyOn(component, 'ngOnInit');
      fixture.detectChanges();
      expect(component.ngOnInit).toHaveBeenCalled();
    });
  });

  describe('ngAfterViewInit', () => {
    it('should call ngAfterViewInit', () => {
      spyOn(component, 'ngAfterViewInit');
      component.ngAfterViewInit();
      fixture.detectChanges();
      expect(component.ngAfterViewInit).toHaveBeenCalled();
    });
    it('should call showSpinnerLoading method at NavigationStart', () => {
      eventSubject.next(new NavigationStart(1, '/app'));
      fixture.detectChanges();
      expect(mockAuthHttpService.showSpinnerLoading).toHaveBeenCalled();
    });
    it('should call hideSpinnerLoading method at NavigationEnd', () => {
      eventSubject.next(new NavigationEnd(1, '/app', '/app'));
      fixture.detectChanges();
      expect(mockAuthHttpService.hideSpinnerLoading).toHaveBeenCalled();
    });
    it('url should not be login at NavigationEnd', () => {
      eventSubject.next(new NavigationEnd(1, '/app', '/app'));
      fixture.detectChanges();
      expect(mockRouter.url).not.toBe('/login');
    });
    it('should call initiatePreference method at NavigationEnd', () => {
      eventSubject.next(new NavigationEnd(1, '/app', '/app'));
      mockAuthService.authToken.scopeName = 'AUTHENTICATED-AND-VERIFIED';
      fixture.detectChanges();
      component.ngAfterViewInit();
      expect(mockRouter.url).not.toBe('/login');
      expect(mockRouter.url).not.toBe('/myprofile/communication-preferences');
      expect(mockRouter.url).not.toBe('/myprofile/verify');
      expect(mockAuthService.authToken.scopeName).toBe('AUTHENTICATED-AND-VERIFIED');
      expect(mockPreferenceModalService.initiatePreference).toHaveBeenCalled();
    });
  });
});
