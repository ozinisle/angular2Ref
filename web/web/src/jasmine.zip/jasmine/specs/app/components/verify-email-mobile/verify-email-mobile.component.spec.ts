import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonModule, TitleCasePipe } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormBuilder, FormsModule, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import {
  MatCardModule,
  MatDialogModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { StorageServiceModule } from 'angular-webstorage-service';
import { TextMaskModule } from 'angular2-text-mask';
import { of } from 'rxjs/observable/of';
import { MaterialModule } from '../../../../../app/material.module';
import { GlobalService } from '../../../../../app/shared/services/global.service';
import { ProfileService } from '../../../../../app/shared/services/myprofile/profile.service';
import { AlertService, AuthService, ConstantsService, ValidationService } from '../../../../../app/shared/shared.module';
import { mocks } from '../../../../constants/mocks.service';
import { jasAVUserData } from '../../../../data/my-profile/avUser.data';
import {
  FakeAlegeusLineChartComponent,
  FakeBreadcrumbsComponent,
  FakeControlMessagesComponent,
  FakeCostBreakdownFilterComponent,
  FakeFadBreadCrumbsComponent,
  FakeFpoLayoutComponent,
  FakePasswordControlMessages
} from '../../../../fake-components';
import { FakeParentFormFieldDirectiveStub, FakeRouterLinkDirectiveStub } from '../../../../fake-directives';
import { VerifyEmailMobileComponent } from '../../../../../app/components/verify-email-mobile/verify-email-mobile.component';
import { AuthHttp } from '../../../../../app/shared/services/auth-http.service';
import { VerifyEmailMobileService } from '../../../../../app/components/verify-email-mobile/verify-email-mobile.service';
import { PreferencesService } from '../../../../../app/shared/services/myprofile/preferences.service';

describe('VerifyEmailMobileComponent', () => {
  let component: VerifyEmailMobileComponent;
  let fixture: ComponentFixture<VerifyEmailMobileComponent>;

  let mockRouter;
  let mockAlertService;
  let mockProfileService;
  let mockValidationService;
  let mockAuthService;
  let mockConstants;
  let mockGlobalService;
  let mockAuthHttp;
  let mockVerifyEmailMobileService;
  let mockPreferenceService;

  // create new instance of FormBuilder
  const formBuilder: FormBuilder = new FormBuilder();

  beforeEach(async(() => {
    mockAuthService = mocks.service.authService;

    mockConstants = mocks.service.constantsService;

    mockGlobalService = mocks.service.globalService;

    mockRouter = mocks.service.router;
    mockRouter.url = '/myprofile/verify';

    mockAlertService = mocks.service.alertService;

    mockProfileService = mocks.service.profileService;

    mockValidationService = mocks.service.validationService;

    mockRouter = mocks.service.router;

    mockAuthHttp = mocks.service.authHttp;
    mockVerifyEmailMobileService = mocks.service.verifyEmailMobileService;
    mockPreferenceService = mocks.service.preferenceService;

    TestBed.configureTestingModule({
      imports: [
        BrowserModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        StorageServiceModule,
        HttpClientTestingModule,
        TextMaskModule,
        MatFormFieldModule,
        MatRadioModule,

        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatDialogModule,
        MaterialModule
      ],
      declarations: [
        FakeRouterLinkDirectiveStub,
        FakeParentFormFieldDirectiveStub,
        FakeControlMessagesComponent,
        FakeFadBreadCrumbsComponent,
        FakeCostBreakdownFilterComponent,
        FakeAlegeusLineChartComponent,
        FakeBreadcrumbsComponent,
        FakeFpoLayoutComponent,
        FakePasswordControlMessages,

        VerifyEmailMobileComponent
      ],
      providers: [
        { provide: Router, useValue: mockRouter },
        { provide: AlertService, useValue: mockAlertService },
        { provide: ProfileService, useValue: mockProfileService },
        { provide: ValidationService, useValue: mockValidationService },
        { provide: AuthService, useValue: mockAuthService },
        { provide: FormBuilder, useValue: formBuilder },
        { provide: ConstantsService, useValue: mockConstants },
        { provide: GlobalService, useValue: mockGlobalService },
        { provide: AuthHttp, useValue: mockAuthHttp },
        { provide: VerifyEmailMobileService, useValue: mockVerifyEmailMobileService},
        { provide: PreferencesService, useValue : mockPreferenceService},
        TitleCasePipe
      ]
    }).compileComponents();

    VerifyEmailMobileComponent.prototype.verifyaccesscodeForm = formBuilder.group(
      {
        accesscode1: ['', [Validators.required]],
        accesscode2: ['', [Validators.required]],
        accesscode3: ['', [Validators.required]],
        accesscode4: ['', [Validators.required]],
        accesscode5: ['', [Validators.required]],
        accesscode6: ['', [Validators.required]]
      },
      {
        validator: mockValidationService.accessCodeValidator()
      }
    );
    spyOn(VerifyEmailMobileComponent.prototype.verifyaccesscodeForm, 'valueChanges').and.returnValue(of('123456'));
  }));

  describe('Constructor', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(VerifyEmailMobileComponent);

      // act
      component = fixture.componentInstance;
    });

    it('should create', () => {
      // assert
      expect(component).toBeTruthy();
    });
    describe('While Component Creation', () => {
      describe('should have initialized', () => {
        it('should have initialized this.location to "myprofile"', () => {
          expect(component.location).toBe('myprofile');
        });

        it(' should have created this.verifyaccesscodeForm', () => {
          expect(component.verifyaccesscodeForm).toBeTruthy();
        });

        it(' should have initialized this.accesscodeMask to this.validationService.accesscodeMask', () => {
          // assert
          const assertion: boolean =
            mockValidationService.accesscodeMask.length === component.accesscodeMask.length &&
            (() => {
              for (let maskItr = 0; maskItr < component.accesscodeMask.length; maskItr++) {
                if (String(mockValidationService.accesscodeMask[maskItr]) === String(component.accesscodeMask[maskItr])) {
                  continue;
                } else {
                  return false;
                }
              }
              return true;
            })();
          expect(assertion).toBeTruthy();
        });
      });

      describe('should have called', () => {
        it('should have called  this.alertService.clearError()', () => {
          expect(mockAlertService.clearError).toHaveBeenCalled();
        });

        xit('should have called  this.verifyaccesscodeForm.valueChanges', () => {
          // this is not a method but an event emitter
          // need to find a way to test this
          expect(component.verifyaccesscodeForm.valueChanges).toHaveBeenCalled();
        });
      });
    });
  });

  describe('ngOnInit', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(VerifyEmailMobileComponent);
      component = fixture.componentInstance;
    });

    describe('should have initialized', () => {
      describe('should have set the value of this.maskedVerifiable to masked userid ', () => {
        it('should mask when userid is email', () => {
          // arrange
          const useridin = 'sampleMailId@sampledomain.com';
          spyOn(sessionStorage.__proto__, 'getItem').and.returnValue(useridin);
          const maskedUserId = useridin;
          maskedUserId.replace(/^(.{3})(.*)(@.*)$/, (_, firstCharacter, charToMasked, domain) => {
            return `${firstCharacter}${charToMasked.replace(/./g, '*')}${domain}`;
          });

          // act
          fixture.detectChanges();

          // assert
          expect(component.maskedVerifiable).toBe(maskedUserId);
        });
        it('should mask when userid is mobile number', () => {
          // arrange
          const useridin = '1234567890';
          spyOn(sessionStorage.__proto__, 'getItem').and.returnValue(useridin);
          const maskedUserId = useridin;
          maskedUserId.replace(/^(.*)(.{4})$/, (_, digitsToMasked, lastFourDigits) => {
            return `${digitsToMasked.replace(/./g, '*')}${lastFourDigits}`;
          });

          // act
          fixture.detectChanges();

          // assert
          expect(component.maskedVerifiable).toBe(maskedUserId);
        });
      });
    });

    describe('should have called', () => {
      xit('should have called sessionStorage.getItem twice', () => {
        // arrange
        const sessGet = spyOn(sessionStorage.__proto__, 'getItem');

        // act
        fixture.detectChanges();

        // assert
        expect(sessGet).toHaveBeenCalledTimes(2);
      });

      xit('should have called profileService.getProfile', () => {
        // act
        fixture.detectChanges();

        // assert
        expect(mockProfileService.getProfile).toHaveBeenCalled();
      });

      xdescribe('when profileService.getProfile() returns valid value', () => {
        it('should not call profile.fetchProfileInfo()', () => {
          // act
          mockProfileService.getProfile.and.returnValue(jasAVUserData.getMemProfile_After_NgOnint);
          fixture.detectChanges();

          // assert
          expect(mockProfileService.fetchProfileInfo).not.toHaveBeenCalled();
        });
        it('should not call profile.fetchProfileInfo()', () => {
          // act
          mockProfileService.getProfile.and.returnValue(jasAVUserData.getMemProfile_After_NgOnint);
          fixture.detectChanges();

          // assert
          expect(mockProfileService.setProfile).not.toHaveBeenCalled();
        });
      });
    });
  });

  describe('methods', () => {
    describe('maskEmailId', () => {
      it('should return masked value of sentMailId["commChannel"] from sessionStorage if present', () => {
        // arrange
        spyOn(sessionStorage.__proto__, 'getItem').and.returnValue('{"commChannel":"abcdefgh@ijklmnop.com"}');
        fixture = TestBed.createComponent(VerifyEmailMobileComponent);
        component = fixture.componentInstance;

        // act
        const result = component.maskEmailId('');

        // assert
        expect(result).toBe('abc*****@ijklmnop.com');
      });
      it('should return masked value of passed in parameter if sentMailId["commChannel"] is absent in sessionStorage', () => {
        // arrange
        spyOn(sessionStorage.__proto__, 'getItem').and.returnValue('{}');
        fixture = TestBed.createComponent(VerifyEmailMobileComponent);
        component = fixture.componentInstance;

        // act
        const result = component.maskEmailId('abcdefgh@ijklmnop.com');

        // assert
        expect(result).toBe('abc*****@ijklmnop.com');
      });

      it('should return masked value of passed in parameter if sentMailId["commChannel"] is absent in sessionStorage', () => {
        // arrange
        const sessStorageSpy = spyOn(sessionStorage.__proto__, 'getItem').and.returnValue('{}');
        fixture = TestBed.createComponent(VerifyEmailMobileComponent);
        component = fixture.componentInstance;

        // act
        const result = component.maskEmailId('abcdefgh@ijklmnop.com');

        // assert
        expect(sessStorageSpy).toHaveBeenCalledTimes(1);
       });
    });

    describe('ngOnDestroy', () => {
      it('should have called alertService.clearError', () => {
        // arrange
        spyOn(sessionStorage.__proto__, 'getItem').and.returnValue('{commChannel:abcdefgh@ijklmnop.com}');
        fixture = TestBed.createComponent(VerifyEmailMobileComponent);
        component = fixture.componentInstance;

        // act
        component.ngOnDestroy();

        // assert
        expect(mockAlertService.clearError).toHaveBeenCalled();
      });
    });

    describe('onSubmit', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('sendAccessCode', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('sendaccesscode', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('sendcommchlaccesscode', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('onKeyDown', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('onKeyUp', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('isValidKeyPressed', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('sendNotification', () => {
      it('should do something', () => {
        pending();
      });
    });
  });
});
