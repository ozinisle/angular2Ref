import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material';
import { ProfileEmailComponent } from '../../../../../app/components/profile-email/profile-email.component';
import { AuthService } from '../../../../../app/shared/services/auth.service';
import { GlobalService } from '../../../../../app/shared/services/global.service';
import { ValidationService } from '../../../../../app/shared/services/validation.service';
import { mocks } from '../../../../constants/mocks.service';
import { jasAVUserData } from '../../../../data/my-profile/avUser.data';
import { FakeControlMessagesComponent } from '../../../../fake-components';

describe('ProfileEmailComponent', () => {
  let component: ProfileEmailComponent;
  let fixture: ComponentFixture<ProfileEmailComponent>;


    let mockGlobalService;
    let mockAuthService;
    let mockValidationService;

    beforeEach(() => {

        mockAuthService = mocks.service.authService;
        mockValidationService = mocks.service.validationService;
        mockGlobalService = mocks.service.globalService;

        TestBed.configureTestingModule({
            imports: [
                ReactiveFormsModule,
                MatFormFieldModule,
            ],
            providers: [
                { provide: GlobalService, useValue: mockGlobalService },
                { provide: AuthService, useValue: mockAuthService },
                { provide: ValidationService, useValue: mockValidationService }
            ],
            declarations: [
                ProfileEmailComponent,
                FakeControlMessagesComponent
            ],
        });

        fixture = TestBed.createComponent(ProfileEmailComponent);
        component = fixture.componentInstance;
        component.ngOnInit();
        component.initializeEmailForm();
    });


    describe('ngOnInit', () => {
        it('should call the method ngOnInit', () => {
            spyOn(component, 'ngOnInit');
            fixture.detectChanges();
            expect(component.ngOnInit).toHaveBeenCalled();
        });
    });

    describe('ngOnChanges', () => {
        it('should call the method ngOnChanges', () => {
            const changes = null;
            spyOn(component, 'ngOnChanges');
            fixture.detectChanges();
            component.ngOnChanges(changes);
            expect(component.ngOnChanges).toHaveBeenCalled();
        });
    });

    describe('impersonation', () => {
        it('should call the method impersonation', () => {
            spyOn(component, 'impersonation');
            fixture.detectChanges();
            component.impersonation();
            expect(component.impersonation).toHaveBeenCalled();
        });
        // it('should return impersonate', () => {
        //     spyOn(component, 'impersonation');
        //     const impersonate = mockAuthService.impersonation;
        //     fixture.detectChanges();
        //     component.impersonation();
        //     expect(component.impersonation).toBe(impersonate);
        // });
    });

    describe('onEmailSubmit', () => {
        it('should call the method onEmailSubmit', () => {
            spyOn(component, 'onEmailSubmit');
            fixture.detectChanges();
            component.onEmailSubmit();
            expect(component.onEmailSubmit).toHaveBeenCalled();
        });
        it('should call the setItem method', () => {
            spyOn(sessionStorage.__proto__, 'setItem');
            fixture.detectChanges();
            component.onEmailSubmit();
            expect(sessionStorage.__proto__.setItem).toHaveBeenCalled();
        });
        // it('should set the item updateProfile in the session storage as true', () => {
        //     spyOn(sessionStorage.__proto__, 'setItem');
        //     fixture.detectChanges();
        //     component.onEmailSubmit();
        //     expect(sessionStorage.updateProfile).toBeFalsy();
        // });
        it('should get the value of memProfile', () => {
            spyOn(sessionStorage.__proto__, 'getItem').and.returnValue(JSON.stringify(jasAVUserData.getMemProfile_After_NgOnint));
            fixture.detectChanges();
            component.onEmailSubmit();
            expect(window.sessionStorage.__proto__.getItem).toHaveBeenCalled();
        });

        it('should assign the value of memProfile to profile', () => {
            fixture.detectChanges();
            const profile = JSON.stringify(jasAVUserData.getMemProfile_After_NgOnint);
            expect(profile).toEqual(JSON.stringify(jasAVUserData.getMemProfile_After_NgOnint));
        });
    });

    describe('cancelEmail', () => {
        it('should call the method cancelEmail', () => {
            spyOn(component, 'cancelEmail');
            fixture.detectChanges();
            component.cancelEmail();
            expect(component.cancelEmail).toHaveBeenCalled();
        });
    });
});

