import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {
  ProfileSelectPreferenceComponent
} from '../../../../../app/components/profile-select-preference/profile-select-preference.component';
import { FpoLayoutModule } from '../../../../../app/shared/layouts/FpoLayoutComponent/fpo-layout.module';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ConstantsService, SharedModule } from '../../../../../app/shared/shared.module';
import { SafePipe } from '../../../../../app/shared/pipes/safe.pipe';
import { FakeAlertsComponent } from '../../../../fake-components';

describe('ProfileSelectPreferenceComponent', () => {
  let component: ProfileSelectPreferenceComponent;
  let fixture: ComponentFixture<ProfileSelectPreferenceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FpoLayoutModule, SharedModule ],
      declarations: [ ProfileSelectPreferenceComponent],
      providers: [ConstantsService],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfileSelectPreferenceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
