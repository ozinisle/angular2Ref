import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsentModalComponent } from '../../../../../app/components/consent-modal/consent-modal.component';
import { StorageServiceModule } from 'angular-webstorage-service';
import { CommonModule } from '@angular/common';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AuthService } from '../../../../../app/shared/shared.module';
import { mocks } from '../../../../constants/mocks.service';
import { AuthHttp } from '../../../../../app/shared/services/auth-http.service';
import { GlobalService } from '../../../../../app/shared/services/global.service';
import { PreferencesService } from '../../../../../app/shared/services/myprofile/preferences.service';

describe('ConsentModalComponent', () => {
  let component: ConsentModalComponent;
  let fixture: ComponentFixture<ConsentModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [CommonModule, MatDialogModule, StorageServiceModule],
      declarations: [ConsentModalComponent],
      providers : [
       {
          provide : AuthService,
          useValue : mocks.service.authService
        },  {
          provide : AuthHttp,
          useValue : mocks.service.authHttp
        }, {
          provide : GlobalService,
          useValue : mocks.service.globalService
        }, {
          provide : PreferencesService,
          useValue : mocks.service.preferencesService
        }, {
          provide: MatDialogRef,
          useValue: {}
        }, {
          provide: MAT_DIALOG_DATA,
          useValue: {preferences: {Preferences: [{CID: ''}]}}
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsentModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
