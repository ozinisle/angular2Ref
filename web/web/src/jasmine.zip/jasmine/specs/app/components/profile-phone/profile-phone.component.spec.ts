import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material';
import { TextMaskModule } from 'angular2-text-mask';
import { ProfilePhoneComponent } from '../../../../../app/components/profile-phone/profile-phone.component';
import { AuthService } from '../../../../../app/shared/services/auth.service';
import { GlobalService } from '../../../../../app/shared/services/global.service';
import { ValidationService } from '../../../../../app/shared/services/validation.service';
import { mocks } from '../../../../constants/mocks.service';
import { jasAVUserData } from '../../../../data/my-profile/avUser.data';
import { FakeControlMessagesComponent } from '../../../../fake-components';

describe('ProfilePhoneComponent', () => {
  let component: ProfilePhoneComponent;
  let fixture: ComponentFixture<ProfilePhoneComponent>;

    let mockGlobalService;
    let mockAuthService;
    let mockValidationService;

    beforeEach(() => {

        mockGlobalService = mocks.service.globalService;
        mockAuthService = mocks.service.authService;
        mockValidationService = mocks.service.validationService;

        TestBed.configureTestingModule({
            imports: [
                ReactiveFormsModule,
                FormsModule,
                TextMaskModule,
                MatFormFieldModule
            ],
            providers: [
                { provide: GlobalService, useValue: mockGlobalService },
                { provide: AuthService, useValue: mockAuthService },
                { provide: ValidationService, useValue: mockValidationService}
            ],
            declarations: [
                ProfilePhoneComponent,
                FakeControlMessagesComponent
            ],
        });

        fixture = TestBed.createComponent(ProfilePhoneComponent);
        component = fixture.componentInstance;
        component.ngOnInit();
        component.initializeForm();
    });
    describe('constructor', () => {
        it('should call the constructor method', () => {
            expect(component).toBeDefined();
        });
    });

    describe('ngOnInit', () => {
        it('should call the ngOnInit method', () => {
            spyOn(component, 'ngOnInit');
            fixture.detectChanges();
            expect(component.ngOnInit).toHaveBeenCalled();
        });
    });

    describe('ngOnChanges', () => {
        it('should call the ngOnChanges method', () => {
            const changes = null;
            spyOn(component, 'ngOnChanges');
            fixture.detectChanges();
            component.ngOnChanges(changes);
            expect(component.ngOnChanges).toHaveBeenCalled();
        });
    });

    describe('impersonation', () => {
        it('should call the impersonation', () => {
            spyOn(component, 'impersonation');
            fixture.detectChanges();
            component.impersonation();
            expect(component.impersonation).toHaveBeenCalled();
        });
    });

    describe('getDefaultOptionForPhoneNumberType', () => {
        it('should call the method getDefaultOptionForPhoneNumberType', () => {
            spyOn(component, 'getDefaultOptionForPhoneNumberType');
            fixture.detectChanges();
            component.initializeForm();
            expect(component.getDefaultOptionForPhoneNumberType).toHaveBeenCalled();
        });
        it('should assign the phone type to Mobile', () => {
            fixture.detectChanges();
            expect(jasAVUserData.getMemProfileApiResponse.phoneType).toEqual('MOBILE');
        });
        it('should return phoneType', () => {
            fixture.detectChanges();
            spyOn(component, 'getDefaultOptionForPhoneNumberType').and.returnValue(jasAVUserData.getMemProfileApiResponse.phoneType);
        });
    });

    describe('onPhoneSubmit', () => {
        it('should call the method onPhoneSubmit', () => {
            spyOn(component, 'onPhoneSubmit');
            fixture.detectChanges();
            component.onPhoneSubmit();
            expect(component.onPhoneSubmit).toHaveBeenCalled();
        });
        it('should get the value of memProfile', () => {
            fixture.detectChanges();
            spyOn(sessionStorage.__proto__, 'getItem').and.returnValue(JSON.stringify(jasAVUserData.getMemProfile_After_NgOnint));
            component.onPhoneSubmit();
            expect(window.sessionStorage.__proto__.getItem).toHaveBeenCalled();
        });
        it('should assign the value of memProfile to profile', () => {
            fixture.detectChanges();
            const profile = JSON.stringify(jasAVUserData.getMemProfile_After_NgOnint);
            expect(profile).toEqual(JSON.stringify(jasAVUserData.getMemProfile_After_NgOnint));
        });

        it('should assign editPhone flag as false', () => {
            fixture.detectChanges();
            expect(component.editPhone).toBeFalsy();
        });
        it('should run the setItem method on sessionStorage item', () => {
            spyOn(sessionStorage.__proto__, 'setItem');
            component.onPhoneSubmit();
            expect(window.sessionStorage.__proto__.setItem).toHaveBeenCalled();
        });
    });

    describe('cancelPhone', () => {
        it('should call the method cancelPhone', () => {
            spyOn(component, 'cancelPhone');
            fixture.detectChanges();
            component.cancelPhone();
            expect(component.cancelPhone).toHaveBeenCalled();
        });
    });
});
