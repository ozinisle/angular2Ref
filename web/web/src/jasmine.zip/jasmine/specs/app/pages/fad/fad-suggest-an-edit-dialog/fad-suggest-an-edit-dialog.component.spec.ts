import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import {
  FadSuggestAnEditDialogComponent 
} from '../../../../../../app/pages/fad/fad-suggest-an-edit-dialog/fad-suggest-an-edit-dialog.component';
import { MaterialModule } from '../../../../../../app/material.module';
import {
  FadSuggestAnEditDialogService
} from '../../../../../../app/pages/fad/fad-suggest-an-edit-dialog/fad-suggest-an-edit-dialog.service';
import { mocks } from '../../../../../constants/mocks.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CommonModule } from '@angular/common';
import { BcbsmaerrorHandlerService } from '../../../../../../app/shared/services/bcbsmaerror-handler.service';
import { ConstantsService } from '../../../../../../app/shared/shared.module';

describe('FadSuggestAnEditDialogComponent', () => {
  let component: FadSuggestAnEditDialogComponent;
  let fixture: ComponentFixture<FadSuggestAnEditDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MaterialModule, CommonModule],
      declarations: [ FadSuggestAnEditDialogComponent ],
      providers: [
        ConstantsService,
        { provide: FadSuggestAnEditDialogService,
          useValue: mocks.service.fadSuggestAnEditDialogService
        },
        {
          provide: BcbsmaerrorHandlerService,
          useValue: mocks.service.bcbsmaerrorHandlerService
        },
        {
          provide: MatDialogRef,
          useValue: {}
        },
        {
          provide: MAT_DIALOG_DATA,
          useValue: {}
        }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FadSuggestAnEditDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
