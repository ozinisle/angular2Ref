import { CommonModule, DatePipe } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatCardModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatListModule,
  MatNativeDateModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { StorageServiceModule } from 'angular-webstorage-service';

import { ChangeDetectorRef } from '@angular/core';
import { of } from 'rxjs/observable/of';
import { MaterialModule } from '../../../../../../app/material.module';
import { ClaimsService } from '../../../../../../app/pages/myclaims/claims.service';
import { ClaimStatusDetailsComponent } from '../../../../../../app/pages/myclaims/myClaimStatusDetails/claimStatusDetails.component';
import { ClaimidPipe } from '../../../../../../app/shared/pipes/claimid/claimid.pipe';
import { DependantsService } from '../../../../../../app/shared/services/dependant.service';
import { FilterService } from '../../../../../../app/shared/services/filter.service';
import { GlobalService } from '../../../../../../app/shared/services/global.service';
import { AlertService, AuthService, ConstantsService, ValidationService, SharedModule } from '../../../../../../app/shared/shared.module';
import { mocks } from '../../../../../constants/mocks.service';
import { getclaimprocessingstatus_response } from '../../../../../data/myClaims/getclaimprocessingstatus.data';
import { getclaimssummary_response } from '../../../../../data/myClaims/getclaimssummary.data';
import { FakeBreadcrumbsComponent, FakeFpoLayoutComponent, FakeSpinnerComponent } from '../../../../../fake-components';
import {
  FakeCellAspectRatioDirectiveStub,
  FakeFromRootDirectiveStub,
  FakeInfiniteScrollContainerDirectiveStub,
  FakeInfiniteScrollDirectiveStub,
  FakeInfiniteScrollDisabledDirectiveStub,
  FakeInfiniteScrollDistanceDirectiveStub,
  FakeInfiniteScrollThrottleDirectiveStub,
  FakeInfiniteScrollUpDistanceDirectiveStub,
  FakescrolledDirectiveStub,
  FakeScrolledUpDirectiveStub,
  FakeScrollWindowDirectiveStub
} from '../../../../../fake-directives';
import { PromoImagesComponent } from '../../../../../../app/shared/components/promo/promo-images/promo-images.component';

describe('ClaimStatusDetailsComponent', () => {
  let component: ClaimStatusDetailsComponent;
  let fixture: ComponentFixture<ClaimStatusDetailsComponent>;

  let mockRouter;
  let mockActivatedRoute;
  let mockAlertService;
  let mockValidationService;
  let mockConstantsService;
  let mockGlobalService;
  let mockAuthService;
  let mockDependantsService;
  let mockFilterService;
  let mockClaimsService;
  let mockChangeDetectionRef;

  const sessionStorageResponseArray = ['mockClaimId', 'mockClaimId', 'mockMemberName'];

  let responseCount = 0;
  const sessionStorageGetItem = function*() {
    if (responseCount >= sessionStorageResponseArray.length) {
      responseCount = 0;
    }
    yield sessionStorageResponseArray[responseCount++];
  };

  beforeEach(async(() => {
    mockActivatedRoute = {
      snapshot: {
        data: {
          claimsInfo: getclaimssummary_response
        }
      }
    };

    mockRouter = mocks.service.router;
    mockAlertService = mocks.service.alertService;
    mockValidationService = mocks.service.validationService;
    mockConstantsService = mocks.service.constantsService;
    mockAuthService = mocks.service.authService;
    mockGlobalService = mocks.service.globalService;
    mockDependantsService = mocks.service.dependantsService;
    mockFilterService = mocks.service.filterService;
    mockClaimsService = mocks.service.claimsService;
    mockChangeDetectionRef = mocks.service.changeDetectionRef;

    spyOn(sessionStorage.__proto__, 'getItem').and.returnValue(sessionStorageGetItem().next().value);

    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        StorageServiceModule,
        HttpClientTestingModule,

        MatDatepickerModule,
        MatNativeDateModule,
        MatFormFieldModule,
        MatRadioModule,
        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatDialogModule,
        MatExpansionModule,
        MatListModule,
        MatButtonModule,
        MaterialModule
      ],
      declarations: [
        FakeBreadcrumbsComponent,
        FakeFpoLayoutComponent,
        FakeSpinnerComponent,

        FakeCellAspectRatioDirectiveStub,
        FakeInfiniteScrollUpDistanceDirectiveStub,
        FakeScrollWindowDirectiveStub,
        FakeInfiniteScrollDirectiveStub,
        FakeInfiniteScrollContainerDirectiveStub,
        FakeFromRootDirectiveStub,
        FakeInfiniteScrollDistanceDirectiveStub,
        FakeInfiniteScrollThrottleDirectiveStub,
        FakeInfiniteScrollDisabledDirectiveStub,
        FakescrolledDirectiveStub,
        FakeScrolledUpDirectiveStub,
        PromoImagesComponent,
        ClaimidPipe,
        ClaimStatusDetailsComponent
      ],
      providers: [
        { provide: Router, useValue: mockRouter },
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: AlertService, useValue: mockAlertService },
        { provide: ValidationService, useValue: mockValidationService },
        { provide: ConstantsService, useValue: mockConstantsService },
        { provide: GlobalService, useValue: mockGlobalService },
        { provide: AuthService, useValue: mockAuthService },
        { provide: DependantsService, useValue: mockDependantsService },
        { provide: FilterService, useValue: mockFilterService },
        { provide: ClaimsService, useValue: mockClaimsService },
        { provide: ChangeDetectorRef, useValue: mockChangeDetectionRef },
        DatePipe
      ]
    }).compileComponents();
  }));

  describe('Constructor', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(ClaimStatusDetailsComponent);
      component = fixture.componentInstance;
    });

    it('should create', () => {
      // assert
      expect(component).toBeTruthy();
    });
  });

  describe('ngOnInit', () => {
    describe('should have initialized', () => {
      it('should have loaded', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimStatusDetailsComponent);
        component = fixture.componentInstance;

        // act
        fixture.detectChanges();

        // assert
        expect(component).toBeTruthy();
      });
    });

    describe('should have called', () => {
      it('should have called this.getClaimProcessingStatus()', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimStatusDetailsComponent);
        component = fixture.componentInstance;
        spyOn(component, 'getClaimProcessingStatus').and.returnValue(null);

        // act
        fixture.detectChanges();

        // assert
        expect(component.getClaimProcessingStatus).toHaveBeenCalled();
      });
      it('should have called sessionStorage.getItem thrice', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimStatusDetailsComponent);
        component = fixture.componentInstance;

        // act
        fixture.detectChanges();

        // assert
        expect(sessionStorage.getItem).toHaveBeenCalledTimes(3);
      });
    });
  });

  describe('methods', () => {
    describe('getClaimProcessingStatus', () => {
      it('should have called this.claimService.getClaimProcessingStatus', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimStatusDetailsComponent);
        component = fixture.componentInstance;
        // act
        fixture.detectChanges();
        // assert
        expect(mockClaimsService.getClaimProcessingStatus).toHaveBeenCalled();
      });
      describe('failure response', () => {
        beforeAll(() => {
          // arrange
          const newMockClaimsService = Object.assign({}, mockClaimsService);
          newMockClaimsService.getClaimProcessingStatus.and.returnValue(of(getclaimprocessingstatus_response.failure));

          TestBed.overrideProvider(ClaimsService, { useValue: newMockClaimsService });
          TestBed.compileComponents();
        });

        beforeEach(async () => {
          fixture = TestBed.createComponent(ClaimStatusDetailsComponent);
          component = fixture.componentInstance;
          fixture.detectChanges();
        });

        afterAll(() => {
          const newMockClaimsService = Object.assign({}, mockClaimsService);
          newMockClaimsService.getClaimProcessingStatus.and.returnValue(of(getclaimprocessingstatus_response.success));
          TestBed.overrideProvider(ClaimsService, { useValue: newMockClaimsService });
          TestBed.compileComponents();
        });

        it('should have set this.alertService.setAlert to have been called', () => {
          // assert
          expect(mockAlertService.setAlert).toHaveBeenCalled();
        });
      });
      describe('success response', () => {
        it('should have called this.setClaimProcessingStatus', () => {
          // arrange
          fixture = TestBed.createComponent(ClaimStatusDetailsComponent);
          component = fixture.componentInstance;
          spyOn(component, 'setClaimProcessingStatus').and.returnValue('');
          // act
          fixture.detectChanges();

          // assert
          expect(component.setClaimProcessingStatus).toHaveBeenCalled();
        });
      });
    });
    describe('setClaimProcessingStatus', () => {
      it('should have called sessionStorage.getItem', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimStatusDetailsComponent);
        component = fixture.componentInstance;
        // act
        fixture.detectChanges();
        // assert
        expect(sessionStorage.getItem).toHaveBeenCalled();
      });
      it('should have called this.formattedDate thrice', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimStatusDetailsComponent);
        component = fixture.componentInstance;
        spyOn(component, 'formattedDate').and.returnValue('');
        // act
        fixture.detectChanges();
        // assert
        expect(component.formattedDate).toHaveBeenCalledTimes(3);
      });
      it('should have called this.setClaimProcessingTagLine', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimStatusDetailsComponent);
        component = fixture.componentInstance;
        spyOn(component, 'setClaimProcessingTagLine').and.returnValue('');
        // act
        fixture.detectChanges();
        // assert
        expect(component.setClaimProcessingTagLine).toHaveBeenCalled();
      });
      it('should have called this.claimProcessingSteps', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimStatusDetailsComponent);
        component = fixture.componentInstance;

        // act
        fixture.detectChanges();

        // assert
        expect(component.claimProcessingSteps.length).toBe(4);
      });
      describe('should assert the following for this.claimProcessingSteps', () => {
        beforeEach(() => {
          // arrange
          fixture = TestBed.createComponent(ClaimStatusDetailsComponent);
          component = fixture.componentInstance;

          // act
          fixture.detectChanges();
        });
        it('should assert for the first value in this claimProcessingSteps array', () => {
          // arrange
          const item = component.claimProcessingSteps[0];

          // assert
          expect(item.step).toEqual(1);
          expect(item.label).toBe('Care');
          expect(item.description).toBe('When you visit a doctor or hospital for medical care.');
          expect(item.additionalDetails).toContain('Date of Service: ');
        });
        it('should assert for the first value in this claimProcessingSteps array', () => {
          // arrange
          const item = component.claimProcessingSteps[1];

          // assert
          expect(item.step).toEqual(2);
          expect(item.label).toBe('Submit');
          expect(item.description).toBe('When you or your doctor submits a claim to Blue Cross.');
          expect(item.additionalDetails).toContain('Claim Submitted to Blue Cross: ');
        });
        it('should assert for the first value in this claimProcessingSteps array', () => {
          // arrange
          const item = component.claimProcessingSteps[2];

          // assert
          expect(item.step).toEqual(3);
          expect(item.label).toBe('Process');
          expect(item.description).toBe('Blue Cross processes your claim based on your health coverage.');
        });
        it('should assert for the first value in this claimProcessingSteps array', () => {
          // arrange
          const item = component.claimProcessingSteps[3];

          // assert
          expect(item.step).toEqual(4);
          expect(item.label).toBe('Notify');
          expect(item.description).toBe('Blue Cross notifies you when you owe money for covered services.');
          expect(item.additionalDetails).toContain('Claim completed: ');
        });
      });
    });

    describe('setClaimProcessingTagLine', () => {
      it('should return "Claim completed" if this.claimProcessingStatus.claimStatus.toLowerCase() is "completed"', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimStatusDetailsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();

        // act
        const result = component.setClaimProcessingTagLine();

        // assert
        expect(result).toBe('Claim completed');
      });
      it('should return "Claim completed" if this.claimProcessingStatus.claimStatus.toLowerCase() is "denied"', () => {
        // arrange
        const newMockClaimsService = Object.assign({}, mockClaimsService);
        newMockClaimsService.getClaimProcessingStatus.and.returnValue(
          of({
            statusRecord: {
              claimId: '020181721502100',
              claimStatus: 'Denied',
              dateOfService: '2017-02-22',
              firstDateOfService: '2017-02-22',
              lastDateOfService: '2017-02-22',
              recievedDate: '2017-02-22',
              completedDate: '2017-02-26'
            }
          })
        );
        TestBed.overrideProvider(ClaimsService, { useValue: newMockClaimsService });
        TestBed.compileComponents();

        fixture = TestBed.createComponent(ClaimStatusDetailsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();

        // act
        const result = component.setClaimProcessingTagLine();

        // assert
        expect(result).toBe('Claim completed');
      });
      it('should return "Claim is pending" if this.claimProcessingStatus.claimStatus.toLowerCase() is "pending"', () => {
        // arrange
        const newMockClaimsService = Object.assign({}, mockClaimsService);
        newMockClaimsService.getClaimProcessingStatus.and.returnValue(
          of({
            statusRecord: {
              claimId: '020181721502100',
              claimStatus: 'pending',
              dateOfService: '2017-02-22',
              firstDateOfService: '2017-02-22',
              lastDateOfService: '2017-02-22',
              recievedDate: '2017-02-22',
              completedDate: '2017-02-26'
            }
          })
        );
        TestBed.overrideProvider(ClaimsService, { useValue: newMockClaimsService });
        TestBed.compileComponents();

        fixture = TestBed.createComponent(ClaimStatusDetailsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();

        // act
        const result = component.setClaimProcessingTagLine();

        // assert
        expect(result).toBe('Claim is pending.');
      });
      it('should return nothing if this.claimProcessingStatus.claimStatus is null or undefined', () => {
        // arrange
        const newMockClaimsService = Object.assign({}, mockClaimsService);
        newMockClaimsService.getClaimProcessingStatus.and.returnValue(
          of({
            statusRecord: {
              claimId: '020181721502100',
              claimStatus: '',
              dateOfService: '2017-02-22',
              firstDateOfService: '2017-02-22',
              lastDateOfService: '2017-02-22',
              recievedDate: '2017-02-22',
              completedDate: '2017-02-26'
            }
          })
        );
        TestBed.overrideProvider(ClaimsService, { useValue: newMockClaimsService });
        TestBed.compileComponents();

        fixture = TestBed.createComponent(ClaimStatusDetailsComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
        // act
        const result = component.setClaimProcessingTagLine();
        // assert
        expect(typeof result).toBe('undefined');
      });
    });
    describe('navigateToDetailsPage', () => {
      it('should have called this.router.navigate with "[\'../myclaims/claimdetails\']") as param', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimStatusDetailsComponent);
        component = fixture.componentInstance;

        // act
        component.navigateToDetailsPage();

        // assert
        expect(mockRouter.navigate).toHaveBeenCalledWith(['../myclaims/claimdetails']);
      });
    });
    describe('formattedDate', () => {
      beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(ClaimStatusDetailsComponent);
        component = fixture.componentInstance;
      });
      it('should have called this.datePipe.transform when called with a valid date string as param', () => {
        // act
        const result = component.formattedDate('01Jan2019');

        // assert
        expect(result).toBe('01/01/2019');
      });
      it('should return undefined if invalid date string/ null/NaN/Undefined value is passed in as param', () => {
        // act
        const result = component.formattedDate('');

        // assert
        expect(typeof result).toBe('undefined');
      });
    });
  });
});
