import { DebugElement } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { MedicationsComponent } from '../../../../../../app/pages/my-pillpack/medications/medications.component';

describe('MedicationsComponent', () => {
  let component: MedicationsComponent;
  let fixture: ComponentFixture<MedicationsComponent>;
  let medicationsDe: DebugElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MedicationsComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicationsComponent);
    medicationsDe = fixture.debugElement;
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });

  xit('should have breadcrumbs', () => {
    const breadCrumbsDe = medicationsDe.query(By.css('app-breadcrumbs'));
    expect(breadCrumbsDe.nativeElement).toBeTruthy();
  });
});
