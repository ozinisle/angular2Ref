import { CommonModule, DatePipe, TitleCasePipe } from '@angular/common';
import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { StorageServiceModule } from 'angular-webstorage-service';
import { FadService } from '../../../../../../app/pages/fad/fad.service';
import { AuthUserLandingComponent } from '../../../../../../app/pages/landing/authenticated-user/authenticated-user.component';
import { LandingService } from '../../../../../../app/pages/landing/landing.service';
import { MyMedicationDetailsService } from '../../../../../../app/pages/medications/myMedicationDetails/my-medication-details.service';
import { MyDedCoService } from '../../../../../../app/pages/myded-co/myded-co.service';
import { PreferenceModalService } from '../../../../../../app/pages/preference-modal/preference-modal.service';
import { LineChartOptions } from '../../../../../../app/shared/components/alegeus-line-chart/line-chart.model';
import { Finanical } from '../../../../../../app/shared/models/finanical.model';
import { CamelcasePipe } from '../../../../../../app/shared/pipes/camelcase/camelcase.pipe';
import { CasingForFilterPipe } from '../../../../../../app/shared/pipes/casingForFilter/casingForFilter.pipe';
import { ClaimidPipe } from '../../../../../../app/shared/pipes/claimid/claimid.pipe';
import { HomedatePipe } from '../../../../../../app/shared/pipes/date/date.pipe';
import { YyyymmddTommddyyyyPipe } from '../../../../../../app/shared/pipes/date/yyyymmdd-to-mmddyyyy.pipe';
import { PhonePipe } from '../../../../../../app/shared/pipes/phone/phone.pipe';
import { AuthHttp } from '../../../../../../app/shared/services/auth-http.service';
import { GlobalService } from '../../../../../../app/shared/services/global.service';
import { ProfileService } from '../../../../../../app/shared/services/myprofile/profile.service';
import { AlertService, AuthService, ConstantsService } from '../../../../../../app/shared/shared.module';
import { mocks } from '../../../../../constants/mocks.service';
import { AuthenticatedUserComponentData } from '../../../../../data/landing/authenticated-user.component.data';
import { gethomepageinfo_response } from '../../../../../data/landing/home-page-info.data';
import {
  FakeAlertsComponent, FakeFinancialChartComponent,
  FakeInactiveHomePageFpoLayoutComponent,
  FakeLineChartComponent,
  FakePromoBlocksComponent,
  FakePromoCarouselComponent,
  FakePromoImagesComponent,
  FakeSpinnerComponent,
  FakeSpinnertimeoutComponent
} from '../../../../../fake-components';
import { FakeMaterializeParamsDirectiveStub, FakeRouterLinkDirectiveStub } from '../../../../../fake-directives';


// to take care of [routerLink] is not a known attribe of a tag error
describe('AuthUserLandingComponent', () => {
  let component: AuthUserLandingComponent;
  let fixture: ComponentFixture<AuthUserLandingComponent>;

  let mockAuthService;
  let mockGlobalService;
  let mockRouter;
  let mockAuthHttp;
  let mockActivatedRoute;
  let mockConstantsService;
  let mockLandingService;
  let mockAlertService;
  let mockMyDedCoService;
  let mockMyMedicationDetailsService;
  let mockPreferenceModalService;
  let mockProfileService;
  let spySessionStorageGetItem;

  beforeEach(async(() => {
    spySessionStorageGetItem = spyOn(window.sessionStorage, 'getItem').and
            .callFake(() => {
              const postLoginInfo = JSON.stringify(AuthenticatedUserComponentData.globalService.getPostLoginSessionObject);
              return postLoginInfo;
            });
    mockActivatedRoute = {
      snapshot: {
        data: {
          memberInfo: gethomepageinfo_response
        }
      }
    };

    mockAuthService = mocks.service.authService;

    mockGlobalService = mocks.service.globalService;

    mockRouter = mocks.service.router;

    mockAuthHttp = mocks.service.authHttp;

    mockConstantsService = mocks.service.constantsService;

    mockLandingService = mocks.service.landingService;

    mockAlertService = mocks.service.alertService;

    mockMyDedCoService = mocks.service.myDedCoService;

    mockMyMedicationDetailsService = mocks.service.myMedicationDetailsService;

    mockProfileService = mocks.service.profileService;

    mockPreferenceModalService = mocks.service.preferenceModalService;

    TestBed.configureTestingModule({
      imports: [CommonModule, FormsModule, StorageServiceModule], // necessary compiler to identify ngModel
      declarations: [
        YyyymmddTommddyyyyPipe,
        CamelcasePipe,
        PhonePipe,
        HomedatePipe,
        CasingForFilterPipe,
        ClaimidPipe,
        AuthUserLandingComponent,
        FakeRouterLinkDirectiveStub,
        FakePromoImagesComponent,
        FakeFinancialChartComponent,
        FakeInactiveHomePageFpoLayoutComponent,
        FakeSpinnertimeoutComponent,
        FakeLineChartComponent,
        FakeSpinnerComponent,
        FakePromoCarouselComponent,
        FakeMaterializeParamsDirectiveStub,
        FakePromoBlocksComponent,
        FakeAlertsComponent
      ],

      providers: [
        TitleCasePipe,
        DatePipe,
        { provide: AuthService, useValue: mockAuthService },
        { provide: GlobalService, useValue: mockGlobalService },
        { provide: Router, useValue: mockRouter },
        { provide: AuthHttp, useValue: mockAuthHttp },
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: ConstantsService, useValue: mockConstantsService },
        { provide: LandingService, useValue: mockLandingService },
        { provide: AlertService, useValue: mockAlertService },
        { provide: MyDedCoService, useValue: mockMyDedCoService },
        { provide: MyMedicationDetailsService, useValue: mockMyMedicationDetailsService },
        { provide: ProfileService, useValue: mockProfileService },
        { provide: PreferenceModalService, useValue: mockPreferenceModalService },
        { provide: FadService, useValue: mocks.service.FadService}
      ]
    }).compileComponents();
  }));

  describe('constructor', () => {
    // assert constructor contents
    beforeEach(() => {
      spyOn(AuthUserLandingComponent.prototype, 'transformCarouselResponse').and.returnValue(
        AuthenticatedUserComponentData.methods.transformCauroselResponse
      );
      fixture = TestBed.createComponent(AuthUserLandingComponent);
      spyOn(sessionStorage, 'removeItem').and.returnValue(null);
      component = fixture.componentInstance;

    });
    it('should create', () => {
      expect(component).toBeTruthy();
    });

    // describe('should have initialized', () => {
    // });
    // describe('should have called', () => {
    // });
  });

  describe('onInit', () => {
    beforeEach(() => {
      spyOn(AuthUserLandingComponent.prototype, 'transformCarouselResponse').and.returnValue(
        AuthenticatedUserComponentData.methods.transformCauroselResponse
      );
      fixture = TestBed.createComponent(AuthUserLandingComponent);
      component = fixture.componentInstance;
      spyOn(sessionStorage.__proto__, 'removeItem').and.returnValue(null);

      fixture.detectChanges();
    });

    it('should load', () => {
      expect(component).toBeTruthy();
    });
    it('Pharmacy Menu links check when links coming as empty array', () => {
      const getPostLoginSessionObject = {
        hasSS: false,
        hasSSO: false,
        hasCI: false
      };
      spySessionStorageGetItem.and
      .callFake(() => {
        const postLoginInfo = JSON.stringify(getPostLoginSessionObject);
        return postLoginInfo;
      });
      fixture = TestBed.createComponent(AuthUserLandingComponent);
      component = fixture.componentInstance;

      const link = component.getMyPharmacyMenu();
      expect(link).toEqual([]);
    });
  });
  describe('getMyPharmacyMenu method check', () => {
    beforeEach(() => {
      fixture = TestBed.createComponent(AuthUserLandingComponent);
      component = fixture.componentInstance;
      spyOn(sessionStorage.__proto__, 'removeItem').and.returnValue(null);

      fixture.detectChanges();
    });

    it('Check Medication Lookup Tool link', () => {
      expect(component.getMyPharmacyMenu()[1]['text']).toEqual('Medication Lookup Tool');
      expect(component.getMyPharmacyMenu()[1]['url']).toEqual('https://home.bluecrossma.com/medication/?icid=myblueglobalnav');
    });

    it('Check PillPack link', () => {
      expect(component.getMyPharmacyMenu()[2]['text']).toEqual('PillPack');
      expect(component.getMyPharmacyMenu()[2]['url']).toEqual('/my-pillpack/landing');
    });
  });
  describe('Express Script link check', () => {
    beforeEach(() => {
      fixture = TestBed.createComponent(AuthUserLandingComponent);
      const getPostLoginSessionObject = {
        hasSS: false,
        hasSSO: false,
        hasCI: false,
        phoneNumbers: [
          {
            text: 'Call Member Service: ',
            number: '800-262-2583'
          },
          {
            text: 'TTY: ',
            number: '711'
          },
          {
            text: 'Talk to a Nurse:',
            number: '888-247-2583'
          },
          {
            text: 'Talk to a Doctor',
            number: ''
          },
          {
            text: 'Send a Message',
            number: ''
          }
        ],
        isCPDPEnrolled: false,
        isCPDPHandedoff: false,
        isCPDPPromotion: true,
        isKYMember: false,
        pharmacyLinks: [
          {
            text: 'My Medications',
            url: '/mymedications'
          },
          {
            text: 'Medication Lookup Tool',
            url: 'https://home.bluecrossma.com/medication/?icid=myblueglobalnav'
          },
          {
            text: 'Express Script',
            url: '/sso/expressscript'
          }
        ]
      };
      spySessionStorageGetItem.and
      .callFake(() => {
        const postLoginInfo = JSON.stringify(getPostLoginSessionObject);
        return postLoginInfo;
      });
      component = fixture.componentInstance;
      spyOn(sessionStorage.__proto__, 'removeItem').and.returnValue(null);

      fixture.detectChanges();
    });
    it('Check Express Script link', () => {
      expect(component.getMyPharmacyMenu()[2]['text']).toEqual('Express Script');
      expect(component.getMyPharmacyMenu()[2]['url']).toEqual('/sso/expressscript');
    });
  });

  describe('navigate Pharmacy Link method check', () => {
    it('should opened navigate Pharmacy Link with sso/link', () => {
      // arrange
      const spyWindowOpen = spyOn(window, 'open');
      fixture = TestBed.createComponent(AuthUserLandingComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      component.navigatePharmacyUrl('sso/link');
      // assert
      expect(spyWindowOpen).toHaveBeenCalledWith('sso/link');
    });

    it('should opened navigate Pharmacy Link with MyPillPack  ', () => {
      // arrange
      fixture = TestBed.createComponent(AuthUserLandingComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      component.navigatePharmacyUrl('/my-pillpack/landing');
      // assert
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/my-pillpack/landing'], { queryParams: { icid: 'PillPack Global' } });
    });

    it('should opened navigate Pharmacy Link as staring with / ', () => {
      // arrange
      fixture = TestBed.createComponent(AuthUserLandingComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      component.navigatePharmacyUrl('/');
      // assert
      expect(mockRouter.navigate).toHaveBeenCalledWith(['/']);
    });

    it('should navigate Pharmacy Link to Cost Share Assistance  ', () => {
      // arrange
      fixture = TestBed.createComponent(AuthUserLandingComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      component.navigatePharmacyUrl('/costShare');
      // assert
      expect(mockRouter.navigate).toHaveBeenCalled();
    });
  });

  describe('methods', () => {
    describe('openBqi', () => {
      let spyWindowOpen;
      beforeEach(() => {
        spyWindowOpen = spyOn(window, 'open');
      });

      it('should call this.authService.impersonation', () => {
        // arrange
        fixture = TestBed.createComponent(AuthUserLandingComponent);
        component = fixture.componentInstance;

        // act
        component.openBqi();

        // assert
        expect(mockAuthService.impersonation).toHaveBeenCalled();
      });

      it('should open sso/connecture in new window as !impersonate ', () => {
        // arrange

        fixture = TestBed.createComponent(AuthUserLandingComponent);
        component = fixture.componentInstance;

        // act
        const impersonate = mockAuthService.impersonation();
        component.openBqi();

        // assert
        if (!impersonate) {
          expect(spyWindowOpen).toHaveBeenCalledWith('sso/connecture', '_blank');
        }
      });
    });

    describe('openAhealthyme', () => {
      it('should call this.authService.impersonation', () => {
        // arrange
        fixture = TestBed.createComponent(AuthUserLandingComponent);
        component = fixture.componentInstance;
        spyOn(component, 'openAhealthyme').and.callFake(() => null);

        // act
        component.openAhealthyme();

        // assert
        expect(mockAuthService.impersonation).toHaveBeenCalled();
      });

      xit('should opened this.constantsService.cernerMedicareUrl in new window '
      + 'when this.memberInfo.cerner.hasCernerMedicare = true && !impersonate', () => {
        // arrange
        const spyWindowOpen = spyOn(window, 'open');
        fixture = TestBed.createComponent(AuthUserLandingComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();

        // act
        gethomepageinfo_response.ROWSET.ROW.cerner.hasCernerMedicare = 'false';
        const impersonate = mockAuthService.impersonation();
        component.openAhealthyme();

        // assert
        expect(spyWindowOpen).toHaveBeenCalledWith(mockConstantsService.CernerMedicareUrl, '_blank');
      });

    describe('navigateToAlegeus', () => {
      it('should call this.authService.impersonation', () => {
        // arrange
        fixture = TestBed.createComponent(AuthUserLandingComponent);
        component = fixture.componentInstance;
        spyOn(component, 'navigateToAlegeus').and.callFake(() => null);
        const lineChart = new Finanical();
        // act
        component.navigateToAlegeus(lineChart);

        // assert
        expect(mockAuthService.impersonation).toHaveBeenCalled();
      });

      xit('should opened /sso/alegeus in new window when hasALG = true && !impersonate', () => {
        // arrange
        const spyWindowOpen = spyOn(window, 'open');
        fixture = TestBed.createComponent(AuthUserLandingComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();

        // act
        gethomepageinfo_response.ROWSET.ROW.hasALG = 'true';
        gethomepageinfo_response.ROWSET.ROW.hasHEQ = 'false';
        const lineChart = new Finanical();
        component.navigateToAlegeus(lineChart);

        // assert
        expect(spyWindowOpen).not.toHaveBeenCalledWith('/sso/alegeus', '_blank');
      });

      xit('should opened /sso/heathequity = true && !impersonate', () => {
        // arrange
        const spyWindowOpen = spyOn(window, 'open');
        fixture = TestBed.createComponent(AuthUserLandingComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();

        // act
        gethomepageinfo_response.ROWSET.ROW.hasALG = 'false';
        gethomepageinfo_response.ROWSET.ROW.hasHEQ = 'true';
        const lineChart = new Finanical();
        component.navigateToAlegeus(lineChart);

        // assert
        expect(spyWindowOpen).not.toHaveBeenCalledWith('/sso/heathequity', '_blank');
      });
    });
  });

  xdescribe('getFinanicalData', () => {
    beforeAll(() => {
      spyOn(AuthUserLandingComponent.prototype, 'hasFinancialsData').and.returnValue(true);
      fixture = TestBed.createComponent(AuthUserLandingComponent);
      component = fixture.componentInstance;
    });
    it('should call the financial data api', () => {
      component.getFinancialData();
      expect(component.landingService.getFinanceBalanceData).toHaveBeenCalled();
    });
    it('should assign the financial data to component', fakeAsync(() => {
      component.getFinancialData();
      tick(1000);
      expect(component.financialChartDetails).toBeTruthy();
      const financial = new Finanical();
      financial.isALGAccount = false;
      financial.acountNumber = '';
      financial.PlanEndDate = '2020-01-01 - 2020-12-31';
      financial.PlanEndDate = '';
      financial.chartOptions = new LineChartOptions();
      expect(component.financialChartDetails[0]).toEqual(financial);
    }));
  });
});
