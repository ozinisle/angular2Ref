import { TestBed, inject } from '@angular/core/testing';

import {
  FadSuggestAnEditDialogService
} from '../../../../../../app/pages/fad/fad-suggest-an-edit-dialog/fad-suggest-an-edit-dialog.service';
import { FadModule } from '../../../../../../app/pages/fad/fad.module';
import { AuthHttp } from '../../../../../../app/shared/services/auth-http.service';
import { mocks } from '../../../../../constants/mocks.service';

describe('FadSuggestAnEditDialogService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [FadModule],
      providers: [FadSuggestAnEditDialogService,
      {
        provide: AuthHttp,
        useValue: mocks.service.AuthHttp
      }]
    });
  });

  it('should be created', inject([FadSuggestAnEditDialogService], (service: FadSuggestAnEditDialogService) => {
    expect(service).toBeTruthy();
  }));
});
