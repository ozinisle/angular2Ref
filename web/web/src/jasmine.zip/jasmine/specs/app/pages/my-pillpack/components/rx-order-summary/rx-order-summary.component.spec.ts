import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RxOrderSummaryComponent } from '../../../../../../../app/pages/my-pillpack/components/rx-order-summary/rx-order-summary.component';

describe('RxOrderSummaryComponent', () => {
  let component: RxOrderSummaryComponent;
  let fixture: ComponentFixture<RxOrderSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RxOrderSummaryComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RxOrderSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
