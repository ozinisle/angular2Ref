import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthenticaionErrorComponent } from '../../../../../../../app/pages/sso-inbound/pages/authenticaion-error/authenticaion-error.component';
import { SsoInboundModule } from '../../../../../../../app/pages/sso-inbound/sso-inbound.module';
import { AlertService } from '../../../../../../../app/shared/shared.module';
import { mocks } from '../../../../../../constants/mocks.service';

describe('AuthenticaionErrorComponent', () => {
  let component: AuthenticaionErrorComponent;
  let fixture: ComponentFixture<AuthenticaionErrorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SsoInboundModule],
      providers : [{provide: AlertService, useValue: mocks.service.alertService}]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuthenticaionErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
