import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { SelectionService } from '../../../../../../app/shared/services/downloadForm/selection.service';
import {
  DownloadReimbursementComponent
} from '../../../../../../app/pages/fitness-and-weightloss/download-reimbursement/download-reimbursement.component';
import { FitnessAndWeightlossModule } from '../../../../../../app/pages/fitness-and-weightloss/fitness-and-weightloss.module';
import { mocks } from '../../../../../constants/mocks.service';
import { AuthHttp } from '../../../../../../app/shared/services/auth-http.service';

describe('DownloadReimbursementComponent', () => {
  let component: DownloadReimbursementComponent;
  let fixture: ComponentFixture<DownloadReimbursementComponent>;
  beforeEach(() => {
    const formBuilderStub = {
      group: formGroup => ({
        year: 2018,
        typeOfReimbursement: 'fitness'
      })
    };
    const routerStub = { navigate: array => ({}) };
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      imports: [FitnessAndWeightlossModule],
      providers: [
        { provide: SelectionService, useValue: mocks.service.selectionService },
        { provide: FormBuilder, useValue: formBuilderStub },
        { provide: Router, useValue: routerStub },
        { provide: AuthHttp, useValue: mocks.service.authHttp}
      ]
    });
    fixture = TestBed.createComponent(DownloadReimbursementComponent);
    component = fixture.componentInstance;
  });
  it('can load instance', () => {
    expect(component).toBeTruthy();
  });
  it('isFormSubmitted defaults to: false', () => {
    expect(component.isFormSubmitted).toEqual(false);
  });
  it('showForm defaults to: false', () => {
    expect(component.showForm).toEqual(false);
  });
  it('buttonCopy defaults to: Continue', () => {
    expect(component.buttonCopy).toEqual('Continue');
  });
  it('typeofBenefit defaults to: []', () => {
    expect(component.typeofBenefit).toEqual([]);
  });
  it('onlineSubmission defaults to: false', () => {
    expect(component.onlineSubmission).toEqual(false);
  });
  it('showSelectionForm defaults to: false', () => {
    expect(component.showSelectionForm).toEqual(false);
  });
  it('showNoFormPage defaults to: true', () => {
    expect(component.showNoFormPage).toEqual(true);
  });
  describe('ngOnInit', () => {
    it('makes expected calls', () => {
      spyOn(component, 'initializeReimbursementsForm').and.callThrough();
      component.ngOnInit();
      expect(component.initializeReimbursementsForm).toHaveBeenCalled();
    });
  });
  describe('initializeReimbursementsForm', () => {
    it('makes expected calls', () => {
      const formBuilderStub: FormBuilder = fixture.debugElement.injector.get(FormBuilder);
      spyOn(formBuilderStub, 'group').and.callThrough();
      component.initializeReimbursementsForm();
      expect(mocks.service.selectionService.getYear).toHaveBeenCalled();
      expect(formBuilderStub.group).toHaveBeenCalled();
    });
  });

  describe('navigateToFitness', () => {
    it('makes expected calls', () => {
      const routerStub: Router = fixture.debugElement.injector.get(Router);
      spyOn(routerStub, 'navigate').and.callThrough();
      component.navigateToFitness();
      expect(routerStub.navigate).toHaveBeenCalled();
    });
  });
  describe('navigateToWeightloss', () => {
    it('makes expected calls', () => {
      const routerStub: Router = fixture.debugElement.injector.get(Router);
      spyOn(routerStub, 'navigate').and.callThrough();
      component.navigateToWeightloss();
      expect(routerStub.navigate).toHaveBeenCalled();
    });
  });
});
