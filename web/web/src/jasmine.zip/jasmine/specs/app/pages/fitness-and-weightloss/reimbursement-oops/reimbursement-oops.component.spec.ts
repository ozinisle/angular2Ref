import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {
  ReimbursementOopsComponent
} from '../../../../../../app/pages/fitness-and-weightloss/reimbursement-oops/reimbursement-oops.component';
import { FitnessAndWeightlossModule } from '../../../../../../app/pages/fitness-and-weightloss/fitness-and-weightloss.module';
import { Router } from '@angular/router';
import { mocks } from '../../../../../constants/mocks.service';
import { AlertService } from '../../../../../../app/shared/shared.module';

describe('ReimbursementOopsComponent', () => {
  let component: ReimbursementOopsComponent;
  let fixture: ComponentFixture<ReimbursementOopsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FitnessAndWeightlossModule],
      providers : [
        {
          provide: Router,
          useValue: mocks.service.router
        }, {
          provide : AlertService,
          useValue: mocks.service.alertService
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReimbursementOopsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
