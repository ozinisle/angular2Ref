import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatCardModule,
  MatDialogModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { StorageServiceModule } from 'angular-webstorage-service';
import { TextMaskModule } from 'angular2-text-mask';
import { Observable } from 'rxjs';
import { of } from 'rxjs/observable/of';
import { MaterialModule } from '../../../../../../app/material.module';
import { ForgotPasswordComponent } from '../../../../../../app/pages/my-account/forgot-password/forgot-password.component';
import { MyAccountService } from '../../../../../../app/pages/my-account/my-account.service';
import { AlertType } from '../../../../../../app/shared/alerts/alertType.model';
import { BcbsmaerrorHandlerService } from '../../../../../../app/shared/services/bcbsmaerror-handler.service';
import { AlertService, AuthService, ValidationService, ConstantsService } from '../../../../../../app/shared/shared.module';
import { mocks } from '../../../../../constants/mocks.service';
import { verifyfpuser_response } from '../../../../../data/my-account/forgot-password/verifyfpuser.data';
import { authService_getTokens_response } from '../../../../../data/services/authService.data';
import { FakeControlMessagesComponent } from '../../../../../fake-components';
import { GlobalService } from '../../../../../../app/shared/services/global.service';

describe('ForgotPasswordComponent', () => {
  let component: ForgotPasswordComponent;
  let fixture: ComponentFixture<ForgotPasswordComponent>;

  const formBuilder: FormBuilder = new FormBuilder();

  let mockAuthService;
  let mockMyAccountService;
  let mockAlertService;
  let mockActivatedRoute;
  let mockRouter;
  let mockValidationService;
  let mockBcbsmaerrorHandlerService;
  let mockGlobalService;

  beforeEach(async(() => {
    mockMyAccountService = mocks.service.myAccountService;
    mockAuthService = mocks.service.authService;
    mockAlertService = mocks.service.alertService;
    mockValidationService = mocks.service.validationService;
    mockGlobalService = mocks.service.globalService;
    mockRouter = mocks.service.router;
    mockActivatedRoute = {
      params: of({ user: 'michelbartlett@yopmail.com' })
    };

    mockBcbsmaerrorHandlerService = mocks.service.bcbsmaerrorHandlerService;

    TestBed.configureTestingModule({
      imports: [
        BrowserModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        StorageServiceModule,
        HttpClientTestingModule,
        TextMaskModule,
        MatFormFieldModule,
        MatRadioModule,

        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatDialogModule,
        MaterialModule
      ],
      declarations: [FakeControlMessagesComponent, ForgotPasswordComponent],

      providers: [
        ConstantsService,
        { provide: FormBuilder, useValue: formBuilder },
        { provide: AuthService, useValue: mockAuthService },
        { provide: MyAccountService, useValue: mockMyAccountService },
        { provide: AlertService, useValue: mockAlertService },
        { provide: GlobalService, useValue: mockGlobalService },
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: Router, useValue: mockRouter },
        { provide: ValidationService, useValue: mockValidationService },
        { provide: BcbsmaerrorHandlerService, useValue: mockBcbsmaerrorHandlerService }
      ]
    }).compileComponents();
  }));

  describe('Constructor', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(ForgotPasswordComponent);
      component = fixture.componentInstance;
    });
    it('should create', () => {
      // assert
      expect(component).toBeTruthy();
    });
    describe('While Component Creation', () => {
      describe('should have initialized', () => {
        it('should have initialized forgotPwdForm form', () => {
          // arrange
          fixture = TestBed.createComponent(ForgotPasswordComponent);
          // act
          component = fixture.componentInstance;
          // assert
          expect(component.forgotPwdForm).toBeTruthy();
        });

        describe('error handler', () => {
          it('should catch errors and handle them as and when they occur', () => {
            spyOn(formBuilder, 'group').and.callFake(() => {
              throw new Error('an-exception');
            });
            // arrange
            fixture = TestBed.createComponent(ForgotPasswordComponent);
            // act
            component = fixture.componentInstance;
            // assert
            expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
          });
        });
      });
    });
  });
  describe('ngOnInit', () => {
    it('should have loaded', () => {
      // arrange
      fixture = TestBed.createComponent(ForgotPasswordComponent);
      component = fixture.componentInstance;
      // act
      fixture.detectChanges();
      // assert
      expect(component).toBeTruthy();
    });

    it('should have called this.forgotPwdForm.patchValue with userid in localstorage if present', () => {
      // arrange
      localStorage['login-user'] = 'test-user';
      // arrange
      fixture = TestBed.createComponent(ForgotPasswordComponent);
      component = fixture.componentInstance;

      const spy_forgotPwdForm_patchValue = spyOn(component.forgotPwdForm, 'patchValue');

      component['route'].params = of({ user: null });

      // act
      fixture.detectChanges();

      // assert
      expect(spy_forgotPwdForm_patchValue).toHaveBeenCalledWith({ useridin: 'test-user' });
    });

    it('should have called this.forgotPwdForm.patchValue', () => {
      // arrange
      fixture = TestBed.createComponent(ForgotPasswordComponent);
      component = fixture.componentInstance;

      const spy_forgotPwdForm_patchValue = spyOn(component.forgotPwdForm, 'patchValue');

      // act
      fixture.detectChanges();
      // assert
      expect(spy_forgotPwdForm_patchValue).toHaveBeenCalled();
    });

    describe('error handling', () => {
      it('should call the BcbsmaerrorHandlerService.logError in case of errors in the method', () => {
        // arrange
        fixture = TestBed.createComponent(ForgotPasswordComponent);
        component = fixture.componentInstance;

        component['route'] = null;
        // act
        try {
          fixture.detectChanges();
        } catch (forcedError) {}

        // assert
        expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
      });
    });
  });

  describe('Methods', () => {
    describe('ngOnDestroy', () => {
      it('should have called this.alertService.clearError', () => {
        // arrange
        fixture = TestBed.createComponent(ForgotPasswordComponent);
        component = fixture.componentInstance;

        // act
        component.ngOnDestroy();

        // assert
        expect(mockAlertService.clearError).toHaveBeenCalled();
      });

      it('should call the BcbsmaerrorHandlerService.logError in case of errors in the method', () => {
        // arrange
        fixture = TestBed.createComponent(ForgotPasswordComponent);
        component = fixture.componentInstance;
        component['route'] = null;

        // act
        try {
          fixture.detectChanges();
        } catch (forcedError) {}

        // assert
        expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
      });

      describe('error handling', () => {
        it('should catch errors as and when they occur', () => {
          // arrange
          mockAlertService.clearError.and.callFake(function() {
            throw new Error('an-exception');
          });
          TestBed.overrideProvider(AlertService, mockAlertService);
          TestBed.compileComponents();

          fixture = TestBed.createComponent(ForgotPasswordComponent);
          component = fixture.componentInstance;

          // act
          component.ngOnDestroy();

          // assert
          expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
        });

        afterAll(() => {
          mockAlertService.clearError.and.returnValue(null);
          TestBed.overrideProvider(AlertService, mockAlertService);
          TestBed.compileComponents();
        });
      });
    });
    describe('onSubmit', () => {
      it('should have called this.getToken', () => {
        // arrange
        fixture = TestBed.createComponent(ForgotPasswordComponent);
        component = fixture.componentInstance;
        spyOn(component, 'getToken');

        // act
        component.onSubmit();

        // assert
        expect(component.getToken).toHaveBeenCalled();
      });

      it('should call the BcbsmaerrorHandlerService.logError in case of errors in the method', () => {
        // arrange
        fixture = TestBed.createComponent(ForgotPasswordComponent);
        component = fixture.componentInstance;

        // act
        component.onSubmit();

        // assert
        expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
      });

      describe('error handling', () => {
        it('should catch errors as and when they occur', () => {
          // arrange
          fixture = TestBed.createComponent(ForgotPasswordComponent);
          component = fixture.componentInstance;

          spyOn(component, 'getToken').and.callFake(function() {
            throw new Error('an-exception');
          });

          // act
          component.onSubmit();

          // assert
          expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
        });
      });
    });

    describe('getToken', () => {
      beforeEach(() => {
        // arrange
        mockAuthService.getTokens.and.returnValue(of(authService_getTokens_response));
        TestBed.overrideProvider(AuthService, { useValue: mockAuthService });
        TestBed.compileComponents();
      });
      beforeEach(async () => {
        fixture = TestBed.createComponent(ForgotPasswordComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
      });

      afterAll(() => {
        mockAuthService.getTokens.and.returnValue(of(authService_getTokens_response));
        TestBed.overrideProvider(AuthService, { useValue: mockAuthService });
        TestBed.compileComponents();
      });

      it('should have called this.authService.getTokens', () => {
        // arrange
        spyOn(component, 'verifyUser');

        // act
        component.getToken();

        // assert
        expect(mockAuthService.getTokens).toHaveBeenCalled();
      });

      it('should have called this.authService.persistSession', () => {
        // arrange
        spyOn(component, 'verifyUser');

        // act
        component.getToken();

        // assert
        expect(mockAuthService.persistSession).toHaveBeenCalled();
      });

      it('should have called this.verifyUser', () => {
        // arrange
        spyOn(component, 'verifyUser');

        // act
        component.getToken();

        // assert
        expect(component.verifyUser).toHaveBeenCalled();
      });

      it('should call the BcbsmaerrorHandlerService.logError in case of errors in the method', () => {
        // arrange
        fixture = TestBed.createComponent(ForgotPasswordComponent);
        component = fixture.componentInstance;
        spyOn(component, 'verifyUser').and.returnValue(null);

        // act
        component.getToken();

        // assert
        expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
      });

      describe('error handling', () => {
        it('should call the BcbsmaerrorHandlerService.handleHttpError in case this.authService.getTokens() api failure', () => {
          // arrange

          mockAuthService.getTokens.and.returnValue(Observable.throw({ status: 404 }));
          TestBed.overrideProvider(AuthService, mockAuthService);
          TestBed.compileComponents();

          fixture = TestBed.createComponent(ForgotPasswordComponent);
          component = fixture.componentInstance;

          // act
          component.getToken();

          // assert
          expect(mockBcbsmaerrorHandlerService.handleHttpError).toHaveBeenCalled();
        });

        it('should call the BcbsmaerrorHandlerService.logError in case of errors in the method', () => {
          // arrange
          mockAuthService.getTokens.and.callFake(function() {
            throw new Error('an-exception');
          });
          TestBed.overrideProvider(AuthService, mockAuthService);
          TestBed.compileComponents();

          fixture = TestBed.createComponent(ForgotPasswordComponent);
          component = fixture.componentInstance;

          // act
          component.getToken();

          // assert
          expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
        });

        afterAll(() => {
          mockAuthService.getTokens.and.returnValue(of(authService_getTokens_response));
          TestBed.overrideProvider(AuthService, mockAuthService);
          TestBed.compileComponents();
        });
      });
    });

    describe('verifyUser', () => {
      beforeEach(() => {
        spyOn(sessionStorage.__proto__, 'setItem');
      });

      beforeEach(() => {
        // arrange
        mockMyAccountService.verifyUser.and.returnValue(of(verifyfpuser_response.success));
        TestBed.overrideProvider(MyAccountService, { useValue: mockMyAccountService });
        TestBed.compileComponents();
      });
      beforeEach(async () => {
        fixture = TestBed.createComponent(ForgotPasswordComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
      });

      afterAll(() => {
        mockMyAccountService.verifyUser.and.returnValue(of(verifyfpuser_response.success));
        TestBed.overrideProvider(MyAccountService, { useValue: mockMyAccountService });
        TestBed.compileComponents();
      });

      it('should call the alertService.clearError', () => {
        // act
        component.verifyUser();

        // assert
        expect(mockAlertService.clearError).toHaveBeenCalled();
      });

      it('should have called this.myAccountService.verifyUser', () => {
        // act
        component.verifyUser();

        // assert
        expect(mockMyAccountService.verifyUser).toHaveBeenCalled();
      });

      it("should have called ['/account/verifyAccessCode','FPW']", () => {
        // act
        component.verifyUser();

        // assert
        expect(mockRouter.navigate).toHaveBeenCalledWith(['/account/verifyAccessCode', 'FPW']);
      });

      it('should have called this.alertService.setAlert', () => {
        // act
        component.verifyUser();

        // assert
        expect(mockAlertService.setAlert).toHaveBeenCalledWith('Verification code sent.', '', AlertType.Success);
      });

      describe('error handling', () => {
        it('should call the BcbsmaerrorHandlerService.logError in case of errors in the method', () => {
          // arrange
          const _mockAlertService = Object.assign({}, mockAlertService);
          _mockAlertService.clearError.and.callFake(function() {
            throw new Error('an-exception');
          });

          TestBed.overrideProvider(AlertService, _mockAlertService);
          TestBed.compileComponents();

          fixture = TestBed.createComponent(ForgotPasswordComponent);
          component = fixture.componentInstance;

          // act
          component.verifyUser();
          _mockAlertService.clearError.and.returnValue(null);

          // assert
          expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
        });

        it('should call the BcbsmaerrorHandlerService.handleHttpError in case of errors in the method', () => {
          // arrange
          const _mockMyAccountService = Object.assign({}, mockMyAccountService);
          _mockMyAccountService.verifyUser.and.returnValue(Observable.throw({ status: 404 }));

          const _mockAlertService = Object.assign({}, mockAlertService);
          _mockAlertService.clearError.and.returnValue(null);

          TestBed.overrideProvider(AlertService, _mockAlertService);
          TestBed.overrideProvider(MyAccountService, _mockMyAccountService);
          TestBed.compileComponents();

          fixture = TestBed.createComponent(ForgotPasswordComponent);
          component = fixture.componentInstance;

          // act
          component.verifyUser();

          // assert
          expect(mockBcbsmaerrorHandlerService.handleHttpError).toHaveBeenCalled();
        });

        // afterAll(() => {
        //   TestBed.overrideProvider(AlertService, mockAlertService);
        //   TestBed.overrideProvider(MyAccountService, mockMyAccountService);
        //   TestBed.compileComponents();
        // })
      });
    });
  });
});
