import { ComponentFixture, TestBed, fakeAsync, tick } from "@angular/core/testing"
import { ProfileComponent } from "../../../../../../app/pages/my-profile/profile/profile.component"
import { ActivatedRouteSnapshot, Router, ActivatedRoute } from "@angular/router";
import { jasAVUserData } from "../../../../../data/my-profile/avUser.data";
import { mocks } from "../../../../../constants/mocks.service";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { ProfileService } from "../../../../../../app/shared/services/myprofile/profile.service";
import { AlertService } from "../../../../../../app/shared/shared.module";
import { FakeAlertsComponent, FakeBreadcrumbsComponent, FakePromoImagesComponent } from "../../../../../fake-components";
import { PreferenceModalService } from "../../../../../../app/pages/preference-modal/preference-modal.service";

describe('ProfileComponent', () => {

    let component: ProfileComponent;
    let fixture: ComponentFixture<ProfileComponent>;

    let mockRouter;
    let mockActivatedRoute;
    let mockPreferenceModalService;
    let mockProfileService;
    let mockAlertService;

    beforeEach( () => {

        mockActivatedRoute = {
            snapshot: {
                data: {
                    profile: jasAVUserData.getMemProfileApiResponse
                }
            }
        };

        mockRouter = mocks.service.router;
        mockPreferenceModalService = mocks.service.preferenceModalService;
        mockProfileService = mocks.service.profileService;
        mockAlertService = mocks.service.alertService;

        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule
            ],
            providers: [
                { provide: Router, useValue: mockRouter },
                { provide: ActivatedRoute, useValue: mockActivatedRoute },
                { provide: PreferenceModalService, useValue: mockPreferenceModalService },
                { provide: ProfileService, useValue: mockProfileService },
                { provide: AlertService, useValue: mockAlertService }
            ],
            declarations: [
                ProfileComponent,
                FakeAlertsComponent,
                FakeBreadcrumbsComponent,
                FakePromoImagesComponent
            ]
        });

        fixture = TestBed.createComponent(ProfileComponent);
        component = fixture.componentInstance;
    });

    describe('constructor', () => {

        it('should exist', () => {
            expect(component).toBeDefined();
        });
        it('assign value to this.profile from resolver', () => {
            component.profile = jasAVUserData.getMemProfileApiResponse;
            fixture.detectChanges();

            expect(component.profile).toEqual(jasAVUserData.getMemProfileApiResponse);
        });
    });

    describe('ngOnInit', () => {
        it('should call ngOnInit', () => {
            spyOn(component, 'ngOnInit');
            fixture.detectChanges();

            expect(component.ngOnInit).toHaveBeenCalled();
        });
        it('should call setProfile from profile service with profile object', fakeAsync(() => {
            fixture.detectChanges();
            tick(1000);
            expect(mockProfileService.setProfile).toHaveBeenCalled();
        }));
        it('should call initiate promo from preference service', () => {
            fixture.detectChanges();

            expect(mockPreferenceModalService.initiatePromo).toHaveBeenCalled();
        });
    });

    describe('ngOnDestroy', () => {
        it('should call ngOnDestroy', () => {
            spyOn(component, 'ngOnDestroy');
            fixture.detectChanges();

            component.ngOnDestroy();

            expect(component.ngOnDestroy).toHaveBeenCalled();
        });
        it('should call clearError from alert service', () => {
            fixture.detectChanges();

            component.ngOnDestroy();

            expect(mockAlertService.clearError).toHaveBeenCalled();
        });
    });
});

