import { PhoneNumber } from './../../../../../../app/shared/models/postlogininfo.model';
import { EmailAddress } from './../../../../../../app/shared/components/email/EmailAddressInterface';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ContactInformationComponent } from '../../../../../../app/pages/my-profile/contact-information/contact-information.component';
import { jasAVUserData } from '../../../../../data/my-profile/avUser.data';
import { mocks } from '../../../../../constants/mocks.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AlertService, ConstantsService, AuthService, ValidationService } from '../../../../../../app/shared/shared.module';
import { GlobalService } from '../../../../../../app/shared/services/global.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ProfileService } from '../../../../../../app/shared/services/myprofile/profile.service';
import { AuthHttp } from '../../../../../../app/shared/services/auth-http.service';
import { PreferenceModalService } from '../../../../../../app/pages/preference-modal/preference-modal.service';
import {
  FakePromoImagesComponent,
  FakeBreadcrumbsComponent,
  FakeAlertsComponent,
  FakeProfileEmailComponent,
  FakeProfilePhoneComponent,
  FakeControlMessagesComponent
} from '../../../../../fake-components';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule, MatSelectModule } from '@angular/material';
import { FakeParentFormFieldDirectiveStub } from '../../../../../fake-directives';
import { TextMaskModule } from 'angular2-text-mask';
import { CamelcasePipe } from '../../../../../../app/shared/pipes/camelcase/camelcase.pipe';
import { PhonePipe } from '../../../../../../app/shared/pipes/phone/phone.pipe';
import { VerifyEmailMobileService } from '../../../../../../app/components/verify-email-mobile/verify-email-mobile.service';

describe('ContactInformationComponent', () => {
  let component: ContactInformationComponent;
  let fixture: ComponentFixture<ContactInformationComponent>;

  let mockRouter;
  let mockActivatedRoute;
  let mockAlertService;
  let mockValidationService;
  let mockProfileService;
  let mockConstantsService;
  let mockGlobalService;
  let mockAuthHttpService;
  let mockPreferenceModalServie;
  let mockAuthService;
  let verifyEmailMobileService;
  const formBuilder: FormBuilder = new FormBuilder();

  beforeEach(() => {
    mockActivatedRoute = {
      snapshot: {
        data: {
          profile: jasAVUserData.getMemProfileApiResponse
        }
      }
    };

    mockRouter = mocks.service.router;
    mockAlertService = mocks.service.alertService;
    mockValidationService = mocks.service.validationService;
    mockProfileService = mocks.service.profileService;
    mockConstantsService = mocks.service.constantsService;
    mockGlobalService = mocks.service.globalService;
    mockAuthHttpService = mocks.service.authHttp;
    mockPreferenceModalServie = mocks.service.preferenceModalService;
    mockAuthService = mocks.service.authService;

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, FormsModule, ReactiveFormsModule, MatSelectModule, TextMaskModule],
      providers: [
        VerifyEmailMobileService,
        { provide: AlertService, useValue: mockAlertService },
        { provide: GlobalService, useValue: mockGlobalService },
        { provide: ConstantsService, useValue: mockConstantsService },
        { provide: Router, useValue: mockRouter },
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: ProfileService, useValue: mockProfileService },
        { provide: AuthService, useValue: mockAuthService },
        { provide: AuthHttp, useValue: mockAuthHttpService },
        { provide: ValidationService, useValue: mockValidationService },
        { provide: FormBuilder, useValue: formBuilder },
        { provide: PreferenceModalService, useValue: mockPreferenceModalServie }
      ],
      declarations: [
        ContactInformationComponent,
        FakePromoImagesComponent,
        FakeBreadcrumbsComponent,
        FakeAlertsComponent,
        FakeProfileEmailComponent,
        FakeProfilePhoneComponent,
        FakeControlMessagesComponent,
        FakeParentFormFieldDirectiveStub,

        CamelcasePipe,
        PhonePipe
      ]
    });

    fixture = TestBed.createComponent(ContactInformationComponent);
    component = fixture.componentInstance;
    verifyEmailMobileService = TestBed.get(VerifyEmailMobileService);
  });

  describe('constructor', () => {
    it('should exist', () => {
      expect(component).toBeDefined();
    });
    it('should profile be defined', () => {
      expect(component.profile).toBeDefined();
    });
    it('should registeredUserOnly be defined and Falsy', () => {
      expect(component.registeredUserOnly).toBeDefined();
      expect(component.registeredUserOnly).toBeFalsy();
    });
    it('should useridin be defined and empty', () => {
      expect(component.useridin).toBeDefined();
      expect(component.useridin).toBeNull();
    });
    it('should disableSave be defined and Truthy', () => {
      expect(component.disableSave).toBeDefined();
      expect(component.disableSave).toBeTruthy();
    });
    it('should impersonate be defined and Truthy', () => {
      expect(component.impersonate).toBeDefined();
      expect(component.impersonate).toBeTruthy();
    });
    it('should emailChanged be defined and Falsy', () => {
      expect(component.emailChanged).toBeDefined();
      expect(component.emailChanged).toBeFalsy();
    });
    it('should phoneChanged be defined and Falsy', () => {
      expect(component.phoneChanged).toBeDefined();
      expect(component.phoneChanged).toBeFalsy();
    });
    it('should getConsentRes be defined', () => {
      expect(component.getConsentRes).toBeDefined();
    });
    it('should editAddress be defined and Falsy', () => {
      expect(component.editAddress).toBeDefined();
      expect(component.editAddress).toBeFalsy();
    });
    it('should address3 be defined and Empty', () => {
      expect(component.address3).toBeDefined();
      expect(component.address3).toBe('');
    });
    it('should diplayEmailAdress be defined and Empty', () => {
      expect(component.diplayEmailAdress).toBeDefined();
      expect(component.diplayEmailAdress).toBe('');
    });
    it('should diplayEmailAdress be defined and Empty', () => {
      expect(component.diplayEmailAdress).toBeDefined();
      expect(component.diplayEmailAdress).toBe('');
    });
    it('should statesList be defined and Truthy', () => {
      expect(component.statesList).toBeDefined();
      expect(component.statesList).toBeTruthy();
    });
    it('should addressMailingMessages be defined and Truthy', () => {
      expect(component.addressMailingMessages).toBeDefined();
      expect(component.addressMailingMessages).toBeTruthy();
    });
    it('should addressBillingMessages be defined and Truthy', () => {
      expect(component.addressBillingtMessages).toBeDefined();
      expect(component.addressBillingtMessages).toBeTruthy();
    });
    it('should cityMessages be defined and Truthy', () => {
      expect(component.cityMessages).toBeDefined();
      expect(component.cityMessages).toBeTruthy();
    });
    it('should stateMessages be defined and Truthy', () => {
      expect(component.stateMessages).toBeDefined();
      expect(component.stateMessages).toBeTruthy();
    });
    it('should zipMessages be defined and Truthy', () => {
      expect(component.zipMessages).toBeDefined();
      expect(component.zipMessages).toBeTruthy();
    });
    it('should mailingAddressToolTipVisible be defined and Falsy', () => {
      expect(component.mailingAddressToolTipVisible).toBeDefined();
      expect(component.mailingAddressToolTipVisible).toBeFalsy();
    });
    it('should addressEditCancelText be defined and to be edit', () => {
      expect(component.addressEditCancelText).toBeDefined();
      expect(component.addressEditCancelText).toBe('edit');
    });
    it('should addressEditCancelText be defined', () => {
      expect(component.addressEditCancelText).toBeDefined();
    });
    it('should editEmail be defined and Falsy', () => {
      expect(component.editEmail).toBeDefined();
      expect(component.editEmail).toBeFalsy();
    });
    it('should emailEditCancelText be defined and to be edit', () => {
      expect(component.emailEditCancelText).toBeDefined();
      expect(component.emailEditCancelText).toBe('edit');
    });
    it('should isUseridAEmail be defined and Falsy', () => {
      expect(component.isUseridAEmail).toBeDefined();
      expect(component.isUseridAEmail).toBeFalsy();
    });
    it('should phoneEditCancelText be defined and to be edit', () => {
      expect(component.phoneEditCancelText).toBeDefined();
      expect(component.phoneEditCancelText).toBe('edit');
    });
    it('should isUseridAPhone be defined and Falsy', () => {
      expect(component.isUseridAPhone).toBeDefined();
      expect(component.isUseridAPhone).toBeFalsy();
    });
    it('should editPhone be defined and Falsy', () => {
      expect(component.editPhone).toBeDefined();
      expect(component.editPhone).toBeFalsy();
    });
    it('should isMedicare be defined and Falsy', () => {
      expect(component.isMedicare).toBeDefined();
      expect(component.isMedicare).toBeFalsy();
    });

    it('should initiate the "profileAddressEditForm"', () => {
      expect(component.profileAddressEditForm.contains('useridin')).toBeTruthy();
      expect(component.profileAddressEditForm.contains('isEditableAddress')).toBeTruthy();
      expect(component.profileAddressEditForm.contains('userState')).toBeTruthy();
      expect(component.profileAddressEditForm.contains('isDirectPay')).toBeTruthy();
      expect(component.profileAddressEditForm.contains('address1')).toBeTruthy();
      expect(component.profileAddressEditForm.contains('address2')).toBeTruthy();
      expect(component.profileAddressEditForm.contains('dob')).toBeTruthy();
      expect(component.profileAddressEditForm.contains('city')).toBeTruthy();
      expect(component.profileAddressEditForm.contains('state')).toBeTruthy();
      expect(component.profileAddressEditForm.contains('zip')).toBeTruthy();
    });
    it('should define sessionStorage useridin', () => {
      const value = sessionStorage.getItem('useridin');
      expect(component.useridin).toBe(value);
    });
    it('should check "isUseridAPhone" is a regular expression', () => {
      const numberRegEx = new RegExp('^[0-9]{10}');
      component.useridin = jasAVUserData.getMemProfileApiResponse.useridin;
      component.isUseridAPhone = numberRegEx.test(component.useridin);
      expect(component.useridin).not.toMatch(numberRegEx);
      expect(component.isUseridAPhone).toBeFalsy();
    });
    it('should call the profileDataChange$ from profileService', () => {
      expect(mockProfileService.profileDataChange$).toBeTruthy();
      expect(mockProfileService.profileDataChange$).toBeDefined();
    });
    it('assign value to this.profile from resolver', () => {
      component.profile = jasAVUserData.getMemProfileApiResponse;
      expect(component.profile).toEqual(jasAVUserData.getMemProfileApiResponse);
    });
    it('should have obtained the user id', () => {
      component.useridin = jasAVUserData.getMemProfileApiResponse.useridin;
      expect(component.useridin).not.toBeNull();
    });
    it('should call preferenceModalService showPreference', () => {
      expect(mockPreferenceModalServie.showPreference).toHaveBeenCalled();
    });
    it('should showPrefPromo to be preferenceModalService showPreference', () => {
      const value = mockPreferenceModalServie.showPreference();
      expect(component.showPrefPromo).toBe(value);
    });
    it('should call memProfileSuccess on ngOnInit', () => {
      const spy = spyOn(component, 'memProfileSuccess');
      component.ngOnInit();
      expect(spy).toHaveBeenCalled();
    });
    it('should call mockPreferenceModalServie initiatePromo on memProfileSuccess', () => {
      const spy = spyOn(component, 'memProfileSuccess');
      component.memProfileSuccess();
      expect(spy).toHaveBeenCalled();
    });
    it('should diplayEmailAdress be profile EmailAddress on memProfileSuccess', () => {
      component.profile = jasAVUserData.getMemProfileApiResponse;
      component.memProfileSuccess();
      expect(component.diplayEmailAdress).toBeDefined();
      expect(component.diplayEmailAdress).toBeTruthy();
      expect(component.diplayEmailAdress).toBe(component.profile.emailAddress);
    });
    it('should registeredUserOnly be Truthy on memProfileSuccess', () => {
      component.profile = jasAVUserData.getMemProfileApiResponse;
      component.memProfileSuccess();
      expect(component.registeredUserOnly).toBeDefined();
    });
    it('should call mockPreferenceModalServie initiatePromo on memProfileSuccess', () => {
      component.profile = jasAVUserData.getMemProfileApiResponse;
      component.memProfileSuccess();
      expect(mockProfileService.getUserRole).toHaveBeenCalled();
    });
    it('should address3 be Truthy on memProfileSuccess', () => {
      component.profile = jasAVUserData.getMemProfileApiResponse;
      component.memProfileSuccess();
      expect(component.address3).toBeDefined();
    });
    it('should profile phoneNumber be defined on memProfileSuccess', () => {
      component.profile = jasAVUserData.getMemProfileApiResponse;
      const phonenumber = component.formatPhone(component.profile.phoneNumber);
      component.memProfileSuccess();
      expect(component.profile.phoneNumber).toBeDefined();
      expect(component.profile.phoneNumber).toBe(phonenumber);
    });
    it('should profileService patchValue define on memProfileSuccess', () => {
      component.profile = jasAVUserData.getMemProfileApiResponse;
      component.memProfileSuccess();
      expect(component.profileAddressEditForm.patchValue).toBeDefined();
    });
    it('should ProfileService setProfile called on memProfileSuccess', () => {
      component.profile = jasAVUserData.getMemProfileApiResponse;
      component.memProfileSuccess();
      expect(mockProfileService.setProfile).toHaveBeenCalled();
    });
    it('should http hideSpinnerLoading called on memProfileSuccess', () => {
      component.memProfileSuccess();
      expect(mockAuthHttpService.hideSpinnerLoading).toHaveBeenCalled();
    });
    it('should authService impersonation called on impersonation', () => {
      component.impersonation();
      expect(mockAuthService.impersonation).toHaveBeenCalled();
    });
    it('should editAddress be defined and Falsy on resetAllEdits', () => {
      component.resetAllEdits();
      expect(component.editAddress).toBeDefined();
      expect(component.editAddress).toBeFalsy();
    });
    it('should editEmail be defined and Falsy on resetAllEdits', () => {
      component.resetAllEdits();
      expect(component.editEmail).toBeDefined();
      expect(component.editEmail).toBeFalsy();
    });
    it('should editPhone be defined and Falsy on resetAllEdits', () => {
      component.resetAllEdits();
      expect(component.editPhone).toBeDefined();
      expect(component.editPhone).toBeFalsy();
    });
    it('should globalService updateConsent defined on updateConsentInfo', () => {
      component.updateConsentInfo();
      expect(mockGlobalService.updateConsent).toBeDefined();
    });
    it('should profile userState be defined on showEdit', () => {
      component.profile = jasAVUserData.getMemProfileApiResponse;
      component.onChannelEdit('EMAIL');
      expect(component.profile.userState).toBeDefined();
    });
    it('should profileService.authService.isSubscriber be defined on showEdit', () => {
      component.onChannelEdit('EMAIL');
      expect(mockProfileService.authService.isSubscriber).toBeDefined();
    });
    it('should profileAddressEditForm.value.isEditableAddress be defined on showEdit', () => {
      component.onChannelEdit('EMAIL');
      expect(component.profileAddressEditForm.value.isEditableAddress).toBeDefined();
    });
    it('should profileService getProfile called on getAddressFormDefinition', () => {
      component.getAddressFormDefinition();
      expect(mockProfileService.getProfile).toHaveBeenCalled();
    });
    it('should initiate the "profileAddressEditForm" on getAddressFormDefinition', () => {
      component.getAddressFormDefinition();
      expect(component.profileAddressEditForm.contains('useridin')).toBeTruthy();
      expect(component.profileAddressEditForm.contains('isEditableAddress')).toBeTruthy();
      expect(component.profileAddressEditForm.contains('userState')).toBeTruthy();
      expect(component.profileAddressEditForm.contains('isDirectPay')).toBeTruthy();
      expect(component.profileAddressEditForm.contains('address1')).toBeTruthy();
      expect(component.profileAddressEditForm.contains('address2')).toBeTruthy();
      expect(component.profileAddressEditForm.contains('dob')).toBeTruthy();
      expect(component.profileAddressEditForm.contains('city')).toBeTruthy();
      expect(component.profileAddressEditForm.contains('state')).toBeTruthy();
      expect(component.profileAddressEditForm.contains('zip')).toBeTruthy();
    });
    it('should profileService patchValue define on getAddressFormDefinition', () => {
      component.getAddressFormDefinition();
      expect(component.profileAddressEditForm.patchValue).toBeDefined();
    });
    it('should profileService updateProfile called on onSubmit', () => {

      component.onSubmit('mailing', component.profilePermanentAddressEditForm);
      expect(mockProfileService.updateProfile2).toHaveBeenCalled();
    });
    it('should editAddress be defined and Falsy on cancelAddress', () => {
      component.cancelAddress('mailing');
      expect(component.editAddress).toBeDefined();
      expect(component.editAddress).toBeFalsy();
    });
    it('should addressEditCancelText be defined and edit on cancelAddress', () => {
      component.cancelAddress('mailing');
      expect(component.addressEditCancelText).toBeDefined();
      expect(component.addressEditCancelText).toBe('edit');
    });
    it('should call verifyEmailMobileService verifyPhone on verifyPhone', () => {
      const spy = spyOn(verifyEmailMobileService, 'verifyPhone');
      component.verifyPhone();
      expect(spy).toHaveBeenCalled();
    });
    it('should call verifyEmailMobileService verifyEmail on verifyEmail', () => {
      const spy = spyOn(verifyEmailMobileService, 'verifyEmail');
      component.verifyEmail();
      expect(spy).toHaveBeenCalled();
    });
    it('should editAddress be defined and Falsy on toggleVisibility', () => {
      component.toggleVisibility('EMAIL');
      expect(component.editAddress).toBeDefined();
      expect(component.editAddress).toBeFalsy();
    });
    it('should alertService clearError called on toggleVisibility', () => {
      component.toggleVisibility('EMAIL');
      expect(mockAlertService.clearError).toHaveBeenCalled();
    });
    it('should http showSpinnerLoading called on toggleVisibility', () => {
      component.toggleVisibility('EMAIL');
      expect(mockAuthHttpService.showSpinnerLoading).toHaveBeenCalled();
    });
    it('should editPhone be defined and Falsy on toggleVisibility', () => {
      component.toggleVisibility('EMAIL');
      expect(component.editPhone).toBeDefined();
      expect(component.editPhone).toBeFalsy();
    });
    it('should phoneEditCancelText and addressEditCancelText be defined and to be edit on toggleVisibility', () => {
      component.toggleVisibility('EMAIL');
      expect(component.phoneEditCancelText).toBeDefined();
      expect(component.phoneEditCancelText).toBe('edit');
      expect(component.addressEditCancelText).toBeDefined();
      expect(component.addressEditCancelText).toBe('edit');
    });
    it('should emailEditCancelText be defined and to be edit on toggleVisibility', () => {
      component.editEmail = true;
      component.toggleVisibility('EMAIL');
      expect(component.emailEditCancelText).toBeDefined();
      expect(component.emailEditCancelText).toBe('edit');
    });
    it('should emailEditCancelText be defined and to be cancel on toggleVisibility', () => {
      component.editEmail = false;
      component.toggleVisibility('EMAIL');
      expect(component.emailEditCancelText).toBeDefined();
      expect(component.emailEditCancelText).toBe('cancel');
    });

    it('should editEmail be defined and Falsy on toggleVisibility', () => {
      component.toggleVisibility('PHONE');
      expect(component.editEmail).toBeDefined();
      expect(component.editEmail).toBeFalsy();
    });
    it('should emailEditCancelText and addressEditCancelText be defined and to be edit on toggleVisibility', () => {
      component.toggleVisibility('PHONE');
      expect(component.emailEditCancelText).toBeDefined();
      expect(component.emailEditCancelText).toBe('edit');
      expect(component.addressEditCancelText).toBeDefined();
      expect(component.addressEditCancelText).toBe('edit');
    });
    it('should phoneEditCancelText be defined and to be edit on toggleVisibility', () => {
      component.editPhone = true;
      component.toggleVisibility('PHONE');
      expect(component.phoneEditCancelText).toBeDefined();
      expect(component.phoneEditCancelText).toBe('edit');
    });
    it('should phoneEditCancelText be defined and to be cancel on toggleVisibility', () => {
      component.editPhone = false;
      component.toggleVisibility('PHONE');
      expect(component.phoneEditCancelText).toBeDefined();
      expect(component.phoneEditCancelText).toBe('cancel');
    });
    it('should http hideSpinnerLoading called on toggleVisibility', () => {
      component.toggleVisibility('PHONE');
      expect(mockAuthHttpService.hideSpinnerLoading).toHaveBeenCalled();
    });
    it('should isUseridAPhone be defined on isWebMigrated', () => {
      component.isWebMigrated();
      expect(component.isUseridAPhone).toBeDefined();
    });
    it('should profile be defined on isWebMigrated', () => {
      component.isWebMigrated();
      expect(component.profile).toBeDefined();
    });
    it('should profile.phoneNumber be defined on isWebMigrated', () => {
      component.isWebMigrated();
      expect(component.profile.phoneNumber).toBeDefined();
    });
    it('should emailEditCancelText be defined and to be edit on cancelEdit', () => {
      component.cancelEdit('EMAIL');
      expect(component.emailEditCancelText).toBeDefined();
      expect(component.emailEditCancelText).toBe('edit');
    });
    it('should editEmail be defined and Falsy on cancelEdit', () => {
      component.cancelEdit('EMAIL');
      expect(component.editEmail).toBeDefined();
      expect(component.editEmail).toBeFalsy();
    });
    it('should phoneEditCancelText be defined and to be edit on cancelEdit', () => {
      component.cancelEdit('PHONE');
      expect(component.phoneEditCancelText).toBeDefined();
      expect(component.phoneEditCancelText).toBe('edit');
    });
    it('should editPhone be defined and Falsy on cancelEdit', () => {
      component.cancelEdit('PHONE');
      expect(component.editPhone).toBeDefined();
      expect(component.editPhone).toBeFalsy();
    });
    it('should call alertService clearError on ngOnDestroy', () => {
      component.ngOnDestroy();
      expect(mockAlertService.clearError).toHaveBeenCalled();
    });
    it('should call subject next and complete on ngOnDestroy', () => {
      const destroy = component.destroy$;
      const spyNext = spyOn(destroy, 'next');
      const spyComplete = spyOn(destroy, 'complete');
      component.ngOnDestroy();
      expect(spyNext).toHaveBeenCalled();
      expect(spyComplete).toHaveBeenCalled();
    });
    it('header contains text', () => {
      const element = document.querySelector('.header');
      expect(element).toBeTruthy();
      expect(element.textContent.length).toBeGreaterThan(0);
    });
  });
});
