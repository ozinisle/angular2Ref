import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatCardModule,
  MatDialogModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute, Router } from '@angular/router';
import { StorageServiceModule } from 'angular-webstorage-service';
import { TextMaskModule } from 'angular2-text-mask';
import { MaterialModule } from '../../../../../app/material.module';
import { NotificationPreferencesComponent } from '../../../../../app/pages/notification-preferences/notification-preferences.component';
import { NotificationPreferencesService } from '../../../../../app/pages/notification-preferences/notification-preferences.service';
import { PhoneNumberPipe } from '../../../../../app/shared/pipes/phone/phoneNumber.pipe';
import { AlertService, AuthService } from '../../../../../app/shared/shared.module';
import { mocks } from '../../../../constants/mocks.service';
import { notification_preferences_resolver_data } from '../../../../data/notification-preferences/notification-preferences.component.data';
import { FakeBreadcrumbsComponent } from '../../../../fake-components';
import { FakeRouterLinkDirectiveStub } from '../../../../fake-directives';

describe('OrderreplacementComponent', () => {
  let component: NotificationPreferencesComponent;
  let fixture: ComponentFixture<NotificationPreferencesComponent>;

  let mockAlertService;
  let mockNotificationPreferencesService;
  let mockActivatedRoute;
  let mockRouter;
  let mockAuthService;

  beforeEach(async(() => {
    mockAlertService = mocks.service.alertService;

    mockNotificationPreferencesService = mocks.service.notificationPreferencesService;
    mockActivatedRoute = {
      snapshot: {
        data: notification_preferences_resolver_data
      }
    };
    mockRouter = mocks.service.router;
    mockAuthService = mocks.service.authService;

    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        BrowserModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        StorageServiceModule,
        HttpClientTestingModule,
        TextMaskModule,
        MatFormFieldModule,
        MatRadioModule,
        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatDialogModule,
        MaterialModule
      ],
      declarations: [FakeRouterLinkDirectiveStub, FakeBreadcrumbsComponent, NotificationPreferencesComponent, PhoneNumberPipe],
      providers: [
        { provide: AuthService, useValue: mockAuthService },
        { provide: NotificationPreferencesService, useValue: mockNotificationPreferencesService },
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: Router, useValue: mockRouter },
        { provide: AlertService, useValue: mockAlertService }
      ]
    }).compileComponents();
  }));

  describe('Constructor', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(NotificationPreferencesComponent);
      component = fixture.componentInstance;
    });

    it('should create', () => {
      // assert
      expect(component).toBeTruthy();
    });

    describe('While Component Creation', () => {
      it('should do', () => {
        // assert
        pending();
      });
    });
  });

  describe('ngOnInit', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(NotificationPreferencesComponent);
      component = fixture.componentInstance;

      // act
      fixture.detectChanges();
    });
    it('should have loaded', () => {
      // assert
      expect(component).toBeTruthy();
    });
    describe('should have initialized', () => {
      it('should have initialized', () => {
        // assert
        pending();
      });
    });

    describe('should have called', () => {
      it('should have called', () => {
        // assert
        pending();
      });
    });
  });
});
