import { AsyncPipe, CommonModule } from '@angular/common';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CostShareComponent } from '../../../../../app/pages/cost-share/cost-share.component';
import { CostShareModule } from '../../../../../app/pages/cost-share/cost-share.module';
import { MyplansService } from '../../../../../app/pages/myplans/myplans.service';
import { AuthHttp } from '../../../../../app/shared/services/auth-http.service';
import { ConstantsService } from '../../../../../app/shared/shared.module';
import { mocks } from '../../../../constants/mocks.service';


describe('CostShareComponent', () => {
  let component: CostShareComponent;
  let fixture: ComponentFixture<CostShareComponent>;

  let mockAuthHttp;
  let mockConstantsService;
  let mockPlanDataService;

  beforeEach(async(() => {
    mockConstantsService = mocks.service.constantsService;
    mockAuthHttp = mocks.service.authHttp;
    mockPlanDataService = mocks.service.planService;
    
    TestBed.configureTestingModule({
      imports: [CostShareModule, CommonModule],
      providers: [
        AsyncPipe,
        { provide: AuthHttp, useValue: mockAuthHttp },
        { provide: ConstantsService, useValue: mockConstantsService },
        { provide: MyplansService, useValue: mockPlanDataService }
      ]
    });

    fixture = TestBed.createComponent(CostShareComponent);
    component = fixture.componentInstance;
  }));

  describe('constructor', () => {
    beforeEach(() => {
      fixture.detectChanges();
    });

    it('should create', () => {
      expect(component).toBeTruthy();
    });

    it('should exist', () => {
      expect(component).toBeDefined();
    });
  });

  describe('ngOnInit', () => {
    it('should call the ngOnInit', () => {
      spyOn(component, 'ngOnInit');
      fixture.detectChanges();
      expect(component.ngOnInit).toHaveBeenCalled();
    });
        
  });

  
});
