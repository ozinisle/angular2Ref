
import { DatePipe, Location } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';
import { MatCheckboxModule } from '@angular/material';
import { PhonePipe } from '../../../../../../app/shared/pipes/phone/phone.pipe';
import {
    FakeAlertsComponent, FakeBreadcrumbsComponent,
    FakeProfileEmailComponent, FakeProfilePhoneComponent } from '../../../../../fake-components';

import { ActivatedRoute, Router } from '@angular/router';
import {
    CommunicationPreferenceComponent
} from '../../../../../../app/pages/my-profile/communication-preference/communication-preference.component';
import { AuthHttp } from '../../../../../../app/shared/services/auth-http.service';
import { GlobalService } from '../../../../../../app/shared/services/global.service';
import { ProfileService } from '../../../../../../app/shared/services/myprofile/profile.service';
import { AlertService, AuthService, ConstantsService } from '../../../../../../app/shared/shared.module';
import { mocks } from '../../../../../constants/mocks.service';
import { jasAVUserData } from '../../../../../data/my-profile/avUser.data';
import { ProfileSelectPreferenceModule } from '../../../../../../app/components/profile-select-preference/profile-select-preference.module';
import { PreferencesService } from '../../../../../../app/shared/services/myprofile/preferences.service';
import { VerifyEmailMobileService } from '../../../../../../app/components/verify-email-mobile/verify-email-mobile.service';
import { async } from 'q';

describe('CommunicationPreferenceComponent', () => {
    let component: CommunicationPreferenceComponent;
    let fixture: ComponentFixture<CommunicationPreferenceComponent>;

    let mockAlertService;
    let mockConstantsService;
    let mockGlobalService;
    let mockRouter;
    let mockActivatedRoute;
    let mockProfileService;
    let mockPreferenceService;
    let mockAuthService;
    let mockAuthHttp;
    let mockLocation;
    let mockVerifyEmailMobileService;

    beforeEach(async() => {
        mockActivatedRoute = {
            snapshot: {
                data: {
                    profile: jasAVUserData.getMemProfileApiResponse,
                    preferences: {
                        message: jasAVUserData.getPreferences
                    }
                }
            }
        };

        mockLocation = {
            assign: (url: string) => url,
            reload: (forcedReload?: boolean) => true,
            replace: (url: string) => url,
            path: () => 'url-path',
            back: () => (back?: boolean) => true,
        };

        mockAlertService = mocks.service.alertService;
        mockGlobalService = mocks.service.globalService;
        mockConstantsService = mocks.service.constantsService;
        mockProfileService = mocks.service.profileService;
        mockPreferenceService = mocks.service.preferenceService;
        mockRouter = mocks.service.router;
        mockAuthService = mocks.service.authService;
        mockAuthHttp = mocks.service.authHttp;
        mockVerifyEmailMobileService = mocks.service.verifyEmailMobileService;

        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule,
                MatCheckboxModule,
                ProfileSelectPreferenceModule
            ],
            providers: [
                DatePipe,
                { provide: AlertService, useValue: mockAlertService },
                { provide: GlobalService, useValue: mockGlobalService },
                { provide: ConstantsService, useValue: mockConstantsService },
                { provide: Router, useValue: mockRouter },
                { provide: ActivatedRoute, useValue: mockActivatedRoute },
                { provide: ProfileService, useValue: mockProfileService },
                { provide: PreferencesService, useValue : mockPreferenceService },
                { provide: VerifyEmailMobileService, useValue : mockVerifyEmailMobileService },
                { provide: AuthService, useValue: mockAuthService },
                { provide: AuthHttp, useValue: mockAuthHttp },
                { provide: Location, useValue: mockLocation },
            ],
            declarations: [
                CommunicationPreferenceComponent,
                FakeBreadcrumbsComponent,
                FakeAlertsComponent,
                FakeProfileEmailComponent,
                FakeProfilePhoneComponent,
                PhonePipe
            ],
        });

        fixture = TestBed.createComponent(CommunicationPreferenceComponent);
        component = fixture.componentInstance;
        spyOn(component, 'handleInputData');
    });

    describe('constructor', () => {
        it('should exists', () => {
            expect(component).toBeDefined();
        });
        it('should call the getConsent from preferenceService', () => {
            fixture.detectChanges();
            component.getConsent();
            expect(mockPreferenceService.getConsent).toHaveBeenCalled();
        });
        it('should assign value to this.getConsentRes', fakeAsync(() => {
            fixture.detectChanges();
            tick(1000);
            expect(component.consentDetails).toEqual(jasAVUserData.getConsentData);
        }));
        it('should call the getconsentDrupal from authhttpService', () => {
            fixture.detectChanges();
            component.getDrupalConsent();
            expect(mockAuthHttp.get).toHaveBeenCalled();
        });
        it('should assign value to this.profile', () => {
            fixture.detectChanges();

            expect(component.profile).toEqual(jasAVUserData.getMemProfile_After_NgOnint);
        });
        it('should assign value to this.preferences', () => {
            fixture.detectChanges();

            expect(component.preferences).toEqual(jasAVUserData.getPreferences);
        });
        it('should call the getProgramGroups from globalService', () => {
            fixture.detectChanges();

            expect(mockPreferenceService.getProgramGroups).toHaveBeenCalled();
        });
        it('should assign value to this.programGroupsObj', () => {
            fixture.detectChanges();

            expect(component.programGroupsObj).toEqual(jasAVUserData.getProgramGroups.message);
        });
        it('should call the handleInputData from component', () => {
            spyOn(CommunicationPreferenceComponent.prototype, 'handleInputData');

            fixture = TestBed.createComponent(CommunicationPreferenceComponent);
            component = fixture.componentInstance;

            fixture.detectChanges();

            expect(component.handleInputData).toHaveBeenCalled();
        });
    });

    describe('ngOnInit', () => {
        it('should call the ngOnInit', () => {
            spyOn(component, 'ngOnInit');
            fixture.detectChanges();

            expect(component.ngOnInit).toHaveBeenCalled();
        });
    });

    describe('submitPreference', () => {
        beforeEach(() => {
            spyOn(sessionStorage.__proto__, 'getItem').and.returnValue(JSON.stringify(jasAVUserData.getMemProfile_After_NgOnint));
        });

        it('should call the verifyPhone from profileService, if this.profile.isVerifiedMobile is false', () => {

            component.profile.isVerifiedMobile = false;
            component.profile.isVerifiedEmail = true;
            fixture.detectChanges();

            component.submitPreference();

            expect(mockVerifyEmailMobileService.verifyPhone).toHaveBeenCalled();
        });
        it('should call the verifyEmail from profileService, if this.profile.isVerifiedEmail is false', () => {

            component.profile.isVerifiedMobile = true;
            component.profile.isVerifiedEmail = false;
            fixture.detectChanges();

            component.submitPreference();

            expect(mockVerifyEmailMobileService.verifyEmail).toHaveBeenCalled();
        });
        it('should call the verifyPhone and set session storage, if isVerifiedMobile and isVerifiedEmail is false', () => {

            spyOn(sessionStorage.__proto__, 'setItem');
            component.profile.isVerifiedMobile = false;
            component.profile.isVerifiedEmail = false;
            fixture.detectChanges();

            component.submitPreference();

            expect(sessionStorage.__proto__.setItem).toHaveBeenCalled();
        });
        it('should call updatePreferenceInfo, if email and mobile are verified', () => {
            component.profile.isVerifiedEmail = true;
            component.profile.isVerifiedMobile = true;
            fixture.detectChanges();

            component.submitPreference();

            expect(mockPreferenceService.updatePreferenceInfo).toHaveBeenCalled();
        });
    });
});
