// // import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// // import { ImpersonationComponent } from './impersonation.component';
// // // import { mocks } from '../../../../src/jasmine/constants/mock.service';
// // import { BrowserModule } from '@angular/platform-browser';
// // import { CommonModule } from '@angular/common';
// // import { NO_ERRORS_SCHEMA } from '@angular/core';
// // import { GlobalService } from '../../shared/services/global.service';
// // import { AlertService, ConstantsService } from '../../shared/shared.module';
// // import { Router, ActivatedRoute } from '@angular/router';
// // import { ImpersonationService } from './impersonation.service';
// // import { FormBuilder } from '@angular/forms';
// // // import { HttpClientTestingModule } from '@angular/common/http/testing';
// // // import { ImpersonationService } from './impersonation.service';

// // describe('ImpersonationComponent', () => {
// //   let component: ImpersonationComponent;
// //   let fixture: ComponentFixture<ImpersonationComponent>;
// //   let mockRouter;
// //   let mockActivatedRoute;
// //   let mockAlertService;
// //   let mockConstantsService;
// //   let mockGlobalService;
// //   let mockImpersonationService;
// //   let formBuilder: FormBuilder;

// //   beforeEach(async(() => {
// //     mockRouter = jasmine.createSpyObj(['navigate']);
// //     mockAlertService = jasmine.createSpyObj(['clearError']);
// //     mockGlobalService = jasmine.createSpyObj(['setAdobe']);
// //     mockConstantsService ={};
// //     mockActivatedRoute = {
// //       snapshot: {
// //         data: {
// //         }
// //       }
// //     };
// //     mockImpersonationService = jasmine.createSpyObj(['decryptData', 'impersonation']);

// //     TestBed.configureTestingModule({
// //       imports:[ BrowserModule,
// //         CommonModule],

// //       declarations: [ ImpersonationComponent ],
// //       schemas: [NO_ERRORS_SCHEMA],
// //       providers: [
// //         { provide: GlobalService, useValue: mockGlobalService },
// //         { provide: AlertService, useValue: mockAlertService },
// //         { provide: ConstantsService, useValue: mockConstantsService },
// //         { provide: Router, useValue: mockRouter },
// //         { provide: FormBuilder, useValue: formBuilder },
// //         { provide: ImpersonationService, useValue: mockImpersonationService },
// //         { provide: ActivatedRoute, useValue: mockActivatedRoute },
// //       ]

// //     })
// //     .compileComponents();
// //   }));

// //   beforeEach(() => {
// //     fixture = TestBed.createComponent(ImpersonationComponent);
// //     component = fixture.componentInstance;
// //     //component.forgotUsernameForm = formBuilder.group({
// //       // email: null,
// //       // mobile: null
// //     //  });
// //     //fixture.detectChanges();

// //   });

// //   it('should create', () => {
// //     expect(component).toBeTruthy();
// //   });
// // });
