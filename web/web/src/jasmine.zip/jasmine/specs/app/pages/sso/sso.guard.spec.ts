import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { SsoGuard } from '../../../../../app/pages/sso/sso.guard';
import { MockRouter } from '../../../../mock-classes/mock-router.class';

describe('SsoGuard', () => {
  describe('canActivate', () => {
    let guard: SsoGuard;
    let router;

    beforeEach(() => {
      router = new MockRouter();
      guard = new SsoGuard(router);
    });

    it('should return true for a logged in user', () => {
      // arrange
      const next = {
        parent: {
          routeConfig: { path: '' }
        }
      } as ActivatedRouteSnapshot;

      spyOn(guard, 'isUserAuthenticated').and.returnValue(true);
      spyOn(guard, 'isUserNotAuthenticatedAndVerified').and.returnValue(false);

      // act
      const result = guard.canActivate(next, {} as RouterStateSnapshot);

      // assert
      expect(result).toBeTruthy();
    });
    it('should return false for a anonymous user', () => {
      // arrange
      const next = {
        parent: {
          routeConfig: { path: '' }
        }
      } as ActivatedRouteSnapshot;

      spyOn(guard, 'isUserAuthenticated').and.returnValue(false);
      spyOn(guard, 'isUserNotAuthenticatedAndVerified').and.returnValue(true);

      // act
      const result = guard.canActivate(next, {} as RouterStateSnapshot);

      // assert
      expect(result).toBeFalsy();
    });

    it('should redirect to homepage for anonymous user when navigated from "sso/alegeus"', () => {
      // arrange
      const next = {
        parent: {
          routeConfig: { path: 'sso/alegeus' }
        }
      } as ActivatedRouteSnapshot;

      spyOn(guard, 'isUserAuthenticated').and.returnValue(true);
      spyOn(guard, 'isUserNotAuthenticatedAndVerified').and.returnValue(true);
      spyOn(window, 'open').and.returnValue(null);
      // act
      guard.canActivate(next, {} as RouterStateSnapshot);

      // assert
      expect(window.open).toHaveBeenCalledWith('/home', '_self');
    });

    it('should have called this.isUserNotAuthenticatedAndVerified', () => {
      // arrange
      const next = {
        parent: {
          routeConfig: { path: '' }
        }
      } as ActivatedRouteSnapshot;

      spyOn(guard, 'isUserAuthenticated').and.returnValue(true);
      spyOn(guard, 'isUserNotAuthenticatedAndVerified').and.returnValue(false);

      // act
      guard.canActivate(next, {} as RouterStateSnapshot);

      // assert
      expect(guard.isUserNotAuthenticatedAndVerified).toHaveBeenCalled();
    });
  });
});
