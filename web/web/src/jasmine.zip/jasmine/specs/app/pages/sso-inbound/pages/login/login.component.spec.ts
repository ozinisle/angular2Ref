import { Location } from '@angular/common';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { LoginComponent } from '../../../../../../../app/pages/sso-inbound/pages/login/login.component';
import { SsoInboundService } from '../../../../../../../app/pages/sso-inbound/service/sso-inbound.service';
import { SsoInboundModule } from '../../../../../../../app/pages/sso-inbound/sso-inbound.module';
import { ROUTER } from '../../../../../../../app/pages/sso-inbound/sso-inbound.routing';
import { AuthHttp } from '../../../../../../../app/shared/services/auth-http.service';
import { GlobalService } from '../../../../../../../app/shared/services/global.service';
import { AlertService, AuthService, ConstantsService, ValidationService } from '../../../../../../../app/shared/shared.module';
import { mocks } from '../../../../../../constants/mocks.service';


xdescribe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(async(() => {
    let router: Router;
    let location: Location;
    const mockActivatedRoute = {
      queryParams: { map: () => {} }
    };

    TestBed.configureTestingModule({
      imports: [RouterTestingModule.withRoutes(ROUTER), SsoInboundModule],
      declarations: [],
      providers: [
        { provide: GlobalService, useValue: mocks.service.globalService },
        { provide: ValidationService, useValue: mocks.service.validationService },
        { provide: Router, useValue: mocks.service.router },
        { provide: SsoInboundService, useValue: mocks.service.ssoInboundService },
        ConstantsService,
        { provide: AuthHttp, useValue: mocks.service.authHttp },
        { provide: AlertService, useValue: mocks.service.alertService },
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: AuthService, useValue: mocks.service.authService }
      ]
    }).compileComponents();

    router = TestBed.get(Router);
    location = TestBed.get(Location) as Location;
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
