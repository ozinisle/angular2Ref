import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AddOtcComponent } from '../../../../../../app/pages/my-pillpack/add-otc/add-otc.component';

describe('AddOtcComponent', () => {
  let component: AddOtcComponent;
  let fixture: ComponentFixture<AddOtcComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AddOtcComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddOtcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
