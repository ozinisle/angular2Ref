// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { ForgotUsernameComponent } from './forgot-username.component';
// import { NO_ERRORS_SCHEMA } from '@angular/core';
// import { FormBuilder, FormsModule, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
// import { BrowserModule } from '@angular/platform-browser';
// import { CommonModule } from '@angular/common';
// import { HttpClientTestingModule } from '@angular/common/http/testing';
// import { TextMaskModule } from 'angular2-text-mask';
// import { MatFormFieldModule, MatRadioModule, MatSelectModule, MatCardModule, MatIconModule, MatSidenavModule, MatTooltipModule, MatGridListModule, MatDialogModule, MatInputModule } from '@angular/material';
// import { MaterialModule } from '../../../material.module';
// import { MyAccountService } from '../my-account.service';
// import { GlobalService } from '../../../shared/services/global.service';
// import { AuthHttp } from '../../../shared/services/authHttp.service';
// import { AlertService, ValidationService, ConstantsService, AuthService } from '../../../shared/shared.module';
// import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
// import { Router } from '@angular/router';

// describe('ForgotUsernameComponent -  Security project', () => {
//   let component: ForgotUsernameComponent;
//   let fixture: ComponentFixture<ForgotUsernameComponent>;
//   let mockRouter;
//   let mockAuthHttp;
//   let mockAlertService;
//   let mockValidationService;
//   let mockConstantsService;
//   let mockGlobalService;
//   let mockMyAccountService;
//   let mockBcbsmaerrorHandlerService;
//   let mockAuthService;
//   let formBuilder: FormBuilder;

//   beforeEach(async(() => {
//     mockRouter = [];
//     mockAuthHttp = jasmine.createSpyObj(['handleError']);
//     mockMyAccountService = jasmine.createSpyObj(['verifyUserValid']);
//     mockBcbsmaerrorHandlerService = jasmine.createSpyObj(['logError','handleHttpError']);
//     mockAuthService = jasmine.createSpyObj(['getTokens','persistSession']);
//     mockAlertService = jasmine.createSpyObj(['clearError', 'setAlert']);
//     mockValidationService =jasmine.createSpyObj(['emailValidator','phoneValidator','mobileValidator','phoneMask']);
//     mockConstantsService ={};
//     formBuilder = new FormBuilder();

//     TestBed.configureTestingModule({
//       imports:[ BrowserModule,
//         CommonModule,
//         FormsModule,
//         ReactiveFormsModule,
//         HttpClientTestingModule,
//         TextMaskModule,
//         MatFormFieldModule,
//         MatRadioModule,
//         MatSelectModule,
//         MatCardModule,
//         MatIconModule,
//         MatSidenavModule,
//         MatTooltipModule,
//         MatGridListModule,
//         MatInputModule,
//         MatDialogModule,
//         MaterialModule],
//       declarations: [ ForgotUsernameComponent ],
//       schemas: [NO_ERRORS_SCHEMA],
//       providers: [
//         { provide: MyAccountService, useValue: mockMyAccountService },
//         { provide: GlobalService, useValue: mockGlobalService },
//         { provide: AuthHttp, useValue: mockAuthHttp },
//         { provide: AlertService, useValue: mockAlertService },
//         { provide: AuthService, useValue: mockAuthService },
//         { provide: ValidationService, useValue: mockValidationService },
//         { provide: ConstantsService, useValue: mockConstantsService },
//         { provide: BcbsmaerrorHandlerService, useValue: mockBcbsmaerrorHandlerService },
//         { provide: Router, useValue: mockRouter },
//         { provide: FormBuilder, useValue: formBuilder }
//       ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(ForgotUsernameComponent);
//     component = fixture.componentInstance;
//     component.forgotUsernameForm = formBuilder.group({
//       email: null,
//       mobile: null
//      });
//     fixture.detectChanges();

//     //security fixes - analysis
//       //0. submit -> getToken -> verifyIsUserValid ->
//       //0.1. handleVerificationResponse -> handleSuccessResponse -> "/account/confirmidentity"
//       //0.2. handleNonAuthenticatedUserResponse -> "/account/verifyAccessCode"
//       // 1. In any case, When user clicks on submit; route to /account/verifyAccessCode
//       // 2. submit must call verifyIsUserValid
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });

//   it('should verified user routed to /account/verifyAccessCode submit',()=>{
//     //before dev: should fail
//     //after dev: should pass
//     expect(true).toBeTruthy();
//   });

//   it('should not verified user routed to /account/verifyAccessCode on submit',()=>{
//     expect(true).toBeTruthy();
//   });

// });
