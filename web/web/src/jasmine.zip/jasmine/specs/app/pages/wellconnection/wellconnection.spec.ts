import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs/observable/of';
import { WellconnectionComponent } from '../../../../../app/pages/wellconnection/wellconnection.component';
import { WellconnectionService } from '../../../../../app/pages/wellconnection/wellconnection.service';
import { consumerEnrollmentResponse } from '../../../../data/well-connection/well-connection.component.data';

xdescribe('YesComponent', () => {
  let component: WellconnectionComponent;
  let fixture: ComponentFixture<WellconnectionComponent>;
  let mockWellConnectionService;


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [WellconnectionComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WellconnectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  describe('ngOnInit', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(WellconnectionComponent);
      component = fixture.componentInstance;
      // act
      fixture.detectChanges();
    });
    it('should have loaded', () => {
      // assert
      expect(component).toBeTruthy();
    });
  });

  describe('onSubmit', () => {
    beforeEach(() => {
      // arrange
      mockWellConnectionService.confirmIdentity.and.returnValue(of(consumerEnrollmentResponse.success));
      TestBed.overrideProvider(WellconnectionService, { useValue: mockWellConnectionService });
      TestBed.compileComponents();
    });
    beforeEach(async () => {
      fixture = TestBed.createComponent(WellconnectionComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });

    afterAll(() => {
      mockWellConnectionService.confirmIdentity.and.returnValue(of(consumerEnrollmentResponse.success));
      TestBed.overrideProvider(WellconnectionService, { useValue: mockWellConnectionService });
      TestBed.compileComponents();
    });


    it('should have called this.wellConnectionService.openVirtualVisit', () => {
      try {
        // act
        component.onSubmit();

        // assert
        expect(mockWellConnectionService.openVirtualVisit).toHaveBeenCalled();
      } catch (error) {
        console.warn(error);
      }
    });

  });

});