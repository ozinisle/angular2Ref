import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatCardModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatListModule,
  MatNativeDateModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute, Router } from '@angular/router';
import { StorageServiceModule } from 'angular-webstorage-service';
import { TextMaskModule } from 'angular2-text-mask';
import { MaterialModule } from '../../../../../../app/material.module';
import { RequestEstimateComponent } from '../../../../../../app/pages/request-estimate/landing/request-estimate.component';
import { RequestEstimateService } from '../../../../../../app/pages/request-estimate/request-estimate.service';
import { CamelcasePipe } from '../../../../../../app/shared/pipes/camelcase/camelcase.pipe';
import { FpocontentService } from '../../../../../../app/shared/services/fpocontent.service';
import { ProfileService } from '../../../../../../app/shared/services/myprofile/profile.service';
import { AlertService, AuthService, ConstantsService, ValidationService } from '../../../../../../app/shared/shared.module';
import { mocks } from '../../../../../constants/mocks.service';
import { request_estimate_resolver_data } from '../../../../../data/request-estimate/request-estimate.component.data';
import {
  FakeAlertsComponent,
  FakeBreadcrumbsComponent,
  FakeControlMessagesComponent,
  FakeFpoLayoutComponent
} from '../../../../../fake-components';
import { FakeParentFormFieldDirectiveStub } from '../../../../../fake-directives';

describe('RequestEstimateComponent', () => {
  let component: RequestEstimateComponent;
  let fixture: ComponentFixture<RequestEstimateComponent>;

  // create new instance of FormBuilder
  const formBuilder: FormBuilder = new FormBuilder();

  let mockRouter;
  let mockActivatedRoute;
  let mockAuthService;
  let mockAlertService;
  let mockValidationService;
  let mockProfileService;
  let mockConstantsService;
  let mockFpocontentService;
  let mockRequestEstimateService;

  beforeEach(async(() => {
    mockRouter = mocks.service.router;
    mockActivatedRoute = {
      snapshot: {
        data: request_estimate_resolver_data
      }
    };
    mockAuthService = mocks.service.authService;
    mockAlertService = mocks.service.alertService;
    mockValidationService = mocks.service.validationService;
    mockProfileService = mocks.service.profileService;
    mockConstantsService = mocks.service.constantsService;
    mockFpocontentService = mocks.service.fpocontentService;
    mockRequestEstimateService = mocks.service.requestEstimateService;

    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        BrowserModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        StorageServiceModule,
        HttpClientTestingModule,
        TextMaskModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatFormFieldModule,
        MatRadioModule,
        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatDialogModule,
        MatExpansionModule,
        MatListModule,
        MatButtonModule,
        MaterialModule
      ],
      declarations: [
        FakeBreadcrumbsComponent,
        FakeAlertsComponent,
        FakeControlMessagesComponent,
        FakeFpoLayoutComponent,
        FakeParentFormFieldDirectiveStub,
        CamelcasePipe,
        RequestEstimateComponent
      ],
      providers: [
        { provide: FormBuilder, useValue: formBuilder },
        { provide: Router, useValue: mockRouter },
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: AuthService, useValue: mockAuthService },
        { provide: AlertService, useValue: mockAlertService },
        { provide: ValidationService, useValue: mockValidationService },
        { provide: ProfileService, useValue: mockProfileService },
        { provide: ConstantsService, useValue: mockConstantsService },
        { provide: FpocontentService, useValue: mockFpocontentService },
        { provide: RequestEstimateService, useValue: mockRequestEstimateService }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestEstimateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  describe('Constructor', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(RequestEstimateComponent);
      component = fixture.componentInstance;
    });
    it('should create', () => {
      // assert
      expect(component).toBeTruthy();
    });
    describe('While Component Creation', () => {
      it('should do', () => {
        // assert
        pending();
      });
    });
  });
  describe('ngOnInit', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(RequestEstimateComponent);
      component = fixture.componentInstance;
      // act
      fixture.detectChanges();
    });
    it('should have loaded', () => {
      // assert
      expect(component).toBeTruthy();
    });
    describe('should have initialized', () => {
      it('should have initialized', () => {
        // assert
        pending();
      });
    });
    describe('should have called', () => {
      it('should have called', () => {
        // assert
        pending();
      });
    });
  });
});
