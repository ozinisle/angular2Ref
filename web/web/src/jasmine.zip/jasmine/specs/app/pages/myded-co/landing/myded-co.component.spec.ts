import { CommonModule, TitleCasePipe } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatCardModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatListModule,
  MatNativeDateModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute } from '@angular/router';
import { StorageServiceModule } from 'angular-webstorage-service';
import { MaterialModule } from '../../../../../../app/material.module';
import { MyDedCoComponent } from '../../../../../../app/pages/myded-co/landing/myded-co.component';
import { MyDedCoService } from '../../../../../../app/pages/myded-co/myded-co.service';
import { YyyymmddTommddyyyyPipe } from '../../../../../../app/shared/pipes/date/yyyymmdd-to-mmddyyyy.pipe';
import { FpocontentService } from '../../../../../../app/shared/services/fpocontent.service';
import { AlertService, AuthService, ConstantsService } from '../../../../../../app/shared/shared.module';
import { mocks } from '../../../../../constants/mocks.service';
import { myded_co_component_resolver_data } from '../../../../../data/myded-co/myded-co.component.data';
import {
  FakeBreadcrumbsComponent,
  FakeDedcoFilterComponent,
  FakeFpoLayoutComponent,
  FakeLineChartComponent
} from '../../../../../fake-components';
import { FakeRouterLinkDirectiveStub } from '../../../../../fake-directives';

describe('MyDedCoComponent', () => {
  let component: MyDedCoComponent;
  let fixture: ComponentFixture<MyDedCoComponent>;

  let mockMyDedCoService;
  let mockAuthService;
  let mockActivatedRoute;
  let mockAlertService;
  let mockConstantsService;
  let mockFpocontentService;

  beforeEach(async(() => {
    mockMyDedCoService = mocks.service.myDedCoService;
    mockAuthService = mocks.service.authService;
    mockActivatedRoute = mockActivatedRoute = {
      snapshot: {
        data: myded_co_component_resolver_data
      }
    };
    mockAlertService = mocks.service.alertService;
    mockConstantsService = mocks.service.constantsService;
    mockFpocontentService = mocks.service.fpocontentService;

    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        StorageServiceModule,
        HttpClientTestingModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatFormFieldModule,
        MatRadioModule,
        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatDialogModule,
        MatExpansionModule,
        MatListModule,
        MatButtonModule,
        MaterialModule
      ],

      declarations: [
        FakeBreadcrumbsComponent,
        FakeDedcoFilterComponent,
        FakeLineChartComponent,
        FakeFpoLayoutComponent,
        FakeRouterLinkDirectiveStub,
        YyyymmddTommddyyyyPipe,
        MyDedCoComponent
      ],

      providers: [
        { provide: MyDedCoService, useValue: mockMyDedCoService },
        { provide: AuthService, useValue: mockAuthService },
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: AlertService, useValue: mockAlertService },
        { provide: ConstantsService, useValue: mockConstantsService },
        { provide: FpocontentService, useValue: mockFpocontentService },
        TitleCasePipe
      ]
    }).compileComponents();
  }));

  describe('Constructor', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(MyDedCoComponent);
      component = fixture.componentInstance;
    });
    it('should create', () => {
      // assert
      expect(component).toBeTruthy();
    });
    describe('While Component Creation', () => {
      it('should do', () => {
        // assert
        pending();
      });
    });
  });
  describe('ngOnInit', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(MyDedCoComponent);
      component = fixture.componentInstance;
      // act
      fixture.detectChanges();
    });
    it('should have loaded', () => {
      // assert
      expect(component).toBeTruthy();
    });
    describe('should have initialized', () => {
      it('should have initialized', () => {
        // assert
        pending();
      });
    });
    describe('should have called', () => {
      it('should have called', () => {
        // assert
        pending();
      });
    });
  });
});
