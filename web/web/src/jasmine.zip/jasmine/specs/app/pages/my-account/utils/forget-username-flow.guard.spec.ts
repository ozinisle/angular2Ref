import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { ForgetUserNameFlowGuard } from '../../../../../../app/pages/my-account/utils/forget-username-flow.guard';
import { MockRouter } from '../../../../../mock-classes/mock-router.class';

describe('ForgetUserNameFlowGuard', () => {
  describe('canActivate', () => {
    let guard: ForgetUserNameFlowGuard;
    let router;

    beforeEach(() => {
      router = new MockRouter();
      guard = new ForgetUserNameFlowGuard(router);
    });

    it('should call the sessionStorage.getItem', () => {
      // arrange
      const next = {
        parent: {
          routeConfig: { path: '' }
        }
      } as ActivatedRouteSnapshot;

      // act
      const isVerifiedAuthandWeb = spyOn(sessionStorage.__proto__, 'getItem');
      const result = guard.canActivate(next, {} as RouterStateSnapshot);

      // assert
      expect(isVerifiedAuthandWeb).toHaveBeenCalledTimes(1);
    });

    it('should return true if isVerifiedAuth && isVerifiedAuth  === TRUE', () => {
      // arrange
      const next = {
        parent: {
          routeConfig: { path: '' }
        }
      } as ActivatedRouteSnapshot;

      // act
      const isVerifiedAuth = spyOn(sessionStorage.__proto__, 'getItem').and.returnValue('TRUE');
      guard.canActivate(next, {} as RouterStateSnapshot);

      // assert
      expect(isVerifiedAuth).toBeTruthy();
    });

    it('should return true if isVerifiedWeb && isVerifiedWeb  === FALSE ', () => {
      // arrange
      const next = {
        parent: {
          routeConfig: { path: '' }
        }
      } as ActivatedRouteSnapshot;

      // act

      const isVerifiedWeb = spyOn(sessionStorage.__proto__, 'getItem').and.returnValue('FALSE');
      guard.canActivate(next, {} as RouterStateSnapshot);

      // assert
      expect(isVerifiedWeb).toBeTruthy();
    });

    it('should redirect to login page if isVerifiedAuth && isVerifiedAuth  === FALSE and isVerifiedWeb && isVerifiedWeb  === TRUE', () => {
      // arrange

      const next = {
        parent: {
          routeConfig: { path: 'login' }
        }
      } as ActivatedRouteSnapshot;

      spyOn(sessionStorage.__proto__, 'clear');
      spyOn(router, 'navigate');

      // act

      const isVerifiedAuth = spyOn(sessionStorage.__proto__, 'getItem').and.returnValue('FALSE');
      guard.canActivate(next, {} as RouterStateSnapshot);

      // assert
      expect(router.navigate).toHaveBeenCalledWith(['login']);
    });

    it('should clear the sessionStorage if isVerifiedAuth && isVerifiedAuth  === FALSE and isVerifiedWeb && isVerifiedWeb  === TRUE', () => {
      // arrange
      const next = {
        parent: {
          routeConfig: { path: '' }
        }
      } as ActivatedRouteSnapshot;
      spyOn(router, 'navigate');
      spyOn(sessionStorage.__proto__, 'clear');

      // act

      const isVerifiedAuth = spyOn(sessionStorage.__proto__, 'getItem').and.returnValue('FALSE');
      guard.canActivate(next, {} as RouterStateSnapshot);

      // assert
      expect(sessionStorage.__proto__.clear).toHaveBeenCalled();
    });
  });
});
