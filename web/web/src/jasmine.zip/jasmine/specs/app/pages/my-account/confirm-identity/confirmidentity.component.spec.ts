import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatCardModule,
  MatDialogModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { StorageServiceModule } from 'angular-webstorage-service';
import { TextMaskModule } from 'angular2-text-mask';
import * as deepEqual from 'deep-equal';
import { of } from 'rxjs/observable/of';
import { MaterialModule } from '../../../../../../app/material.module';
import { ConfirmidentityComponent } from '../../../../../../app/pages/my-account/confirm-identity/confirmidentity.component';
import { MyAccountConstants } from '../../../../../../app/pages/my-account/my-account.constants';
import { MyAccountService } from '../../../../../../app/pages/my-account/my-account.service';
import { AlertType } from '../../../../../../app/shared/alerts/alertType.model';
import { BcbsmaerrorHandlerService } from '../../../../../../app/shared/services/bcbsmaerror-handler.service';
import { GlobalService } from '../../../../../../app/shared/services/global.service';
import { AlertService, ValidationService } from '../../../../../../app/shared/shared.module';
import { ConstantsService } from '../../../../../../app/shared/shared.module';
import { mocks } from '../../../../../constants/mocks.service';
import { verifyfunauthuser_response } from '../../../../../data/my-account/confirm-identity/verifyfunauthuser.data';
import { FakeControlMessagesComponent } from '../../../../../fake-components';

describe('ConfirmidentityComponent', () => {
  let component: ConfirmidentityComponent;
  let fixture: ComponentFixture<ConfirmidentityComponent>;

  const formBuilder: FormBuilder = new FormBuilder();
  let mockMyAccountService;
  let mockRouter;
  let mockGlobalService;
  let mockConstantsService;
  let mockAlertService;
  let mockValidationService;
  let mockBcbsmaerrorHandlerService;

  beforeEach(async(() => {
    mockMyAccountService = mocks.service.myAccountService;
    mockAlertService = mocks.service.alertService;
    mockRouter = mocks.service.router;
    mockValidationService = mocks.service.validationService;
    mockBcbsmaerrorHandlerService = mocks.service.bcbsmaerrorHandlerService;
    mockGlobalService = mocks.service.globalService;
    mockConstantsService = mocks.service.constantsService;

    TestBed.configureTestingModule({
      imports: [
        BrowserModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        StorageServiceModule,
        HttpClientTestingModule,
        TextMaskModule,
        MatFormFieldModule,
        MatRadioModule,
        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatDialogModule,
        MaterialModule
      ],

      declarations: [FakeControlMessagesComponent, ConfirmidentityComponent],

      providers: [
        { provide: FormBuilder, useValue: formBuilder },
        { provide: MyAccountService, useValue: mockMyAccountService },
        { provide: AlertService, useValue: mockAlertService },
        { provide: ConstantsService, useValue: mockConstantsService },
        { provide: Router, useValue: mockRouter },
        { provide: ValidationService, useValue: mockValidationService },
        { provide: BcbsmaerrorHandlerService, useValue: mockBcbsmaerrorHandlerService },
        { provide: GlobalService, useValue: mockGlobalService }
      ]
    }).compileComponents();
  }));

  describe('Constructor', () => {
    it('should have been created', () => {
      try {
        // arrange
        fixture = TestBed.createComponent(ConfirmidentityComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(component).toBeTruthy();
      } catch (error) {
        console.warn(error);
      }
    });
    describe('While Component Creation', () => {
      // assert constructor contents

      describe('should have initialized', () => {
        beforeEach(() => {
          try {
            // arrange
            fixture = TestBed.createComponent(ConfirmidentityComponent);
            // act
            component = fixture.componentInstance;
          } catch (error) {
            console.warn(error);
          }
        });

        it('should have initialized identityForm form', () => {
          try {
            // assert
            expect(component.identityForm).toBeTruthy();
          } catch (error) {
            console.warn(error);
          }
        });

        it('should have assigned dobMask from ValidationService.dobMask', () => {
          try {
            // act
            const result = deepEqual(component.dobMask, mockValidationService.dobMask);
            // assert
            expect(result).toBeTruthy();
          } catch (error) {
            console.warn(error);
          }
        });
      });
    });
    describe('error handling', () => {
      xit('should catch errors and handle them as and when they occur', () => {
        try {
          // arrange
          const _mockValidationService = Object.assign({}, mockValidationService);
          _mockValidationService.dateValidator.and.callFake(function() {
            throw new Error('an-exception');
          });

          TestBed.overrideProvider(ValidationService, _mockValidationService);
          TestBed.compileComponents();

          fixture = TestBed.createComponent(ConfirmidentityComponent);
          // act
          component = fixture.componentInstance;
          // assert
          expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
        } catch (error) {
          console.warn(error);
        }
      });

      afterAll(() => {
        try {
          mockValidationService.dateValidator.and.returnValue(() => true);
          TestBed.overrideProvider(ValidationService, mockValidationService);
          TestBed.compileComponents();
        } catch (error) {
          console.warn(error);
        }
      });
    });
  });
  describe('ngOnInit', () => {
    it('should have loaded', () => {
      try {
        // arrange
        fixture = TestBed.createComponent(ConfirmidentityComponent);
        component = fixture.componentInstance;

        // act
        fixture.detectChanges();
        // assert
        expect(component).toBeTruthy();
      } catch (error) {
        console.warn(error);
      }
    });

    it('should call the this.alertService.clearError', () => {
      try {
        // arrange
        fixture = TestBed.createComponent(ConfirmidentityComponent);
        component = fixture.componentInstance;

        // act
        fixture.detectChanges();
        // assert
        expect(mockAlertService.clearError).toHaveBeenCalled();
      } catch (error) {
        console.warn(error);
      }
    });
    describe('error handling', () => {
      it('should call the BcbsmaerrorHandlerService.logError', () => {
        try {
          // arrange
          fixture = TestBed.createComponent(ConfirmidentityComponent);
          component = fixture.componentInstance;
          component['alertService'] = null;
          // act
          try {
            fixture.detectChanges();
          } catch (forcedError) {}
          // assert
          expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
        } catch (error) {
          console.warn(error);
        }
      });
    });
  });

  describe('Methods', () => {
    describe('ngOnDestroy', () => {
      it('should have called this.alertService.clearError', () => {
        try {
          // arrange
          fixture = TestBed.createComponent(ConfirmidentityComponent);
          component = fixture.componentInstance;

          // act
          component.ngOnDestroy();

          // assert
          expect(mockAlertService.clearError).toHaveBeenCalled();
        } catch (error) {
          console.warn(error);
        }
      });
    });
    describe('onSubmit', () => {
      beforeEach(() => {
        // arrange
        mockMyAccountService.confirmIdentity.and.returnValue(of(verifyfunauthuser_response.success));
        TestBed.overrideProvider(MyAccountService, { useValue: mockMyAccountService });
        TestBed.compileComponents();
      });
      beforeEach(async () => {
        fixture = TestBed.createComponent(ConfirmidentityComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
      });

      afterAll(() => {
        mockMyAccountService.confirmIdentity.and.returnValue(of(verifyfunauthuser_response.success));
        TestBed.overrideProvider(MyAccountService, { useValue: mockMyAccountService });
        TestBed.compileComponents();
      });
      it('should have called this.alertService.clearError', () => {
        try {
          // act
          component.onSubmit();

          // assert
          expect(mockAlertService.clearError).toHaveBeenCalled();
        } catch (error) {
          console.warn(error);
        }
      });

      it('should assigned the value of this.identityForm.value to request', () => {
        try {
          // act
          const requestRes = component.identityForm.value;
          component.onSubmit();

          // assert
          expect(requestRes).toBeTruthy();
        } catch (error) {
          console.warn(error);
        }
      });

      it('should have called this.myAccountService.confirmIdentity', () => {
        try {
          // act
          component.onSubmit();

          // assert
          expect(mockMyAccountService.confirmIdentity).toHaveBeenCalled();
        } catch (error) {
          console.warn(error);
        }
      });

      it('should have called this.handleVerifiedResponse if res["result"] === 0', () => {
        try {
          spyOn(component, 'handleVerifiedResponse');
          // act
          const request = '06/12/1947';
          const res: any = verifyfunauthuser_response.success;
          component.onSubmit();
          // mockMyAccountService.confirmIdentity(request);

          // assert
          if (res && (res['result'] === '0' || res['result'] === 0)) {
            expect(component.handleVerifiedResponse).toHaveBeenCalled();
          }
        } catch (error) {
          console.warn(error);
        }
      });

      xit('should have called this.handleVerifiedResponse if res["result"] < 0', () => {
        try {
          // act
          const request = '06/12/1947';
          const res: any = verifyfunauthuser_response.failure;
          component.onSubmit();
          mockMyAccountService.confirmIdentity.and.returnValue(of(verifyfunauthuser_response.failure));
          TestBed.overrideProvider(MyAccountService, mockMyAccountService);
          TestBed.compileComponents();
          // mockMyAccountService.confirmIdentity(request);
          // assert
          if (res['result'] < 0) {
            expect(mockGlobalService.handleError).toHaveBeenCalled();
          }
        } catch (error) {
          console.warn(error);
        }
      });

      describe('error handling', () => {
        it('should catch errors and handle them as and when they occur', () => {
          try {
            mockAlertService.clearError.and.callFake(function() {
              throw new Error('an-exception');
            });
            // act
            component.onSubmit();
            // assert
            expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
          } catch (error) {
            console.warn(error);
          }
        });
      });

      afterAll(() => {
        mockMyAccountService.confirmIdentity.and.returnValue(of(verifyfunauthuser_response.success));
        // mockMyAccountService.confirmIdentity.and.returnValue(of(verifyfunauthuser_response.failure));
        TestBed.overrideProvider(MyAccountService, mockMyAccountService);
        TestBed.compileComponents();
      });
    });

    describe('handleVerifiedResponse', () => {
      xit('should assigned this.clearAlertOnDestroy as false', () => {
        try {
          // arrange
          fixture = TestBed.createComponent(ConfirmidentityComponent);
          component = fixture.componentInstance;

          // act
          component.handleVerifiedResponse();

          // assert
          //  expect(component.clearAlertOnDestroy).toBeFalsy();
        } catch (error) {
          console.warn(error);
        }
      });

      xit('should have called this.alertService.setAlert', () => {
        try {
          // arrange
          fixture = TestBed.createComponent(ConfirmidentityComponent);
          component = fixture.componentInstance;

          // act
          component.handleVerifiedResponse();

          // assert
          expect(mockAlertService.setAlert).toHaveBeenCalledWith(MyAccountConstants.NotificationMsg, '', AlertType.Notification);
        } catch (error) {
          console.warn(error);
        }
      });
      // Clear storage is not called inside handleVerifiedResponse anymore.
      xit('should have called this.alertService.clearStorage', () => {
        try {
          // arrange
          fixture = TestBed.createComponent(ConfirmidentityComponent);
          component = fixture.componentInstance;

          // act
          component.handleVerifiedResponse();

          // assert
          expect(mockMyAccountService.clearStorage).toHaveBeenCalled();
        } catch (error) {
          console.warn(error);
        }
      });

      it("should this.navigate called with ['/account/verifyAccessCode']", () => {
        try {
          // arrange
          fixture = TestBed.createComponent(ConfirmidentityComponent);
          component = fixture.componentInstance;

          // act
          component.handleVerifiedResponse();

          // assert
          expect(mockRouter.navigate).toHaveBeenCalledWith(['/account/verifyAccessCode', 'FUN']);
        } catch (error) {
          console.warn(error);
        }
      });

      xit('should have called this.alertService.setAlert', () => {
        try {
          // arrange
          fixture = TestBed.createComponent(ConfirmidentityComponent);
          component = fixture.componentInstance;

          // act
          component.handleVerifiedResponse();

          // assert
          expect(mockAlertService.setAlert).toHaveBeenCalledWith(
            'Please check your email account or mobile number for your username.',
            '',
            AlertType.Success
          );
        } catch (error) {
          console.warn(error);
        }
      });

      //There is no direct setAlert call in the handleVerifiedResponse alsp noticed issues
      // with reset of TestBed.overrideProvider.
      xit('should call the BcbsmaerrorHandlerService.logError', () => {
        try {
          // arrange
          // arrange
          mockAlertService.setAlert.and.callFake(function() {
            throw new Error('an-exception');
          });
          TestBed.overrideProvider(AlertService, mockAlertService);
          TestBed.compileComponents();
          fixture = TestBed.createComponent(ConfirmidentityComponent);
          component = fixture.componentInstance;

          // act
          component.handleVerifiedResponse();

          // assert
          expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
        } catch (error) {
          console.warn(error);
        }
        afterAll(() => {
          mockAlertService.setAlert.and.returnValue(null);
          TestBed.overrideProvider(AlertService, mockAlertService);
          TestBed.compileComponents();
        });
      });
    });
  });
});
