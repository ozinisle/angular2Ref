import { CommonModule, TitleCasePipe } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatCardModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatListModule,
  MatNativeDateModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute, Router } from '@angular/router';
import { StorageServiceModule } from 'angular-webstorage-service';
import { FilterPipe, FilterPipeModule } from 'ngx-filter-pipe';
import { OrderModule } from 'ngx-order-pipe';
import { MaterialModule } from '../../../../../../app/material.module';
import { MyMedicationDetailsService } from '../../../../../../app/pages/medications/myMedicationDetails/my-medication-details.service';
import { MyMedicationsComponent } from '../../../../../../app/pages/medications/mymedications/mymedications.component';
import { CasingForFilterPipe } from '../../../../../../app/shared/pipes/casingForFilter/casingForFilter.pipe';
import { YyyymmddTommddyyyyPipe } from '../../../../../../app/shared/pipes/date/yyyymmdd-to-mmddyyyy.pipe';
import { PhonePipe } from '../../../../../../app/shared/pipes/phone/phone.pipe';
import { AuthHttp } from '../../../../../../app/shared/services/auth-http.service';
import { DependantsService } from '../../../../../../app/shared/services/dependant.service';
import { FilterService } from '../../../../../../app/shared/services/filter.service';
import { GlobalService } from '../../../../../../app/shared/services/global.service';
import { MedicationsService } from '../../../../../../app/shared/services/medications/medications.service';
import { AlertService, AuthService, ConstantsService } from '../../../../../../app/shared/shared.module';
import { mocks } from '../../../../../constants/mocks.service';
import { mockMyMedsResolverServiceData } from '../../../../../data/myMedications/mock.myMedsResolverService.data';
import { FakeBreadcrumbsComponent, FakeFpoLayoutComponent } from '../../../../../fake-components';
import { FakeCellAspectRatioDirectiveStub } from '../../../../../fake-directives';
import { MockRouter } from '../../../../../mock-classes/mock-router.class';

describe('MyMedicationsComponent', () => {
  let component: MyMedicationsComponent;
  let fixture: ComponentFixture<MyMedicationsComponent>;

  let mockMedicationsService;
  let mockAuthService;
  let mockDependantsService;
  let mockFilterService;
  let mockGlobalService;
  let mockAuthHttpService;
  let mockConstantsService;
  let mockActivatedRoute;
  let mockMyMedicationDetailsService;
  let mockAlertService;

  beforeEach(async(() => {
    mockActivatedRoute = {
      snapshot: {
        data: mockMyMedsResolverServiceData
      }
    };

    mockMedicationsService = mocks.service.medicationService;
    mockAuthService = mocks.service.authService;
    mockDependantsService = mocks.service.dependantsService;
    mockFilterService = mocks.service.filterService;
    mockGlobalService = mocks.service.globalService;
    mockAuthHttpService = mocks.service.authHttp;
    mockConstantsService = mocks.service.constantsService;
    mockMyMedicationDetailsService = mocks.service.medicationDetailsService;
    mockAlertService = mocks.service.alertService;

    TestBed.configureTestingModule({
      imports: [
        BrowserAnimationsModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        StorageServiceModule,
        HttpClientTestingModule,

        MatDatepickerModule,
        MatNativeDateModule,
        MatFormFieldModule,
        MatRadioModule,
        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatDialogModule,
        MatExpansionModule,
        MatListModule,
        MatButtonModule,
        MaterialModule,
        FilterPipeModule,
        OrderModule
      ],
      declarations: [
        FakeBreadcrumbsComponent,
        FakeFpoLayoutComponent,
        FakeCellAspectRatioDirectiveStub,

        CasingForFilterPipe,
        PhonePipe,
        YyyymmddTommddyyyyPipe,

        MyMedicationsComponent
      ],
      providers: [
        { provide: MedicationsService, useValue: mockMedicationsService },
        { provide: AuthService, useValue: mockAuthService },
        { provide: Router, useValue: new MockRouter() },
        { provide: DependantsService, useValue: mockDependantsService },
        { provide: FilterService, useValue: mockFilterService },
        { provide: GlobalService, useValue: mockGlobalService },
        { provide: AuthHttp, useValue: mockAuthHttpService },
        { provide: ConstantsService, useValue: mockConstantsService },
        { provide: MyMedicationDetailsService, useValue: mockMyMedicationDetailsService },
        { provide: AlertService, useValue: mockAlertService },
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        FilterPipe,
        TitleCasePipe,
        CasingForFilterPipe,
        PhonePipe,
        YyyymmddTommddyyyyPipe
      ]
    }).compileComponents();
  }));

  describe('Constructor', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(MyMedicationsComponent);
      component = fixture.componentInstance;
    });

    it('should create', () => {
      // assert
      expect(component).toBeTruthy();
    });

    // describe('While Component Creation', () => {
    // });
  });

  describe('ngOnInit', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(MyMedicationsComponent);
      component = fixture.componentInstance;

      // act
      fixture.detectChanges();
    });
    it('should load', () => {
      // assert
      expect(component).toBeTruthy();
    });
    // describe('should have initialized', () => {
    // });
    // describe('should have called', () => {
    // });
  });
});
