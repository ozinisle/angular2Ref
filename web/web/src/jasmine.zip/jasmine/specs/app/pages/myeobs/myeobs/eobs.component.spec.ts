import { CommonModule, DatePipe } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatCardModule,
  MatDialogModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute, Router } from '@angular/router';
import { StorageServiceModule } from 'angular-webstorage-service';
import { TextMaskModule } from 'angular2-text-mask';
import { MaterialModule } from '../../../../../../app/material.module';
import { EobsService } from '../../../../../../app/pages/myeobs/eobs.service';
import { EobsComponent } from '../../../../../../app/pages/myeobs/myeobs/eobs.component';
import { AuthHttp } from '../../../../../../app/shared/services/auth-http.service';
import { DependantsService } from '../../../../../../app/shared/services/dependant.service';
import { FilterService } from '../../../../../../app/shared/services/filter.service';
import { GlobalService } from '../../../../../../app/shared/services/global.service';
import { AlertService, AuthService, ConstantsService } from '../../../../../../app/shared/shared.module';
import { mocks } from '../../../../../constants/mocks.service';
import { eob_resolver_mock_data } from '../../../../../data/eob/eob.component.data';
import { FakeBreadcrumbsComponent, FakeFpoLayoutComponent, FakeSpinnerComponent } from '../../../../../fake-components';
import {
  FakeCellAspectRatioDirectiveStub,
  FakeFromRootDirectiveStub,
  FakeInfiniteScrollContainerDirectiveStub,
  FakeInfiniteScrollDirectiveStub,
  FakeInfiniteScrollDisabledDirectiveStub,
  FakeInfiniteScrollDistanceDirectiveStub,
  FakeInfiniteScrollThrottleDirectiveStub,
  FakeInfiniteScrollUpDistanceDirectiveStub,
  FakeScrollWindowDirectiveStub
} from '../../../../../fake-directives';

describe('EobsComponent', () => {
  let component: EobsComponent;
  let fixture: ComponentFixture<EobsComponent>;

  let mockEobsService;
  let mockAuthService;
  let mockAuthHttp;
  let mockRouter;
  let mockDependantsService;
  let mockFilterService;
  let mockGlobalService;
  let mockConstants;
  let mockActivatedRoute;
  let mockAlertService;

  beforeEach(async(() => {
    mockEobsService = mocks.service.eobsService;
    mockAuthService = mocks.service.authService;
    mockAuthHttp = mocks.service.authHttp;
    mockRouter = mocks.service.router;
    mockDependantsService = mocks.service.dependantsService;
    mockFilterService = mocks.service.filterService;
    mockGlobalService = mocks.service.globalService;
    mockConstants = mocks.service.constantsService;
    mockAlertService = mocks.service.alertService;

    mockActivatedRoute = {
      snapshot: {
        data: {
          eobInfo: eob_resolver_mock_data
        }
      }
    };

    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        BrowserModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        StorageServiceModule,
        HttpClientTestingModule,
        TextMaskModule,
        MatFormFieldModule,
        MatRadioModule,
        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatDialogModule,
        MaterialModule
      ],

      declarations: [
        FakeBreadcrumbsComponent,
        FakeSpinnerComponent,
        FakeFpoLayoutComponent,
        FakeCellAspectRatioDirectiveStub,
        FakeScrollWindowDirectiveStub,
        FakeInfiniteScrollContainerDirectiveStub,
        FakeInfiniteScrollDirectiveStub,
        FakeInfiniteScrollDistanceDirectiveStub,
        FakeInfiniteScrollThrottleDirectiveStub,
        FakeInfiniteScrollUpDistanceDirectiveStub,
        FakeInfiniteScrollDisabledDirectiveStub,
        FakeFromRootDirectiveStub,
        EobsComponent
      ],

      providers: [
        { provide: EobsService, useValue: mockEobsService },
        { provide: AuthService, useValue: mockAuthService },
        { provide: AuthHttp, useValue: mockAuthHttp },
        { provide: Router, useValue: mockRouter },
        { provide: DependantsService, useValue: mockDependantsService },
        { provide: FilterService, useValue: mockFilterService },
        { provide: GlobalService, useValue: mockGlobalService },
        { provide: ConstantsService, useValue: mockConstants },
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: AlertService, useValue: mockAlertService },
        DatePipe
      ]
    }).compileComponents();
  }));

  describe('Constructor', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(EobsComponent);
      component = fixture.componentInstance;
    });

    it('should create', () => {
      // assert
      expect(component).toBeTruthy();
    });

    describe('While Component Creation', () => {
      it('should do', () => {
        // assert
        pending();
      });
    });
  });

  describe('ngOnInit', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(EobsComponent);
      component = fixture.componentInstance;

      // act
      fixture.detectChanges();
    });
    it('should have loaded', () => {
      // assert
      expect(component).toBeTruthy();
    });
    describe('should have initialized', () => {
      it('should have initialized', () => {
        // assert
        pending();
      });
    });

    describe('should have called', () => {
      it('should have called', () => {
        // assert
        pending();
      });
    });
  });
});
