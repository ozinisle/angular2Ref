import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TempMemInfoComponent } from '../../../../../../../app/pages/sso-inbound/pages/temp-mem-info/temp-mem-info.component';
import { SsoInboundModule } from '../../../../../../../app/pages/sso-inbound/sso-inbound.module';
import { AlertsComponent } from '../../../../../../../app/shared/alerts/alerts.component';
import { SharedModule } from 'primeng/primeng';
import { GlobalService } from '../../../../../../../app/shared/services/global.service';
import { mocks } from '../../../../../../constants/mocks.service';
import { SsoInboundService } from '../../../../../../../app/pages/sso-inbound/service/sso-inbound.service';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';

describe('TempMemInfoComponent', () => {
  let component: TempMemInfoComponent;
  let fixture: ComponentFixture<TempMemInfoComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SsoInboundModule, SharedModule],
      declarations: [ ],
      providers : [
        FormBuilder,
        {
          provide: SsoInboundService,
          useValue: mocks.service.ssoInboundService
        },
        {
          provide: GlobalService,
          useValue: mocks.service.globalService
        },
        {
          provide: Router,
          useValue: mocks.service.router
        }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TempMemInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
