import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PreferenceModalComponent } from '../../../../../app/pages/preference-modal/preference-modal/preference-modal.component';
import { SharedModule, AlertService, AuthService, ConstantsService } from '../../../../../app/shared/shared.module';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { GlobalService } from '../../../../../app/shared/services/global.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ProfileService } from '../../../../../app/shared/services/myprofile/profile.service';
import { PreferencesService } from '../../../../../app/shared/services/myprofile/preferences.service';
import { VerifyEmailMobileService } from '../../../../../app/components/verify-email-mobile/verify-email-mobile.service';
import { AuthHttp } from '../../../../../app/shared/services/auth-http.service';
import { mocks } from '../../../../constants/mocks.service';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material';
import { SESSION_STORAGE } from 'angular-webstorage-service';

describe('PreferenceModalComponent', () => {
  let component: PreferenceModalComponent;
  let fixture: ComponentFixture<PreferenceModalComponent>;
  const mockAlertService = mocks.service.alertService;
  const mockGlobalService = mocks.service.globalService;
  const mockProfileService = mocks.service.profileService;
  const mockPreferenceService = mocks.service.preferenceService;
  const mockRouter = mocks.service.router;
  const mockAuthService = mocks.service.authService;
  const mockAuthHttp = mocks.service.authHttp;
  const mockVerifyEmailMobileService = mocks.service.verifyEmailMobileService;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule, MatDialogModule],
      declarations: [ PreferenceModalComponent ],
      providers : [
        { provide: AlertService, useValue: mockAlertService },
        { provide: GlobalService, useValue: mockGlobalService },
        ConstantsService,
        { provide: Router, useValue: mockRouter },
        { provide: ProfileService, useValue: mockProfileService },
        { provide: PreferencesService, useValue : mockPreferenceService },
        { provide: VerifyEmailMobileService, useValue : mockVerifyEmailMobileService },
        { provide: AuthService, useValue: mockAuthService },
        { provide: AuthHttp, useValue: mockAuthHttp },
        {
          provide: MAT_DIALOG_DATA,
          useValue: {preferences: {Preferences: [{CID: ''}]}}
        },
        {
          provide: SESSION_STORAGE,
          useValue: {}
        },
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreferenceModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
