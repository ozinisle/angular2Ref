import { CommonModule, TitleCasePipe } from '@angular/common';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserModule } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { MyAccountComponent } from '../../../../../app/pages/myaccount/myaccount.component';
import { AlertService, AuthService, ConstantsService } from '../../../../../app/shared/shared.module';
import { mocks } from '../../../../constants/mocks.service';
import { myaccount_resolver_data } from '../../../../data/myaccount/myaccount.component.data';
import { FakeBreadcrumbsComponent } from '../../../../fake-components';
import { FakeRouterLinkDirectiveStub } from '../../../../fake-directives';
import { PreferenceModalService } from '../../../../../app/pages/preference-modal/preference-modal.service';
import { AuthHttp } from '../../../../../app/shared/services/auth-http.service';

describe('MyAccountComponent', () => {
  let component: MyAccountComponent;
  let fixture: ComponentFixture<MyAccountComponent>;

  let mockRouter;
  let mockAlertService;
  let mockAuthService;
  let mockActivatedRoute;
  let mockConstantsService;

  beforeEach(async(() => {
    mockRouter = mocks.service.router;
    mockAlertService = mocks.service.alertService;
    mockAuthService = mocks.service.authService;
    mockConstantsService = mocks.service.constantsService;
    mockActivatedRoute = {
      snapshot: {
        data: {
          myAccountData: myaccount_resolver_data
        }
      }
    };

    TestBed.configureTestingModule({
      imports: [BrowserModule, CommonModule],

      declarations: [FakeBreadcrumbsComponent, FakeRouterLinkDirectiveStub, MyAccountComponent],

      providers: [
        { provide: AuthService, useValue: mockAuthService },
        { provide: Router, useValue: mockRouter },
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        TitleCasePipe,
        { provide: ConstantsService, useValue: mockConstantsService },
        { provide: AlertService, useValue: mockAlertService },
        {provide : PreferenceModalService, useValue : mocks.service.preferenceModalService}

      ]
    }).compileComponents();
  }));

  describe('Constructor', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(MyAccountComponent);
      component = fixture.componentInstance;
    });
    it('should create', () => {
      // assert
      expect(component).toBeTruthy();
    });
    describe('While Component Creation', () => {
      it('should do', () => {
        // assert
        pending();
      });
    });
  });
  describe('ngOnInit', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(MyAccountComponent);
      component = fixture.componentInstance;
      // act
      fixture.detectChanges();
    });
    it('should have loaded', () => {
      // assert
      expect(component).toBeTruthy();
    });
    describe('should have initialized', () => {
      it('should have initialized', () => {
        // assert
        pending();
      });
    });
    describe('should have called', () => {
      it('should have called', () => {
        // assert
        pending();
      });
    });
  });
});
