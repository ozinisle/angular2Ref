import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatCardModule,
  MatDialogModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { StorageServiceModule } from 'angular-webstorage-service';
import { TextMaskModule } from 'angular2-text-mask';
import { of } from 'rxjs/observable/of';
import { MaterialModule } from '../../../../../../app/material.module';
import { ForgotUsernameComponent } from '../../../../../../app/pages/my-account/forgot-username/forgot-username.component';
import { mocks } from '../../../../../constants/mocks.service';
import { FakeControlMessagesComponent } from '../../../../../fake-components';

import * as deepEqual from 'deep-equal';
import { Observable } from 'rxjs';
import { MyAccountService } from '../../../../../../app/pages/my-account/my-account.service';
import { AlertType } from '../../../../../../app/shared/alerts/alertType.model';
import { AuthHttp } from '../../../../../../app/shared/services/auth-http.service';
import { BcbsmaerrorHandlerService } from '../../../../../../app/shared/services/bcbsmaerror-handler.service';
import { AlertService, AuthService, ValidationService, ConstantsService } from '../../../../../../app/shared/shared.module';
import { verifyfunuser_response } from '../../../../../data/my-account/forgot-username/verifyfunuser.data';
import { authService_getTokens_response } from '../../../../../data/services/authService.data';
import { RegType } from '../../../../../../app/shared/models/regType.enum';
import { GlobalService } from '../../../../../../app/shared/services/global.service';

describe('ForgotUsernameComponent', () => {
  let component: ForgotUsernameComponent;
  let fixture: ComponentFixture<ForgotUsernameComponent>;

  const formBuilder: FormBuilder = new FormBuilder();
  let mockMyAccountService;
  let mockAuthService;
  let mockAuthHttp;
  let mockAlertService;
  let mockRouter;
  let mockValidationService;
  let mockBcbsmaerrorHandlerService;
  let mockGlobalService;

  beforeEach(async(() => {
    mockMyAccountService = mocks.service.myAccountService;
    mockAuthService = mocks.service.authService;
    mockAuthHttp = mocks.service.authHttp;
    mockAlertService = mocks.service.alertService;
    mockGlobalService = mocks.service.globalService;
    mockRouter = mocks.service.router;
    mockValidationService = mocks.service.validationService;
    mockBcbsmaerrorHandlerService = mocks.service.bcbsmaerrorHandlerService;

    TestBed.configureTestingModule({
      imports: [
        BrowserModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        StorageServiceModule,
        HttpClientTestingModule,
        TextMaskModule,
        MatFormFieldModule,
        MatRadioModule,

        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatDialogModule,
        MaterialModule
      ],
      declarations: [FakeControlMessagesComponent, ForgotUsernameComponent],

      providers: [
        ConstantsService,
        { provide: FormBuilder, useValue: formBuilder },
        { provide: MyAccountService, useValue: mockMyAccountService },
        { provide: AuthService, useValue: mockAuthService },
        { provide: AuthHttp, useValue: mockAuthHttp },
        { provide: AlertService, useValue: mockAlertService },
        { provide: GlobalService, useValue: mockGlobalService },
        { provide: Router, useValue: mockRouter },
        { provide: ValidationService, useValue: mockValidationService },
        { provide: BcbsmaerrorHandlerService, useValue: mockBcbsmaerrorHandlerService }
      ]
    }).compileComponents();
  }));

  describe('Constructor', () => {
    it('should have been created', () => {
      // arrange
      fixture = TestBed.createComponent(ForgotUsernameComponent);
      // act
      component = fixture.componentInstance;
      // assert
      expect(component).toBeTruthy();
    });
    describe('While Component Creation', () => {
      // assert constructor contents

      describe('should have initialized', () => {
        beforeEach(() => {
          // arrange
          fixture = TestBed.createComponent(ForgotUsernameComponent);
          // act
          component = fixture.componentInstance;
        });

        it('should have initialized updatePasswordForm form', () => {
          // assert
          expect(component.forgotUsernameForm).toBeTruthy();
        });

        it('should have assigned phoneMask from ValidationService.phoneMask', () => {
          // act
          const result = deepEqual(component.phoneMask, mockValidationService.phoneMask);
          // assert
          expect(result).toBeTruthy();
        });
      });
    });
    describe('error handling', () => {
      it('should catch errors and handle them as and when they occur', () => {
        // arrange
        const _mockValidationService = Object.assign({}, mockValidationService);
        _mockValidationService.emailValidator.and.callFake(function() {
          throw new Error('an-exception');
        });

        TestBed.overrideProvider(ValidationService, _mockValidationService);
        TestBed.compileComponents();

        fixture = TestBed.createComponent(ForgotUsernameComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
      });

      afterAll(() => {
        mockValidationService.emailValidator.and.returnValue(() => true);
        TestBed.overrideProvider(ValidationService, mockValidationService);
        TestBed.compileComponents();
      });
    });
  });
  describe('ngOnInit', () => {
    it('should have loaded', () => {
      // arrange
      fixture = TestBed.createComponent(ForgotUsernameComponent);
      component = fixture.componentInstance;

      // act
      fixture.detectChanges();
      // assert
      expect(component).toBeTruthy();
    });

    it('should call the this.alertService.clearError', () => {
      // arrange
      fixture = TestBed.createComponent(ForgotUsernameComponent);
      component = fixture.componentInstance;

      // act
      fixture.detectChanges();
      // assert
      expect(mockAlertService.clearError).toHaveBeenCalled();
    });
    describe('error handling', () => {
      it('should call the BcbsmaerrorHandlerService.logError', () => {
        // arrange
        fixture = TestBed.createComponent(ForgotUsernameComponent);
        component = fixture.componentInstance;
        component['alertService'] = null;
        // act
        try {
          fixture.detectChanges();
        } catch (forcedError) {}
        // assert
        expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
      });
    });
  });

  describe('Methods', () => {
    describe('ngOnDestroy', () => {
      it('should have called this.alertService.clearError', () => {
        // arrange
        fixture = TestBed.createComponent(ForgotUsernameComponent);
        component = fixture.componentInstance;

        // act
        fixture.detectChanges();

        // assert
        expect(mockAlertService.clearError).toHaveBeenCalled();
      });
    });
    describe('onSubmit', () => {
      it('should have called this.alertService.clearError', () => {
        // arrange
        fixture = TestBed.createComponent(ForgotUsernameComponent);
        component = fixture.componentInstance;
        spyOn(component, 'getToken');

        // act
        component.onSubmit();

        // assert
        expect(mockAlertService.clearError).toHaveBeenCalled();
      });

      it('should have called this.getToken', () => {
        // arrange
        fixture = TestBed.createComponent(ForgotUsernameComponent);
        component = fixture.componentInstance;
        spyOn(component, 'getToken');

        // act
        component.onSubmit();

        // assert
        expect(component.getToken).toHaveBeenCalled();
      });

      describe('error handling', () => {
        it('should catch errors and handle them as and when they occur', () => {
          // arrange

          fixture = TestBed.createComponent(ForgotUsernameComponent);
          component = fixture.componentInstance;
          spyOn(component, 'getToken').and.callFake(function() {
            throw new Error('an-exception');
          });
          // act
          component.onSubmit();
          // assert
          expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
        });
      });
    });

    describe('handleSuccessResponse', () => {
      beforeEach(() => {
        spyOn(sessionStorage.__proto__, 'setItem');
      });

      it("should have called ['/account/confirmidentity']", () => {
        // arrange
        fixture = TestBed.createComponent(ForgotUsernameComponent);
        component = fixture.componentInstance;

        // act
        component.handleSuccessResponse(RegType.EMAIL, {});

        // assert
        expect(mockRouter.navigate).toHaveBeenCalledWith(['./account/confirmidentity']);
      });

      it('should have called this.alertService.setAlert', () => {
        // arrange
        fixture = TestBed.createComponent(ForgotUsernameComponent);
        component = fixture.componentInstance;

        // act
        component.handleNonVerifiedResponse();

        // assert
        expect(mockAlertService.setAlert)
        .toHaveBeenCalledWith('Please check your email account or mobile number for your username.', '', AlertType.Success);
      });

      it('should call the BcbsmaerrorHandlerService.logError', () => {
        // arrange
        fixture = TestBed.createComponent(ForgotUsernameComponent);
        component = fixture.componentInstance;

        // act
        component.handleSuccessResponse(RegType.EMAIL, {});

        // assert
        expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
      });

      describe('error handling', () => {
        xit('should catch errors and handle them as and when they occur', () => {
          // arrange
          const _mockRouter = Object.assign({}, mockRouter);
          _mockRouter.navigate.and.callFake(() => {
            throw new Error('an-exception');
          });

          TestBed.overrideProvider(Router, _mockRouter);
          TestBed.compileComponents();

          fixture = TestBed.createComponent(ForgotUsernameComponent);
          component = fixture.componentInstance;

          // act
          component.handleSuccessResponse(RegType.EMAIL, {});

          // assert
          expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
        });

        afterAll(() => {
          TestBed.overrideProvider(Router, mockRouter);
          TestBed.compileComponents();
        });
      });
    });

    describe('getToken', () => {
      beforeEach(() => {
        // arrange
        mockAuthService.getTokens.and.returnValue(of(authService_getTokens_response));
        TestBed.overrideProvider(AuthService, { useValue: mockAuthService });
        TestBed.compileComponents();
      });
      beforeEach(async () => {
        fixture = TestBed.createComponent(ForgotUsernameComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
      });

      afterAll(() => {
        mockAuthService.getTokens.and.returnValue(of(authService_getTokens_response));
        TestBed.overrideProvider(AuthService, { useValue: mockAuthService });
        TestBed.compileComponents();
      });

      it('should have called this.authService.getTokens', () => {
        // arrange
        spyOn(component, 'verifyIsUserValid');

        // act 
        component.getToken();

        // assert
        expect(mockAuthService.getTokens).toHaveBeenCalled();
      });

      it('should have called this.authService.persistSession', () => {
        // act
        component.getToken();

        // assert
        expect(mockAuthService.persistSession).toHaveBeenCalled();
      });

      it('should have called this.verifyIsUserValid', () => {
        // arrange
        const spyVerifyIsUserValid = spyOn(component, 'verifyIsUserValid');

        // act
        component.getToken();

        // assert
        expect(spyVerifyIsUserValid).toHaveBeenCalled();
      });

      describe('error handling', () => {
        it('should catch errors and handle them as and when they occur', () => {
          // arrange
          const _mockAuthService = Object.assign({}, mockAuthService);
          _mockAuthService.getTokens.and.callFake(function() {
            throw new Error('an-exception');
          });

          TestBed.overrideProvider(AuthService, _mockAuthService);
          TestBed.compileComponents();

          fixture = TestBed.createComponent(ForgotUsernameComponent);
          component = fixture.componentInstance;
          // act
          component.getToken();
          // assert
          expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
        });

        it('should catch errors when handling response data in getTokens() call', () => {
          // arrange
          const _mockAuthService = Object.assign({}, mockAuthService);
          _mockAuthService.getTokens.and.returnValue(Observable.throw({ status: 404 }));

          TestBed.overrideProvider(AuthService, _mockAuthService);
          TestBed.compileComponents();

          fixture = TestBed.createComponent(ForgotUsernameComponent);
          component = fixture.componentInstance;
          // act
          component.getToken();
          // assert
          expect(mockAuthHttp.handleError).toHaveBeenCalled();
        });
      });
    });

    describe('verifyIsUserValid', () => {
      beforeEach(() => {
        // arrange
        mockMyAccountService.verifyUserValid.and.returnValue(of(verifyfunuser_response.success));
        TestBed.overrideProvider(MyAccountService, { useValue: mockMyAccountService });
        TestBed.compileComponents();
      });
      beforeEach(async () => {
        fixture = TestBed.createComponent(ForgotUsernameComponent);
        component = fixture.componentInstance;
      });

      afterAll(() => {
        mockMyAccountService.verifyUserValid.and.returnValue(of(verifyfunuser_response.success));
        TestBed.overrideProvider(MyAccountService, { useValue: mockMyAccountService });
        TestBed.compileComponents();
      });

      it('should replace the mobile number from xxx-xxx-xxxx to xxxxxxxxxx', () => {
        // act
        const mobile = '123-123-1234';
        const result = mobile.replace(/-/g, '');
        component.verifyIsUserValid();

        // assert
        expect(result).toBe('1231231234');
      });

      it('should replace the email upperCase to lowerCase', () => {
        // act
        const mobile = 'Abccc@gmail.com';
        const result = mobile.toLowerCase().trim();
        component.verifyIsUserValid();

        // assert
        expect(result).toBe('abccc@gmail.com');
      });

      it('should set the this.myAccountService.funverifyuserResponse to response', () => {
        spyOn(component, 'handleSuccessResponse').and.returnValue(null);

        // act
        component.verifyIsUserValid();

        // assert
        expect(mockMyAccountService.funverifyuserResponse).toBeTruthy();
      });

      it('should have called this.myAccountService.verifyUserValid', () => {
        // act
        component.verifyIsUserValid();

        // assert
        expect(mockMyAccountService.verifyUserValid).toHaveBeenCalled();
      });

      it('should call mockMyAccountService.verifyUserValid when the forgotusername form contains valid user name or password', () => {
        // arrange
        component.forgotUsernameForm.controls['mobile'].setValue('9874563210');
        component.forgotUsernameForm.controls['email'].setValue('testemail@testdomain.com');

        // act
        component.verifyIsUserValid();

        // assert
        expect(mockMyAccountService.verifyUserValid).toHaveBeenCalled();
      });

      describe('error handling', () => {
        it('should catch errors and handle them as and when they occur', () => {
          // act
          component['myAccountService'] = null;
          // act
          try {
            component.verifyIsUserValid();
          } catch (forcedError) {}
          // assert
          expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
        });

        it('should catch errors when handling response data in getTokens() call', () => {
          // arrange
          const _mockMyAccountService = Object.assign({}, mockMyAccountService);
          _mockMyAccountService.verifyUserValid.and.returnValue(Observable.throw({ status: 404 }));

          TestBed.overrideProvider(MyAccountService, _mockMyAccountService);
          TestBed.overrideProvider(BcbsmaerrorHandlerService, mockBcbsmaerrorHandlerService);
          TestBed.compileComponents();

          fixture = TestBed.createComponent(ForgotUsernameComponent);
          component = fixture.componentInstance;
          // act
          component.getToken();
          // assert
          expect(mockBcbsmaerrorHandlerService.handleHttpError).toHaveBeenCalled();
        });
      });
    });
  });
});
