import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserNotFoundComponent } from '../../../../../../../app/pages/sso-inbound/pages/user-not-found/user-not-found.component';
import { SsoInboundModule } from '../../../../../../../app/pages/sso-inbound/sso-inbound.module';

describe('UserNotFoundComponent', () => {
  let component: UserNotFoundComponent;
  let fixture: ComponentFixture<UserNotFoundComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SsoInboundModule],
      declarations: []
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserNotFoundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
