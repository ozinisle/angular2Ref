import { CommonModule, LocationStrategy } from '@angular/common';
import { Location } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ReflectiveInjector } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatCardModule,
  MatDialogModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { StorageServiceModule } from 'angular-webstorage-service';
import { TextMaskModule } from 'angular2-text-mask';
import { async } from 'q';
import { MaterialModule } from '../../../../../../app/material.module';
import { FadDoctorProfileService } from '../../../../../../app/pages/fad/fad-doctor-profile/fad-doctor-profile.service';
import { FadReviewComponent } from '../../../../../../app/pages/fad/fad-review/fad-review.component';
import { FadReviewService } from '../../../../../../app/pages/fad/fad-review/fad-review.service';
import { AlertService, AuthService } from '../../../../../../app/shared/shared.module';
import { mocks } from '../../../../../constants/mocks.service';
import { FakeFadReviewQuestionComponent } from '../../../../../fake-components';

describe('FadReviewComponent', () => {
  let component: FadReviewComponent;
  let fixture: ComponentFixture<FadReviewComponent>;

  let mockFadReviewService;
  let mockLocation;
  let mockAlertService;
  let mockFadDoctorProfileService;
  let mockAuthService;

  beforeEach(async(() => {
    mockFadReviewService = mocks.service.fadReviewService;
    mockLocation = mocks.service.location;
    mockAlertService = mocks.service.alertService;
    mockFadDoctorProfileService = mocks.service.fadDoctorProfileService;
    mockAuthService = mocks.service.authService;

    TestBed.configureTestingModule({
      imports: [
        BrowserModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        StorageServiceModule,
        HttpClientTestingModule,
        TextMaskModule,
        MatFormFieldModule,
        MatRadioModule,

        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatDialogModule,
        MaterialModule
      ],
      declarations: [FakeFadReviewQuestionComponent, FadReviewComponent],
      providers: [
        { provide: FadReviewService, useValue: mockFadReviewService },
        { provide: Location, useValue: mockLocation },
        { provide: AlertService, useValue: mockAlertService },
        { provide: FadDoctorProfileService, useValue: mockFadDoctorProfileService },
        { provide: AuthService, useValue: mockAuthService }
      ]
    }).compileComponents();
  }));

  describe('constuctor', () => {
    beforeEach(() => {
      // arrange & act
      fixture = TestBed.createComponent(FadReviewComponent);
      component = fixture.componentInstance;
    });
    it('should have created a component instance', () => {
      // assert
      expect(component).toBeTruthy();
    });
  });

  describe('ngOnInit', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(FadReviewComponent);
      component = fixture.componentInstance;

      // act
      fixture.detectChanges();
    });
    it('should have created a component instance', () => {
      // assert
      expect(component).toBeTruthy();
    });
  });

  describe('methods', () => {
    describe('ngOnDestroy', () => {
      it('should call this.authService.clearError', () => {
        // arrange
        fixture = TestBed.createComponent(FadReviewComponent);
        component = fixture.componentInstance;

        // act
        component.ngOnDestroy();

        // assert
        expect(mockAlertService.clearError).toHaveBeenCalled();
      });
    });

    describe('impersonation', () => {
      beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(FadReviewComponent);
        component = fixture.componentInstance;
      });
      it('should call this.authService.impersonation', () => {
        // act
        component.impersonation();

        // assert
        expect(mockAuthService.impersonation).toHaveBeenCalled();
      });

      it('should return this.authService.impersonation()', () => {
        // arrange
        fixture = TestBed.createComponent(FadReviewComponent);
        component = fixture.componentInstance;
        const impersonationFlag = mockAuthService.impersonation();
        // act
        const result = component.impersonation();

        // assert
        expect(result).toBe(impersonationFlag);
      });
    });

    xdescribe('closeScreen', () => {
      beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(FadReviewComponent);
        component = fixture.componentInstance;
      });
      it('should call this.location.back', () => {
        // act

        let testFadReviewComponent: FadReviewComponent;
        let location: Location;
        // let injector = ReflectiveInjector.resolveAndCreate([
        //    LocationStrategy,
        // Location
        //  ]);

        // Get the created object from the injector
        // location = injector.get(Location);

        // Create the spy.  Optionally: .and.callFake(implementation)
        spyOn(location, 'back');

        component.closeScreen();

        // assert
        // testFadReviewComponent.backClicked(location);
        expect(location.back).toHaveBeenCalledTimes(1);
      });
    });
  });
});
