import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatCardModule,
  MatDatepickerModule,
  MatDialogModule,
  MatDividerModule,
  MatExpansionModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatListModule,
  MatNativeDateModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { StorageServiceModule } from 'angular-webstorage-service';
import { MaterialModule } from '../../../../../../app/material.module';
import { CardComponent } from '../../../../../../app/pages/mycards/card/card.component';
import { CasingForFilterPipe } from '../../../../../../app/shared/pipes/casingForFilter/casingForFilter.pipe';
import { DependantsService } from '../../../../../../app/shared/services/dependant.service';
import { GlobalService } from '../../../../../../app/shared/services/global.service';
import { mocks } from '../../../../../constants/mocks.service';
import { mock_card_component_single_card_data } from '../../../../../data/mycards/card.component.data';

describe('CardComponent', () => {
  let component: CardComponent;
  let fixture: ComponentFixture<CardComponent>;
  let mockDependantsService;
  let mockGlobalService;

  beforeEach(async(() => {
    mockGlobalService = mocks.service.globalService;
    mockDependantsService = mocks.service.dependantsService;

    TestBed.configureTestingModule({
      imports: [
        BrowserAnimationsModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        StorageServiceModule,
        HttpClientTestingModule,

        MatDividerModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatFormFieldModule,
        MatRadioModule,
        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatDialogModule,
        MatExpansionModule,
        MatListModule,
        MatButtonModule,
        MaterialModule
      ],
      declarations: [CasingForFilterPipe, CardComponent],
      providers: [
        { provide: GlobalService, useValue: mockGlobalService },
        { provide: DependantsService, useValue: mockDependantsService }
      ]
    }).compileComponents();
  }));

  describe('Constructor', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(CardComponent);
      component = fixture.componentInstance;
    });

    it('should create', () => {
      // assert
      expect(component).toBeTruthy();
    });

    // describe('While Component Creation', () => {
    // });
  });

  describe('ngOnInit', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(CardComponent);
      component = fixture.componentInstance;
      // configuring card inputs as this is supposed to be child component
      component.cardData = mock_card_component_single_card_data;
      component.hasDependents = true;
      component.ismobile = true;

      // act
      fixture.detectChanges();
    });
    it('should load', () => {
      // assert
      expect(component).toBeTruthy();
    });
    // describe('should have initialized', () => {
    // });
    // describe('should have called', () => {
    // });
  });
});
