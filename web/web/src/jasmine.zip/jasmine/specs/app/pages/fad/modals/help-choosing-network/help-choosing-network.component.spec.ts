import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HelpChoosingNetworkComponent
} from '../../../../../../../app/pages/fad/modals/help-choosing-network/help-choosing-network.component';
import { MaterialModule } from '../../../../../../../app/material.module';
import { MatDialogRef, MatDialogModule, MatDialog } from '@angular/material';

describe('HelpChoosingNetworkComponent', () => {
  let component: HelpChoosingNetworkComponent;
  let fixture: ComponentFixture<HelpChoosingNetworkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [MaterialModule, MatDialogModule],
      declarations: [ HelpChoosingNetworkComponent ],
      providers : [
        {
          provide: MatDialog,
          useValue: {_overlayContainer : {
            _containerElement: {className : ''}
          }}
        }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HelpChoosingNetworkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
