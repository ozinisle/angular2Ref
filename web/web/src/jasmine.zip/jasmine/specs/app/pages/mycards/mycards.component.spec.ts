import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonModule } from '@angular/common';
import {
  MatButtonModule,
  MatCardModule,
  MatDialogModule,
  MatExpansionModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatListModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute, Router } from '@angular/router';
import { MaterialModule } from '../../../../../app/material.module';
import { MycardsComponent } from '../../../../../app/pages/mycards/mycards.component';
import { AuthHttp } from '../../../../../app/shared/services/auth-http.service';
import { DependantsService } from '../../../../../app/shared/services/dependant.service';
import { GlobalService } from '../../../../../app/shared/services/global.service';
import { MyCardsService } from '../../../../../app/shared/services/mycards/mycards.service';
import { AlertService, AuthService, ConstantsService } from '../../../../../app/shared/shared.module';
import { mocks } from '../../../../constants/mocks.service';
import { mycardscomponentResolverData } from '../../../../data/mycards/mycards.component.data';
import { FakeBreadcrumbsComponent, FakeCardComponent, FakeFpoLayoutComponent } from '../../../../fake-components';
import { FakeRouterLinkDirectiveStub } from '../../../../fake-directives';

describe('MycardsComponent', () => {
  let component: MycardsComponent;
  let fixture: ComponentFixture<MycardsComponent>;

  let mockDependantsService;
  let mockCardService;
  let mockAlertService;
  let mockAuthService;
  let mockGlobalService;
  let mockAuthHttp;
  let mockActivatedRoute;
  let mockRouter;
  let mockConstantsService;

  let spygetSelectedMembers;

  beforeEach(async(() => {
    mockDependantsService = mocks.service.dependantsService;
    mockCardService = mocks.service.cardService;
    mockAlertService = mocks.service.alertService;
    mockAuthService = mocks.service.authService;
    mockGlobalService = mocks.service.globalService;
    mockAuthHttp = mocks.service.authHttp;
    mockRouter = mocks.service.router;
    mockConstantsService = mocks.service.constantsService;

    mockActivatedRoute = {
      snapshot: {
        data: {
          cardsInfo: mycardscomponentResolverData
        }
      }
    };

    TestBed.configureTestingModule({
      imports: [
        BrowserAnimationsModule,
        BrowserModule,
        CommonModule,
        MatFormFieldModule,
        MatRadioModule,

        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatDialogModule,
        MatExpansionModule,
        MatListModule,
        MatButtonModule,
        MaterialModule
      ],

      declarations: [FakeRouterLinkDirectiveStub, FakeFpoLayoutComponent, FakeBreadcrumbsComponent, FakeCardComponent, MycardsComponent],

      providers: [
        { provide: GlobalService, useValue: mockGlobalService },
        { provide: AlertService, useValue: mockAlertService },
        { provide: ConstantsService, useValue: mockConstantsService },
        { provide: Router, useValue: mockRouter },
        { provide: AuthService, useValue: mockAuthService },
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: DependantsService, useValue: mockDependantsService },
        { provide: MyCardsService, useValue: mockCardService },
        { provide: AuthHttp, useValue: mockAuthHttp }
      ]
    }).compileComponents();
  }));

  describe('Constructor', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(MycardsComponent);
      component = fixture.componentInstance;
    });
    it('should create', () => {
      // assert
      expect(component).toBeTruthy();
    });
    describe('While Component Creation', () => {
      it('should do', () => {
        // assert
        pending();
      });
    });
  });
  describe('ngOnInit', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(MycardsComponent);
      component = fixture.componentInstance;
      spygetSelectedMembers = spyOn(component, 'getSelectedMembers').and.returnValue(0);

      // act
      fixture.detectChanges();
    });
    it('should have loaded', () => {
      // assert
      expect(component).toBeTruthy();
    });
    describe('should have initialized', () => {
      it('should have initialized', () => {
        // assert
        pending();
      });
    });
    describe('should have called', () => {
      it('should have called', () => {
        // assert
        pending();
      });
    });
  });
});
