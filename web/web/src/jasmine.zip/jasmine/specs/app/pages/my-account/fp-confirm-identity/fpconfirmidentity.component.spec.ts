import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatCardModule,
  MatDialogModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { TextMaskModule } from 'angular2-text-mask';
import { deepEqual } from 'assert';
import { of } from 'rxjs/observable/of';
import { MaterialModule } from '../../../../../../app/material.module';
import { FpConfirmidentityComponent } from '../../../../../../app/pages/my-account/fp-confirm-identity/fpconfirmidentity.component';
import { MyAccountService } from '../../../../../../app/pages/my-account/my-account.service';
import { AlertType } from '../../../../../../app/shared/alerts/alertType.model';
import { BcbsmaConstants } from '../../../../../../app/shared/constants/bcbsma.constants';
import { GlobalService } from '../../../../../../app/shared/services/global.service';
import { AlertService, ConstantsService, ValidationService } from '../../../../../../app/shared/shared.module';
import { mocks } from '../../../../../constants/mocks.service';
import { verifyfphintanswer_response } from '../../../../../data/my-account/fp-confirm-identity/verifyfphintanswer.data';
import { FakeControlMessagesComponent } from '../../../../../fake-components';
import { MockRouter } from '../../../../../mock-classes/mock-router.class';

describe('FpConfirmidentityComponent', () => {
  let component: FpConfirmidentityComponent;
  let fixture: ComponentFixture<FpConfirmidentityComponent>;

  const formBuilder: FormBuilder = new FormBuilder();
  let mockMyAccountService;
  let mockRouter;
  let mockGlobalService;
  let mockConstantsService;
  let mockAlertService;
  let mockValidationService;

  beforeEach(async(() => {
    mockMyAccountService = mocks.service.myAccountService;
    mockRouter = new MockRouter();
    mockGlobalService = mocks.service.globlaService;
    mockConstantsService = mocks.service.constantsService;
    mockAlertService = mocks.service.alertService;
    mockValidationService = mocks.service.validationService;

    TestBed.configureTestingModule({
      imports: [
        BrowserModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientTestingModule,
        TextMaskModule,
        MatFormFieldModule,
        MatRadioModule,
        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatInputModule,
        MatDialogModule,
        MaterialModule
      ],
      declarations: [FakeControlMessagesComponent, FpConfirmidentityComponent],
      providers: [
        { provide: FormBuilder, useValue: formBuilder },
        { provide: MyAccountService, useValue: mockMyAccountService },
        { provide: Router, useValue: mockRouter },
        { provide: GlobalService, useValue: mockGlobalService },
        { provide: ConstantsService, useValue: mockConstantsService },
        { provide: AlertService, useValue: mockAlertService },
        { provide: ValidationService, useValue: mockValidationService }
      ]
    }).compileComponents();
  }));

  describe('Constructor', () => {
    beforeEach(() => {
      try {
        // arrange
        fixture = TestBed.createComponent(FpConfirmidentityComponent);
        component = fixture.componentInstance;
      } catch (error) {
        console.warn(error);
      }
    });
    it('should create', () => {
      try {
        // assert
        expect(component).toBeTruthy();
      } catch (error) {
        console.warn(error);
      }
    });
    describe('While Component Creation', () => {
      describe('should have initialized', () => {
        beforeEach(() => {
          try {
            // arrange
            fixture = TestBed.createComponent(FpConfirmidentityComponent);
            // act
            component = fixture.componentInstance;
          } catch (error) {
            console.warn(error);
          }
        });

        it('should have initialized identityForm form', () => {
          try {
            // assert
            expect(component.identityForm).toBeTruthy();
          } catch (error) {
            console.warn(error);
          }
        });

        it('should have assigned dobMask from ValidationService.dobMask', () => {
          try {
            // act
            spyOn(component, 'dobMask');
            const result = deepEqual(component.dobMask, mockValidationService.dobMask);
            // assert
            expect(component.dobMask).toBeTruthy();
          } catch (error) {
            console.warn(error);
          }
        });
      });
    });
    it('should called this.identityForm.get("hintques").disable() when this.getHintQuestionText() === BcbsmaConstants.text.UNAVAILABLE', () => {
      try {
        // arrange

        fixture = TestBed.createComponent(FpConfirmidentityComponent);
        component = fixture.componentInstance;

        // act

        const hinQuestion = component.getHintQuestionText();
        const unavailableText = BcbsmaConstants.text.UNAVAILABLE;

        // assert
        if (hinQuestion === unavailableText) {
          expect(component.identityForm.get('hintques').disable()).toHaveBeenCalled;
        }
      } catch (error) {
        console.warn(error);
      }
    });

    it('should called this.identityForm.get("hintques").clearValidators() when this.getHintQuestionText() === BcbsmaConstants.text.UNAVAILABLE', () => {
      try {
        // arrange

        fixture = TestBed.createComponent(FpConfirmidentityComponent);
        component = fixture.componentInstance;

        // act

        const hinQuestion = component.getHintQuestionText();
        const unavailableText = BcbsmaConstants.text.UNAVAILABLE;

        // assert
        if (hinQuestion === unavailableText) {
          expect(component.identityForm.get('hintques').clearValidators()).toHaveBeenCalled;
        }
      } catch (error) {
        console.warn(error);
      }
    });

    it('should called this.identityForm.get("hintques").updateValueAndValidity() when this.getHintQuestionText() === BcbsmaConstants.text.UNAVAILABLE', () => {
      try {
        // arrange

        fixture = TestBed.createComponent(FpConfirmidentityComponent);
        component = fixture.componentInstance;

        // act

        const hinQuestion = component.getHintQuestionText();
        const unavailableText = BcbsmaConstants.text.UNAVAILABLE;

        // assert
        if (hinQuestion === unavailableText) {
          expect(component.identityForm.get('hintques').updateValueAndValidity()).toHaveBeenCalled;
        }
      } catch (error) {
        console.warn(error);
      }
    });
  });
  describe('ngOnInit', () => {
    beforeEach(() => {
      try {
        // arrange
        fixture = TestBed.createComponent(FpConfirmidentityComponent);
        component = fixture.componentInstance;
        // act
        fixture.detectChanges();
      } catch (error) {
        console.warn(error);
      }
    });
    it('should have loaded', () => {
      try {
        // assert
        expect(component).toBeTruthy();
      } catch (error) {
        console.warn(error);
      }
    });
  });
  describe('Methods', () => {
    describe('ngOnDestroy', () => {
      it('should have called this.alertService.clearError', () => {
        try {
          // arrange
          fixture = TestBed.createComponent(FpConfirmidentityComponent);
          component = fixture.componentInstance;

          // act
          component.ngOnDestroy();

          // assert
          expect(mockAlertService.clearError).toHaveBeenCalled();
        } catch (error) {
          console.warn(error);
        }
      });
    });
    describe('onSubmit', () => {
      beforeEach(() => {
        // arrange
        mockMyAccountService.verifyUserAuth.and.returnValue(of(verifyfphintanswer_response));
        TestBed.overrideProvider(MyAccountService, { useValue: mockMyAccountService });
        TestBed.compileComponents();
      });
      beforeEach(async () => {
        fixture = TestBed.createComponent(FpConfirmidentityComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
      });

      afterAll(() => {
        mockMyAccountService.verifyUserAuth.and.returnValue(of(verifyfphintanswer_response));
        TestBed.overrideProvider(MyAccountService, { useValue: mockMyAccountService });
        TestBed.compileComponents();
      });

      it('should have called this.alertService.clearError', () => {
        try {
          // act
          component.onSubmit();

          // assert
          expect(mockAlertService.clearError).toHaveBeenCalled();
        } catch (error) {
          console.warn(error);
        }
      });

      xit('should have called this.myAccountService.verifyUserAuth', () => {
        // act
        component.onSubmit();

        // assert
        expect(mockMyAccountService.verifyUserAuth).toHaveBeenCalled();
      });

      it('should have called this.globalService.handleError when result !== "0" && result !== 0', () => {
        try {
          // act
          const res: any = verifyfphintanswer_response;
          const result = isNaN(res.original['result']) ? res.original['result'] : res.original['result'].toString();
          component.onSubmit();

          // assert

          if (result !== '0' && result !== 0) {
            expect(mockGlobalService.handleError).toHaveBeenCalled();
          }
        } catch (error) {
          console.warn(error);
        }
      });

      it("should this.router.navigate called with ['/account/createPassword']", () => {
        try {
          // act
          const res: any = verifyfphintanswer_response;
          const result = isNaN(res.original['result']) ? res.original['result'] : res.original['result'].toString();
          component.onSubmit();

          // assert

          if (result === '0' && result === 0) {
            expect(mockRouter.navigate).toHaveBeenCalledWith(['/account/createPassword']);
          }
        } catch (error) {
          console.warn(error);
        }
      });
    });

    describe('handleVerifiedResponse', () => {
      it('should have called this.alertService.clearStorage', () => {
        try {
          // arrange

          fixture = TestBed.createComponent(FpConfirmidentityComponent);
          component = fixture.componentInstance;
          spyOn(sessionStorage.__proto__, 'clear');

          // act
          component.handleVerifiedResponse();

          // assert
          expect(sessionStorage.__proto__.clear).toHaveBeenCalled();
        } catch (error) {
          console.warn(error);
        }
      });

      it("should this.navigate called with ['/login']", () => {
        try {
          // arrange
          fixture = TestBed.createComponent(FpConfirmidentityComponent);
          component = fixture.componentInstance;

          // act
          component.handleVerifiedResponse();

          // assert
          expect(mockRouter.navigate).toHaveBeenCalledWith(['/login']);
        } catch (error) {
          console.warn(error);
        }
      });

      it('should have called this.alertService.setAlert', () => {
        try {
          // arrange
          fixture = TestBed.createComponent(FpConfirmidentityComponent);
          component = fixture.componentInstance;

          // act
          component.handleVerifiedResponse();

          // assert
          expect(mockAlertService.setAlert).toHaveBeenCalledWith(
            'Please check your email account or mobile number for your username.',
            '',
            AlertType.Success
          );
        } catch (error) {
          console.warn(error);
        }
      });
    });

    describe('getHintQuestionText', () => {
      it('should disable the identityForm of hintquest when not equal to null and undefined', () => {
        try {
          // arrange

          fixture = TestBed.createComponent(FpConfirmidentityComponent);
          component = fixture.componentInstance;

          // act

          const hinQuestion = mockMyAccountService.hintQuestion;
          const unavailableText = BcbsmaConstants.text.UNAVAILABLE;
          component.getHintQuestionText();

          // assert
          if (hinQuestion === unavailableText) {
            expect(component.identityForm.get('hintques').disable);
          }
        } catch (error) {
          console.warn(error);
        }
      });

      it('should return the value BcbsmaConstants.text.UNAVAILABLE when this.myAccountService.hintQuestion not equal to null and undefined', () => {
        try {
          // arrange

          fixture = TestBed.createComponent(FpConfirmidentityComponent);
          component = fixture.componentInstance;

          // act

          const hinQuestion = mockMyAccountService.hintQuestion;
          const unavailableText = BcbsmaConstants.text.UNAVAILABLE;
          component.getHintQuestionText();

          // assert
          if (hinQuestion === unavailableText) {
            expect(BcbsmaConstants.text.UNAVAILABLE).toBe('Unavailable');
          }
        } catch (error) {
          console.warn(error);
        }
      });

      it('should disable the identityForm of hintquest when this.myAccountService.hintQuestion equal to BcbsmaConstants.text.UNAVAILABLE', () => {
        try {
          // arrange

          fixture = TestBed.createComponent(FpConfirmidentityComponent);
          component = fixture.componentInstance;

          // act

          const hinQuestion = mockMyAccountService.hintQuestion;
          const unavailableText = BcbsmaConstants.text.UNAVAILABLE;
          component.getHintQuestionText();

          // assert
          if (hinQuestion === unavailableText) {
            expect(component.identityForm.get('hintques').disable);
          }
        } catch (error) {
          console.warn(error);
        }
      });

      it('should update this.myAccountService.hintQuestion as true when this.myAccountService.hintQuestion equal to BcbsmaConstants.text.UNAVAILABLE', () => {
        try {
          // arrange

          fixture = TestBed.createComponent(FpConfirmidentityComponent);
          component = fixture.componentInstance;

          // act

          const hinQuestion = mockMyAccountService.hintQuestion;
          const unavailableText = BcbsmaConstants.text.UNAVAILABLE;
          component.getHintQuestionText();

          // assert
          if (hinQuestion === unavailableText) {
            expect(mockMyAccountService.hintQuestion).toBe(hinQuestion);
          }
        } catch (error) {
          console.warn(error);
        }
      });

      it('should return this.myAccountService.hintQuestion when this.myAccountService.hintQuestion equal to BcbsmaConstants.text.UNAVAILABLE', () => {
        try {
          // arrange

          fixture = TestBed.createComponent(FpConfirmidentityComponent);
          component = fixture.componentInstance;

          // act

          const hinQuestion = mockMyAccountService.hintQuestion;
          const unavailableText = BcbsmaConstants.text.UNAVAILABLE;
          component.getHintQuestionText();

          // assert
          if (hinQuestion === unavailableText) {
            expect(mockMyAccountService.hintQuestion).toBe(hinQuestion);
          }
        } catch (error) {
          console.warn(error);
        }
      });

      it('should return this.myAccountService.hintQuestion + "*" when this.myAccountService.hintQuestion equal to BcbsmaConstants.text.UNAVAILABLE', () => {
        try {
          // arrange

          fixture = TestBed.createComponent(FpConfirmidentityComponent);
          component = fixture.componentInstance;

          // act

          const hinQuestion = mockMyAccountService.hintQuestion;
          const unavailableText = BcbsmaConstants.text.UNAVAILABLE;
          component.getHintQuestionText();

          // assert
          if (hinQuestion === unavailableText) {
            expect(mockMyAccountService.hintQuestion).toBe(hinQuestion + '*');
          }
        } catch (error) {
          console.warn(error);
        }
      });
    });
  });
});
