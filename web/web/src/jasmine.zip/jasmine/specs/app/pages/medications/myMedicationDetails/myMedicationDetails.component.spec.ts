import { CommonModule, TitleCasePipe } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatCardModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatListModule,
  MatNativeDateModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { StorageServiceModule } from 'angular-webstorage-service';
import { FilterPipe, FilterPipeModule } from 'ngx-filter-pipe';
import { OrderModule } from 'ngx-order-pipe';
import { MaterialModule } from '../../../../../../app/material.module';
import { MyMedicationDetailsService } from '../../../../../../app/pages/medications/myMedicationDetails/my-medication-details.service';
import { MyMedicationDetailsComponent } from '../../../../../../app/pages/medications/myMedicationDetails/myMedicationDetails.component';
import { CasingForFilterPipe } from '../../../../../../app/shared/pipes/casingForFilter/casingForFilter.pipe';
import { YyyymmddTommddyyyyPipe } from '../../../../../../app/shared/pipes/date/yyyymmdd-to-mmddyyyy.pipe';
import { PhonePipe } from '../../../../../../app/shared/pipes/phone/phone.pipe';
import { MedicationsService } from '../../../../../../app/shared/services/medications/medications.service';
import { AlertService, AuthService, ConstantsService } from '../../../../../../app/shared/shared.module';
import { mocks } from '../../../../../constants/mocks.service';
import { FakeBreadcrumbsComponent, FakeFpoLayoutComponent } from '../../../../../fake-components';
import { FakeCellAspectRatioDirectiveStub } from '../../../../../fake-directives';

xdescribe('MyMedicationDetailsComponent', () => {
  let component: MyMedicationDetailsComponent;
  let fixture: ComponentFixture<MyMedicationDetailsComponent>;

  let mockMyMedicationDetailsService;
  let mockRouter;
  let mockAlertService;
  let mockMedicationsService;
  let mockConstantsService;
  let mockAuthService;

  beforeEach(async(() => {
    mockMedicationsService = mocks.service.medicationService;
    mockAuthService = mocks.service.authService;
    mockRouter = mocks.service.router;
    mockConstantsService = mocks.service.constantsService;
    mockMyMedicationDetailsService = mocks.service.medicationDetailsService;
    mockAlertService = mocks.service.alertService;

    TestBed.configureTestingModule({
      imports: [
        BrowserAnimationsModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        StorageServiceModule,
        HttpClientTestingModule,

        MatDatepickerModule,
        MatNativeDateModule,
        MatFormFieldModule,
        MatRadioModule,
        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatDialogModule,
        MatExpansionModule,
        MatListModule,
        MatButtonModule,
        MaterialModule,
        FilterPipeModule,
        OrderModule
      ],
      declarations: [
        FakeBreadcrumbsComponent,
        FakeFpoLayoutComponent,
        FakeCellAspectRatioDirectiveStub,

        CasingForFilterPipe,
        PhonePipe,
        YyyymmddTommddyyyyPipe,

        MyMedicationDetailsComponent
      ],
      providers: [
        { provide: MedicationsService, useValue: mockMedicationsService },
        { provide: AuthService, useValue: mockAuthService },
        { provide: Router, useValue: mockRouter },
        { provide: ConstantsService, useValue: mockConstantsService },
        { provide: MyMedicationDetailsService, useValue: mockMyMedicationDetailsService },
        { provide: AlertService, useValue: mockAlertService },
        FilterPipe,
        TitleCasePipe,
        CasingForFilterPipe,
        PhonePipe,
        YyyymmddTommddyyyyPipe
      ]
    }).compileComponents();
  }));

  describe('Constructor', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(MyMedicationDetailsComponent);
      component = fixture.componentInstance;
    });

    it('should create', () => {
      // assert
      expect(component).toBeTruthy();
    });

    describe('While Component Creation', () => {});
  });

  describe('ngOnInit', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(MyMedicationDetailsComponent);
      component = fixture.componentInstance;

      // act
      fixture.detectChanges();
    });
    describe('should have initialized', () => {});

    describe('should have called', () => {});
  });
});
