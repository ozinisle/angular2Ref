import { CommonModule, DatePipe } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ChangeDetectorRef, ElementRef } from '@angular/core';
import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatCardModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatListModule,
  MatNativeDateModule,
  MatRadioModule,
  MatSelectionList,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute, Router } from '@angular/router';
import { StorageServiceModule } from 'angular-webstorage-service';
import * as deepEqual from 'deep-equal';
import moment = require('moment');
import { MaterialModule } from '../../../../../../app/material.module';
import { ClaimsService } from '../../../../../../app/pages/myclaims/claims.service';
import { DateSearchListInterface } from '../../../../../../app/pages/myclaims/models/interfaces/claims-generic-models.interface';
import { ClaimsComponent } from '../../../../../../app/pages/myclaims/myclaims/claims.component';
import { DateSearchList } from '../../../../../../app/pages/myeobs/models/claims-generics.model';
import { AlertType } from '../../../../../../app/shared/alerts/alertType.model';
import { ClaimidPipe } from '../../../../../../app/shared/pipes/claimid/claimid.pipe';
import { DependantsService } from '../../../../../../app/shared/services/dependant.service';
import { FilterService } from '../../../../../../app/shared/services/filter.service';
import { GlobalService } from '../../../../../../app/shared/services/global.service';
import { AlertService, AuthService, ConstantsService, ValidationService, SharedModule } from '../../../../../../app/shared/shared.module';
import { environment } from '../../../../../../environments/environment';
import { mocks } from '../../../../../constants/mocks.service';
import { getclaimssummary_response } from '../../../../../data/myClaims/getclaimssummary.data';
import { FakeBreadcrumbsComponent, FakeFpoLayoutComponent, FakeSpinnerComponent } from '../../../../../fake-components';
import {
  FakeCellAspectRatioDirectiveStub,
  FakeFromRootDirectiveStub,
  FakeInfiniteScrollContainerDirectiveStub,
  FakeInfiniteScrollDirectiveStub,
  FakeInfiniteScrollDisabledDirectiveStub,
  FakeInfiniteScrollDistanceDirectiveStub,
  FakeInfiniteScrollThrottleDirectiveStub,
  FakeInfiniteScrollUpDistanceDirectiveStub,
  FakescrolledDirectiveStub,
  FakeScrolledUpDirectiveStub,
  FakeScrollWindowDirectiveStub
} from '../../../../../fake-directives';
import { PromoImagesComponent } from '../../../../../../app/shared/components/promo/promo-images/promo-images.component';

// ***********************************************************
// NOTE
// ***********************************************************
// Dead code Identified:
//   Methdod getDependantMedicationCount() is a dead code
//   Methdod transformClaimsData is a dead code
// setSortFiltervalue
// clearSessionStorageItems
// clearFilterList
// sortFilterChanged
// claimsErrorMessage
// getSelectedSort
// saveFilterDetails
// fromDateChange
// clearSearchVal
// customDateInputKeyDownEvent
// getDefaultClaimsStatusList
// getDefaultPlanList
// onSelectionChange
// selectAllOptions
// checkSelectAllOptionIfAllSelected
// unCheckSelectAllOption
// setShowClearLink
// sortFilterChanged
// toDateChange
// ***********************************************************

describe('ClaimsComponent', () => {
  let component: ClaimsComponent;
  let fixture: ComponentFixture<ClaimsComponent>;

  let mockRouter;
  let mockActivatedRoute;
  let mockAlertService;
  let mockValidationService;
  let mockConstantsService;
  let mockGlobalService;
  let mockAuthService;
  let mockDependantsService;
  let mockFilterService;
  let mockClaimsService;
  let mockChangeDetectionRef;

  let newAuthServiceMock;

  beforeEach(async(() => {
    mockActivatedRoute = {
      snapshot: {
        data: {
          claimsInfo: getclaimssummary_response
        }
      }
    };

    mockRouter = mocks.service.router;
    mockAlertService = mocks.service.alertService;
    mockValidationService = mocks.service.validationService;
    mockConstantsService = mocks.service.constantsService;
    mockAuthService = mocks.service.authService;
    mockGlobalService = mocks.service.globalService;
    mockDependantsService = mocks.service.dependantsService;
    mockFilterService = mocks.service.filterService;
    mockClaimsService = mocks.service.claimsService;
    mockChangeDetectionRef = mocks.service.changeDetectionRef;

    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        StorageServiceModule,
        HttpClientTestingModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatFormFieldModule,
        MatRadioModule,
        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatDialogModule,
        MatExpansionModule,
        MatListModule,
        MatButtonModule,
        MaterialModule
      ],

      declarations: [
        FakeBreadcrumbsComponent,
        FakeFpoLayoutComponent,
        FakeSpinnerComponent,
        FakeCellAspectRatioDirectiveStub,
        FakeInfiniteScrollUpDistanceDirectiveStub,
        FakeScrollWindowDirectiveStub,
        FakeInfiniteScrollDirectiveStub,
        FakeInfiniteScrollContainerDirectiveStub,
        FakeFromRootDirectiveStub,
        FakeInfiniteScrollDistanceDirectiveStub,
        FakeInfiniteScrollThrottleDirectiveStub,
        FakeInfiniteScrollDisabledDirectiveStub,
        FakescrolledDirectiveStub,
        FakeScrolledUpDirectiveStub,
        PromoImagesComponent,
        ClaimidPipe,
        ClaimsComponent
      ],

      providers: [
        { provide: Router, useValue: mockRouter },
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: AlertService, useValue: mockAlertService },
        { provide: ValidationService, useValue: mockValidationService },
        { provide: ConstantsService, useValue: mockConstantsService },
        { provide: GlobalService, useValue: mockGlobalService },
        { provide: AuthService, useValue: mockAuthService },
        { provide: DependantsService, useValue: mockDependantsService },
        { provide: FilterService, useValue: mockFilterService },
        { provide: ClaimsService, useValue: mockClaimsService },
        { provide: ChangeDetectorRef, useValue: mockChangeDetectionRef },
        DatePipe
      ]
    }).compileComponents();
  }));

  describe('Constructor', () => {
    it('should create', () => {
      // arrange
      fixture = TestBed.createComponent(ClaimsComponent);
      // act
      component = fixture.componentInstance;
      // assert
      expect(component).toBeTruthy();
    });

    describe('While Component Creation', () => {
      it('should have initialized this.claimsInfo to this.activatedRoute.snapshot.data.claimsInfo', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);

        // act
        component = fixture.componentInstance;
        const result = deepEqual(component['claimsInfo'], mockActivatedRoute.snapshot.data.claimsInfo);

        // assert
        expect(result).toBeTruthy();
      });

      //#region jasmine-bug
      // it('should have initialized this.initialClaimsCount to this.claimsInfo[0].memberRecord.length, when this.claimsInfo[0].memberRecord is valid', () => {
      //   //arrange
      //   ClaimsComponent.prototype.initialClaimsCount = 0;  //assuming this is a jasmine bug with number data types that renders them as undefined if not initialized
      //   mockActivatedRoute.snapshot.data.claimsInfo = mockActivatedRoute.snapshot.data.claimsInfo ?
      //     mockActivatedRoute.snapshot.data.claimsInfo = [mockActivatedRoute.snapshot.data.claimsInfo]
      //     : [{ memberRecord: [] }];
      //   mockActivatedRoute.snapshot.data.claimsInfo[0].memberRecord = mockActivatedRoute.snapshot.data.claimsInfo[0].memberRecord ? mockActivatedRoute.snapshot.data.claimsInfo[0].memberRecord : [];
      //   mockActivatedRoute.snapshot.data.claimsInfo[0].memberRecord.unshift('sampleValidText');

      //   TestBed.configureTestingModule({
      //     providers: [
      //       { provide: ActivatedRoute, useValue: mockActivatedRoute }
      //     ]
      //   })
      //     .compileComponents();
      //   fixture = TestBed.createComponent(ClaimsComponent);
      //   //act
      //   component = fixture.componentInstance;
      //   //assert
      //   expect(component.initialClaimsCount).toBe(mockActivatedRoute.snapshot.data.claimsInfo[0].memberRecord.length);
      // });

      // it('should have not changed this.initialClaimsCount, when this.claimsInfo[0].memberRecord is invalid', () => {
      //   //arrange
      //   ClaimsComponent.prototype.initialClaimsCount = 0;  //assuming this is a jasmine bug with number data types that renders them as undefined if not initialized
      //   mockActivatedRoute.snapshot.data.claimsInfo = [{}];
      //   fixture = TestBed.createComponent(ClaimsComponent);
      //   //act
      //   component = fixture.componentInstance;
      //   //assert
      //   expect(component.initialClaimsCount).toEqual(0);
      // });
      //#endregion

      it('should have initialized this.sortSelectedFilter to "Most Recent"', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(component.sortSelectedFilter).toBe('Most Recent');
      });

      it('should have initialized this.currentSortValue to this.sortSelectedFilter', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(component['currentSortValue']).toBe(component.sortSelectedFilter);
      });

      it('should have initialized this.isautosearch to false', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(component['isautosearch']).toBeFalsy();
      });

      it('should have initialized this.isDisplayMessage to false', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(component.isDisplayMessage).toBeFalsy();
      });

      it('should have initialized this.issearchShowing to false', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(component['issearchShowing']).toBeFalsy();
      });

      it('should have initialized this.showDate to false', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(component['showDate']).toBeFalsy();
      });

      it('should have initialized this.sideNavMode to be "side"', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(component['sideNavMode']).toBe('side');
      });

      it('should have initialized this.index to be "-1"', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(component['index']).toBe(-1);
      });

      it('should have initialized this.isSidenavOpened to false', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(component.isSidenavOpened).toBeFalsy();
      });

      it('should have initialized this.errorMessage to be "null"', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(component.errorMessage).toBeNull();
      });

      it('should have initialized this.collapsedHeight to be "32px"', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(component.collapsedHeight).toBe('32px');
      });

      it('should have initialized this.collapsedSortHeight to be "48px"', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(component.collapsedSortHeight).toBe('48px');
      });

      it('should have initialized expandedHeight.collapsedHeight to be "40px"', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(component.expandedHeight).toBe('40px');
      });

      it('should have initialized expandedSortHeight.collapsedHeight to be "48px"', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(component.expandedSortHeight).toBe('48px');
      });

      it('should have initialized this.isexpanded to false', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(component['isexpanded']).toBeFalsy();
      });

      it('should have initialized this.showCalender to false', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(component.showCalender).toBeFalsy();
      });

      it('should have initialized this.isSortExpanded to false', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(component.isSortExpanded).toBeFalsy();
      });

      it('should have initialized this.ismobile to true if window.innerWidth <= this.mobileViewPort', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        if (window.innerWidth <= component.mobileViewPort) {
          expect(component.ismobile).toBeTruthy();
        } else {
          expect(component.ismobile).toBeFalsy();
        }
      });

      it('should have initialized this.sideNavStatus to "out" if this.ismobile is true', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        if (window.innerWidth <= component.mobileViewPort) {
          expect(component.sideNavStatus).toBe('out');
        } else {
          expect(component.sideNavStatus).toBe('in');
        }
      });

      it('should have initialized this.dependentList to this.authService.getDependentsList()', () => {
        // this.dependentList = this.authService.getDependentsList();
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(component['dependentList']).toBe(mockAuthService.getDependentsList());
      });

      // this.subscription = this.globalService.memberData$.subscribe(data => {
      //   this.memberData = data;
      // });

      it('should have initialized this.isUserStateActive to true if this.authService.fetchUserState() === "Active"', () => {
        // arrange
        mockAuthService.fetchUserState.and.returnValue('Active');
        TestBed.configureTestingModule({
          providers: [{ provide: AuthService, useValue: mockAuthService }]
        }).compileComponents();
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(component.isUserStateActive).toBeTruthy();
      });

      it('should have initialized this.isUserStateActive to false if this.authService.fetchUserState() === "InActive"', () => {
        // arrange
        mockAuthService.fetchUserState.and.returnValue('InActive');
        TestBed.configureTestingModule({
          providers: [{ provide: AuthService, useValue: mockAuthService }]
        }).compileComponents();

        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(component.isUserStateActive).toBeFalsy();
      });

      it('should call sessionStorage.removeItem once if sessionStorage.getItem returns valid value', () => {
        // arrange
        spyOn(sessionStorage.__proto__, 'getItem').and.returnValue('validValue');
        spyOn(sessionStorage.__proto__, 'removeItem');
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(sessionStorage.__proto__.removeItem).toHaveBeenCalledTimes(1);
      });

      it('should call sessionStorage.removeItem once if sessionStorage.getItem returns valid value', () => {
        // arrange
        spyOn(sessionStorage.__proto__, 'getItem').and.returnValue('');
        spyOn(sessionStorage.__proto__, 'removeItem');
        fixture = TestBed.createComponent(ClaimsComponent);
        // act
        component = fixture.componentInstance;
        // assert
        expect(sessionStorage.__proto__.removeItem).not.toHaveBeenCalled();
      });
    });
  });

  describe('ngOnInit', () => {
    let spyinitAllClaimsFilterOptions, spymanageClaimsListing, spyhandleFinanceLinksInSideBar;
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(ClaimsComponent);
      component = fixture.componentInstance;

      spyinitAllClaimsFilterOptions = spyOn<any>(component, 'initAllClaimsFilterOptions').and.returnValue(null);
      spymanageClaimsListing = spyOn<any>(component, 'manageClaimsListing').and.returnValue(null);
      spyhandleFinanceLinksInSideBar = spyOn<any>(component, 'handleFinanceLinksInSideBar').and.returnValue(null);
      spyOn(component['subscription'], 'unsubscribe').and.returnValue(null);
      sessionStorage.setItem('authToken', JSON.stringify({planTypes: []}));
      // act
      fixture.detectChanges();
    });

    describe('should have initialized', () => {
      it('should have updated this.isMedicareUser to true if userType is medicare or medex', () => {
        // arrange
        const userType = mockAuthService.authToken.userType ? mockAuthService.authToken.userType.toLowerCase() : '';

        // assert
        let result = false;
        if (userType === 'medicare' || userType === 'medex') {
          result = true;
          expect(result).toBeTruthy();
        } else {
          expect(result).toBeFalsy();
        }
      });
    });

    describe('should have called', () => {
      it('should have called this.initAllClaimsFilterOptions', () => {
        // assert
        expect(spyinitAllClaimsFilterOptions).toHaveBeenCalledTimes(1);
      });

      it('should have called this.manageClaimsListing', () => {
        // assert
        expect(spymanageClaimsListing).toHaveBeenCalledTimes(1);
      });

      it('should have called this.handleFinanceLinksInSideBar', () => {
        // assert
        expect(spyhandleFinanceLinksInSideBar).toHaveBeenCalledTimes(1);
      });
    });
  });

  describe('methods', () => {
    describe('handleFinanceLinksInSideBar', () => {
      describe('this.authService.authToken.isHEQ is true or false', () => {
        it('should update this.ssoFinancialLink as "/sso/alegeus" when false', () => {
          // arrange
          fixture = TestBed.createComponent(ClaimsComponent);
          component = fixture.componentInstance;

          // act
          fixture.detectChanges();
          // component['handleFinanceLinksInSideBar']();

          // assert
          expect(component['ssoFinancialLink']).toBe('/sso/alegeus');
        });
        describe('should update this.ssoFinancialLink as "/sso/heathequity" when true', () => {
          beforeEach(() => {
            // arrange

            newAuthServiceMock = Object.assign({}, mockAuthService);
            newAuthServiceMock.authToken.isHEQ = 'true';

            TestBed.overrideProvider(AuthService, { useValue: newAuthServiceMock });
            TestBed.compileComponents();

            // TestBed.configureTestingModule({
            //     providers: [
            //         { provide: AuthService, useValue: newAuthServiceMock }
            //     ]
            // })
            //     .compileComponents();
          });
          beforeEach(async () => {
            fixture = TestBed.createComponent(ClaimsComponent);
            const authService = fixture.debugElement.injector.get(AuthService);
            component = fixture.componentInstance;

            // act
            fixture.detectChanges();
            // component['handleFinanceLinksInSideBar']();
          });

          it('should assert to true', () => {
            // assert
            expect(component['ssoFinancialLink']).toBe('/sso/heathequity');
          });
        });
      });

      describe('this.authService.authToken.isALG is true or false', () => {
        describe('this.authService.authToken.isALG is true', () => {
          describe('this.authService.authToken.isHEQ is true or false', () => {
            describe('this.authService.authToken.isHEQ is true', () => {
              beforeEach(() => {
                // arrange
                newAuthServiceMock = Object.assign({}, mockAuthService);
                newAuthServiceMock.authToken.isALG = 'true';
                newAuthServiceMock.authToken.isHEQ = 'true';

                TestBed.overrideProvider(AuthService, { useValue: newAuthServiceMock });
                TestBed.compileComponents();

                // TestBed.configureTestingModule({
                //     providers: [
                //         { provide: AuthService, useValue: newAuthServiceMock }
                //     ]
                // })
                //     .compileComponents();
              });
              beforeEach(async () => {
                fixture = TestBed.createComponent(ClaimsComponent);
                component = fixture.componentInstance;

                // act
                fixture.detectChanges();
                // component['handleFinanceLinksInSideBar']();
              });
              it('should update this.showHEQALGFinancialLink as true', () => {
                // assert
                expect(component.showHEQALGFinancialLink).toBeTruthy();
              });
              it('should update this.showFinancialLink as false', () => {
                // assert
                expect(component.showFinancialLink).toBeFalsy();
              });
            });
            describe('this.authService.authToken.isHEQ is false', () => {
              beforeEach(() => {
                // arrange
                newAuthServiceMock = Object.assign({}, mockAuthService);
                newAuthServiceMock.authToken.isALG = 'true';
                newAuthServiceMock.authToken.isHEQ = 'false';

                TestBed.overrideProvider(AuthService, { useValue: newAuthServiceMock });
                TestBed.compileComponents();

                // TestBed.configureTestingModule({
                //     providers: [
                //         { provide: AuthService, useValue: newAuthServiceMock }
                //     ]
                // })
                //     .compileComponents();
              });
              beforeEach(async () => {
                fixture = TestBed.createComponent(ClaimsComponent);
                component = fixture.componentInstance;

                // act
                component['handleFinanceLinksInSideBar']();
              });
              it('should update this.showHEQALGFinancialLink as false', () => {
                // assert
                expect(component.showHEQALGFinancialLink).toBeFalsy();
              });
              it('should update this.showFinancialLink as true', () => {
                // assert
                expect(component.showFinancialLink).toBeTruthy();
              });
            });
          });
        });
        describe('this.authService.authToken.isALG is false', () => {
          describe('this.authService.authToken.isHEQ is true or false', () => {
            describe('this.authService.authToken.isHEQ is true', () => {
              beforeEach(() => {
                newAuthServiceMock = Object.assign({}, mockAuthService);
                newAuthServiceMock.authToken.isALG = 'false';
                newAuthServiceMock.authToken.isHEQ = 'true';

                TestBed.overrideProvider(AuthService, { useValue: newAuthServiceMock });
                TestBed.compileComponents();

                // TestBed.configureTestingModule({
                //     providers: [
                //         { provide: AuthService, useValue: newAuthServiceMock }
                //     ]
                // })
                //     .compileComponents();
              });
              beforeEach(async () => {
                // arrange
                fixture = TestBed.createComponent(ClaimsComponent);
                component = fixture.componentInstance;

                // act
                fixture.detectChanges();
                // component['handleFinanceLinksInSideBar']();
              });
              it('should update this.showHEQALGFinancialLink as false', () => {
                // assert
                expect(component.showHEQALGFinancialLink).toBeFalsy();
              });
              it('should update this.showFinancialLink as true', () => {
                // assert
                expect(component.showFinancialLink).toBeTruthy();
              });
            });
            describe('this.authService.authToken.isHEQ is false', () => {
              beforeEach(() => {
                newAuthServiceMock = Object.assign({}, mockAuthService);
                newAuthServiceMock.authToken.isALG = 'false';
                newAuthServiceMock.authToken.isHEQ = 'false';

                TestBed.overrideProvider(AuthService, { useValue: newAuthServiceMock });
                TestBed.compileComponents();

                // TestBed.configureTestingModule({
                //     providers: [
                //         { provide: AuthService, useValue: newAuthServiceMock }
                //     ]
                // })
                //     .compileComponents();
              });
              beforeEach(async () => {
                // arrange
                fixture = TestBed.createComponent(ClaimsComponent);
                component = fixture.componentInstance;

                // act
                fixture.detectChanges();
                // component['handleFinanceLinksInSideBar']();
              });
              it('should update this.showHEQALGFinancialLink as false', () => {
                // assert
                expect(component.showHEQALGFinancialLink).toBeFalsy();
              });
              it('should update this.showFinancialLink as false', () => {
                // assert
                expect(component.showFinancialLink).toBeFalsy();
              });
            });
          });
        });
      });
    });

    describe('openSSO', () => {
      it('should open this.ssoFinancialLink link in new window when called with "algOrHeq"', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        // act
        component.openSSO('algOrHeq');
        // assert
        expect(sessionStorage.getItem('consentLink')).toEqual('/sso/heathequity');
      });
      it('should open "/sso/alegeus" link in new window when called with "alg"', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        // act
        component.openSSO('alg');
        // assert
        expect(sessionStorage.getItem('consentLink')).toEqual('/sso/alegeus');
      });
      it('should open "/sso/heathequity" link in new window when called with "heq"', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        // act
        component.openSSO('heq');
        // assert
        expect(sessionStorage.getItem('consentLink')).toEqual('/sso/heathequity');
      });
      it('should open "/sso/connecture" link in new window when called with "connecture"', () => {
        // arrange
        const spyWindowOpen = spyOn(window, 'open');
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        // act
        component.openSSO('connecture');
        // assert
        expect(spyWindowOpen).toHaveBeenCalledWith('/sso/connecture', '_blank');
      });
    });

    describe('formattedData', () => {
      it('should process input valid string date and return string value in MM/dd/yyyy format', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;

        // act
        const result = component.formattedData('28 Dec 2018');

        // assert
        expect(result).toBe('12/28/2018');
      });

      it('should error out if input param is not a valid string with valid date value', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;

        // act
        let error;
        try {
          const result = component.formattedData('InvalidDateValueToForceAnError $%^&*()#@!');
        } catch (Exception) {
          error = Exception;
        }

        // assert
        expect(error).toBeTruthy();
      });

      it('should error out if input param is null', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;

        // act
        let error;
        try {
          const result = component.formattedData(null);
        } catch (Exception) {
          error = Exception;
        }

        // assert
        expect(error).toBeTruthy();
      });
      it('should error out if input param is undefined', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;

        // act
        let error;
        try {
          let input: string;
          const result = component.formattedData(input);
        } catch (Exception) {
          error = Exception;
        }

        // assert
        expect(error).toBeTruthy();
      });
    });

    describe('isSortOpened', () => {
      it('should update component.isSortExpanded as true', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;

        // act
        component.isSortOpened();

        // assert
        expect(component.isSortExpanded).toBeTruthy();
      });
    });

    describe('isSortClosed', () => {
      it('should update component.isSortExpanded as false', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;

        // act
        component.isSortClosed();

        // assert
        expect(component.isSortExpanded).toBeFalsy();
      });
    });

    describe('ngOnDestroy', () => {
      it('should have called this subscription.unsubscribe', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        spyOn(component['subscription'], 'unsubscribe').and.returnValue(null);

        // act
        component.ngOnDestroy();

        // assert
        expect(component['subscription'].unsubscribe).toHaveBeenCalled();
      });
      it('should have called this.alertService.clearError', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        // act
        component.ngOnDestroy();

        // assert
        expect(mockAlertService.clearError).toHaveBeenCalled();
      });
    });

    describe('toggleFilter', () => {
      beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
      });

      it('should have toggled the value of this.isSidenavOpened', () => {
        // act
        component.toggleFilter(false);

        // assert
        expect(component.isSidenavOpened).toBeTruthy();
      });

      it('should set this.sideNavStatus as "in" if this.sideNavStatus===out', () => {
        // arrange
        fixture.detectChanges();

        // act
        component.sideNavStatus = 'out';
        component.toggleFilter('');

        // assert
        expect(component.sideNavStatus).toBe('in');
      });

      it('should assigned this.sideNavStatus as "out" if sideNavStatus this.sideNavStatus===in ', () => {
        // arrange
        fixture.detectChanges();

        // act
        component.sideNavStatus = 'in';
        component.toggleFilter('');

        // assert
        expect(component.sideNavStatus).toBe('out');
      });

      it('should update this.sideNavMode to "over" if window.innerWidth <= 992 else "side"', () => {
        // act
        component.toggleFilter('');

        // assert
        if (window.innerWidth <= 992) {
          expect(component['sideNavMode']).toBe('over');
        } else {
          expect(component['sideNavMode']).toBe('side');
        }
      });
    });

    describe('closeSideNavigation', () => {
      it('should update component.isSidenavOpned as false', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;

        // act
        component.closeSideNavigation();

        // assert
        expect(component.isSidenavOpened).toBeFalsy();
      });
    });

    describe('closeFilter', () => {
      beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
      });
      it('should update this.sideNavStatus as out when this.ismobile==true', () => {
        // act
        component.ismobile = true;
        component.closeFilter();

        // assert
        expect(component.sideNavStatus).toBe('out');
      });
      it('should update this.isSidenavOpened as false when this.ismobile==true', () => {
        // act
        component.ismobile = true;
        component.closeFilter();

        // assert
        expect(component.isSidenavOpened).toBeFalsy();
      });
    });

    describe('isOpened', () => {
      beforeEach(function() {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
      });

      it('should update this.step[1] to 1', () => {
        // act
        component.isOpened(1);
        // assert
        expect(component.step[1]).toBe(1);
      });

      it('should update this.step[2] to 2', () => {
        // act
        component.isOpened(2);
        // assert
        expect(component.step[2]).toBe(2);
      });

      it('should update this.step[3] to 3', () => {
        // act
        component.isOpened(3);
        // assert
        expect(component.step[3]).toBe(3);
      });

      it('should update this.step[4] to 4', () => {
        // act
        component.isOpened(4);
        // assert
        expect(component.step[4]).toBe(4);
      });

      it('should update this.step[5] to 5', () => {
        // act
        component.isOpened(5);
        // assert
        expect(component.step[5]).toBe(5);
      });

      it('should update this.step[6] to 6', () => {
        // act
        component.isOpened(6);
        // assert
        expect(component.step[6]).toBe(6);
      });
    });

    describe('showClaimDetails', () => {
      beforeEach(() => {
        spyOn(sessionStorage.__proto__, 'setItem');
      });

      it("should have called ['/myclaims/claimdetails']", () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;

        // act
        component.showClaimDetails('');

        // assert
        expect(mockRouter.navigate).toHaveBeenCalledWith(['/myclaims/claimdetails']);
      });
    });

    describe('dateFilterChanged', () => {
      beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;

        component['initAllClaimsFilterOptions']();
      });

      describe('when this.dateSelectedFilter is valid', () => {
        describe('when user does not select custom date range', () => {
          beforeEach(() => {
            component.dateSelectedFilter = { dateRange: 'All dates', dateCount: 14 };
          });
          it('should have called this.clearCustomDateRangeSelections', () => {
            // arrange
            spyOn(component, 'clearCustomDateRangeSelections');
            // act
            component.dateFilterChanged();
            // assert
            expect(component.clearCustomDateRangeSelections).toHaveBeenCalled();
          });
          it('should have set this.showCalendar to false', () => {
            // arrange
            component.dateSelectedFilter = { dateRange: 'All dates', dateCount: 14 };
            spyOn(component, 'clearCustomDateRangeSelections');
            // act
            component.dateFilterChanged();
            // assert
            expect(component.showCalender).toBeFalsy();
          });
          it('should not have changed this.showCalender ', () => {
            // arrange
            component.isDisplayCustomDateRange = true;
            spyOn(component, 'clearCustomDateRangeSelections');
            // act
            component.dateFilterChanged();
            // assert
            expect(component.isDisplayCustomDateRange).toBeTruthy();
          });
          it('should not updated this.fromDate to ""', () => {
            // arrange
            spyOn(component, 'clearCustomDateRangeSelections');
            // act
            component.dateFilterChanged();
            // assert
            expect(component.fromDate).toBe('');
          });
          it('should not updated this.isSelectedDateInvalid to false', () => {
            // arrange
            spyOn(component, 'clearCustomDateRangeSelections');
            // act
            component.dateFilterChanged();
            // assert
            expect(component.isSelectedDateInvalid).toBeFalsy();
          });
          it('should not updated this.isCustomDateRangeInValid to false', () => {
            // arrange
            spyOn(component, 'clearCustomDateRangeSelections');
            // act
            component.dateFilterChanged();
            // assert
            expect(component.isCustomDateRangeInValid).toBeFalsy();
          });
        });
        describe('whe user selects custom date range', () => {
          beforeEach(() => {
            component.dateSelectedFilter = { dateRange: 'Custom Date Range', dateCount: 0 };
          });
          it('should have called this.clearCustomDateRangeSelections', () => {
            // arrange

            spyOn(component, 'clearCustomDateRangeSelections');
            // act
            component.dateFilterChanged();
            // assert
            expect(component.clearCustomDateRangeSelections).not.toHaveBeenCalled();
          });
          it('should have called this.isDisplayCustomDateRange to true', () => {
            // arrange

            spyOn(component, 'clearCustomDateRangeSelections');
            // act
            component.dateFilterChanged();
            // assert
            expect(component.isDisplayCustomDateRange).toBeTruthy();
          });
          it('should not have changed this.showCalender ', () => {
            // arrange
            component.showCalender = true;
            spyOn(component, 'clearCustomDateRangeSelections');
            // act
            component.dateFilterChanged();
            // assert
            expect(component.showCalender).toBeTruthy();
          });
          it('should not updated this.fromDate to ""', () => {
            // arrange
            spyOn(component, 'clearCustomDateRangeSelections');
            // act
            component.dateFilterChanged();
            // assert
            expect(component.fromDate).toBe('');
          });
          it('should not updated this.isSelectedDateInvalid to false', () => {
            // arrange
            spyOn(component, 'clearCustomDateRangeSelections');
            // act
            component.dateFilterChanged();
            // assert
            expect(component.isSelectedDateInvalid).toBeFalsy();
          });
          it('should not updated this.isCustomDateRangeInValid to false', () => {
            // arrange
            spyOn(component, 'clearCustomDateRangeSelections');
            // act
            component.dateFilterChanged();
            // assert
            expect(component.isCustomDateRangeInValid).toBeFalsy();
          });
        });
      });

      describe('when this.dateSelectedFilter is in valid', () => {
        beforeEach(() => {
          component.dateSelectedFilter = null;
        });
        it('should have called this.clearCustomDateRangeSelections', () => {
          // arrange
          spyOn(component, 'clearCustomDateRangeSelections');
          // act
          component.dateFilterChanged();
          // assert
          expect(component.clearCustomDateRangeSelections).not.toHaveBeenCalled();
        });
        it('should not have modified this.isDisplayCustomDateRange ', () => {
          // arrange
          spyOn(component, 'clearCustomDateRangeSelections');
          component.isDisplayCustomDateRange = true;
          // act
          component.dateFilterChanged();
          // assert
          expect(component.isDisplayCustomDateRange).toBeTruthy();
        });
        it('should not have modified this.showCalender ', () => {
          // arrange
          component.showCalender = true;
          spyOn(component, 'clearCustomDateRangeSelections');
          // act
          component.dateFilterChanged();
          // assert
          expect(component.showCalender).toBeTruthy();
        });
      });

      it('should have not return any thing when called', () => {
        // arrange
        spyOn(component, 'clearCustomDateRangeSelections');
        // act
        component.dateSelectedFilter = { dateRange: 'All dates', dateCount: 14 };
        const result = component.dateFilterChanged();

        component.dateSelectedFilter = null;
        const result2 = component.dateFilterChanged();
        // assert
        expect(result).toBeUndefined();
        expect(result2).toBeUndefined();
      });
    });

    describe('validateFromDate', () => {
      beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
      });
      it('should have called this.filterService.getMinimumFromDate()', () => {
        // act
        component.validateFromDate();
        // assert
        expect(mockFilterService.getMinimumFromDate).toHaveBeenCalled();
      });
      it('should have updated this.isSelectedDateInvalid as per logic if this.fromDate is valid', () => {
        // arrange
        component.fromDate = 'Tue Oct 22 2019 17:50:19 GMT+0530 (India Standard Time)';
        // act
        component.validateFromDate();

        const minFormDate = new Date();
        minFormDate.setFullYear(minFormDate.getFullYear() - 2);

        const result =
          !component.fromDate ||
          component.fromDate.length !== 10 ||
          moment(component.fromDate, this.dateFormat).diff(moment(component.calendarMaxDate)) > 0 ||
          moment(component.fromDate, this.dateFormat).diff(moment(minFormDate)) < 0;

        // assert
        expect(component.isSelectedDateInvalid).toBe(result);
      });
      it('should have updated this.isSelectedDateInvalid to true if this.fromDate is invalid', () => {
        // arrange
        component.fromDate = null;
        // act
        component.validateFromDate();

        // assert
        expect(component.isSelectedDateInvalid).toBeTruthy();
      });
      it('should return this.isSelectedDateInvalid as per logic if this.fromDate is valid', () => {
        // arrange
        component.fromDate = 'Tue Oct 22 2019 17:50:19 GMT+0530 (India Standard Time)';
        // act
        const result = component.validateFromDate();

        const minFormDate = new Date();
        minFormDate.setFullYear(minFormDate.getFullYear() - 2);

        const asserter =
          !component.fromDate ||
          component.fromDate.length !== 10 ||
          moment(component.fromDate, this.dateFormat).diff(moment(component.calendarMaxDate)) > 0 ||
          moment(component.fromDate, this.dateFormat).diff(moment(minFormDate)) < 0;

        // assert
        expect(asserter).toBe(result);
      });
      it('should return this.isSelectedDateInvalid to true if this.fromDate is invalid', () => {
        // arrange
        component.fromDate = null;
        // act
        const result = component.validateFromDate();
        // assert
        expect(result).toBeTruthy();
      });
    });

    describe('validateToDate', () => {
      beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
      });
      it('should have called this.filterService.getMinimumFromDate()', () => {
        // act
        component.validateToDate();
        // assert
        expect(mockFilterService.getMinimumFromDate).toHaveBeenCalled();
      });
      it('should have updated this.isSelectedDateInvalid as per logic if this.toDate is valid', () => {
        // arrange
        component.toDate = 'Tue Oct 22 2019 17:50:19 GMT+0530 (India Standard Time)';
        // act
        component.validateToDate();

        const minFormDate = new Date();
        minFormDate.setFullYear(minFormDate.getFullYear() - 2);

        const result =
          !component.toDate ||
          moment(component.toDate, component['dateFormat']).diff(moment(component.calendarMaxDate)) > 0 ||
          moment(component.fromDate, component['dateFormat']).diff(moment(minFormDate)) < 0;

        // assert
        expect(component.isSelectedDateInvalid).toBe(result);
      });
      it('should have updated this.isSelectedDateInvalid to true if this.toDate is invalid', () => {
        // arrange
        component.toDate = null;
        // act
        component.validateToDate();

        // assert
        expect(component.isSelectedDateInvalid).toBeTruthy();
      });
      it('should return this.isSelectedDateInvalid as per logic if this.toDate is valid', () => {
        // arrange
        component.toDate = 'Tue Oct 22 2019 17:50:19 GMT+0530 (India Standard Time)';
        // act
        const result = component.validateToDate();

        const minFormDate = new Date();
        minFormDate.setFullYear(minFormDate.getFullYear() - 2);

        const asserter =
          !component.toDate ||
          moment(component.toDate, component['dateFormat']).diff(moment(component.calendarMaxDate)) > 0 ||
          moment(component.fromDate, component['dateFormat']).diff(moment(minFormDate)) < 0;

        // assert
        expect(asserter).toBe(result);
      });
      it('should return this.isSelectedDateInvalid to true if this.toDate is invalid', () => {
        // arrange
        component.toDate = null;
        // act
        const result = component.validateToDate();
        // assert
        expect(result).toBeTruthy();
      });
    });

    describe('validateCustomRange', () => {
      beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
      });
      it('should set this.isCustomDateRangeInValid to false if this.toDate>this.fromDate', () => {
        // arrange
        const toDate = new Date().getTime();
        component.fromDate = String(new Date(new Date().setTime(toDate - 100000)));
        component.toDate = String(new Date(new Date().setTime(toDate)));
        // act
        component.validateCustomRange();
        // assert
        expect(component.isCustomDateRangeInValid).toBeFalsy();
      });
      it('should set this.isCustomDateRangeInValid to true if this.toDate<this.fromDate', () => {
        // arrange
        const toDate = new Date().getTime();
        component.fromDate = String(new Date(new Date().setTime(toDate + 100000)));
        component.toDate = String(new Date(new Date().setTime(toDate)));
        // act
        component.validateCustomRange();
        // assert
        expect(component.isCustomDateRangeInValid).toBeTruthy();
      });
      it('should not change this.isCustomDateRangeInvalid if either this.toDate  is invalid', () => {
        // arrange
        component.toDate = null;
        component.isCustomDateRangeInValid = true;
        // act
        component.validateCustomRange();
        // assert
        expect(component.isCustomDateRangeInValid).toBeTruthy();
      });
      it('should not change this.isCustomDateRangeInvalid if either this.fromDate  is invalid', () => {
        // arrange
        component.fromDate = null;
        component.isCustomDateRangeInValid = true;
        // act
        component.validateCustomRange();
        // assert
        expect(component.isCustomDateRangeInValid).toBeTruthy();
      });
    });

    describe('clearCustomDateRangeSelections', () => {
      xit('should update component.toDate as L format', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;

        // act
        component.clearCustomDateRangeSelections();

        // assert
        expect(component.toDate).toBeFalsy();
      });
      it('should update component.fromDate as null', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;

        // act
        component.clearCustomDateRangeSelections();

        // assert
        expect(component.fromDate).toBeNull();
      });
      it('should update component.fromMinDate as null', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;

        // act
        component.clearCustomDateRangeSelections();

        // assert
        expect(component.fromMinDate).toBeNull();
      });
      it('should update component.isCustomDateRangeInValid as false', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;

        // act
        component.clearCustomDateRangeSelections();

        // assert
        expect(component.isCustomDateRangeInValid).toBeFalsy();
      });
      it('should update component.isSelectedDateInvalid as false', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;

        // act
        component.clearCustomDateRangeSelections();

        // assert
        expect(component.isSelectedDateInvalid).toBeFalsy();
      });
      it('should update component.isDisplayCustomDateRange as false', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;

        // act
        component.clearCustomDateRangeSelections();

        // assert
        expect(component.isDisplayCustomDateRange).toBeFalsy();
      });
    });

    describe('toggleCalender', () => {
      it("should call the toggleCalendarDisplay if isFormDateSelected=true and selectedDateType='to'", () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        spyOn(component, 'toggleCalendarDisplay');
        spyOn(component, 'setCalendarMinimumDate').and.returnValue('');

        // act
        component['isFormDateSelected'] = false;
        component.toggleCalender('to');

        // assert
        expect(component.toggleCalendarDisplay).not.toHaveBeenCalled();
      });

      it("should call the toggleCalendarDisplay if isFormDateSelected=false and selectedDateType='to'", () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        spyOn(component, 'toggleCalendarDisplay');
        spyOn(component, 'setCalendarMinimumDate').and.returnValue('');

        // act
        component['isFormDateSelected'] = true;
        component.toggleCalender('to');

        // assert
        expect(component.toggleCalendarDisplay).toHaveBeenCalled();
      });

      it("should upadte showCalender as true if isFormDateSelected=true and selectedDateType='from'", () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        spyOn(component, 'toggleCalendarDisplay');
        spyOn(component, 'setCalendarMinimumDate').and.returnValue('');

        // act
        component['isFormDateSelected'] = true;
        component.toggleCalender('from');

        // assert
        expect(component.showCalender).toBeTruthy();
      });

      it("should upadte showCalender as true if isFormDateSelected=false and selectedDateType='from'", () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        spyOn(component, 'toggleCalendarDisplay');
        spyOn(component, 'setCalendarMinimumDate').and.returnValue('');

        // act
        component['isFormDateSelected'] = false;
        component.toggleCalender('from');

        // assert
        expect(component.showCalender).toBeFalsy();
      });

      it('should call setCalendarMinimumDate', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        spyOn(component, 'toggleCalendarDisplay');
        spyOn(component, 'setCalendarMinimumDate').and.returnValue('');

        // act
        component.toggleCalender('');

        // assert
        expect(component.setCalendarMinimumDate).toHaveBeenCalled();
      });
    });

    describe('toggleCalendarDisplay', () => {
      it('should updated this.showCalender as false', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        component.fromInputDate = component.fromInputDate || {
          nativeElement: {
            focus: () => {}
          }
        };
        component.toInputDate = component.toInputDate || {
          nativeElement: {
            focus: () => {}
          }
        };

        // act
        component.toggleCalendarDisplay();

        // assert
        expect(component.showCalender).toBeFalsy();
      });

      it('should updated this.showCalender as true', fakeAsync(() => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        component.fromInputDate = component.fromInputDate || {
          nativeElement: {
            focus: () => {}
          }
        };
        component.toInputDate = component.toInputDate || {
          nativeElement: {
            focus: () => {}
          }
        };

        spyOn(component.fromInputDate.nativeElement, 'focus').and.returnValue(null);
        spyOn(component.toInputDate.nativeElement, 'focus').and.returnValue(null);

        // act
        component.toggleCalendarDisplay();
        tick(100);

        // assert
        fixture.whenStable().then(() => {
          expect(component.showCalender).toBeTruthy();
        });
      }));

      it('should call this.fromInputDate.nativeElement.focus() with a delay when this.isFormDateSelected is true', fakeAsync(() => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        component.fromInputDate = component.fromInputDate || {
          nativeElement: {
            focus: () => {}
          }
        };

        const spyFocus = spyOn(component.fromInputDate.nativeElement, 'focus').and.returnValue(null);
        // act
        component['isFormDateSelected'] = true;
        component.toggleCalendarDisplay();
        tick(100);
        // assert
        fixture.whenStable().then(() => {
          expect(spyFocus).toHaveBeenCalled();
        });
      }));

      it('should call this.toInputDate.nativeElement.focus() with a delay when this.isFormDateSelected is false', fakeAsync(() => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        component.toInputDate = component.toInputDate || {
          nativeElement: {
            focus: () => {}
          }
        };
        const spyFocus = spyOn(component.toInputDate.nativeElement, 'focus').and.returnValue(null);
        // act
        component['isFormDateSelected'] = false;
        component.toggleCalendarDisplay();
        tick(100);

        // assert
        fixture.whenStable().then(() => {
          expect(spyFocus).toHaveBeenCalled();
        });
      }));
    });

    describe('getSelectedValue', () => {
      beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        spyOn(component, 'setCalendarMinimumDate').and.returnValue('');
      });

      it('should updated this.isCustomDateRangeInValid as false', () => {
        // act
        component.getSelectedValue('mm/dd/yyyy');
        // assert
        expect(component.isCustomDateRangeInValid).toBeFalsy();
      });
      it('should updated this.isSelectedDateInvalid as false', () => {
        // act
        component.getSelectedValue('mm/dd/yyyy');
        // assert
        expect(component.isSelectedDateInvalid).toBeFalsy();
      });
      it('should assign this.fromDate = this.filterService.getFormatDateString(date) if this.isFormDateSelected as true ', () => {
        // arrange
        component['isFormDateSelected'] = true;
        // act
        component.getSelectedValue('mm/dd/yyyy');

        // assert
        expect(component.fromDate).toBe(mockFilterService.getFormatDateString(''));
      });
      it('should assign this.toDate = this.filterService.getFormatDateString(date) if this.isFormDateSelected as false ', () => {
        // arrange
        component['isFormDateSelected'] = false;
        // act
        component.getSelectedValue('mm/dd/yyyy');
        // assert
        expect(component.toDate).toBe(mockFilterService.getFormatDateString(''));
      });
      it('should have called component.setCalendarMinimumDate', () => {
        // act
        component.getSelectedValue('mm/dd/yyyy');
        // assert
        expect(component.setCalendarMinimumDate).toHaveBeenCalled();
      });
      it('should updated this.showCalender as false', () => {
        // act
        component.getSelectedValue('mm/dd/yyyy');
        // assert
        expect(component.showCalender).toBeFalsy();
      });
    });

    describe('setCalendarMinimumDate', () => {
      beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
      });
      it('should update this.fromMinDate to date object of this.fromDate if this.fromDate is valid and this.isFormDateSelected is false', () => {
        // arrange
        component['isFormDateSelected'] = false;
        component.fromDate = String(new Date());
        // act
        component.setCalendarMinimumDate();
        // assert
        expect(component.fromMinDate.getTime()).toBe(new Date(component.fromDate).getTime());
      });
      describe('should do the following otherwise', () => {
        it('should call this.filterService.getMinimumFromDate', () => {
          // arrange
          component['isFormDateSelected'] = true;
          // act
          component.setCalendarMinimumDate();
          // assert
          expect(mockFilterService.getMinimumFromDate).toHaveBeenCalled();
        });
        it('should update this.fromMinDate to this.filterService.getMinimumFromDate()', () => {
          // arrange
          component['isFormDateSelected'] = true;
          // act
          component.setCalendarMinimumDate();
          const result = mockFilterService.getMinimumFromDate();
          // assert
          expect(component.fromMinDate).toBe(result);
        });
      });
    });

    describe('formatInputFromDate', () => {
      beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
      });
      it('should have called this.filterService.convertInputStringToDate with value::@Param', () => {
        // arramge
        component.fromDate = String(new Date());
        const param = String(new Date());
        spyOn(component, 'toggleCalendarDisplay').and.returnValue(null);
        // act
        component.formatInputFromDate(param);
        // assert
        expect(mockFilterService.convertInputStringToDate).toHaveBeenCalledWith(param);
      });
      it('should call this.validateFromDate if this.fromDate text length>10', () => {
        // arrange
        component.fromDate = String(new Date());
        const spy_validateFromDate = spyOn(component, 'validateFromDate').and.returnValue(null);
        spyOn(component, 'toggleCalendarDisplay').and.returnValue(null);
        // act
        component.formatInputFromDate(String(new Date()));
        // assert
        expect(spy_validateFromDate).toHaveBeenCalled();
      });
      describe('should do the following when this.fromDate text length>10', () => {
        beforeEach(() => {
          // arrange
          component.fromDate = String(new Date());
        });
        it('should call this.validateCustomRange ', () => {
          // arrange
          const spy_validateCustomRange = spyOn(component, 'validateCustomRange').and.returnValue(null);
          spyOn(component, 'toggleCalendarDisplay').and.returnValue(null);
          // act
          component.formatInputFromDate(String(new Date()));
          // assert
          expect(spy_validateCustomRange).toHaveBeenCalled();
        });

        describe('should do the following if this.isCustomDateRangeInValid and this.isSelectedDateInvalid are both false', () => {
          beforeEach(() => {
            // arrange
            component.isCustomDateRangeInValid = false;
            component.isSelectedDateInvalid = false;
            spyOn(component, 'validateFromDate');
            spyOn(component, 'validateCustomRange');
          });
          it('should have have updated this.currentSelectedDate', () => {
            // assert
            spyOn(component, 'toggleCalendarDisplay').and.returnValue(null);
            // act
            component.formatInputFromDate(String(new Date()));
            // assert
            expect(component.currentSelectedDate.getTime()).toBe(new Date(component.fromDate).getTime());
          });
          it('should have called this.toggleCalendarDisplay()', () => {
            // arrange
            const spy_toggleCalendarDisplay = spyOn(component, 'toggleCalendarDisplay').and.returnValue(null);
            // act
            component.formatInputFromDate(String(new Date()));
            // assert
            expect(spy_toggleCalendarDisplay).toHaveBeenCalled();
          });
        });
      });
    });

    describe('formatInputToDate', () => {
      beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
      });
      it('should have called this.filterService.convertInputStringToDate with value::@Param', () => {
        // arramge
        component.toDate = String(new Date());
        const param = String(new Date());
        spyOn(component, 'toggleCalendarDisplay').and.returnValue(null);
        // act
        component.formatInputToDate(param);
        // assert
        expect(mockFilterService.convertInputStringToDate).toHaveBeenCalledWith(param);
      });
      it('should call this.validateToDate if this.toDate text length>10', () => {
        // arrange
        component.toDate = String(new Date());
        const spyValidateToDate = spyOn(component, 'validateToDate').and.returnValue(null);
        spyOn(component, 'toggleCalendarDisplay').and.returnValue(null);
        // act
        component.formatInputToDate(String(new Date()));
        // assert
        expect(spyValidateToDate).toHaveBeenCalled();
      });
      describe('should do the following when this.toDate text length>10', () => {
        beforeEach(() => {
          // arrange
          component.toDate = String(new Date());
        });
        it('should call this.validateCustomRange ', () => {
          // arrange
          const spyValidateCustomRange = spyOn(component, 'validateCustomRange').and.returnValue(null);
          spyOn(component, 'toggleCalendarDisplay').and.returnValue(null);
          // act
          component.formatInputToDate(String(new Date()));
          // assert
          expect(spyValidateCustomRange).toHaveBeenCalled();
        });

        describe('should do the following if this.isCustomDateRangeInValid and this.isSelectedDateInvalid are both false', () => {
          beforeEach(() => {
            // arrange
            component.isCustomDateRangeInValid = false;
            component.isSelectedDateInvalid = false;
            spyOn(component, 'validateToDate');
            spyOn(component, 'validateCustomRange');
          });
          it('should have have updated this.currentSelectedDate', () => {
            // assert
            spyOn(component, 'toggleCalendarDisplay').and.returnValue(null);
            // act
            component.formatInputToDate(String(new Date()));
            // assert
            expect(component.currentSelectedDate.getTime()).toBe(new Date(component.toDate).getTime());
          });
          it('should have called this.toggleCalendarDisplay()', () => {
            // arrange
            const spy_toggleCalendarDisplay = spyOn(component, 'toggleCalendarDisplay').and.returnValue(null);
            // act
            component.formatInputToDate(String(new Date()));
            // assert
            expect(spy_toggleCalendarDisplay).toHaveBeenCalled();
          });
        });
      });
    });

    describe('getDefaultClaimsStatuses', () => {
      beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
      });
      it('should return an array with 5 elements', () => {
        // act
        const result = component.getDefaultClaimsStatuses();
        // assert
        expect(result.length).toBe(5);
      });
    });

    describe('openUrl', () => {
      it('should open component.contactus within broswer', () => {
        // arrange
        const spyWindowOpen = spyOn(window, 'open');
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        const url = 'sampleUrlString';

        // act
        component.openUrl();

        // assert
        expect(spyWindowOpen).toHaveBeenCalledWith(component['contactus'], '_self');
      });
    });

    describe('openUrlinNewWindow', () => {
      it('should have called window.open with this.constants.directPayUrl as the first parameter and "_self" as second param', () => {
        // arrange
        const spyWindowOpen = spyOn(window, 'open');
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        const url = 'sampleUrlString';
        // act
        component.openUrlinNewWindow(url);
        // assert
        expect(spyWindowOpen).toHaveBeenCalledWith(mockConstantsService.directPayUrl, '_blank');
      });
    });

    describe('trackByFn', () => {
      beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
      });
      it('should return claim.id when a valid claim with id is passed as second parameter', () => {
        // act
        const index = 0;
        const claim = { id: 'testClaimId' };
        const result = component.trackByFn(index, claim);
        // assert
        expect(result).toBe(claim.id);
      });
      it('should return undefined when a valid claim with no claim id is passed as parameter', () => {
        // act
        const index = 111;
        const claim = {};
        const result = component.trackByFn(index, claim);
        // assert
        expect(result).toBeUndefined();
      });
      it('should return index::@param when a invalid claim is passed as parameter', () => {
        // act
        const index = 222;
        const claim = null;
        const result = component.trackByFn(index, claim);
        // assert
        expect(result).toBe(222);
      });
    });

    describe('initAllClaimsFilterOptions', () => {
      beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        // act
        component['initAllClaimsFilterOptions']();
      });

      it('should have updated this.allClaimsFilterOptions with a valid plan', () => {
        // assert
        expect(component.allClaimsFilterOptions.plan).toBeTruthy();
      });

      it('should have updated this.allClaimsFilterOptions with a valid date', () => {
        // assert
        expect(component.allClaimsFilterOptions.date).toBeTruthy();
      });

      it('should have updated this.allClaimsFilterOptions with a valid member', () => {
        // assert
        expect(component.allClaimsFilterOptions.member).toBeTruthy();
      });

      it('should have updated this.allClaimsFilterOptions with a valid provider', () => {
        // assert
        expect(component.allClaimsFilterOptions.provider).toBeTruthy();
      });

      it('should have updated this.allClaimsFilterOptions with a valid visitType', () => {
        // assert
        expect(component.allClaimsFilterOptions.visitType).toBeTruthy();
      });

      it('should have updated this.allClaimsFilterOptions with a valid claimStatus', () => {
        // assert
        expect(component.allClaimsFilterOptions.claimStatus).toBeTruthy();
      });
    });

    describe('manageClaimsListing', () => {
      beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        component['claimsInfo'] = getclaimssummary_response;
        spyOn(component, 'manageClaimsFilter').and.returnValue(null);
      });

      describe('when called with invalid filterPaginationApiData', () => {
        describe('when this.claimsInfo is a valid array', () => {
          describe('when this.claimsInfo[0].result !==0', () => {
            it('should have updated this.claimsListing with this.claimsInfo[0]', () => {
              // arrange
              let filterPaginationApiData;
              // act
              component.manageClaimsListing(filterPaginationApiData);
              const result = deepEqual(component['claimsInfo'][0], component.claimsListing);
              // assert
              expect(result).toBeTruthy();
            });
            describe('when this.isClearFilter is not set', () => {
              it('should have updated this.recordsPerPage with this.claimsListing.summaryMetaData.recordEndIndex', () => {
                // arrange
                let filterPaginationApiData;
                component['isClearFilter'] = false;
                // act
                component.manageClaimsListing(filterPaginationApiData);
                const result = deepEqual(component['recordsPerPage'], component.claimsListing.summaryMetaData.recordEndIndex);
                // assert
                expect(result).toBeTruthy();
              });
              it('should have called this.manageClaimsFilter with this.claimsListing', () => {
                // arrange
                let filterPaginationApiData;
                component['isClearFilter'] = false;
                // act
                component.manageClaimsListing(filterPaginationApiData);
                // assert
                expect(component.manageClaimsFilter).toHaveBeenCalledWith(component.claimsListing);
              });
            });
            describe('when this.isClearFilter is  set', () => {
              it('should have updated this.recordsPerPage with this.claimsListing.summaryMetaData.recordEndIndex', () => {
                // arrange
                let filterPaginationApiData;
                component['isClearFilter'] = true;
                // act
                component.manageClaimsListing(filterPaginationApiData);
                const result = deepEqual(component['recordsPerPage'], component.claimsListing.summaryMetaData.recordEndIndex);
                // assert
                expect(result).toBeFalsy();
              });
              it('should have called this.manageClaimsFilter with this.claimsListing', () => {
                // arrange
                let filterPaginationApiData;
                component['isClearFilter'] = true;
                // act
                component.manageClaimsListing(filterPaginationApiData);
                // assert
                expect(component.manageClaimsFilter).not.toHaveBeenCalled();
              });
            });
          });
          xdescribe('when this.claimsInfo[0].result ===0', () => {
            it('should have called this.alertService.setAlert with params', () => {
              // arrange
              let filterPaginationApiData;
              component['claimsInfo'][0].__proto__.result = 0;
              // act
              component.manageClaimsListing(filterPaginationApiData);
              // assert
              expect(mockAlertService.setAlert).toHaveBeenCalledWith('', component['claimsInfo'][0]['displaymessage'], AlertType.Failure);
            });
          });
        });
      });

      describe('when called with valid filterPaginationApiData', () => {
        let filterPaginationApiData;
        beforeEach(() => {
          filterPaginationApiData = component['claimsInfo'][0];
          component.manageClaimsListing(filterPaginationApiData);
        });
        it('should have updated this.claimsListing with passed in parameter', () => {
          // arrange
          const result = deepEqual(filterPaginationApiData, component.claimsListing);
          // assert
          expect(result).toBeTruthy();
        });
      });

      describe('when this.claimsListing.memberRecord is a valid array', () => {
        it('should update this.filteredClaims with this.claimsListing.memberRecord', () => {
          // arrange
          let filterPaginationApiData;
          // act
          component.manageClaimsListing(filterPaginationApiData);
          const result = deepEqual(component.filteredClaims, component.claimsListing.memberRecord);
          // assert
          expect(result).toBeTruthy();
        });
        it('should update this.fpoTargetUrl with this.constants.drupalClaimsrUrl', () => {
          // arrange
          let filterPaginationApiData;
          // act
          component.manageClaimsListing(filterPaginationApiData);
          const result = deepEqual(component.fpoTargetUrl, component.constants.drupalClaimsrUrl);
          // assert
          expect(result).toBeTruthy();
        });
      });

      describe('when this.claimsListing.memberRecord is not a valid array with values', () => {
        beforeEach(() => {
          component['claimsInfo'][0].memberRecord = [];
        });
        it('should update this.noClaimsAvailable to true', () => {
          // arrange
          let filterPaginationApiData;
          // act
          component.manageClaimsListing(filterPaginationApiData);
          // assert
          expect(component.noClaimsAvailable).toBeTruthy();
        });
        it('should update this.fpoTargetUrl with this.constants.drupalNoClaimsrUrl', () => {
          // arrange
          let filterPaginationApiData;
          // act
          component.manageClaimsListing(filterPaginationApiData);
          const result = deepEqual(component.fpoTargetUrl, component.constants.drupalNoClaimsrUrl);
          // assert
          expect(result).toBeTruthy();
        });
      });

      it('should have updated this.fpoTargetListingUrl with environment.drupalTestUrl/page/mydoctors-listingscreen', () => {
        // arrange
        let filterPaginationApiData;
        // act
        component.manageClaimsListing(filterPaginationApiData);
        // assert
        expect(component.fpoTargetListingUrl).toBe(`${environment.drupalTestUrl}/page/mydoctors-listingscreen`);
      });
    });

    describe('manageClaimsFilter', () => {
      describe('should perform the following operation', () => {
        let filterPaginationApiData;
        beforeEach(() => {
          // arrange
          fixture = TestBed.createComponent(ClaimsComponent);
          component = fixture.componentInstance;
          component['claimsInfo'] = getclaimssummary_response;
          spyOn<any>(component, 'checkExistingClaimsFilterOptions');

          component['initAllClaimsFilterOptions']();
        });
        it('should update "this.allClaimsFilterOptions.member.all.memberCount" to "claimsListing.summaryMetaData.totalRecordCount" when called with "claimsListing" ', () => {
          // act
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          const result = deepEqual(
            component.allClaimsFilterOptions.member.all.memberCount,
            component.claimsListing.summaryMetaData.totalRecordCount
          );
          // assert
          expect(result).toBeTruthy();
        });
        it('should update "this.allClaimsFilterOptions.provider.all.providerCount" to "claimsListing.summaryMetaData.totalRecordCount" when called with "claimsListing" ', () => {
          // act
          //          component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          const result = deepEqual(
            component.allClaimsFilterOptions.provider.all.providerCount,
            component.claimsListing.summaryMetaData.totalRecordCount
          );
          // assert
          expect(result).toBeTruthy();
        });
        it('should update "this.allClaimsFilterOptions.visitType.all.visitTypeCount" to "claimsListing.summaryMetaData.totalRecordCount" when called with "claimsListing" ', () => {
          // act
          //          component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          const result = deepEqual(
            component.allClaimsFilterOptions.visitType.all.visitTypeCount,
            component.claimsListing.summaryMetaData.totalRecordCount
          );
          // assert
          expect(result).toBeTruthy();
        });
        it('should update "this.allClaimsFilterOptions.claimStatus.all.statusCount" to "claimsListing.summaryMetaData.totalRecordCount" when called with "claimsListing" ', () => {
          // act
          //          component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          const result = deepEqual(
            component.allClaimsFilterOptions.claimStatus.all.statusCount,
            component.claimsListing.summaryMetaData.totalRecordCount
          );
          // assert
          expect(result).toBeTruthy();
        });
        it('should update this.allClaimsFilterOptions.date.custom.dateCount with claimsListing.filtersMetadata.dateMetaData.customDateRange.customDateCount when called with "claimsListing"', () => {
          // arrange
          let result;
          // act
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          if (
            component.claimsListing.dateMetaData &&
            component.claimsListing.dateMetaData.customDateRange &&
            component.claimsListing.dateMetaData.customDateRange.customDateCount
          ) {
            result = deepEqual(
              component.allClaimsFilterOptions.date.custom.dateCount,
              component.claimsListing.dateMetaData.customDateRange.customDateCount
            );
            // assert
            expect(result).toBeTruthy();
          } else {
            result = false;
            // assert
            expect(result).toBeFalsy();
          }
        });
        it('should update this.membersList with claimsListing.filtersMetadata.memberTypeMetaData.memberTypeMetaList when called with "claimsListing"', () => {
          // act
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          const result = deepEqual(component.membersList, component.claimsListing.filtersMetadata.memberTypeMetaData.memberTypeMetaList);
          // assert
          expect(result).toBeTruthy();
        });
        it('should update this.providerList with claimsListing.filtersMetadata.memberTypeMetaData.memberTypeMetaList when called with "claimsListing"', () => {
          // act
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          const result = deepEqual(component.providerList, component.claimsListing.filtersMetadata.providerMetaData.providerMetaList);
          // assert
          expect(result).toBeTruthy();
        });
        it('should update this.visitTypeList with claimsListing.filtersMetadata.visitTypeMetaData.visitTypeMetaList when called with "claimsListing"', () => {
          // act
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          const result = deepEqual(component.visitTypeList, component.claimsListing.filtersMetadata.visitTypeMetaData.visitTypeMetaList);
          // assert
          expect(result).toBeTruthy();
        });

        it('should update this.claimsStatusList with claimsListing.filtersMetadata.claimStatusMetaData.claimStatusMetaList when called with "claimsListing"', () => {
          // act
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          const result = deepEqual(
            component.claimsStatusList,
            component.claimsListing.filtersMetadata.claimStatusMetaData.claimStatusMetaList
          );
          // assert
          expect(result).toBeTruthy();
        });

        it('should update this.dateList with claimsListing.filtersMetadata.dateMetaData.dateMetaList when called with "claimsListing"', () => {
          // act
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          const result = deepEqual(component.dateList, component.claimsListing.filtersMetadata.dateMetaData.dateMetaList);
          // assert
          expect(result).toBeTruthy();
        });

        it('should have called this.checkExistingClaimsFilterOptions 5 times', () => {
          // act
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          // assert
          expect(component['checkExistingClaimsFilterOptions']).toHaveBeenCalledTimes(5);
        });

        it('should have called this.checkExistingClaimsFilterOptions 5 times', () => {
          // act
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          // assert
          expect(component['checkExistingClaimsFilterOptions']).toHaveBeenCalledTimes(5);
        });

        it('should have called this.checkExistingClaimsFilterOptions with this.membersList, this.allClaimsFilterOptions.member.all.memberName', () => {
          // act
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          // assert
          expect(component['checkExistingClaimsFilterOptions']).toHaveBeenCalledWith(
            component.membersList,
            component.allClaimsFilterOptions.member.all.memberName
          );
        });

        it('should have called this.checkExistingClaimsFilterOptions with this.providerList, this.allClaimsFilterOptions.provider.all.providerName', () => {
          // act
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          // assert
          expect(component['checkExistingClaimsFilterOptions']).toHaveBeenCalledWith(
            component.providerList,
            component.allClaimsFilterOptions.provider.all.providerName
          );
        });

        it('should have called this.checkExistingClaimsFilterOptions with this.visitTypeList, this.allClaimsFilterOptions.visitType.all.visitType', () => {
          // act
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          // assert
          expect(component['checkExistingClaimsFilterOptions']).toHaveBeenCalledWith(
            component.visitTypeList,
            component.allClaimsFilterOptions.visitType.all.visitType
          );
        });

        it('should have called this.checkExistingClaimsFilterOptions with this.claimsStatusList, this.allClaimsFilterOptions.claimStatus.all.status', () => {
          // act
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          // assert
          expect(component['checkExistingClaimsFilterOptions']).toHaveBeenCalledWith(
            component.claimsStatusList,
            component.allClaimsFilterOptions.claimStatus.all.status
          );
        });

        it('should have called this.checkExistingClaimsFilterOptions with this.dateList, this.allClaimsFilterOptions.date.custom.dateRange', () => {
          // act
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          // assert
          expect(component['checkExistingClaimsFilterOptions']).toHaveBeenCalledWith(
            component.dateList,
            component.allClaimsFilterOptions.date.custom.dateRange
          );
        });
      });

      describe('should perform the following when this.checkExistingClaimsFilterOptions results false', () => {
        let filterPaginationApiData;
        beforeEach(() => {
          // arrange
          fixture = TestBed.createComponent(ClaimsComponent);
          component = fixture.componentInstance;
          component['claimsInfo'] = getclaimssummary_response;
          spyOn<any>(component, 'checkExistingClaimsFilterOptions').and.returnValue(false);
          component['initAllClaimsFilterOptions']();
        });

        it('should have added this.allClaimsFilterOptions.member.all to the this.membersList array', () => {
          // act
          component.membersList = [];
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          const result = deepEqual(component.membersList[component.membersList.length - 1], component.allClaimsFilterOptions.member.all);
          // assert
          expect(result).toBeTruthy();
        });

        it('should have added this.allClaimsFilterOptions.provider.all to the this.providerList array', () => {
          // act
          component.providerList = [];
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          const result = deepEqual(
            component.providerList[component.providerList.length - 1],
            component.allClaimsFilterOptions.provider.all
          );
          // assert
          expect(result).toBeTruthy();
        });

        it('should have added this.allClaimsFilterOptions.visitType.all to the this.visitTypeList array', () => {
          // act
          component.visitTypeList = [];
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          const result = deepEqual(
            component.visitTypeList[component.visitTypeList.length - 1],
            component.allClaimsFilterOptions.visitType.all
          );
          // assert
          expect(result).toBeTruthy();
        });

        it('should have added this.allClaimsFilterOptions.claimStatus.all to the this.claimsStatusList array', () => {
          // act
          component.claimsStatusList = [];
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          const result = deepEqual(
            component.claimsStatusList[component.claimsStatusList.length - 1],
            component.allClaimsFilterOptions.claimStatus.all
          );
          // assert
          expect(result).toBeTruthy();
        });

        it('should have added this.allClaimsFilterOptions.date.custom to the this.dateList array', () => {
          // act
          component.dateList = [];
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          const result = deepEqual(component.dateList[component.claimsStatusList.length - 1], component.allClaimsFilterOptions.date.custom);
          // assert
          expect(result).toBeTruthy();
        });
      });

      describe('should perform the following when this.checkExistingClaimsFilterOptions results true', () => {
        let filterPaginationApiData;
        beforeEach(() => {
          // arrange
          fixture = TestBed.createComponent(ClaimsComponent);
          component = fixture.componentInstance;
          component['claimsInfo'] = getclaimssummary_response;
          spyOn<any>(component, 'checkExistingClaimsFilterOptions').and.returnValue(true);
          component['initAllClaimsFilterOptions']();
        });

        it('should have not modified the this.membersList array', () => {
          // act
          const result = component['claimsInfo'][0].filtersMetadata.memberTypeMetaData.memberTypeMetaList.length;
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          // assert
          expect(component.membersList.length).toBe(result);
        });

        it('should have not modified the this.providerList array', () => {
          // act
          const result = component['claimsInfo'][0].filtersMetadata.providerMetaData.providerMetaList.length;
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          // assert
          expect(component.providerList.length).toBe(result);
        });

        it('should have not modified the this.visitTypeList array', () => {
          // act
          const result = component['claimsInfo'][0].filtersMetadata.visitTypeMetaData.visitTypeMetaList.length;
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          // assert
          expect(component.visitTypeList.length).toBe(result);
        });

        it('should have not modified the this.claimsStatusList array', () => {
          // act
          const result = component['claimsInfo'][0].filtersMetadata.claimStatusMetaData.claimStatusMetaList.length;
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          // assert
          expect(component.claimsStatusList.length).toBe(result);
        });

        it('should have not modified the this.dateList array', () => {
          // act
          const result = component['claimsInfo'][0].filtersMetadata.dateMetaData.dateMetaList.length;
          // component.manageClaimsFilter(claimsListing); - the method will be called internally when the following method is called
          component.manageClaimsListing(filterPaginationApiData);
          // assert
          expect(component.dateList.length).toBe(result);
        });
      });
    });

    describe('checkExistingClaimsFilterOptions', () => {
      it('should return the object whose value matches the second parameter in the array passed as first parameter', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        // act
        const result = component['checkExistingClaimsFilterOptions']([{ a: '1' }, { a: '2' }, { a: '3' }], '2');
        // assert
        expect(result.a).toBe('2');
      });
    });

    describe('manageSelectedClaimsFilter', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('checkClaimsFilterOptions', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('getSelectedClaimsFilterOptions', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('applyFilter', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('clearFilter', () => {
      let spy_closeFilter;
      let spy_clearCustomDateRangeSelections;
      let spy_clearFilterOptionsFromView;
      let spy_initClearFilterOptions;
      let spy_manageClaimsListing;
      let spy_closeSideNavigation;

      let element: ElementRef;
      let mockProviderList: MatSelectionList;
      let mockClaimStatusList: MatSelectionList;
      let mockVisitTypeList: MatSelectionList;
      let mockMemberList: MatSelectionList;

      class MockElementRef implements ElementRef {
        nativeElement: {};
      }

      beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;

        spy_closeFilter = spyOn(component, 'closeFilter').and.returnValue(null);
        spy_clearCustomDateRangeSelections = spyOn(component, 'clearCustomDateRangeSelections').and.returnValue(null);
        spy_clearFilterOptionsFromView = spyOn<any>(component, 'clearFilterOptionsFromView').and.returnValue(null);
        spy_initClearFilterOptions = spyOn<any>(component, 'initClearFilterOptions').and.returnValue(null);
        spy_manageClaimsListing = spyOn(component, 'manageClaimsListing').and.returnValue(null);
        spy_closeSideNavigation = spyOn(component, 'closeSideNavigation').and.returnValue(null);

        element = new MockElementRef();
        mockProviderList = new MatSelectionList(element, '1');
        mockClaimStatusList = new MatSelectionList(element, '1');
        mockVisitTypeList = new MatSelectionList(element, '1');
        mockMemberList = new MatSelectionList(element, '1');
      });
      describe('should have updated the values as follows', () => {
        beforeEach(() => {
          // act
          component.clearFilter(mockProviderList, mockClaimStatusList, mockVisitTypeList, mockMemberList);
        });
        it('should have updated this.step to []', () => {
          // arrange
          const result = deepEqual(component.step, []);
          // assert
          expect(result).toBeTruthy();
        });

        it('should have updated this.showClose to false', () => {
          // assert
          expect(component['showClose']).toBeFalsy();
        });

        it('should have updated this.showCalender to false', () => {
          // assert
          expect(component.showCalender).toBeFalsy();
        });

        it('should have updated this.showResultsCount to false', () => {
          // assert
          expect(component['showResultsCount']).toBeFalsy();
        });

        it('should have updated this.isSortExpanded to false', () => {
          // assert
          expect(component.isSortExpanded).toBeFalsy();
        });

        it('should have updated this.isClearFilter to true', () => {
          // assert
          expect(component['isClearFilter']).toBeTruthy();
        });

        it('should have updated this.isDisplayMessage to false', () => {
          // assert
          expect(component.isDisplayMessage).toBeFalsy();
        });

        it('should have updated this.isDisplayResults to false', () => {
          // assert
          expect(component.isDisplayResults).toBeFalsy();
        });

        it('should have updated this.showClearLink to false', () => {
          // assert
          expect(component.showClearLink).toBeFalsy();
        });

        it('should have updated this.selectedProviderList to []', () => {
          // arrange
          const result = deepEqual(component['selectedProviderList'], []);
          // assert
          expect(result).toBeTruthy();
        });

        it('should have updated this.selectedClaimsList to []', () => {
          // arrange
          const result = deepEqual(component['selectedClaimsList'], []);
          // assert
          expect(result).toBeTruthy();
        });

        it('should have updated this.selectedVisitTypeList to []', () => {
          // arrange
          const result = deepEqual(component['selectedVisitTypeList'], []);
          // assert
          expect(result).toBeTruthy();
        });

        it('should have updated this.selectedMemberList to []', () => {
          // arrange
          const result = deepEqual(component['selectedMemberList'], []);
          // assert
          expect(result).toBeTruthy();
        });
      });
      describe('should update the following based on specific conditions', () => {
        it('should have this.dateSelectedFilter to {}', () => {
          // act
          component.dateSelectedFilter = new DateSearchList();
          component.clearFilter(mockProviderList, mockClaimStatusList, mockVisitTypeList, mockMemberList);
          const result = deepEqual(component.dateSelectedFilter, (this.dateSelectedFilter = {} as DateSearchListInterface));
          // assert
          expect(result).toBeTruthy();
        });
      });

      describe('should have called the following methods', () => {
        it('should have called this.closeFilter ', () => {
          // act
          component.clearFilter(mockProviderList, mockClaimStatusList, mockVisitTypeList, mockMemberList);
          // assert
          expect(spy_closeFilter).toHaveBeenCalled();
        });

        it('should have called this.clearFilterOptionsFromView', () => {
          // act
          component.clearFilter(mockProviderList, mockClaimStatusList, mockVisitTypeList, mockMemberList);
          // assert
          expect(spy_clearFilterOptionsFromView).toHaveBeenCalled();
        });

        it('should have called this.clearFilterOptionsFromView 4 times', () => {
          // act
          component.clearFilter(mockProviderList, mockClaimStatusList, mockVisitTypeList, mockMemberList);
          // assert
          expect(spy_clearFilterOptionsFromView).toHaveBeenCalledTimes(4);
        });

        it('should have called this.clearFilterOptionsFromView with @Param::memberList', () => {
          // act
          component.clearFilter(mockProviderList, mockClaimStatusList, mockVisitTypeList, mockMemberList);
          // assert
          expect(spy_clearFilterOptionsFromView).toHaveBeenCalledWith(mockMemberList);
        });

        it('should have called this.clearFilterOptionsFromView with @Param::providerList', () => {
          // act
          component.clearFilter(mockProviderList, mockClaimStatusList, mockVisitTypeList, mockMemberList);
          // assert
          expect(spy_clearFilterOptionsFromView).toHaveBeenCalledWith(mockProviderList);
        });

        it('should have called this.clearFilterOptionsFromView with @Param::visitTypeList', () => {
          // act
          component.clearFilter(mockProviderList, mockClaimStatusList, mockVisitTypeList, mockMemberList);
          // assert
          expect(spy_clearFilterOptionsFromView).toHaveBeenCalledWith(mockVisitTypeList);
        });

        it('should have called this.clearFilterOptionsFromView with @Param::claimStatusList', () => {
          // act
          component.clearFilter(mockProviderList, mockClaimStatusList, mockVisitTypeList, mockMemberList);
          // assert
          expect(spy_clearFilterOptionsFromView).toHaveBeenCalledWith(mockClaimStatusList);
        });

        it('should have called this.initClearFilterOptions', () => {
          // act
          component.clearFilter(mockProviderList, mockClaimStatusList, mockVisitTypeList, mockMemberList);
          // assert
          expect(spy_initClearFilterOptions).toHaveBeenCalled();
        });

        it('should have called this.initClearFilterOptions 4 times', () => {
          // act
          component.clearFilter(mockProviderList, mockClaimStatusList, mockVisitTypeList, mockMemberList);
          // assert
          expect(spy_initClearFilterOptions).toHaveBeenCalledTimes(4);
        });

        it('should have called this.initClearFilterOptions to have been called with this.membersList', () => {
          // act
          component.clearFilter(mockProviderList, mockClaimStatusList, mockVisitTypeList, mockMemberList);
          // assert
          expect(spy_initClearFilterOptions).toHaveBeenCalledWith(component.membersList);
        });

        it('should have called this.initClearFilterOptions to have been called with this.providerList', () => {
          // act
          component.clearFilter(mockProviderList, mockClaimStatusList, mockVisitTypeList, mockMemberList);
          // assert
          expect(spy_initClearFilterOptions).toHaveBeenCalledWith(component.providerList);
        });

        it('should have called this.initClearFilterOptions to have been called with this.visitTypeList', () => {
          // act
          component.clearFilter(mockProviderList, mockClaimStatusList, mockVisitTypeList, mockMemberList);
          // assert
          expect(spy_initClearFilterOptions).toHaveBeenCalledWith(component.visitTypeList);
        });

        it('should have called this.initClearFilterOptions to have been called with this.claimsStatusList', () => {
          // act
          component.clearFilter(mockProviderList, mockClaimStatusList, mockVisitTypeList, mockMemberList);
          // assert
          expect(spy_initClearFilterOptions).toHaveBeenCalledWith(component.claimsStatusList);
        });

        it('should have called this.manageClaimsListing', () => {
          // act
          component.clearFilter(mockProviderList, mockClaimStatusList, mockVisitTypeList, mockMemberList);
          // assert
          expect(spy_manageClaimsListing).toHaveBeenCalled();
        });

        it('should have called this.filterService.scrollToTop', () => {
          // act
          component.clearFilter(mockProviderList, mockClaimStatusList, mockVisitTypeList, mockMemberList);
          // assert
          expect(mockFilterService.scrollToTop).toHaveBeenCalled();
        });

        it('should have called this.closeSideNavigation', () => {
          // act
          component.clearFilter(mockProviderList, mockClaimStatusList, mockVisitTypeList, mockMemberList);
          // assert
          expect(spy_closeSideNavigation).toHaveBeenCalled();
        });

        it('should have called this.alertService.clearError', () => {
          // act
          component.clearFilter(mockProviderList, mockClaimStatusList, mockVisitTypeList, mockMemberList);
          // assert
          expect(mockAlertService.clearError).toHaveBeenCalled();
        });

        it('should not have called this.clearCustomDateRangeSelections if this.dateSelectedFilter is not a valid value', () => {
          // act
          component.dateSelectedFilter = null;
          component.clearFilter(mockProviderList, mockClaimStatusList, mockVisitTypeList, mockMemberList);
          // assert
          expect(spy_clearCustomDateRangeSelections).not.toHaveBeenCalled();
        });

        it('should have called this.clearCustomDateRangeSelections if this.dateSelectedFilter is a valid value', () => {
          // act
          component.dateSelectedFilter = new DateSearchList();
          component.dateSelectedFilter.checked = true;
          component.clearFilter(mockProviderList, mockClaimStatusList, mockVisitTypeList, mockMemberList);
          // assert
          expect(spy_clearCustomDateRangeSelections).toHaveBeenCalled();
        });
      });
    });

    describe('clearFilterOptionsFromView', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('initClearFilterOptions', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('paginationOnScrollDown', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('onScrollUp', () => {
      it('should do nothing', () => {
        // arrange
        const fixture = TestBed.createComponent(ClaimsComponent);
        const component = fixture.componentInstance;

        // act
        const result = component.onScrollUp();

        // assert
        expect(typeof result).toBe('undefined');
      });
    });

    describe('claimsFilterPaginationReqParams', () => {
      it('should do something', () => {
        pending();
      });
    });

    describe('openPDF', () => {
      xit('should download the pdf', () => {
        // arrange
        // let spyWindowOpen = spyOn(window, 'open');
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        const fileItem = '#';

        // act
        const result = component.openPDF();

        // assert
        expect(typeof result).toBe('undefined');
      });
    });

    describe('decimalFragment', () => {
      it('should return a first two decimal places of the number is passed as parameter', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        // fixture.detectChanges();

        // act
        const result = component.decimalFragment(10.87);
        // assert
        expect(result).toBe('87');
      });
      it('should return the first two decimal places of a number rounded to its first two decimal places, when it is passed as string parameter', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        // fixture.detectChanges();

        // act
        const result2 = component.decimalFragment('210.287');
        // assert
        expect(result2).toBe('29');
      });

      it('should return the first two decimal places of a number rounded to its first two decimal places, when it is passed as  string parameter', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        // fixture.detectChanges();

        // act
        const result2 = component.decimalFragment('-3310.1287');
        // assert
        expect(result2).toBe('13');
      });
      it('should return the first two decimal places of a number rounded to its first two decimal places, when it is passed as nuimber parameter', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        // fixture.detectChanges();

        // act
        const result2 = component.decimalFragment('-440.3449');
        // assert
        expect(result2).toBe('34');
      });

      it('should return "00" when invalid number is passed as string parameter', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;
        // fixture.detectChanges();

        // act
        const nan_result = component.decimalFragment('invalidValue');

        // assert
        expect(nan_result).toBe('00');
      });
      it('should return "00" when invalid number is passed as object parameter', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;

        // act
        const object_result = component.decimalFragment({});

        // assert
        expect(object_result).toBe('00');
      });
      it('should return "00" when invalid number is passed as null parameter', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;

        // act
        const null_result = component.decimalFragment(null);
        // assert
        expect(null_result).toBe('00');
      });
      it('should return "00" when invalid number is passed as undefined parameter', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;

        // act
        let undefined_x;
        const undefined_result = component.decimalFragment(undefined_x);

        // assert
        expect(undefined_result).toBe('00');
      });
      xit('should return "00" when invalid number is passed as boolean true parameter', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;

        // act
        const undefined_result = component.decimalFragment(true);
        // assert
        expect(undefined_result).toBe('00');
      });
      it('should return "00" when invalid number is passed as boolean false parameter', () => {
        // arrange
        fixture = TestBed.createComponent(ClaimsComponent);
        component = fixture.componentInstance;

        // act
        const undefined_result = component.decimalFragment(false);
        // assert
        expect(undefined_result).toBe('00');
      });
    });
  });
});
