import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { YesFinDedComponent } from '../../../../../../app/pages/year-end-summary/yes-fin-ded/yes-fin-ded.component';

xdescribe('YesFinDedComponent', () => {
  let component: YesFinDedComponent;
  let fixture: ComponentFixture<YesFinDedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [YesFinDedComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YesFinDedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
