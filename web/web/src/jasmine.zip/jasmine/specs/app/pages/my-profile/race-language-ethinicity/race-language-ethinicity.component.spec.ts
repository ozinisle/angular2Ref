// // import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// // import {
// //   MatSelectModule, MatRadioModule, MatCardModule, MatIconModule, MatSidenavModule, MatDialogModule,
// //   MatTooltipModule, MatGridListModule, MatFormFieldModule
// // } from '@angular/material';
// // import { Router } from '@angular/router';
// // import { FormBuilder, FormsModule } from '@angular/forms';
// // import { CommonModule } from '@angular/common';
// // import { ReactiveFormsModule } from '@angular/forms'
// // import { TextMaskModule } from 'angular2-text-mask';
// // import { StorageServiceModule } from 'angular-webstorage-service';
// // import { HttpClientTestingModule } from '@angular/common/http/testing';
// // import { BrowserModule } from '@angular/platform-browser';
// // import { RaceLanguageEthinicityComponent } from '../../../../../../app/pages/my-profile/race-language-ethinicity/race-language-ethinicity.component';
// // import { mocks } from '../../../../../constants/mocks.service';
// // import { MaterialModule } from '../../../../../../app/material.module';
// // import { FakeRouterLinkDirectiveStub, FakeParentFormFieldDirectiveStub } from '../../../../../fake-directives';
// // import { FakeControlMessagesComponent, FakeFadBreadCrumbsComponent, FakeCostBreakdownFilterComponent, FakeAlegeusLineChartComponent, FakeBreadcrumbsComponent, FakeFpoLayoutComponent } from '../../../../../fake-components';
// // import { AlertService, AuthService } from '../../../../../../app/shared/shared.module';
// // import { ProfileService } from '../../../../../../app/shared/services/myprofile/profile.service';
// // import { getDemographicInfo_response } from '../../../../../data/my-profile/getDemographicInfo.data';
// // import { UpdateDemographicInfoRequestModel } from '../../../../../../app/pages/my-profile/models/update-demographic-info.model';
// // import { AlertType } from '../../../../../../app/shared/alerts/alertType.model';

// // describe('RaceLanguageEthinicityComponent', () => {
// //   let component: RaceLanguageEthinicityComponent;
// //   let fixture: ComponentFixture<RaceLanguageEthinicityComponent>;

// //   let mockAlertService;
// //   let mockRouter;
// //   let mockProfileService;
// //   let mockAuthService;

// //   // create new instance of FormBuilder
// //   const formBuilder: FormBuilder = new FormBuilder();

// //   beforeEach(async(() => {
// //     mockRouter = mocks.service.router;

// //     mockAlertService = mocks.service.alertService;

// //     mockProfileService = mocks.service.profileService;

// //     mockRouter = mocks.service.router;

// //     mockAuthService = mocks.service.authService;

// //     TestBed.configureTestingModule({
// //       imports: [
// //         BrowserModule,
// //         CommonModule,
// //         FormsModule,
// //         ReactiveFormsModule,
// //         StorageServiceModule,
// //         HttpClientTestingModule,
// //         TextMaskModule,
// //         MatFormFieldModule,
// //         MatRadioModule,

// //         MatSelectModule,
// //         MatCardModule,
// //         MatIconModule,
// //         MatSidenavModule,
// //         MatTooltipModule,
// //         MatGridListModule,
// //         MatDialogModule,
// //         MaterialModule
// //       ],
// //       declarations: [
// //         FakeRouterLinkDirectiveStub,
// //         FakeParentFormFieldDirectiveStub,
// //         FakeControlMessagesComponent,
// //         FakeFadBreadCrumbsComponent,
// //         FakeCostBreakdownFilterComponent,
// //         FakeAlegeusLineChartComponent,
// //         FakeBreadcrumbsComponent,
// //         FakeFpoLayoutComponent,

// //         RaceLanguageEthinicityComponent
// //       ],
// //       providers: [
// //         { provide: AlertService, useValue: mockAlertService },
// //         { provide: FormBuilder, useValue: formBuilder },
// //         { provide: Router, useValue: mockRouter },
// //         { provide: ProfileService, useValue: mockProfileService },
// //         { provide: AuthService, useValue: mockAuthService }
// //       ]

// //     })
// //       .compileComponents();
// //   }));

// //   describe('Constructor', () => {
// //     describe('While Component Creation', () => {  // assert constructor contents
// //       it('should have initialized race-lang-ethinicity form', () => {
// //         //arrange

// //         fixture = TestBed.createComponent(RaceLanguageEthinicityComponent);

// //         //act
// //         component = fixture.componentInstance;

// //         //assert
// //         expect(component.raceForm).toBeTruthy();
// //       });

// //       it('should have called alertService.clearError method', () => {
// //         //arrange

// //         fixture = TestBed.createComponent(RaceLanguageEthinicityComponent);

// //         //act
// //         component = fixture.componentInstance;

// //         //assert
// //         expect(mockAlertService.clearError).toHaveBeenCalled()
// //       });
// //     });
// //   });

// //   describe('ngOnInit', () => {
// //     beforeEach(() => {
// //       //arrange
// //       fixture = TestBed.createComponent(RaceLanguageEthinicityComponent);
// //       component = fixture.componentInstance;

// //     });

// //     it('should have called ngOnInit', () => {
// //       //arrange
// //       spyOn(component, 'ngOnInit');

// //       //act
// //       fixture.detectChanges();

// //       //assert
// //       expect(component.ngOnInit).toHaveBeenCalled();
// //     });

// //     describe('should have internally performed the following while executing ngOnInit', () => {
// //       it('should have called profileService.getDemoGraphicInfo', () => {
// //         //act
// //         fixture.detectChanges();

// //         //assert
// //         expect(mockProfileService.getDemoGraphicInfo).toHaveBeenCalled();
// //       });

// //       it('should have initialized this.showRaceForm to  getDemographicInfo_response.agree', () => {
// //         //act
// //         fixture.detectChanges();

// //         //assert
// //         expect(component.showRaceForm).toBe(getDemographicInfo_response.agree);
// //       });

// //       it('should have initialized this.raceList to  getDemographicInfo_response.raceList', () => {
// //         //act
// //         fixture.detectChanges();

// //         //assert
// //         expect(component.raceList).toBe(getDemographicInfo_response.raceList);
// //       });

// //       it('should have initialized this.ethnicityList to  getDemographicInfo_response.ethnicityList', () => {
// //         //act
// //         fixture.detectChanges();

// //         //assert
// //         expect(component.ethnicityList).toBe(getDemographicInfo_response.ethnicityList);
// //       });

// //       it('should have initialized this.latinoOriginList to  getDemographicInfo_response.latinoOriginList', () => {
// //         //act
// //         fixture.detectChanges();

// //         //assert
// //         expect(component.latinoOriginList).toBe(getDemographicInfo_response.latinoOriginList);
// //       });

// //       it('should have initialized this.languageList to  getDemographicInfo_response.languageList', () => {
// //         //act
// //         fixture.detectChanges();

// //         //assert
// //         expect(component.languageList).toBe(getDemographicInfo_response.languageList);
// //       });

// //       it('should have initialized showRace2Flag to true if race2 Value is set in response', () => {
// //         //act
// //         fixture.detectChanges();

// //         if (component.raceForm.value.race2 !== '') {
// //           expect(component.showRace2Flag).toBeTruthy();
// //         } else {
// //           expect(component).toBeTruthy();
// //         }

// //       });

// //       it('should have initialized showEthenicity2Flag to true if ethnicity2 Value is set in response', () => {
// //         //act
// //         fixture.detectChanges();

// //         if (component.raceForm.value.ethnicity2 !== '') {
// //           expect(component.showEthenicity2Flag).toBeTruthy();
// //         } else {
// //           expect(component).toBeTruthy();
// //         }

// //       });

// //       describe('should have updated raceForm with data from getDemographicInfo_response', () => {
// //         it('should have initialized raceForm.race1 to getDemographicInfo_response.race1', () => {
// //           //act
// //           fixture.detectChanges();

// //           //assert
// //           expect(component.raceForm.value.race1).toBe(getDemographicInfo_response.race1);

// //         });

// //         it('should have initialized raceForm.race2 to getDemographicInfo_response.race2', () => {
// //           //act
// //           fixture.detectChanges();

// //           //assert
// //           expect(component.raceForm.value.race2).toBe(getDemographicInfo_response.race2);
// //         });

// //         it('should have initialized raceForm.ethnicity1 to getDemographicInfo_response.ethnicity1', () => {
// //           //act
// //           fixture.detectChanges();

// //           //assert
// //           expect(component.raceForm.value.ethnicity1).toBe(getDemographicInfo_response.ethnicity1);
// //         });

// //         it('should have initialized raceForm.ethnicity2 to getDemographicInfo_response.ethnicity2', () => {
// //           //act
// //           fixture.detectChanges();

// //           //assert
// //           expect(component.raceForm.value.ethnicity2).toBe(getDemographicInfo_response.ethnicity2);
// //         });

// //         it('should have initialized raceForm.latinoOrigin to getDemographicInfo_response.latinoOrigin', () => {
// //           //act
// //           fixture.detectChanges();

// //           //assert
// //           expect(component.raceForm.value.latinoOrigin).toBe(getDemographicInfo_response.latinoOrigin);
// //         });

// //         it('should have initialized raceForm.primaryLang to getDemographicInfo_response.primaryLang', () => {
// //           //act
// //           fixture.detectChanges();

// //           //assert
// //           expect(component.raceForm.value.primaryLang).toBe(getDemographicInfo_response.primaryLang);
// //         });

// //         it('should have initialized raceForm.memberDOB to getDemographicInfo_response.memberDOB', () => {
// //           //act
// //           fixture.detectChanges();

// //           //assert
// //           expect(component.raceForm.value.memberDOB).toBe(getDemographicInfo_response.memberDOB);
// //         });

// //         it('should have initialized raceForm.agree to getDemographicInfo_response.agree', () => {
// //           //act
// //           fixture.detectChanges();

// //           //assert
// //           expect(component.raceForm.value.agree).toBe(getDemographicInfo_response.agree);
// //         });

// //       });
// //     });
// //   });

// //   describe('Methods', () => {
// //     describe('provideInfo', () => {
// //       it('should have toggled the value of this.showRaceForm', () => {
// //         //arrange
// //         fixture = TestBed.createComponent(RaceLanguageEthinicityComponent);
// //         component = fixture.componentInstance;

// //         //act
// //         let actual = component.showRaceForm;
// //         component.provideInfo();

// //         //assert
// //         expect(component.showRaceForm).toBe(!actual);
// //       });

// //       it('should have marked the value of this.showRace2Flag as false', () => {
// //         //arrange
// //         fixture = TestBed.createComponent(RaceLanguageEthinicityComponent);
// //         component = fixture.componentInstance;

// //         //act
// //         component.provideInfo();

// //         //assert
// //         expect(component.showRace2Flag).toBeFalsy();
// //       });

// //       it('should have marked the value of this.showEthenicity2Flag as false', () => {
// //         //arrange
// //         fixture = TestBed.createComponent(RaceLanguageEthinicityComponent);
// //         component = fixture.componentInstance;

// //         //act
// //         component.provideInfo();

//         //assert
//         expect(component.showEthenicity2Flag).toBeFalsy();
//       });

//       describe('should have reset the raceForm with default data from ', () => {
//         it('should have reset the field value "agree" to this.showRaceForm', () => {
//           //arrange
//           fixture = TestBed.createComponent(RaceLanguageEthinicityComponent);
//           component = fixture.componentInstance;

//           //act
//           component.provideInfo();

//           //assert
//           expect(component.raceForm.value.agree).toBe(component.showRaceForm);
//         });

//         it('should have reset the field value "ethnicity1" to ""', () => {
//           //arrange
//           fixture = TestBed.createComponent(RaceLanguageEthinicityComponent);
//           component = fixture.componentInstance;

//           //act
//           component.provideInfo();

//           //assert
//           expect(component.raceForm.value.ethnicity1).toBe('');
//         });

//         it('should have reset the field value "ethnicity2" to ""', () => {
//           //arrange
//           fixture = TestBed.createComponent(RaceLanguageEthinicityComponent);
//           component = fixture.componentInstance;

//           //act
//           component.provideInfo();

//           //assert
//           expect(component.raceForm.value.ethnicity2).toBe('');
//         });

//         it('should have reset the field value "ethnicity2" to ""', () => {
//           //arrange
//           fixture = TestBed.createComponent(RaceLanguageEthinicityComponent);
//           component = fixture.componentInstance;

//           //act
//           component.provideInfo();

//           //assert
//           expect(component.raceForm.value.ethnicity2).toBe('');
//         });

//         it('should have reset the field value "latinoOrigin" to ""', () => {
//           //arrange
//           fixture = TestBed.createComponent(RaceLanguageEthinicityComponent);
//           component = fixture.componentInstance;

//           //act
//           component.provideInfo();

//           //assert
//           expect(component.raceForm.value.latinoOrigin).toBe('');
//         });

//         it('should have reset the field value "primaryLang" to ""', () => {
//           //arrange
//           fixture = TestBed.createComponent(RaceLanguageEthinicityComponent);
//           component = fixture.componentInstance;

//           //act
//           component.provideInfo();

//           //assert
//           expect(component.raceForm.value.primaryLang).toBe('');
//         });

//         it('should have reset the field value "memberDOB" to ""', () => {
//           //arrange
//           fixture = TestBed.createComponent(RaceLanguageEthinicityComponent);
//           component = fixture.componentInstance;

//           //act
//           component.provideInfo();

//           //assert
//           expect(component.raceForm.value.memberDOB).toBe('');
//         });
//       });

//     });

//     describe('onSubmit', () => {
//       let updateDemographicInfoReq: UpdateDemographicInfoRequestModel;
//       beforeEach(() => {

//         //arrange
//         fixture = TestBed.createComponent(RaceLanguageEthinicityComponent);
//         component = fixture.componentInstance;
//         fixture.detectChanges();

//         updateDemographicInfoReq = new UpdateDemographicInfoRequestModel();
//         updateDemographicInfoReq.useridin = mockProfileService.getProfile().useridin;
//         updateDemographicInfoReq.agree = component.raceForm.value.agree;
//         updateDemographicInfoReq.race1 = component.raceForm.value.race1;
//         updateDemographicInfoReq.race2 = component.raceForm.value.race2;
//         updateDemographicInfoReq.ethnicity1 = component.raceForm.value.ethnicity1;
//         updateDemographicInfoReq.ethnicity2 = component.raceForm.value.ethnicity2;
//         updateDemographicInfoReq.latinoOrigin = component.raceForm.value.latinoOrigin;
//         updateDemographicInfoReq.primaryLang = component.raceForm.value.primaryLang;
//         updateDemographicInfoReq.memberDOB = component.raceForm.value.memberDOB;

//         //act
//         component.onSubmit();
//       });

//       xit('should have called this.profileService.updateDemographicInfo with the latest form data', () => {
//         //assert
//         expect(mockProfileService.updateDemographicInfo).toHaveBeenCalledWith(updateDemographicInfoReq);
//       });

//       xit('should have called this.alertService.setAlert with params: "Success!","",0', () => {
//         //assert
//         expect(mockAlertService.setAlert).toHaveBeenCalledWith('Success!', '', AlertType.Success);
//       });

//       xit('should initiate page navigation to "/myProfile"', () => {
//         //assert
//         expect(mockRouter.navigate).toHaveBeenCalledWith(['/myprofile']);
//       });

//     });

//     describe('cancel', () => {
//       it('should initiate page navigation to "../../myprofile"', () => {
//         //arrange
//         fixture = TestBed.createComponent(RaceLanguageEthinicityComponent);
//         component = fixture.componentInstance;
//         fixture.detectChanges();

//         //act
//         component.cancel();

//         //assert
//         expect(mockRouter.navigate).toHaveBeenCalledWith(['../../myprofile']);
//       })
//     });

//     describe('showEthenicity2', () => {
//       it('should set the value of this.showEthenicity2Flag to true', () => {
//         //arrange
//         fixture = TestBed.createComponent(RaceLanguageEthinicityComponent);
//         component = fixture.componentInstance;
//         fixture.detectChanges();

//         //act
//         component.showEthenicity2();

//         //assert
//         expect(component.showEthenicity2Flag).toBeTruthy();
//       });
//     });

//     describe('showRace2', () => {
//       it('should set the value of this.showRace2Flag to true', () => {
//         //arrange
//         fixture = TestBed.createComponent(RaceLanguageEthinicityComponent);
//         component = fixture.componentInstance;
//         fixture.detectChanges();

//         //act
//         component.showRace2();

//         //assert
//         expect(component.showRace2Flag).toBeTruthy();
//       });
//     });
//     describe('impersonation', () => {
//       it('should have called this.authSerive.impersonation', () => {
//         //arrange
//         fixture = TestBed.createComponent(RaceLanguageEthinicityComponent);
//         component = fixture.componentInstance;

//         //act
//         component.impersonation();

//         //assert
//         expect(mockAuthService.impersonation).toHaveBeenCalled();
//       });

//       it('should return this.authService.impersonation()', () => {
//         //arrange
//         fixture = TestBed.createComponent(RaceLanguageEthinicityComponent);
//         component = fixture.componentInstance;
//         let impersonationFlag = mockAuthService.impersonation();
//         //act
//         let result = component.impersonation();

//         //assert
//         expect(result).toBe(impersonationFlag);
//       })
//     })
//   });
// });
