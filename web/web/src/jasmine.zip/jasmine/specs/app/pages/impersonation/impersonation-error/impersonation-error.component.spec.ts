// //  import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// // import { ImpersonationErrorComponent } from './impersonation-error.component';
// // import { BrowserModule } from '@angular/platform-browser';
// // import { CommonModule } from '@angular/common';
// // import { ReactiveFormsModule } from '@angular/forms';
// // import { ImpersonationComponent } from '../impersonation.component';
// // import { NO_ERRORS_SCHEMA } from '@angular/core';

// // describe('ImpersonationErrorComponent', () => {
// //   let component: ImpersonationErrorComponent;
// //   let fixture: ComponentFixture<ImpersonationErrorComponent>;

// //   beforeEach(async(() => {

// //     TestBed.configureTestingModule({
// //       imports:[ BrowserModule,
// //         CommonModule,
// //         ReactiveFormsModule,CommonModule],

// //       declarations: [ ImpersonationErrorComponent ],
// //       schemas: [NO_ERRORS_SCHEMA],
// //       providers: [
// //       ]

// //     })
// //     .compileComponents();
// //   }));

// //   beforeEach(() => {
// //     fixture = TestBed.createComponent(ImpersonationErrorComponent);
// //     component = fixture.componentInstance;
// //     //component.forgotUsernameForm = formBuilder.group({
// //       // email: null,
// //       // mobile: null
// //     //  });
// //     fixture.detectChanges();

// //   });

// //   it('should create', () => {
// //     expect(component).toBeTruthy();
// //   });
// // });
