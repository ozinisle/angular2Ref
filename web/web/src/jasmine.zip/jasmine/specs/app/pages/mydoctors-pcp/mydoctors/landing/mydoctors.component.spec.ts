// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { MyDoctorsComponent } from './mydoctors.component';
// import {
//     MatFormFieldModule, MatRadioModule, MatSelectModule, MatCardModule, MatIconModule,
//     MatSidenavModule, MatDialogModule, MatTooltipModule, MatGridListModule
// } from '@angular/material';
// import { NoopAnimationsModule } from '@angular/platform-browser/animations';
// import { BrowserModule } from '@angular/platform-browser';
// import { CommonModule } from '@angular/common';
// import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { StorageServiceModule } from 'angular-webstorage-service';
// import { HttpClientTestingModule } from '@angular/common/http/testing';
// import { TextMaskModule } from 'angular2-text-mask';
// import { MaterialModule } from '../../../../material.module';

// describe('MyDoctorsComponent', () => {
//     let component: MyDoctorsComponent;
//     let fixture: ComponentFixture<MyDoctorsComponent>;

//     beforeEach(async(() => {
//         TestBed.configureTestingModule({
//             imports: [
//                 NoopAnimationsModule,
//                 BrowserModule,
//                 CommonModule,
//                 FormsModule,
//                 ReactiveFormsModule,
//                 StorageServiceModule,
//                 HttpClientTestingModule,
//                 TextMaskModule,
//                 MatFormFieldModule,
//                 MatRadioModule,
//                 MatSelectModule,
//                 MatCardModule,
//                 MatIconModule,
//                 MatSidenavModule,
//                 MatTooltipModule,
//                 MatGridListModule,
//                 MatDialogModule,
//                 MaterialModule
//             ],
//             declarations: [MyDoctorsComponent]
//         })
//             .compileComponents();
//     }));

//     describe('Constructor', () => {

//         beforeEach(() => {
//             //arrange
//             fixture = TestBed.createComponent(MyDoctorsComponent);
//             component = fixture.componentInstance;
//         });

//         it('should create', () => {
//             //assert
//             expect(component).toBeTruthy();
//         });

//         describe('While Component Creation', () => {
//             it('should do', () => {
//                 //assert
//                 pending();
//             });
//         });
//     });

//     describe('ngOnInit', () => {
//         beforeEach(() => {
//             //arrange
//             fixture = TestBed.createComponent(MyDoctorsComponent);
//             component = fixture.componentInstance;

//             //act
//             fixture.detectChanges();
//         });
//         it('should have loaded', () => {
//             //assert
//             expect(component).toBeTruthy();
//         });
//         describe('should have initialized', () => {
//             it('should have initialized', () => {
//                 //assert
//                 pending();
//             });
//         });

//         describe('should have called', () => {
//             it('should have called', () => {
//                 //assert
//                 pending();
//             });
//         });
//     });
// });
