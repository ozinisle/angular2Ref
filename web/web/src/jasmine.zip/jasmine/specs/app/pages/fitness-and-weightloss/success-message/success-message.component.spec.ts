import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SuccessMessageComponent } from '../../../../../../app/pages/fitness-and-weightloss/success-message/success-message.component';
import { FitnessAndWeightlossModule } from '../../../../../../app/pages/fitness-and-weightloss/fitness-and-weightloss.module';
import { Router } from '@angular/router';
import { mocks } from '../../../../../constants/mocks.service';
import { SelectionService } from '../../../../../../app/shared/services/downloadForm/selection.service';
import { AlertService } from '../../../../../../app/shared/shared.module';
import { FormBuilder } from '@angular/forms';

describe('SuccessMessageComponent', () => {
  let component: SuccessMessageComponent;
  let fixture: ComponentFixture<SuccessMessageComponent>;
  const mockSelectionService = mocks.service.selectionService;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FitnessAndWeightlossModule],
      providers : [
        FormBuilder,
        { provide: Router, useValue: mocks.service.router },
        { provide: SelectionService, useValue: mockSelectionService},
        { provide: AlertService, useValue: mocks.service.alertService},
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuccessMessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
