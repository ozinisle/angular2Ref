import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { CreatePasswordGuard } from '../../../../../../app/pages/my-account/utils/create-password.guard';
import { MockRouter } from '../../../../../mock-classes/mock-router.class';

describe('CreatePasswordGuard', () => {
  describe('canActivate', () => {
    let guard: CreatePasswordGuard;
    let router;

    beforeEach(() => {
      router = new MockRouter();
      guard = new CreatePasswordGuard(router);
    });

    it('should call the sessionStorage.getItem', () => {
      // arrange
      const next = {
        parent: {
          routeConfig: { path: '' }
        }
      } as ActivatedRouteSnapshot;

      // act
      const sessionResult = spyOn(sessionStorage.__proto__, 'getItem');
      const result = guard.canActivate(next, {} as RouterStateSnapshot);

      // assert
      expect(sessionResult).toHaveBeenCalledTimes(1);
    });

    it('should return true if isOTPSuccess && isOTPSuccess  === TRUE', () => {
      // arrange
      const next = {
        parent: {
          routeConfig: { path: '' }
        }
      } as ActivatedRouteSnapshot;

      // act
      const isOTPSuccess = spyOn(sessionStorage.__proto__, 'getItem').and.returnValue('TRUE');
      guard.canActivate(next, {} as RouterStateSnapshot);

      // assert
      expect(isOTPSuccess).toBeTruthy();
    });

    it('should redirect to login page if isOTPSuccess=false or isOTPSuccess=null', () => {
      // arrange

      const next = {
        parent: {
          routeConfig: { path: 'login' }
        }
      } as ActivatedRouteSnapshot;

      spyOn(sessionStorage.__proto__, 'clear');
      spyOn(router, 'navigate');

      // act
      const isOTPSuccess = spyOn(sessionStorage.__proto__, 'getItem').and.returnValue(null);
      guard.canActivate(next, {} as RouterStateSnapshot);

      // assert
      expect(router.navigate).toHaveBeenCalledWith(['login']);
    });

    it('should clear the sessionStorage if isOTPSuccess=false or isOTPSuccess=null', () => {
      // arrange
      const next = {
        parent: {
          routeConfig: { path: '' }
        }
      } as ActivatedRouteSnapshot;
      spyOn(router, 'navigate');
      spyOn(sessionStorage.__proto__, 'clear');

      // act
      const isOTPSuccess = spyOn(sessionStorage.__proto__, 'getItem').and.returnValue(null);
      guard.canActivate(next, {} as RouterStateSnapshot);

      // assert
      expect(sessionStorage.__proto__.clear).toHaveBeenCalled();
    });
  });
});
