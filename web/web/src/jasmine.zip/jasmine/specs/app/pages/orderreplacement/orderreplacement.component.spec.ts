import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatCardModule,
  MatDialogModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ActivatedRoute } from '@angular/router';
import { StorageServiceModule } from 'angular-webstorage-service';
import { TextMaskModule } from 'angular2-text-mask';
import { MaterialModule } from '../../../../../app/material.module';
import { OrderreplacementComponent } from '../../../../../app/pages/orderreplacement/orderreplacement.component';
import { DependantsService } from '../../../../../app/shared/services/dependant.service';
import { GlobalService } from '../../../../../app/shared/services/global.service';
import { OrderreplacementService } from '../../../../../app/shared/services/orderreplacement/orderreplacement.service';
import { AlertService, AuthService } from '../../../../../app/shared/shared.module';
import { mocks } from '../../../../constants/mocks.service';
import { orderreplacement_component_resolver_data } from '../../../../data/orderreplacement/orderreplacement.component.data';
import { FakeBreadcrumbsComponent, FakeMaintenanceComponent } from '../../../../fake-components';
import { FakeRouterLinkDirectiveStub } from '../../../../fake-directives';

describe('OrderreplacementComponent', () => {
  let component: OrderreplacementComponent;
  let fixture: ComponentFixture<OrderreplacementComponent>;

  let mockAlertService;
  let mockAuthService;
  let mockActivatedRoute;
  let mockDependantsService;
  let mockOrderreplacementService;
  let mockGlobalService;

  beforeEach(async(() => {
    mockAlertService = mocks.service.alertService;
    mockAuthService = mocks.service.authService;
    mockActivatedRoute = {
      snapshot: {
        data: orderreplacement_component_resolver_data
      }
    };
    mockDependantsService = mocks.service.dependantsService;
    mockOrderreplacementService = mocks.service.orderreplacementService;
    mockGlobalService = mocks.service.globalService;

    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        BrowserModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        StorageServiceModule,
        HttpClientTestingModule,
        TextMaskModule,
        MatFormFieldModule,
        MatRadioModule,
        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatDialogModule,
        MaterialModule
      ],
      declarations: [FakeRouterLinkDirectiveStub, FakeBreadcrumbsComponent, FakeMaintenanceComponent, OrderreplacementComponent],
      providers: [
        { provide: AlertService, useValue: mockAlertService },
        { provide: AuthService, useValue: mockAuthService },
        { provide: ActivatedRoute, useValue: mockActivatedRoute },
        { provide: DependantsService, useValue: mockDependantsService },
        { provide: OrderreplacementService, useValue: mockOrderreplacementService },
        { provide: GlobalService, useValue: mockGlobalService }
      ]
    }).compileComponents();
  }));

  describe('Constructor', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(OrderreplacementComponent);
      component = fixture.componentInstance;
    });

    it('should create', () => {
      // assert
      expect(component).toBeTruthy();
    });

    describe('While Component Creation', () => {
      it('should do', () => {
        // assert
        pending();
      });
    });
  });

  describe('ngOnInit', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(OrderreplacementComponent);
      component = fixture.componentInstance;

      // act
      fixture.detectChanges();
    });
    it('should have loaded', () => {
      // assert
      expect(component).toBeTruthy();
    });
    describe('should have initialized', () => {
      it('should have initialized', () => {
        // assert
        pending();
      });
    });

    describe('should have called', () => {
      it('should have called', () => {
        // assert
        pending();
      });
    });
  });
});
