import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { VerifyAccessGuard } from '../../../../../../app/pages/my-account/utils/verify-access.guard';
import { MockRouter } from '../../../../../mock-classes/mock-router.class';

describe('VerifyAccessGuard', () => {
  describe('canActivate', () => {
    let guard: VerifyAccessGuard;
    let router;

    beforeEach(() => {
      router = new MockRouter();
      guard = new VerifyAccessGuard(router);
    });

    it('should call the sessionStorage.getItem', () => {
      // arrange
      const next = {
        parent: {
          routeConfig: { path: '' }
        }
      } as ActivatedRouteSnapshot;

      // act
      const sessionResult = spyOn(sessionStorage.__proto__, 'getItem');
      const result = guard.canActivate(next, {} as RouterStateSnapshot);

      // assert
      expect(sessionResult).toHaveBeenCalledTimes(1);
    });

    it('should return true if isOTPSent && isOTPSent  === TRUE', () => {
      // arrange
      const next = {
        parent: {
          routeConfig: { path: '' }
        }
      } as ActivatedRouteSnapshot;

      // act
      const isOTPSent = spyOn(sessionStorage.__proto__, 'getItem').and.returnValue('TRUE');
      guard.canActivate(next, {} as RouterStateSnapshot);

      // assert
      expect(isOTPSent).toBeTruthy();
    });

    it('should redirect to login page if isOTPSent=false or isOTPSent=null', () => {
      // arrange

      const next = {
        parent: {
          routeConfig: { path: 'login' }
        }
      } as ActivatedRouteSnapshot;

      spyOn(sessionStorage.__proto__, 'clear');
      spyOn(router, 'navigate');

      // act
      const isOTPSent = spyOn(sessionStorage.__proto__, 'getItem').and.returnValue(null);
      guard.canActivate(next, {} as RouterStateSnapshot);

      // assert
      expect(router.navigate).toHaveBeenCalledWith(['login']);
    });

    it('should clear the sessionStorage if isOTPSent=false or isOTPSent=null', () => {
      // arrange
      const next = {
        parent: {
          routeConfig: { path: '' }
        }
      } as ActivatedRouteSnapshot;
      spyOn(router, 'navigate');
      spyOn(sessionStorage.__proto__, 'clear');

      // act
      const isOTPSuccess = spyOn(sessionStorage.__proto__, 'getItem').and.returnValue(null);
      guard.canActivate(next, {} as RouterStateSnapshot);

      // assert
      expect(sessionStorage.__proto__.clear).toHaveBeenCalled();
    });
  });
});
