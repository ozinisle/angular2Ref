import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatCardModule,
  MatDialogModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { StorageServiceModule } from 'angular-webstorage-service';
import { TextMaskModule } from 'angular2-text-mask';
import { MaterialModule } from '../../../../../../../app/material.module';
import { MyDoctorsPcpService } from '../../../../../../../app/pages/mydoctors-pcp/mydoctors-pcp.service';
import { UpdatePcpComponent } from '../../../../../../../app/pages/mydoctors-pcp/pcp/update-pcp/update-pcp.component';
import { DependantsService } from '../../../../../../../app/shared/services/dependant.service';
import { AlertService, AuthService, ConstantsService, ValidationService } from '../../../../../../../app/shared/shared.module';
import { mocks } from '../../../../../../constants/mocks.service';
import {
  FakeBreadcrumbsComponent,
  FakeControlMessagesComponent,
  FakeFpoLayoutComponent,
  FakeMaintenanceComponent
} from '../../../../../../fake-components';
import { FakeParentFormFieldDirectiveStub } from '../../../../../../fake-directives';

describe('UpdatePcpComponent', () => {
  let component: UpdatePcpComponent;
  let fixture: ComponentFixture<UpdatePcpComponent>;

  let mockValidationService;
  let mockAlertService;
  let mockRouter;
  let mockDependantsService;
  let mockAuthService;
  let mockMyDoctorsPcpService;
  let mockConstantsService;

  // create new instance of FormBuilder
  const formBuilder: FormBuilder = new FormBuilder();

  beforeEach(async(() => {
    mockValidationService = mocks.service.validationService;
    mockAlertService = mocks.service.alertService;

    mockRouter = mocks.service.router;
    mockRouter.url = '/mydoctors/update-pcp';

    mockDependantsService = mocks.service.dependantsService;
    mockAuthService = mocks.service.authService;
    mockMyDoctorsPcpService = mocks.service.myDoctorsPcpService;
    mockConstantsService = mocks.service.constantsService;

    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        BrowserModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        StorageServiceModule,
        HttpClientTestingModule,
        TextMaskModule,
        MatFormFieldModule,
        MatRadioModule,
        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatDialogModule,
        MaterialModule
      ],
      declarations: [
        FakeBreadcrumbsComponent,
        FakeFpoLayoutComponent,
        FakeControlMessagesComponent,
        FakeMaintenanceComponent,
        FakeParentFormFieldDirectiveStub,
        UpdatePcpComponent
      ],
      providers: [
        { provide: ValidationService, useValue: mockValidationService },
        { provide: AlertService, useValue: mockAlertService },
        { provide: FormBuilder, useValue: formBuilder },
        { provide: Router, useValue: mockRouter },
        { provide: DependantsService, useValue: mockDependantsService },
        { provide: AuthService, useValue: mockAuthService },
        { provide: MyDoctorsPcpService, useValue: mockMyDoctorsPcpService },
        { provide: ConstantsService, useValue: mockConstantsService }
      ]
    }).compileComponents();
  }));

  describe('Constructor', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(UpdatePcpComponent);
      component = fixture.componentInstance;
    });

    xit('should create', () => {
      // assert
      expect(component).toBeTruthy();
    });

    describe('While Component Creation', () => {
      it('should do', () => {
        // assert
        pending();
      });
    });
  });

  describe('ngOnInit', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(UpdatePcpComponent);
      component = fixture.componentInstance;

      // act
      fixture.detectChanges();
    });
    xit('should have loaded', () => {
      // assert
      expect(component).toBeTruthy();
    });
    describe('should have initialized', () => {
      it('should have initialized', () => {
        // assert
        pending();
      });
    });

    describe('should have called', () => {
      it('should have called', () => {
        // assert
        pending();
      });
    });
  });
});
