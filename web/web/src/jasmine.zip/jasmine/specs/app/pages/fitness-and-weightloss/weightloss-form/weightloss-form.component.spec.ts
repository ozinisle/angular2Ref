import { Location } from '@angular/common';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, AbstractControl } from '@angular/forms';
import { WeightlossFormComponent } from '../../../../../../app/pages/fitness-and-weightloss/weightloss-form/weightloss-form.component';
import { FitnessAndWeightlossModule } from '../../../../../../app/pages/fitness-and-weightloss/fitness-and-weightloss.module';
import { SelectionService } from '../../../../../../app/shared/services/downloadForm/selection.service';
import { mocks } from '../../../../../constants/mocks.service';
import { Router } from '@angular/router';
import { ValidationService, AuthService } from '../../../../../../app/shared/shared.module';
import { NgxMaskModule } from 'ngx-mask';
describe('WeightlossFormComponent', () => {
  let component: WeightlossFormComponent;
  let fixture: ComponentFixture<WeightlossFormComponent>;
  const mockSelectionService = mocks.service.selectionService;
  beforeEach(() => {
    const formBuilderStub = {
      group: formGroup => ({
        patchValue() {}
      })
    };
    const locationStub = { back: () => ({}) };
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      imports : [FitnessAndWeightlossModule, NgxMaskModule.forRoot()],
      providers: [
        FormBuilder,
        { provide: Location, useValue: locationStub },
        { provide: SelectionService, useValue: mockSelectionService },
        { provide : Router, useValue : mocks.service.router },
        { provide: ValidationService, useValue: mocks.service.validationService },
        { provide: AuthService, useValue: mocks.service.authService }
      ]
    });

    mockSelectionService.checkAnnualFee.and.callFake(() => {
        return (control: AbstractControl): { [key: string]: any } => {
          return { minValue: { value: true } };
        };
      }
    );
    fixture = TestBed.createComponent(WeightlossFormComponent);
    component = fixture.componentInstance;
  });
  it('can load instance', () => {
    expect(component).toBeTruthy();
  });
  it('isFormSubmitted defaults to: false', () => {
    expect(component.isFormSubmitted).toEqual(false);
  });
  it('showForm defaults to: false', () => {
    expect(component.showForm).toEqual(false);
  });
  it('isAgreed defaults to: false', () => {
    expect(component.isAgreed).toEqual(false);
  });
  it('toolTipVisible defaults to: false', () => {
    expect(component.toolTipVisible).toEqual(false);
  });
  it('email_Addresses defaults to: []', () => {
    expect(component.email_Addresses).toEqual([]);
  });
  describe('ngOnInit', () => {
    it('makes expected calls', () => {
      spyOn(component, 'initializeFitnessForm').and.callThrough();
      component.ngOnInit();
      expect(component.initializeFitnessForm).toHaveBeenCalled();
    });
  });
  describe('initializeFitnessForm', () => {
    it('makes expected calls', () => {
      component.benefitsData = {memberList: []};
      const formBuilderStub: FormBuilder = fixture.debugElement.injector.get(FormBuilder);
      spyOn(formBuilderStub, 'group').and.callThrough();
      fixture.detectChanges();
      component.initializeFitnessForm();
      expect(formBuilderStub.group).toHaveBeenCalled();
    });
  });
  describe('onBackPressed', () => {
    it('makes expected calls', () => {
      const locationStub: Location = fixture.debugElement.injector.get(Location);
      spyOn(locationStub, 'back').and.callThrough();
      component.onBackPressed();
      expect(locationStub.back).toHaveBeenCalled();
    });
  });
});
