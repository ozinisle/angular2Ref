import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormsModule, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import {
  MatCardModule,
  MatDialogModule,
  MatFormFieldModule,
  MatGridListModule,
  MatIconModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { StorageServiceModule } from 'angular-webstorage-service';
import { TextMaskModule } from 'angular2-text-mask';
import { of } from 'rxjs/observable/of';
import { MaterialModule } from '../../../../../../app/material.module';
import { CreatePasswordComponent } from '../../../../../../app/pages/my-account/create-password/create-password.component';
import { MyAccountService } from '../../../../../../app/pages/my-account/my-account.service';
import { BcbsmaerrorHandlerService } from '../../../../../../app/shared/services/bcbsmaerror-handler.service';
import { GlobalService } from '../../../../../../app/shared/services/global.service';
import { ProfileService } from '../../../../../../app/shared/services/myprofile/profile.service';
import { AlertService, ValidationService } from '../../../../../../app/shared/shared.module';
import { ConstantsService } from '../../../../../../app/shared/shared.module';
import { mocks } from '../../../../../constants/mocks.service';
import { verifyfpuser_response } from '../../../../../data/my-account/forgot-password/verifyfpuser.data';
import {
  FakeAlegeusLineChartComponent,
  FakeBreadcrumbsComponent,
  FakeControlMessagesComponent,
  FakeCostBreakdownFilterComponent,
  FakeFadBreadCrumbsComponent,
  FakeFpoLayoutComponent,
  FakePasswordControlMessages
} from '../../../../../fake-components';
import { FakeParentFormFieldDirectiveStub, FakeRouterLinkDirectiveStub } from '../../../../../fake-directives';

describe('CreatePasswordComponent', () => {
  let component: CreatePasswordComponent;
  let fixture: ComponentFixture<CreatePasswordComponent>;

  let mockMyAccountService;
  let mockRouter;
  let mockAlertService;
  let mockProfileService;
  let mockConstantsService;
  let mockGlobalService;
  let mockValidationService;
  let mockBcbsmaerrorHandlerService;

  // create new instance of FormBuilder
  const formBuilder: FormBuilder = new FormBuilder();

  beforeEach(async(() => {
    mockGlobalService = mocks.service.globalService;
    mockMyAccountService = mocks.service.myAccountService;
    mockProfileService = mocks.service.profileService;
    mockBcbsmaerrorHandlerService = mocks.service.bcbsmaerrorHandlerService;
    mockValidationService = mocks.service.validationService;
    mockRouter = mocks.service.router;
    mockAlertService = mocks.service.alertService;
    mockConstantsService = mocks.service.constantsService;

    TestBed.configureTestingModule({
      imports: [
        BrowserModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        StorageServiceModule,
        HttpClientTestingModule,
        TextMaskModule,
        MatFormFieldModule,
        MatRadioModule,

        MatSelectModule,
        MatCardModule,
        MatIconModule,
        MatSidenavModule,
        MatTooltipModule,
        MatGridListModule,
        MatDialogModule,
        MaterialModule
      ],
      declarations: [
        FakeRouterLinkDirectiveStub,
        FakeParentFormFieldDirectiveStub,
        FakeControlMessagesComponent,
        FakeFadBreadCrumbsComponent,
        FakeCostBreakdownFilterComponent,
        FakeAlegeusLineChartComponent,
        FakeBreadcrumbsComponent,
        FakeFpoLayoutComponent,
        FakePasswordControlMessages,
        CreatePasswordComponent
      ],
      providers: [
        { provide: Router, useValue: mockRouter },
        { provide: ConstantsService, useValue: mockConstantsService },
        { provide: MyAccountService, useValue: mockMyAccountService },
        { provide: AlertService, useValue: mockAlertService },
        { provide: ProfileService, useValue: mockProfileService },
        { provide: ValidationService, useValue: mockValidationService },
        { provide: FormBuilder, useValue: formBuilder },
        { provide: BcbsmaerrorHandlerService, useValue: mockBcbsmaerrorHandlerService },
        { provide: GlobalService, useValue: mockGlobalService }
      ]
    }).compileComponents();
  }));

  describe('Constructor', () => {
    describe('While Component Creation', () => {
      // assert constructor contents
      describe('should have initialized', () => {
        beforeEach(() => {
          // arrange

          fixture = TestBed.createComponent(CreatePasswordComponent);

          // act
          component = fixture.componentInstance;
        });
        it('should have initialized this.type to "password"', () => {
          expect(component.type).toBe('password');
        });

        it('should have initialized this.typePlaceholder to "Show"', () => {
          expect(component.typePlaceholder).toBe('Show');
        });

        it('should have initialized this.typeReEnterNew to "password"', () => {
          expect(component.typeReEnterNew).toBe('password');
        });

        it('should have initialized this.typePlaceholderReEnterNew to "Show"', () => {
          expect(component.typePlaceholderReEnterNew).toBe('Show');
        });
      });

      // describe('should have called', () => {
      xit('should have called passwordin fields setValidator method', () => {
        // arrange
        fixture = TestBed.createComponent(CreatePasswordComponent);
        const fb = new FormBuilder();

        CreatePasswordComponent.prototype.createPasswordForm = fb.group({
          passwordin: '',
          reEnterNewPassword: ''
        });

        const target = CreatePasswordComponent.prototype.createPasswordForm.controls['passwordin'];

        const targetSpy = spyOn(target, 'setValidators').and.returnValue(null);

        // act
        component = fixture.componentInstance;
        // debugger;
        // assert
        expect(targetSpy).toHaveBeenCalled();
      });

      xit('should have called reEnterNewPassword fields setValidator method', () => {
        // arrange
        fixture = TestBed.createComponent(CreatePasswordComponent);
        const fb = new FormBuilder();
        CreatePasswordComponent.prototype.createPasswordForm = fb.group({
          passwordin: '',
          reEnterNewPassword: ''
        });
        const target = CreatePasswordComponent.prototype.createPasswordForm.controls['reEnterNewPassword'];
        const targetSpy = spyOn(target, 'setValidators').and.returnValue(null);

        // act
        component = fixture.componentInstance;

        // assert
        expect(targetSpy).toHaveBeenCalled();
      });

      it('should have called validationService.invalidPasswordValidatorWrapper', () => {
        // arrange
        fixture = TestBed.createComponent(CreatePasswordComponent);

        // act
        component = fixture.componentInstance;

        // assert
        expect(mockValidationService.invalidPasswordValidatorWrapper).toHaveBeenCalled();
      });

      it('should have called validationService.checkConfirmPasswordValidator', () => {
        // arrange
        fixture = TestBed.createComponent(CreatePasswordComponent);

        // act
        component = fixture.componentInstance;

        // assert
        expect(mockValidationService.checkConfirmPasswordValidator).toHaveBeenCalled();
      });

      it('should have called Validators.minLength to have been called once', () => {
        // arrange
        spyOn(Validators, 'minLength').and.returnValue({ createPasswordForm: true });
        fixture = TestBed.createComponent(CreatePasswordComponent);

        // act
        component = fixture.componentInstance;

        // assert
        expect(Validators.minLength).toHaveBeenCalled();
      });

      it('should have called this.alertService.clearError', () => {
        // arrange
        fixture = TestBed.createComponent(CreatePasswordComponent);

        // act
        component = fixture.componentInstance;

        // assert
        expect(mockAlertService.clearError).toHaveBeenCalled();
      });
      describe('error handler', () => {
        it('should catch errors and handle them as and when they occur', () => {
          spyOn(formBuilder, 'group').and.callFake(() => {
            throw new Error('an-exception');
          });
          // arrange
          fixture = TestBed.createComponent(CreatePasswordComponent);
          // act
          component = fixture.componentInstance;
          // assert
          expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
        });
      });

      // });
    });
  });

  describe('ngOnInit', () => {
    beforeEach(() => {
      // arrange
      fixture = TestBed.createComponent(CreatePasswordComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
    });
  });

  describe('Methods', () => {
    describe('ngOnDestroy', () => {
      it('should have called this.alertService.clearError', () => {
        // arrange
        fixture = TestBed.createComponent(CreatePasswordComponent);
        component = fixture.componentInstance;

        // act
        component.ngOnDestroy();

        // assert
        expect(mockAlertService.clearError).toHaveBeenCalled();
      });

      describe('error handling', () => {
        it('should call the BcbsmaerrorHandlerService.logError', () => {
          try {
            // arrange
            fixture = TestBed.createComponent(CreatePasswordComponent);
            component = fixture.componentInstance;
            component['alertService'] = null;
            // act
            try {
              fixture.detectChanges();
            } catch (forcedError) {}
            // assert
            expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
          } catch (error) {
            console.warn(error);
          }
        });
      });
    });

    describe('togglenewPasswordVisibility', () => {
      beforeEach(() => {
        // arrange
        fixture = TestBed.createComponent(CreatePasswordComponent);
        component = fixture.componentInstance;
      });
      describe('when called with param confirmPassword=true', () => {
        describe('when this.typeReEnterNew = "text"', () => {
          it('should change the value of component.typeReEnterNew to "password"', () => {
            // arrange
            component.typeReEnterNew = 'text';

            // act
            component.togglePasswordVisibility(true);

            // assert
            expect(component.typeReEnterNew).toBe('password');
          });
          it('should change the value of component.typePlaceholderReEnterNew to "Show"', () => {
            // arrange
            component.typeReEnterNew = 'text';

            // act
            component.togglePasswordVisibility(true);

            // assert
            expect(component.typePlaceholderReEnterNew).toBe('Show');
          });
        });
        describe('when this.typeReEnterNew = "password"', () => {
          it('should change the value of component.typeReEnterNew to "text"', () => {
            // arrange
            component.typeReEnterNew = 'password';

            // act
            component.togglePasswordVisibility(true);

            // assert
            expect(component.typeReEnterNew).toBe('text');
          });
          it('should change the value of component.typePlaceholderReEnterNew to "Hide"', () => {
            // arrange
            component.typeReEnterNew = 'password';

            // act
            component.togglePasswordVisibility(true);

            // assert
            expect(component.typePlaceholderReEnterNew).toBe('Hide');
          });
        });
      });
      describe('when called with param confirmPassword=false', () => {
        describe('when this.type = "text"', () => {
          it('should change the value of component.type to "password"', () => {
            // arrange
            component.type = 'text';

            // act
            component.togglePasswordVisibility(false);

            // assert
            expect(component.type).toBe('password');
          });
          it('should change the value of component.typePlaceholder to "Show"', () => {
            // arrange
            component.type = 'text';

            // act
            component.togglePasswordVisibility(false);

            // assert
            expect(component.typePlaceholder).toBe('Show');
          });
        });
        describe('when this.typeNew = "password"', () => {
          it('should change the value of component.type to "text"', () => {
            // arrange
            component.type = 'password';

            // act
            component.togglePasswordVisibility(false);

            // assert
            expect(component.type).toBe('text');
          });
          it('should change the value of component.typePlaceholderReEnterNew to "Hide"', () => {
            // arrange
            component.type = 'password';

            // act
            component.togglePasswordVisibility(false);

            // assert
            expect(component.typePlaceholder).toBe('Hide');
          });
        });
      });

      // this.togglePasswordVisibility trigger always try block because this focus on window property.
      xdescribe('error handling', () => {
        it('should call the BcbsmaerrorHandlerService.logError', () => {
          try {
            // arrange
            fixture = TestBed.createComponent(CreatePasswordComponent);
            component = fixture.componentInstance;
            // component.togglePasswordVisibility = null;
            // act
            try {
              component.togglePasswordVisibility(null);
            } catch (forcedError) {}
            // assert
            expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
          } catch (error) {
            console.warn(error);
          }
        });
      });
    });

    describe('onSubmit', () => {
      beforeEach(() => {
        // arrange
        mockMyAccountService.resetPassword.and.returnValue(of(verifyfpuser_response.success));
        TestBed.overrideProvider(MyAccountService, { useValue: mockMyAccountService });
        TestBed.compileComponents();
      });
      beforeEach(async () => {
        fixture = TestBed.createComponent(CreatePasswordComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
      });

      afterAll(() => {
        mockMyAccountService.resetPassword.and.returnValue(of(verifyfpuser_response.success));
        TestBed.overrideProvider(MyAccountService, { useValue: mockMyAccountService });
        TestBed.compileComponents();
      });

      it('should have called this.mockMyAccountService.resetPassword', () => {
        // act
        component.onSubmit();

        // assert
        expect(mockMyAccountService.resetPassword).toHaveBeenCalled();
      });

      it('should set the createPasswordForm passwordin value as empty', () => {
        // act
        const res = verifyfpuser_response.success.original.result;
        const result = component.createPasswordForm.controls.passwordin.setValue('');
        component.onSubmit();
        // assert
        if (res !== '0') {
          expect(result).toBeTruthy();
        }
      });

      it('should have called globalService.handleError', () => {
        // act
        const result = verifyfpuser_response.success.original.result;
        component.onSubmit();

        // assert
        if (result === '0') {
          expect(mockGlobalService.handleError).toHaveBeenCalled();
        }
      });

      it('should have called this.accountService.clearStorage', () => {
        // act
        const result: any = verifyfpuser_response.success.original.result;
        component.onSubmit();

        // assert
        if (result === '0' && result === 0) {
          expect(mockMyAccountService.clearStorage).toHaveBeenCalled();
        }
      });

      it('should have called this.router.navigate as ["../login"]', () => {
        // act
        const result: any = verifyfpuser_response.success.original.result;
        component.onSubmit();

        // assert
        if (result === '0' && result === 0) {
          expect(mockRouter.navigate).toHaveBeenCalledWith(['../login']);
        }
      });

      describe('error handling', () => {
        it('should call the BcbsmaerrorHandlerService.logError in case of errors in the method', () => {
          // arrange
          mockMyAccountService.resetPassword.and.callFake(() => {
            throw new Error('an-exception');
          });
          TestBed.overrideProvider(MyAccountService, mockMyAccountService);
          TestBed.compileComponents();

          fixture = TestBed.createComponent(CreatePasswordComponent);
          component = fixture.componentInstance;

          // act
          component.onSubmit();

          // assert
          expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
        });
      });
      afterAll(() => {
        mockMyAccountService.resetPassword.and.returnValue(of(verifyfpuser_response.success));
        TestBed.overrideProvider(MyAccountService, mockMyAccountService);
        TestBed.compileComponents();
      });
    });

    describe('showErrorOnBlur', () => {
      it('should update this.showPasswordErrors to true, when called with param : confirmPassword=true', () => {
        // arrange
        fixture = TestBed.createComponent(CreatePasswordComponent);
        component = fixture.componentInstance;

        // act
        component.showErrorOnBlur(true);

        // assert
        expect(component.showPasswordErrors).toBeTruthy();
      });

      it('should update this.showPasswordErrors to true, when called with param : confirmPassword=false', () => {
        // arrange
        fixture = TestBed.createComponent(CreatePasswordComponent);
        component = fixture.componentInstance;

        // act
        component.showErrorOnBlur(false);

        // assert
        expect(component.showPasswordErrors).toBeTruthy();
      });

      // this.showPasswordErrors trigger always try block because this focus on window property.
      xdescribe('error handling', () => {
        it('should call the BcbsmaerrorHandlerService.logError', () => {
          try {
            // arrange
            fixture = TestBed.createComponent(CreatePasswordComponent);
            component = fixture.componentInstance;

            component.showErrorOnBlur(false);

            expect(mockBcbsmaerrorHandlerService.logError).toHaveBeenCalled();
          } catch (error) {
            console.warn(error);
          }
        });
      });
    });
  });
});
