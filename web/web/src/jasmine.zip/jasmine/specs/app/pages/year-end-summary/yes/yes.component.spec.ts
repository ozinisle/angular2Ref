import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { YesComponent } from '../../../../../../app/pages/year-end-summary/yes/yes.component';

xdescribe('YesComponent', () => {
  let component: YesComponent;
  let fixture: ComponentFixture<YesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [YesComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
