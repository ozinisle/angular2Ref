import { environmentDefault as environment } from '../../../app/services/environement/environment.config';

describe('environment', () => {
  describe('should have attributes/properties', () => {
    it('should have a property name "uitxnid"', () => {
      expect(environment.hasOwnProperty('uitxnid')).toBeTruthy();
    });

    it('should have a property name "production"', () => {
      expect(environment.hasOwnProperty('production')).toBeTruthy();
    });

    it('should have a property name "dynamicTagLink"', () => {
      expect(environment.hasOwnProperty('dynamicTagLink')).toBeTruthy();
    });

    it('should have a property name "screenNavigationSLA"', () => {
      expect(environment.hasOwnProperty('screenNavigationSLA')).toBeTruthy();
    });

    it('should have a property name "tokenbaseurl"', () => {
      expect(environment.hasOwnProperty('tokenbaseurl')).toBeTruthy();
    });

    it('should have a property name "tokensEndPoint"', () => {
      expect(environment.hasOwnProperty('tokensEndPoint')).toBeTruthy();
    });

    it('should have a property name "serviceUrl"', () => {
      expect(environment.hasOwnProperty('serviceUrl')).toBeTruthy();
    });

    it('should have a property name "serviceUrlV2"', () => {
      expect(environment.hasOwnProperty('serviceUrlV2')).toBeTruthy();
    });

    it('should have a property name "privacyUrl"', () => {
      expect(environment.hasOwnProperty('privacyUrl')).toBeTruthy();
    });

    it('should have a property name "drupalTestUrl"', () => {
      expect(environment.hasOwnProperty('drupalTestUrl')).toBeTruthy();
    });

    it('should have a property name "enableconsolelog"', () => {
      expect(environment.hasOwnProperty('enableconsolelog')).toBeTruthy();
    });

    it('should have a property name "drupalHomeUrl"', () => {
      expect(environment.hasOwnProperty('drupalHomeUrl')).toBeTruthy();
    });

    it('should have a property name "contactus"', () => {
      expect(environment.hasOwnProperty('contactus')).toBeTruthy();
    });

    it('should have a property name "educationCenter"', () => {
      expect(environment.hasOwnProperty('educationCenter')).toBeTruthy();
    });

    it('should have a property name "drupalsecureinquiry"', () => {
      expect(environment.hasOwnProperty('drupalsecureinquiry')).toBeTruthy();
    });

    it('should have a property name "leafLetUrl"', () => {
      expect(environment.hasOwnProperty('leafLetUrl')).toBeTruthy();
    });

    it('should have a property name "impersonation"', () => {
      expect(environment.hasOwnProperty('impersonation')).toBeTruthy();
    });
  });

  describe('should have boolean attributes', () => {
    it('should have a boolean type attribute named "uitxnid"', () => {
      expect(typeof environment.uitxnid).toBe('boolean');
    });
    it('should have a boolean type attribute named "enableconsolelog"', () => {
      expect(typeof environment.enableconsolelog).toBe('boolean');
    });
    it('should have a boolean type attribute named "impersonation"', () => {
      expect(typeof environment.impersonation).toBe('boolean');
    });
  });

  describe('should have number attributes', () => {
    it('should have a number attribute of type "screenNavigationSLA"', () => {
      expect(typeof environment.screenNavigationSLA).toBe('number');
    });
  });
  describe('should have string attributes', () => {
    it('should have a string type attribute named "dynamicTagLink"', () => {
      expect(typeof environment.dynamicTagLink).toBe('string');
    });

    it('should have a string type attribute named "tokenbaseurl"', () => {
      expect(typeof environment.tokenbaseurl).toBe('string');
    });

    it('should have a string type attribute named "tokensEndPoint"', () => {
      expect(typeof environment.tokensEndPoint).toBe('string');
    });

    it('should have a string type attribute named "serviceUrl"', () => {
      expect(typeof environment.serviceUrl).toBe('string');
    });

    it('should have a string type attribute named "serviceUrlV2"', () => {
      expect(typeof environment.serviceUrlV2).toBe('string');
    });

    it('should have a string type attribute named "privacyUrl"', () => {
      expect(typeof environment.privacyUrl).toBe('string');
    });

    it('should have a string type attribute named "drupalTestUrl"', () => {
      expect(typeof environment.drupalTestUrl).toBe('string');
    });

    it('should have a string type attribute named "drupalHomeUrl"', () => {
      expect(typeof environment.drupalHomeUrl).toBe('string');
    });

    it('should have a string type attribute named "contactus"', () => {
      expect(typeof environment.contactus).toBe('string');
    });

    it('should have a string type attribute named "educationCenter"', () => {
      expect(typeof environment.educationCenter).toBe('string');
    });

    it('should have a string type attribute named "drupalsecureinquiry"', () => {
      expect(typeof environment.drupalsecureinquiry).toBe('string');
    });

    it('should have a string type attribute named "leafLetUrl"', () => {
      expect(typeof environment.leafLetUrl).toBe('string');
    });
  });

  // NOTE: DO NOT DELETE
  // Test cases have been developed against values configured as follows
  // export const environment = {
  //     uitxnid: true,
  //     production: false, //strip key using this constant
  //     dynamicTagLink: '//assets.adobedtm.com/launch-ENfd28d85532164d63933fc8f696980fe5-staging.min.js',
  //     screenNavigationSLA: 3000,
  //     tokenbaseurl: 'https://mobilememberstage.bluecrossma.com',
  //     tokensEndPoint: '/memwebapi1_test/mobilekeyservice/v1/gettokens',
  //     serviceUrl: 'https://bcbsma-test.apigee.net/member/web/v1/',
  //     // Security Fixes
  //     serviceUrlV2: 'https://bcbsma-test.apigee.net/member/web/v2/',
  //     privacyUrl: 'https://myblueapi.bluecrossma.com/page/',
  //     drupalTestUrl: 'https://games.bluecrossma.com',
  //     enableconsolelog: true,
  //     drupalHomeUrl: 'https://myblue.bluecrossma.com/',
  //     contactus: 'https://myblue.bluecrossma.com/contact-us',
  //     educationCenter: 'https://myblue.bluecrossma.com/health-plan/plan-education-center',
  //     drupalsecureinquiry: 'http://20181010myblue.bluecrossma.acsitefactory.com/inquiry',
  //     leafLetUrl: 'https://api.mapbox.com/',
  //     impersonation: false
  // };
});
