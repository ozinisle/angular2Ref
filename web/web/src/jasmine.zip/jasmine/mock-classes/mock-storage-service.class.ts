export class MockStorageService {
  get(key: string): any {
    return '';
  }
  set(key: string, value: any): void {
    return;
  }
  remove(key: string): void {
    return;
  }
}
