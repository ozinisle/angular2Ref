import { ActionReducer, ActionsSubject, ReducerManager, StateObservable, Store } from '@ngrx/store';
import { Observable, Observer, Operator } from 'rxjs';
import { Action } from 'rxjs/scheduler/Action';

export class MockStore<T> extends Observable<T> implements Observer<Action<T>> {
  private actionsObserver;
  private reducerManager;
  constructor(public state$?: StateObservable, actionsObserver?: ActionsSubject, reducerManager?: ReducerManager) {
    super();
  }
  select<K>(mapFn: (state: T) => K): MockStore<K> {
    return new MockStore(this.state$, this.actionsObserver, this.reducerManager);
  }

  lift<R>(operator: Operator<T, R>): MockStore<R> {
    return new MockStore(this.state$, this.actionsObserver, this.reducerManager);
  }
  dispatch<V>(action: V): void {}
  next(action): void {}
  error(err: any): void {}
  complete(): void {}
  addReducer<State, Actions>(key: string, reducer: ActionReducer<State, null>): void {}
  removeReducer<Key extends keyof T>(key: Key): void {}
}
