import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

import { Filter } from '../app/shared/components/dedcofilter/dedco-filter.model';
import { FilterInterface } from '../app/shared/components/financialsfilter/filter.model';

import { FadReviewQuestion } from '../app/pages/fad/modals/fad-review-questions.modal';
import { BreadCrumb } from '../app/pages/fad/utils/fad.utils';
import { LineChartOptionsInterface } from '../app/shared/components/line-chart/line-chart.interface';
import { LineChartOptions } from '../app/shared/components/line-chart/line-chart.model';
import { Image } from '../app/shared/models/image.model';

@Component({
  selector: 'app-fake-route-target',
  template: '<div></div>'
})
export class FakeRouteTargetComponent {}

@Component({
  selector: 'app-fad-bread-crumbs',
  template: '<div></div>'
})
export class FakeFadBreadCrumbsComponent {}

@Component({
  selector: 'app-cost-breakdown-financials-filter',
  template: '<div></div>'
})
export class FakeCostBreakdownFilterComponent {
  @Input() filterConfig: FilterInterface = new Filter();
  @Input() dispatchEvent = '';
  @Output() radioChange = new EventEmitter();
  @Output() toggleFilter = new EventEmitter(); // Mobile & Tablet
}

@Component({
  selector: 'app-alegeus-linechart',
  template: '<div></div>'
})
export class FakeAlegeusLineChartComponent {
  @Input() public lineChartOptions: LineChartOptions = new LineChartOptions()
    .setHeaderText('')
    .setHeaderText1('')
    .setTotalValue(0)
    .setChartValue(0)
    .setChartOption1Text('')
    .setChartOption2Text('');
}

@Component({
  selector: 'app-control-messages',
  template: '<div></div>'
})
export class FakeControlMessagesComponent {
  @Input() control: FormControl;
  @Input() customMessages: any;
  @Input() valdiateOnFormSubmit = false;
  @Input() isFormSubmitted = false;
  @Input() controlName = '';
}

@Component({
  selector: 'app-breadcrumbs',
  template: '<div></div>'
})
export class FakeBreadcrumbsComponent {
  @Input('breadCrumbs') breadCrumbs: BreadCrumb[] = [];
}

@Component({
  selector: 'app-fpo-layout',
  template: '<div></div>'
})
export class FakeFpoLayoutComponent {
  @Input() targetUrl = '';
  @Input() toolTipdataPlans: object = {};
  @Input() isplandetails = false;
  @Input() displayCategory = '';
  @Input() layout = '';
  @Output() closePullTextEmitter = new EventEmitter();
}

@Component({
  selector: 'app-header',
  template: '<div></div>'
})
export class FakeHeaderComponent {}

@Component({
  selector: 'app-alerts',
  template: '<div></div>'
})
export class FakeAlertsComponent {}

@Component({
  selector: 'app-footer',
  template: '<div></div>'
})
export class FakefooterComponent {}

@Component({
  selector: 'app-session',
  template: '<div></div>'
})
export class FakesessionComponent {}

@Component({
  selector: 'app-password-control-messages',
  template: '<div></div>'
})
export class FakePasswordControlMessages {
  @Input() control: FormControl;
  @Input() password: string;
  @Input() isSubmitted: boolean;
  @Input() isBlurEvent: boolean;
}

@Component({
  selector: 'app-financialchart',
  template: '<div></div>'
})
export class FakeFinancialChartComponent {
  @Input() public lineChartOptions: LineChartOptionsInterface;
}

@Component({
  selector: 'app-inactive-homepage-fpo-layout',
  template: '<div></div>'
})
export class FakeInactiveHomePageFpoLayoutComponent {
  @Input() targetUrl: string;
  @Input() toolTipdataPlans: object;
  @Input() isplandetails: boolean;
  @Input() displayCategory: string;
  @Input() layout = '';
  @Output() closePullTextEmitter = new EventEmitter();
}

@Component({
  selector: 'app-spinner',
  template: '<div></div>'
})
export class FakeSpinnerComponent {
  @Input() public showSpinner = false;
}

@Component({
  selector: 'app-spinnertimeout',
  template: '<div></div>'
})
export class FakeSpinnertimeoutComponent {}

@Component({
  selector: 'app-linechart',
  template: '<div></div>'
})
export class FakeLineChartComponent {
  @Input() public lineChartOptions: LineChartOptionsInterface;
}

@Component({
  selector: 'app-promo-carousel',
  template: '<div></div>'
})
export class FakePromoCarouselComponent {
  @Input() carouselItems: Image[];
  @Input() ismobile: boolean;
}

@Component({
  selector: 'app-promo-blocks',
  template: '<div></div>'
})
export class FakePromoBlocksComponent {
  @Input() data: any;
  @Input() ismobile: boolean;
}

@Component({
  selector: 'app-promo-images',
  template: '<div></div>'
})
export class FakePromoImagesComponent {
  @Input() images: any[];
  @Input() type;
}

@Component({
  selector: 'app-fad-review-question',
  template: '<div></div>'
})
export class FakeFadReviewQuestionComponent {
  @Input() form: FormGroup;
  @Input() question: FadReviewQuestion;
}

@Component({
  selector: 'app-card',
  template: '<div></div>'
})
export class FakeCardComponent {
  @Input('cardData') cardData: any;
  @Input('hasDependents') hasDependents: boolean;
  @Input('ismobile') ismobile: boolean;
}

@Component({
  selector: 'app-dedco-filter',
  template: '<div></div>'
})
export class FakeDedcoFilterComponent {
  @Input() filterConfig: FilterInterface;
  @Input() dispatchEvent: string;
  @Output() radioChange = new EventEmitter();
  @Output() checkboxChange = new EventEmitter();
  @Output() dateChange = new EventEmitter();
  @Output() applyFilter = new EventEmitter();
  @Output() clearFilter = new EventEmitter();
  @Output() toggleFilter = new EventEmitter();
}

@Component({
  selector: 'app-maintenance',
  template: '<div></div>'
})
export class FakeMaintenanceComponent {}

@Component({
  selector: 'app-profile-email',
  template: '<div></div>'
})
export class FakeProfileEmailComponent {
  @Input() profile: any;
  @Input() editEmail: boolean;
  @Input() slot: string;
  @Output() preferenceSuccess: EventEmitter<any> = new EventEmitter();
  @Output() cancelEdit: EventEmitter<any> = new EventEmitter();
  @Output() editProfile: EventEmitter<any> = new EventEmitter();
}

@Component({
  selector: 'app-profile-phone',
  template: '<div></div>'
})
export class FakeProfilePhoneComponent {
  @Input() profile: any;
  @Input() editPhone: boolean;
  @Input() slot: string;
  @Output() preferenceSuccess: EventEmitter<any> = new EventEmitter();
  @Output() cancelEdit: EventEmitter<any> = new EventEmitter();
  @Output() editProfile: EventEmitter<any> = new EventEmitter();
}

@Component({
  selector: 'app-modals',
  template: '<div></div>'
})
export class FakeAppmodalsComponent {}