import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { of } from 'rxjs/observable/of';
import { AuthService } from '../../shared/services/auth.service';
import { FadService } from '../fad/fad.service';

@Injectable()
export class FadResolver implements Resolve<Observable<any>> {
  constructor(private fadService: FadService, private authService: AuthService) {}

  async resolve() {
    const fadData = JSON.parse(sessionStorage.getItem('fadData'));
    return fadData
      ? of([])
      : this.fadService.resolve(true).then(result => {
          sessionStorage.setItem('fadData', JSON.stringify(result, null, 2));
          return of(result);
        });
  }
}
