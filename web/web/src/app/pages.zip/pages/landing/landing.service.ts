import { TitleCasePipe } from '@angular/common';
import { Injectable } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import * as moment from 'moment';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { publishReplay, refCount } from 'rxjs/operators';
import { Subject } from 'rxjs/Subject';
import { environment } from '../../../environments/environment';
import { LineChartOptionsInterface } from '../../shared/components/alegeus-line-chart/line-chart.interface';
import { LineChartOptions } from '../../shared/components/alegeus-line-chart/line-chart.model';
import { Finanical, TransactionInfo } from '../../shared/models/finanical.model';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { AuthService } from '../../shared/services/auth.service';
import { ConstantsService } from '../../shared/services/constants.service';
import { DependantsService } from '../../shared/services/dependant.service';
import {
  CoinsuranceInterface,
  OutofpocketInterface,
  OverallBenefitInterface,
  OverallDeductablesInterface
} from '../myded-co/models/interfaces/myded-co-info-model.interface';
import { AccumChartType } from '../myded-co/models/types/myded-co.types';
import { BRAND_PROMO } from './constants/homepage.constants';
import { ArticleModel, HomePageInfoModel } from './landing.model';

const brandPromo = BRAND_PROMO;
@Injectable()
export class LandingService {
  public articleSubject1$: BehaviorSubject<ArticleModel>;
  public articleSubject2$: BehaviorSubject<ArticleModel>;
  public articleSubject3$: BehaviorSubject<ArticleModel>;

  public article1$: Observable<ArticleModel>;
  public article2$: Observable<ArticleModel>;
  public article3$: Observable<ArticleModel>;

  public articles: any;
  public memberInfo: HomePageInfoModel;
  public hasMedicalAccounts$ = new BehaviorSubject(false);
  public hasFinancialView$ = new BehaviorSubject(false);
  public financialInfoLength$ = new Subject();
  private financialResponse$: Observable<any>;
  private homePageResponse$: Observable<HomePageInfoModel>;
  private isHeqTransactionsEnabled: boolean;

  constructor(
    private http: AuthHttp,
    private constants: ConstantsService,
    private sanitizer: DomSanitizer,
    private constantsService: ConstantsService,
    private authService: AuthService,
    private dependantsService: DependantsService,
    private titleCase: TitleCasePipe
  ) {
    this.articleSubject1$ = new BehaviorSubject(new ArticleModel(1));
    this.articleSubject2$ = new BehaviorSubject(new ArticleModel(2));
    this.articleSubject3$ = new BehaviorSubject(new ArticleModel(3));

    this.article1$ = this.articleSubject1$.asObservable();
    this.article2$ = this.articleSubject2$.asObservable();
    this.article3$ = this.articleSubject3$.asObservable();

    this.articles = [];
    this.articles.push(this.article1$);
    this.articles.push(this.article2$);
    this.articles.push(this.article3$);

    this.isHeqTransactionsEnabled = environment.showHeqTransactions;
  }

  loadArticle(number) {
    this.http.get(this.constants.drupalTestUrl + `/page/home-promoblock${number}`).subscribe(item => {
      this[`articleSubject${number}$`].next(new ArticleModel(number).deserialize(item[0], this.sanitizer));
    });
  }

  heroBannerItemsDetails(bannetType?: string): Observable<any> {
    return this.http.get(this.constantsService.drupalTestUrl + '/page/myblue-banner' + (bannetType ? '?type=' + bannetType : ''));
  }

  promoDetails(id): Observable<any> {
    return this.http.get(this.constantsService.drupalTestUrl + brandPromo[id]);
  }

  getCarouselItemDetails(): Observable<any> {
    return this.http.get(this.constantsService.drupalSliderUrl);
  }

  getRecommendedForYouContent(): Observable<any> {
    return this.http.get(this.constantsService.drupalRecommendedUrl + '?tileids=78266,78271,78276');
  }

  getFinanceBalanceData(): Observable<any> {
    const request = {
      useridin: this.authService.useridin,
      noOfTransactionsPerAccount: this.isHeqTransactionsEnabled ? 5 : 0
    };

    return this.http.encryptPost(this.constants.financeUrl, request, null, null, false);
  }

  getFinanceBalancChartData(): Observable<any> {
    if (!this.financialResponse$) {
      this.financialResponse$ = this.getFinanceBalanceData()
        .pipe(publishReplay(1), refCount())
        .map(response => {
          this.hasMedicalAccounts$.next(response.hasMedicalAccounts);
          const financialInfo = this.transformFinanceChartData(response);
          this.financialInfoLength$.next((financialInfo || []).length);
          return {
            financialInfo,
            hasMedicalAccounts: response.hasMedicalAccounts
          };
        });
    }
    return this.financialResponse$;
  }

  clearCache() {
    this.financialResponse$ = null;
    this.homePageResponse$ = null;
  }

  extractTransactions(transactions: any[]) {
    const noTransactions = new TransactionInfo();
    noTransactions.description = 'No Recent Transaction';
    if (!transactions || !transactions.length) {
      return [];
    }
    if (transactions.length < 5) {
      return transactions.concat(Array(5 - transactions.length).fill(noTransactions));
    }
    return transactions;
  }

  // Heq data
  transformChartDataForHeq(finanicalInfo: any): Finanical {
    const finanicalData = new Finanical();
    finanicalData.acountNumber = finanicalInfo.acountNumber
      ? finanicalInfo.acountNumber.substr(0, finanicalInfo.acountNumber.length - 4).replace(/[0-9]/g, '*') +
        finanicalInfo.acountNumber.substr(-4)
      : '';
    finanicalData.Type = finanicalInfo.type || '';
    finanicalData.PlanStartDate = finanicalInfo.planStartDate
      ? `${moment(finanicalInfo.planStartDate, 'YYYYMMDD').format('MM/DD/YYYY')} - ${moment(finanicalInfo.planEndDate, 'YYYYMMDD').format(
          'MM/DD/YYYY'
        )}`
      : '';
    finanicalData.PlanEndDate = '';
    finanicalData.transactions = this.extractTransactions(finanicalInfo.transactions);
    finanicalData.chartOptions = new LineChartOptions()
      .setHeaderText(this.isHsaAccount(finanicalInfo.type) ? '' : 'Annual Election')
      .setHeaderText1(finanicalInfo.accountName)
      .setTotalValue(finanicalInfo.balanceAvailable)
      .setChartValue(this.isHsaAccount(finanicalInfo.type) ? finanicalInfo.investments : finanicalInfo.spent) // investments savingssccounts
      .setAnnualElection(finanicalInfo.electionAmount !== undefined ? finanicalInfo.electionAmount : '')
      .setChartColor('#3DA148')
      .setChartBackgroundColor('#FFFFFF')
      .setChartOption1Text('Available')
      .setChartOption2Text(this.isHsaAccount(finanicalInfo.type) ? 'Investment' : 'Spent');
    return finanicalData;
  }

  isHsaAccount(type) {
    return type === 'ABH' || type === 'HSA' || type === 'AB2';
  }

  // alg data
  transformChartDataForAlg(finanicalInfo: any): Finanical {
    const finanicalData = new Finanical();
    finanicalData.isALGAccount = true;
    finanicalData.acountNumber = finanicalInfo.acountNumber
      ? finanicalInfo.acountNumber.substr(0, finanicalInfo.acountNumber.length - 4).replace(/[0-9]/g, '*') +
        finanicalInfo.acountNumber.substr(-4)
      : '';
    finanicalData.Type = finanicalInfo.type || '';
    finanicalData.PlanStartDate = finanicalInfo.planStartDate ? moment(finanicalInfo.planStartDate, 'YYYYMMDD').format() : '';
    finanicalData.PlanEndDate = finanicalInfo.planEndDate ? moment(finanicalInfo.planEndDate, 'YYYYMMDD').format() : '';
    finanicalData.chartOptions = new LineChartOptions()
      .setHeaderText('Annual Election')
      .setHeaderText1(finanicalInfo.accountName)
      .setTotalValue(finanicalInfo.balanceAvailable)
      .setChartValue(this.isHsaAccount(finanicalInfo.type) ? finanicalInfo.investments : finanicalInfo.spent)
      .setAnnualElection(finanicalInfo.electionAmount !== undefined ? finanicalInfo.electionAmount : '')
      .setChartColor('#3DA148')
      .setChartBackgroundColor('#FFFFFF')
      .setChartOption1Text('Available')
      .setChartOption2Text(this.isHsaAccount(finanicalInfo.type) ? 'Investment' : 'Spent');
    return finanicalData;
  }

  transformFinanceChartData(response: any): Finanical[] {
    const finanicalDataList = [];

    const transformHeqInfo = accountInfo => finanicalDataList.push(this.transformChartDataForHeq(accountInfo));
    const transformAlgInfo = accountInfo => finanicalDataList.push(this.transformChartDataForAlg(accountInfo));

    if (response && response.heqAccounts) {
      if (response.heqAccounts.reimbursementAccountInfo && response.heqAccounts.reimbursementAccountInfo.length) {
        response.heqAccounts.reimbursementAccountInfo.forEach(transformHeqInfo);
      }
      if (response.heqAccounts.savingsAccountInfo && response.heqAccounts.savingsAccountInfo.length) {
        response.heqAccounts.savingsAccountInfo.forEach(transformHeqInfo);
      }
    }
    if (response && response.algsAccounts) {
      if (response.algsAccounts.reimbursementAccountInfo && response.algsAccounts.reimbursementAccountInfo.length) {
        response.algsAccounts.reimbursementAccountInfo.forEach(transformAlgInfo);
      }
      if (response.algsAccounts.savingsAccountInfo && response.algsAccounts.savingsAccountInfo.length) {
        response.algsAccounts.savingsAccountInfo.forEach(transformAlgInfo);
      }
    }
    return finanicalDataList;
  }

  getHomePageInfo(): Observable<HomePageInfoModel> {
    if (!this.homePageResponse$) {
      const request = {
        useridin: this.authService.useridin
      };
      this.homePageResponse$ = this.http.encryptPost(this.constants.homepageUrl, request).do(result => {
        if (result && result.ROWSET && result.ROWSET.ROW) {
          this.memberInfo = new HomePageInfoModel(this.titleCase).deserialize(result.ROWSET.ROW);
          sessionStorage.setItem('wellnessVendorCd', result.ROWSET.ROW.wellnessVendorCd);
        }
      });
    }
    return this.homePageResponse$;
  }

  getDedcoInfo() {
    const request = {
      useridin: this.authService.useridin
    };
    return this.http.encryptPost(this.constants.dedcoUrl, request, null, null, false);
  }

  public getLineChartOptions(
    accumItem: CoinsuranceInterface | OverallDeductablesInterface | OutofpocketInterface | OverallBenefitInterface,
    target: AccumChartType
  ): LineChartOptionsInterface {
    const lineChartOptions: LineChartOptionsInterface = new LineChartOptions();

    let refinedAccumItem: CoinsuranceInterface | OverallDeductablesInterface | OutofpocketInterface | OverallBenefitInterface = null;

    let headerText = '';
    let totalValue = 0;
    let chartValue = 0;

    switch (target) {
      case AccumChartType.Coinsurance:
        refinedAccumItem = accumItem as CoinsuranceInterface;
        headerText = 'Co-Insurance Maximum';
        totalValue = Number(refinedAccumItem.coinsuranceMax);
        chartValue = refinedAccumItem.coinsuranceContributed ? Number(refinedAccumItem.coinsuranceContributed) : 0;
        break;

      case AccumChartType.overallDeductables:
        refinedAccumItem = accumItem as OverallDeductablesInterface;
        headerText = 'Overall Deductible';
        totalValue = Number(refinedAccumItem.overallDeductible);
        chartValue = refinedAccumItem.deductibleContributed ? Number(refinedAccumItem.deductibleContributed) : 0;

        break;

      case AccumChartType.overallBenefit:
        refinedAccumItem = accumItem as OverallBenefitInterface;
        headerText = 'Over-All-Benefit Maximum';
        totalValue = refinedAccumItem.overallBenefitMax;
        chartValue = refinedAccumItem.overallBenefitMaxContributed ? Number(refinedAccumItem.overallBenefitMaxContributed) : 0;

        break;

      case AccumChartType.outOfPocket:
        refinedAccumItem = accumItem as OutofpocketInterface;
        headerText = 'Out-Of-Pocket Maximum';
        totalValue = refinedAccumItem.outOfPocketMax;
        chartValue = refinedAccumItem.oopMaxContributed ? Number(refinedAccumItem.oopMaxContributed) : 0;
        break;

      case AccumChartType.firstCoverage:
        refinedAccumItem = accumItem as OverallDeductablesInterface;
        headerText = 'First Coverage';
        totalValue = Number(refinedAccumItem.overallDeductible);
        chartValue = refinedAccumItem.deductibleContributed ? Number(refinedAccumItem.deductibleContributed) : 0;
        break;

      default:
        break;
    }

    lineChartOptions
      .setHeaderText(headerText)
      .setTotalValue(totalValue)
      .setChartValue(chartValue)
      .setChartColor('#2574bb')
      .setChartBackgroundColor('#FFFFFF')
      .setChartOption1Text('Contributed')
      .setChartOption2Text('Remaining to Meet');
    return lineChartOptions;
  }
}
