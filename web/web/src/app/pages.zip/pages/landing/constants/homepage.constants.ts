export const QUICK_ACCESS_LINKS = [
  {
    id: 'ql-claim-status',
    label: 'CHECK A CLAIM',
    icon: 'fal fa-file-invoice-dollar',
    link: '../myclaims'
  },
  {
    id: 'ql-my-doctors',
    label: 'SEE MY DOCTORS',
    icon: 'fal fa-user-md',
    link: '../mydoctors'
  },
  {
    id: 'ql-plan-documentsclaim',
    label: 'SEE MY PLAN',
    icon: 'fal fa-file-alt',
    link: '../message-center/documents/planDocuments'
  }
];

export const TRACK_WIDGETS = [
  // {
  //   id: 'ql-rewards',
  //   label: 'REWARDS',
  //   icon: 'fal fa-gift-card',
  //   link: '../myclaims',
  //   hasWidget: true,
  //   selected: false,
  // },
  {
    label: 'FINANCIAL ACCOUNTS',
    icon: 'fal fa-piggy-bank',
    hasWidget: true,
    selected: true,
  },
  // {
  //   id: 'ql-inbox',
  //   label: 'INBOX',
  //   icon: 'fal fa-envelope',
  //   link: '../message-center/documents/planDocuments',
  //   hasWidget: true,
  //   selected: false,
  // },
  // {
  //   id: 'ql-add-widget-1',
  //   label: 'Add a widget',
  //   icon: 'fal fa-plus',
  //   link: '../message-center/documents/planDocuments',
  //   hasWidget: false,
  //   selected: false,
  // },
  // {
  //   id: 'ql-add-widget-2',
  //   label: 'Add a widget',
  //   icon: 'fal fa-plus',
  //   link: '../message-center/documents/planDocuments',
  //   hasWidget: false,
  //   selected: false,
  // }
];

export const MEMBER_LINKS = [
  {
    id: 'mentalHealth',
    label: 'EXPLORE MENTAL HEALTH CARE OPTIONS',
    text: 'Learn more about everything from remote therapy visits and self-guided ' +
    'programs to substance use support on our' +
    ' <a href="https://www.bluecrossma.org/myblue/your-health/mental-and-behavioral-health/mental-health-resource-center"' +
    ' class="textDecoration textDecoration-link" target="blank">Mental Health Resource Center</a>.' +
    '<br /><br />  Looking for your coverage information? Click the link below, then choose your plan. Select &#8220View Plan Benefits&#8221 (or &#8220Plan Benefits&#8221 from our mobile app) and select a mental health service to view your coverage.',
    warningText: '',
    icon: 'fal fa-head-side-brain',
    buttonText: 'EXPLORE YOUR BENEFITS',
    mobilelabel:'EXPLORE MENTAL HEALTH CARE OPTIONS',
    link: '/myplans',
    isSelected: true,
    isExternal: false
  },
  {
    id: 'getYourFluShot',
    label: 'GET YOUR <br> FLU SHOT',
    text: 'Getting your flu shot this season is more crucial than ever. ' +
    'It will help keep you, your family, and your community from getting sick. ' +
    'And it could keep you all out of the doctor’s office when so many others may need critical care. ' +
    'Plus, getting your shot is no-cost* and safe.' +
    '<br /><br />',
    warningText: '*Exceptions may apply. Check your plan materials for details.' +
    ' Medicare Advantage members are covered when administered by an in-network or out-of-network provider.' +
    ' Flu vaccines are covered under Medicare Part B.',
    icon: 'fal fa-user-injured',
    buttonText: 'WHERE TO GET YOUR SHOT',
    mobilelabel:'GET YOUR FLU SHOT',
    link: 'https://www.bluecrossma.org/myblue/your-health/health-and-wellness/flu-resources',
    isSelected: false,
    isExternal: true
  },
  {
    id: 'telehealth',
    label: 'WELL CONNECTION',
    text:
      'Doctors on call, on your device.<br/><br/>Well Connection is now accessible through MyBlue, making it easier than ever for you to get the care you need. ' + 
      'Get convenient access to medical care 24/7 or schedule a visit with a licensed therapist or psychiatrist on your computer or mobile device.',
    warningText: '',
    icon: 'fal fa-video-plus',
    buttonText: 'START VIDEO VISIT',
    mobilelabel: 'WELL CONNECTION',
    link: '/virtual-visit',
    isSelected: false,
    isExternal: false,
  },
  {
    id: 'covid19',
    label: 'FIND COVID-19 TESTING',
    text: 'To find a COVID-19 testing location, click below. Please consult your provider to determine if  COVID-19 testing' +
    ' is medically appropriate for you. For information about coverage for COVID-19 testing, see our' +
    '<a href="https://www.bluecrossma.org/myblue/coronavirus-resource-center#FAQs" class="textDecoration textDecoration-link" target="blank">' +
    ' frequently asked questions</a>.',
    warningText: '',
    icon: 'fal fa-vial',
    buttonText: 'FIND A TESTING LOCATION',
    mobilelabel:'FIND COVID-19 TESTING',
    link: 'https://www.bluecrossma.org/myblue/coronavirus-resource-center',
    isSelected: false,
    isExternal: true
  },
  {
    id: 'remoteDoctorVisits',
    label: 'REMOTE DOCTOR VISITS',
    text: 'Get care virtually with expanded telehealth benefits.<br/><br/>The pandemic has shown us that telehealth is a vitally important method of providing medical and behavioral ' +
          'health care for members. We are expanding the types of care available via telehealth to include early intervention, ' +
          'short-term rehabilitation, and preventive care as covered services. Effective July 1, your applicable costs ' +
          '(copay, co-insurance, and deductible), if any, will apply for non-COVID telehealth visits*, as they would for ' +
          'in-person services. For more than a year, we waived member costs for non-COVID-19 telehealth visits to help ensure ' +
          'access to care and to help prevent COVID-19 infection and illness. With the successful roll out of vaccines and the ' +
          'relaxation of restrictions, we are ending this temporary accommodation. To find a provider that offers telehealth services:',
    warningText: '*Benefits may vary by plan, does not apply to Medicare or FEP plans.',
    icon: 'fal fa-video',
    buttonText: 'FIND A DOCTOR',
    mobilelabel: 'REMOTE DOCTOR VISITS',
    link: '/fad',
    isSelected: false,
    isExternal: false
  },
  {
    id: 'fitnessReimbursement',
    label: 'GET YOUR FITNESS/ WEIGHT-LOSS REIMBURSEMENT',
    text: 'You <b>may</b> be eligible for a fitness OR weight-loss reimbursement! It’s easy, quick, and paperless. ' + 
    'And it could cover health club memberships, and fitness classes like spin, yoga, and kickboxing. ' + 
    'Plus in-person or online weight-loss programs like WW®´´ (formerly Weight Watchers). ' + 
    'So don’t forget to submit the form!',
    warningText: '',
    icon: 'fal fa-weight',
    buttonText: 'GET REIMBURSEMENT',
    mobilelabel:'GET YOUR FITNESS/ WEIGHT-LOSS REIMBURSEMENT',
    link: '/fitness-and-weightloss',
    isSelected: false,
    isExternal: false
  },
];

export const BRAND_PROMO = [
  '/page/brand-promoblock1',
  '/page/brand-promoblock2',
  '/page/brand-promoblock3',
  '/page/brand-promoblock4'
];
