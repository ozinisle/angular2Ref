import { TitleCasePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/shared.module';
import { AuthGuard } from '../../shared/utils/auth.guard';
import { ScopeGuard } from '../../shared/utils/scope.guard';
import { FadService } from '../fad/fad.service';
import { PwkModule } from '../pwk/pwk.module';
import { RegistrationService } from '../registration/registration.service';
import { AuthUserLandingComponent } from './authenticated-user/authenticated-user.component';
import { AllowAVOnlyGuard, LandingGuard } from './landing.guard';
import { LandingRouter } from './landing.routing';

// prettier-ignore
@NgModule({
  declarations: [
    AuthUserLandingComponent,
  ],
  exports: [],
  providers: [
    AllowAVOnlyGuard,
    AuthGuard,
    FadService,
    LandingGuard,
    RegistrationService,
    ScopeGuard,
    TitleCasePipe
  ],
  imports: [
    SharedModule,
    LandingRouter,
    PwkModule
  ]
})
export class LandingModule {}
