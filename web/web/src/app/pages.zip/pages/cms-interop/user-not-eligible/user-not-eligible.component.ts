import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { GlobalService } from '../../../shared/services/global.service';
import { AlertService } from '../../../shared/shared.module';
import { CmsInteropService } from '../cms-interop.service';

@Component({
  selector: 'app-user-not-eligible',
  templateUrl: './user-not-eligible.component.html',
  styleUrls: ['./user-not-eligible.component.scss', '../consent-knowledge/consent-knowledge.component.scss']
})
export class UserNotEligibleComponent implements OnInit {
  tr: string;
  getConsentData$: Observable<any>;
  firstPageContent;
  constructor(
    private alertService: AlertService,
    private globalService: GlobalService,
    private router: Router,
    private cmsService: CmsInteropService
  ) {}

  ngOnInit() {
    this.drupalContent();
  }

  /**
   * Getting all drupal content as warning-message
   */
  drupalContent() {
    this.getConsentData$ = this.cmsService.getConsentDrupalContent();
    this.getConsentData$.subscribe(drupalres => {
      // console.log('🚀 ~ file: consent-knowledge.component.ts ~ line 62 ~ ConsentKnowledgeComponent ~ ngOnInit ~ drupalres', drupalres);
      this.firstPageContent = drupalres[8];
    });
  }

  /**
   * logout user
   */
  cancel() {
    const tr = localStorage.getItem('interopRoute');
    localStorage.setItem('targetRoute', tr);
    this.alertService.clearError();
    this.globalService.logout();

    // MENU_ITEMS_RESET_COPY();
  }

  goToLink() {
    this.router.navigate(['/home']);
  }
}
