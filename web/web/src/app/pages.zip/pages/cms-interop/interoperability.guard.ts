import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class InteroperabilityGuard implements CanActivate {
  constructor(private router: Router) {}

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    // If user logout and user want to log back in
    // this will store route which route they are coming from and route them over there
    if (
      sessionStorage.getItem('authToken') !== 'undefined' &&
      sessionStorage.getItem('authToken') !== 'null' &&
      sessionStorage.getItem('authToken')
    ) {
      const authTokenDetails = sessionStorage.getItem('authToken');
      localStorage.setItem('interopRoute', state.url);
      const authTokenDetailsJson = JSON.parse(authTokenDetails);
      // only MEDICAR ADV is not allow to go through Interop
      if (localStorage.getItem('interopRoute') && localStorage.getItem('interopRoute') !== '/') {
        if (authTokenDetailsJson.scopename === 'AUTHENTICATED-AND-VERIFIED' && authTokenDetailsJson.userType === 'MEDICARE') {
          return true;
        } else {
          // If user is authenticated and Verified but not MEDICAR AV  then not-eligible flow.
          this.router.navigate(['/interop/not-eligible']);
        }
      } else {
        this.router.navigate(['/login']);
      }
    } else {
      this.router.navigate(['/login']);
    }
  }
}
