import { ChangeDetectionStrategy, ChangeDetectorRef, Component, HostListener, OnInit } from '@angular/core';
import { MatSlideToggleChange } from '@angular/material';
import { Router } from '@angular/router';
import { addDays, isBefore } from 'date-fns';
import { Observable, Subject } from 'rxjs';
import { GlobalService } from '../../../shared/services/global.service';
import { AlertService } from '../../../shared/shared.module';
import { CmsInteropService } from '../cms-interop.service';

@Component({
  selector: 'app-consent-knowledge',
  templateUrl: './consent-knowledge.component.html',
  styleUrls: ['./consent-knowledge.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [CmsInteropService]
})
export class ConsentKnowledgeComponent implements OnInit {
  panelOpenState = false;
  state: string;
  memFirstName: string;
  memLastName: string;
  isChecked;
  userEmailAddress: string;
  destroy$ = new Subject<void>();
  clickResentEmail: boolean;

  firstPageContent: string;
  secoundPageContent: string;
  thirdPageContent: string;
  fourthPageContent: string;
  allowConsentPageContent: string;
  emailSentPageContent: string;
  reEmailSentPageContent: string;
  secoundAccordionContent: string;
  secoundLastContent: string;
  getConsentData$: Observable<any>;

  @HostListener('window:scroll') onScroll(e: Event): void {
    this.cdr.detectChanges();
  }

  constructor(
    private alertService: AlertService,
    private cdr: ChangeDetectorRef,
    private globalService: GlobalService,
    private cmsService: CmsInteropService,
    private router: Router
  ) {}

  ngOnInit() {
    // this.state = 'firstConsentLanguagePage';
    this.basicInfoOfUser();

    this.cmsService.fetchProfileInfo().subscribe(profileInfo => {
      this.userEmailAddress = profileInfo.emailAddress;
      this.cdr.detectChanges();
    });

    this.drupalContent();
    this.cmsService
      .getConsent()
      .debounceTime(500)
      .subscribe(getAllConsentData => {
        // no Consent and no acknowledge the it will start from first
        if (!getAllConsentData.userHasConsented && !getAllConsentData.useHasAcknowledged) {
          this.state = 'firstConsentLanguagePage';
          this.cdr.detectChanges();
        }

        // consented and no acknowledge then it will go to resent email
        if (getAllConsentData.userHasConsented && !getAllConsentData.useHasAcknowledged) {
          this.state = 'sixthConsentLanguagePage';
          this.cdr.detectChanges();
        }

        // if consented and acknowledge then it will check time
        // it will check no token created then it will take acknowledge time and if yes then consent time stemp
        // if it within 24hrs then it will call user authorized
        // if it is more then 24hrs then it will go through first consent page
        if (getAllConsentData.userHasConsented && getAllConsentData.useHasAcknowledged) {
          // e.g Wed May 25 2021 21:43:55 GMT-0500
          const time = !getAllConsentData.tokenCreated
            ? new Date(getAllConsentData.consentAcknowledgeTimestamp)
            : new Date(getAllConsentData.consentedTimestamp);
          const nextDate = addDays(new Date(time), 1); // e.g Wed May 26 2021 21:43:55 GMT-0500
          // e.g  Wed May 26 2021 21:43:55 GMT-0500 , Tue May 25 2021 17:03:00 GMT-0500
          const checkDate = isBefore(new Date(nextDate), new Date()); // e.g  false

          // if checkDate is true it will go here in IF and trigger user Authorized call
          if (!checkDate) {
            // console.log('it is consented and acknowledge and this is within 24hrs, it will navigate to 3rd party app');
            this.cmsService.postUserAuthorized().then(res => {
              // console.log('post user authorized ------- :', res);
            });
          } else {
            this.state = 'firstConsentLanguagePage';
            this.cdr.detectChanges();
          }
        }
      });
  }

  /**
   * @param elem
   * returns boolean based on viewport visibility
   */
  isInViewport(elem): boolean {
    const bounding = elem.getBoundingClientRect();
    return (
      bounding.top >= 0 &&
      bounding.left >= 0 &&
      bounding.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
      bounding.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
  }

  /**
   * after user go to fourthConsentLanguage part
   * it will scroll up to TOP
   */
  thirdNextButton() {
    this.goTo('fourthConsentLanguagePage');
    window.scrollTo(0, 0);
  }

  /**
   * Resend email click.
   */
  resendEmailClick() {
    this.cmsService
      .postConsent('true')
      .then(res => {
        this.clickResentEmail = true;
        this.cdr.detectChanges();
      })
      .catch(err => console.log('error :', err));
  }
  /**
   * Close modal on the resend email click
   */
  modalClose() {
    const modal = document.getElementById('myModal');
    modal.style.display = 'block';
    this.clickResentEmail = false;
  }

  /**
   * getting user First Name and Last Name.
   */
  basicInfoOfUser() {
    this.cmsService.getMemBasicInfo().subscribe(memBasicInfoResp => {
      if (memBasicInfoResp.rxSummary.memFirstName) {
        this.memFirstName = memBasicInfoResp.rxSummary.memFirstName;
        this.cdr.detectChanges();
      }
      if (memBasicInfoResp.rxSummary.memLastName) {
        this.memLastName = memBasicInfoResp.rxSummary.memLastName;
        this.cdr.detectChanges();
      }
    });
  }

  /**
   * Getting all drupal content as warning-message
   */
  drupalContent() {
    this.getConsentData$ = this.cmsService.getConsentDrupalContent();
    this.getConsentData$.subscribe(drupalres => {
      // console.log('🚀 ~ file: consent-knowledge.component.ts ~ line 62 ~ ConsentKnowledgeComponent ~ ngOnInit ~ drupalres', drupalres);
      this.firstPageContent = drupalres[0];
      this.secoundPageContent = drupalres[1];
      this.thirdPageContent = drupalres[2];
      this.fourthPageContent = drupalres[3];
      this.allowConsentPageContent = drupalres[4];
      this.emailSentPageContent = drupalres[5];
      this.reEmailSentPageContent = drupalres[6];
      this.secoundAccordionContent = drupalres[9];
      this.secoundLastContent = drupalres[10];
      this.cdr.detectChanges();
    });
  }

  /**
   *
   * @param state change state - Next/BACK to go to that part.
   */
  goTo(state) {
    this.state = state;
    this.cdr.detectChanges();
  }

  /**
   * Toggle switch before the consent part
   * @param $event
   */
  toggleDisplayDiv($event?: MatSlideToggleChange) {
    this.isChecked = $event.checked;
  }

  /**
   * cancel - Logout()
   */
  cancel() {
    const tr = localStorage.getItem('interopRoute');
    localStorage.setItem('targetRoute', tr);
    this.alertService.clearError();
    this.globalService.logout();
  }

  /**
   * Allow consent for the consent allow/decline part.
   * cancel - navigate to user-decline and do post consent call.
   */
  declineConsent() {
    this.cmsService
      .postConsent('false')
      .then(res => {
        this.router.navigate(['/interop/user-decline']);
      })
      .catch(err => console.log('error :', err));
  }

  /**
   * Allow consent for the consent allow/decline part.
   * if it is success then we need to navigate to Email sent.
   * TODO: still need to catch an error, if it fail.
   */
  allowConsent() {
    this.cmsService
      .postConsent('true')
      .then(res => {
        // we are checking here if it is already consented and acknowledged the after allow will fire user authorized
        // If not, it will go the resent email page
        this.cmsService
          .getConsent()
          .debounceTime(500)
          .subscribe(getAllConsentData => {
            if (getAllConsentData.userHasConsented && getAllConsentData.useHasAcknowledged) {
              // console.log(
              // 'user is coming after 24hrs to it will navigate them to
              //   consent part and on allow click it will navigate to 3rd party app'
              // );
              this.cmsService.postUserAuthorized().then(res2 => {
                // console.log('post user authorized ------- :', res2);
              });
            } else {
              this.goTo('sixthConsentLanguagePage');
              this.cdr.detectChanges();
            }
          });
      })
      .catch(err => console.log('error :', err)); // TODO: need to get requirement from bussiness if any!
  }
}
