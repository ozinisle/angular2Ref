import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { GlobalService } from '../../../shared/services/global.service';
import { AlertService } from '../../../shared/shared.module';
import { CmsInteropService } from '../cms-interop.service';

@Component({
  selector: 'app-acknowledgement',
  templateUrl: './acknowledgement.component.html',
  styleUrls: ['./acknowledgement.component.scss']
})
export class AcknowledgementComponent implements OnInit {
  state: string;
  getAckData$: Observable<any>;
  firstPageContent: string;
  secoundPageContent: string;
  constructor(
    private alertService: AlertService,
    private globalService: GlobalService,
    private router: Router,
    private cmsService: CmsInteropService
  ) {}

  ngOnInit() {
    this.state = 'firstAckPage';
    this.drupalContent();
  }

  /**
   * cancel - navigate to user-decline
   */
  cancel() {
    this.router.navigate(['/interop/user-decline']);
  }

  /**
   * Getting all drupal content as warning-message
   */
  drupalContent() {
    this.getAckData$ = this.cmsService.getAcknowledgeDrupalContent();
    this.getAckData$.subscribe(drupalres => {
      // console.log('🚀 ~ file: consent-knowledge.component.ts ~ line 62 ~ ConsentKnowledgeComponent ~ ngOnInit ~ drupalres', drupalres);
      this.firstPageContent = drupalres[0];
      this.secoundPageContent = drupalres[1];
    });
  }

  /**
   * User authorized button click to authorized it
   */
  authorizedBtnClick() {
    this.cmsService
      .putAcknowledgement()
      .then(res => {
        this.state = 'authorizedAckPage';
      })
      .catch(err => {
        console.log(err);
      });
  }

  /**
   * Done is to just log user out
   */
  done() {
    const tr = localStorage.getItem('interopRoute');
    localStorage.setItem('targetRoute', tr);
    this.alertService.clearError();
    this.globalService.logout();
  }
}
