export const MyAccountConstants = {
  Success: '',
  VerificationMsgSuccess: 'Verification code sent!',
  VerificationMsgSuccessForMobile: 'Verification code is resent!',
  VerificationResentMsgSuccess: 'Verification code resent! You may need to check your spam folder.',
  NotificationMsg: 'Please check your email account or mobile number for your username.',
  BackSpace: 'Backspace',
  ArrowLeft: 'ArrowLeft',
  ArrowRight: 'ArrowRight'
};
