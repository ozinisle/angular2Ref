import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { ConstantsService } from '../../shared/services/constants.service';
import { AuthService } from '../../shared/shared.module';

@Injectable()
export class MyAccountService {
  constructor(private http: AuthHttp, private authService: AuthService, private constants: ConstantsService) {}

  getAccountInfo(): Observable<any> {
    const request = {
      useridin: this.authService.useridin
    };
    return this.http.encryptPost(this.constants.myaccountUrl, request);
  }
}
