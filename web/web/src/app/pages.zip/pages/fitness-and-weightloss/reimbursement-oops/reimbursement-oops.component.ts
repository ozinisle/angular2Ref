import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { AlertService } from '../../../shared/shared.module';

@Component({
  selector: 'app-reimbursement-oops',
  templateUrl: './reimbursement-oops.component.html',
  styleUrls: ['./reimbursement-oops.component.scss']
})
export class ReimbursementOopsComponent implements OnInit, OnDestroy {
  constructor(private router: Router, private alertService: AlertService) {}

  ngOnInit() {
    this.alertService.setAlert('Error!', '', AlertType.Failure);
  }

  downloadFitness() {
    window.open('http://www.bluecrossma.com/common/en_US/pdfs/New_SOB/55-0763_Fitness_Reimbursement_Form.pdf');
  }

  downloadWeightloss() {
    window.open('http://www.bluecrossma.com/common/en_US/pdfs/New_SOB/55-0764_Weight_Loss_Reimbursement_Form.pdf');
  }

  onClick() {
    this.router.navigate(['fitness-and-weightloss/']);
  }

  ngOnDestroy(): void {
    this.alertService.resetErrorObject();
  }
}
