import { RouterModule, Routes } from '@angular/router';
import { DownloadReimbursementComponent } from './download-reimbursement/download-reimbursement.component';
import { FitnessFormComponent } from './fitness-form/fitness-form.component';
import { ReimbursementOopsComponent } from './reimbursement-oops/reimbursement-oops.component';
import { SuccessMessageComponent } from './success-message/success-message.component';
import { WeightlossFormComponent } from './weightloss-form/weightloss-form.component';

const routes: Routes = [
  {
    path: 'fitness-form',
    component: FitnessFormComponent
  },
  {
    path: 'weightloss-form',
    component: WeightlossFormComponent
  },
  {
    path: 'download-reimbursement',
    component: DownloadReimbursementComponent
  },
  {
    path: 'success-message',
    component: SuccessMessageComponent
  },
  {
    path: 'reimbursement-oops',
    component: ReimbursementOopsComponent
  },
  {
    path: '',
    component: DownloadReimbursementComponent
  }
];

export const FitnessAndWeightlossRouter = RouterModule.forChild(routes);
