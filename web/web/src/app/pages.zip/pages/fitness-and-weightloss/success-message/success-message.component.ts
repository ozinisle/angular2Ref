import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { SelectionService } from '../../../shared/services/downloadForm/selection.service';
import { AlertService } from '../../../shared/shared.module';
import { BenefitData } from '../benefits.model';

@Component({
  selector: 'app-success-message',
  templateUrl: './success-message.component.html',
  styleUrls: ['./success-message.component.scss']
})
export class SuccessMessageComponent implements OnInit, OnDestroy {
  reimbursementForm: FormGroup;
  selectedBenefitType: any;
  typeOfBenefit: any = [];
  isContinueEnabled = false;
  showForm = false;
  onlineSubmission = false;
  planTitle = '';
  otherBenefitTypes: any;
  buttonCopy = 'Continue';
  downloadData: any;
  benefitsData: BenefitData = {};
  confirmationNumber: number;
  selectedYear: any;
  selectedBenefit: any;
  submittedFormName: string;
  errorCode: any;
  selectionErrorCodes = [];
  ineligibleErrorCodes = [];
  yearstring: string;
  constructor(
    private router: Router,
    private fb: FormBuilder,
    private selectionService: SelectionService,
    private alertService: AlertService
  ) { }

  ngOnInit() {
    this.benefitsData = this.selectionService.getBenefitModelData();
    this.initializeSuccessMessage();
  }

  initializeSuccessMessage() {
    this.otherBenefitTypes = this.selectionService.getOverallBenefits();
    const benefitData = this.selectionService.getBenefitData();
    this.downloadData = benefitData.benefits;
    this.errorCode = benefitData.result;
    this.confirmationNumber = this.benefitsData.confirmationNumber;
    if (this.confirmationNumber) {
      this.alertService.setAlert('Success!', '', AlertType.Success);
    }
    const selectedYear = this.benefitsData.selectionYear;
    const selectedBenefit = this.benefitsData.selectionType;
    this.selectedBenefitType = selectedYear + ' ' + selectedBenefit;
    const formGroup = {
      year: ['', Validators.required]
    };
    this.reimbursementForm = this.fb.group(formGroup);

    for (let i = 0; i < this.otherBenefitTypes.length; i++) {
      if (this.otherBenefitTypes[i]) {
        this.typeOfBenefit = this.otherBenefitTypes.filter(item => item !== this.selectedBenefitType); // This should return only 3 values except 2019 Weight Loss
      }
    }

    if (this.typeOfBenefit) {
      this.showForm = true;
    }
    if (this.errorCode) {
      this.checkErrorCodes(this.errorCode);
    }

    this.submittedFormName = this.benefitsData.selectionType;
  }

  checkErrorCodes(errorCode: any) {
    this.selectionErrorCodes = this.benefitsData.selectionErrorCodes;
    this.ineligibleErrorCodes = this.benefitsData.ineligibleErrorCodes;

    this.ineligibleErrorCodes.forEach(codeVal => {
      if (codeVal === errorCode) {
        this.router.navigate(['fitness-and-weightloss/']);
      }
    });

    this.selectionErrorCodes.forEach(codeVal => {
      if (codeVal === errorCode) {
        this.router.navigate(['fitness-and-weightloss/reimbursement-oops']);
      }
    });
  }

  onSubmit() {
    const year = this.reimbursementForm.get('year').value;
    const selectionYear = year.substring(0, 4);
    const selectionBenefit = year.substring(5);
    this.benefitsData.selectionYear = selectionYear;
    this.benefitsData.selectionType = selectionBenefit;
    this.selectionService.setBenefitModelData(this.benefitsData);
    this.selectionService.setSelectedBenefitData({
      year: selectionYear,
      typeOfReimbursement: selectionBenefit
    });
    this.checkSelectedForm();
    this.checkErrorCodes(this.errorCode);
  }

  checkSelectedForm() {
    const year: any = this.reimbursementForm.get('year').value;
    const typeOfReimbursement = year.substring(5);
    this.buttonCopy === 'Download' ? this.downLoadForm(typeOfReimbursement) : this.routeToForm(typeOfReimbursement);
  }

  routeToForm(typeOfReimbursement: string) {
    if (typeOfReimbursement === 'Fitness') {
      this.navigateToFitness();
    } else {
      this.navigateToWeightloss();
    }
  }

  navigateToFitness() {
    this.router.navigate(['fitness-and-weightloss/fitness-form']);
  }

  navigateToWeightloss() {
    this.router.navigate(['fitness-and-weightloss/weightloss-form']);
  }

  downLoadForm(typeOfReimbursement: string) {
    typeOfReimbursement.toLowerCase() === 'fitness' ? this.downloadFitness() : this.downloadWeightloss();
  }

  downloadFitness() {
    window.open('http://www.bluecrossma.com/common/en_US/pdfs/New_SOB/55-0763_Fitness_Reimbursement_Form.pdf');
  }

  downloadWeightloss() {
    window.open('http://www.bluecrossma.com/common/en_US/pdfs/New_SOB/55-0764_Weight_Loss_Reimbursement_Form.pdf');
  }

  onChange() {
    this.isContinueEnabled = true;
    this.updateCTA();
  }
  updateCTA() {
    const yearAndFitness: string = this.reimbursementForm.get('year').value;
    const selectionBenefit = yearAndFitness.substring(5);
    this.yearstring = yearAndFitness.substring(0, 4);
    const selectionYear = parseInt(this.yearstring);
    this.planTitle = selectionBenefit === 'Fitness' ? 'Fitness' : 'Weightloss';
    if (selectionYear && selectionBenefit) {
      for (let i = 0; i < this.downloadData.length; i++) {
        if (this.downloadData[i].weightloss && this.downloadData[i].weightloss.receiptRequired) {
          this.benefitsData.weightlossReceiptRequired = this.downloadData[i].weightloss.receiptRequired;
        }
        if (this.downloadData[i].fitness && this.downloadData[i].fitness.receiptRequired) {
          this.benefitsData.fitnessReceiptRequired = this.downloadData[i].fitness.receiptRequired;
        }
        if (this.downloadData[i].year === selectionYear) {
          this.benefitsData.memberList = this.downloadData[i].members;
          if (this.downloadData[i].fitness) {
            if (this.downloadData[i].fitness.collateralName === this.planTitle) {
              this.onlineSubmission = this.downloadData[i].fitness.onlineSubmissionEligible;
              this.benefitsData.isEHB = this.downloadData[i].fitness.isEHB;
              this.benefitsData.benefitAmount = this.downloadData[i].fitness.benefitAmount;
              this.benefitsData.collateralText = this.downloadData[i].fitness.collateralText;
              this.benefitsData.fitnessReceiptRequired = this.downloadData[i].fitness.receiptRequired;
              this.benefitsData.selectionYear = this.yearstring;
              this.benefitsData.selectionType = selectionBenefit;
              break;
            }
          }
          if (this.downloadData[i].weightloss) {
            if (this.downloadData[i].weightloss.collateralName === this.planTitle) {
              this.onlineSubmission = this.downloadData[i].weightloss.onlineSubmissionEligible;
              this.benefitsData.isEHB = this.downloadData[i].weightloss.isEHB;
              this.benefitsData.benefitAmount = this.downloadData[i].weightloss.benefitAmount;
              this.benefitsData.selectionYear = this.yearstring;
              this.benefitsData.selectionType = selectionBenefit;
              this.benefitsData.collateralText = this.downloadData[i].weightloss.collateralText;
              this.benefitsData.weightlossReceiptRequired = this.downloadData[i].weightloss.receiptRequired;
              break;
            }
          }
        }
      }
      this.buttonCopy = this.onlineSubmission ? 'Continue' : 'Download';
      this.selectionService.setBenefitModelData(this.benefitsData);
    }
  }

  ngOnDestroy(): void {
    this.alertService.resetErrorObject();
  }
}
