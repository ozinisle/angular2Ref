export interface BenefitData {
  selectionYear?: string;
  selectionType?: string;
  memberList?: MemberList[];
  subscriberMaskedEmail?: string;
  memberEmail?: string;
  fitnessCollateralText?: string;
  weightlossCollateralText?: string;
  isEHB?: boolean;
  confirmationNumber?: number;
  fitnessReceiptRequired?: boolean;
  weightlossReceiptRequired?: boolean;
  selectionErrorCodes?: number[];
  submissionErrorCodes?: number[];
  ineligibleErrorCodes?: number[];
  benefitAmount?: string;
  collateralText?: string;
  groupNumber?: string;
}

export interface MemberList {
  fullName: string;
  suffix: string;
  status: string;
  relationship: string;
  memberCancelDate: string;
}
