import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatProgressBarModule } from '@angular/material';
import { NgxCurrencyModule } from 'ngx-currency';
import { NgxMaskModule } from 'ngx-mask';
import { SharedModule } from '../../shared/shared.module';
import { DownloadReimbursementComponent } from './download-reimbursement/download-reimbursement.component';
import { FitnessAndWeightlossRouter } from './fitness-and-weightloss.routing';
import { FitnessFormComponent } from './fitness-form/fitness-form.component';
import { ReimbursementOopsComponent } from './reimbursement-oops/reimbursement-oops.component';
import { SuccessMessageComponent } from './success-message/success-message.component';
import { WeightlossFormComponent } from './weightloss-form/weightloss-form.component';

@NgModule({
  imports: [
    CommonModule,
    FitnessAndWeightlossRouter,
    ReactiveFormsModule,
    SharedModule,
    NgxMaskModule,
    NgxCurrencyModule,
    MatProgressBarModule
  ],
  declarations: [
    FitnessFormComponent,
    WeightlossFormComponent,
    DownloadReimbursementComponent,
    SuccessMessageComponent,
    ReimbursementOopsComponent
  ]
})
export class FitnessAndWeightlossModule {}
