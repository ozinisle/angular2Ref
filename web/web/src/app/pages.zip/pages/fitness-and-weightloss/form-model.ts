export interface FormModel {
  useridin: string;
  claim: FWBClaimModel;
  programInformation: ProgramInformationModel;
}

export interface FWBClaimModel {
  year: number;
  type: string;
  forMember: MemberModel;
  isEHB: boolean;
  category?: string;
  unitAmount?: number;
  annualFeeAmount?: number;
  totalAmount: number;
  planCancelDate: string;
  collateralName: string;
  subscriberAlternateEmail?: string;
  memberAlternateEmail?: string;
}

export interface ProgramInformationModel {
  programName: string;
  address: string;
  state: string;
  zip: string;
  phoneNumber: string;
}

export interface MemberModel {
  fullName: string;
  suffix: string;
  status: string;
  relationship: string;
  memberCancelDate: string;
  groupNumber: string;
}
