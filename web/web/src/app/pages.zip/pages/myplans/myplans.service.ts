import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { PlanConfigService } from '../../services/plan-config/plan-config-service';
import { BcbsmaConstants } from '../../shared/constants/bcbsma.constants';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { AuthService } from '../../shared/services/auth.service';
import { BcbsmaHttpService } from '../../shared/services/bcbsma-http.service';
import { BcbsmaerrorHandlerService } from '../../shared/services/bcbsmaerror-handler.service';
import { ConstantsService } from '../../shared/services/constants.service';
import { ValidationService } from '../../shared/services/validation.service';
import { MyPlansConstants } from './constants/my-plans.constants';
import {
  AuthReferralResponseInterface,
  BenefitDetailsResponseInterface,
  LimitationResponseInterface
} from './models/interfaces/benefit-details-model.interface';
import { NetworkType } from './models/interfaces/benefits-model.interface';
import {
  PlanBenefitsListRequestModelInterface,
  PlanBenefitsListResponseModelInterface
} from './models/interfaces/plan-benefits-list-model.interface';
import { PlanEntityInterface, PlanEntityMemberInterface } from './models/interfaces/plan-benefits-page-adapted-data-model.inteface';
import {
  GetPlanBenefitServicesRequestModelInterface,
  GetPlanBenefitServicesResponseModelInterface
} from './models/interfaces/plans-benefits-service-model.interface';
import { PlanBenefitsListRequestModel, PlanBenefitsListResponseModel } from './models/plan-benefits-list.model';
import { PlanEntity, PlanEntityMember } from './models/plan-benefits-page-adapted-data.model';
import { PlanEntityMemberType } from './models/types/myplans.types';

@Injectable()
export class MyplansService {
  private planBenefitRequest: GetPlanBenefitServicesRequestModelInterface = null;
  private selectedPlanEntity: PlanEntityInterface = null;
  private plans: PlanEntityInterface[];
  private planBenefits: GetPlanBenefitServicesResponseModelInterface;
  private serviceBenefitCategoryName = ''; // To Do
  private ciAcBenefitsDetails = '';

  constructor(
    private authService: AuthService,
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService,
    private bcbsmaHttpService: BcbsmaHttpService,
    private constants: ConstantsService,
    private http: AuthHttp,
    private planConfigService: PlanConfigService,
    private router: Router,
    private validationService: ValidationService
  ) {}

  public getPlanBenefits() {
    return this.planBenefits;
  }

  public setPlanBenefits(planBenefits) {
    this.planBenefits = planBenefits;
  }

  public setPlanBenefitRequest(planBenefitRequest: GetPlanBenefitServicesRequestModelInterface) {
    this.planBenefitRequest = planBenefitRequest;
    sessionStorage.setItem('myplans.selectedPlan', JSON.stringify(planBenefitRequest));
  }

  public getPlanBenefitRequest(): GetPlanBenefitServicesRequestModelInterface {
    if (this.planBenefitRequest) {
      return this.planBenefitRequest;
    } else {
      const plan = sessionStorage.getItem('myplans.selectedPlan');
      if (plan) {
        return JSON.parse(plan);
      } else {
        return null;
      }
    }
  }

  public setSelectedPlanEntity(setSelectedPlanEntity: PlanEntityInterface) {
    this.selectedPlanEntity = setSelectedPlanEntity;
    sessionStorage.setItem('myplans.selectedPlanEntity', JSON.stringify(setSelectedPlanEntity));
  }

  public getSelectedPlanEntity(): PlanEntityInterface {
    if (this.selectedPlanEntity) {
      return this.selectedPlanEntity;
    } else {
      const selectedPlanEntity = sessionStorage.getItem('myplans.selectedPlanEntity');
      if (selectedPlanEntity) {
        return JSON.parse(selectedPlanEntity);
      } else {
        return {} as PlanEntityInterface;
      }
    }
  }

  public getServiceBenefitCategoryName(): string {
    if (this.serviceBenefitCategoryName) {
      return this.serviceBenefitCategoryName;
    } else {
      const serviceBenefitCategoryName = sessionStorage.getItem('myplans.serviceBenefitCategoryName');
      if (serviceBenefitCategoryName) {
        return JSON.parse(serviceBenefitCategoryName);
      } else {
        return '';
      }
    }
  }

  public setServiceBenefitCategoryName(serviceBenefitCategoryName: string) {
    this.serviceBenefitCategoryName = serviceBenefitCategoryName;
    sessionStorage.setItem('myplans.serviceBenefitCategoryName', JSON.stringify(serviceBenefitCategoryName));
  }

  public getCiAcBenefitDetails() {
    if (!this.ciAcBenefitsDetails) {
      const details = sessionStorage.getItem('myplans.ciAcBenefiDetails');
      if (details) {
        this.ciAcBenefitsDetails = JSON.parse(details);
      }
    }
    return this.ciAcBenefitsDetails;
  }

  public clearCIAcBenefitDetails() {
    this.ciAcBenefitsDetails = null;
    sessionStorage.removeItem('myplans.ciAcBenefiDetails');
  }

  public setCiAcBenefitDetails(details: any) {
    this.ciAcBenefitsDetails = details;
    sessionStorage.setItem('myplans.ciAcBenefiDetails', JSON.stringify(details));
  }

  public setPlans(plans: PlanEntityInterface[]) {
    this.plans = plans;
    sessionStorage.setItem('myplans.plans', JSON.stringify(plans));
  }

  public getPlans(): PlanEntityInterface[] {
    if (!this.plans || !this.plans.length) {
      const plans = sessionStorage.getItem('myplans.plans');
      this.plans = plans ? JSON.parse(plans) : [];
    }
    return this.plans;
  }

  getPlansData(effectiveDate: string): Observable<PlanBenefitsListResponseModelInterface> {
    const request: PlanBenefitsListRequestModelInterface = new PlanBenefitsListRequestModel();
    request.useridin = this.authService.useridin;
    request.effectiveDate = effectiveDate;

    return this.http.encryptPost(this.constants.getPlansBenefitsListUrl, request).map(response => {
      if (response.result < 0) {
        return response as PlanBenefitsListResponseModelInterface;
      } else {
        const planBenefitsListResponse: PlanBenefitsListResponseModelInterface = response as PlanBenefitsListResponseModelInterface;

        if (planBenefitsListResponse['type'] !== 'error') {
          if (planBenefitsListResponse.fault && planBenefitsListResponse.fault.faultstring) {
            return;
          } else {
            this.setPlans(planBenefitsListResponse.RowSet['osplinPlans'].plans);
            return planBenefitsListResponse;
          }
        }
      }
    });
  }

  getCiAcBenfitsDetails() {
    const planBenefitRequest = this.getPlanBenefitRequest();

    let isBlueFitPlan = false;
    this.planConfigService.getPlanConfigByCoveragePackageCode$(planBenefitRequest.coveragePackageCode).subscribe(
      // This obeservable is cold so we know this will be called syncnrhouslusy.
      // Otherwize flatmap would need to be used.
      config => (isBlueFitPlan = config != null ? config.isDigitalFirstCDH : false)
    );

    if (isBlueFitPlan) {
      const planEntity = this.getSelectedPlanEntity();
      const year = new Date(planEntity.effectiveStartDate).getFullYear();
      return this.http.get(`${this.constants.getCiAcBenefits}${year}`);
    } else {
      return Observable.of(null);
    }
  }

  getPlanBenefitServices(checkAvailablility: boolean, sortFlag?: string): Observable<GetPlanBenefitServicesResponseModelInterface> {
    if (!this.getPlanBenefitRequest()) {
      this.router.navigate(['home']);
      return Observable.throw(new Error('Invalid Request'));
    }
    if (checkAvailablility) {
      const benefits = this.getPlanBenefits();
      if (benefits && benefits.planBenefits.length > 0) {
        return Observable.of(benefits);
      }
    }
    const request = Object.assign(this.getPlanBenefitRequest(), {
      sortFlag: sortFlag || 'A-Z'
    });
    return this.http.encryptPost(this.constants.getPlanBenefitServicesUrl, request).map(response => {
      // tslint:disable-next-line:max-line-length
      const planmemberCostTextResponse: GetPlanBenefitServicesResponseModelInterface = response as GetPlanBenefitServicesResponseModelInterface;
      if (planmemberCostTextResponse.planBenefits) {
        this.setPlanBenefits(planmemberCostTextResponse);
      }
      return planmemberCostTextResponse;
    });
  }

  getPlanBenefitDetails(): Observable<BenefitDetailsResponseInterface> {
    const benefitRequest = this.getPlanBenefitRequest();
    if (!benefitRequest) {
      this.router.navigate(['home']);
      return Observable.throw(new Error('Invalid Request'));
    }
    const serviceBenefitCategoryName = this.getServiceBenefitCategoryName();
    if (serviceBenefitCategoryName !== benefitRequest.benefitCategoryName) {
      benefitRequest.benefitCategoryID = null;
    }
    const request = Object.assign(benefitRequest, {
      benefitCategoryName: serviceBenefitCategoryName,
      cpcCode: benefitRequest.coveragePackageCode
    });

    if (!request.planName) {
      const filtered = this.getPlans().filter(plan => plan.coveragePackageCode === request.coveragePackageCode);
      if (filtered.length) {
        request.planName = filtered[0].planName;
      }
    }
    return this.http.encryptPost(this.constants.getBenefitEnhancedDetailsUrl, request).map(response => {
      return response;
    });
  }

  getLimitationText(): Observable<LimitationResponseInterface> {
    const benefitRequest = this.getPlanBenefitRequest();
    if (!benefitRequest) {
      this.router.navigate(['home']);
      return Observable.throw(new Error('Invalid Request'));
    }
    const request = Object.assign(benefitRequest, {
      benefitCategoryName: this.getServiceBenefitCategoryName()
    });
    delete request.cpcCode;
    if (!request.planName) {
      const filtered = this.getPlans().filter(plan => plan.coveragePackageCode === request.coveragePackageCode);
      if (filtered.length) {
        request.planName = filtered[0].planName;
      }
    }
    return this.http.encryptPost(this.constants.getLimitationTextUrl, request).map(response => {
      return response;
    });
  }

  getAuthReferral(): Observable<AuthReferralResponseInterface> {
    const request = Object.assign(this.getPlanBenefitRequest(), {
      state: this.getSelectedPlanEntity().pcpState,
      benefitCategoryName: this.getServiceBenefitCategoryName(),
      planEffectiveDate: this.getSelectedPlanEntity().effectiveStartDate
    });
    return this.http.encryptPost(this.constants.getAuthReferralUrl, request).map(response => {
      // response.result = -9898989898;
      // response.errormessage = 'forced error message';
      // response.displaymessage = 'force display error message';
      return response;
    });
  }

  getNetworkString(network: string): string {
    if (network === NetworkType.inNetwork || network === 'I' || network === MyPlansConstants.network.inNetwork) {
      return MyPlansConstants.network.inNetwork;
    } else if (network === NetworkType.outOfNetwork || network === 'O' || network === MyPlansConstants.network.outNetwork) {
      return MyPlansConstants.network.outNetwork;
    } else if (
      network === NetworkType.inNetworkAndOutOfNetworkCombined ||
      network === 'C' ||
      network === MyPlansConstants.network.combined
    ) {
      return MyPlansConstants.network.combined;
    }
  }

  getStyledHtmlText(str: string): string {
    if (str === null || str === undefined) {
      return;
    }
    const currencyMatch = str.match(/[$]/i);
    const percentMatch = str.match(/([0-9]+)[%]/i);
    for (let i = 0; i < MyPlansConstants.regexMatch.length; i++) {
      const customMatch = str.match(new RegExp(MyPlansConstants.regexMatch[i], 'i'));
      if (currencyMatch && currencyMatch.length > 0) {
        if (customMatch && customMatch.length > 0 && customMatch.index > currencyMatch.index) {
          return (
            str.substring(0, currencyMatch.index) +
            '<span class="bold">' +
            str.substring(currencyMatch.index, customMatch.index + customMatch[0].length) +
            '</span>' +
            str.substring(customMatch.index + customMatch[0].length, str.length)
          );
        }
      }
      if (percentMatch && percentMatch.length > 0) {
        if (customMatch && customMatch.length > 0 && customMatch.index > percentMatch.index) {
          return (
            str.substring(0, percentMatch.index) +
            '<span class="bold">' +
            str.substring(percentMatch.index, customMatch.index + customMatch[0].length) +
            '</span>' +
            str.substring(customMatch.index + customMatch[0].length, str.length)
          );
        }
      }
    }
    if (str === MyPlansConstants.noCostText || str === MyPlansConstants.noLimitText) {
      return '<span class="bold">' + str + '</span>';
    }
    return str;
  }

  public mapPlanBenefitsResponse(planBenefitsResponseData: PlanBenefitsListResponseModel) {
    const transformedResponse: PlanEntityInterface[] = [];
    try {
      const planBenefitRowSet = Object.freeze(planBenefitsResponseData.RowSet);
      planBenefitRowSet.osplinPlans.plans.map(plan => {
        const planEntity = new PlanEntity();
        planEntity.planName = plan.planName;
        planEntity.coveragePackageCode = plan.coveragePackageCode;
        planEntity.pcpState = plan.pcpState;
        plan.groupInfo.group.map(group => {
          planEntity.effectiveEndDate = '';
          planEntity.effectiveStartDate = group.planEffectiveDt;
          planEntity.subscriberId = group.subscriberId;
          planEntity.groupName = group.groupName;
          planEntity.groupNumber = group.groupNumber;
        });
        planEntity.foundFlag = plan.foundFlag;
        const planEntityMembers: PlanEntityMemberInterface[] = [];
        plan.osplinPlanMembers.members.map(member => {
          const planEntityMember: PlanEntityMemberInterface = new PlanEntityMember();
          planEntityMember.memberId = member.memberId;

          planEntityMember.name = member.middleInitial
            ? `${member.firstName} ${member.middleInitial} ${member.lastName}`
            : `${member.firstName} ${member.lastName}`;
          planEntityMember.memberDOB = member.memberDOB;
          planEntityMember.UACoverageCode = member.UACoverageCode;
          switch (member.memberId) {
            case '00':
              planEntityMember.memberType = 'Subscriber' as PlanEntityMemberType;
              break;
            case '01':
            case '02':
            case '03':
            case '04':
            case '05':
            case '06':
            case '07':
            case '08':
              planEntityMember.memberType = 'Spouse' as PlanEntityMemberType;
              break;
            default:
              const age = this.validationService.getAge(member.memberDOB);
              planEntityMember.memberType =
                !isNaN(age) && age > 18 ? ('Dependent over 18 years' as PlanEntityMemberType) : ('Dependent' as PlanEntityMemberType);
              break;
          }
          planEntityMembers.push(planEntityMember);
        });
        planEntity.members = planEntityMembers;
        transformedResponse.push(planEntity);
      });
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.myPlansModule,
        MyPlansConstants.components.myPlans,
        MyPlansConstants.methods.getTransformResponse
      );
    }
    return transformedResponse;
  }
}
