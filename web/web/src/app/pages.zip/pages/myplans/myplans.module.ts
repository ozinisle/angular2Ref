import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatCardModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatIconModule,
  MatListModule,
  MatNativeDateModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { MaterializeModule } from 'angular2-materialize';
import { FpoLayoutModule } from '../../shared/layouts/FpoLayoutComponent/fpo-layout.module';
import { SharedModule } from '../../shared/shared.module';
import { BenefitDetailsComponent } from './benefitdetails/benefit-details.component';
import { BenefitsComponent } from './benefits/benefits.component';
import { MyBenefitsResolverService } from './benefits/benefits.resolver';
import { DialogTermsComponent } from './dialogTerms/dialogTerms.component';
import { MyplansComponent } from './myplans.component';
import { MyplansRouter } from './myplans.routing';
import { PlandetailsComponent } from './plandetails/plandetails.component';
import { MyPlansDetailsResolverService } from './plandetails/plandetails.resolver';

@NgModule({
  declarations: [DialogTermsComponent, MyplansComponent, PlandetailsComponent, BenefitsComponent, BenefitDetailsComponent],
  imports: [
    CommonModule,
    MatDialogModule,
    MatIconModule,
    MatExpansionModule,
    MaterializeModule,
    MyplansRouter,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    MatSidenavModule,
    MatListModule,
    MatRadioModule,
    MatDatepickerModule,
    MatButtonModule,
    MatNativeDateModule,
    MatCardModule,
    MatSelectModule,
    MatTooltipModule,
    FpoLayoutModule
  ],
  providers: [MyPlansDetailsResolverService, MyBenefitsResolverService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  entryComponents: [DialogTermsComponent]
})
export class MyplansModule {}
