import { RouterModule, Routes } from '@angular/router';
import { ScopeGuard } from '../../shared/utils/scope.guard';
import { BenefitDetailsComponent } from './benefitdetails/benefit-details.component';
import { BenefitsComponent } from './benefits/benefits.component';
import { MyBenefitsResolverService } from './benefits/benefits.resolver';
import { MyplansComponent } from './myplans.component';
import { PlandetailsComponent } from './plandetails/plandetails.component';
import { MyPlansDetailsResolverService } from './plandetails/plandetails.resolver';

const MYPLANS_ROUTER: Routes = [
  {
    path: '',
    component: MyplansComponent
  },
  {
    path: 'plandetails',
    canActivate: [ScopeGuard],
    component: PlandetailsComponent,
    resolve: {
      planDetails: MyPlansDetailsResolverService
    },
    data: {
      breadcrumb: 'Plan Details'
    }
  },
  {
    path: 'benefits',
    component: BenefitsComponent,
    resolve: {
      benefits: MyBenefitsResolverService
    },
    data: {
      breadcrumb: 'Plan Benefits'
    }
  },
  {
    path: 'benefitdetails',
    component: BenefitDetailsComponent,
    data: {
      breadcrumb: 'Benefit Details'
    }
  }
];

export const MyplansRouter = RouterModule.forChild(MYPLANS_ROUTER);
