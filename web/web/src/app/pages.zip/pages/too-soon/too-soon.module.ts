import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { TooSoonComponent } from './too-soon.component';
import { tooSoonRouter } from './too-soon.routing';

@NgModule({
  imports: [CommonModule, tooSoonRouter, ],
  declarations: [TooSoonComponent],
  providers: []
})
export class TooSoonModule {}
