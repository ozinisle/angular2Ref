import { RouterModule, Routes } from '@angular/router';
import { TooSoonComponent } from './too-soon.component';

const TOO_SOON_ROUTER: Routes = [
  {
    path: '',
    component: TooSoonComponent,
  }
];

export const tooSoonRouter = RouterModule.forChild(TOO_SOON_ROUTER);
