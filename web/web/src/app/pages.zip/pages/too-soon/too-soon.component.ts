import { HttpClient } from '@angular/common/http';
import { Component, OnDestroy, OnInit } from '@angular/core';
import * as moment from 'moment';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { LoadingSpinnerService } from '../../core/components/loading-spinner';
import { GlobalService } from '../../shared/services/global.service';
import { AuthService, ConstantsService } from '../../shared/shared.module';

interface DrupalResponse {
  Body: string;
}

@Component({
  selector: 'too-soon',
  templateUrl: './too-soon.component.html',
  styleUrls: ['./too-soon.component.scss']
})
export class TooSoonComponent implements OnInit, OnDestroy {
  content$: Observable<string>;

  constructor(
    private authService: AuthService,
    private globalService: GlobalService,
    private spinner: LoadingSpinnerService,
    private constantsService: ConstantsService,
    private http: HttpClient
  ) {}

  logout() {
    this.globalService.logout();
  }

  ngOnInit() {
    this.spinner.show();

    // Get content from drupal and inject date
    this.content$ = this.http
      .get<DrupalResponse[]>(this.constantsService.drupalFutureEnrolleeUrl)
      .map(response => this.handdleDrupalResponse(response))
      .pipe(finalize(() => this.spinner.hide()));
  }

  /**
   * Extract the html fragment from drupal response and inject the date.
   * @param html to be inserted in the page
   */
  private handdleDrupalResponse(response: DrupalResponse[]): string {
    if (response[0]) {
      let content = response[0].Body;
      const formatedStartDate = moment(this.authService.getStartDate()).format(this.constantsService.futureEnrolleeStartDateDisplayFormat);
      content = content.replace(this.constantsService.drupalFutureEnrolleeDateToken, formatedStartDate);
      return content;
    }
    return '';
  }

  ngOnDestroy() {}
}
