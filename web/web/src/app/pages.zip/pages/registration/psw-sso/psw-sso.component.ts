import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { AlertService } from '../../../shared/shared.module';
import { SsoService } from '../../sso/sso.service';
@Component({
  selector: 'app-psw-sso',
  templateUrl: './psw-sso.component.html',
  styleUrls: ['./psw-sso.component.scss']
})
export class PSWSsoComponent implements OnInit, OnDestroy {
  ssoDetails: any;
  @ViewChild('pswSso') ssoform: ElementRef;
  constructor(
    private authHttpService: AuthHttp,
    private ssoService: SsoService,
    private alertService: AlertService,
    private router: Router,
    private httpService: AuthHttp
  ) {}

  ngOnInit() {}
  navigateToPSWSso() {
    if (sessionStorage.getItem('isPSW') === 'true') {
      const ssoUrl = 'sso/psw';
      this.ssoService.getSsoDetails(ssoUrl).subscribe(response => {
        if (response && response.error) {
          this.router.navigate(['/home']).then(() => {
            this.httpService.showServiceErrorModalPopup('requestTimeoutError');
          });
        } else if (response['displaymessage']) {
          this.alertService.setAlert(response['displaymessage'], '', AlertType.Failure);
        } else if (response['ssomsg'] && response['ssomsg']['samlUrl']) {
          this.ssoDetails = response;
          setTimeout(() => {
            this.ssoform.nativeElement.submit();
          });
        }
      });
    }
  }
  ngOnDestroy() {
    this.authHttpService.hideSpinnerLoading();
    this.alertService.clearError();
  }
}
