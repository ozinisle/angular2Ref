import { RouterModule, Routes } from '@angular/router';
import { UnauthenticatedLayoutComponent } from '../../shared/layouts/UnauthenticatedLayoutComponent/UnauthenticatedLayout.component';
import { ImpersonationLoginGuard } from '../../shared/utils/impersonation-login.guard';
import { NoMenuResolver } from '../../shared/utils/nomenu.resolver';
import { MemberInfoComponent } from './member-info/member-info.component';
import { PSWAuthenticationSuccessComponent } from './psw-authentication-success/psw-authentication-success.component';
import { PSWSuccessComponent } from './psw-success/psw-success.component';
import { RegisterDetailComponent } from './register-detail/register-detail.component';
import { RegisterComponent } from './register/register.component';
import { RegistrationResolver } from './registration-resolver';
import { RegistrationGuard } from './registration.guard';
import { SecurityComponent } from './security-answers/security-answers.component';
import { SuccessInfoComponent } from './success/success-info.component';
import { UpdatessnComponent } from './updatessn/updatessn.component';
import { VerifyaccesscodeComponent } from './verifyaccesscode/verifyaccesscode.component';

const REGISTER_ROUTER: Routes = [
  {
    path: '',
    canActivate: [ImpersonationLoginGuard],
    component: UnauthenticatedLayoutComponent,
    resolve: {
      menu: NoMenuResolver
    },
    children: [
      {
        path: '',
        component: RegisterComponent
      },
      {
        path: 'register-detail',
        component: RegisterDetailComponent
      },
      {
        path: 'memberinfo',
        component: MemberInfoComponent,
        canActivate: [RegistrationGuard],
        resolve: {
          memberInfo: RegistrationResolver
        }
      },
      {
        path: 'updatessn',
        component: UpdatessnComponent,
        canActivate: [RegistrationGuard],
        resolve: {
          memberInfo: RegistrationResolver
        }
      },
      {
        path: 'verifyaccesscode',
        component: VerifyaccesscodeComponent
      },
      {
        path: 'success',
        component: SuccessInfoComponent
      },
      {
        path: 'securityanswers',
        component: SecurityComponent
      },
      {
        path: 'account-creation-success',
        component: PSWSuccessComponent
      },
      {
        path: 'account-auth-success',
        component: PSWAuthenticationSuccessComponent,
        canActivate: [RegistrationGuard],
        resolve: {
          memberInfo: RegistrationResolver
        }
      }
    ]
  }
];

export const RegistrationRouter = RouterModule.forChild(REGISTER_ROUTER);
