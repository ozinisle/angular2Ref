import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { AlertService } from '../../../shared/shared.module';
import { PSWSsoComponent } from '../psw-sso/psw-sso.component';
@Component({
  selector: 'app-psw-authentication-success',
  templateUrl: './psw-authentication-success.component.html',
  styleUrls: ['./psw-authentication-success.component.scss']
})
export class PSWAuthenticationSuccessComponent implements OnInit, OnDestroy {
  @ViewChild(PSWSsoComponent) ssoComponent;
  constructor(private alertService: AlertService) {}

  ngOnInit() {
    if (sessionStorage.getItem('isPSW') === 'true' && sessionStorage.getItem('registrationProcessCompleted') === 'true') {
      this.alertService.setAlert('Congratulations! You now have full access to your account information.', '', AlertType.Success);
    }
  }
  navigateToPSW() {
    if (sessionStorage.getItem('isPSW') === 'true' && sessionStorage.getItem('registrationProcessCompleted') === 'true') {
      this.ssoComponent.navigateToPSWSso();
    }
  }
  ngOnDestroy() {
    this.alertService.clearError();
  }
}
