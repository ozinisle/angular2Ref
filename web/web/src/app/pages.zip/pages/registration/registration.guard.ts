import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';


@Injectable()
export class RegistrationGuard implements CanActivate {
  constructor(
    private router: Router
  ) {}

  SCOPE_NAME_WITH_URLS = {
    'AUTHENTICATED-AND-VERIFIED': 'home',
    'AUTHENTICATED-NOT-VERIFIED': 'register/verifyaccesscode'
  };

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    const authTokenDetails = sessionStorage.getItem('authToken');
    const sessionDetails = sessionStorage.getItem('registrationSuccessfull');
    if (sessionDetails && sessionDetails === 'true') {
      sessionStorage.removeItem('registrationSuccessfull');
      sessionStorage.setItem('registrationProcessCompleted', 'true');
      return true;
    }

    if (sessionStorage.getItem('updatessn') === 'true') {
      return true;
    }

    if (sessionStorage.getItem('memberinfo') === 'true') {
      return true;
    }

    if (sessionStorage.getItem('accesscode') === 'true') {
      this.router.navigate(['register/verifyaccesscode']);
      return true;
    }

    if (this.isRegistrationProcessCompleted()) {
      return this.redirectToLoginPage();
    }
    if (authTokenDetails && authTokenDetails !== 'undefined') {
      const authTokenDetailsJson = JSON.parse(authTokenDetails);
      if (authTokenDetailsJson && authTokenDetailsJson.migrationtype === 'NONE') {
        return this.redirectToScopeNameUrl(authTokenDetailsJson, state);
      } else {
        return this.redirectToLoginPage();
      }
    } else {
      return this.redirectToLoginPage();
    }
    // return true;
  }

  isRegistrationProcessCompleted(): boolean {
    const isProcessCompleted = sessionStorage.getItem('registrationProcessCompleted');
    return isProcessCompleted && isProcessCompleted === 'true';
  }

  redirectToLoginPage(): boolean {
    this.router.navigate(['login']);
    return false;
  }

  redirectToScopeNameUrl(authTokenDetailsJson, state: RouterStateSnapshot): boolean {
    const scopeName = authTokenDetailsJson.scopename;
    if (scopeName && this.SCOPE_NAME_WITH_URLS[scopeName] && state.url !== `/${this.SCOPE_NAME_WITH_URLS[scopeName]}`) {
      this.router.navigate([this.SCOPE_NAME_WITH_URLS[scopeName]]);
      return false;
    }
    return this.redirectBasedUponLastMemResult(scopeName, state);
  }

  redirectBasedUponLastMemResult(scopeName: string, state: RouterStateSnapshot) {
    return true;
  }
}
