import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { AlertService } from '../../../shared/services/alert.service';
import { AuthService } from '../../../shared/services/auth.service';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { ConstantsService } from '../../../shared/services/constants.service';

@Component({
  selector: 'app-success-info',
  templateUrl: './success-info.component.html',
  styleUrls: ['./success-info.component.scss']
})
export class SuccessInfoComponent implements OnInit, OnDestroy {
  location: string;
  displayMessage: string;
  constructor(
    private alertService: AlertService,
    private authService: AuthService,
    private constants: ConstantsService,
    private http: AuthHttp,
    private router: Router
  ) {}

  ngOnInit() {
    this.location = this.router.url.split('/')[1];
    this.alertService.setAlert(
      this.location === 'register'
        ? 'Congratulations! You now have full access to your account information.'
        : 'Your password has been updated',
      '',
      AlertType.Success
    );
    this.displayMessage = this.location === 'register' ? 'Get Started.' : 'Your password is updated';
    if (sessionStorage.getItem('userType')) {
      sessionStorage.removeItem('userType');
    }
  }

  login() {
    this.authService.logout();
  }

  ngOnDestroy() {
    this.alertService.clearError();
  }

  savePageUrl(url?: string) {
    if (url) {
      const requestPayload = {
        useridin: this.authService.useridin,
        linkinfo: url
      };
      this.http.post(this.constants.postdesinfoUrl, this.http.handleRequest(requestPayload)).subscribe(response => {
        this.redirectToLoginPage();
      });
    } else {
      this.redirectToLoginPage();
    }
  }

  redirectToLoginPage() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
