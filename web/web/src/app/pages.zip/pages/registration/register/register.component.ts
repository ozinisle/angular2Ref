import { AfterViewInit, Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { RegType } from '../../../shared/models/regType.enum';
import { AlertService } from '../../../shared/services/alert.service';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { AuthService } from '../../../shared/services/auth.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { GlobalService } from '../../../shared/services/global.service';
import { ValidationService } from '../../../shared/shared.module';
import { RegisterConstants } from '../register-detail.error.constants';
import { RegistrationService } from '../registration.service';
declare let $: any;

@Component({
  selector: 'app-core-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit, AfterViewInit, OnDestroy {
  registerForm: FormGroup;
  type: string;
  typePlaceholder: string;
  userType: RegType;
  subheading: string;
  userTypeChangeLabel: string;
  userTypeLabel: string;
  isFormSubmitted = false;
  phoneMask: any[];
  mask: any;
  maxLength = 100;
  showPasswordErrors = false;
  customMessages = {};
  formData;
  drupalres: any;
  pageParams: string;
  isMPSW = false;

  //added as part of klo-1990
  isShowUserAlreadyExistsError:boolean = false;
  userAlreadyExistsErrorMessage:string=null;
  disableContinueButton:boolean = false;
  useridinOnPageLoad:string = null;
  invalidUserIdErrorMessage = "";

  
  @ViewChild('conditions') elementView: ElementRef;
  @ViewChild('continueButton')continueButton:ElementRef;

  constructor(
    private alertService: AlertService,
    private fb: FormBuilder,
    private registrationService: RegistrationService,
    private validationService: ValidationService,
    private constants: ConstantsService,
    private globalService: GlobalService,
    private authService: AuthService,
    private router: Router,
    private http: AuthHttp,
    private activatedRoute:ActivatedRoute
  ) {
    this.initializeEmailForm();
    this.userType = RegType.EMAIL;
    this.type = 'password';
    this.typePlaceholder = 'Show';
    this.phoneMask = this.validationService.phoneMask;
    this.mask = { mask: false, guide: false };
    this.formData = sessionStorage.getItem('register.form');
    if (this.formData) {
      this.formData = JSON.parse(this.formData);
      this.userType = this.formData['userType'];
      this.maxLength = this.formData['maxLength'];
      this.typePlaceholder = this.formData['typePlaceholder'];
      this.type = this.formData['type'];
      this.showPasswordErrors = this.formData['showPasswordErrors'];
      this.isFormSubmitted = this.formData['isFormSubmitted'];
      if (this.userType === RegType.EMAIL) {
        this.initializeEmailForm();
        this.mask = { mask: false, guide: false };
      } else {
        this.initializeMobileForm();
        this.mask = { mask: this.phoneMask, guide: false };
      }
      this.registerForm.patchValue(this.formData);
      sessionStorage.removeItem('register.form');
    }
    this.http.get(this.constants.getconsentDrupal).subscribe(drupalres => {
      this.drupalres = drupalres;
      sessionStorage.setItem('consentDrupalContent', JSON.stringify(drupalres));
    });
  }

  ngOnInit() {
		$('ul.tabs').tabs();
		$('.modal').modal();

		if (this.authService.isAuthenticated()) {
		  this.authService.clearSession();
		}
		this.activatedRoute.queryParamMap
		  .subscribe(params => { 
			this.pageParams = params.get('from');
			this.isMPSW = this.pageParams === 'MPSW' ? true : false;
			params.get('InstanceId') !== undefined && params.get('InstanceId') !== "" && params.get('InstanceId') !== null ? sessionStorage.setItem('instanceId', params.get('InstanceId')) : '';
			sessionStorage.setItem('isPSW', JSON.stringify(this.isMPSW));
		  });
	  }

  ngAfterViewInit() {
    setTimeout(() => {
      if (this.elementView.nativeElement.scrollHeight <= this.elementView.nativeElement.offsetHeight) {
        this.registerForm.controls.receiveinfo.patchValue(true);
      }
    }, 2000);
  }

  getMessages() {
    return (this.customMessages = {
      required: this.userType === RegType.EMAIL ? 'You must enter a valid email address.' : 'You must enter a valid mobile number.',
      invalidEmail: 'You must enter a valid email address.',
      invalidNumber: 'You must enter a valid phone number.',
      invalidMobile: 'You must enter a valid phone number.',
      invalidPassword: 'Your password does not meet the minimum requirement. Please try again.'
    });
  }

  getPasswordMessages() {
    return {
      required: 'You must enter a valid password.',
      minlength: 'Your password does not meet the minimum requirement. Please try again.',
      invalidPassword: 'Your password does not meet the minimum requirement. Please try again.'
    };
  }

  initializeEmailForm() {
    this.userTypeLabel = 'Email (This will be your username.)*';
    this.userTypeChangeLabel = 'Use mobile number instead';
    this.subheading = '';
    this.registerForm = this.fb.group({
      useridin: ['', [Validators.required, this.validationService.emailValidator()]],
      passwordin: [
        '',
        [
          Validators.required,
          Validators.minLength(8),
          this.validationService.invalidPasswordValidator,
          this.validationService.spaceValidator()
        ]
      ],
      receiveinfo: [false]
    });
    this.setNewMemberAlert();
  }

  initializeMobileForm() {
    this.userTypeLabel = 'Mobile Number(This will be your username.)*';
    this.userTypeChangeLabel = 'Use email instead';
    this.subheading = 'We\'ll send a text verification. Message and data rates may apply.';
    this.registerForm = this.fb.group({
      useridin: ['', [Validators.required, this.validationService.phoneValidator(), this.validationService.mobileValidator()]],
      passwordin: [
        '',
        [
          Validators.required,
          Validators.minLength(8),
          this.validationService.invalidPasswordValidator,
          this.validationService.spaceValidator()
        ]
      ],
      receiveinfo: [false]
    });
    this.setNewMemberAlert();
  }

  ngOnDestroy() {
    this.alertService.clearError();
  }

  saveState() {
    sessionStorage.setItem(
      'register.form',
      JSON.stringify(
        Object.assign(this.registerForm.getRawValue(), {
          userType: this.userType,
          maxLength: this.maxLength,
          typePlaceholder: this.typePlaceholder,
          type: this.type,
          showPasswordErrors: this.showPasswordErrors,
          isFormSubmitted: this.isFormSubmitted
        })
      )
    );
  }

  toggleUserType(conditionsElement) {
    this.invalidUserIdErrorMessage = "";
    conditionsElement.scrollTop = 0;
    this.isShowUserAlreadyExistsError = false;
    if (this.userType === RegType.EMAIL) {
      this.userType = RegType.MOBILE;
      this.alertService.clearError();
      this.resetForm();
      this.maxLength = 12;
      this.mask = { mask: this.phoneMask, guide: false };
      this.initializeMobileForm();
      if (this.elementView.nativeElement.scrollHeight <= this.elementView.nativeElement.offsetHeight) {
        this.registerForm.controls.receiveinfo.patchValue(true);
      }
      this.showPasswordErrors = false;
    } else {
      this.userType = RegType.EMAIL;
      this.alertService.clearError();
      this.resetForm();
      this.maxLength = 100;
      this.mask = { mask: false, guide: false };
      this.initializeEmailForm();
      if (this.elementView.nativeElement.scrollHeight <= this.elementView.nativeElement.offsetHeight) {
        this.registerForm.controls.receiveinfo.patchValue(true);
      }
      this.showPasswordErrors = false;
    }
    this.isFormSubmitted = false;
    this.globalService.markFormGroupUnTouched(this.registerForm);
  }

  onScroll() {
    if (
      this.elementView.nativeElement.offsetHeight + this.elementView.nativeElement.scrollTop >=
      this.elementView.nativeElement.scrollHeight
    ) {
      this.registerForm.controls.receiveinfo.patchValue(true);
    }
  }

  showErrorOnBlur() {
    this.showPasswordErrors = true;
  }

  checkUserIdOnBlur() {
    this.invalidUserIdErrorMessage = "";
    if(this.registerForm.controls['useridin'].value && this.registerForm.controls['useridin'].status === "INVALID"){
      this.invalidUserIdErrorMessage = this.userType === RegType.EMAIL ? 'You must enter a valid email address.' : 'You must enter a valid mobile number.';
    }
  }

  onSubmit() {
    this.isFormSubmitted = true;
    this.isShowUserAlreadyExistsError = false;
    this.globalService.markFormGroupTouched(this.registerForm);
    if (this.registerForm.valid) {
      this.alertService.clearError();
      this.registerForm.value['regType'] = RegType[this.userType];
      this.registerForm.value['useridin'] = this.transformUserId(this.registerForm.value.useridin, this.userType);

      // the registration happens after the verifying the accesscode. CheckUser is to validate the email or phone is present or not.
      this.registrationService.checkUser(this.registerForm.value).subscribe(
        response => {
          if (response['displaymessage']) {
            //logic modified as part of klo-1990
            //this requires an architectural change as the requirement is in deviation of the existing standards
            //where the error message is to displayed right below the username field instead of the top of the page
            //as in the entire application
            if(response['result'] && response['errormessage'] && 
              response['result'] === -93222 && response['errormessage']=== "UserId already exist") {
                this.isShowUserAlreadyExistsError = true;
                this.useridinOnPageLoad = this.registerForm.controls['useridin'].value;
                if( this.userTypeChangeLabel === 'Use mobile number instead') {
                  this.userAlreadyExistsErrorMessage = "This email address is already in use by another account. Please use a different email address or try using your mobile number as your username."
                } else {
                  this.userAlreadyExistsErrorMessage = "This mobile number is already in use by another account. Please use a different mobile number or try using your email address as your username.";
                }
              } else {
                this.handleApiError(response);
                this.validationService.focusFirstFiled();
                this.registerForm.controls.passwordin.setValue('');
              }
          } else {
            this.globalService.setUserData(this.registerForm.value);
            sessionStorage.setItem('registeredUserId', JSON.stringify(this.registerForm.value['useridin']));
            this.router.navigate(['/register/verifyaccesscode']);
          }
        },
        err => {
          if (err.status >= 500) {
            $('#requestTimeoutError').modal('open');
          } else {
            this.globalService.handleError(err.error, this.constants.displayMessage); // , true
            $('#requestTimeoutError').modal('open');
          }
        }
      );
    }
  }

  handleApiError(response?) {
    let displayMessage = response['displaymessage'];
    const errorMessage = response['errormessage'];
    if (errorMessage.indexOf('Exists') > 0 || errorMessage.indexOf('exist') > 0 || response['result'] === '-1') {
      displayMessage = RegisterConstants.userMismatchMsg;
    }
    this.alertService.setAlert(displayMessage, '', AlertType.Failure);
  }

  togglePasswordVisibility() {
    const typeDetails = this.globalService.togglePasswordType(this.type);
    this.type = typeDetails.type;
    this.typePlaceholder = typeDetails.placeHolder;
  }

  resetForm() {
    this.registerForm.reset({
      useridin: '',
      passwordin: ''
    });
  }

  transformUserId(userId: string, registrationType: RegType): string {
    return userId && registrationType === RegType.MOBILE ? userId.replace(/-/g, '') : userId.trim();
  }

  setNewMemberAlert() {
    this.alertService.setAlert(
      this.constants.registerNewMembers + this.constants.registerNewMembersLink,
      'Welcome New Members!',
      AlertType.Warning,
      'component',
      'registernewmembers'
    );
  }

  doUserIdValidation() {
    if(this.isShowUserAlreadyExistsError) {
      this.disableContinueButton = this.useridinOnPageLoad === this.registerForm.controls['useridin'].value;
     // this.continueButton.nativeElement.disabled = !this.registerForm.valid || this.disableContinueButton;
    }
  }

  openhelp(){
    window.open("https://www.bluecrossma.org/myblue/myblue-app#faq","_blank");
  }
  signIn(){
    sessionStorage.getItem('isPSW') === 'true' && sessionStorage.getItem('instanceId') ? 
    this.router.navigate(['sso/medicare-plan-selection-wizard'], { queryParams: { from: this.pageParams, InstanceId : sessionStorage.getItem('instanceId') } }) : sessionStorage.getItem('isPSW') === 'true' ? 
    this.router.navigate(['sso/medicare-plan-selection-wizard'], { queryParams: { from: this.pageParams} }) :
    this.router.navigate(['/login']);
  }
}
