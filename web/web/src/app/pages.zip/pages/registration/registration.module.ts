import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule, MatListModule, MatRadioModule, MatSelectModule } from '@angular/material';
import { MatInputModule } from '@angular/material/input';
import { TextMaskModule } from 'angular2-text-mask';
import { AuthService } from '../../shared/services/auth.service';
import { SharedModule } from '../../shared/shared.module';
import { AuthGuard } from '../../shared/utils/auth.guard';
import { LandingService } from '../landing/landing.service';
import { MyAccountService } from '../my-account/my-account.service';
import { MemberInfoComponent } from './member-info/member-info.component';
import { PSWAuthenticationSuccessComponent } from './psw-authentication-success/psw-authentication-success.component';
import { PSWSsoComponent } from './psw-sso/psw-sso.component';
import { PSWSuccessComponent } from './psw-success/psw-success.component';
import { RegisterDetailComponent } from './register-detail/register-detail.component';
import { RegisterComponent } from './register/register.component';
import { RegistrationResolver } from './registration-resolver';
import { RegistrationGuard } from './registration.guard';
import { RegistrationRouter } from './registration.routing';
import { RegistrationService } from './registration.service';
import { SecurityComponent } from './security-answers/security-answers.component';
import { SuccessInfoComponent } from './success/success-info.component';
import { UpdatessnComponent } from './updatessn/updatessn.component';
export { AuthService, RegistrationService };

@NgModule({
  declarations: [
    RegisterComponent,
    RegisterDetailComponent,
    MemberInfoComponent,
    UpdatessnComponent,
    SuccessInfoComponent,
    SecurityComponent,
    PSWSuccessComponent,
    PSWSsoComponent,
    PSWAuthenticationSuccessComponent
  ],
  exports: [],
  imports: [
    CommonModule,
    RegistrationRouter,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    TextMaskModule,
    MatRadioModule,
    MatSelectModule,
    MatListModule,
    MatInputModule,
    MatFormFieldModule
  ],
  providers: [AuthGuard, RegistrationGuard, RegistrationService, MyAccountService, LandingService, RegistrationResolver]
})
export class RegistrationModule {}
