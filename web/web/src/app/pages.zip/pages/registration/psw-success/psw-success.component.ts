import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { AlertService, AuthService } from '../../../shared/shared.module';
import { PSWSsoComponent } from '../psw-sso/psw-sso.component';
@Component({
  selector: 'app-psw-success',
  templateUrl: './psw-success.component.html',
  styleUrls: ['./psw-success.component.scss']
})
export class PSWSuccessComponent implements OnInit, OnDestroy {
  userid: string;
  @ViewChild(PSWSsoComponent) ssoComponent;
  constructor(private authService: AuthService, private alertService: AlertService, private router: Router) {}

  ngOnInit() {
    this.userid = this.authService.useridin;
  }
  navigateToPSW() {
    if (sessionStorage.getItem('isPSW') === 'true' && sessionStorage.getItem('isPSWVerifyCode') === 'true') {
      this.ssoComponent.navigateToPSWSso();
    }
  }
  navigateToVerify() {
    if (sessionStorage.getItem('isPSW') === 'true' && sessionStorage.getItem('isPSWVerifyCode') === 'true') {
      this.router.navigate(['../register/register-detail']);
    }
  }
  ngOnDestroy() {
    this.alertService.clearError();
  }
}
