import { DatePipe } from '@angular/common';
import { AfterViewInit, Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import * as momenttz from 'moment-timezone';
import { pairwise, startWith } from 'rxjs/operators';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { RegType } from '../../../shared/models/regType.enum';
import { AlertService } from '../../../shared/services/alert.service';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { AuthService } from '../../../shared/services/auth.service';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { GlobalService } from '../../../shared/services/global.service';
import { ValidationService } from '../../../shared/services/validation.service';
import { RegistrationModuleConstants } from '../constants/registration-module.constants';
import { FormGroupControlsModel, VerifyAccessCodeInputValidationResultModel } from '../models/registrationModule.models';
import { RegistrationService } from '../registration.service';

declare let $: any;

@Component({
  selector: 'app-verifyaccesscode',
  templateUrl: './verifyaccesscode.component.html',
  styleUrls: ['./verifyaccesscode.component.scss']
})
export class VerifyaccesscodeComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('accesscode1') accesscode1: ElementRef;
  @ViewChild('accesscode2') accesscode2: ElementRef;
  @ViewChild('accesscode3') accesscode3: ElementRef;
  @ViewChild('accesscode4') accesscode4: ElementRef;
  @ViewChild('accesscode5') accesscode5: ElementRef;
  @ViewChild('accesscode6') accesscode6: ElementRef;
  public verifyaccesscodeForm: FormGroup;
  public isFormSubmitted = false;
  public registrationModuleConstants;
  public verifyaccesscodeFormValidator: VerifyAccessCodeInputValidationResultModel = new VerifyAccessCodeInputValidationResultModel();
  private shiftKeyDown = false;
  drupalres: any;
  timezoneOffset = momenttz(new Date())
    .tz('America/New_York')
    .format('Z');
  errorMessage: any;
  userData: any;

  constructor(
    private alertService: AlertService,
    private authService: AuthService,
    private fb: FormBuilder,
    private constants: ConstantsService,
    private registrationService: RegistrationService,
    private globalService: GlobalService,
    private router: Router,
    private datePipe: DatePipe,
    private validationService: ValidationService,
    private bcbsmaErrorHandlerService: BcbsmaerrorHandlerService,
    private http: AuthHttp
  ) {
    this.verifyaccesscodeForm = this.fb.group(
      {
        accesscode1: ['', [Validators.required]],
        accesscode2: ['', [Validators.required]],
        accesscode3: ['', [Validators.required]],
        accesscode4: ['', [Validators.required]],
        accesscode5: ['', [Validators.required]],
        accesscode6: ['', [Validators.required]]
      },
      {
        validator: this.validationService.accessCodeValidator()
      }
    );
    this.verifyaccesscodeForm.valueChanges.pipe(startWith(''), pairwise()).subscribe(accesscodes => {
      const prevVals = accesscodes[0];
      const newVals = accesscodes[1];
      Object.keys(newVals).forEach((key, index) => {
        const newItemValue = (newVals[key] ? newVals[key] : '').toString();
        const oldItemValue = (prevVals[key] ? prevVals[key] : '').toString();
        // console.log(newItemValue + "   " + oldItemValue);
        // if all validations work fine; newItemValue string length will never be more than 2 digits
        // code depends on previous validations to run without fail.
        if (newItemValue !== oldItemValue && newItemValue.length > 1) {
          // console.log("new value found");
          const digits = newItemValue.split('');
          const currentIndex = index + 1;
          const allEqual = digits.every((val, i, arr) => val === arr[0]);
          if (allEqual) {
            // console.log("pick first digit");
            this.verifyaccesscodeForm.get('accesscode' + currentIndex).setValue(digits[0], { emitEvent: false });
          } else {
            digits.forEach(digit => {
              if (digit !== oldItemValue) {
                // console.log("swapping new value");
                this.verifyaccesscodeForm.get('accesscode' + currentIndex).setValue(digit, { emitEvent: false });
              }
            });
          }
          this.verifyaccesscodeForm.get('accesscode' + currentIndex).updateValueAndValidity();
        }
      });
    });
  }

  ngOnInit() {
    this.registrationModuleConstants = RegistrationModuleConstants;
    this.userData = this.globalService.getUserData();

    this.http.get(this.constants.getconsentDrupal).subscribe(drupalres => {
      this.drupalres = drupalres;
      sessionStorage.setItem('consentDrupalContent', JSON.stringify(drupalres));
    });
  }

  isValidKeyPressed(event) {
    const key = event.key;
    return (
      key === 'Backspace' ||
      key === 'Control' ||
      key === 'ArrowLeft' ||
      key === 'ArrowRight' ||
      (event.keyCode >= 48 && event.keyCode <= 57) ||
      (event.keyCode >= 96 && event.keyCode <= 105) || event.keyCode == 86
    );
  }

  onSubmit() {
    this.isFormSubmitted = true;
    this.alertService.clearError();
    const code = [
      this.verifyaccesscodeForm.value.accesscode1,
      this.verifyaccesscodeForm.value.accesscode2,
      this.verifyaccesscodeForm.value.accesscode3,
      this.verifyaccesscodeForm.value.accesscode4,
      this.verifyaccesscodeForm.value.accesscode5,
      this.verifyaccesscodeForm.value.accesscode6
    ].join('');

    if (this.userData && this.userData.regType) {
      this.registerUser(code);
    } else {
      let type: RegType;
      let commChannelValue = '';
      if (this.registrationService.isUserIdValidEmailOrPhoneNumber()) {
        type = this.userData.useridin.includes('@') ? RegType.EMAIL : RegType.MOBILE;
        commChannelValue = this.userData.useridin;
      } else {
        this.registrationService.getMemberProfile().subscribe(profile => {
          const commChannelDetails = this.registrationService.getRequestedData(profile);
          type = commChannelDetails.commChannelType === 'EMAIL' ? RegType.EMAIL : RegType.MOBILE;
          commChannelValue = commChannelDetails.commChannel;
        });
      }

      this.registrationService.verifyAccessCode(this.userData.useridin, code, type, commChannelValue).subscribe((response: any) => {
        if (response.result === '0') {
          sessionStorage.setItem('success', 'true');
          sessionStorage.removeItem('accesscode');
          sessionStorage.setItem('registrationProcessCompleted', 'true');
          this.router.navigate(['/register/success']);
        } else {
          this.alertService.setAlert(response.displaymessage, '', AlertType.Failure);
        }
      });
    }
  }

  registerUser(code: string) {
    const requestedData = {
      useridin: this.userData.useridin,
      passwordin: this.userData.passwordin,
      accessCode: code,
      regType: this.userData.regType,
      consentLanguageId: this.drupalres[0].Version,
      consentLanguage: encodeURI(this.drupalres[0].Body),
      consentTS: this.datePipe.transform(new Date(), 'M/d/yyyy h:m:s aa', this.timezoneOffset),
      from: sessionStorage.getItem('isPSW') === 'true' ? 'MPSW' : ''
    };
    this.registrationService.register(requestedData).subscribe(
      response => {
        if (response['displaymessage']) {
          this.alertService.setAlert(response['displaymessage'], '', AlertType.Failure);
        } else {
          const generatedRequest = {
            useridin: this.userData.useridin,
            passwordin: this.userData.passwordin
          };
          sessionStorage.setItem('email-password', JSON.stringify(generatedRequest));
          this.http.newlogin(generatedRequest).subscribe(() => {
            this.globalService.setUserData({});
            sessionStorage.getItem('isPSW') === 'true'
              ? (this.router.navigate(['/register/account-creation-success']), sessionStorage.setItem('isPSWVerifyCode', 'true'))
              : this.router.navigate(['/register/register-detail']);
          });
        }
      },
      err => {
        if (err.status < 500) {
          this.globalService.handleError(err.error, this.constants.displayMessage);
        }
        $('#requestTimeoutError').modal('open');
      }
    );
  }

  splitAndPlacePastedValues(event, materialForm): boolean {
    event.preventDefault();
    let pastedData = '';
    if (event.clipboardData) {
      pastedData = event.clipboardData.getData('text/plain');
    } else if (window['clipboardData']) {
      pastedData = window['clipboardData'].getData('Text');
    }
    pastedData = pastedData.replace(/\D/g, '');
    let pastedCharArr = pastedData.split('');
    if (pastedCharArr.length > 6) {
      pastedCharArr = pastedCharArr.splice(0, 6);
    }

    const accessCodeFields: NodeListOf<Element> = document.querySelectorAll('input.access-code');
    Object.keys(materialForm.controls).forEach((controlName, controlIndex) => {
      const pastedNumber: string = pastedCharArr[controlIndex];
      if (pastedNumber) {
        const formInputControl: FormControl = materialForm.get(controlName);
        // focus method does not work as such in ie11. hence requires a timeout block as fix/workaround for the same
        setTimeout(() => {
          (accessCodeFields[controlIndex] as HTMLInputElement).focus();
          formInputControl.setValue(pastedNumber);
        }, 10);
      } else {
        return false;
      }
    });

    this.getMatFormClass(materialForm);
    return true;
  }

  getMatFormClass(materialForm: FormGroup): VerifyAccessCodeInputValidationResultModel {
    this.verifyaccesscodeFormValidator = new VerifyAccessCodeInputValidationResultModel();

    if (!materialForm) {
      throw new Error(RegistrationModuleConstants.errorMessages.invalidMaterialFormError);
    }

    const controls: FormGroupControlsModel = materialForm.controls;
    const controlNames = RegistrationModuleConstants.controls;
    const accessCodeControl1 = controls[controlNames.accessCode1];
    const accessCodeControl2 = controls[controlNames.accessCode2];
    const accessCodeControl3 = controls[controlNames.accessCode3];
    const accessCodeControl4 = controls[controlNames.accessCode4];
    const accessCodeControl5 = controls[controlNames.accessCode5];
    const accessCodeControl6 = controls[controlNames.accessCode6];

    if (
      !(accessCodeControl1 && accessCodeControl2 && accessCodeControl3 && accessCodeControl4 && accessCodeControl5 && accessCodeControl6)
    ) {
      return this.verifyaccesscodeFormValidator;
    }

    const controlErrors: ValidationErrors =
      accessCodeControl1.errors ||
      accessCodeControl2.errors ||
      accessCodeControl3.errors ||
      accessCodeControl4.errors ||
      accessCodeControl5.errors ||
      accessCodeControl6.errors;

    const allTouched: boolean =
      accessCodeControl1.touched &&
      accessCodeControl2.touched &&
      accessCodeControl3.touched &&
      accessCodeControl4.touched &&
      accessCodeControl5.touched &&
      accessCodeControl6.touched;

    const errorFlag: boolean = controlErrors ? true : !allTouched;

    const hasRequiredErrorFlags: boolean =
      (accessCodeControl1.errors && accessCodeControl1.errors.required) ||
      (accessCodeControl2.errors && accessCodeControl2.errors.required) ||
      (accessCodeControl3.errors && accessCodeControl3.errors.required) ||
      (accessCodeControl4.errors && accessCodeControl4.errors.required) ||
      (accessCodeControl5.errors && accessCodeControl5.errors.required) ||
      (accessCodeControl6.errors && accessCodeControl6.errors.required);

    this.verifyaccesscodeFormValidator.isError = errorFlag;
    this.verifyaccesscodeFormValidator.hasErrors = hasRequiredErrorFlags;
  }

  onKeyDown(event) {
    if (event.keyCode === 16) {
      this.shiftKeyDown = true;
    }
    if (this.shiftKeyDown || !this.isValidKeyPressed(event)) {
      return false;
    }
  }

  onKeyUp(event, previousElement, nextElement, materialForm) {
    if (this.shiftKeyDown) {
      if (event.keyCode === 16) {
        this.shiftKeyDown = false;
      }
      return false;
    }

    if (event && event.target['value'] === '' && !this.isValidKeyPressed(event)) {
      return false;
    }
    this.getMatFormClass(materialForm);
    if ((event.key === 'Backspace' || event.which === 37 || event.key === 'ArrowLeft') && previousElement) {
      previousElement.focus();
    }
    if (
      (event.key === 'ArrowRight' ||
        event.which === 39 ||
        (event.keyCode >= 48 && event.keyCode <= 57) ||
        (event.keyCode >= 96 && event.keyCode <= 105)) &&
      nextElement
    ) {
      setTimeout(() => nextElement.focus(), 100);
    }
  }

  resendAccessCode() {
    this.verifyaccesscodeForm.reset();
    if (this.userData.regType) {
      this.registrationService.checkUser(this.userData).subscribe(
        response => {
          console.log(response);
          if (response['displaymessage']) {
            this.alertService.setAlert(response['displaymessage'], '', AlertType.Failure);
          } else {
            this.alertService.clearError();
          }
        },
        err => {
          if (err.status >= 500) {
            $('#requestTimeoutError').modal('open');
          } else {
            this.globalService.handleError(err.error, this.constants.displayMessage); // , true
            $('#requestTimeoutError').modal('open');
          }
        }
      );
    } else {
      this.registrationService.sendCode(this.userData.useridin).subscribe();
    }
  }

  ngOnDestroy() {
    this.alertService.clearError();
  }

  ngAfterViewInit(): void {
    const scopename = this.authService.authToken ? this.authService.authToken.scopename : '';
    if (this.userData && !this.userData.regType && scopename !== 'AUTHENTICATED-NOT-VERIFIED') {
      this.registrationService.sendCode(this.userData.useridin).subscribe();
    }
  }
}
