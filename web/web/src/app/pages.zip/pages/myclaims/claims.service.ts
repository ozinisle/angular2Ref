import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { AuthService } from '../../shared/shared.module';
import { ConstantsService } from '../../shared/shared.module';

import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { ClaimsDetails, MockClaim } from './claims.model';
import { ClaimsSummaryRequestModel, ClaimsSummaryResponseModel, ClaimSummaryMetadata } from './models/claims-summary-data.model';
import {
  ClaimsSummaryRequestModelInterface,
  ClaimsSummaryResponseModelInterface
} from './models/interfaces/claims-summary-data-model.interface';
import { of } from 'rxjs/observable/of';
import { catchError, map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';


export interface Config{
  eyeMedStartDate: string;
}

@Injectable()
export class ClaimsService {
  private claimDetails = new BehaviorSubject<ClaimsDetails>(null);
  public claimDetails$ = this.claimDetails.asObservable();

  private claimRecord = new BehaviorSubject<MockClaim>(null);
  public claimRecord$ = this.claimRecord.asObservable();

  constructor(private http: AuthHttp, private httpClient: HttpClient, private constants: ConstantsService, private authService: AuthService) {}

  getClaims(
    filterPaginationReqParams?: ClaimsSummaryRequestModelInterface,
    pagination?: boolean
  ): Observable<ClaimsSummaryResponseModelInterface> {
    let request: ClaimsSummaryRequestModelInterface = new ClaimsSummaryRequestModel(),
      globalSpinner = true;
    if (!filterPaginationReqParams) {
      request.useridin = this.authService.useridin;
      const sortorder = 'Most Recent';
      request.summaryMetaData = new ClaimSummaryMetadata();
      request.summaryMetaData.sortOrder = sortorder;
    } else {
      request = filterPaginationReqParams;
      if (pagination) {
        globalSpinner = false;
      }
    }

    return this.http.encryptPost(this.constants.claimsUrl, request, null, null, globalSpinner).map(response => {
      return response as ClaimsSummaryResponseModel;
    });
  }

  getClaimDetails(body): Observable<any> {
    const url = body.depid ? this.constants.claimsdepdetailsUrl : this.constants.claimdetailsUrl;
    return this.http.encryptPost(url, body);
  }

  getClaimProcessingStatus(requestParams) {
    const url = this.constants.claimProcessingStatusUrl;
    return this.http.encryptPost(url, requestParams);
  }

  getClaimsBenefitsLink(body): Observable<any> {
    const url = this.constants.benefitsLinkUrl;
    return this.http.encryptPost(url, body);
  }

  getCostShareClaimStatusMessage(): Observable<any> {
    return this.http.get(this.constants.drupalCostShareForClaimsUrl);
  }

  /**
   * Return an observbable with the configuration from Drupal.
   * Map to an error if config is not returned in the content.
   */
  private getConfig$() : Observable<Config> {
    return this.httpClient.get<Array<any>>(this.constants.drupalConfigUrl)
      .pipe(map(response => {
        if (response != null && response.length > 0 && response[0].config != null) {
          return JSON.parse(response[0].config) as Config
        } else {
          throw new Error("Config is not returned with any value");
        }
      }));
  }

  /**
   * Return the start date to show EyeMed link.
   * If the date is not in the config or if there is an error
   * we fallback on the date from the constant service.
   */
  private getEyeMedStartDate$() : Observable<Date> {
    return this.getConfig$()
      .pipe(map(config => {
        if (config.eyeMedStartDate 
          && config.eyeMedStartDate !== ""
          && !isNaN(new Date(config.eyeMedStartDate).getDate())) {
          return new Date(config.eyeMedStartDate)
        } else {
          return this.constants.eyeMedStartDate;
        }}))
      .pipe(catchError(() => {
        return of(this.constants.eyeMedStartDate);
      }));
  }

  /**
   * Return bool value if link needs to be displayed.
   */
  shouldDisplayEyemedLink$(userType:String) : Observable<boolean> {
    if (userType.toLowerCase() !== 'medicare') {
      return Observable.of(false);
    } else {
      return this.getEyeMedStartDate$().pipe(map(date => date < new Date()));
    }
  }

}
