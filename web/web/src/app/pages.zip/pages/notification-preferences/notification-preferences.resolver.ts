import { Injectable } from '@angular/core';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { ProfileService } from '../../shared/services/myprofile/profile.service';
import { NotificationPreferencesService } from './notification-preferences.service';

@Injectable()
export class NotificationPreferencesResolver {
  constructor(private profileService: ProfileService) {}

  resolve() {
    return this.getCommStatus().map(result => ({
      commstatus: result[0]
    }));
  }

  getCommStatus() {
    return forkJoin(this.profileService.getcommStatus());
  }
}
