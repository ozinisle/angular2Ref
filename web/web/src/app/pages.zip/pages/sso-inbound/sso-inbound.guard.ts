import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from "@angular/router";
import { Observable } from "rxjs";
import { EnvironmentService } from "../../services/environement/environment.service";

@Injectable()
export class SsoInboundGuard implements CanActivate {

    constructor(private router: Router, private environmentService: EnvironmentService) {}

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean> | Promise<boolean> {
        if (this.environmentService.isProdEnv()) {
            this.router.navigate(['/login']);
            return false;
        }
        return true;
    }

}