import { RouterModule, Routes } from '@angular/router';
import { UnauthenticatedLayoutComponent } from '../../shared/layouts/UnauthenticatedLayoutComponent/UnauthenticatedLayout.component';
import { LoginComponent } from './pages/login/login.component';
import { TempMemInfoComponent } from './pages/temp-mem-info/temp-mem-info.component';
import { UserNotFoundComponent } from './pages/user-not-found/user-not-found.component';
import { AuthenticaionErrorComponent } from './pages/authenticaion-error/authenticaion-error.component';
import { SsoInboundGuard } from './sso-inbound.guard';

export const ROUTER: Routes = [
  {
    path: 'login',
    component: UnauthenticatedLayoutComponent,
    children: [
      {
        path: '',
        component: LoginComponent
      }
    ]
  },
  {
    path: 'user-not-found',
    component: UnauthenticatedLayoutComponent,
    children: [
      {
        path: '',
        component: UserNotFoundComponent
      }
    ]
  },
  {
    path: 'mem-info',
    canActivate: [SsoInboundGuard],
    children: [
      {
        path: '',
        component: TempMemInfoComponent
      }
    ]
  },
  {
    path: 'authentication/error',
    component: UnauthenticatedLayoutComponent,
    children: [
      {
        path: '',
        component: AuthenticaionErrorComponent
      }
    ]
  },
  {
    path: '**',
    redirectTo: 'mem-info'
  }
];

export const SsoInboundRouter =  RouterModule.forChild(ROUTER);
