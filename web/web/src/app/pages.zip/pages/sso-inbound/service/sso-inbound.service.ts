import { Injectable } from '@angular/core';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { AuthService } from '../../../shared/shared.module';
import { HttpHeaders } from '@angular/common/http';
import { SsoInboundConstants } from './sso-inbound.constants';

@Injectable()
export class SsoInboundService {

    constructor(
        private constants: SsoInboundConstants,
        private authHttp: AuthHttp,
        private authService: AuthService
    ) {}

    authorize(authToken: string) {
        const headers = new HttpHeaders().set('Authorization', `Bearer ${authToken}`);
        const payload: any = {};
        return this.authService.getTokens()
        .do((token) => {
            this.authService.cryptoToken = token;
            payload.key2id = this.authService.cryptoToken.key2id;
            this.authService.persistSession();
        })
        .switchMap(() => {            
            return this.authHttp.post(this.constants.authorize, this.authHttp.handleRequest(payload), {headers})
        });                
    }

    authenticate(payload: any) {
        return this.authHttp.post(this.constants.apiAuthUrl, payload);
    }

}
