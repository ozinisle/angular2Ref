import { Injectable } from '@angular/core';
import { environment } from '../../../../environments/environment';

@Injectable()
export class SsoInboundConstants {

    apiAuthUrl: string;
    authorize: string;
    authentication: string;

    constructor() {
        this.apiAuthUrl = environment.ssoInboundAuthUrl;
        this.authorize = `${environment.ssoInboundAuthorize}authorize`
        this.authentication = environment.ssoInboundAuthenticationUrl;
    }

}
