import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedModule } from '../../shared/shared.module';
import { LoginComponent } from './pages/login/login.component';
import { TempMemInfoComponent } from './pages/temp-mem-info/temp-mem-info.component';
import { UserNotFoundComponent } from './pages/user-not-found/user-not-found.component';
import { AuthenticaionErrorComponent } from './pages/authenticaion-error/authenticaion-error.component';
import { HttpModule } from '@angular/http';
import { SsoInboundService } from './service/sso-inbound.service';
import { SsoInboundConstants } from './service/sso-inbound.constants';
import { SsoInboundRouter } from './sso-inbound.routing';
import { SsoInboundGuard } from './sso-inbound.guard';

@NgModule({
    declarations: [LoginComponent,  UserNotFoundComponent, TempMemInfoComponent, AuthenticaionErrorComponent],
    exports: [],
    imports: [
      CommonModule,
      HttpClientModule,
      HttpModule,
      FormsModule,
      SharedModule,
      ReactiveFormsModule,
      MatFormFieldModule,
      MatInputModule,
      TextMaskModule,
      SsoInboundRouter
    ],
    providers: [
      SsoInboundService,
      SsoInboundConstants,
      SsoInboundGuard
    ]
  })
  export class SsoInboundModule {}
