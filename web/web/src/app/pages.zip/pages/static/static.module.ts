import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material';
import { SharedModule } from '../../shared/shared.module';
import { AlegeustermsComponent } from './alegeusterms/alegeusterms.component';
import { Campaign1Component } from './campaign-1/campaign-1.component';
import { Campaign2Component } from './campaign-2/campaign-2.component';
import { Campaign3Component } from './campaign-3/campaign-3.component';
import { Campaign4Component } from './campaign-4/campaign-4.component';
import { Campaign5Component } from './campaign-5/campaign-5.component';
import { Campaign6Component } from './campaign-6/campaign-6.component';
import { ConfidentialityComponent } from './confidentiality/confidentiality.component';
import { FpoMyprofileComponent } from './fpo-myprofile/fpo-myprofile.component';
import { LearnMoreComponent } from './learn-more/learn-more.component';
import { MaintenanceComponent } from './maintenance/maintenance.component';
import { Secure1Component } from './secure-1/secure-1.component';
import { StaticComponent } from './static.component';
import { StaticPagesResolver } from './static.resolver';
import { StaticComponentRouter } from './static.routing';
import { TermsComponent } from './terms/terms.component';
import { FpoLayoutModule } from '../../shared/layouts/FpoLayoutComponent/fpo-layout.module';

@NgModule({
  declarations: [
    StaticComponent,
    ConfidentialityComponent,
    LearnMoreComponent,
    TermsComponent,
    AlegeustermsComponent,
    MaintenanceComponent,
    FpoMyprofileComponent,
    Campaign1Component,
    Campaign2Component,
    Campaign3Component,
    Campaign4Component,
    Campaign5Component,
    Campaign6Component,
    Secure1Component
  ],
  imports: [StaticComponentRouter, SharedModule, FormsModule, ReactiveFormsModule, CommonModule, MatButtonModule, FpoLayoutModule],
  providers: [StaticPagesResolver]
})
export class StaticModule {}
