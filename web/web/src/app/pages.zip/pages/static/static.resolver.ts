import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { AlertType } from '../../shared/alerts/alertType.model';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { AlertService, AuthService, ConstantsService } from '../../shared/shared.module';

@Injectable()
export class StaticPagesResolver {
  public securefpocontentData = null;
  public sourceURL = '';
  public currUrl = '';

  constructor(
    private authService: AuthService,
    private router: Router,
    private authHttp: AuthHttp,
    private alertService: AlertService,
    private constants: ConstantsService
  ) {}

  async resolve(routeInfo: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    this.sourceURL = state.url;
    const numberal = this.sourceURL.substring(this.sourceURL.length - 1);
    console.log('fromURL:', numberal);
    this.currUrl = 'drupalContentSecureCampaignUrl' + numberal;
    console.log('lookingFor', this.constants[this.currUrl]);
    return await forkJoin([this.fetchMyAccountInfo()]).toPromise();
  }

  fetchMyAccountInfo(): Observable<any> {
    return this.authHttp.get(this.constants[this.currUrl]);
  }
}
