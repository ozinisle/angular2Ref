import { Component, HostListener, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService, ConstantsService } from '../../../shared/shared.module';

@Component({
  selector: 'app-maintenance',
  templateUrl: './maintenance.component.html',
  styleUrls: ['./maintenance.component.scss']
})
export class MaintenanceComponent implements OnInit {
  mobileViewPort = 992;
  ismobile: boolean;
  contactus = this.constants.contactus + this.authService.authToken.scopename;
  urlConfig = {
    myplans: '../myplans',
    myaccount: '../myaccount',
    fad: '../fad'
  };

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    if (event.target.innerWidth <= this.mobileViewPort) {
      this.ismobile = true;
    } else {
      this.ismobile = false;
    }
  }
  constructor(public constants: ConstantsService, public authService: AuthService, private router: Router, private r: ActivatedRoute) {}

  ngOnInit() {}

  openUrl(url) {
    if (url) {
      window.open(url, '_blank');
    }
  }

  openSsoUrl(url) {
    if (url) {
      window.open(url, '_blank');
    }
  }
  navigate(id, routeParams?) {
    const url = this.urlConfig[id];

    if (url) {
      if (!routeParams) {
        this.router.navigate([url], { relativeTo: this.r });
      } else {
        this.router.navigate([url], { relativeTo: this.r });
      }
    } else {
      return;
    }
  }
}
