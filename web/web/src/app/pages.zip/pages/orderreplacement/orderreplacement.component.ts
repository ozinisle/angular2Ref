import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertType } from '../../shared/alerts/alertType.model';
import { DependantsService } from '../../shared/services/dependant.service';
import { GlobalService } from '../../shared/services/global.service';
import { OrderreplacementService } from '../../shared/services/orderreplacement/orderreplacement.service';
import { AlertService, AuthService } from '../../shared/shared.module';
import { DependentsResponseModel } from '../myclaims/models/dependants.model';
import { DependentsResponseModelInterface } from '../myclaims/models/interfaces/dependants-model.interface';
import { OrderreplacementModel } from './orderreplacement.model';

@Component({
  templateUrl: './orderreplacement.component.html',
  styleUrls: ['./orderreplacement.component.scss']
})
export class OrderreplacementComponent implements OnInit, OnDestroy {
  cardListResponseCount: number;
  memberList: any[];
  message: string;
  isEligible: boolean;
  isRtmsUpmode: boolean;
  public ismobile: any;
  mobileViewPort = 992;
  isReviewed: boolean;
  isSubmitted: boolean;
  submissionMessageHeader: string;
  submissionMessage: string;
  reviewMessage: string;
  submittedSuccessfully: boolean;
  sideNavStatus: string;
  header: string;
  res: any;
  isMemberText: boolean;
  userString: 'User' = 'User';
  dependant: string;
  dependentList: DependentsResponseModelInterface = new DependentsResponseModel();
  medicalCardUsers = [];
  dentalCardUsers = [];
  selectedMemberList = [];
  selectedMedicalMemberList = [];
  selectedDentalMemberList = [];
  submittedMembersList: any[];
  medicalUnEligibleList = [];
  dentalUnEligibleList = [];
  subscriberAddress: any = {};
  successList: any[];
  successMedicalList = [];
  successDentalList = [];
  failureList: any[];
  cardKeys = [];
  keys = [];
  authTokenDetailsJson: any;
  orderIdCardsData = true;
  allmeidcalselected: boolean = false;
  alldentalselected: boolean = false;
  allMedicalCardSelectDisable: boolean = false;
  memberData: OrderreplacementModel = new OrderreplacementModel().deserialize({});

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    if (event.target.innerWidth <= this.mobileViewPort) {
      this.ismobile = true;
    } else {
      this.ismobile = false;
      this.sideNavStatus = 'in';
    }
  }

  constructor(
    public authService: AuthService,
    private alertService: AlertService,
    private activatedRoute: ActivatedRoute,
    public dependantsService: DependantsService,
    public orderreplacementService: OrderreplacementService,
    public globalService: GlobalService,
    public router: Router
  ) {
    this.memberList = [];
    this.message = '';
    this.isEligible = true;
    this.isReviewed = false;
    this.isSubmitted = false;
    this.submittedMembersList = [];
    this.successList = [];
    this.failureList = [];
    this.submissionMessageHeader = '';
    this.submissionMessage = '';
    this.reviewMessage =
      "Our records indicate you've placed an order in the past 14 days. " +
      "If you haven't received your card, call Member Service at " +
      '<a href="tel:+18002622583" class="underline">1-800-262-BLUE (2583)</a>.';
    this.submittedSuccessfully = false;
    this.header = 'Order ID Card';
    this.isMemberText = true;
    this.dependentList = this.authService.getDependentsList();
    this.res = this.activatedRoute.snapshot.data.cardsData;

    this.handleError(this.res);
  }

  handleError(errRes) {
    try {
      if (errRes && errRes['result'] && errRes['result'] < 0) {
        const displayMessage = errRes['displaymessage']
          ? errRes['displaymessage']
          : "We're sorry, there's been a system error. Please try again.";
        this.alertService.setAlert(displayMessage, '', AlertType.Failure);
        this.orderIdCardsData = false;
      }
    } catch (e) {
      console.log(e);
    }
  }

  ngOnInit() {
    if (this.authService.getRtmsMode()) {
      this.isRtmsUpmode = true;
    } else {
      this.isRtmsUpmode = false;
    }
    const data = this.res;

    if (data) {
      if (data.SubscriberAddress) {
        this.subscriberAddress = data.SubscriberAddress;
      }
      this.cardListResponseCount = data.MemberDetails.length;
    }
    this.dependant = this.userString;
    const authTokenDetails = sessionStorage.getItem('authToken');
    if (authTokenDetails && authTokenDetails !== 'undefined') {
      this.authTokenDetailsJson = JSON.parse(authTokenDetails);
    }
    this.verifyPreSelectedCards(this.res.MemberDetails);
  }

  includeCardTypesForMember(totalMembers) {
    this.memberList = this.memberList.map(member => {
      const cardTypes = [];
      let isFirstPlanChecked = 0;
      const filteredMemebers = totalMembers.filter(totalMember => totalMember.MemberID === member.value);
      filteredMemebers.sort((filterMemberA, filterMemberB) =>
        filterMemberA.PlanType > filterMemberB.PlanType ? -1 : filterMemberB.PlanType > filterMemberA.PlanType ? 1 : 0
      );
      filteredMemebers.forEach((filterdMember, sIndex) => {
        if (filterdMember.RequestIDcardEligibilityIndicator !== 'false' && !isFirstPlanChecked) {
          isFirstPlanChecked = sIndex + 1;
        }
        cardTypes.push({
          type: filterdMember.PlanType,
          planName: filterdMember.PlanName,
          groupNumber: filterdMember.GroupNumber,
          isChecked: isFirstPlanChecked === sIndex + 1,
          isEligible: filterdMember.RequestIDcardEligibilityIndicator
        });
        if (filterdMember.DateEligibilityIndicator === 'false' && !this.isReviewed) {
          this.isReviewed = true;
        }
      });

      return {
        ...member,
        cardTypes
      };
    });
  }

  getMembersList(data) {
    const membersListItems = [];
    let memberData: OrderreplacementModel;
    const memberSuffItems = [];
    let isRequestCardEligible = false;
    data.forEach(member => {
      if (memberSuffItems.indexOf(member.MemberID) !== -1) {
        return;
      }
      const isEligible = data.find(
        eligibleMember => eligibleMember.MemberID === member.MemberID && eligibleMember.RequestIDcardEligibilityIndicator === 'true'
      );
      memberSuffItems.push(member.MemberID);
      memberData = new OrderreplacementModel().deserialize(member);
      if (member.Relationship === 'subscriber') {
        this.memberData = memberData;
      }
      membersListItems.push({
        ...memberData,
        value: member.MemberID,
        selected: false, // && member.Relationship === 'subscriber'
        name: memberData.fullMemInfo,
        aliasName: memberData.fullName,
        requestIdCardElegible: !!isEligible
      });
      if (!!isEligible) {
        isRequestCardEligible = true;
      }
    });

    return membersListItems;
  }

  ngOnDestroy() {
    this.alertService.clearError();
  }

  preparesuccessResponse(resultset) {
    this.successMedicalList = [];
    this.successDentalList = [];
    const memberList = this.selectedMemberList && this.selectedMemberList.length ? this.selectedMemberList : this.memberList;
    resultset.forEach(result => {
      const selectedMember = memberList.find(member => member.GroupNumber === result.groupNumber && member.MemberID === result.memberID);
      if (selectedMember) {
        result.result.toString() === '0' ? this.successList.push(selectedMember) : this.failureList.push(selectedMember);
      }
    });
    this.successList.forEach(card => {
      if (card.PlanType == 'medical') {
        this.successMedicalList.push(card);
      }
      if (card.PlanType == 'dental') {
        this.successDentalList.push(card);
      }
    });
  }
  submit() {
    const selectedMemberCardList = this.getSelectedMembersList();
    this.isSubmitted = true;

    this.orderreplacementService.submitCard(selectedMemberCardList).subscribe(resultset => {
      const errorList = resultset.filter(result => result.result < 0);
      if (errorList && errorList.length === resultset.length) {
        this.alertService.setAlert('', 'Error!', AlertType.Failure);
        this.submissionMessageHeader = errorList.length > 1 ? "We Can't Complete Your Order" : "We Can't Complete Your Order";
        this.submissionMessage = resultset[0]['displayMessage'] || this.reviewMessage;
      } else {
        this.alertService.setAlert('', 'Success!', AlertType.Success);
        this.submissionMessageHeader = 'We Received Your Order';
        this.submittedSuccessfully = true;
        this.preparesuccessResponse(resultset);

        this.header = "We've received your order!";
      }
    });
  }

  checkAuthorized() {
    return true;
  }

  reviewCard(bReview) {
    this.message = this.reviewMessage;
    this.isEligible = !bReview;
    this.isReviewed = true;
    this.isMemberText = false;
  }

  disbaledSubmitButton() {
    return this.selectedMedicalMemberList.length + this.selectedDentalMemberList.length < 1 ? true : false;
  }

  verifyPreSelectedCards(data) {
    data.forEach(card => {
      if (card.PlanType == 'medical') {
        this.medicalCardUsers.push(card);
        if (card.RequestIDcardEligibilityIndicator == 'false') {
          this.medicalUnEligibleList.push(card);
        }
        if (card.isChecked) {
          card.selected = true;
          this.selectedMedicalMemberList.push(card);
        }
      } else if (card.PlanType == 'dental') {
        this.dentalCardUsers.push(card);
        if (card.RequestIDcardEligibilityIndicator == 'false') {
          this.dentalUnEligibleList.push(card);
        }
        if (card.isChecked) {
          card.selected = true;
          this.selectedDentalMemberList.push(card);
        }
      }
    });
    this.memberList = data;
    this.allmeidcalselected = this.selectedMedicalMemberList.length === this.medicalCardUsers.length ? true : false;
    this.alldentalselected = this.selectedDentalMemberList.length === this.dentalCardUsers.length ? true : false;

    if (this.medicalUnEligibleList.length || this.dentalUnEligibleList.length) {
      this.alertService.setAlert(
        'Our records show that you have placed an order in the past 14 days.',
        'Too soon to order!',
        AlertType.Notification
      );
    }

    if (data && data.length == 1) {
      if (data[0].RequestIDcardEligibilityIndicator != 'false') {
        data[0].isChecked = true;
        data[0].selected = true;
        this.memberList = data;
        this.submit();
      }
    }
  }
  cancel() {
    this.router.navigate(['mycards']);
  }

  onCardAllCheckedStatusChange(changeEvent, type) {
    if (type === 'medical') {
      if (changeEvent.checked) {
        this.selectedMedicalMemberList = [];
        this.memberList.forEach(card => {
          if (card.PlanType == 'medical' && card.RequestIDcardEligibilityIndicator != 'false') {
            card.selected = true;
            card.isChecked = true;
            this.selectedMedicalMemberList.push(card);
          }
        });
        this.allmeidcalselected = true;
        // this.unselectAllmembersChecked(changeEvent, type);
      } else {
        this.memberList.forEach(card => {
          if (card.PlanType == 'medical' && card.RequestIDcardEligibilityIndicator != 'false') {
            card.selected = false;
            card.isChecked = false;
          }
        });

        // this.unselectAllmembersChecked(changeEvent, type);
        this.selectedMedicalMemberList = [];
        this.allmeidcalselected = false;
      }
    }
    if (type === 'dental') {
      if (changeEvent.checked) {
        this.selectedDentalMemberList = [];
        this.memberList.forEach(card => {
          if (card.PlanType == 'dental' && card.RequestIDcardEligibilityIndicator != 'false') {
            card.selected = true;
            card.isChecked = true;
            this.selectedDentalMemberList.push(card);
          }
        });
        this.alldentalselected = true;
      } else {
        this.memberList.forEach(card => {
          if (card.PlanType == 'dental' && card.RequestIDcardEligibilityIndicator != 'false') {
            card.selected = true;
            card.selected = false;
            card.isChecked = false;
          }
        });
        this.selectedDentalMemberList = [];
        this.alldentalselected = false;
      }
    }
  }

  unselectAllmembersChecked(changeEvent, type) {
    this.memberList.forEach(member => {
      member.cardTypes.forEach(card => {
        if (type == card.type) {
          card.isChecked = changeEvent.checked;
        }
        if (type == card.type) {
          card.isChecked = changeEvent.checked;
        }
      });
    });
  }

  onUserCheckedStatusChange(changeEvent, member, type) {
    if (type === 'medical' && member.RequestIDcardEligibilityIndicator != 'false') {
      if (changeEvent.checked) {
        member.selected = changeEvent.checked;
        member.isChecked = changeEvent.checked;
        this.selectedMedicalMemberList.push(member);
      } else {
        member.selected = changeEvent.checked;
        member.isChecked = changeEvent.checked;
        let findItem = this.selectedMedicalMemberList.find((e, i) => {
          if (e.MemberID == member.MemberID) {
            e.index = i;
            return e;
          }
        });
        if (findItem) {
          this.selectedMedicalMemberList.splice(findItem.index, 1);
        }
        this.allmeidcalselected = false;
      }

      this.allmeidcalselected = this.selectedMedicalMemberList.length === this.medicalCardUsers.length ? true : false;
    }

    if (type === 'dental' && member.RequestIDcardEligibilityIndicator != 'false') {
      if (changeEvent.checked) {
        member.selected = changeEvent.checked;
        member.isChecked = changeEvent.checked;
        this.selectedDentalMemberList.push(member);
      } else {
        member.selected = changeEvent.checked;
        member.isChecked = changeEvent.checked;
        let findItem = this.selectedDentalMemberList.find((e, i) => {
          if (e.MemberID == member.MemberID) {
            e.index = i;
            return e;
          }
        });
        if (findItem) {
          this.selectedDentalMemberList.splice(findItem.index, 1);
        }
        this.alldentalselected = false;
      }

      this.alldentalselected = this.selectedDentalMemberList.length === this.dentalCardUsers.length ? true : false;
    }
  }

  getSelectedMembersList() {
    const selectedMemberCardList = [];
    for (const member of this.memberList) {
      if (member.isChecked) {
        this.submittedMembersList.push(member);
        selectedMemberCardList.push({
          groupNumber: member.GroupNumber,
          idCardIndicator: 'Y',
          subscriberNumber: member.SubscriberNumber,
          memberID: member.MemberID
        });
      }
    }
    return selectedMemberCardList;
  }

  impersonation() {
    return this.authService.impersonation();
  }
}
