import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule, MatCheckboxModule, MatListModule } from '@angular/material';
import { ConstantsService } from '../../shared/services/constants.service';
import { SharedModule } from '../../shared/shared.module';
import { MaintenanceComponent } from './maintenance/maintenance.component';
import { OrderreplacementComponent } from './orderreplacement.component';
import { OrderreplacementRouter } from './orderreplacement.routing';

@NgModule({
  declarations: [OrderreplacementComponent, MaintenanceComponent],
  imports: [
    CommonModule,
    OrderreplacementRouter,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    MatCheckboxModule,
    MatListModule,
    MatButtonModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class OrderreplacementModule {}
