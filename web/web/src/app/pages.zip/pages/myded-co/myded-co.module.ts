import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule, MatExpansionModule, MatListModule, MatRadioModule, MatTooltipModule } from '@angular/material';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedModule } from '../../shared/shared.module';
import { GlossaryComponent } from './drupalpages/glossary/glossary.component';
import { InformationComponent } from './drupalpages/information/information.component';
import { MyDedCoComponent } from './landing/myded-co.component';
import { MyDedCoG1, MyDedCoG2, MyDedCoGuard } from './myded-co.guard';
import { MyDedCoRouter } from './myded-co.routing';
import { FpoLayoutModule } from '../../shared/layouts/FpoLayoutComponent/fpo-layout.module';

@NgModule({
  declarations: [MyDedCoComponent, GlossaryComponent, InformationComponent],
  exports: [],
  providers: [MyDedCoG1, MyDedCoG2, MyDedCoGuard],
  imports: [
    MyDedCoRouter,
    FormsModule,
    CommonModule,
    TextMaskModule,
    ReactiveFormsModule,
    SharedModule,
    MatListModule,
    MatRadioModule,
    MatButtonModule,
    MatExpansionModule,
    MatTooltipModule,
    FpoLayoutModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class MyDedCoModule {}
