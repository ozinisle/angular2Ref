import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { FilterSelectionItemInterface } from '../../shared/components/filter/filter-model.interface';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { DependantsService } from '../../shared/services/dependant.service';
import { DependentsResponseModelInterface } from '../myclaims/models/interfaces/dependants-model.interface';
import { AuthService } from './../../shared/services/auth.service';
import { ConstantsService } from './../../shared/services/constants.service';
import { GetFamilyDeductiblesRequest } from './models/getFamilyDeductibles.model';
import { GetIndDeductiblesRequest } from './models/getIndDeductibles.model';
import { GetFamilyDeductiblesRequestInterface, GetFamilyDeductiblesResponseInterface } from './models/interfaces/getFamilyDeductibles-model.interface';
import { GetIndDeductiblesResponseInterface } from './models/interfaces/getIndDeductibles-model.interface';

@Injectable()
export class MyDedCoService {
  constructor(
    private http: AuthHttp,
    private constants: ConstantsService,
    public dependantsService: DependantsService,
    public authService: AuthService
  ) {}

  getDeductiblesAndCoinsuranceInfo(): Observable<GetFamilyDeductiblesResponseInterface> {
    const request: GetFamilyDeductiblesRequestInterface = new GetFamilyDeductiblesRequest();
    request.useridin = this.authService.useridin;
    return this.http
      .encryptPost(this.constants.getfamilydeductiblesUrl, request)
      .shareReplay(1)
      .map(response => {
        const familyDeductiblesResponse: GetFamilyDeductiblesResponseInterface = response as GetFamilyDeductiblesResponseInterface;
        this.sortDeductiblesData(familyDeductiblesResponse);
        return familyDeductiblesResponse;
      });
  }

  getIndividualDeductiblesAndCoinsuranceInfo(selectedMember: FilterSelectionItemInterface): Observable<GetIndDeductiblesResponseInterface> {
    const getIndDeductiblesRequest: GetIndDeductiblesRequest = new GetIndDeductiblesRequest();

    getIndDeductiblesRequest.member
      .setSubscriberNo(selectedMember.selectedOption.subscriberNo)
      .setMemberSuffix(
        selectedMember.selectedOption.memSuffix === ''
          ? selectedMember.selectedOption.loggedinUserSuffix
          : selectedMember.selectedOption.memSuffix
      )
      .setCoverageType(selectedMember.selectedOption.coverageType)
      .setUseridin(this.authService.useridin);

    return this.http
      .encryptPost(this.constants.getindividualdeductiblesUrl, getIndDeductiblesRequest)
      .map(individualDeductiblesResponse => {
        if (individualDeductiblesResponse) {
          console.log('GetIndividualDeductiblesAndCoinsuranceResponse', individualDeductiblesResponse);
          if (individualDeductiblesResponse.result && individualDeductiblesResponse.result < 0) {
            // this.bcbsmaErrorHandler.logError(individualDeductiblesResponse.errormessage, BcbsmaConstants.modules.myDedCoModule
            //   , MyDedCoConstants.service.myDedCoService, MyDedCoConstants.methods.getIndividualDeductiblesAndCoinsuranceInfo);
            return null;
          }

          this.sortDeductiblesData(individualDeductiblesResponse);
          return individualDeductiblesResponse as GetIndDeductiblesResponseInterface;
        } else {
          return null;
        }
      });
  }

  getDependents(): Observable<DependentsResponseModelInterface | {}> {
    return this.dependantsService.fetchDependentsList().catch(() => {
      return Observable.empty();
    });
  }

  sortDeductiblesData(deductiblesData) {
    if (deductiblesData && deductiblesData.accums && deductiblesData.accums.length > 0) {
      deductiblesData.accums.forEach(accumItem => {
        if (accumItem.outOfPocket && accumItem.outOfPocket.length > 0) {
          accumItem.outOfPocket.sort(this.getSortedList('networkIndicatorForOutOfPocketMax'));
        }
        if (accumItem.overallDeductibles && accumItem.overallDeductibles.length > 0) {
          accumItem.overallDeductibles.sort(this.getSortedList('networkIndicatorForOverallDeductible'));
        }
      });
    }
  }

  getSortedList(propertyName) {
    return (firstItem, secondItem) => {
      if (firstItem[propertyName] > secondItem[propertyName]) {
        return 1;
      } else if (firstItem[propertyName] < secondItem[propertyName]) {
        return -1;
      }
      return 0;
    };
  }

  getIndividualDedAndCoinInfo(deductiblesRequest): Observable<GetIndDeductiblesResponseInterface> {
    const getIndDeductiblesRequest: GetIndDeductiblesRequest = new GetIndDeductiblesRequest();

    getIndDeductiblesRequest.member
      .setSubscriberNo(deductiblesRequest.subscriberNo)
      .setMemberSuffix(
        deductiblesRequest.memSuffix === ''
          ? deductiblesRequest.loggedinUserSuffix
          : deductiblesRequest.memSuffix
      )
      .setCoverageType(deductiblesRequest.coverageType)
      .setUseridin(this.authService.useridin);

    return this.http
      .encryptPost(this.constants.getindividualdeductiblesUrl, getIndDeductiblesRequest)
      .map(individualDeductiblesResponse => {
        if (individualDeductiblesResponse) {
          if (individualDeductiblesResponse.result && individualDeductiblesResponse.result < 0) {
            return null;
          }

          this.sortDeductiblesData(individualDeductiblesResponse);
          return individualDeductiblesResponse as GetIndDeductiblesResponseInterface;
        } else {
          return null;
        }
      });
  }
}
