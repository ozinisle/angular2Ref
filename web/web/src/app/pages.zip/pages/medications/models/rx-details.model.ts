import { GeneralError } from '../../../shared/models/generic-app.model';
import { RxDetailsRequestModelInterface, RxDetailsResponseModelInterface } from './interfaces/rx-details-model.interface';
import { BaseRxDetailsRequestModel, RxDetails } from './my-medications-generic.models';

// tslint:disable-next-line:no-empty-interface
export class RxDetailsRequestModel extends BaseRxDetailsRequestModel implements RxDetailsRequestModelInterface {}

export class RxDetailsResponseModel extends GeneralError implements RxDetailsResponseModelInterface {
  rxDetails: RxDetails;
}
