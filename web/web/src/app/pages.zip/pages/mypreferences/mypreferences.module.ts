import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatCardModule,
  MatCheckboxModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatFormFieldModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatNativeDateModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedModule } from '../../shared/shared.module';
import { MyPrefDeliveryFinancialComponent } from './delivery-financial/delivery-financial.component';
import { MyPrefDeliveryComponent } from './delivery/delivery.component';
import { MyPrefConst } from './mypreferences.constants';
import { MyPrefALGGuard, MyPrefAPIResolver, MyPrefAVScopeGuard, MyProfileAPIResolver } from './mypreferences.guard';
import { PrefRouter } from './mypreferences.routing';
import { MyPrefService } from './mypreferences.service';
import { MyPreferencesComponent } from './mypreferences/mypreferences.component';
import { NotificationDetailComponent } from './notification-detail/notification-detail.component';
import { MyPrefNotificationsComponent } from './notifications/notifications.component';
import { VerifyEmailMobileComponent } from './verify-email-mobile/verify-email-mobile.component';


@NgModule({
  declarations: [
    MyPreferencesComponent,
    NotificationDetailComponent,
    MyPrefNotificationsComponent,
    MyPrefDeliveryComponent,
    VerifyEmailMobileComponent,
    MyPrefDeliveryFinancialComponent
  ],
  exports: [],
  providers: [MyPrefAVScopeGuard, MyPrefALGGuard, MyPrefService, MyPrefAPIResolver, MyProfileAPIResolver, MyPrefConst],
  imports: [
    FormsModule,
    CommonModule,
    TextMaskModule,
    ReactiveFormsModule,
    PrefRouter,
    SharedModule,
    MatRadioModule,
    MatSelectModule,
    MatCardModule,
    MatIconModule,
    MatSidenavModule,
    MatTooltipModule,
    MatDialogModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatExpansionModule,
    MatListModule,
    MatNativeDateModule,
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule, 
  ]
})
export class MyPreferencesModule {}
