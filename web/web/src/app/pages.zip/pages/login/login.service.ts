import { Injectable } from '@angular/core';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { AuthService } from '../../shared/services/auth.service';

@Injectable()
export class LoginService {
  constructor(private authService: AuthService, private authHttp: AuthHttp) {}

  login(request) {
    this.authService.cryptoToken = null;
    return this.authHttp.login(request);
  }
}
