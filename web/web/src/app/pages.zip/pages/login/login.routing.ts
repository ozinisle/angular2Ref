import { RouterModule, Routes } from '@angular/router';
import { UnauthenticatedLayoutComponent } from '../../shared/layouts/UnauthenticatedLayoutComponent/UnauthenticatedLayout.component';
import { ImpersonationLoginGuard } from '../../shared/utils/impersonation-login.guard';
import { NoMenuResolver } from '../../shared/utils/nomenu.resolver';
import { LoginComponent } from './login.component';

const LOGIN_ROUTER: Routes = [
  {
    path: 'login',
    canActivate: [ImpersonationLoginGuard],
    component: UnauthenticatedLayoutComponent,
    resolve: {
      menu: NoMenuResolver
    },
    children: [
      {
        path: '',
        component: LoginComponent
      }
    ]
  }
];

export const LoginRouter = RouterModule.forChild(LOGIN_ROUTER);
