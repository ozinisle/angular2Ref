import { Injectable } from '@angular/core';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { AuthService } from '../../../shared/shared.module';
import { FadConstants } from '../constants/fad.constants';
import { GetSearchByProfessionalResponseModelInterface } from '../modals/interfaces/getSearchByProfessional-models.interface';

@Injectable()
export class FadProviderCompareService {
  public searchResults: GetSearchByProfessionalResponseModelInterface;
  public searchData;
  public compareString = '';

  constructor(private bcbsmaHttpService: BcbsmaHttpService, private authHttp: AuthHttp,
    private authService: AuthService) { }

  getCompareTableDetail() {
    const doctorIDList = sessionStorage.getItem(FadConstants.storageVars.searchItemCompare);
    if (this.compareString || (doctorIDList && doctorIDList.length > 1)) {
      const compareUrl = FadConstants.urls.fadCompareProfessionals;
      const request = {
        useridin: this.authService.useridin,
        professionalIdList: this.compareString ? this.compareString : doctorIDList
      };
      if (this.authService.getFadHccsFlag() !== null) {
        request['hccsFlag'] = this.authService.getFadHccsFlag();
      }

      // adhoc fix for KLO-1722
      // fix is to call encryptFadPost instead of encryptPost
      return this.authHttp.encryptFadPost(compareUrl, request);
    }
    const url = FadConstants.jsonurls.fadFacilityCompareUrl;
    return this.bcbsmaHttpService.get(url);
  }

  setSearchResult(searchResults) {
    this.searchResults = searchResults;
  }

  getSearchResult() {
    return this.searchResults;
  }

  setCompareStirng(compareString: string) {
    sessionStorage.setItem(FadConstants.storageVars.searchItemCompare, compareString);
    this.compareString = compareString;
  }

  setCostInfo(costInfo) {
    sessionStorage.setItem('doctorCostInfo', JSON.stringify(costInfo));
  }

  getCostInfo() {
    const costInfo = sessionStorage.getItem('doctorCostInfo');
    if (costInfo) {
      const costInfoJson = JSON.parse(costInfo);
      return costInfoJson;
    }
    return null;
  }
}
