import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { SharedModule } from '../../shared/shared.module';
import { FadResolver } from '../landing/fad.resolver';
import { FadBreadCrumbsComponent } from './fad-bread-crumbs/fad-bread-crumbs.component';
import { FadBreadCrumbsService } from './fad-bread-crumbs/fad-bread-crumbs.service';
import { FadCostBreakdownComponent } from './fad-cost-breakdown/fad-cost-breakdown.component';
import { FadCostBreakdownService } from './fad-cost-breakdown/fad-cost-breakdown.service';
import { FadDoctorProfileComponent } from './fad-doctor-profile/fad-doctor-profile.component';
import { FadDoctorProfileResolver } from './fad-doctor-profile/fad-doctor-profile.resolver';
import { FadDoctorProfileService } from './fad-doctor-profile/fad-doctor-profile.service';
import { FadDoctorRatingComponent } from './fad-doctor-rating/fad-doctor-rating.component';
import { FadFacilityCardComponent } from './fad-facility-card/fad-facility-card.component';
import { FadFacilityCompareComponent } from './fad-facility-compare/fad-facility-compare.component';
import { FadFacilityCompareService } from './fad-facility-compare/fad-facility-compare.service';
import { FadFacilityListComponent } from './fad-facility-list/fad-facility-list.component';
import { FadFacilityListService } from './fad-facility-list/fad-facility-list.service';
import { FadFacilityProfileComponent } from './fad-facility-profile/fad-facility-profile.component';
import { FadFacilityProfileResolver } from './fad-facility-profile/fad-facility-profile.resolver';
import { FadFacilityProfileService } from './fad-facility-profile/fad-facility-profile.service';
import { FadFacilitySearchFilterComponent } from './fad-facility-search-filter/fad-facility-search-filter.component';
import { FadLandingPageComponent } from './fad-landing-page/fad-landing-page.component';
import { FadLandingPageService } from './fad-landing-page/fad-landing-page.service';
import { FadMedicalIndexComponent } from './fad-medical-index/fad-medical-index.component';
import { FadMedicalIndexService } from './fad-medical-index/fad-medical-index.service';
import { FadNoDocsPageComponent } from './fad-no-docs-page/fad-no-docs-page.component';
import { FadNoDocsPageService } from './fad-no-docs-page/fad-no-docs-page.service';
import { FadPastSearchQueryListComponent } from './fad-past-search-query-list/fad-past-search-query-list.component';
import { FadPastSearchQueryListService } from './fad-past-search-query-list/fad-past-search-query-list.service';
import { FadProfessionalCompareComponent } from './fad-professional-compare/fad-professional-compare.component';
import { FadProfessionalCompareService } from './fad-professional-compare/fad-professional-compare.service';
import { FadProfileCardComponent } from './fad-profile-card/fad-profile-card.component';
import { FadProviderCompareComponent } from './fad-provider-compare/fad-provider-compare.component';
import { FadProviderCompareService } from './fad-provider-compare/fad-provider-compare.service';
import { FadProviderFacilityCardComponent } from './fad-provider-facility-card/fad-provider-facility-card.component';
import { FadProviderFacilityListComponent } from './fad-provider-facility-list/fad-provider-facility-list.component';
import { FadProviderFacilityListService } from './fad-provider-facility-list/fad-provider-facility-list.service';
import { FadReviewQuestionComponent } from './fad-review/fad-review-question/fad-review-question.component';
import { FadReviewComponent } from './fad-review/fad-review.component';
import { FadReviewService } from './fad-review/fad-review.service';
import { RatingComponent } from './fad-review/rating/rating.component';
import { FadSearchFilterComponent } from './fad-search-filter/fad-search-filter.component';
import { FadSearchListComponent } from './fad-search-list/fad-search-list.component';
import { FadSearchListService } from './fad-search-list/fad-search-list.service';
import { FadSearchResultsComponent } from './fad-search-results/fad-search-results.component';
import { FadSearchResultsResolver } from './fad-search-results/fad-search-results.resolver';
import { FadSearchResultsService } from './fad-search-results/fad-search-results.service';
import { FadSpecialtySearchFilterComponent } from './fad-specialty-search-filter/fad-specialty-search-filter.component';
import { FadSuggestAnEditDialogComponent } from './fad-suggest-an-edit-dialog/fad-suggest-an-edit-dialog.component';
import { FadSuggestAnEditDialogService } from './fad-suggest-an-edit-dialog/fad-suggest-an-edit-dialog.service';
import { FadGuard } from './fad.guard';
import { FadRouter } from './fad.routing';
import { FadService } from './fad.service';
import { HelpChoosingNetworkComponent } from './modals/help-choosing-network/help-choosing-network.component';

@NgModule({
  imports: [CommonModule, FadRouter, SharedModule, InfiniteScrollModule],
  exports: [],
  declarations: [
    FadLandingPageComponent,
    FadMedicalIndexComponent,
    FadSearchResultsComponent,
    FadNoDocsPageComponent,
    FadSearchFilterComponent,
    FadSearchListComponent,
    FadDoctorProfileComponent,
    FadFacilityProfileComponent,
    FadProfileCardComponent,
    FadPastSearchQueryListComponent,
    FadProviderCompareComponent,
    FadProfessionalCompareComponent,
    FadFacilityCompareComponent,
    FadCostBreakdownComponent,
    FadDoctorRatingComponent,
    FadFacilityListComponent,
    FadFacilityCardComponent,
    FadFacilitySearchFilterComponent,
    FadSpecialtySearchFilterComponent,
    FadBreadCrumbsComponent,
    FadReviewComponent,
    FadReviewQuestionComponent,
    RatingComponent,
    FadProviderFacilityListComponent,
    FadProviderFacilityCardComponent,
    FadSuggestAnEditDialogComponent,
    HelpChoosingNetworkComponent,
  ],
  entryComponents: [FadProfileCardComponent, FadFacilityCardComponent, FadProviderFacilityCardComponent, FadSuggestAnEditDialogComponent, HelpChoosingNetworkComponent],
  providers: [
    FadService,
    FadResolver,
    FadLandingPageService,
    FadMedicalIndexService,
    FadSearchResultsService,
    FadNoDocsPageService,
    FadSearchListService,
    FadDoctorProfileService,
    FadFacilityProfileService,
    FadPastSearchQueryListService,
    FadProviderCompareService,
    FadProfessionalCompareService,
    FadFacilityCompareService,
    FadCostBreakdownService,
    FadSearchResultsResolver,
    FadDoctorProfileResolver,
    FadFacilityProfileResolver,
    FadFacilityListService,
    FadBreadCrumbsService,
    FadGuard,
    FadReviewService,
    FadProviderFacilityListService,
    FadSuggestAnEditDialogService
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class FadModule {}
