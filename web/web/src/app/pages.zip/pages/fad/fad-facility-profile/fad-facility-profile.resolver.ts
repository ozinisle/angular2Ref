import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { AuthService } from '../../../shared/shared.module';
import { FadConstants } from '../constants/fad.constants';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadFacilityProfileRequestModel } from '../modals/fad-facility-profile-details.model';
import { FadFacilityProfileRequestModelInterface, FadFacilityResponseModelInterface } from '../modals/interfaces/fad-facility-profile-details.interface';
import { FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import { FadFacilityProfileService } from './fad-facility-profile.service';

@Injectable()
export class FadFacilityProfileResolver<T> implements Resolve<Promise<FadFacilityResponseModelInterface>> {
  constructor(
    private fadSearchResultsService: FadSearchResultsService,
    private errorHandler: BcbsmaerrorHandlerService,
    private fadFacilityProfileService: FadFacilityProfileService,
    private authService: AuthService
  ) { }

  async resolve(): Promise<FadFacilityResponseModelInterface> {
    try {
      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
      const facilityProfileId = parseInt(sessionStorage.getItem('facilityProfileId'));
      const networkId =
        searchCriteria && searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
          ? searchCriteria.getPlanName().getNetworkId()
          : FadConstants.defaults.networkId;
      const geoLocation =
        searchCriteria && searchCriteria.getZipCode() && searchCriteria.getZipCode().geo
          ? searchCriteria.getZipCode().geo
          : FadConstants.defaults.geo;
      const locationId = sessionStorage.getItem('locationId');
      const procedureID = searchCriteria.getSearchText().getProcedureId();
      const facilityLocationFlag = sessionStorage.getItem('facilityLocationFlag');
      const fadDoctorProfileRequestParams: FadFacilityProfileRequestModelInterface = new FadFacilityProfileRequestModel();
      if (facilityLocationFlag == 'true') {
        fadDoctorProfileRequestParams
          .setGeoLocation(geoLocation)
          .setfacilityId(facilityProfileId)
          .setNetworkId(networkId);
      } else {
        fadDoctorProfileRequestParams
          .setGeoLocation(geoLocation)
          .setfacilityId(facilityProfileId)
          .setNetworkId(networkId)
          .setLocationId(Number(locationId));
      }

      if (procedureID && facilityLocationFlag != 'true') {
        fadDoctorProfileRequestParams.setProcedureId(procedureID);
        fadDoctorProfileRequestParams.setRadius(sessionStorage.getItem('radius') != 'null' ? Number(sessionStorage.getItem('radius')) : 25);
      }

      const authUserId = this.authService.useridin;
      if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
        fadDoctorProfileRequestParams.useridin = this.authService.useridin;
      }

      fadDoctorProfileRequestParams['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');

      return await this.fadFacilityProfileService.getFadGetprofessionalprofileDetails(fadDoctorProfileRequestParams).toPromise();
    } catch (exception) {
      this.errorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.services.FadFacilityProfileResolver,
        FadConstants.methods.resolve
      );
    }
    return null;
  }
}
