import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { StarRatingComponentInputModelInterface } from '../../../shared/components/star-rating/star-rating.interface';
import { StarRatingComponentInputModel } from '../../../shared/components/star-rating/star-rating.model';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { AlertService, AuthService } from '../../../shared/shared.module';
import { FadConstants } from '../constants/fad.constants';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { FadCostBreakdownService } from '../fad-cost-breakdown/fad-cost-breakdown.service';
import { FadSearchListService } from '../fad-search-list/fad-search-list.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadSuggestAnEditDialogComponent } from '../fad-suggest-an-edit-dialog/fad-suggest-an-edit-dialog.component';
import { FadService } from '../fad.service';
import { FadFacilityProfileRequestModel, FadFacilityResponseModel } from '../modals/fad-facility-profile-details.model';
import { FadSuggestAnEditDialog_CorrectionType, FadSuggestAnEditDialog_InputData } from '../modals/fad-suggest-an-edit-dialog.model';
import { GetSearchByProfessionalRequestModel } from '../modals/getSearchByProfessional.model';
import { FadFacilityProfileRequestModelInterface, FadFacilityResponseModelInterface, LocationListInterface } from '../modals/interfaces/fad-facility-profile-details.interface';
import { FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import { FadSuggestAnEditDialog_CorrectionTypeInterface, FadSuggestAnEditDialog_InputDataInterface } from '../modals/interfaces/fad-suggest-an-edit-dialog.interface';
import { StarRatingComponentConsumer } from '../modals/interfaces/fad.interface';
import { FadProfessionalInterface, GetSearchByProfessionalRequestModelInterface } from '../modals/interfaces/getSearchByProfessional-models.interface';
import { BreadCrumb } from '../utils/fad.utils';
import { FadFacilityProfileService } from './fad-facility-profile.service';

@Component({
  selector: 'app-fad-facility-profile',
  templateUrl: './fad-facility-profile.component.html',
  styleUrls: ['./fad-facility-profile.component.scss']
})
export class FadFacilityProfileComponent implements OnInit, OnDestroy, StarRatingComponentConsumer {
  public facilityProfile: FadProfessionalInterface; // FVProSRProfessionalInSearchEntity;
  public facilityName: string;
  public awards = new Array();

  private specialityNamesList: string[] = [];
  public isShowFacilityDetialsSection = false;
  public fadFacilityResposeData: FadFacilityResponseModelInterface;
  public startRating: StarRatingComponentInputModelInterface;
  public selectedLocationDetails: LocationListInterface;
  private selectedLocationIndex = 0;
  private hospitalQualityDefaultListLimit = 3;
  private hospitalQualityListLimit: number = this.hospitalQualityDefaultListLimit;
  public accordianToggleStatus: any = {};
  public isProcedure = false;
  public procedureTitle: string;
  public procedureID: string;
  public icon = false;
  public chapter224 = false;

  public disclaimers: any = [];
  public disclaimerToplist: any = [];
  public disclaimerBottomlist: any = [];
  public mleEligibility: string;
  showAffiliatedDoctors: boolean;
  private toolTipTxt: string;
  public tierTooltipDescription: string;
  public fasFlag = false;
  public tierTooltip = new Array();
  public fasFlagAward = false;
  public awardIndex = 0;
  public profileTooltip = new Array();
  public identifierToolTipDescription = '';
  public identifierFlag = false;
  public qmToolTipDescription = '';
  public qcFlag = false;
  public onRecordDiclaimers: any;
  public disclaimersFlag: boolean;
  public disclaimersText: string;
  public networkChanged: string;
  public disclaimerBcbsBottomCostModule: any;
  public disclaimerBcbsTopProfile: any;
  public fadFacilityProfileData: FadFacilityResponseModelInterface = null;
  private isMobileView: boolean = false;

  constructor(
    private router: Router,
    private alertService: AlertService,
    private route: ActivatedRoute,
    public authService: AuthService,
    private fadService: FadService,
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService,
    private fadBreadCrumbsService: FadBreadCrumbsService,
    private fadCostBreakdownService: FadCostBreakdownService,
    private fadSearchResultsService: FadSearchResultsService,
    private fadFacilityProfileService: FadFacilityProfileService,
    private authHttp: AuthHttp,
    private fadSearchListService: FadSearchListService,
    public dialogRef: MatDialog
  ) {}

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.isMobileView = event.target.innerWidth <= 992;
  }

  ngOnInit() {
    try {
      this.alertService.resetErrorObject();
      this.isMobileView = window.innerWidth <= 992;
      this.fadSearchListService.isFilterChanged(false);
      this.chapter224 = this.authService.getMLEIndicator() === 'lite';
      if (JSON.parse(sessionStorage.getItem('tiersLabel'))) {
        this.tierTooltip = JSON.parse(sessionStorage.getItem('tiersLabel'));
      }
      if (JSON.parse(sessionStorage.getItem('profileLabel'))) {
        this.profileTooltip = JSON.parse(sessionStorage.getItem('profileLabel'));
      }
      this.fadSearchResultsService.setContextText('');

      this.getNPToolTipDescription();

      this.fadBreadCrumbsService.addBreadCrumb(new BreadCrumb().setLabel('Facility Details').setUrl('/fad/facility-profile'));

      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();

      this.mleEligibility = this.authService.getMleEligibility();

      if (searchCriteria) {
        this.isProcedure = searchCriteria.getSearchText().isProcedure();

        this.procedureTitle = searchCriteria.getSearchText().getSimpleText();
        this.procedureID = searchCriteria.getSearchText().getProcedureId();
      }

      const resolvedData: FadFacilityResponseModelInterface =
        this.fadFacilityProfileData == null ? this.route.snapshot.data.fadFacilityResposeData : this.fadFacilityProfileData;
      if (resolvedData && resolvedData.displaymessage && resolvedData.errormessage && resolvedData.result) {
        this.isShowFacilityDetialsSection = false;
        this.alertService.setAlert(resolvedData.displaymessage, null, AlertType.Failure);
      } else {
        this.fadFacilityResposeData = new FadFacilityResponseModel();
        this.fadFacilityResposeData = resolvedData.facility;
        if (this.fadFacilityResposeData.disclaimers) {
          this.disclaimers = this.fadFacilityResposeData.disclaimers;
          this.disclaimerToplist = this.disclaimers.filter(function(disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerProfileTopList;
          });
          this.disclaimerBottomlist = this.disclaimers.filter(function(disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerProfileBottomList;
          });
          this.disclaimerBcbsBottomCostModule = this.disclaimers.filter(function(disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerBcbsBottomCostModule;
          });
          this.disclaimerBcbsTopProfile = this.disclaimers.filter(function(disclaimers) {
            return disclaimers.category === FadConstants.text.disclaimerBcbsTopProfile;
          });

          this.disclaimerToplist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
          this.disclaimerBottomlist.sort((disclaimersA, disclaimersB) => Number(disclaimersB.priority) - Number(disclaimersA.priority));
        }
        if (this.fadFacilityResposeData.onRecordDiclaimers) {
          this.onRecordDiclaimers = this.fadFacilityResposeData.onRecordDiclaimers;
          if (
            this.onRecordDiclaimers &&
            this.onRecordDiclaimers.category &&
            this.onRecordDiclaimers.category == 'on_record' &&
            this.onRecordDiclaimers.text
          ) {
            this.disclaimersFlag = true;
            this.disclaimersText = this.onRecordDiclaimers.text;
          }
        }
        this.networkChanged = sessionStorage.getItem('networkChange');
        console.log(this.networkChanged);
        const locationId = sessionStorage.getItem('locationId');
        this.loadDetailsBasedOnLocation(locationId, false);

        this.isShowFacilityDetialsSection = true;
        if (this.route.snapshot.data.fadFacilityResposeData.facility.location[0].linkedAffiliationId) {
          sessionStorage.setItem('facilityname', this.route.snapshot.data.fadFacilityResposeData.facility.facilityName);
          sessionStorage.setItem(
            'linkedAffiliationId',
            this.route.snapshot.data.fadFacilityResposeData.facility.location[0].linkedAffiliationId
          );
        }
        const vitalsSearchRequestbyProfessional: GetSearchByProfessionalRequestModelInterface = new GetSearchByProfessionalRequestModel();
        vitalsSearchRequestbyProfessional
          .setLimit(FadConstants.defaults.limit)
          .setPage(FadConstants.defaults.page)
          .setNetworkId(searchCriteria.getPlanName().getNetworkId());
        this.fadSearchResultsService.getFadProfileSearchResults(vitalsSearchRequestbyProfessional, false).subscribe(data => {
          setTimeout(() => {
            if (data) {
              if (data.totalCount > 0) {
                this.showAffiliatedDoctors = true;
              } else {
                this.showAffiliatedDoctors = false;
              }
            }
          }, 500);
        });

        if (!this.isMobileView) {
          this.accordianToggleStatus.location = true;
        }
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadFacilityProfileComponent,
        FadConstants.methods.ngOnInit
      );
    }
  }

  public openSuggestAnEditDialog() {
    try {
      this.alertService.resetErrorObject();
      const feedBackValues: FadSuggestAnEditDialog_CorrectionTypeInterface = new FadSuggestAnEditDialog_CorrectionType();
      feedBackValues.correctionType = this.fadFacilityResposeData.feedbackValues.correctionType;

      const suggestAnEditDialogInput: FadSuggestAnEditDialog_InputDataInterface = new FadSuggestAnEditDialog_InputData();
      suggestAnEditDialogInput.feedBackValues = feedBackValues;
      suggestAnEditDialogInput.suggestingEditFor = this.fadFacilityResposeData.facilityName;
      suggestAnEditDialogInput.providerIdentifier = this.selectedLocationDetails.identifiers;
      suggestAnEditDialogInput.providerAddress = this.selectedLocationDetails.address;
      suggestAnEditDialogInput.providerPhone = this.selectedLocationDetails.phone.toString();

      let dialogRef: MatDialogRef<FadSuggestAnEditDialogComponent, any> = this.dialogRef.open(FadSuggestAnEditDialogComponent, {
        // height: this.isMobileView?'590px':'550px',
        // width: '600px',
        data: suggestAnEditDialogInput
      });

      dialogRef.afterClosed().subscribe(result => {
        //console.log(result);
        if (result) {
          window.scrollTo(0, 0);
          if (result.result === 0) {
            this.alertService.setAlert('Success', '', AlertType.Success);
          } else {
            this.alertService.setAlert('Error', '', AlertType.Failure);
          }
        }
      });
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadDoctorProfileComponent,
        FadConstants.methods.openSuggestAnEditDialog
      );
    }
  }

  getNPToolTipDescription() {
    if (this.profileTooltip) {
      this.profileTooltip.forEach(tooltip => {
        if (tooltip.toolTip.code === 'PPIN') {
          this.identifierToolTipDescription = tooltip.toolTip.description;
        } else if (tooltip.toolTip.code === 'PCQM') {
          this.qmToolTipDescription = tooltip.toolTip.description;
        }
      });
    }

  }
  getToolTipText(toolTip, awardname) {
    this.toolTipTxt = '';

    return this.toolTipTxt;
  }
  ngOnDestroy() {
    this.alertService.clearError();
  }

  loadDetailsBasedOnLocation(locationsId, change: boolean) {
    this.awards = [];
    this.selectedLocationIndex = locationsId;
    sessionStorage.setItem('locationId', locationsId);
    sessionStorage.setItem('locationIdAffl', locationsId);
    if (change) {
      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
      // tslint:disable-next-line:radix
      const facilityProfileId = parseInt(sessionStorage.getItem('facilityProfileId'));
      const networkId =
        searchCriteria && searchCriteria.getPlanName() && searchCriteria.getPlanName().getNetworkId()
          ? searchCriteria.getPlanName().getNetworkId()
          : FadConstants.defaults.networkId;
      const geoLocation =
        searchCriteria && searchCriteria.getZipCode() && searchCriteria.getZipCode().geo
          ? searchCriteria.getZipCode().geo
          : FadConstants.defaults.geo;
      const locationId = sessionStorage.getItem('locationId');
      const procedureID = searchCriteria.getSearchText().getProcedureId();
      const facilityLocationFlag = sessionStorage.getItem('facilityLocationFlag');

      const fadDoctorProfileRequestParams: FadFacilityProfileRequestModelInterface = new FadFacilityProfileRequestModel();
      if (facilityLocationFlag == 'true') {
        fadDoctorProfileRequestParams
          .setGeoLocation(geoLocation)
          .setfacilityId(facilityProfileId)
          .setNetworkId(networkId);
      } else {
        fadDoctorProfileRequestParams
          .setGeoLocation(geoLocation)
          .setfacilityId(facilityProfileId)
          .setNetworkId(networkId)
          .setLocationId(Number(locationId));
      }

      if (procedureID && facilityLocationFlag != 'true') {
        fadDoctorProfileRequestParams.setProcedureId(procedureID);
        fadDoctorProfileRequestParams.setRadius(sessionStorage.getItem('radius') != 'null' ? Number(sessionStorage.getItem('radius')) : 25);
      }

      const authUserId = this.authService.useridin;
      if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
        fadDoctorProfileRequestParams.useridin = this.authService.useridin;
      }
      const mleIndicator = this.authService.getMleEligibility();
      if (sessionStorage.getItem('fadVendorMemberNumber') && (mleIndicator === 'Y' || mleIndicator === 'lite')) {
        fadDoctorProfileRequestParams['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
      }

      this.authHttp.showSpinnerLoading();
      this.fadFacilityProfileService.getFadGetprofessionalprofileDetails(fadDoctorProfileRequestParams).subscribe(data => {
        console.log(data);
        this.fadFacilityProfileData = data;
        this.ngOnInit();
        this.authHttp.hideSpinnerLoading();
      });
    }

    const facilityLocationFlag = sessionStorage.getItem('facilityLocationFlag');
    if (facilityLocationFlag == 'true' && this.fadFacilityResposeData && this.fadFacilityResposeData.location.length) {
      this.selectedLocationDetails = this.fadFacilityResposeData.location[0];
      console.log(this.selectedLocationDetails);
      sessionStorage.setItem('facilityLocationFlag', 'false');
    } else {
      this.selectedLocationDetails = this.fadFacilityResposeData.location.find(p => p.locationId.toString() == locationsId);
    }
    console.log(this.selectedLocationDetails);

    if (this.selectedLocationDetails.quality.length) {
      const quality = this.selectedLocationDetails.quality;
      quality.sort((a, b) => b.score - a.score);

      this.selectedLocationDetails.quality = quality;
    }
    if (this.selectedLocationDetails.awards) {
      this.selectedLocationDetails.awards.forEach(award => {
        this.awards.push(award);
      });
    }
    if (this.selectedLocationDetails && this.selectedLocationDetails.tiers && this.selectedLocationDetails.tiers.description) {
      this.getToolTipDescription(this.tierTooltip, this.selectedLocationDetails.tiers.description);
    }
    this.accordianToggleStatus = {};
  }

  getToolTipDescription(toolTip, tier) {
    this.tierTooltipDescription = '';
    if (toolTip) {
      toolTip.forEach(toolTips => {
        if (toolTips.toolTip.code && toolTips.toolTip.code.toLowerCase() === tier.toLowerCase()) {
          this.tierTooltipDescription = toolTips.toolTip.description;
        }
      });
    }
    return this.tierTooltipDescription;
  }
  fasIcon() {
    this.fasFlag = !this.fasFlag;
  }
  qcIcon() {
    this.qcFlag = !this.qcFlag;
  }
  identifierIcon() {
    this.identifierFlag = !this.identifierFlag;
  }

  fasIconAward(index) {
    this.fasFlagAward = !this.fasFlagAward;
    this.awardIndex = index;
  }

  getRating(reviews) {
    this.startRating = new StarRatingComponentInputModel();
    if (Object.keys(reviews).length === 0) {
      this.startRating.totalRatings = 0;
      this.startRating.overAllRating = 0;
    } else {
      this.startRating.totalRatings = reviews.totalRatings;
      this.startRating.overAllRating = parseFloat(reviews.overallRating);
    }
    return this.startRating;
  }

  getQualityRating(quality) {
    this.startRating = new StarRatingComponentInputModel();
    this.startRating.totalRatings = quality.score;
    this.startRating.numberOfStars = 3;
    this.startRating.overAllRating = parseFloat(quality.score);
    return this.startRating;
  }

  public copyIdentifierValue(event, inputId: string): void {
    const element: any = document.querySelector('#' + inputId);
    element.select();
    document.execCommand('copy');
    element.setSelectionRange(0, 0);
  }

  toggleAccordion(listItem, status) {
    this.accordianToggleStatus[listItem] = status;
  }

  hospitalQualityListLimitToggle() {
    this.hospitalQualityListLimit =
      this.hospitalQualityListLimit === this.hospitalQualityDefaultListLimit
        ? this.selectedLocationDetails.quality.length
        : this.hospitalQualityDefaultListLimit;
  }

  public getDirections(location, event): void {
    const locationURL = 'http://maps.google.com/?q=' + encodeURI(location);
    window.open(locationURL, '_self');
  }

  public openFacility(event): void {
    try {
      setTimeout(() => {
        this.router.navigate(['/fad/facility-profile']);
      }, 1);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadFacilityProfileComponent,
        FadConstants.methods.openProfile
      );
    }
  }

  public reviewBenefits(): void {
    this.fadService.reviewMyBenfits();
  }

  public doAuthentication() {
    throw new Error('yet to be coded');
  }

  public showCostBreakdown(providerName, facilityCost, costBenefit) {
    this.fadCostBreakdownService.costBenefitsData = costBenefit;
    this.fadCostBreakdownService.facilityCostData = facilityCost;
    this.fadCostBreakdownService.providerName = providerName;
    this.fadCostBreakdownService.parentPage = FadConstants.text.facilityPage;
    this.router.navigate(['/fad/cost-breakdown']);
  }

  public learnMoreAboutQuality() {
    window.open('https://www.bluecrossma.org/disclaimer/member-rights-and-responsibilities/quality-improvement', '_blank');
  }

  public searchAffiliatedDoctors() {
    const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
    sessionStorage.setItem('facilityname', this.route.snapshot.data.fadFacilityResposeData.facility.facilityName);
    sessionStorage.setItem('affiliatedDoctorSearchProviderId', this.route.snapshot.data.fadFacilityResposeData.facility.providerId);
    sessionStorage.setItem('linkedAffiliationId', this.route.snapshot.data.fadFacilityResposeData.facility.location[0].linkedAffiliationId);

    this.fadSearchResultsService.setAffiliatedLinkedId(sessionStorage.getItem('linkedAffiliationId'));
    this.fadSearchResultsService.setAffiliatedLocationId(sessionStorage.getItem('locationId'));
    this.fadSearchResultsService.setAffiliatedFacilityId(sessionStorage.getItem('facilityProfileId'));
    if (searchCriteria) {
      this.fadSearchResultsService.setSearchCriteria(searchCriteria);
      this.fadSearchResultsService.setContextText('affiliated');
      this.router.navigate([FadConstants.urls.fadAffiliatedDoctorsSearch]);
    }
  }

  // Methods to convert Transaction amount into decimal values
  public convertAmountToBaseValue(value) {
    return Math.trunc(value);
  }

  public convertAmountToDecimalValue(value) {
    const int_part = Math.trunc(value);
    const float_part = Number((value - int_part).toFixed(2));
    const decimal: string[] = float_part.toString().split('.');
    if (!decimal[1]) {
      const zero = '00';
      return zero;
    }
    return decimal[1];
  }
  additionalCostExpantion() {
    this.icon = !this.icon;
  }

  public requestWrittenEstimte() {
    this.fadService.requestWrittenEstimate();
  }

  public impersonation() {
    return this.authService.impersonation();
  }
}
