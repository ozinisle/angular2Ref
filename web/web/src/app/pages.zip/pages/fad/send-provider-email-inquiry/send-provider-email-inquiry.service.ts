import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { GeneralErrorInterface } from '../../../shared/models/interfaces/generic-app-models.interface';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { FadConstants } from '../constants/fad.constants';
import { SendProviderInquiryDialog_InputDataInterface } from '../modals/interfaces/send-provider-inquiry-dialogs.interface';


@Injectable()
export class SendProviderEmailInquiryService {

  constructor(private authHttp: AuthHttp) { }

  submitSendProviderEmailInquiry(request: SendProviderInquiryDialog_InputDataInterface): Observable<GeneralErrorInterface> {
    // adhoc fix for KLO-1722
    // fix is to call encryptFadPost instead of encryptPost
    return this.authHttp.encryptFadPost(FadConstants.urls.sendProviderInquiryUrl, request, '', '', false).map(response => {
      return response;
    })
  }

}
