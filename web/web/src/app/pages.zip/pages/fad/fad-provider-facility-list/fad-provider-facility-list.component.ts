import {
  ApplicationRef,
  ChangeDetectorRef,
  Component,
  ComponentFactoryResolver,
  ElementRef,
  EventEmitter,
  HostListener,
  Injector,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild
} from "@angular/core";
import { Router } from "@angular/router";
import * as leafLet from "leaflet";
import { Subscription } from "rxjs/Subscription";
import { BcbsmaConstants } from "../../../shared/constants/bcbsma.constants";
import { BcbsmaerrorHandlerService } from "../../../shared/services/bcbsmaerror-handler.service";
import { AuthService } from "../../../shared/shared.module";
import { FadConstants } from "../constants/fad.constants";
import { FadFacilityProfileService } from "../fad-facility-profile/fad-facility-profile.service";
import { FadLandingPageService } from "../fad-landing-page/fad-landing-page.service";
import { FadProviderCompareService } from "../fad-provider-compare/fad-provider-compare.service";
import { FadSearchResultsService } from "../fad-search-results/fad-search-results.service";
import { FadFacilityProfileRequestModel } from "../modals/fad-facility-profile-details.model";
import { FadNoDocsPageInputDataModel } from "../modals/fad-no-docs-page.modal";
import { FadProviderProfileCardComponentInputModel } from "../modals/fad-profile-card.modal";
import { FadFacilityListComponentOutputModel } from "../modals/fad-search-list.modal";
import { FZCSRCity } from "../modals/fad-vitals-collection.model";
import { FadFacilityProfileRequestModelInterface } from "../modals/interfaces/fad-facility-profile-details.interface";
import { FadLandingPageSearchControlValuesInterface } from "../modals/interfaces/fad-landing-page.interface";
import { FadNoDocsPageInputDataModelInterface } from "../modals/interfaces/fad-no-docs-page.interface";
import { FadProviderCardComponentOutputModelInterface } from "../modals/interfaces/fad-profile-card.interface";
import {
  ClearSearchResultFlagInterface,
  FadFacilityListComponentOutputModelInterface,
  FadSearchListComponentOutputModelInterface,
  FadSpecialtyListComponentInputModelInterface
} from "../modals/interfaces/fad-search-list.interface";
import { FadZipCodeSearchResponseModelInterface } from "../modals/interfaces/fad-vitals-collection.interface";
import {
  FadNoSearchResultsPageConsumer,
  FadProviderCardConsumer
} from "../modals/interfaces/fad.interface";
import {
  FadSpecialtyInterface,
  GetSearchBySpecialtyResponseModelInterface
} from "../modals/interfaces/getSearchBySpeciality-models.interface";
import { FadResouceTypeCodeConfig } from "../modals/types/fad.types";
import { ClearSearchResultFlagModel } from "./../modals/fad-search-list.modal";
import { FadProviderFacilityListService } from "./fad-provider-facility-list.service";

@Component({
  selector: "app-provider-fad-facility-list",
  templateUrl: "./fad-provider-facility-list.component.html",
  styleUrls: ["./fad-provider-facility-list.component.scss"]
})
export class FadProviderFacilityListComponent
  implements
    OnInit,
    OnChanges,
    FadNoSearchResultsPageConsumer,
    FadProviderCardConsumer {
  @Output("componentOutput") componentOutput: EventEmitter<
    FadFacilityListComponentOutputModelInterface
  > = new EventEmitter<FadFacilityListComponentOutputModel>();

  @Input("componentInput")
  componentInput: FadSpecialtyListComponentInputModelInterface;

  @ViewChild("profileCardList") profileCardList: ElementRef;

  public searchText: string = "";

  public filterCategories: string[] = [];

  public isDisplayBanner: boolean = false;

  // No search results page consumption requirement
  public noSearchResultsPageData: FadNoDocsPageInputDataModelInterface = new FadNoDocsPageInputDataModel();
  public isNoSearchResults = false;
  // End: No search results page consumption requirement

  public filteredSearchResponse: GetSearchBySpecialtyResponseModelInterface;
  public searchResponse: GetSearchBySpecialtyResponseModelInterface;
  public facilityList: FadSpecialtyInterface[] = null;
  public selectedProfessionals: FadSpecialtyInterface[] = [];

  private mapInstance: leafLet.Map;
  private cachedAllZipCodeInfo: FadZipCodeSearchResponseModelInterface;
  public idValues: number[];
  public list: number[] = [];
  private maxSelectionAllowed = 5;
  public comparefacilityData = [];
  public isTelehealthInd_Res: boolean = false;
  public isMedicareUser: boolean = false;
  hpnZeroResults: boolean = false;
  displayCampaignTelehealth: boolean = true;

  disableSelection = false;

  constructor(
    private router: Router,
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService,
    private fadSearchListService: FadProviderFacilityListService,
    private fadFacilityProfileService: FadFacilityProfileService,
    public authService: AuthService,
    private fadSearchResultsService: FadSearchResultsService,
    private landingPageService: FadLandingPageService,
    public FadProviderCompareService: FadProviderCompareService,
    private cdRef: ChangeDetectorRef,
    private el: ElementRef
  ) {
    this.noSearchResultsPageData.type = FadResouceTypeCodeConfig.speciality;
  }

  // Show banner section on window scroll to clear and delete message listing
  @HostListener("window:scroll", ["$event"])
  showBannerOnWindowScroll($event) {
    const fadSearchListPos = this.el.nativeElement.offsetTop,
      windowScrollPos = window.pageYOffset;

    if (windowScrollPos > fadSearchListPos) {
      this.isDisplayBanner = true;
    } else {
      this.isDisplayBanner = false;
    }
  }
  ngOnInit() {
    this.cachedAllZipCodeInfo = this.landingPageService.vitalsZipCodeInfo;
    if (
      this.authService.authToken &&
      this.authService.authToken.userType != null &&
      (this.authService.authToken.userType.toLowerCase() === "medicare" ||
        this.authService.authToken.userType.toLowerCase() === "medex")
    ) {
      this.isMedicareUser = true;
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    try {
      if (this.fadSearchResultsService.getSearchCriteria()) {
        this.searchText = this.fadSearchResultsService
          .getSearchCriteria()
          .getSearchText()
          .getSimpleText()
          ? this.fadSearchResultsService
              .getSearchCriteria()
              .getSearchText()
              .getSimpleText()
          : this.fadSearchResultsService
              .getSearchCriteria()
              .getSearchText()
              .getContextText();
        this.searchText = this.searchText
          .replace(FadConstants.text.allDoctorOptionText, "")
          .replace(/["']/g, "");
        this.searchText = this.searchText
          .replace(FadConstants.text.allHospitalsOrFacilitiesText, "")
          .replace(/["']/g, "");
        if (
          this.noSearchResultsPageData &&
          this.noSearchResultsPageData.type &&
          this.noSearchResultsPageData.type ===
            FadResouceTypeCodeConfig.professional
        ) {
          this.filterCategories = this.fadSearchResultsService.getFilterCategories();
        } else if (
          this.noSearchResultsPageData &&
          this.noSearchResultsPageData.type &&
          this.noSearchResultsPageData.type ===
            FadResouceTypeCodeConfig.facility
        ) {
          this.filterCategories = this.fadSearchResultsService.getFacilityFilterCategories();
        } else {
          this.filterCategories = this.fadSearchResultsService.getSpecialtyFilterCategories();
        }
      }
      this.componentInput = changes.componentInput.currentValue;

      if (this.componentInput) {
        this.searchResponse = this.componentInput.specialtyResults;
        this.hpnZeroResults = this.searchResponse.hpnZeroResults;

        if (this.searchResponse) {
          this.setTHIndicatorFlag(this.searchResponse);
          if (this.fadSearchListService.isFilterChangedFlag == true) {
            this.clearProfileSelections();
          }

          this.facilityList = this.searchResponse.providers;
          if (this.facilityList) {
            this.selectedProfessionals = this.searchResponse.providers.filter(
              facility => {
                return facility.isChecked;
              }
            );
          }
          const disableFurtherSelection =
            this.selectedProfessionals &&
            this.selectedProfessionals.length >= this.maxSelectionAllowed
              ? true
              : false;
          this.facilityList = this.facilityList.map(item => {
            item.isDisabled = item.isChecked ? false : disableFurtherSelection;
            return item;
          });
          this.isNoSearchResults = false;
        } else {
          this.isNoSearchResults = true;
        }

        this.cdRef.detectChanges();
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadSearchListComponent,
        FadConstants.methods.ngOnChanges
      );
    }
  }
  setTHIndicatorFlag(data: any) {
    let memberTHDetails = this.landingPageService.getVitalsTeleHealthDetails();
    let memberHasTHBenefit =
      memberTHDetails && memberTHDetails.teleHealthEligible ? true : false;
    if (data && data.telehealthInd) {
      if (memberHasTHBenefit) {
        this.isTelehealthInd_Res = true;
        //No need to reset the request
        //this.isTelehealthInd_Req = false;
      } else {
        this.isTelehealthInd_Res = false;
      }
    }
  }

  // FadProfileCardConsumer consumption requirement
  public getProfileCardInput(
    facility: FadSpecialtyInterface
  ): FadProviderProfileCardComponentInputModel {
    return new FadProviderProfileCardComponentInputModel(facility);
  }

  public onProfileCardComponentInteraction(
    facilityCardCompOutput: FadProviderCardComponentOutputModelInterface
  ) {
    const selectedItem = this.facilityList.find(
      item => item.providerId === facilityCardCompOutput.provider.providerId
    );
    selectedItem.isChecked = facilityCardCompOutput.isSelected;
    this.selectedProfessionals = this.facilityList.filter(
      item => item.isChecked
    );

    const fadSeachListComponentOutput: FadSearchListComponentOutputModelInterface = {
      selectedProfessionals: this.selectedProfessionals
    };
    const disableFurtherSelection =
      this.selectedProfessionals &&
      this.selectedProfessionals.length >= this.maxSelectionAllowed
        ? true
        : false;
    this.facilityList = this.facilityList.map(item => {
      item.isDisabled = item.isChecked ? false : disableFurtherSelection;
      return item;
    });

    this.FadProviderCompareService.setSearchResult(this.selectedProfessionals);

    this.componentOutput.emit(fadSeachListComponentOutput);
  }

  // end: FadProfileCardConsumer consumption requirement

  public compareSelectedProfiles() {
    this.fadSearchListService.setSelectedId(this.list);
    this.router.navigate([FadConstants.urls.fadCompareTablePage]);
  }

  public clearProfileSelections() {
    this.selectedProfessionals = [];
    if (this.profileCardList != undefined) {
      const checkBoxList: NodeListOf<Element> = this.profileCardList.nativeElement.querySelectorAll(
        '[type="checkbox"]'
      );
      Array.from(checkBoxList).forEach(checkBox => {
        const chkBox = checkBox as HTMLInputElement;
        chkBox.removeAttribute("checked");
        chkBox.checked = false;
      });
    }
  }

  public onTabSelectionChange(selectedIndex) {
    let selectedLatitude: number;
    let selectedLongitude: number;

    try {
      if (selectedIndex === 0) {
        this.bcbsmaErrorHandler.devLog("List tab selected");
      } else if (selectedIndex === 1) {
        this.bcbsmaErrorHandler.devLog("Map tab selected");
        if (!this.fadSearchResultsService.getSearchCriteria()) {
          if (this.mapInstance && this.mapInstance.remove) {
            this.mapInstance.off();
            this.mapInstance.remove();
          }
          return;
        }

        const zipCodeInSearch: FZCSRCity = this.fadSearchResultsService
          .getSearchCriteria()
          .getZipCode();
        let targetIndex = -1;
        this.cachedAllZipCodeInfo.cities.some((city, index) => {
          if (zipCodeInSearch && zipCodeInSearch.zip.indexOf(city.zip) >= 0) {
            targetIndex = index;
            return true;
          }
        });

        if (targetIndex < 0) {
          const fadLastSelectedCityZip = JSON.parse(
            localStorage.getItem("fadLastSelectedCityZip")
          ) as FZCSRCity;
          if (
            fadLastSelectedCityZip &&
            zipCodeInSearch.zip === fadLastSelectedCityZip.zip
          ) {
            selectedLatitude = Number(fadLastSelectedCityZip.lat);
            selectedLongitude = Number(fadLastSelectedCityZip.lng);
          } else {
            throw new Error("Invalid zipcode");
          }
        } else {
          selectedLatitude = Number(
            this.cachedAllZipCodeInfo.cities[targetIndex].lat
          );
          selectedLongitude = Number(
            this.cachedAllZipCodeInfo.cities[targetIndex].lng
          );
        }

        const onMapCreatedEventWatcher: Subscription = this.fadSearchListService
          .onMapContainerCreated()
          .subscribe(data => {
            this.createInteractiveMap(
              FadConstants.elementRef.fadSearchListMapContent,
              [selectedLatitude, selectedLongitude],
              13
            );
            onMapCreatedEventWatcher.unsubscribe();
          });
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadSearchListComponent,
        FadConstants.methods.onTabSelectionChange
      );
    }
  }

  private createInteractiveMap(
    mapContainerId: string,
    coords: leafLet.LatLngExpression,
    zoomLevel: number
  ) {
    try {
      if (this.mapInstance && this.mapInstance.remove) {
        this.mapInstance.off();
        this.mapInstance.remove();
      }
      this.mapInstance = leafLet.map(mapContainerId).setView(coords, zoomLevel);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadSearchListComponent,
        FadConstants.methods.createInteractiveMap
      );
    }
  }

  getFacilityData(facilityoutput) {
    try {
      if (this.comparefacilityData.length > this.selectedProfessionals.length) {
        this.comparefacilityData = [];
      }

      const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
      const facilityProfileId = parseInt(
        facilityoutput.provider.providerId.toString()
      );
      const networkId =
        searchCriteria &&
        searchCriteria.getPlanName() &&
        searchCriteria.getPlanName().getNetworkId()
          ? searchCriteria.getPlanName().getNetworkId()
          : FadConstants.defaults.networkId;
      const geoLocation =
        searchCriteria &&
        searchCriteria.getZipCode() &&
        searchCriteria.getZipCode().geo
          ? searchCriteria.getZipCode().geo
          : FadConstants.defaults.geo;
      const locationId = facilityoutput.provider.locations[0].id;
      const procedureID = searchCriteria.getSearchText().getProcedureId();

      const fadDoctorProfileRequestParams: FadFacilityProfileRequestModelInterface = new FadFacilityProfileRequestModel();
      fadDoctorProfileRequestParams
        .setGeoLocation(geoLocation)
        .setfacilityId(facilityProfileId)
        .setNetworkId(networkId)
        .setLocationId(Number(locationId));

      if (procedureID) {
        fadDoctorProfileRequestParams.setProcedureId(procedureID);
        fadDoctorProfileRequestParams.setRadius(FadConstants.defaults.radius);
      }

      const authUserId = this.authService.useridin;
      if (
        authUserId &&
        authUserId !== "undefined" &&
        authUserId !== "null" &&
        authUserId !== null
      ) {
        fadDoctorProfileRequestParams.useridin = this.authService.useridin;
      }
      const mleIndicator = this.authService.getMleEligibility();
      if (
        sessionStorage.getItem("fadVendorMemberNumber") &&
        (mleIndicator === "Y" || mleIndicator === "lite")
      ) {
        fadDoctorProfileRequestParams[
          "fadVendorMemberNumber"
        ] = sessionStorage.getItem("fadVendorMemberNumber");
      }
      this.fadFacilityProfileService
        .getFadGetprofessionalprofileDetails(fadDoctorProfileRequestParams)
        .subscribe(data => {
          if (
            data.facility.location[0].facilityId ==
              facilityoutput.provider.providerId &&
            facilityoutput.isSelected
          ) {
            this.comparefacilityData.push(data.facility);
          } else {
            if (
              this.comparefacilityData.length >= 1 &&
              !facilityoutput.isSelected
            ) {
              for (let i = 0; i < this.comparefacilityData.length - 1; i++) {
                if (
                  this.comparefacilityData[i].location[0].providerId ==
                  facilityoutput.provider.providerId
                )
                  this.comparefacilityData.splice(i, 1);
              }
            }
          }

          this.FadProviderCompareService.setSearchResult(
            this.comparefacilityData
          );
        });
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadSearchResultsComponent,
        FadConstants.methods.onSearchListComponentInteraction
      );
    }
  }

  public clearFilter() {
    const searchResultFlagObj: ClearSearchResultFlagInterface = new ClearSearchResultFlagModel();
    searchResultFlagObj.clearFlag = true;
    searchResultFlagObj.type =
      this.noSearchResultsPageData && this.noSearchResultsPageData.type != ""
        ? this.noSearchResultsPageData.type
        : null;
    this.fadSearchResultsService.clearFilterFlagSubject.next(
      searchResultFlagObj
    );
  }
  public hideshowtelehealthBanner(event) {
    this.displayCampaignTelehealth = event;
    console.log("telehealth flag", event);
  }
}
