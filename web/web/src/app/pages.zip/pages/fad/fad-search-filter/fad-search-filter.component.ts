import { ChangeDetectorRef, Component, ElementRef, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { MatRadioChange, MatSidenav } from '@angular/material';
import { Subscription } from 'rxjs';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { GlobalService } from '../../../shared/services/global.service';
import { FadConstants } from '../constants/fad.constants';
import { FadSearchListService } from '../fad-search-list/fad-search-list.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadSpecialtyFilterComponentOutputModel, FilterRadioItem } from '../modals/fad-search-filter.modal';
import { FadSearchListComponentInputModel } from '../modals/fad-search-list.modal';
import { FiltersMetadata, SortMetadata } from '../modals/getSearchByProfessional.model';
import { FadAutoCompleteComplexOptionInterface, FadLandingPageSearchControlValuesInterface } from '../modals/interfaces/fad-landing-page.interface';
import { FadSearchFilterComponentOutputModelInterface, FilterCheckboxItemInterface, FilterListItemInterface, FilterRadioItemInterface, GrpHospitalAffiliationFilterListItemInterface } from '../modals/interfaces/fad-search-filter.interface';
import { FadSearchListComponentInputModelInterface } from '../modals/interfaces/fad-search-list.interface';
import { FacetsListInterface, FiltersMetadataInterface, GetSearchByProfessionalResponseModelInterface, SortMetadataInterface } from '../modals/interfaces/getSearchByProfessional-models.interface';
import { FadResouceTypeCodeConfig } from '../modals/types/fad.types';

@Component({
  selector: 'app-fad-search-filter',
  templateUrl: './fad-search-filter.component.html',
  styleUrls: ['./fad-search-filter.component.scss']
})
export class FadSearchFilterComponent implements OnInit, OnChanges, OnDestroy {
  @Output('componentOutput') componentOutput = new EventEmitter<FadSearchFilterComponentOutputModelInterface>();
  @ViewChild('sideNavContainer') elementView: ElementRef;
  @ViewChild('filterWidth') filterElementView: ElementRef;
  @ViewChild('searchInput') searchInput;
  @ViewChild('sidenav') sideNav: MatSidenav;

  // being used both the html view and the component(this file)
  public isDisplayFilter = false;
  public fadConstants;
  public outputTransaction: FadSearchFilterComponentOutputModelInterface = new FadSpecialtyFilterComponentOutputModel();

  // flag values used bound to the view alone (html tags)
  public collapsedSortHeight: string;
  public expandedSortHeight: string;
  public sortSelectedFilter: string;
  public collapsedHeight: string;
  public expandedHeight: string;

  @Input('componentFilterInput') componentFilterInput: FadSearchListComponentInputModelInterface = new FadSearchListComponentInputModel();
  public searchResponse: GetSearchByProfessionalResponseModelInterface;
  public facetsList: FacetsListInterface;
  public locationGeoList: FilterListItemInterface[] = [];
  public languagesList: FilterListItemInterface[] = [];
  public genderList: FilterListItemInterface[] = [];
  public ratingList: FilterListItemInterface[] = [];
  public agesTreatedList: FilterListItemInterface[] = [];
  public areasOfExpertiseList: FilterListItemInterface[] = [];
  public specialtyList: FilterListItemInterface[] = [];
  public disordersTreatedList: FilterListItemInterface[] = [];
  public treatmentMethodsList: FilterListItemInterface[] = [];
  public groupAffiliationList: GrpHospitalAffiliationFilterListItemInterface[] = [];
  public hospitalAffiliationList: GrpHospitalAffiliationFilterListItemInterface[] = [];
  public acceptingNewPatientsCheckbox: FilterCheckboxItemInterface;
  public teleHealthCheckbox: FilterCheckboxItemInterface;
  public techSavvyCheckbox: FilterCheckboxItemInterface;
  public inNetworkOnlyCheckbox: FilterCheckboxItemInterface;
  public primaryCareProviderCheckbox: FilterCheckboxItemInterface;
  public providerType: FilterListItemInterface[] = [];
  public isChoicePcpCheckbox: FilterCheckboxItemInterface;
  public tiersList: FilterListItemInterface[] = [];
  public awardTypeCodesList: FilterListItemInterface[] = [];
  public bcdTypeCodesList: FilterListItemInterface[] = [];

  public filterMetaData: FiltersMetadataInterface = new FiltersMetadata();
  public sortMetaData: SortMetadataInterface = new SortMetadata();
  public enableClearfilterFlag = false;
  public clearFilterFlagSubjectSubscription: Subscription;

  public sortCurrentValue: string;
  public isSortExpanded: boolean;
  public sortList: FilterRadioItem[] = [
    {
      name: 'Distance',
      value: 'distance+asc',
      checked: true
    },
    {
      name: 'Last Name A-Z',
      value: 'provider_name_sortable+asc',
      checked: false
    },
    {
      name: 'Last Name Z-A',
      value: 'provider_name_sortable+desc',
      checked: false
    },
    {
      name: 'Best Match',
      value: 'relevancy+desc',
      checked: false
    },
    {
      name: 'Quality',
      value: 'clinical_quality+desc',
      checked: false
    }
  ];
  public checkboxFilterFlag = false;

  constructor(
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService,
    public globalService: GlobalService,
    private cdRef: ChangeDetectorRef,
    private fadSearchResultsService: FadSearchResultsService,
    private fadSearchListService: FadSearchListService
  ) {
    this.fadConstants = FadConstants;
    this.collapsedHeight = '32px';
    this.collapsedSortHeight = '56px';
    this.expandedHeight = '40px';
    this.expandedSortHeight = '48px';
    this.isSortExpanded = false;
    this.sortSelectedFilter = 'Distance';

    this.pushSortData();
  }

  ngOnInit() {
    this.clearFilterFlagSubjectSubscription = this.fadSearchResultsService.clearFilterFlagSubject$.subscribe(message => {
      if (message && message.clearFlag == true && message.type == FadResouceTypeCodeConfig.professional) {
        this.clearFilter();
      }
    });
    this.fadSearchListService.isFilterChanged(false);
  }

  ngOnChanges(changes: SimpleChanges) {
    try {
      if (changes) {
        this.componentFilterInput = changes.componentFilterInput.currentValue;
        if (this.componentFilterInput) {
          this.searchResponse = this.componentFilterInput.searchResults;
          if (this.searchResponse && this.searchResponse.facets) {
            this.facetsList = this.searchResponse.facets;
            this.manageFilter(this.facetsList);
          }

          if (this.searchResponse && this.searchResponse.sort) {
            this.sortCurrentValue = this.searchResponse.sort;
            this.manageSorting();
          }
          this.cdRef.detectChanges();
        }
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadSearchFilterComponent,
        FadConstants.methods.ngOnChanges
      );
    }
  }

  ngOnDestroy(): void {
    this.clearFilterFlagSubjectSubscription.unsubscribe();
  }

  public manageSorting() {
    this.sortList = this.sortList.map(sortObj => {
      if (this.sortCurrentValue && sortObj.value == this.sortCurrentValue) {
        sortObj.checked = true;
        this.sortSelectedFilter = sortObj.name;
      } else {
        sortObj.checked = false;
      }
      return sortObj;
    });
  }

  public manageFilter(facetsList: FacetsListInterface) {
    this.locationGeoList = facetsList.locationGeo ? facetsList.locationGeo : [];
    this.genderList = facetsList.professionalGender ? facetsList.professionalGender : [];
    this.languagesList = facetsList.professionalLanguages ? facetsList.professionalLanguages : [];
    this.ratingList = facetsList.overallRating ? facetsList.overallRating : [];
    this.agesTreatedList = facetsList.treatedTypeCodes ? facetsList.treatedTypeCodes : [];
    this.areasOfExpertiseList = facetsList.expertiseTypeCodes ? facetsList.expertiseTypeCodes : [];
    this.specialtyList = facetsList.fieldSpecialtyIds ? facetsList.fieldSpecialtyIds : [];
    this.disordersTreatedList = facetsList.disordersTreatedTypeCodes ? facetsList.disordersTreatedTypeCodes : [];
    this.treatmentMethodsList = facetsList.treatmentMethodsTypeCodes ? facetsList.treatmentMethodsTypeCodes : [];
    this.groupAffiliationList = facetsList.groupAffiliationIds ? facetsList.groupAffiliationIds : [];
    this.hospitalAffiliationList = facetsList.hospitalAffiliationIds ? facetsList.hospitalAffiliationIds : [];
    this.acceptingNewPatientsCheckbox = facetsList.acceptingNewPatients ? facetsList.acceptingNewPatients : null;
    this.teleHealthCheckbox = facetsList.teleHealth ? facetsList.teleHealth : null;
    this.techSavvyCheckbox = facetsList.techSavvy ? facetsList.techSavvy : null;
    this.inNetworkOnlyCheckbox = facetsList.inNetwork ? facetsList.inNetwork : null;
    this.primaryCareProviderCheckbox = facetsList.isPcp ? facetsList.isPcp : null;
    this.isChoicePcpCheckbox = facetsList.isChoicePcp ? facetsList.isChoicePcp : null;
    this.providerType = facetsList.providerType ? facetsList.providerType : null;
    this.tiersList = facetsList.tiers ? facetsList.tiers : null;
    this.awardTypeCodesList = facetsList.awardTypeCodes ? facetsList.awardTypeCodes : null;
    this.bcdTypeCodesList = facetsList.bdcTypeCodes ? facetsList.bdcTypeCodes : null;
    
    let itemslected : boolean = false;
    let modifiedlocationGeoList: FilterListItemInterface[] = [];
    
    let firstelement :boolean = false;
    this.locationGeoList.forEach(function(item){
     if(item.selected){
        itemslected = true;
        firstelement = true;
     }else{
       firstelement = false;
     }
     if(itemslected && !firstelement){
       item.count = "N";
     }
     
      modifiedlocationGeoList.push(item);

    });
    if (this.inNetworkOnlyCheckbox || this.teleHealthCheckbox || this.acceptingNewPatientsCheckbox 
      || this.primaryCareProviderCheckbox || this.techSavvyCheckbox || this.isChoicePcpCheckbox) {
      this.checkboxFilterFlag = true;
    } else {
      this.checkboxFilterFlag = false;
    }

    this.locationGeoList = modifiedlocationGeoList;
    console.log("this geolocationlist",this.locationGeoList);
  }

  

  public isSortOpened() {
    this.isSortExpanded = true;
  }

  public isSortClosed() {
    this.isSortExpanded = false;
  }

  /**
   * @description helps hide the sections other than the filter section and vice versa when the "Filter" dropdown is clicked in
   *  mobile screen only. Does not have any effect on the desktop screens
   */
  public toggleFilter() {
    this.isDisplayFilter = !this.isDisplayFilter;
    this.outputTransaction.filterOverlayFlag = this.isDisplayFilter;
    this.outputTransaction.filterCriteriaData = null;
    this.outputTransaction.sortCriteriaData = null;
    this.componentOutput.emit(this.outputTransaction);
  }

  public applySortFilter() {
    this.outputTransaction.filterCriteriaData = this.filterMetaData;
    this.outputTransaction.sortCriteriaData = this.sortMetaData;
    this.isDisplayFilter = false;
    this.outputTransaction.filterOverlayFlag = this.isDisplayFilter;
    this.enableClearfilterFlag = true;
    this.fadSearchListService.isFilterChanged(true);
    this.componentOutput.emit(this.outputTransaction);
  }

  public clearFilter() {
    this.isSortExpanded = false;
    this.isDisplayFilter = false;
    this.enableClearfilterFlag = false;
    this.outputTransaction.filterOverlayFlag = this.isDisplayFilter;

    this.filterMetaData = new FiltersMetadata();
    this.sortMetaData = new SortMetadata();
    this.outputTransaction.filterCriteriaData = this.filterMetaData;
    this.outputTransaction.sortCriteriaData = this.sortMetaData;
    this.fadSearchListService.isFilterChanged(false);
    this.componentOutput.emit(this.outputTransaction);
  }

  /*
     To get the selected sorted criteria from the view/template while changing the options
  */
  public onSortItemChanged(selectedSortObject: MatRadioChange): void {
    const selectValue = selectedSortObject.value;
    this.sortList = this.sortList.map(sortObj => {
      if (selectValue.value && sortObj.value == selectValue.value) {
        sortObj.checked = true;
        this.sortSelectedFilter = sortObj.name;
      } else {
        sortObj.checked = false;
      }
      return sortObj;
    });

    this.sortMetaData = selectedSortObject.value;
    this.applySortFilter();
  }

  /*
     To get the selected filter criteria from the view/template while changing the options
  */
  public manageSelectedProfessionalFilter(selectionListRadioBoxChange: MatRadioChange) {
    const selectValue = selectionListRadioBoxChange.value;
    window.scroll(0, 0);
    switch (selectionListRadioBoxChange.source.name) {
      case 'filterLocation':
        this.filterMetaData.filterLocation = selectValue;
        break;
      case 'filterGender':
        this.filterMetaData.filterGender = selectValue;
        break;
      case 'filterLanguage':
        this.filterMetaData.filterLanguage = selectValue;
        break;
      case 'filterRating':
        this.filterMetaData.filterRating = selectValue;
        break;
      case 'filterAges':
        this.filterMetaData.filterAges = selectValue;
        break;
      case 'filterSpecialities':
        this.filterMetaData.filterSpecialities = selectValue;
        break;
      case 'filterDisorders':
        this.filterMetaData.filterDisorders = selectValue;
        break;
      case 'filterTreatment':
        this.filterMetaData.filterTreatment = selectValue;
        break;
      case 'filterHospitalAffilation':
        this.filterMetaData.filterHospitalAffilation = selectValue; //
        break;
      case 'filterGroupAffilation':
        this.filterMetaData.filterGroupAffilation = selectValue;
        break;
      case 'filterBcd':
        this.filterMetaData.filterBcd = selectValue;
        break;
      case 'filterAwards':
        this.filterMetaData.filterAwards = selectValue;
        break;
      case 'filterTiers':
        this.filterMetaData.filterTiers = selectValue;
        break;
      case 'filterAreasOfExpertise':
        this.filterMetaData.filterAreasOfExpertise = selectValue;
        break;
    }

    this.applySortFilter();
  }

  /*
      To get the selected filter criteria from the view/template while changing the options
   */
  public manageCheckboxProfessionalFilter(selectionChBoxChange) {
    const selectValue = selectionChBoxChange.checked ? selectionChBoxChange.source.value : null;
    switch (selectionChBoxChange.source.name) {
      case 'filterPCP':
        this.filterMetaData.filterPCP = selectValue;
        break;
      case 'filterAcceptingNewPatients':
        this.filterMetaData.filterAcceptingNewPatients = selectValue;
        break;
      case 'filterTeleHealth':
        this.filterMetaData.filterTeleHealth = selectValue;
        break;
      case 'filterTechSavvy':
        this.filterMetaData.filterTechSavvy = selectValue;
        break;
      case 'filterInNetwork':
        this.filterMetaData.filterInNetwork = selectValue;
        break;
      case 'filterisChoicePCP':
        this.filterMetaData.filterisChoicePcp = selectValue;
        break;
    }

    this.applySortFilter();
  }

  private pushSortData() {
    const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();
    const searchTextOption: FadAutoCompleteComplexOptionInterface = searchCriteria.getSearchText();
    if (searchTextOption.isProcedure() && searchTextOption.getProcedureId()) {
      const newSortItem: FilterRadioItemInterface = {
        name: 'Ratings',
        value: 'aggregate_overall_rating+desc',
        checked: false
      };
      this.sortList.push(newSortItem);
    } else {
      const newSortItem: FilterRadioItemInterface = {
        name: 'Ratings',
        value: 'prs_overall_rating+desc,+prs_experience_of_care+desc',
        checked: false
      };
      this.sortList.push(newSortItem);
    }
  }

  /**
   * @description checks whether filters have key data
   */
  public expandAccordion(property): boolean {
    if (this.filterMetaData && this.filterMetaData.hasOwnProperty(property)) {
      return true;
    }

    return false;
  }
}
