import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AlertType } from '../../shared/alerts/alertType.model';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { DependantsService } from '../../shared/services/dependant.service';
import { AlertService, AuthService } from '../../shared/shared.module';
import { FadConstants } from './constants/fad.constants';
import { FadMembersInfoModel, FadMembersInfoRequestModel } from './modals/fad-landing-page.modal';
import { FadPlanSearchRequestModel } from './modals/fad-vitals-collection.model';
import { GetSearchByProcedureRequestModel } from './modals/getSearchByProcedure.model';
import { FadMembersInfoRequestModelInterface, FadMembersInfoResponseModelInterface } from './modals/interfaces/fad-landing-page.interface';
import {
  FadPlanSearchRequestModelInterface,
  FadPlanSearchResponseModelInterface
} from './modals/interfaces/fad-vitals-collection.interface';
import { GetSearchByProcedureRequestModelInterface } from './modals/interfaces/getSearchByProcedure-models.interface';

@Injectable()
export class FadService {
  public fadConstants = FadConstants;
  public dependantsList: FadMembersInfoModel[] = [];
  public isRVRNVUser = false;

  constructor(
    private alertService: AlertService,
    private router: Router,
    public dependantsService: DependantsService,
    public authService: AuthService,
    private http: AuthHttp
  ) {}

  public setServiceAlert(title, type = AlertType.Failure, scope = 'component'): void {
    const errorList = this.alertService.getAllError();
    if (JSON.stringify(errorList) === '{}' || errorList['component'] === '') {
      this.alertService.setAlert(title, '', type, scope);
    }
  }

  public clearServiceAlert(scope = 'component'): void {
    const errorList = this.alertService.getAllError();
    if (errorList && errorList.hasOwnProperty(scope)) {
      this.resetServiceError();
    }
  }

  public resetServiceError(): void {
    this.alertService.resetErrorObject();
  }

  public reviewMyBenfits() {
    this.router.navigate([this.fadConstants.urls.reviewmybenfits]);
  }

  public requestWrittenEstimate() {
    this.router.navigate([this.fadConstants.urls.requestEstimateUrl]);
  }

  async resolve(useGlobalSpinner = false): Promise<FadPlanSearchResponseModelInterface> {
    await this.authService
      .getTokens()
      .toPromise()
      .then(token => {
        this.authService.cryptoToken = token;
        this.authService.persistSession();
      });
    this.isRVRNVUser = false;
    if (this.authService.authToken !== undefined && this.authService.authToken !== null) {
      //If the User is not AV, dont make Secured Vitals calls
      if (!this.authService.authToken.userType || this.authService.getScopeName() === 'REGISTERED-AND-VERIFIED') {
        this.isRVRNVUser = true;
      }
    }
    if (
      this.authService.useridin &&
      this.authService.useridin !== 'undefined' &&
      this.authService.useridin !== '' &&
      this.authService.useridin !== undefined &&
      this.authService.useridin !== 'undefined' &&
      this.authService.useridin !== 'null' &&
      !this.isRVRNVUser
    ) {
      const vitalResponse = await this.getVitalsDependantList(useGlobalSpinner).toPromise();

      if (vitalResponse && vitalResponse.result && vitalResponse.result < 0) {
        sessionStorage.setItem('memberdisplayerrormessage', vitalResponse['displaymessage']);
        //return;
        return await this.getVitalsPlanInfo(useGlobalSpinner).toPromise();
      } else if (vitalResponse && vitalResponse.membersInfoList && vitalResponse.membersInfoList.length > 0) {
        this.dependantsList = vitalResponse.membersInfoList;

        if (!sessionStorage.getItem('fadVendorMemberNumber')) {
          sessionStorage.setItem('fadVendorMemberNumber', this.dependantsList[0].fadVendorMemberNumber);
        }
        sessionStorage.setItem('dependantsList', JSON.stringify(this.dependantsList));
      }

      await this.getProcedureSummary(useGlobalSpinner).toPromise();
    }
    return await this.getVitalsPlanInfo(useGlobalSpinner).toPromise();
  }

  // code copy pasted from fad-landing-page.service.ts
  // using a direct service call requires 4+ fad specific services to be provided in app module
  public getVitalsPlanInfo(useGlobalSpinner = false, customaccountName?: string): Observable<FadPlanSearchResponseModelInterface> {
    const request: FadPlanSearchRequestModelInterface = new FadPlanSearchRequestModel();
    const url = FadConstants.urls.fadLandingPagePlansAutocompleteListUrl;
    request.useridin = this.authService.useridin && this.authService.useridin !== 'undefined' ? this.authService.useridin : '';
    if (customaccountName && customaccountName !== 'undefined' && customaccountName !== 'null' && customaccountName !== null) {
      request.accountName = customaccountName;
    }
    // adhoc fix for KLO-1722
    // fix is to call encryptFadPost instead of encryptPost
    return this.http.encryptPost(url, request, null, null, useGlobalSpinner);
  }

  getDependents() {
    return this.dependantsService.fetchDependentsList().toPromise();
  }

  getVitalsDependantList(useGlobalSpinner = false): Observable<FadMembersInfoResponseModelInterface> {
    const request: FadMembersInfoRequestModelInterface = new FadMembersInfoRequestModel();
    request.useridin = this.authService.useridin;
    if (this.authService.getFadHccsFlag() !== null) {
      request['hccsFlag'] = this.authService.getFadHccsFlag();
    }

    const url = FadConstants.urls.fadLandingPageDependentsListUrl;

    return this.http.encryptPost(url, request, null, null, useGlobalSpinner).map(response => {
      // adhoc fix for KLO-1722
      // this map method is the adhoc fix
      if (response.result === -92829) {
        sessionStorage.setItem('isUserNotMemberInCHC', 'true');
        this.authService.isUserNotMemberInCHC = true;
      }
      return response;
    });
  }

  getProcedureSummary(useGlobalSpinner = false) {
    const procedureSearchReq: GetSearchByProcedureRequestModelInterface = new GetSearchByProcedureRequestModel();
    procedureSearchReq.setUserId(this.authService.useridin).setLocale(FadConstants.defaults.locale + '');
    if (this.authService.getFadHccsFlag() !== null) {
      procedureSearchReq['hccsFlag'] = this.authService.getFadHccsFlag();
    }
    if (sessionStorage.getItem('fadVendorMemberNumber')) {
      procedureSearchReq['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
    }
    const url = FadConstants.urls.fadVitalsProcedureUrl;
    // adhoc fix for KLO-1722
    // fix is to call encryptFadPost instead of encryptPost
    return this.http.encryptFadPost(url, procedureSearchReq, null, null, useGlobalSpinner);
  }

  public notAcceptingPatients(acceptingNewPatients) {
    return acceptingNewPatients === 'E' || acceptingNewPatients === 'EX' || acceptingNewPatients === 'XE' || acceptingNewPatients === 'N';
  }

  public acceptingPatients(acceptingNewPatients) {
    return acceptingNewPatients === 'O' || acceptingNewPatients === 'OX' || acceptingNewPatients === 'XO' || acceptingNewPatients === 'Y';
  }

  public acceptingPatientsPCP(acceptingNewPatients) {
    return acceptingNewPatients === 'OE';
  }

  public acceptingPatientsSpecialist(acceptingNewPatients) {
    return acceptingNewPatients === 'EO';
  }

  public acceptingFamilyPatients(acceptingNewPatients) {
    return acceptingNewPatients === 'F';
  }
}
