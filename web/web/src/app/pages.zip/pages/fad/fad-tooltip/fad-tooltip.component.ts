import { Component, ElementRef, HostListener, Input, OnInit } from '@angular/core';
import { TooltipService } from './fad-tooltip.service';

declare let $: any;

@Component({
  selector: 'app-fad-tooltip',
  templateUrl: './fad-tooltip.component.html',
  styleUrls: ['./fad-tooltip.component.scss']
})
export class FadTooltipComponent implements OnInit {

  @Input() tooltipText: string = '';
  @Input() tooltipHeading?: string = '';
  @Input() tooltipLink?: string = '';
  isActive = false;
  href: any;
  modalcontent: string = "";
  showothermodal: boolean = false;
  showpopup1: boolean = false;
  showpopup2: boolean = false;
  modalClosed: boolean = false;

  constructor(private tooltipService: TooltipService, private el: ElementRef) {
  }

  @HostListener('click', ['$event'])
  onclick($event) {
    $event.stopPropagation();
    if (this.modalClosed != true) {
      if (!this.isActive) {

        this.tooltipService.dismissTooltip();
        this.isActive = true;
      }
      else
        this.tooltipService.dismissTooltip();
    }
  }

  dismiss() {
    if (this.isActive) this.isActive = false;
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick() {
    if (this.isActive) this.isActive = false;
  }

  ngOnInit() {
    this.tooltipService.dismissTooltip();
    $('#openOtherPartySiteWithExternalLinkB').modal({ dismissible: true });
    $('#openOtherPartySiteWithExternalLink1').modal({ dismissible: true });
    $('#openOtherPartySiteWithExternalLink2').modal({ dismissible: true });
    this.tooltipService.getDismiss().subscribe((data) => {
      this.dismiss();
    });
    if (this.tooltipHeading) {
      this.showothermodal = true;
    }

  }
  ngOnChanges() {
    this.tooltipService.dismissTooltip();
  }
  public openOtherPartySite(url, $event) {
    $event.stopPropagation();
    $event.stopImmediatePropagation();
    console.log(this.tooltipHeading.indexOf('Blue Distinction Centers'));
    this.showothermodal = false;
    this.dismiss();
    this.tooltipService.dismissTooltip();
    console.log(this.tooltipHeading);
    if (this.tooltipHeading.indexOf('The Joint Commission') >= 0) {
      this.modalcontent = "QualityCheck.org is an independent website managed by the Joint Commission that lists the accreditation status of health care organizations. Through the accreditation process, organizations learn state-of-the-art performance-improvement strategies in order to continuously improve the safety and quality of care."

      this.showothermodal = true;
      this.showpopup2 = true;
      $('#openOtherPartySiteWithExternalLink1').modal('open');
    }

    else if (this.tooltipHeading.indexOf('Blue Distinction') >= 0) {

      this.modalcontent = "BCBS.com is an independent website managed by the Blue Cross Blue Shield Association. Blue Cross Blue Shield companies recognize select doctors, hospitals, and other health care facilities as Blue Distinction Centers when they meet our standards for quality and affordability."

      this.showothermodal = true;
      this.showpopup1 = true;
      $('#openOtherPartySiteWithExternalLinkB').modal('open');

    }
    else if (this.tooltipHeading.indexOf('Certification Matters') >= 0) {
      this.modalcontent = "CertificationMatters.org is an independent website managed by ABMS, a not-for-profit organization. Doctors who are board certified by an ABMS Member Board have completed additional clinical training and demonstrated expertise in specialized areas of care. Visit CertificationMatters.org to learn more and to view or search for board-certified doctors."
      sessionStorage.setItem("bcurl", "https://www.certificationmatters.org/");
      this.showothermodal = true;
      $('#openOtherPartySiteWithExternalLink2').modal('open');
    }
    else {
      this.tooltipHeading = null;
      this.dismiss();
      this.showothermodal = false;
      this.tooltipService.dismissTooltip();
      if (url) {
        this.openUrlinNewWindow(url);
      }
    }

    sessionStorage.setItem("url", url);

  }
  continue(tooltipLink) {
    this.dismiss();
    this.tooltipService.dismissTooltip();
    this.modalClosed = true;
    $('#openOtherPartySiteWithExternalLinkB').modal('close');
    $('#openOtherPartySiteWithExternalLink1').modal('close');
    $('#openOtherPartySiteWithExternalLink2').modal('close');

    this.openUrlinNewWindow(sessionStorage.getItem("url"));
  }
  closeModals() {
    this.dismiss();
    this.modalClosed = true;
    $('#openOtherPartySiteWithExternalLinkB').modal('close');
    $('#openOtherPartySiteWithExternalLink1').modal('close');
    $('#openOtherPartySiteWithExternalLink2').modal('close');
  }
  openUrlinNewWindow(url) {
    if (url) {
      window.open(url, '_blank');
    }
  }
}
