import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import * as moment from 'moment';
import { Observable } from 'rxjs/Observable';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { AuthService } from '../../../shared/services/auth.service';
import { FadConstants } from '../constants/fad.constants';
import { GetToolTipInfoRequestModel } from '../modals/getToolTipInfo.model';
import { FadDoctorProfileRequestModelInterface, FadDoctorRatingsRequestModelInterface, FadDoctorRatingsResponseModelInterface, FadProfessionalResponseModelInterface } from '../modals/interfaces/fad-doctor-profile-details.interface';
import { GetToolTipInfoRequestModelInterface } from '../modals/interfaces/getToolTipInfo-models.interface';

@Injectable()
export class FadDoctorProfileService {
  public doctorProfile: any;
  constructor(private http: AuthHttp, private simphttp: HttpClient, private authService: AuthService) { }

  getFadGetprofessionalprofileDetails(request: FadDoctorProfileRequestModelInterface): Observable<FadProfessionalResponseModelInterface> {
    let params = new HttpParams();

    // tslint:disable-next-line:forin
    for (const key in request) {
      params = params.append(key.toString(), request[key]);
    }
    if (this.authService.getFadHccsFlag() !== null) {
      request['hccsFlag'] = this.authService.getFadHccsFlag();
    }

    return this.http.encryptFadPost(FadConstants.urls.professionalprofile, request, '', '', false)
      .do(res => {
        for (let location of res.locations) {
          if (location.endDateDisclaimers && location.endDateDisclaimers.futureTerminationDate) {
            location.endDateDisclaimers.futureTerminationDate = moment.utc(location.endDateDisclaimers.futureTerminationDate)
              .format('MM/DD/YYYY');
          }
        }
      })
      .map(response => {
        return response;
      });
  }

  getProfessionalratings(request: FadDoctorRatingsRequestModelInterface): Observable<FadDoctorRatingsResponseModelInterface> {
    let params = new HttpParams();

    // tslint:disable-next-line:forin
    for (const key in request) {
      params = params.append(key.toString(), request[key]);
    }

    if (this.authService.getFadHccsFlag() !== null) {
      request['hccsFlag'] = this.authService.getFadHccsFlag();
    }

    // adhoc fix for KLO-1722
    // fix is to call encryptFadPost instead of encryptPost
    return this.http.encryptFadPost(FadConstants.urls.fadGetDoctorRatings, request, '', '', false);

  }
  getToolTipInfo() {
    const ToolTipReq: GetToolTipInfoRequestModelInterface = new GetToolTipInfoRequestModel();
    if (this.authService.useridin && this.authService.useridin != 'undefined') {
      ToolTipReq.setUserId(this.authService.useridin);
    }
    ToolTipReq['categoryType'] = 'All';
    const url = FadConstants.urls.fadVitalsToolTipsInfo;

    // adhoc fix for KLO-1722
    // fix is to call encryptFadPost instead of encryptPost
    return this.http.encryptFadPost(url, ToolTipReq, null, null, false);
  }
  getAcceptableReviewers(request: FadDoctorRatingsRequestModelInterface): Observable<FadDoctorRatingsResponseModelInterface> {
    let params = new HttpParams();
    delete request.ratingIdentifier;
    // tslint:disable-next-line:forin
    for (const key in request) {
      params = params.append(key.toString(), request[key]);
    }

    if (this.authService.getFadHccsFlag() !== null) {
      request['hccsFlag'] = this.authService.getFadHccsFlag();
    }

    // adhoc fix for KLO-1722
    // fix is to call encryptFadPost instead of encryptPost
    return this.http.encryptFadPost(FadConstants.urls.fadGetAcceptableReviersUrl, request, '', '', true);

  }
}
