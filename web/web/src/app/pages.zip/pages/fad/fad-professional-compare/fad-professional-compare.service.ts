import { Injectable } from '@angular/core';
import { FadConstants } from '../constants/fad.constants';
import { GetSearchByProfessionalResponseModelInterface } from '../modals/interfaces/getSearchByProfessional-models.interface';

@Injectable()
export class FadProfessionalCompareService {
  public searchResults: GetSearchByProfessionalResponseModelInterface;
  public searchData;
  public compareString = '';

  constructor() { }

  setSearchResult(searchResults) {
    this.searchResults = searchResults;
  }

  getSearchResult() {
    return this.searchResults;
  }

  setCompareStirng(compareString: string) {
    sessionStorage.setItem(FadConstants.storageVars.searchItemCompare, compareString);
    this.compareString = compareString;
  }

  setCostInfo(costInfo) {
    sessionStorage.setItem(FadConstants.storageVars.doctorCostInfo, JSON.stringify(costInfo));
  }

  getCostInfo() {
    const costInfo = sessionStorage.getItem(FadConstants.storageVars.doctorCostInfo);
    if (costInfo) {
      const costInfoJson = JSON.parse(costInfo);
      return costInfoJson;
    }
    return null;
  }
}
