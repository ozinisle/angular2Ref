import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  Input,
  OnChanges,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild,
  OnDestroy
} from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatAutocompleteTrigger, MatDialog } from '@angular/material';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import * as cloneDeep from 'lodash/cloneDeep';
import { Observable } from 'rxjs/Observable';
import { interval } from 'rxjs/observable/interval';
import { timer } from 'rxjs/observable/timer';
import { map } from 'rxjs/operators';
import { delay } from 'rxjs/operators/delay';
import { startWith } from 'rxjs/operators/startWith';
import { LoadingSpinnerService } from '../../../core/components/loading-spinner';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { BcbsmaConstants } from '../../../shared/constants/bcbsma.constants';
import { MatchTextHighlightPipe } from '../../../shared/pipes/match-text-highlight/match-text-highlight.pipe';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { GlobalService } from '../../../shared/services/global.service';
import { AuthService } from '../../../shared/shared.module';
import { FadConstants } from '../constants/fad.constants';
import { FadBreadCrumbsService } from '../fad-bread-crumbs/fad-bread-crumbs.service';
import { FadDoctorProfileService } from '../fad-doctor-profile/fad-doctor-profile.service';
import { FadFacilityProfileService } from '../fad-facility-profile/fad-facility-profile.service';
import { FadPastSearchQueryListService } from '../fad-past-search-query-list/fad-past-search-query-list.service';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import { FadService } from '../fad.service';
import {
  FadAutoCompleteComplexOption,
  FadAutoCompleteOptionForSearchText,
  FadLandingPageSearchControlsModel,
  FadLandingPageSearchControlValues,
  FadMembersInfoModel,
  LandingPageResponseCacheModel
} from '../modals/fad-landing-page.modal';
import {
  DoctorProfileSearchRequestModel,
  FadVitalsNetwork,
  FadVitalsZipCodeSearchRequestModel,
  FPSRPlan,
  FZCSRCity
} from '../modals/fad-vitals-collection.model';
import { GetSearchByProviderRequestModel } from '../modals/getSearchByProvider.models';
import { HelpChoosingNetworkComponent } from '../modals/help-choosing-network/help-choosing-network.component';
import {
  FadAutoCompleteComplexOptionInterface,
  FadAutoCompleteOptionForSearchTextInterface,
  FadLandingPageCompInputInterface,
  FadLandingPageCompOutputInterface,
  FadLandingPageSearchControlValuesInterface,
  FadLinkOptionInterface
} from '../modals/interfaces/fad-landing-page.interface';
import {
  DoctorProfileSearchRequestModelInterface,
  FadVitalsNetworkInterface,
  FadVitalsZipCodeSearchRequestModelInterface
} from '../modals/interfaces/fad-vitals-collection.interface';
import { GetSearchByProviderRequestModelInterface } from '../modals/interfaces/getSearchByProvider-models.interface';
import {
  AuthRequestType,
  FadLandingPageComponentMode,
  FadLandingPageFocusTracker,
  FadResouceTypeCodeConfig,
  FadResourceTypeCode
} from '../modals/types/fad.types';
import { BreadCrumb } from '../utils/fad.utils';
import { FadLandingPageService } from './fad-landing-page.service';

declare let $: any;

/* tslint:disable */
@Component({
  selector: 'app-fad-landing-page',
  templateUrl: './fad-landing-page.component.html',
  styleUrls: ['./fad-landing-page.component.scss']
})
export class FadLandingPageComponent implements OnInit, OnChanges, AfterViewInit, OnDestroy {
  // optional input value to be provided only when consumed by other components like
  // fad-search-results component
  @Input('componentInput') componentInput: FadLandingPageCompInputInterface;
  @Output('componentOutput') componentOutput = new EventEmitter<FadLandingPageCompOutputInterface>();
  @ViewChild('searchTextTypeAhead', { read: MatAutocompleteTrigger })
  searchTextTypeAheadTrigger;
  @ViewChild('zipCodeTypeAhead', { read: MatAutocompleteTrigger })
  zipCodeTypeAheadTrigger;
  @ViewChild('planTypeAhead', { read: MatAutocompleteTrigger })
  planTypeAheadTrigger;
  @ViewChild('dependantListTypeAhead', { read: MatAutocompleteTrigger })
  dependantListTypeAheadTrigger;
  @ViewChild('searchBar') searchBar: ElementRef;
  @ViewChild('searchNameTypeAHeadContainer')
  searchNameTypeAHeadContainer: ElementRef;
  @ViewChild('zipCodeTypeAHeadContainer') zipCodeTypeAHeadContainer: ElementRef;
  @ViewChild('planTypeAheadContainer') planTypeAheadContainer: ElementRef;

  public fadConstants = FadConstants;
  public zipClearIcon = 'hidden';
  public planClearIcon = 'hidden';
  public dependantClearIcon = 'hidden';
  public searchTextPlaceHolder = '';
  public networkPlaceHolder = '';
  public isMedicareUser = false;
  public isRVRNVUser = false;
  public componentMode: FadLandingPageComponentMode = FadConstants.flags.fadLandingPageComponentMode_Normal;
  public displayDependentsOptionFlag = false;
  public searchControls: FadLandingPageSearchControlsModel;
  public zipCodeOptions: FZCSRCity[] = [];
  public filteredZipCodeOptions: Observable<FZCSRCity[]>;
  public dependantsList: FadMembersInfoModel[] = [];
  public selectedMember: FadMembersInfoModel;
  public defaultPlanOptions: FadAutoCompleteOptionForSearchText[] = [];
  public planOptions: FadAutoCompleteOptionForSearchText[] = [];
  public allnetworksList: any[];
  public filteredPlanOptions: Observable<FadAutoCompleteOptionForSearchText[]>;
  public autoCompleteOptionsForSearchText: FadAutoCompleteOptionForSearchText[] = [];
  public filteredAutoCompleteSearchOptions: Observable<FadAutoCompleteOptionForSearchText[]>;
  public viewPortWidth: number = null;
  public emboseSearchTextField = false;
  public emboseZipCodeField = false;
  public embosePlanField = false;
  public emboseDependantsField = false;
  public focusedTarget: string;
  public userCurrentPlan: FPSRPlan = new FPSRPlan();
  private preventSearchTextAutoCompleteDropdown = false;
  public textToHighlightInPlanOption: string;
  private textToHighlightInSearchTextOption: string;
  private isLogin = false;
  private defaultAutoCompleteSearchOption: FadAutoCompleteOptionForSearchTextInterface[] = [];
  private searchTextMaterialAutoCompleteBugWorkAroundFlag = 0;
  private searchTextMaterialAutoCompleteBugWorkAroundTimerFlag = 0;
  public defaultplanindex = 0;
  private debounceTime = 400;
  private isPageReload = false;
  private bypassPlanFieldFocusLogic = false;
  private userState: string;
  public getLocalStorageZipCodeOption: FZCSRCity;
  public fadInfo: any;
  public showTextField = false;
  public fadNetworkList = [];
  public selectedNetworkOption: any;
  public memberTHDetails: any;
  public isTelehealthInd_Req = false;
  public zipCodeValidationErrors = {
    invalidZipCode: {
      exists: false,
      errorMsg: 'Please enter Zip Code or City, State.',
      display: false
    },
    noMatchFound: {
      exists: false,
      errorMsg: 'Please check that you have entered the correct Zip Code or City.',
      display: false
    }
  };

  public planValidationErrors = {
    invalidPlan: {
      errorMsg: 'Please enter a valid network name.',
      display: false
    },
    noMatchFound: {
      errorMsg: 'Please check that you have entered a correct plan name.',
      display: false
    }
  };
  public iszipcodechangeFlag = false;
  private currentPlanNetwork: any;

  public lat: string;
  public lng: string;
  public isUnauthenticatedUser = false;
  public isAuthenticatedUserFlag: boolean;
  public isAnonymousUserFlag: boolean;
  public isAuthenticationRequiredFlag: boolean;
  public teleHealthData: any;
  // this network ID comes from Query String in Url - planid
  private networkIdFromURL = '';
  private customAccount = '';
  constructor(
    private router: Router,
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService,
    public landingPageService: FadLandingPageService,
    private fadSearchResultsService: FadSearchResultsService,
    private fadPastSearchQueryListService: FadPastSearchQueryListService,
    private doctorProfileService: FadDoctorProfileService,
    private facilityProfileService: FadFacilityProfileService,
    public authService: AuthService,
    public fb: FormBuilder,
    private fadService: FadService,
    private fadBreadCrumbsService: FadBreadCrumbsService,
    private globalService: GlobalService,
    private constantsService: ConstantsService,
    private authHttp: AuthHttp,
    private activatedRoute: ActivatedRoute,
    public dialogRef: MatDialog,
    private spinnerService: LoadingSpinnerService,
    private cdRef: ChangeDetectorRef
  ) {
    // Start:: code moved from Constructor
    const fadData = JSON.parse(sessionStorage.getItem('fadData'));
    this.teleHealthData = JSON.parse(sessionStorage.getItem('vitalsResponse'));
    // get the planid from URL and set it as default Network ID
    this.activatedRoute.queryParams.subscribe(params => {
      this.networkIdFromURL = params['planid'];
      this.customAccount = params['ci'];
    });
    if (fadData) {
      this.landingPageService.plannetworkdata = fadData;
    }
    if (this.teleHealthData) {
      this.landingPageService.setVitalsTeleHealthDetails(this.teleHealthData);
    }

    this.fadInfo = this.landingPageService.plannetworkdata;
    const planOption = new FadAutoCompleteOptionForSearchText();

    if (this.customAccount) {
      this.fadService.getVitalsPlanInfo(true, this.customAccount).subscribe(data => {
        sessionStorage.setItem('fadData', JSON.stringify(data, null, 2));
        this.landingPageService.plannetworkdata = data;
        this.fadInfo = data;
        if (this.fadInfo.networks) {
          this.fadInfo.networks.map(_network => {
            const network: FadVitalsNetworkInterface = Object.assign(new FadVitalsNetwork(), _network);
            const plan: FPSRPlan = Object.assign(new FPSRPlan(), network.getNetwork());
            planOption.addOption(new FadAutoCompleteComplexOption().setSimpleText(plan.getName()).setNetworkId(plan.getId()));
            if (plan.getPlanIndicator()) {
              this.userCurrentPlan = plan;
            }
          });
        }
        this.dyanamicplanhandleData();
      });
    }

    //Reset Plan option when user login
    if (sessionStorage.getItem('userLoginFlag') !== 'true') {
      if (fadData) {
        this.fadInfo = fadData;
      }

      if (this.fadInfo) {
        this.userCurrentPlan = this.getDefaultPlan();
        this.authService.setMleEligibility(this.fadInfo.mleEligibility);
        if (this.userCurrentPlan.getName() && this.userCurrentPlan.getId()) {
          const cachedPlans = new FadAutoCompleteComplexOption()
            .setSimpleText(this.userCurrentPlan.getName())
            .setNetworkId(this.userCurrentPlan.getId());

          this.fadSearchResultsService.setLastSelectedPlanOption(cachedPlans);
          sessionStorage.setItem('userLoginFlag', 'true');
        }
      }
    }

    let mleIndicator = undefined;
    let hccsFlag = undefined;
    // setting modal popup for mleindicator for null & N scenarios
    if (this.fadInfo && this.fadInfo.mleEligibility) {
      mleIndicator = this.fadInfo.mleEligibility;
    }
    if (this.fadInfo && this.fadInfo.hccsFlag) {
      hccsFlag = this.fadInfo.hccsFlag;
    }

    if (hccsFlag) {
      sessionStorage.setItem('hccsFlag', hccsFlag);
    }
    this.authService.setMLEIndicator(mleIndicator);

    this.viewPortWidth = window.innerWidth;

    const zipCodeLastSearchedWith: FZCSRCity = JSON.parse(localStorage.getItem('FadLandingPageSearchCriteria_zipCode')) as FZCSRCity;

    if (zipCodeLastSearchedWith) {
      this.getLocalStorageZipCodeOption = Object.assign(new FZCSRCity(), cloneDeep(zipCodeLastSearchedWith));
    } else {
      this.fillLocationOnLoad();
      this.getLocalStorageZipCodeOption = null;
    }
  }

  ngOnInit() {
    try {
      if (this.isAuthenticatedUser() && !this.authService.hasMembershipStarted()) {
        this.router.navigate(['too-soon']);
      }

      const tracking = JSON.parse(sessionStorage.getItem('path')) ? JSON.parse(sessionStorage.getItem('path')) : [];

      if (tracking[tracking.length - 1] != 'search-results') {
        tracking.push('fad');
      }
      sessionStorage.setItem('path', JSON.stringify(tracking));
      if (this.isAnonymousUser()) {
        this.networkPlaceHolder = this.fadConstants.text.landingPage_selectPlan_placeHolder_anonymous;
      }

      if (this.isAnonymousUser() || this.authService.getScopeName() === 'REGISTERED-AND-VERIFIED') {
        this.searchTextPlaceHolder = this.fadConstants.text.landingPage_entity_placeHolder_anonymous;
      } else if (
        this.authService.authToken &&
        this.authService.authToken.userType &&
        (this.authService.authToken.userType.toLowerCase() === 'medicare' || this.authService.authToken.userType.toLowerCase() === 'medex')
      ) {
        this.searchTextPlaceHolder = this.fadConstants.text.landingPage_entity_placeHolder_anonymous;
      } else if (sessionStorage.getItem('isUserNotMemberInCHC') === 'true') {
        this.searchTextPlaceHolder = this.fadConstants.text.landingPage_entity_placeHolder_anonymous;
      } else {
        this.searchTextPlaceHolder = this.fadConstants.text.landingPage_entity_placeHolder_user;
      }
      this.router.events.subscribe(event => {
        if (event instanceof NavigationEnd) {
          if (!event.url.includes('/fad')) {
            sessionStorage.removeItem('selMemIdx');
          }
        }
      });

      if (this.componentMode === FadConstants.flags.fadLandingPageComponentMode_Normal && !this.showTextField) {
        this.fadBreadCrumbsService.addBreadCrumb(new BreadCrumb().setLabel('Find a Doctor').setUrl('/fad'));
      }

      // DO NOT CHANGE CODE ORDER - STEP 1
      // step 1 - If the component is being opened in abstract mode, the set values persisted from the
      // main screen on to the search fields in the current age
      if (this.componentInput && this.componentInput.componentMode === FadConstants.flags.fadLandingPageComponentMode_Abstract) {
        this.searchControls = new FadLandingPageSearchControlsModel();
        this.searchControls.setValues(this.fadSearchResultsService.getSearchCriteria() as FadLandingPageSearchControlValues);
        this.landingPageService.setCachedSearchControlState(this.fadSearchResultsService.getSearchCriteria());
      }

      // DO NOTE CHANGE CODE ORDER - STEP 2
      // step 2 - use existing search control references if any
      if (this.landingPageService.getCachedSearchControlState()) {
        this.searchControls = this.landingPageService.getCachedSearchControlState() as FadLandingPageSearchControlsModel;

        this.fadInfo = this.landingPageService.plannetworkdata;

        this.currentPlanNetwork = new FadAutoCompleteComplexOption()
          .setSimpleText(this.getDefaultPlanOption().getName())
          .setNetworkId(this.getDefaultPlanOption().getId());
      } else {
        this.searchControls = new FadLandingPageSearchControlsModel();
        this.fadInfo = this.landingPageService.plannetworkdata;
      }

      // DO NOT CHANGE CODE ORDER - STEP 3
      // step 3 - service call initiations. This is sequential and hence the code order must not change
      if (
        this.viewPortWidth > 992 ||
        (this.componentMode === FadConstants.flags.fadLandingPageComponentMode_Normal && this.viewPortWidth < 993)
      ) {
        this.initData();
      } else if (
        this.landingPageService.getCachedSearchControlState() &&
        this.searchControls.dependantNameControl.value &&
        this.authService.getDependentsList() &&
        this.authService.getDependentsList().dependents.length > 0
      ) {
        this.displayDependentsOptionFlag = true;
      } else if (this.landingPageService.getCachedSearchControlState() && this.searchControls.dependantNameControl.value) {
        this.fetchDependentList();
      }

      // DO NOTE CHANGE CODE ORDER - STEP 4
      // step 4 - page needs to be updated with cached values if any, only after the defaults are loaded into memory
      if (this.fadPastSearchQueryListService.searchControlValues) {
        this.searchControls.setValues(this.fadPastSearchQueryListService.searchControlValues as FadLandingPageSearchControlValues);
        this.fadPastSearchQueryListService.searchControlValues = null;
      }

      // step 4 - help to enhanced the search functionlity in the typehead component which are loaded into memory with data
      if (
        this.viewPortWidth > 992 ||
        (this.componentMode === FadConstants.flags.fadLandingPageComponentMode_Normal && this.viewPortWidth < 993)
      ) {
        this.enhancedSearchAfterInitData();
      }

      const searchText: string = this.searchControls.searchTypeAheadControl.value;
      if (!searchText) {
        this.isPageReload = true;
      }

      if (searchText && searchText.trim) {
        this.isPageReload = false;
        this.stripAllDoctorFacilityTextAndUpdateUI(searchText);
      } else {
        this.searchControls.searchTypeAheadControl.setValue(searchText);
      }

      this.landingPageService.getToolTipInfo().subscribe(data => {
        if (data.toolTipInfo && data.toolTipInfo.tiersLabel) {
          data.toolTipInfo.tiersLabel.map(tierLabels => {
            switch (tierLabels.toolTip.code) {
              case 'TEBT':
                tierLabels.toolTip.code = 'Enhanced Benefits Tier';
                break;
              case 'TBBT':
                tierLabels.toolTip.code = 'Basic Benefits Tier';
                break;
              case 'TSBT':
                tierLabels.toolTip.code = 'Standard Benefits Tier';
                break;
              case 'THCS':
                tierLabels.toolTip.code = 'Higher Cost Share';
                break;
              case 'TLCS':
                tierLabels.toolTip.code = 'Lower Cost Share';
                break;
              default:
                tierLabels.toolTip.code = 'Higher Cost Share';
                break;
            }
          });

          sessionStorage.setItem('tiersLabel', JSON.stringify(data.toolTipInfo.tiersLabel));
          sessionStorage.setItem('profileLabel', JSON.stringify(data.toolTipInfo.profile));
        }
      });

      this.isAuthenticatedUserFlag = this.isAuthenticatedUser();
      this.isAnonymousUserFlag = this.isAnonymousUser();
      this.isAuthenticationRequiredFlag = this.isAuthenticationRequired();
      this.memberTHDetails = this.landingPageService.getVitalsTeleHealthDetails();
      if (this.memberTHDetails && this.memberTHDetails.teleHealthEligible) {
        this.isTelehealthInd_Req = true;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.ngOnInit
      );
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    // if the component is being displayed as part of other components in 'abstract' mode
    // for example as part of fad-search-results component
    // use the input provided by the consumer to popuplate the component
    this.componentInput = changes.componentInput.currentValue;
    if (this.componentInput) {
      this.showTextField = true;
    }
  }

  ngAfterViewInit() {
    try {
      if (this.landingPageService.getCachedSearchControlState()) {
        this.landingPageService.clearCachedSearchControlState();
      }

      if (
        this.landingPageService.getCachedSearchControlState() &&
        this.landingPageService.cachedResponse.planOptions &&
        this.planTypeAheadTrigger
      ) {
        this.planTypeAheadTrigger._element.nativeElement.value = this.searchControls.planControl.value.getSimpleText();
      } else if (
        this.isLogin &&
        (!this.landingPageService.cachedResponse || !this.landingPageService.cachedResponse.planOptions) &&
        this.planTypeAheadTrigger
      ) {
        this.planTypeAheadTrigger._element.nativeElement.value = this.userCurrentPlan.getName();
      }

      if (this.componentMode === FadConstants.flags.fadLandingPageComponentMode_Normal) {
        this.updateZipCodeFieldFromApplicationStorage();

        let cachedPlan: FadAutoCompleteComplexOption = this.fadSearchResultsService.getLastSelectedPlanOption();

        if (!cachedPlan) {
          const searchCriteria = Object.assign(new FadLandingPageSearchControlValues(), this.fadSearchResultsService.getSearchCriteria());
          cachedPlan = searchCriteria && searchCriteria.getPlanName ? searchCriteria.getPlanName() : null;
          if (!cachedPlan || !cachedPlan.getSimpleText || cachedPlan.getSimpleText() === '') {
            cachedPlan = new FadAutoCompleteComplexOption()
              .setSimpleText(this.userCurrentPlan.getName())
              .setNetworkId(this.userCurrentPlan.getId());
          }
        }

        this.fadSearchResultsService.setLastSelectedPlanOption(cachedPlan);

        if (this.planOptions.length === 0) {
          const planOption = new FadAutoCompleteOptionForSearchText();
          planOption.addOption(
            new FadAutoCompleteComplexOption().setSimpleText(this.userCurrentPlan.getName()).setNetworkId(this.userCurrentPlan.getId())
          );
          this.planOptions.push(planOption);
        }
      } else {
        this.updateZipCodeFieldFromApplicationStorage();
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.ngAfterViewInit
      );
    }
  }

  private addOnClickToAutoCompleteSpinner() {
    const autoCompleteSpinnerList: HTMLElement[] = Array.from(
      document.getElementsByClassName('mat-auto-complete-spinner')
    ) as HTMLElement[];
    autoCompleteSpinnerList.map(spinner => {
      const _spinner = spinner as HTMLDivElement;
      spinner['removeAllListeners'] ? spinner['removeAllListeners']() : this.noop();
      _spinner.addEventListener('click', event => {
        event.preventDefault();
        event.stopPropagation();
      });
    });
  }

  getDefaultPlan(): FPSRPlan {
    let resultValue: FPSRPlan = new FPSRPlan();
    try {
      if (this.fadInfo && this.fadInfo && this.fadInfo.networks) {
        if (this.isAnonymousUser() && this.networkIdFromURL) {
          this.fadInfo.networks.some(res => {
            if (res.network && res.network.id && res.network.id.toString() === this.networkIdFromURL) {
              resultValue = Object.assign(new FPSRPlan(), res.network);
              return true;
            }
          });
        } else {
          this.fadInfo.networks.some(res => {
            if (res.network.planIndicator === true || res.network.planIndicator === 'true') {
              resultValue = Object.assign(new FPSRPlan(), res.network);
              return true;
            }
          });
        }
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.getDefaultPlanOption
      );
    }
    return resultValue;
  }

  getDefaultPlanOption(): FPSRPlan {
    let resultValue: FPSRPlan = new FPSRPlan();
    try {
      if (this.fadInfo && this.fadInfo.networks) {
        if (this.isAnonymousUser() && this.networkIdFromURL) {
          this.fadInfo.networks.some(res => {
            if (res.network && res.network.id && res.network.id.toString() === this.networkIdFromURL) {
              resultValue = Object.assign(new FPSRPlan(), res.network);
              return true;
            }
          });
        } else {
          this.fadInfo.networks.some(res => {
            if (res.network.planIndicator === true || res.network.planIndicator === 'true') {
              resultValue = Object.assign(new FPSRPlan(), res.network);
              return true;
            }
          });
        }
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.getDefaultPlanOption
      );
    }
    return resultValue;
  }

  ngOnDestroy() {
    this.fadService.resetServiceError();
  }

  // will help determine the window width of the screen at all times
  // helps make RWD specific code as necessary
  // viewPortWidth for desktop is >= 993, for mobile and tablet is <=992
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.viewPortWidth = window.innerWidth;
  }

  /**
   * @description triggered with login/register/authenticate related links are clicked
   * YET TO BE CODED
   * @param event : HTML Event
   * @param target : AuthRequestType
   */
  public redirectRequestPlanDropDown(event, target?: AuthRequestType) {
    try {
      if (target === AuthRequestType.authenticate) {
        this.globalService
          .redirectionRoute()
          .then(response => {})
          .catch(route => {
            this.router.navigate([route]);
          });
      } else if (target === AuthRequestType.login) {
        localStorage.setItem('targetRoute', '/fad');
        this.router.navigateByUrl('/login');
      } else if (target === AuthRequestType.register) {
        this.router.navigateByUrl('/register');
      }
      event.stopPropagation();
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.redirectRequestPlanDropDown
      );
    }
  }

  /**
   * @description helps highlight text being searched for matching in the auto complete options
   * @param optionText - string  - the option that is displayed in the drop down autocompelete list
   */
  public getMatchHighlightedTextInPlanOption(optionText: string): string {
    let returnValue = '';
    try {
      if (optionText) {
        returnValue = new MatchTextHighlightPipe().transform(optionText, this.textToHighlightInPlanOption);
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.getMatchHighlightedTextInPlanOption
      );
    } finally {
      return returnValue;
    }
  }

  /**
   * @description helps highlight text being searched for matching in the auto complete options
   * @param optionText - string  - the option that is displayed in the drop down autocompelete list
   */
  public getMatchHighlightedTextInSearchTextOption(optionText: string): string {
    let returnValue = '';
    try {
      if (optionText) {
        returnValue = new MatchTextHighlightPipe().transform(optionText, this.textToHighlightInSearchTextOption);
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.getMatchHighlightedTextInSearchTextOption
      );
    } finally {
      return returnValue;
    }
  }

  /**
   * @description helps remove focus from a search field to avoid the auto complete list from being displayed
   * @param target - string
   */
  public removeIconFocusTracker(target: string, event?) {
    try {
      this.focusedTarget = target;
      if (this.viewPortWidth < 993) {
        switch (target) {
          // when remove icon inside the search doctor field is clicked
          case FadLandingPageFocusTracker.searchText:
            break;
          // when remove icon inside the search zipcode field is clicked
          case FadLandingPageFocusTracker.zipCode:
            this.landingPageService.cachedResponse.zipCodeOptions = [];
            this.filteredZipCodeOptions = Observable.of([]);
            this.displayZipCodeDropDown(event);
            break;
          // when remove icon inside the search plan field is clicked
          case FadLandingPageFocusTracker.plan:
            this.displayPlanDropDown(event);
            break;
          // when remove icon inside the search dependant field is clicked
          case FadLandingPageFocusTracker.dependant:
            break;
          // otherwise do nothing
          default:
            break;
        }
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.removeIconFocusTracker
      );
    }
  }

  /**
   * @description helps display only the search for doctor fiel on mobile screen
   * @param flag
   */
  public emboseSearchTextFieldOnScreen(flag: boolean, cancelButtonClicked?: boolean): boolean {
    try {
      this.emboseSearchTextField = flag;
      if (!flag && !cancelButtonClicked) {
        this.triggerSearchOnEnterKey();
      }

      //fix for klo-2014 mobile's web view issue
      this.scrollToElement(flag, this.searchNameTypeAHeadContainer);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.emboseSearchTextFieldOnScreen
      );
    }
    return flag;
  }

  private scrollToElement(emboseFlag: boolean, elementToScrollTo: ElementRef) {
    //@description: fix for klo-2014 mobile's web view issue
    if (emboseFlag) {
      interval(200)
        .takeUntil(timer(500))
        .subscribe(() => {
          const scrollTop: number = window.pageYOffset;
          const finalOffset: number = elementToScrollTo.nativeElement.getBoundingClientRect().top + scrollTop - 5000;
          window.parent.scrollTo({
            top: finalOffset,
            behavior: 'auto'
          });
        });
    }
  }

  public triggerSearchOnSearchLensIcon(flag: boolean): boolean {
    try {
      this.emboseSearchTextFieldOnScreen(flag);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.triggerSearchOnSearchLensIcon
      );
    }
    return flag;
  }
  /**
   * @description helps display only the search for zipcode field on mobile screen
   * @param flag
   */
  public emboseZipCodeFieldOnScreen(flag: boolean, location?: FZCSRCity): boolean {
    try {
      if (location) {
        const selectedZipCodeOption: FZCSRCity = new FZCSRCity();
        selectedZipCodeOption
          .setCity(location.city)
          .setCounty(location.county)
          .setGeo(location.geo)
          .setLat(location.lat)
          .setLng(location.lng)
          .setName(location.name)
          .setPlace_id(location.place_id)
          .setScore(location.score)
          .setState(location.state)
          .setState_code(location.state_code)
          .setZip(location.zip);

        this.fadSearchResultsService.setLastSelectedZipCodeOption(selectedZipCodeOption);

        setTimeout(() => {
          try {
            this.zipCodeTypeAheadTrigger._onChange(selectedZipCodeOption.getDisplayValue());
            this.zipCodeTypeAheadTrigger.closePanel();
            this.emboseZipCodeField = false;
          } finally {
            // IGNORE ERROR - IT WILL RESULT IN ANGULAR ERROR ON AUTOMATIC FOCUS TO SEARCH FIELD ON PAGE LOAD
          }
        }, 100);
      } else {
        this.emboseZipCodeField = flag;
      }

      this.zipClearIcon = flag ? 'visible' : 'hidden';

      //fix for klo-2014 mobile's web view issue
      this.scrollToElement(flag, this.zipCodeTypeAHeadContainer);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.emboseZipCodeFieldOnScreen
      );
    }
    return flag;
  }

  /**
   * @description helps display only the search for plan name field on mobile screen
   * @param flag
   */
  public embosePlanFieldOnScreen(flag: boolean, planOption?: FadAutoCompleteComplexOption): boolean {
    try {
      if (planOption) {
        const selectedPlanOption: FadAutoCompleteComplexOption = Object.assign(new FadAutoCompleteComplexOption(), planOption);

        this.planValidator(selectedPlanOption.getSimpleText() || selectedPlanOption.getContextText());

        this.fadSearchResultsService.setLastSelectedPlanOption(selectedPlanOption);
        this.searchControls.planControl.setValue(selectedPlanOption);
        setTimeout(() => {
          try {
            this.planTypeAheadTrigger._onChange(selectedPlanOption.getSimpleText());
            this.planTypeAheadTrigger.closePanel();
            this.embosePlanField = false;
          } finally {
            // IGNORE ERROR - IT WILL RESULT IN ANGULAR ERROR ON AUTOMATIC FOCUS TO SEARCH FIELD ON PAGE LOAD
          }
        }, 100);
      } else {
        this.planTypeAheadTrigger.closePanel();
        this.embosePlanField = flag;
      }

      this.planClearIcon = flag ? 'visible' : 'hidden';

      //fix for klo-2014 mobile's web view issue
      this.scrollToElement(flag, this.planTypeAheadContainer);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.emboseZipCodeFieldOnScreen
      );
    }

    return flag;
  }

  public planAutoCompleteListDesktopViewSelectionChange(option: FadAutoCompleteComplexOption): void {
    try {
      this.bypassPlanFieldFocusLogic = true;
      this.selectedNetworkOption = option;

      if (this.userCurrentPlan.getId() == option.getNetworkId()) {
        sessionStorage.setItem('networkChange', 'false');
      } else {
        if (this.authService.authToken) {
          if (this.authService.useridin && this.authService.authToken.userType) {
            sessionStorage.setItem('networkChange', 'true');
          }
        }
      }

      if (option.getInfoText() === 'my-current-plan-option') {
        option.setSimpleText(option.getContextText());
        option.setInfoText('');
        option.setContextText('');
      }

      if (option.getInfoText() !== FadConstants.plans.dontKnowPlanOption) {
        this.fadSearchResultsService.setLastSelectedPlanOption(option);
        this.planValidator(option.getSimpleText() || option.getContextText());
        this.doSearch();
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.planAutoCompleteListDesktopViewSelectionChange
      );
    }
  }

  /**
   * @description helps display only the search for dependants field on mobile screen
   * @param flag
   */
  public emboseDependantsFieldOnScreen(flag: boolean): boolean {
    this.emboseDependantsField = flag;
    this.dependantClearIcon = flag ? 'visible' : 'hidden';

    return flag;
  }

  /**
   * @description helps navigate to All Specialities and All Procedures page
   * @param event
   * @param link
   */
  public openSelectionList(event, link: FadLinkOptionInterface): boolean {
    this.router.navigate([link.href]);
    event.stopPropagation();

    return false;
  }

  /**
   * @description helps display the zip code typeahead drop down with options
   * @param event
   */
  public checkAndDisplayZipCodeDropDown(event): boolean {
    try {
      if (event.keyCode === 32 || event.keyCode === 13) {
        event.stopPropagation();
        this.displayZipCodeDropDown(event);
        return false;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.checkAndDisplayZipCodeDropDown
      );
    }
    return true;
  }

  /**
   * @description helps display the plan name typeahead drop down with options
   * @param event
   */
  public checkAndDisplayPlanDropDown(event) {
    try {
      if (event.keyCode === 32 || event.keyCode === 13) {
        event.stopPropagation();
        this.displayPlanDropDown(event);
        return false;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.checkAndDisplayPlanDropDown
      );
    }
  }

  /**
   * @description helps dislay dependants name typeahead drop down with options on screen
   * @param event
   */
  public checkAndDisplayDependentListDropDown(event): boolean {
    try {
      if (event.keyCode === 32 || event.keyCode === 13) {
        event.stopPropagation();
        this.displayDependentListDropDown(event);
        return false;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.checkAndDisplayDependentListDropDown
      );
    }
    return true;
  }

  /**
   * @description helps display past search history on screen
   * @param event
   */
  public checkAndDisplayPastSearchHistory(event): boolean {
    try {
      if (event.keyCode === 32 || event.keyCode === 13) {
        event.stopPropagation();
        this.displayPastSearchHistory();
        return false;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.checkAndDisplayPastSearchHistory
      );
    }
    return true;
  }

  /**
   * @description - defines what has to happen when the user selects a different option value in
   *    the search type a head drop down. In this case it ensures that the drop down list
   *    being displayed is hidden from view
   */
  public onSearchTextOptionSelected(option: FadAutoCompleteComplexOption, isSpecialityOption: boolean): void {
    try {
      this.isPageReload = false;
      this.fadSearchResultsService.setLastSelectedSearchTextOption(option);
      this.fadSearchResultsService.setLastSelectedPlanOption(this.selectedNetworkOption);
      this.preventSearchTextAutoCompleteDropdown = true;

      if (isSpecialityOption) {
        if (!this.zipCodeValidationErrors.invalidZipCode.display || !this.planValidationErrors.invalidPlan.display) {
          // if a speciality option is clicked in the autocomplete dropdown, trigger the search for the same
          const searchControlValues: FadLandingPageSearchControlValues = this.searchControls.getValues(this.fadSearchResultsService);
          searchControlValues.setSearchText(option);
          option.setSimpleText(searchControlValues.getSearchText().getSimpleText());
          this.fadSearchResultsService.setSearchCriteria(searchControlValues);

          if (!this.isSearchButtonDisabled()) {
            this.doSearch();
          }
        }
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.onSearchTextOptionSelected
      );
    }
  }

  onZipCodeTypeaheadOptionSelectionChange(location: FZCSRCity) {
    try {
      this.fadSearchResultsService.setLastSelectedZipCodeOption(location);
      this.iszipcodechangeFlag = true;
      sessionStorage.setItem('zipcodechangeflag', 'true');
      this.doSearch();
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.onZipCodeTypeaheadOptionSelectionChange
      );
    }
  }

  private triggerSearchOnEnterKey(desktopSearchButtonClick?: boolean, enterKeyPressed?: boolean) {
    try {
      // if enter key has been pressed, select the first matching option in the dropdown as the lastselected option
      const userProvidedSearchText = this.searchControls.searchTypeAheadControl.value;
      const lastSelectedZipCodeOption = this.fadSearchResultsService.getLastSelectedZipCodeOption();
      const geoKey = lastSelectedZipCodeOption && lastSelectedZipCodeOption.getGeo ? lastSelectedZipCodeOption.getGeo() : '';
      const cachedLookupOptions: FadAutoCompleteOptionForSearchText[] = this.landingPageService.getCachedSearchTextLookupOptions(
        `${userProvidedSearchText}~${geoKey}`
      );

      // DOAIP-3543
      let isSameSearch: boolean = false;
      let previousSearchCriteria = Object.assign(
        new FadLandingPageSearchControlValues(),
        JSON.parse(sessionStorage.getItem('FadLandingPageSearchCriteria'))
      );
      if (previousSearchCriteria && previousSearchCriteria.getSearchText() && previousSearchCriteria.getSearchText().getSimpleText()) {
        let previousSearchText = previousSearchCriteria.getSearchText().getSimpleText();
        if (
          previousSearchText.indexOf(FadConstants.text.allDoctorOptionText) === 0 ||
          previousSearchText.indexOf(FadConstants.text.allHospitalsOrFacilitiesText) === 0 ||
          previousSearchText.indexOf(FadConstants.text.allSpecialities) === 0 ||
          previousSearchText.indexOf(FadConstants.text.allProcedures) === 0
        ) {
          previousSearchText = previousSearchText.substring(previousSearchText.indexOf('"') + 1, previousSearchText.lastIndexOf('"'));
        }
        const userProvidedZipCode = this.searchControls.zipCodeTypeAheadControl.value.substring(
          0,
          this.searchControls.zipCodeTypeAheadControl.value.indexOf(' ')
        );
        const userProvidedPlan = this.searchControls.planControl.value;
        const userProvidedDependant = this.searchControls.dependantNameControl.value;
        let dependantChange = userProvidedDependant
          ? userProvidedDependant === previousSearchCriteria.getDependantName()
            ? false
            : true
          : false;
        if (
          userProvidedSearchText === previousSearchText &&
          userProvidedPlan.networkId === previousSearchCriteria.getPlanName().getNetworkId() &&
          userProvidedZipCode === previousSearchCriteria.getZipCode().getZip() &&
          !dependantChange
        ) {
          isSameSearch = true;
        }
      }

      if (cachedLookupOptions && cachedLookupOptions.length && !isSameSearch) {
        let cachedLookupOption = this.getCachedLookupOption(cachedLookupOptions, enterKeyPressed);
        cachedLookupOption = cachedLookupOption == null ? cachedLookupOptions[0] : cachedLookupOption;
        if (cachedLookupOption && cachedLookupOption.category === FadConstants.text.areYouLookingFor) {
          const firstSpecialityOption: FadAutoCompleteComplexOption = cachedLookupOptions[0].options[0] as FadAutoCompleteComplexOption;
          this.fadSearchResultsService.setLastSelectedSearchTextOption(firstSpecialityOption);
          if (!this.zipCodeValidationErrors.invalidZipCode.display || !this.planValidationErrors.invalidPlan.display) {
            this.emboseSearchTextField = false;
            this.searchControls.searchTypeAheadControl.setValue(cachedLookupOption.options[0].getSimpleText());
            this.searchTextTypeAheadTrigger._onChange(this.searchControls.searchTypeAheadControl.value);
            this.searchTextTypeAheadTrigger.closePanel();
            if (this.searchControls.zipCodeTypeAheadControl.value && this.searchControls.zipCodeTypeAheadControl.value.trim()) {
              this.doSearch();
            }
          } else {
            this.searchTextTypeAheadTrigger._onChange(this.searchControls.searchTypeAheadControl.value);
            this.searchTextTypeAheadTrigger.closePanel();
          }
        } else if (
          cachedLookupOption &&
          cachedLookupOption.category &&
          cachedLookupOption.category.indexOf(FadConstants.text.allDoctorOptionText) === 0
        ) {
          const searchControlValues: FadLandingPageSearchControlValues = this.searchControls.getValues(this.fadSearchResultsService);

          const searchTextOption = new FadAutoCompleteComplexOption();
          searchTextOption.setSimpleText(cachedLookupOption.category);
          searchTextOption.setResourceTypeCode(FadResouceTypeCodeConfig.professional);

          searchControlValues.setSearchText(searchTextOption);

          this.fadSearchResultsService.setLastSelectedSearchTextOption(searchTextOption);
          if (!this.isSearchButtonDisabled()) {
            this.searchControls.setValues(searchControlValues);
            if (this.searchControls.zipCodeTypeAheadControl.value && this.searchControls.zipCodeTypeAheadControl.value.trim()) {
              this.doSearch();
            }
          }
        } else if (
          cachedLookupOption &&
          cachedLookupOption.category &&
          cachedLookupOption.category.indexOf(FadConstants.text.allHospitalsOrFacilitiesText) === 0
        ) {
          const searchControlValues: FadLandingPageSearchControlValues = this.searchControls.getValues(this.fadSearchResultsService);

          const searchTextOption = new FadAutoCompleteComplexOption();
          searchTextOption.setSimpleText(cachedLookupOption.category); // cachedLookupOptions[0].options[0].getSimpleText());
          searchTextOption.setResourceTypeCode(FadResouceTypeCodeConfig.facility);

          searchControlValues.setSearchText(searchTextOption);

          this.fadSearchResultsService.setLastSelectedSearchTextOption(searchTextOption);
          if (!this.isSearchButtonDisabled()) {
            this.searchControls.setValues(searchControlValues);
            if (this.searchControls.zipCodeTypeAheadControl.value && this.searchControls.zipCodeTypeAheadControl.value.trim()) {
              this.doSearch();
            }
          }
        }
      } else if (desktopSearchButtonClick && !isSameSearch) {
        this.doSearch();
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.triggerSearchOnEnterKey
      );
    }
  }

  /*
  Method to get the correct cached option list based on the item selected in the autocomplete
  - if specialty/procedure has been selected, it will be always the 1st list
  - if 'All doctors' has been selected, find based on category (could be 1st/2nd list)
  - if 'All facilities' has been selected, find based on category (could be 1st/2nd/3rd list)
  */
  private getCachedLookupOption(lookupOptions, enterKeyPressed: boolean) {
    let lookupOption = null;

    const searchCriteria = this.fadSearchResultsService.getSearchCriteria();
    const searchText = searchCriteria ? searchCriteria.getSearchText() : null;
    const specialtyId = searchText ? searchText.getSpecialityId() : '';
    const procedureId = searchText ? searchText.getProcedureId() : '';
    const resourceTypeCode = searchText ? searchText.getResourceTypeCode() : '';
    // if specialty/procedure or Enter button is clicked
    if ((specialtyId || procedureId || !resourceTypeCode || enterKeyPressed) && lookupOptions[0]) {
      lookupOption = lookupOptions[0];
      // if 'All doctors'
    } else if (!specialtyId && !procedureId && resourceTypeCode === 'P') {
      if (lookupOptions[0] && lookupOptions[0].category && lookupOptions[0].category.indexOf(FadConstants.text.allDoctorOptionText) === 0) {
        lookupOption = lookupOptions[0];
      } else if (
        lookupOptions[1] &&
        lookupOptions[1].category &&
        lookupOptions[1].category.indexOf(FadConstants.text.allDoctorOptionText) === 0
      ) {
        lookupOption = lookupOptions[1];
      }
      // if 'All facilities'
    } else if (!specialtyId && !procedureId && resourceTypeCode === 'F') {
      if (
        lookupOptions[0] &&
        lookupOptions[0].category &&
        lookupOptions[0].category.indexOf(FadConstants.text.allHospitalsOrFacilitiesText) === 0
      ) {
        lookupOption = lookupOptions[0];
      } else if (
        lookupOptions[1] &&
        lookupOptions[1].category &&
        lookupOptions[1].category.indexOf(FadConstants.text.allHospitalsOrFacilitiesText) === 0
      ) {
        lookupOption = lookupOptions[1];
      } else if (
        lookupOptions[2] &&
        lookupOptions[2].category &&
        lookupOptions[2].category.indexOf(FadConstants.text.allHospitalsOrFacilitiesText) === 0
      ) {
        lookupOption = lookupOptions[2];
      }
    }
    return lookupOption;
  }

  /**
   * @description helps display values in the search for a doctor typeahead list
   */
  public displaySearchTextAutoCompleteDropDown(event?: KeyboardEvent): void {
    try {
      this.removeIconFocusTracker(FadLandingPageFocusTracker.searchText);

      if (this.viewPortWidth < 993) {
        this.clearServiceAlert(FadConstants.flags.mobileView);
        this.emboseSearchTextFieldOnScreen(!this.preventSearchTextAutoCompleteDropdown);
      }

      if (event && event.keyCode === 13) {
        this.triggerSearchOnEnterKey(false, true);

        return;
      } else if (event && event instanceof KeyboardEvent && (event.keyCode === 38 || event.keyCode === 40)) {
        // if up or down arrow is pressed do the associated menu navigation
        window.clearInterval(this.searchTextMaterialAutoCompleteBugWorkAroundTimerFlag);
        return;
      }

      if (this.preventSearchTextAutoCompleteDropdown) {
        this.preventSearchTextAutoCompleteDropdown = false;
        return;
      }

      setTimeout(() => {
        try {
          if (!!this.searchControls.searchTypeAheadControl.value && !!this.searchControls.searchTypeAheadControl.value.trim) {
            this.searchTextTypeAheadTrigger._onChange(this.searchControls.searchTypeAheadControl.value.trim());
            this.searchTextTypeAheadTrigger.openPanel();

            setTimeout(() => {
              try {
                this.searchTextMaterialAutoCompleteBugWorkAroundFlag = 0;
                this.searchTextMaterialAutoCompleteBugWorkAroundTimerFlag = window.setInterval(() => {
                  this.searchTextMaterialAutoCompleteBugWorkAroundFlag++;
                  try {
                    const autoCompletePanes: HTMLCollection = document.getElementsByClassName('cdk-overlay-pane');
                    let activeAutoCompletePane: HTMLElement = null;
                    for (let acpItr = 0; acpItr < autoCompletePanes.length; acpItr++) {
                      const autoCompPane: HTMLElement = autoCompletePanes[acpItr] as HTMLElement;
                      if (autoCompPane.innerHTML !== '') {
                        activeAutoCompletePane = autoCompPane;
                        break;
                      }
                    }

                    if (activeAutoCompletePane) {
                      const optionGroups: HTMLCollectionOf<HTMLElement> = activeAutoCompletePane.getElementsByClassName(
                        'mat-optgroup-label'
                      ) as HTMLCollectionOf<HTMLElement>;

                      if (optionGroups && optionGroups.length && activeAutoCompletePane) {
                        const firstOptGroupLabel: HTMLElement = optionGroups[0];

                        if (
                          firstOptGroupLabel &&
                          firstOptGroupLabel.innerHTML &&
                          (firstOptGroupLabel.innerHTML.indexOf(FadConstants.text.allDoctorOptionText) === 0 ||
                            firstOptGroupLabel.innerHTML.indexOf(FadConstants.text.allHospitalsOrFacilitiesText) === 0)
                        ) {
                          if (firstOptGroupLabel.className.indexOf('mat-active') !== -1) {
                            this.searchTextMaterialAutoCompleteBugWorkAroundFlag = 0;
                            window.clearInterval(this.searchTextMaterialAutoCompleteBugWorkAroundTimerFlag);
                            return;
                          }
                          firstOptGroupLabel.className += ' mat-active';

                          const matOptions: HTMLCollectionOf<HTMLElement> = activeAutoCompletePane.getElementsByTagName(
                            'mat-option'
                          ) as HTMLCollectionOf<HTMLElement>;
                          const firstMatOption: HTMLElement = matOptions[0];
                          if (firstMatOption) {
                            firstMatOption.className = firstMatOption.className
                              ? firstMatOption.className.replace('mat-active', '').trim()
                              : '';
                          }
                        } else if (
                          firstOptGroupLabel &&
                          firstOptGroupLabel.innerHTML &&
                          firstOptGroupLabel.innerHTML.indexOf(FadConstants.text.notSureWhatToSearch) === 0
                        ) {
                          return;
                        } else if (firstOptGroupLabel && firstOptGroupLabel.innerHTML === '') {
                          const matOptions: HTMLCollectionOf<HTMLElement> = activeAutoCompletePane.getElementsByTagName(
                            'mat-option'
                          ) as HTMLCollectionOf<HTMLElement>;
                          const firstMatOption: HTMLElement = matOptions[0];
                          this.searchTextMaterialAutoCompleteBugWorkAroundFlag = 0;

                          if (firstMatOption && firstMatOption.className.indexOf('mat-active') === -1) {
                            firstMatOption.className += ' mat-active';

                            return;
                          }
                        }
                      }
                    }
                    if (this.searchTextMaterialAutoCompleteBugWorkAroundFlag > 25) {
                      this.searchTextMaterialAutoCompleteBugWorkAroundFlag = 0;
                      window.clearInterval(this.searchTextMaterialAutoCompleteBugWorkAroundTimerFlag);
                    }

                    this.addOnClickToAutoCompleteSpinner();
                  } catch (exception) {
                    this.bcbsmaErrorHandler.logError(
                      exception,
                      BcbsmaConstants.modules.fadModule,
                      FadConstants.components.fadLandingPageComponent,
                      [FadConstants.methods.displaySearchTextAutoCompleteDropDown, FadConstants.methods.setInterval, 'nested level 3'].join(
                        ' - '
                      )
                    );
                  }
                }, 200);
              } catch (exception) {
                this.bcbsmaErrorHandler.logError(
                  exception,
                  BcbsmaConstants.modules.fadModule,
                  FadConstants.components.fadLandingPageComponent,
                  [FadConstants.methods.displaySearchTextAutoCompleteDropDown, FadConstants.methods.setTimeout, 'nested level 2'].join(
                    ' - '
                  )
                );
              }
            }, 100);
          }
        } finally {
          // IGNORE ERROR - IT WILL RESULT IN ANGULAR ERROR ON AUTOMATIC FOCUS TO SEARCH FIELD ON PAGE LOAD
        }
      }, 500);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.displaySearchTextAutoCompleteDropDown
      );
    }
  }

  /**
   * @description hide the auto complete text search
   */
  public cancelSearchTextAutoCompleteDropDown(): void {
    try {
      if (this.viewPortWidth < 993) {
        const cancelFlag = true;
        this.emboseSearchTextFieldOnScreen(false, cancelFlag);
        // if pageloads to clear session storage to avoid last value fetching in autocomplete
        if (this.isPageReload) {
          const option: FadAutoCompleteComplexOption = new FadAutoCompleteComplexOption();
          option.setSimpleText('');
          const searchControlValues: FadLandingPageSearchControlValues = this.searchControls.getValues(this.fadSearchResultsService);
          searchControlValues.setSearchText(option);
          this.searchControls.setValues(searchControlValues);
        }
      }

      setTimeout(() => {
        try {
          if (this.searchControls.searchTypeAheadControl.value) {
            const searchCriteria: FadLandingPageSearchControlValuesInterface = this.fadSearchResultsService.getSearchCriteria();

            if (!searchCriteria) {
              this.searchControls.searchTypeAheadControl.setValue('');
              this.searchTextTypeAheadTrigger._onChange(this.searchControls.searchTypeAheadControl.value);
              this.searchTextTypeAheadTrigger.closePanel();
            } else {
              const simpleText = searchCriteria.getSearchText().getSimpleText();
              this.searchControls.searchTypeAheadControl.setValue(simpleText);
              this.searchTextTypeAheadTrigger._onChange(this.searchControls.searchTypeAheadControl.value);
              this.searchTextTypeAheadTrigger.closePanel();
            }
          }
        } finally {
          // IGNORE ERROR - IT WILL RESULT IN ANGULAR ERROR ON AUTOMATIC FOCUS TO SEARCH FIELD ON PAGE LOAD
        }
      }, 100);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.cancelSearchTextAutoCompleteDropDown
      );
    }
  }

  /**
   * @description helps display values in the search for a zip code typeahead list
   * @param event
   */

  public fillLocation() {
    this.zipCodeValidationErrors.noMatchFound.display = false;
    this.zipCodeValidationErrors.invalidZipCode.display = false;

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(position => {
        this.lat = position.coords.latitude.toString();
        this.lng = position.coords.longitude.toString();
        const vitalsZipCodeSearchRequest: FadVitalsZipCodeSearchRequestModelInterface = new FadVitalsZipCodeSearchRequestModel();
        vitalsZipCodeSearchRequest.lat = this.lat;
        vitalsZipCodeSearchRequest.lng = this.lng;
        vitalsZipCodeSearchRequest.limit = 1;
        vitalsZipCodeSearchRequest.sort = 'distance';
        this.filteredZipCodeOptions = Observable.of([]);
        this.landingPageService.getVitalsZipCodeInfo(vitalsZipCodeSearchRequest).subscribe(vitalsZipCodeResponse => {
          this.filteredZipCodeOptions = Observable.of([]);
          this.filteredZipCodeOptions = Observable.of(vitalsZipCodeResponse.cities);
        });
      });
    }
  }

  public fillLocationOnLoad() {
    this.zipCodeValidationErrors.noMatchFound.display = false;
    this.zipCodeValidationErrors.invalidZipCode.display = false;

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(position => {
        this.lat = position.coords.latitude.toString();
        this.lng = position.coords.longitude.toString();
        const vitalsZipCodeSearchRequest: FadVitalsZipCodeSearchRequestModelInterface = new FadVitalsZipCodeSearchRequestModel();
        vitalsZipCodeSearchRequest.lat = this.lat;
        vitalsZipCodeSearchRequest.lng = this.lng;
        vitalsZipCodeSearchRequest.limit = 1;
        vitalsZipCodeSearchRequest.sort = 'distance';
        this.filteredZipCodeOptions = Observable.of([]);
        this.landingPageService.getVitalsZipCodeInfo(vitalsZipCodeSearchRequest).subscribe(vitalsZipCodeResponse => {
          this.filteredZipCodeOptions = Observable.of([]);
          this.filteredZipCodeOptions = Observable.of(vitalsZipCodeResponse.cities);
          this.filteredZipCodeOptions.subscribe(response => {
            const defaultCityZip: FZCSRCity = new FZCSRCity();
            defaultCityZip
              .setZip(response[0].zip)
              .setCity(response[0].city)
              .setState_code(response[0].state_code)
              .setGeo(response[0].geo) // '42.242921,-71.009972');
              .setCounty(response[0].county)
              .setGeo(response[0].geo)
              .setLat(response[0].lat)
              .setLng(response[0].lng)
              .setName(response[0].name)
              .setPlace_id(response[0].place_id)
              .setScore(response[0].score)
              .setState(response[0].state)
              .setState_code(response[0].state_code)
              .setZip(response[0].zip);

            const lastSelectedZipCodeOption = this.fadSearchResultsService.getLastSelectedZipCodeOption();

            this.fadSearchResultsService.setLastSelectedZipCodeOption(defaultCityZip);
            const zipCodeText = defaultCityZip.getDisplayValue();
            this.searchControls.zipCodeTypeAheadControl.setValue(zipCodeText);
            this.zipCodeTypeAheadTrigger._element.nativeElement.value = zipCodeText;
            this.zipCodeOptions.push(defaultCityZip);

            localStorage.setItem('FadLandingPageSearchCriteria_zipCode', JSON.stringify(defaultCityZip));
          });
        });
      });
    }
  }

  public displayZipCodeDropDown(event, flag = false): void {
    try {
      if (flag) {
        flag = false;
        this.filteredZipCodeOptions = Observable.of([]);
        this.fillLocation();
      }
      if (this.viewPortWidth < 993) {
        this.clearServiceAlert(FadConstants.flags.mobileView);
        this.emboseZipCodeFieldOnScreen(true);
      }
      document.getElementsByTagName('body')[0].click();

      setTimeout(() => {
        const zipCodeField = this.zipCodeTypeAheadTrigger._element.nativeElement;
        zipCodeField.focus();
        if (zipCodeField.value && zipCodeField.value.length > 0) {
          this.zipClearIcon = 'visible';
          if (zipCodeField.value.length < 3) {
            return;
          }
        } else {
          this.zipClearIcon = 'hidden';
        }
        event.stopPropagation();
        setTimeout(() => {
          this.zipCodeTypeAheadTrigger._onChange('');
          this.zipCodeTypeAheadTrigger.openPanel();
        });
      });
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.displayZipCodeDropDown
      );
    }
  }

  /**
   * @description hide the zipcode drop down
   */
  public hideZipCodeDropDown(): void {
    try {
      if (this.viewPortWidth < 993) {
        this.emboseZipCodeFieldOnScreen(false);
      }

      setTimeout(() => {
        try {
          const lastSelectedZipCodeOption: FZCSRCity = Object.assign(
            Object.create(new FZCSRCity()),
            this.fadSearchResultsService.getLastSelectedZipCodeOption()
          );
          this.zipCodeTypeAheadTrigger._onChange(lastSelectedZipCodeOption.getDisplayValue());
          this.zipCodeTypeAheadTrigger.closePanel();
          this.searchControls.zipCodeTypeAheadControl.setValue(lastSelectedZipCodeOption.getDisplayValue());
        } finally {
          // IGNORE ERROR - IT WILL RESULT IN ANGULAR ERROR ON AUTOMATIC FOCUS TO SEARCH FIELD ON PAGE LOAD
        }
      }, 100);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.hideZipCodeDropDown
      );
    }
  }

  /**
   * @description helps display values in the search for a plan name typeahead list
   * @param event
   */
  public displayPlanDropDown(event): void {
    try {
      if (this.bypassPlanFieldFocusLogic) {
        this.bypassPlanFieldFocusLogic = false;
        return;
      }

      if (event.keyCode && (event.keyCode === 38 || event.keyCode === 40)) {
        // if user presses up arrow or down arrow, then skip proceeding further
        return;
      }

      if (this.viewPortWidth < 993) {
        this.clearServiceAlert(FadConstants.flags.mobileView);
        this.embosePlanFieldOnScreen(true);
      }
      document.getElementsByTagName('body')[0].click();

      const planField = this.planTypeAheadTrigger._element.nativeElement;
      planField.focus();
      if (planField.value && planField.value.length > 0) {
        this.planClearIcon = 'visible';
      } else {
        this.planClearIcon = 'hidden';
      }

      event.stopPropagation();
      setTimeout(() => {
        this.planTypeAheadTrigger._onChange(this.searchControls.planControl.value);
        this.filterAutoCompletePlanOptions(this.searchControls.planControl.value);
        this.planTypeAheadTrigger.openPanel();
        if (this.viewPortWidth > 992) {
          setTimeout(() => {
            const planDropDownList: HTMLCollectionOf<Element> = document.getElementsByClassName('mat-autocomplete-panel planOption');
            const planDropDown: HTMLElement = planDropDownList ? (planDropDownList[0] as HTMLElement) : null;

            const planDropDownContainer: HTMLElement = planDropDown ? planDropDown.parentElement : null;
            if (planDropDownContainer) {
              let pddcClass = planDropDown.getAttribute('class');
              pddcClass = pddcClass && pddcClass.trim ? pddcClass.trim() : '';

              if (!!this.planValidationErrors.invalidPlan.display) {
                pddcClass = pddcClass.replace(' planValidationErrorExist-42', '').replace('planValidationErrorExist-42', '');
                if (pddcClass.indexOf('planValidationErrorExist-42') < 0) {
                  pddcClass += ' planValidationErrorExist-42';
                }
              } else if (!!this.planValidationErrors.noMatchFound.display) {
                pddcClass = pddcClass.replace(' planValidationErrorExist-55', '').replace('planValidationErrorExist-55', '');
                if (pddcClass.indexOf('planValidationErrorExist-55') < 0) {
                  pddcClass += ' planValidationErrorExist-55';
                }
              } else {
                pddcClass = pddcClass
                  .replace(' planValidationErrorExist-42', '')
                  .replace('planValidationErrorExist-42', '')
                  .replace(' planValidationErrorExist-55', '')
                  .replace('planValidationErrorExist-55', '');
              }
              planDropDown.setAttribute('class', pddcClass);
            }
          });
        }
      });
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.displayPlanDropDown
      );
    }
  }

  /**
   * @description hide the plan drop down
   */
  public hiddenPlanDropDown(): void {
    try {
      if (this.viewPortWidth < 993) {
        this.embosePlanFieldOnScreen(false);
      }

      setTimeout(() => {
        try {
          const lastSelectedPlanOption = this.fadSearchResultsService.getLastSelectedPlanOption();
          this.planTypeAheadTrigger._onChange(lastSelectedPlanOption);
          this.planTypeAheadTrigger.closePanel();
          this.searchControls.planControl.setValue(lastSelectedPlanOption);
          if (lastSelectedPlanOption && lastSelectedPlanOption.getSimpleText) {
            this.planValidator(lastSelectedPlanOption.getSimpleText());
          }
        } finally {
          // IGNORE ERROR - IT WILL RESULT IN ANGULAR ERROR ON AUTOMATIC FOCUS TO SEARCH FIELD ON PAGE LOAD
        }
      }, 100);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.hiddenPlanDropDown
      );
    }
  }

  /**
   * @description helps display values in the search for a dependant typeahead list
   * @param event
   */
  public displayDependentListDropDown(event): void {
    try {
      if (this.viewPortWidth < 993) {
        this.emboseDependantsFieldOnScreen(true);
      }
      document.getElementsByTagName('body')[0].click();

      const dependantField = this.dependantListTypeAheadTrigger._element.nativeElement;
      dependantField.focus();
      if (dependantField.value && dependantField.value.length > 0) {
        this.dependantClearIcon = 'visible';
      } else {
        this.dependantClearIcon = 'hidden';
      }
      event.stopPropagation();
      setTimeout(() => {
        this.dependantListTypeAheadTrigger._onChange('');
        this.dependantListTypeAheadTrigger.openPanel();
      });
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.displayDependentListDropDown
      );
    }
  }

  /**
   * @description hide the dependant drop down
   */
  public hiddenDependantDropDown(): void {
    try {
      if (this.viewPortWidth < 993) {
        this.emboseDependantsFieldOnScreen(false);
      }

      setTimeout(() => {
        try {
          this.dependantListTypeAheadTrigger._onChange(this.searchControls.dependantNameControl.value);
          this.dependantListTypeAheadTrigger.closePanel();
        } finally {
          // IGNORE ERROR - IT WILL RESULT IN ANGULAR ERROR ON AUTOMATIC FOCUS TO SEARCH FIELD ON PAGE LOAD
        }
      }, 100);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.hiddenDependantDropDown
      );
    }
  }

  /**
   * @name showDoctorList
   * @description to help display the doctors list on screen
   */
  public showDoctorList(): void {
    try {
      this.router.navigate([FadConstants.urls.fadSearchResultsPage]);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.showDoctorList
      );
    }
  }

  /**
   * @name displayPastSearchHistory
   * @description helps display 10 previous search results
   */
  public displayPastSearchHistory() {
    try {
      this.router.navigate([FadConstants.urls.fadPastSearchQueries]);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.displayPastSearchHistory
      );
    }
  }

  /**
   * @description helps display the All Specialities and All Procedures screen
   * @param url - specialities/procedures routing url
   */
  public openMedicalIndex(url: string) {
    try {
      this.landingPageService.setCachedSearchControlState(this.searchControls);
      this.router.navigate([url]);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.openMedicalIndex
      );
    }
  }

  /**
   * @description gets triggered when the remove icon is clicked inside the search fields. Helps clear the current field value when clicked
   * @return void - nothing
   */
  public clearTargetValue(target?: string): void {
    try {
      target = target || this.focusedTarget;

      switch (target) {
        // when remove icon inside the search doctor field is clicked
        case FadLandingPageFocusTracker.searchText:
          this.searchControls.searchTypeAheadControl.setValue('');
          this.searchTextTypeAheadTrigger._element.nativeElement.focus();
          break;
        // when remove icon inside the search zipcode field is clicked
        case FadLandingPageFocusTracker.zipCode:
          this.searchControls.zipCodeTypeAheadControl.setValue('');

          if (this.searchControls.zipCodeTypeAheadControl.value === '') {
            this.zipCodeValidationErrors.noMatchFound.display = false;
            this.zipCodeValidationErrors.invalidZipCode.display = true;
            this.landingPageService.cachedResponse.zipCodeOptions = [];
            this.filteredZipCodeOptions = Observable.of([]);
            this.fadSearchResultsService.setLastSelectedZipCodeOption(null);
            this.landingPageService.cachedResponse.setZipCodeOptions([]);
          }

          this.zipCodeTypeAheadTrigger._element.nativeElement.focus();
          break;

        // when remove icon inside the search dependant field is clicked
        case FadLandingPageFocusTracker.dependant:
          this.searchControls.dependantNameControl.setValue('');
          this.dependantListTypeAheadTrigger._element.nativeElement.focus();
          break;
        // otherwise do nothing
        default:
          break;
      }
      this.focusedTarget = '';
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.clearTargetValue
      );
    }
  }

  /**
   * @description triggers when the 'Search' button is clicked on the landing page component
   *  defines specific behavour for Abstract mode (when displayed as child component)
   *  and Normal mode (when displayed as stand alone component)
   * @returns void - nothing
   */
  public doSearch(flag = false): void {
    try {
      if (this.userCurrentPlan.getId() == this.fadSearchResultsService.getLastSelectedPlanOption().getNetworkId()) {
        sessionStorage.setItem('networkChange', 'false');
      } else {
        if (this.authService.authToken) {
          if (this.authService.useridin && this.authService.authToken.userType) {
            sessionStorage.setItem('networkChange', 'true');
          }
        }
      }
      if (this.isSearchButtonDisabled() && !flag) {
        return;
      }
      const searchCriteria = this.searchControls.getValues(this.fadSearchResultsService);
      if (this.viewPortWidth <= 992 && this.showTextField && flag) {
        this.landingPageService.setCachedSearchControlState(this.searchControls);
        this.router.navigate([FadConstants.urls.fadLandingPage]);
        return;
      }

      this.router.navigate([FadConstants.urls.fadSearchResultsPage]);

      this.fadSearchResultsService.setSearchCriteria(searchCriteria);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.doSearch
      );
    }
  }

  showAllProdecuresOptionInSearchDropdown(useridin) {
    if (
      useridin !== '' &&
      useridin !== undefined &&
      this.userState !== this.constantsService['Inactive'] &&
      sessionStorage.getItem('mleEligibility') &&
      sessionStorage.getItem('mleEligibility') !== 'N'
    ) {
      return true;
    }
    return false;
  }

  /**
   * @description helps populate the landing page's search control with default/cached values as necessary
   *  Also take care of initializing the drop down typeahead component behaviour for each of the search fields
   */
  private initData() {
    try {
      this.userCurrentPlan = this.getDefaultPlanOption();

      this.isLogin =
        this.authService.isLogin() && !(this.authService.isUserNotMemberInCHC || sessionStorage.getItem('isUserNotMemberInCHC') === 'true');
      const useridin = this.authService.useridin;

      if (this.isLogin) {
        this.defaultAutoCompleteSearchOption.push(
          new FadAutoCompleteOptionForSearchText()
            .setCategory(FadConstants.text.notSureWhatToSearch)
            .addOption(new FadAutoCompleteComplexOption().setLink(FadConstants.text.allSpecialities, '/fad/medical-index/specialities'))
        );

        this.userState = this.authService.fetchUserState();

        const planOption = new FadAutoCompleteOptionForSearchText();

        if (!this.fadInfo) {
          this.fadService.getVitalsPlanInfo(true).subscribe(data => {
            this.fadInfo = data;
            if (this.fadInfo.networks) {
              this.fadInfo.networks.map(_network => {
                const network: FadVitalsNetworkInterface = Object.assign(new FadVitalsNetwork(), _network);
                const plan: FPSRPlan = Object.assign(new FPSRPlan(), network.getNetwork());
                planOption.addOption(new FadAutoCompleteComplexOption().setSimpleText(plan.getName()).setNetworkId(plan.getId()));
                if (plan.getPlanIndicator()) {
                  this.userCurrentPlan = plan;
                }
              });
            }
          });
        }
        if (
          this.authService.authToken.userType != null &&
          (this.authService.authToken.userType.toLowerCase() === 'medicare' ||
            this.authService.authToken.userType.toLowerCase() === 'medex') &&
          this.authService.getMLEIndicator() != 'N' &&
          this.getDefaultPlan()
        ) {
          this.isMedicareUser = true;
        }
        if (this.authService.authToken.userType == null && this.authService.getScopeName() != 'REGISTERED-AND-VERIFIED') {
          this.isRVRNVUser = true;
        }

        if (
          this.showAllProdecuresOptionInSearchDropdown(useridin) &&
          !this.isMedicareUser &&
          !this.isRVRNVUser &&
          !this.authService.isUserNotMemberInCHC
        ) {
          this.defaultAutoCompleteSearchOption.push(
            new FadAutoCompleteOptionForSearchText().addOption(
              new FadAutoCompleteComplexOption().setLink(FadConstants.text.allProcedures, '/fad/medical-index/procedures')
            )
          );
        }
        if (!this.landingPageService.getCachedSearchControlState()) {
          const defaultObj = new FadAutoCompleteComplexOption()
            .setSimpleText(this.userCurrentPlan.getName())
            .setNetworkId(this.userCurrentPlan.getId());
          this.searchControls.planControl.setValue(defaultObj);
        }
      } else {
        this.defaultAutoCompleteSearchOption.push(
          new FadAutoCompleteOptionForSearchText()
            .setCategory(FadConstants.text.notSureWhatToSearch)
            .addOption(new FadAutoCompleteComplexOption().setLink(FadConstants.text.allSpecialities, '/fad/medical-index/specialities'))
        );
      }

      if (!this.landingPageService.cachedResponse) {
        this.landingPageService.cachedResponse = new LandingPageResponseCacheModel();
        this.landingPageService.cachedResponse.userId = this.authService.useridin;
      } else if (this.isUserIdChanged()) {
        this.clearCacheResponseOnUserIdChange();
      }
      this.autoCompleteOptionsForSearchText = this.defaultAutoCompleteSearchOption;

      // Start Handle Dependend list data //
      this.fetchDependentList();
      // End Handle Dependend list data //
    } catch (exception) {
      if (this.fadInfo && this.fadInfo.result && this.fadInfo.result < 0) {
        this.setServiceAlert(this.fadInfo['displaymessage'], AlertType.Failure);
      }
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.initData
      );
    }
  }
  public fetchProcedureSummary() {
    this.landingPageService.getProcedureSummary().subscribe(data => {
      this.spinnerService.hide();
    });
  }
  private fetchNetworkList() {}
  private fetchDependentList() {
    const useridin = this.authService.useridin;

    const currScope = this.authService.authToken ? this.authService.authToken.scopename : '';
    const memIdx = sessionStorage.getItem('selMemIdx');
    if (
      useridin !== '' &&
      useridin !== undefined &&
      this.landingPageService.cachedResponse &&
      !this.landingPageService.cachedResponse.dependantsList &&
      (currScope === 'AUTHENTICATED-AND-VERIFIED' || currScope === 'AUTHENTICATED-NOT-VERIFIED')
    ) {
      this.dependantsList = JSON.parse(sessionStorage.getItem('dependantsList')) as FadMembersInfoModel[];
      if (sessionStorage.getItem('memberdisplayerrormessage')) {
        this.setServiceAlert(sessionStorage.getItem('memberdisplayerrormessage'), AlertType.Failure);
      } else if (this.dependantsList.length > 0) {
        this.displayDependentsOptionFlag = true;

        this.landingPageService.cachedResponse.dependantsList = this.dependantsList;
        if (memIdx) {
          this.selectedMember = this.dependantsList[memIdx];
          sessionStorage.setItem('fadVendorMemberNumber', this.dependantsList[memIdx].fadVendorMemberNumber);
        } else {
          this.selectedMember = this.dependantsList[0];
          sessionStorage.setItem('fadVendorMemberNumber', this.dependantsList[0].fadVendorMemberNumber);
        }
      }
    } else if (useridin !== '' && useridin !== undefined && useridin !== 'undefined' && useridin != 'null') {
      this.dependantsList = this.landingPageService.cachedResponse.dependantsList;
      this.displayDependentsOptionFlag = true;
      if (this.dependantsList) {
        if (memIdx) {
          this.selectedMember = this.dependantsList[memIdx];
          sessionStorage.setItem('fadVendorMemberNumber', this.dependantsList[memIdx].fadVendorMemberNumber);
        } else {
          this.selectedMember = this.dependantsList[0];
          sessionStorage.setItem('fadVendorMemberNumber', this.dependantsList[0].fadVendorMemberNumber);
        }
      } else if (this.landingPageService.cachedResponse && this.landingPageService.cachedResponse.dependantsList) {
        this.dependantsList = this.landingPageService.cachedResponse.dependantsList;
        this.displayDependentsOptionFlag = true;
        if (memIdx) {
          this.selectedMember = this.landingPageService.cachedResponse.dependantsList[memIdx];
          sessionStorage.setItem(
            'fadVendorMemberNumber',
            this.landingPageService.cachedResponse.dependantsList[memIdx].fadVendorMemberNumber
          );
        } else {
          this.selectedMember = this.landingPageService.cachedResponse.dependantsList[0];
          sessionStorage.setItem('fadVendorMemberNumber', this.landingPageService.cachedResponse.dependantsList[0].fadVendorMemberNumber);
        }
      }
    }
  }

  private clearCacheResponseOnUserIdChange() {
    this.landingPageService.cachedResponse = new LandingPageResponseCacheModel();

    this.landingPageService.cachedResponse.userId = this.authService.useridin;
    this.landingPageService.cachedResponse.planOptions = null;
    this.landingPageService.cachedResponse.zipCodeOptions = [];

    this.fadSearchResultsService.setLastSelectedZipCodeOption(null);
    this.landingPageService.cachedResponse.setZipCodeOptions([]);
  }

  private isUserIdChanged(): boolean {
    return (
      this.landingPageService.cachedResponse &&
      this.landingPageService.cachedResponse.userId &&
      this.landingPageService.cachedResponse.userId !== this.authService.useridin
    );
  }
  /**
   * @description helps to search the data on typehead component after populate the
   * landing page's search control with default/cached values as necessary
   */
  private enhancedSearchAfterInitData() {
    try {
      this.searchControls.zipCodeTypeAheadControl.valueChanges.subscribe(
        searchText => {
          if (searchText && this.searchControls.zipCodeTypeAheadControl.value.trim()) {
            this.removeZipCodeError();
          }

          if (!searchText || (searchText && searchText.length < 3)) {
            return;
          }

          const cachedZipCodeLookupOptions: FZCSRCity[] = this.landingPageService.getCachedZipCodeLookupOptions(searchText.trim());
          if (cachedZipCodeLookupOptions) {
            this.zipCodeOptions = cachedZipCodeLookupOptions;
            this.landingPageService.cachedResponse.setZipCodeOptions(this.zipCodeOptions);

            this.searchControls.zipCodeTypeAheadControl.valueChanges
              .pipe(
                startWith(''),
                delay(0),
                map(val => {
                  if (this.zipCodeTypeAheadTrigger) {
                    clearInterval(this.zipCodeTypeAheadTrigger);
                    const currentSelectedValue = val ? val : this.zipCodeTypeAheadTrigger._element.nativeElement.value.trim();

                    this.filteredZipCodeOptions = Observable.of(
                      this.zipCodeOptions.filter(
                        option =>
                          option.city.toLowerCase().indexOf(currentSelectedValue.toLowerCase()) !== -1 ||
                          option.zip.indexOf(currentSelectedValue) !== -1
                      )
                    );
                  } else {
                    this.filteredZipCodeOptions = Observable.of(this.zipCodeOptions);
                  }
                })
              )
              .subscribe();

            return;
          }

          const zip_inSearchText = searchText ? searchText.split('-')[0].trim() : '';
          const regex = new RegExp(/(\d{5}) - (\w{1,}), (\w{2})/);
          const wholezipcode = searchText.match(regex);
          const vitalsZipCodeSearchRequest: FadVitalsZipCodeSearchRequestModelInterface = new FadVitalsZipCodeSearchRequestModel();
          vitalsZipCodeSearchRequest.place = wholezipcode ? '' : zip_inSearchText;
          vitalsZipCodeSearchRequest.page = 1;
          vitalsZipCodeSearchRequest.limit = this.viewPortWidth > 992 ? 10 : 6;
          if (wholezipcode && wholezipcode.length) {
            vitalsZipCodeSearchRequest.zip = wholezipcode[1] || '';
            vitalsZipCodeSearchRequest.city = wholezipcode[2] || '';
            vitalsZipCodeSearchRequest.state = wholezipcode[3] || '';
          }

          this.landingPageService.getVitalsZipCodeInfo(vitalsZipCodeSearchRequest).subscribe(
            vitalsZipCodeResponse => {
              try {
                this.landingPageService.vitalsZipCodeInfo = vitalsZipCodeResponse;
                this.zipcodeResponseValidator();
                this.clearServiceAlert();

                if (vitalsZipCodeResponse.cities) {
                  // remove zipcode error message if match found with response
                  if (
                    searchText &&
                    searchText.length >= 3 &&
                    vitalsZipCodeResponse.cities.length === 0 &&
                    this.zipCodeValidationErrors.noMatchFound.exists === false
                  ) {
                    this.zipCodeValidationErrors.noMatchFound.display = false;
                    this.zipCodeValidationErrors.invalidZipCode.display = false;
                  }

                  // display zipcode error message if no match found with response
                  if (
                    searchText &&
                    searchText.length >= 3 &&
                    this.zipCodeValidationErrors.invalidZipCode.exists === false &&
                    vitalsZipCodeResponse.cities.length === 0 &&
                    this.zipCodeValidationErrors.noMatchFound.exists === true
                  ) {
                    this.zipCodeValidationErrors.noMatchFound.display = true;
                    this.zipCodeValidationErrors.invalidZipCode.display = false;
                  }
                }
                // display error message if invalid zipcode exists like alphanumberic
                if (this.zipCodeValidationErrors.invalidZipCode.exists === true) {
                  this.zipCodeValidationErrors.noMatchFound.display = false;
                  this.zipCodeValidationErrors.invalidZipCode.display = true;
                }

                this.zipCodeOptions =
                  vitalsZipCodeResponse && vitalsZipCodeResponse.cities
                    ? (vitalsZipCodeResponse.cities as FZCSRCity[])
                    : ([] as FZCSRCity[]);
                if (!this.zipCodeTypeAheadTrigger) {
                  return;
                }
                this.fadSearchResultsService.setLastSelectedZipCodeOption(this.zipCodeOptions[0]);
                this.landingPageService.cachedResponse.setZipCodeOptions(this.zipCodeOptions);
                const zipFrag = searchText ? searchText.trim().split(' - ') : '';
                if (zipFrag[0] && Number(zipFrag[0].trim())) {
                  this.landingPageService.setCachedZipCodeLookupOptions(zipFrag[0].trim(), Object.assign([], this.zipCodeOptions));
                }

                this.searchControls.zipCodeTypeAheadControl.valueChanges
                  .pipe(
                    startWith(''),
                    delay(0),
                    map(val => {
                      if (this.zipCodeTypeAheadTrigger) {
                        clearInterval(this.zipCodeTypeAheadTrigger);
                        const currentSelectedValue = val ? val : this.zipCodeTypeAheadTrigger._element.nativeElement.value.trim();

                        this.filteredZipCodeOptions = Observable.of(
                          this.zipCodeOptions.filter(
                            option =>
                              option.city.toLowerCase().indexOf(currentSelectedValue.toLowerCase()) !== -1 ||
                              option.zip.indexOf(currentSelectedValue) !== -1
                          )
                        );
                      } else {
                        this.filteredZipCodeOptions = Observable.of(this.zipCodeOptions);
                      }
                    })
                  )
                  .subscribe();
              } catch (exception) {
                this.bcbsmaErrorHandler.logError(
                  exception,
                  BcbsmaConstants.modules.fadModule,
                  FadConstants.components.fadLandingPageComponent,
                  FadConstants.methods.getVitalsZipCodeInfo
                );
              }
            },
            error => {
              this.bcbsmaErrorHandler.handleHttpError(
                error,
                BcbsmaConstants.modules.fadModule,
                FadConstants.services.landingPageService,
                FadConstants.methods.getVitalsZipCodeInfo
              );
            }
          );
        },
        error => {
          this.bcbsmaErrorHandler.handleHttpError(
            error,
            BcbsmaConstants.modules.fadModule,
            FadConstants.services.searchTypeAheadControl_valueChanges,
            FadConstants.methods.valueChanges
          );
        }
      );

      // Start Handle Plan Option list data //
      this.dyanamicplanhandleData();
      this.searchControls.searchTypeAheadControl.valueChanges
        .debounceTime(this.debounceTime)
        .distinctUntilChanged()
        .subscribe(
          searchText => {
            try {
              searchText = searchText && searchText.trim ? searchText.trim() : '';
              if (searchText && searchText.length > 2) {
                const lastSelectedZipCodeOption = this.fadSearchResultsService.getLastSelectedZipCodeOption();
                const geoKey = lastSelectedZipCodeOption && lastSelectedZipCodeOption.getGeo ? lastSelectedZipCodeOption.getGeo() : '';
                const cachedLookupOptions: FadAutoCompleteOptionForSearchText[] = this.landingPageService.getCachedSearchTextLookupOptions(
                  `${searchText}~${geoKey}`
                );
                if (cachedLookupOptions) {
                  this.autoCompleteOptionsForSearchText = cachedLookupOptions;
                  this.filteredAutoCompleteSearchOptions = Observable.of(this.filterAutoCompleteSearchOptions(searchText));
                  return;
                }
                const vitalsAutoCompleteSearchRequest: GetSearchByProviderRequestModelInterface = new GetSearchByProviderRequestModel();

                let searchName = searchText;
                if (searchName && searchName.trim && searchName.trim().indexOf(FadConstants.text.allDoctorOptionText) >= 0) {
                  searchName = searchName.replace(FadConstants.text.allDoctorOptionText, '').replace(/["']/g, '');
                } else if (
                  searchName &&
                  searchName.trim &&
                  searchName.trim().indexOf(FadConstants.text.allHospitalsOrFacilitiesText) >= 0
                ) {
                  searchName = searchName.replace(FadConstants.text.allHospitalsOrFacilitiesText, '').replace(/["']/g, '');
                }

                const selectedZipCodeOptions: FZCSRCity = this.searchControls.getValues(this.fadSearchResultsService).getZipCode();
                vitalsAutoCompleteSearchRequest
                  .setSearchParameter(searchName)
                  .setGeoLocation(selectedZipCodeOptions ? selectedZipCodeOptions.getGeo() : '')
                  .setNetworkId(
                    this.fadSearchResultsService.getLastSelectedPlanOption()
                      ? this.fadSearchResultsService.getLastSelectedPlanOption().getNetworkId()
                      : FadConstants.defaults.networkId
                  ) // have to check -
                  // networkid has to come from chosen plan - check with prag - kalagi01
                  .setLimit(FadConstants.defaults.autoCompleteSearchRequest_limit);

                const authUserId = this.authService.useridin;
                if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
                  vitalsAutoCompleteSearchRequest.useridin = this.authService.useridin;
                  vitalsAutoCompleteSearchRequest['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
                }

                this.landingPageService.getVitalsAutoCompleteSearchResponse(vitalsAutoCompleteSearchRequest).subscribe(
                  response => {
                    try {
                      if (response.result && response.result < 0) {
                        this.setServiceAlert(response['displaymessage'], AlertType.Failure);

                        return;
                      } else {
                        this.clearServiceAlert();
                      }

                      this.autoCompleteOptionsForSearchText = [];
                      const conditionList = new FadAutoCompleteOptionForSearchText().setCategory('');
                      const doctorsList = new FadAutoCompleteOptionForSearchText().setCategory(
                        `${FadConstants.text.allDoctorOptionText}"${searchText}"`
                      );
                      const facilityList = new FadAutoCompleteOptionForSearchText().setCategory(
                        `${FadConstants.text.allHospitalsOrFacilitiesText}"${searchText}"`
                      );

                      if (response.searchSpecialties) {
                        response.searchSpecialties.map(speciality => {
                          const conditionOption: FadAutoCompleteComplexOptionInterface = new FadAutoCompleteComplexOption();
                          conditionOption
                            .setSimpleText(speciality.name)
                            .setProcedure(speciality.isProcedure)
                            .setDescriptionText(speciality.procedureDescription)
                            .setInfoText(FadConstants.text.speciality)
                            .setResourceTypeCode(speciality.resourceTypeCode as FadResourceTypeCode);

                          if (speciality.isProcedure === true) {
                            conditionOption.setProcedureId(speciality.id);
                          } else {
                            conditionOption.setSpecialityId(speciality.id);
                          }
                          conditionList.options.push(conditionOption);
                        });
                      }

                      if (response.professionals) {
                        response.professionals.map(professional => {
                          const doctorNameOption: FadAutoCompleteComplexOptionInterface = new FadAutoCompleteComplexOption();
                          doctorNameOption
                            .setContextText(professional.name)
                            .setInfoText(professional.specialty)
                            .setNetworkId(professional.id)
                            .setLocationId(professional.locationId)
                            .setResourceTypeCode(FadResouceTypeCodeConfig.professional);
                          doctorsList.options.push(doctorNameOption);
                        });
                      }

                      if (response.facilities) {
                        response.facilities.map(facility => {
                          const facilityNameOption: FadAutoCompleteComplexOptionInterface = new FadAutoCompleteComplexOption();
                          facilityNameOption
                            .setContextText(facility.name)
                            .setInfoText(facility.specialty)
                            .setNetworkId(facility.id)
                            .setLocationId(facility.locationId)
                            .setResourceTypeCode(FadResouceTypeCodeConfig.facility);
                          facilityList.options.push(facilityNameOption);
                        });
                      }

                      if (conditionList.options.length) {
                        this.autoCompleteOptionsForSearchText.push(conditionList);
                      }

                      if (doctorsList.options.length) {
                        this.autoCompleteOptionsForSearchText.push(doctorsList);
                      }

                      if (facilityList.options.length) {
                        this.autoCompleteOptionsForSearchText.push(facilityList);
                      }
                      if (this.autoCompleteOptionsForSearchText && this.autoCompleteOptionsForSearchText.length > 0) {
                        this.landingPageService.setCachedSearchTextLookupOptions(
                          `${searchText}~${selectedZipCodeOptions ? selectedZipCodeOptions.getGeo() : ''}`,
                          Object.assign([], this.autoCompleteOptionsForSearchText)
                        );
                      }

                      this.filteredAutoCompleteSearchOptions = Observable.of(this.filterAutoCompleteSearchOptions(searchText));
                    } catch (exception) {
                      this.bcbsmaErrorHandler.logError(
                        exception,
                        BcbsmaConstants.modules.fadModule,
                        FadConstants.components.fadLandingPageComponent,
                        FadConstants.methods.ngOnInit
                      );
                    }
                  },
                  error => {
                    this.bcbsmaErrorHandler.handleHttpError(
                      error,
                      BcbsmaConstants.modules.fadModule,
                      FadConstants.services.landingPageService,
                      FadConstants.methods.getVitalsAutoCompleteSearchResponse
                    );
                  },
                  () => {
                    this.landingPageService.showAutoCompleteDropDownSpinner = false;
                  }
                );
              } else {
                this.autoCompleteOptionsForSearchText = this.defaultAutoCompleteSearchOption;
                this.filteredAutoCompleteSearchOptions = Observable.of(this.filterAutoCompleteSearchOptions(searchText));
              }
            } catch (exception) {
              this.bcbsmaErrorHandler.logError(
                exception,
                BcbsmaConstants.modules.fadModule,
                FadConstants.components.fadLandingPageComponent,
                FadConstants.methods.ngOnInit
              );
            }
          },
          error => {
            this.bcbsmaErrorHandler.handleHttpError(
              error,
              BcbsmaConstants.modules.fadModule,
              FadConstants.services.searchTypeAheadControl_valueChanges,
              FadConstants.methods.valueChanges
            );
          }
        );
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.enhancedSearchAfterInitData
      );
    }
  }

  /**
   * @description update the zipcode field from local storage of application;
   */
  private updateZipCodeFieldFromApplicationStorage() {
    try {
      if (this.zipCodeTypeAheadTrigger && this.zipCodeTypeAheadTrigger._element) {
        let cachedCityZip: FZCSRCity = new FZCSRCity();

        if (this.getLocalStorageZipCodeOption) {
          const zipCodeOptionInLocalStorage = Object.assign(Object.create(new FZCSRCity()), this.getLocalStorageZipCodeOption);
          let _zipInLS = false;
          let _cityInLS = false;
          let _StateCodeInLS = false;
          if (zipCodeOptionInLocalStorage.zip && zipCodeOptionInLocalStorage.getZip()) {
            if (zipCodeOptionInLocalStorage.getZip().trim) {
              _zipInLS = !!zipCodeOptionInLocalStorage.getZip().trim();
            }
          }

          if (zipCodeOptionInLocalStorage.getCity && zipCodeOptionInLocalStorage.getCity()) {
            if (zipCodeOptionInLocalStorage.getCity().trim) {
              _cityInLS = !!zipCodeOptionInLocalStorage.getCity().trim();
            }
          }

          if (zipCodeOptionInLocalStorage.getCity && zipCodeOptionInLocalStorage.getCity()) {
            if (zipCodeOptionInLocalStorage.getCity().trim) {
              _StateCodeInLS = !!zipCodeOptionInLocalStorage.getCity().trim();
            }
          }

          if (_zipInLS && _cityInLS && _StateCodeInLS) {
            cachedCityZip = new FZCSRCity();
            cachedCityZip
              .setZip(this.getLocalStorageZipCodeOption.zip)
              .setCity(this.getLocalStorageZipCodeOption.city)
              .setState_code(this.getLocalStorageZipCodeOption.state_code)
              .setGeo(this.getLocalStorageZipCodeOption.geo);
          }
        }

        if (cachedCityZip) {
          this.fadSearchResultsService.setLastSelectedZipCodeOption(cachedCityZip);
          const zipCodeText = cachedCityZip.getDisplayValue();
          this.searchControls.zipCodeTypeAheadControl.setValue(zipCodeText);
          this.zipCodeTypeAheadTrigger._element.nativeElement.value = zipCodeText;
          this.zipCodeOptions.push(cachedCityZip);
        }
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.updateZipCodeFieldFromApplicationStorage
      );
    }
  }

  /**
   * @description helps prepare a list of options to be displayed in the auto complete drop down list for the plan field
   * @param searchText :string
   * @return FadAutoCompleteOptionForSearchText[] - options used to display data in the auto complete drop down typeahead list
   * for the plan field
   */
  private filterAutoCompletePlanOptions(searchText: string): FadAutoCompleteOptionForSearchText[] {
    this.textToHighlightInPlanOption = searchText;

    let filteredOptions: FadAutoCompleteOptionForSearchText[] = [];
    try {
      if (this.isAuthenticatedUser() && this.userCurrentPlan.getName()) {
        filteredOptions.push(
          new FadAutoCompleteOptionForSearchText().addOption(
            new FadAutoCompleteComplexOption()
              .setInfoText(FadConstants.plans.myCurrentPlanOption)
              .setContextText(this.userCurrentPlan.getName())
              .setNetworkId(this.userCurrentPlan.getId())
          )
        );
      } else if (this.isAuthenticationRequired()) {
        filteredOptions.push(
          new FadAutoCompleteOptionForSearchText().addOption(
            new FadAutoCompleteComplexOption()
              .setInfoText(FadConstants.plans.dontKnowPlanOption)
              .setNetworkId(FadConstants.plans.dontKnowPlanOptionId)
          )
        );
      } else if (this.isAnonymousUser()) {
        filteredOptions.unshift(
          new FadAutoCompleteOptionForSearchText().addOption(
            new FadAutoCompleteComplexOption().setInfoText(FadConstants.plans.defaultOption)
          )
        );
      }
      if (!this.fadInfo.customAccount) {
        filteredOptions.push(
          new FadAutoCompleteOptionForSearchText().addOption(
            new FadAutoCompleteComplexOption()
              .setInfoText(FadConstants.plans.medexMedexChoiceOrDentalMember)
              .setContextText('Are you a Medex, Medex Choice, or Dental Member?')
          )
        );
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.filterAutoCompleteSearchOptions
      );
    }

    if (filteredOptions.length && filteredOptions[0].options.length) {
      const firstOption: FadAutoCompleteComplexOptionInterface = filteredOptions[0].options[0];
      if (!firstOption.getContextText()) {
        if (!firstOption.getInfoText()) {
          if (!firstOption.getSimpleText()) {
            filteredOptions.splice(0, 1);
          }
        }
      }
    }

    return filteredOptions;
  }

  /**
   * @description helps prepare a list of options for defaulted plan option
   * @param searchText :string
   * @return FadAutoCompleteOptionForSearchText[] - options used to display data in the auto complete
   * drop down typeahead list
   * for the plan field
   */
  public pushDefaultAutoCompletePlanOption(searchText: string): FadAutoCompleteOptionForSearchTextInterface[] {
    const filteredOptions: FadAutoCompleteOptionForSearchText[] = [];
    try {
      const defaultPlanArrary = [
        FadConstants.plans.myCurrentPlanOption,
        FadConstants.plans.dontKnowPlanOption,
        FadConstants.plans.defaultOption
      ];

      if (
        this.landingPageService.getCachedSearchControlState() &&
        this.searchControls.planControl.value &&
        this.searchControls.planControl.value.profileId &&
        !defaultPlanArrary.includes(this.searchControls.planControl.value.infoText)
      ) {
        filteredOptions.push(new FadAutoCompleteOptionForSearchText().addOption(this.searchControls.planControl.value));
      }

      if (this.isAuthenticatedUser() && this.userCurrentPlan.getName()) {
        filteredOptions.push(
          new FadAutoCompleteOptionForSearchText().addOption(
            new FadAutoCompleteComplexOption()
              .setInfoText(FadConstants.plans.myCurrentPlanOption)
              .setContextText(this.userCurrentPlan.getName())
              .setNetworkId(this.userCurrentPlan.getId())
          )
        );
      } else if (this.isAuthenticationRequired()) {
        filteredOptions.push(
          new FadAutoCompleteOptionForSearchText().addOption(
            new FadAutoCompleteComplexOption()
              .setInfoText(FadConstants.plans.dontKnowPlanOption)
              .setNetworkId(FadConstants.plans.dontKnowPlanOptionId)
          )
        );
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.pushDefaultAutoCompletePlanOption
      );
    }

    return filteredOptions;
  }

  /**
   * @description  helps prepare a list of options to be displayed in the auto complete search results when user types
   * a minimum of 3 characters in the Search for a doctor/facility/provider field
   * @param searchText :string
   * @return FadAutoCompleteOptionForSearchText[] - options used to display data in the auto complete drop down typeahead list
   */
  private filterAutoCompleteSearchOptions(searchText: string): FadAutoCompleteOptionForSearchText[] {
    let filteredOptions: FadAutoCompleteOptionForSearchText[] = [];
    try {
      if (searchText && searchText.length > 2) {
        this.textToHighlightInSearchTextOption = searchText;
        this.autoCompleteOptionsForSearchText.map(autoCompleteOption => {
          if (
            autoCompleteOption.category ||
            (autoCompleteOption.category === '' && autoCompleteOption.options && autoCompleteOption.options.length > 0)
          ) {
            filteredOptions.push(autoCompleteOption);
          } else {
            const matchingOptionTexts = autoCompleteOption.options.filter(option => {
              return (
                option
                  .getSimpleText()
                  .toLowerCase()
                  .indexOf(searchText.toLowerCase()) !== -1
              );
            });

            if (matchingOptionTexts.length) {
              const matchingOption: FadAutoCompleteOptionForSearchText = new FadAutoCompleteOptionForSearchText();
              matchingOption.category = autoCompleteOption.category;
              matchingOption.options = matchingOptionTexts;

              filteredOptions.push(matchingOption);
            }
          }
        });
      }

      if (!filteredOptions.length) {
        filteredOptions = this.defaultAutoCompleteSearchOption;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.filterAutoCompleteSearchOptions
      );
    }

    return filteredOptions;
  }

  /**
   * @description get plan id from selected plan option
   */
  private getPlanIdFromPlanDetails() {
    try {
      return this.searchControls.planControl.value ? this.searchControls.planControl.value.profileId : null;
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.getPlanIdFromPlanDetails
      );
    }
  }

  /**
   * @description display the selected plan option name on the search text
   */
  public displaySelectedPlanOptionName(state) {
    try {
      if (state) {
        return state.contextText || state.simpleText;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.displaySelectedPlanOptionName
      );
    }
  }

  /**
   * @description proceed with the auto complete option search
   */
  public async selectAutoCompleteSearchTextOption(optionObj: FadAutoCompleteComplexOption) {
    try {
      let plannetworkFlag;
      const zipCode = this.searchControls.zipCodeTypeAheadControl.value;
      const plan = !this.searchControls.planControl.value || !this.searchControls.planControl.value.networkId;

      if (
        this.searchControls.planControl.value.networkId == 'undefined' ||
        this.searchControls.planControl.value.networkId == undefined ||
        this.searchControls.planControl.value.networkId == null
      ) {
        plannetworkFlag = false;
        this.planValidationErrors.invalidPlan.display = true;
      } else {
        plannetworkFlag = true;
      }
      const searchCriteria = this.searchControls.getValues(this.fadSearchResultsService);

      searchCriteria.setSearchText(optionObj);
      this.fadSearchResultsService.setLastSelectedSearchTextOption(optionObj);
      this.fadSearchResultsService.setSearchCriteria(searchCriteria);

      if (
        this.searchControls.zipCodeTypeAheadControl.value &&
        this.searchControls.zipCodeTypeAheadControl.value.trim() &&
        this.searchControls.planControl.value &&
        plannetworkFlag
      ) {
        if (optionObj.getResourceTypeCode() === FadResouceTypeCodeConfig.professional) {
          const getDoctorProfileRequest: DoctorProfileSearchRequestModelInterface = new DoctorProfileSearchRequestModel();
          const selectedZipCodeOptions: FZCSRCity = this.searchControls.getValues(this.fadSearchResultsService).getZipCode();

          getDoctorProfileRequest.professionalid = optionObj.getNetworkId().toString();
          getDoctorProfileRequest.geo_location = selectedZipCodeOptions ? selectedZipCodeOptions.getGeo() : '';
          getDoctorProfileRequest.network_id = this.fadSearchResultsService.getLastSelectedPlanOption()
            ? this.fadSearchResultsService
                .getLastSelectedPlanOption()
                .getNetworkId()
                .toString()
            : '';
          getDoctorProfileRequest.locationId = optionObj.getLocationId().toString();

          this.doctorProfileService.doctorProfile = optionObj.getNetworkId();
          sessionStorage.setItem('professionalId', optionObj.getNetworkId().toString());
          sessionStorage.setItem('locationId', optionObj.getLocationId().toString());
          this.router.navigate([FadConstants.urls.fadDoctorProfilePage]);
        } else if (optionObj.getResourceTypeCode() === FadResouceTypeCodeConfig.facility) {
          this.facilityProfileService.facilityProfile = optionObj.getNetworkId();
          sessionStorage.setItem('facilityProfileId', optionObj.getNetworkId().toString());

          sessionStorage.setItem('locationId', optionObj.getLocationId().toString());
          this.router.navigate([FadConstants.urls.fadFacilityProfilePage]);
        }
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.selectAutoCompleteSearchTextOption
      );
    }
  }

  /**
   * @description proceed with the auto complete optgroup option search
   */
  public searchTypeOptLableClickHandler(e) {
    try {
      const zipCode = this.searchControls.zipCodeTypeAheadControl.value;
      const plan = !this.searchControls.planControl.value || !this.searchControls.planControl.value.networkId;

      const optGroupParentElement: boolean = e.target.parentElement.classList.contains('clickable-label');
      this.isPageReload = false;
      if (optGroupParentElement && e.target.className.split(' ').indexOf('mat-optgroup-label') >= 0) {
        try {
          if (this.viewPortWidth < 993) {
            this.emboseSearchTextFieldOnScreen(false);
          }

          if (e.target && e.target.innerText && e.target.innerText.indexOf(FadConstants.text.allDoctorOptionText) === 0) {
            const searchControlValues: FadLandingPageSearchControlValues = this.searchControls.getValues(this.fadSearchResultsService);
            const searchTextOption = new FadAutoCompleteComplexOption();

            searchTextOption.setSimpleText(e.target.innerText.trim());
            searchTextOption.setResourceTypeCode(FadResouceTypeCodeConfig.professional);
            searchControlValues.setSearchText(searchTextOption);

            this.searchControls.setValues(searchControlValues);
            this.fadSearchResultsService.setSearchCriteria(searchControlValues);

            this.fadSearchResultsService.setLastSelectedSearchTextOption(searchTextOption);
            if (!this.isSearchButtonDisabled()) {
              this.searchControls.setValues(searchControlValues);
              this.doSearch();
            } else {
              try {
                this.searchTextTypeAheadTrigger._onChange(this.searchControls.searchTypeAheadControl.value);
                this.searchTextTypeAheadTrigger.closePanel();
              } finally {
                this.stripAllDoctorFacilityTextAndUpdateUI(this.searchControls.searchTypeAheadControl.value);
              }
            }
          } else if (e.target && e.target.innerText && e.target.innerText.indexOf(FadConstants.text.allHospitalsOrFacilitiesText) === 0) {
            const searchControlValues: FadLandingPageSearchControlValues = this.searchControls.getValues(this.fadSearchResultsService);

            const searchTextOption = new FadAutoCompleteComplexOption();
            searchTextOption.setSimpleText(e.target.innerText.trim());
            searchTextOption.setResourceTypeCode(FadResouceTypeCodeConfig.facility);

            searchControlValues.setSearchText(searchTextOption);
            this.fadSearchResultsService.setSearchCriteria(searchControlValues);

            this.fadSearchResultsService.setLastSelectedSearchTextOption(searchTextOption);
            if (!this.isSearchButtonDisabled()) {
              this.searchControls.setValues(searchControlValues);
              if (this.searchControls.zipCodeTypeAheadControl.value && this.searchControls.zipCodeTypeAheadControl.value.trim()) {
                this.doSearch();
              }
            } else {
              try {
                this.searchTextTypeAheadTrigger._onChange(this.searchControls.searchTypeAheadControl.value);
                this.searchTextTypeAheadTrigger.closePanel();
              } finally {
                this.stripAllDoctorFacilityTextAndUpdateUI(this.searchControls.searchTypeAheadControl.value);
              }
            }
          } else {
            setTimeout(() => {
              try {
                this.searchTextTypeAheadTrigger._onChange(this.searchControls.searchTypeAheadControl.value);
                this.searchTextTypeAheadTrigger.closePanel();
                if (!this.isSearchButtonDisabled()) {
                  if (this.searchControls.zipCodeTypeAheadControl.value && this.searchControls.zipCodeTypeAheadControl.value.trim()) {
                    this.doSearch();
                  }
                }
              } finally {
                // IGNORE ERROR - IT WILL RESULT IN ANGULAR ERROR ON AUTOMATIC FOCUS TO SEARCH FIELD ON PAGE LOAD
              }
            }, 100);
          }
        } catch (exception) {
          this.bcbsmaErrorHandler.logError(
            exception,
            BcbsmaConstants.modules.fadModule,
            FadConstants.components.fadLandingPageComponent,
            FadConstants.methods.searchTypeOptLableClickHandler
          );
        }
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.searchTypeOptLableClickHandler
      );
    }
  }

  /**
   * @description display error message if there is an invalid input
   */
  zipcodeValidator(zipText) {
    try {
      setTimeout(() => {
        this.zipcodeResponseValidator();
      }, 1000);
      const validZipCodeRegxp = /^(?:[\d\s-]+|[a-zA-Z\s-]+)$/; // alphanumeric validator
      this.zipCodeValidationErrors.invalidZipCode.exists =
        !zipText || (zipText && (zipText.trim() === '' || !validZipCodeRegxp.test(zipText)));
      if (this.zipCodeValidationErrors.invalidZipCode.exists === true) {
        this.zipCodeValidationErrors.invalidZipCode.display = true;
        this.zipCodeValidationErrors.noMatchFound.display = false;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.zipcodeValidator
      );
    }
  }

  dyanamicplanhandleData() {
    if (!this.landingPageService.cachedResponse.planOptions || this.customAccount) {
      const planOption = new FadAutoCompleteOptionForSearchText();
      this.planOptions = [];
      this.fadNetworkList = [];
      if (this.fadInfo && this.fadInfo.result && this.fadInfo.result < 0) {
        this.setServiceAlert(this.fadInfo['displaymessage'], AlertType.Failure);

        return;
      } else if (this.fadInfo && this.fadInfo.networks) {
        this.clearServiceAlert();

        if (this.fadInfo.networks) {
          this.fadInfo.networks.map(_network => {
            const network: FadVitalsNetworkInterface = Object.assign(new FadVitalsNetwork(), _network);
            const plan: FPSRPlan = Object.assign(new FPSRPlan(), network.getNetwork());
            planOption.addOption(new FadAutoCompleteComplexOption().setSimpleText(plan.getName()).setNetworkId(plan.getId()));
            if (plan.getPlanIndicator()) {
              this.userCurrentPlan = plan;
            }
          });
        }
      } else {
        return;
      }

      this.planOptions.push(planOption);
      this.defaultPlanOptions = this.planOptions;
      this.landingPageService.cachedResponse.planOptions = this.planOptions;
    } else {
      this.planOptions = this.landingPageService.cachedResponse.planOptions;
      this.defaultPlanOptions = this.planOptions;
    }
    const networkFilteredData = this.filterAutoCompletePlanOptions('');
    networkFilteredData.forEach(options => {
      options.options.forEach(option => {
        this.fadNetworkList.push(option);
      });
    });
    const selnetworkIndex = sessionStorage.getItem('selNetworkIdx');
    this.allnetworksList = this.planOptions[0].options;
    if (selnetworkIndex) {
      this.selectedNetworkOption = this.planOptions[0].options[selnetworkIndex];
    } else {
      if (this.isAuthenticatedUser() && this.userCurrentPlan.getName()) {
        this.selectedNetworkOption = this.planOptions[0].options[0];
      }
    }
  }
  planValidator(planName) {
    // clean up
    this.planValidationErrors.noMatchFound.display = false;
    this.planValidationErrors.invalidPlan.display = false;

    if (!planName || !planName.trim || planName.trim().length === 0) {
      this.fadSearchResultsService.setLastSelectedPlanOption(null);
      this.planValidationErrors.invalidPlan.display = true;
    } else if (planName.trim().length > 0) {
      this.planValidationErrors.noMatchFound.display =
        this.planOptions.length === 0 ||
        !this.planOptions[0] ||
        !this.planOptions[0].options ||
        this.planOptions[0].options.length === 0 ||
        !this.planOptions[0].options.some(
          planOption =>
            planOption && planName && planOption.getSimpleText && planOption.getSimpleText().toUpperCase() === planName.toUpperCase().trim()
        );
    }
  }

  /**
   * @description hide the location field error message
   */
  removeZipCodeError() {
    try {
      this.zipCodeValidationErrors.invalidZipCode.display = false;
      this.zipCodeValidationErrors.noMatchFound.display = false;
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.removeZipCodeError
      );
    }
  }

  /**
   * @description hide the location field error message
   */
  removePlanError() {
    try {
      this.planValidationErrors.invalidPlan.display = false;
      this.planValidationErrors.noMatchFound.display = false;
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.removePlanError
      );
    }
  }

  /**
   * @description display error message if there is no match found in response
   */
  private zipcodeResponseValidator() {
    try {
      let searchText =
        this.zipCodeTypeAheadTrigger &&
        this.zipCodeTypeAheadTrigger._element &&
        this.zipCodeTypeAheadTrigger._element.nativeElement &&
        this.zipCodeTypeAheadTrigger._element.nativeElement.value;

      searchText = searchText && searchText.trim();
      if (searchText && searchText.length < 3) {
        return;
      }
      const zipFrag = searchText ? searchText.trim().split('-') : '';
      const cachedZipCodeLookupOptions: FZCSRCity[] = this.landingPageService.getCachedZipCodeLookupOptions(
        zipFrag[0] ? zipFrag[0].trim() : ''
      );
      const alphaNumericRegex: RegExp = new RegExp(/^[a-z0-9]+$/i); // alpha numeric
      this.zipCodeValidationErrors.noMatchFound.exists = !!(
        searchText &&
        alphaNumericRegex.test(searchText) &&
        searchText.trim() !== '' &&
        (!cachedZipCodeLookupOptions || (cachedZipCodeLookupOptions && cachedZipCodeLookupOptions.length === 0))
      );

      if (
        alphaNumericRegex.test(searchText) &&
        cachedZipCodeLookupOptions === undefined &&
        this.zipCodeValidationErrors.noMatchFound.exists === undefined
      ) {
        this.zipCodeValidationErrors.noMatchFound.exists = true;
      }

      const cityFrag = zipFrag[1] ? zipFrag[1].trim().split(',') : '';
      if (cityFrag) {
        // it will compare each user input text with response to remove the error message
        const zipCodeOptionsIndex = this.zipCodeOptions.findIndex(
          x => x.zip === zipFrag[0].trim() && cityFrag[0] && cityFrag[1] && x.city === cityFrag[0] && x.state_code === cityFrag[1].trim()
        );
        if (zipCodeOptionsIndex !== -1) {
          this.zipCodeValidationErrors.invalidZipCode.exists = false;
          this.zipCodeValidationErrors.noMatchFound.exists = false;
          this.zipCodeValidationErrors.invalidZipCode.display = false;
          this.zipCodeValidationErrors.noMatchFound.display = false;
        }
      }

      // if user input is not present in cached lookup zipcode options then it will display no match found error message
      if (
        searchText &&
        searchText.length >= 3 &&
        cachedZipCodeLookupOptions &&
        cachedZipCodeLookupOptions.length === 0 &&
        this.zipCodeValidationErrors.invalidZipCode.exists === false &&
        this.zipCodeValidationErrors.noMatchFound.exists === true
      ) {
        this.zipCodeValidationErrors.noMatchFound.display = true;
        this.zipCodeValidationErrors.invalidZipCode.display = false;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.zipcodeResponseValidator
      );
    }
  }

  /**
   * @description hide the search type ahead drop down on e
   */
  private hiddenSearchTypeAheadDropDown(): void {
    try {
      if (this.viewPortWidth < 993) {
        this.emboseSearchTextFieldOnScreen(false);
      }
      setTimeout(() => {
        try {
          this.searchTextTypeAheadTrigger.closePanel();
        } finally {
        }
      }, 100);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.hiddenSearchTypeAheadDropDown
      );
    }
  }

  /**
   * @description set service alerts
   */
  private setServiceAlert(title, type = AlertType.Failure): void {
    try {
      this.fadService.setServiceAlert(title, type, FadConstants.components.fadLandingPageComponent);
      this.hiddenSearchTypeAheadDropDown();
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.serviceAlert
      );
    }
  }

  /**
   * @description clearing the service alerts
   */
  private clearServiceAlert(view = FadConstants.flags.allView): void {
    try {
      switch (view) {
        case FadConstants.flags.allView:
          this.fadService.clearServiceAlert(FadConstants.components.fadLandingPageComponent);
          break;
        case FadConstants.flags.mobileView:
          if (this.viewPortWidth < 993) {
            this.fadService.clearServiceAlert(FadConstants.components.fadLandingPageComponent);
          }
          break;
        default:
          break;
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.clearServiceAlert
      );
    }
  }

  public isAuthenticationRequired() {
    let returnValue = false;
    try {
      if (this.isAnonymousUser()) {
        return false;
      }
      const scopeName = this.authService.getScopeName();
      returnValue = scopeName !== 'AUTHENTICATED-AND-VERIFIED';
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.isAuthenticationRequired
      );
    }
    return returnValue;
  }

  public isAnonymousUser(): boolean {
    let returnValue = false;
    try {
      const userid = this.authService.useridin;
      returnValue = userid && userid !== 'undefined' && userid !== 'null' ? false : true;
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.isAnonymousUser
      );
    }
    this.isUnauthenticatedUser = returnValue;
    return returnValue;
  }

  public isAuthenticatedUser() {
    let returnValue = false;
    try {
      if (this.isAnonymousUser()) {
        return false;
      }
      const scopeName = this.authService.getScopeName();
      returnValue = scopeName === 'AUTHENTICATED-AND-VERIFIED';
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.isAuthenticatedUser
      );
    }
    return returnValue;
  }

  public noop(event?) {
    if (event && event.stopPropagation) {
      event.stopPropagation();
    }
    return false;
  }

  public updateLastSelectedPlanOption() {
    try {
      if (this.planOptions && this.planOptions[0] && this.planOptions[0].options && this.planOptions[0].options.length > 0) {
        this.planOptions[0].options.some(planOption => {
          if (
            planOption &&
            planOption.getSimpleText &&
            this.searchControls.planControl.value &&
            this.searchControls.planControl.value.toUpperCase &&
            planOption.getSimpleText().toUpperCase() === this.searchControls.planControl.value.toUpperCase().trim()
          ) {
            this.fadSearchResultsService.setLastSelectedPlanOption(planOption as FadAutoCompleteComplexOption);
            return true;
          }
        });
      }
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.updateLastSelectedPlanOption
      );
    }
  }

  public isSearchButtonDisabled() {
    let returnValue = true;
    try {
      const userProvidedSearchText = this.searchControls.searchTypeAheadControl.value;
      const userProvidedZipCode = this.searchControls.zipCodeTypeAheadControl.value;
      const userProvidedPlanControl = this.searchControls.planControl.value;

      const effectiveSearchText = userProvidedSearchText && userProvidedSearchText.trim ? userProvidedSearchText.trim() : null;
      const effectiveZipCode = userProvidedZipCode && userProvidedZipCode.trim ? userProvidedZipCode.trim() : null;
      let effectivePlanControl = null;
      if (userProvidedPlanControl) {
        if (userProvidedPlanControl.simpleText || userProvidedPlanControl.contextText) {
          effectivePlanControl = userProvidedPlanControl.simpleText.trim ? userProvidedPlanControl.simpleText.trim() : '';
          if (effectivePlanControl === '' && userProvidedPlanControl.contextText && userProvidedPlanControl.contextText.trim) {
            effectivePlanControl = userProvidedPlanControl.contextText.trim();
          }
        } else if (userProvidedPlanControl.trim) {
          effectivePlanControl = userProvidedPlanControl.trim();
        }
      }

      let validSearchText = false;
      if (effectiveSearchText && effectiveSearchText.length > 2) {
        validSearchText = true;
      }

      const zipCodeValue = this.searchControls.zipCodeTypeAheadControl.value;
      const zipCodeValueNotValid = !zipCodeValue || !zipCodeValue.trim || zipCodeValue.trim().length < 3;

      const errors: boolean =
        !!this.zipCodeValidationErrors.noMatchFound.display ||
        !!this.zipCodeValidationErrors.invalidZipCode.display ||
        !!this.planValidationErrors.noMatchFound.display ||
        !!this.planValidationErrors.invalidPlan.display ||
        zipCodeValueNotValid;

      returnValue = errors || !(validSearchText && !!effectiveZipCode && !!effectivePlanControl);
    } catch (exception) {
      this.bcbsmaErrorHandler.logError(
        exception,
        BcbsmaConstants.modules.fadModule,
        FadConstants.components.fadLandingPageComponent,
        FadConstants.methods.isSearchButtonDisabled
      );
    }
    return returnValue;
  }

  private stripAllDoctorFacilityTextAndUpdateUI(searchText: string): string {
    if (searchText && searchText.trim) {
      this.isPageReload = false;
      searchText = searchText.trim();
      if (searchText.indexOf(FadConstants.text.allHospitalsOrFacilitiesText) >= 0) {
        searchText = searchText.replace(FadConstants.text.allHospitalsOrFacilitiesText, '').replace(/["']/g, '');
        setTimeout(() => {
          this.searchControls.searchTypeAheadControl.setValue(searchText);
        }, 10);
      } else if (searchText.indexOf(FadConstants.text.allDoctorOptionText) >= 0) {
        searchText = searchText.replace(FadConstants.text.allDoctorOptionText, '').replace(/["']/g, '');
        setTimeout(() => {
          this.searchControls.searchTypeAheadControl.setValue(searchText);
        }, 10);
      }
    }
    return searchText;
  }

  public changeSelectedMember(event) {
    const chMemberId = event.value;
    sessionStorage.setItem('fadVendorMemberNumber', event.value);

    this.fetchProcedureSummary();
    this.doSearch();
    const memberIndex = this.dependantsList
      .map(function(mem) {
        return mem.fadVendorMemberNumber;
      })
      .indexOf(chMemberId);
    this.selectedMember = this.dependantsList[memberIndex];

    sessionStorage.setItem('selMemIdx', memberIndex.toString());
  }

  getSelectedUserName(memberId?): string {
    const selectedUser =
      this.dependantsList &&
      this.dependantsList.filter(res => {
        return res.fadVendorMemberNumber === memberId;
      });
    if (selectedUser && selectedUser.length === 1) {
      return `${selectedUser[0].subscriberFirstName} ${selectedUser[0].subscriberLastName}`;
    } else {
      return '';
    }
  }

  public helpOnNetwork() {
    this.dialogRef.open(HelpChoosingNetworkComponent);
  }

  public changeNetworkOption(event) {
    setTimeout(() => {
      const networkOption = event.value;
      if (!networkOption) return;
      sessionStorage.setItem('selectednetwork', event.value);
      const networkIndex = this.allnetworksList
        .map(function(mem) {
          return mem;
        })
        .indexOf(networkOption);

      this.bypassPlanFieldFocusLogic = true;
      if (this.userCurrentPlan.getId() == networkOption.networkId) {
        sessionStorage.setItem('networkChange', 'false');
      } else {
        if (this.authService.authToken) {
          if (this.authService.useridin && this.authService.authToken.userType) {
            sessionStorage.setItem('networkChange', 'true');
          }
        }
      }

      if (
        networkOption.infoText !== FadConstants.plans.dontKnowPlanOption &&
        networkOption.infoText !== FadConstants.plans.medexMedexChoiceOrDentalMember
      ) {
        this.fadSearchResultsService.setLastSelectedPlanOption(networkOption);
        if (networkOption.infoText === 'my-current-plan-option') {
          this.selectedNetworkOption = this.planOptions[0].options[0];
          sessionStorage.setItem('selNetworkIdx', this.defaultplanindex.toString());
        } else {
          this.selectedNetworkOption = this.planOptions[0].options[networkIndex];
          sessionStorage.setItem('selNetworkIdx', networkIndex.toString());
        }
        this.networkPlaceHolder = '';

        this.doSearch();
      } else if (networkOption.infoText == FadConstants.plans.medexMedexChoiceOrDentalMember) {
        const selnetworkIndex = sessionStorage.getItem('selNetworkIdx');
        if (selnetworkIndex) {
          this.selectedNetworkOption = this.planOptions[0].options[selnetworkIndex];
        }
        this.helpOnNetwork();
        this.searchControls.planControl.setValue(this.selectedNetworkOption);
      }
    }, 500);
  }
  compareWithFn(o1: any, o2: any) {
    return false;
  }
}
