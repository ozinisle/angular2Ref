import { HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { AuthService, ConstantsService } from '../../../shared/shared.module';
import { HashMapInterface } from '../../financials/models';
import { HashMap } from '../../financials/utils/all-transaction.utilities';
import { FadConstants } from '../constants/fad.constants';
import { FadSearchResultsService } from '../fad-search-results/fad-search-results.service';
import {
  FadAutoCompleteOptionForSearchText,
  FadLandingPageSearchControlsModel,
  FadLandingPageSearchControlValues,
  FadMembersInfoRequestModel
} from '../modals/fad-landing-page.modal';
import { FZCSRCity } from '../modals/fad-vitals-collection.model';
import { GetSearchByProcedureRequestModel } from '../modals/getSearchByProcedure.model';
import { GetToolTipInfoRequestModel } from '../modals/getToolTipInfo.model';
import { GetVitalsTeleHealthDetailsResponseModel } from '../modals/getVitalsTeleHealthDetails.models';
import {
  FadLandingPageSearchControlsModelInterface,
  FadLandingPageSearchControlValuesInterface,
  FadMembersInfoRequestModelInterface,
  FadMembersInfoResponseModelInterface,
  LandingPageResponseCacheModelInterface
} from '../modals/interfaces/fad-landing-page.interface';
import {
  DoctorProfileSearchRequestModelInterface,
  FadVitalsZipCodeSearchRequestModelInterface,
  FadZipCodeSearchResponseModelInterface
} from '../modals/interfaces/fad-vitals-collection.interface';
import {
  GetSearchByFacilityRequestModelInterface,
  GetSearchByFacilityResponseModelInterface
} from '../modals/interfaces/getSearchByFacility-models.interface';
import { GetSearchByProcedureRequestModelInterface } from '../modals/interfaces/getSearchByProcedure-models.interface';
import { GetSearchByProfessionalResponseModelInterface } from '../modals/interfaces/getSearchByProfessional-models.interface';
import {
  GetSearchByProviderRequestModelInterface,
  GetSearchByProviderResponseModelInterface
} from '../modals/interfaces/getSearchByProvider-models.interface';
import { GetToolTipInfoRequestModelInterface } from '../modals/interfaces/getToolTipInfo-models.interface';
import { GetVitalsTeleHealthDetailsResponseInterface } from '../modals/interfaces/getVitalsTeleHealthDetails-models.interface';
import { LeafLetResponseModelInterface } from '../modals/interfaces/leaflet-model.interface';

@Injectable()
export class FadLandingPageService {
  public vitalsZipCodeInfo: FadZipCodeSearchResponseModelInterface = null;
  public cachedResponse: LandingPageResponseCacheModelInterface = null;

  public plannetworkdata = null;
  private cachedSearchControlState: FadLandingPageSearchControlsModelInterface = null;
  private cachedSearchTextLookupOptions: HashMapInterface<FadAutoCompleteOptionForSearchText[]> = new HashMap<
    FadAutoCompleteOptionForSearchText[]
  >();
  private cachedZipCodeLookupOptions: HashMapInterface<FZCSRCity[]> = new HashMap<FZCSRCity[]>();

  public showAutoCompleteDropDownSpinner = false;

  private vitalsTeleHealthDetails: GetVitalsTeleHealthDetailsResponseInterface = null;

  constructor(
    private bcbsmaHttpService: BcbsmaHttpService,
    private http: AuthHttp,
    private authService: AuthService,
    private constants: ConstantsService,
    private fadSearchResultsService: FadSearchResultsService
  ) {}

  getVitalsTeleHealthDetails(): GetVitalsTeleHealthDetailsResponseInterface {
    let vitalsTeleHealthDetails: GetVitalsTeleHealthDetailsResponseInterface = this.vitalsTeleHealthDetails;
    if (!vitalsTeleHealthDetails) {
      let _vitalsTeleHealthDetails = sessionStorage.getItem('vitalsResponse');
      if (_vitalsTeleHealthDetails) {
        _vitalsTeleHealthDetails = JSON.parse(_vitalsTeleHealthDetails);
        vitalsTeleHealthDetails = Object.assign(new GetVitalsTeleHealthDetailsResponseModel(), _vitalsTeleHealthDetails);
      }
    }

    return vitalsTeleHealthDetails;
  }

  setVitalsTeleHealthDetails(vitalsTeleHealthDetails: GetVitalsTeleHealthDetailsResponseInterface) {
    let _vitalsTeleHealthDetails: string = null;
    if (vitalsTeleHealthDetails) {
      try {
        _vitalsTeleHealthDetails = JSON.stringify(vitalsTeleHealthDetails);
      } catch (err) {
        // Noop
      }
    }
    this.vitalsTeleHealthDetails = vitalsTeleHealthDetails;
  }

  public getCachedZipCodeLookupOptions(searchText: string): FZCSRCity[] {
    return this.cachedZipCodeLookupOptions.get(searchText);
  }
  public setCachedZipCodeLookupOptions(searchText: string, zipCodeLookupOptions: FZCSRCity[]): FadLandingPageService {
    this.cachedZipCodeLookupOptions.put(searchText, zipCodeLookupOptions);
    return this;
  }

  public getCachedSearchTextLookupOptions(key: string): FadAutoCompleteOptionForSearchText[] {
    let options: FadAutoCompleteOptionForSearchText[] = this.cachedSearchTextLookupOptions.get(key);
    if (!options) {
      const keyEntities = key.split('~');
      options = this.cachedSearchTextLookupOptions.get(`${keyEntities[0]}~`);
    }
    return options;
  }

  public setCachedSearchTextLookupOptions(searchText: string, lookupOptions: FadAutoCompleteOptionForSearchText[]): FadLandingPageService {
    this.cachedSearchTextLookupOptions.put(searchText, lookupOptions);
    return this;
  }

  getVitalsAutoCompleteSearchResponse(
    request: GetSearchByProviderRequestModelInterface
  ): Observable<GetSearchByProviderResponseModelInterface> {
    this.showAutoCompleteDropDownSpinner = true;
    if (this.authService.getFadHccsFlag() !== null) {
      request['hccsFlag'] = this.authService.getFadHccsFlag();
    }

    const url = FadConstants.urls.fadLandingPageSearchAutocompleteListUrl;

    // adhoc fix for KLO-1722
    // fix is to call encryptFadPost instead of encryptPost
    return this.http.encryptFadPost(url, request, '', '', false);
  }

  getVitalsZipCodeInfo(
    vitalsZipCodeSearchRequest: FadVitalsZipCodeSearchRequestModelInterface
  ): Observable<FadZipCodeSearchResponseModelInterface> {
    let url;

    if (vitalsZipCodeSearchRequest.city || vitalsZipCodeSearchRequest.zip || vitalsZipCodeSearchRequest.state) {
      url = `${FadConstants.urls.fadLandingPageZipcodeAutocompleteListUrl}?city=${vitalsZipCodeSearchRequest.city}&state_code=${vitalsZipCodeSearchRequest.state}&zip=${vitalsZipCodeSearchRequest.zip}`;
    } else if (
      vitalsZipCodeSearchRequest.lat &&
      vitalsZipCodeSearchRequest.lng &&
      vitalsZipCodeSearchRequest.sort &&
      vitalsZipCodeSearchRequest.limit
    ) {
      url = `${FadConstants.urls.fadLandingPageZipcodeAutocompleteListUrl}?limit=${vitalsZipCodeSearchRequest.limit}&lat=${vitalsZipCodeSearchRequest.lat}&lng=${vitalsZipCodeSearchRequest.lng}&sort=${vitalsZipCodeSearchRequest.sort}`;
    } else {
      url = `${FadConstants.urls.fadLandingPageZipcodeAutocompleteListUrl}?limit=${vitalsZipCodeSearchRequest.limit}&place=${vitalsZipCodeSearchRequest.place}`;
    }
    const httpOptions = {
      headers: new HttpHeaders({
        uitxnid: 'WEB_v3.0_' + this.http.uuid()
      })
    };
    httpOptions.headers = this.http.addHeaderForImpersonation(httpOptions.headers);
    return this.http.get(url, httpOptions, false);
  }

  getVitalsDependantList(): Observable<FadMembersInfoResponseModelInterface> {
    const request: FadMembersInfoRequestModelInterface = new FadMembersInfoRequestModel();
    request.useridin = this.authService.useridin;
    if (this.authService.getFadHccsFlag() !== null) {
      request['hccsFlag'] = this.authService.getFadHccsFlag();
    }

    const url = FadConstants.urls.fadLandingPageDependentsListUrl;

    // adhoc fix for KLO-1722
    // fix is to call encryptFadPost instead of encryptPost
    return this.http.encryptPost(url, request).map(response => {
      // adhoc fix for KLO-1722
      // this map method is the adhoc fix
      if (response.result === -92829) {
        sessionStorage.setItem('isUserNotMemberInCHC', 'true');
        this.authService.isUserNotMemberInCHC = true;
      }
      return response;
    });
  }

  getProcedureSummary() {
    const ProcedureSearchReq: GetSearchByProcedureRequestModelInterface = new GetSearchByProcedureRequestModel();
    ProcedureSearchReq.setUserId(this.authService.useridin).setLocale(FadConstants.defaults.locale + '');
    if (this.authService.getFadHccsFlag() !== null) {
      ProcedureSearchReq['hccsFlag'] = this.authService.getFadHccsFlag();
    }
    if (sessionStorage.getItem('fadVendorMemberNumber')) {
      ProcedureSearchReq['fadVendorMemberNumber'] = sessionStorage.getItem('fadVendorMemberNumber');
    }
    const url = FadConstants.urls.fadVitalsProcedureUrl;
    // adhoc fix for KLO-1722
    // fix is to call encryptFadPost instead of encryptPost
    return this.http.encryptFadPost(url, ProcedureSearchReq, null, null, true);
  }
  getCachedSearchControlState(): FadLandingPageSearchControlsModelInterface {
    return this.cachedSearchControlState;
  }

  setCachedSearchControlState(
    searchControlState: FadLandingPageSearchControlsModelInterface | FadLandingPageSearchControlValuesInterface
  ): FadLandingPageService {
    this.cachedSearchControlState = new FadLandingPageSearchControlsModel();
    if (searchControlState instanceof FadLandingPageSearchControlsModel) {
      this.cachedSearchControlState.setControls(
        searchControlState as FadLandingPageSearchControlsModelInterface,
        this.fadSearchResultsService
      );
    } else {
      this.cachedSearchControlState.setValues(searchControlState as FadLandingPageSearchControlValues);
    }
    return this;
  }

  clearCachedSearchControlState(): FadLandingPageService {
    this.cachedSearchControlState = null;
    return this;
  }

  getLocationFromLatLong(position: Position): Observable<LeafLetResponseModelInterface> {
    let params = new HttpParams();
    params = params.append('access_token', FadConstants.text.leafLetAccessToken);
    params = params.append('types', FadConstants.text.leafLetGeoCodingQueryTypes.join(','));

    const url = this.constants.leafLetGecodingVersionUrl + '/' + position.coords.longitude + ',' + position.coords.latitude + '.json';
    return this.bcbsmaHttpService.get(url, { params: params });
  }

  getDoctorProfileDetails(request: DoctorProfileSearchRequestModelInterface): Observable<GetSearchByProfessionalResponseModelInterface> {
    request.userid = this.authService.useridin;

    const url = FadConstants.jsonurls.fadGetDoctorProfile;

    return this.bcbsmaHttpService.get(url);
  }

  getFacilityProfileDetails(request: GetSearchByFacilityRequestModelInterface): Observable<GetSearchByFacilityResponseModelInterface> {
    const url = FadConstants.urls.fadGetFacilityProfile;
    return this.bcbsmaHttpService.get(url);
  }

  getToolTipInfo() {
    const ToolTipReq: GetToolTipInfoRequestModelInterface = new GetToolTipInfoRequestModel();
    if (this.authService.useridin && this.authService.useridin != 'undefined') {
      ToolTipReq.setUserId(this.authService.useridin);
    }
    ToolTipReq['categoryType'] = 'All';
    const url = FadConstants.urls.fadVitalsToolTipsInfo;

    // adhoc fix for KLO-1722
    // fix is to call encryptFadPost instead of encryptPost
    return this.http.encryptFadPost(url, ToolTipReq, null, null, true);
  }
}
