import { Injectable } from '@angular/core';
import { BcbsmaHttpService } from '../../../shared/services/bcbsma-http.service';
import { FadConstants } from '../constants/fad.constants';
import { FadCostBenefitsModel, FadFacilityCostModel } from '../modals/fad-facility-profile-details.model';
import { FadCostBenefitsInterface, FadFacilityCostInterface } from '../modals/interfaces/fad-facility-profile-details.interface';

@Injectable()
export class FadCostBreakdownService {
  public costBenefitsData: FadCostBenefitsInterface = new FadCostBenefitsModel();
  public facilityCostData: FadFacilityCostInterface = new FadFacilityCostModel();
  public parentPage: string;
  public facilityData: any;
  public providerName: string;
  constructor(private bcbsmaHttpService: BcbsmaHttpService) { }

  public getCostBreakDown() {
    const url = FadConstants.jsonurls.fadCostBreakDownUrl;

    return this.bcbsmaHttpService.get(url);
  }
}
