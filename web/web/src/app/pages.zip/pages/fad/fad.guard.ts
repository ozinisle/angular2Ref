import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AuthService } from '../../shared/shared.module';
declare let $: any;

@Injectable()
export class FadGuard implements CanActivate {
  constructor(private router: Router, private authService:AuthService) {}

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    if (this.isUserAuthenticatedAndVerified()) {
      const postLoginInfo = sessionStorage.getItem('postLoginInfo');
      if (postLoginInfo) {
        const postLoginInfoJson = JSON.parse(postLoginInfo);
        if (postLoginInfoJson.hasCI || postLoginInfoJson.hasSS || postLoginInfoJson.hasSSO) {
          this.openFadSsoSite();
          this.router.navigate(['/home']);  
          return false;
        }
      } else {
        this.router.navigate(['/home']);
        return false;
      }
    }
    return true;
  }

  openFadSsoSite() {
    if(!this.authService.impersonation()){
      sessionStorage.setItem('consentLink', '/sso/vitals');
      $('#openSsoFadSite').modal('open');
    }
  }


  isUserAuthenticatedAndVerified() {
    const authTokenDetails = sessionStorage.getItem('authToken');
    if (authTokenDetails && authTokenDetails !== 'undefined') {
      const authTokenDetailsJson = JSON.parse(authTokenDetails);
      if (authTokenDetailsJson && authTokenDetailsJson.scopename === 'AUTHENTICATED-AND-VERIFIED') {
        return true;
      }
    }
    return false;
  }
}
