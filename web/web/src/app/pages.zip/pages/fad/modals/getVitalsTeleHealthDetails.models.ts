import {
  GetVitalsTeleHealthDetailsResponseInterface,
  GetVitalsTeleHealthDetailsRequestInterface,
  PlatformProvider
} from './interfaces/getVitalsTeleHealthDetails-models.interface';
import { GeneralError } from '../../../shared/models/generic-app.model';

export class GetVitalsTeleHealthDetailsResponseModel extends GeneralError implements GetVitalsTeleHealthDetailsResponseInterface {
  teleHealthEligible: boolean;
  platformProvider: PlatformProvider;
}

export class GetVitalsTeleHealthDetailsRequestModel implements GetVitalsTeleHealthDetailsRequestInterface {
  useridin: string;
}
