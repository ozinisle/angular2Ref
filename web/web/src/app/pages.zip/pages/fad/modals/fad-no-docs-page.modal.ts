import { FadNoDocsPageInputDataModelInterface } from './interfaces/fad-no-docs-page.interface';

export class FadNoDocsPageInputDataModel implements FadNoDocsPageInputDataModelInterface {
    type: string;
}
