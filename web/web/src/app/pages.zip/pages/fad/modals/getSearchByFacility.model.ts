import { GeneralError } from '../../../shared/models/generic-app.model';
import { FilterCheckboxItem, FilterListItem } from './fad-search-filter.modal';
import { FadLocationDetails, FadReviewsList } from './getSearchByProfessional.model';
import {
  FacetsFacilityListInterface,
  FacilityFiltersMetadataInterface,
  FadFacilityInterface,
  FadPdfRequestInterface,
  FadSearchParamsInterface,
  FadTiersInterface,
  GetSearchByFacilityRequestModelInterface,
  GetSearchByFacilityResponseModelInterface
} from './interfaces/getSearchByFacility-models.interface';
import { CostDetails, Disclaimers } from './interfaces/getSearchByProfessional-models.interface';

// tslint:disable-next-line:no-empty-interface
export class GetSearchByFacilityRequestModel implements GetSearchByFacilityRequestModelInterface {
  geoLocation: string;
  limit: number;
  page: number;
  radius: number;
  networkId: number;
  searchSpecialtyId: string;
  name: string;
  searchForTH: boolean;

  sort: string;
  procedureId: string;
  aggregateOverallRating: string;
  awardId: string;
  cqmId: string;
  bdcId: string;
  useridin: string;
  tiers: string;

  getGeoLocation(): string {
    return this.geoLocation;
  }

  setGeoLocation(geoLocation: string): GetSearchByFacilityRequestModel {
    this.geoLocation = geoLocation;
    return this;
  }

  getLimit(): number {
    return this.limit;
  }

  setLimit(limit: number): GetSearchByFacilityRequestModel {
    this.limit = limit;
    return this;
  }

  getPage(): number {
    return this.page;
  }

  setPage(page: number): GetSearchByFacilityRequestModel {
    this.page = page;
    return this;
  }

  getTiers(): string {
    return this.tiers;
  }

  setTiers(tiers: string): GetSearchByFacilityRequestModel {
    this.tiers = tiers;
    return this;
  }

  getRadius(): number {
    return this.radius;
  }

  setRadius(radius: number): GetSearchByFacilityRequestModel {
    this.radius = radius;
    return this;
  }

  getNetworkId(): number {
    return this.networkId;
  }

  setNetworkId(networkId: number): GetSearchByFacilityRequestModel {
    this.networkId = networkId;
    return this;
  }

  getSearchSpecialtyId(): string {
    return this.searchSpecialtyId;
  }

  setSearchSpecialtyId(searchSpecialtyId: string): GetSearchByFacilityRequestModel {
    this.searchSpecialtyId = searchSpecialtyId;
    return this;
  }

  getName(): string {
    return this.name;
  }

  setName(name: string): GetSearchByFacilityRequestModel {
    this.name = name;
    return this;
  }

  getUserIdIn(): string {
    return this.useridin;
  }

  setUserIdIn(useridin: string): GetSearchByFacilityRequestModel {
    this.useridin = useridin;
    return this;
  }

  getSort(): string {
    return this.sort;
  }

  setSort(sort: string): GetSearchByFacilityRequestModel {
    this.sort = sort;
    return this;
  }

  getProcedureId(): string {
    return this.procedureId;
  }

  setProcedureId(procedureId: string): GetSearchByFacilityRequestModel {
    this.procedureId = procedureId;
    return this;
  }

  getAggregateOverallRating(): string {
    return this.aggregateOverallRating;
  }

  setAggregateOverallRating(aggregateOverallRating: string): GetSearchByFacilityRequestModel {
    this.aggregateOverallRating = aggregateOverallRating;
    return this;
  }

  getAwardId(): string {
    return this.awardId;
  }

  setAwardId(awardId: string): GetSearchByFacilityRequestModel {
    this.awardId = awardId;
    return this;
  }

  getCqmId(): string {
    return this.cqmId;
  }

  setCqmId(cqmId: string): GetSearchByFacilityRequestModel {
    this.cqmId = cqmId;
    return this;
  }

  getBdcId(): string {
    return this.bdcId;
  }

  setBdcId(bdcId: string): GetSearchByFacilityRequestModel {
    this.bdcId = bdcId;
    return this;
  }

  getSearchForTH(): boolean {
    return this.searchForTH ? true : false;
  }

  setSearchForTH(search: boolean): GetSearchByFacilityRequestModel {
    this.searchForTH = search;
    return this;
  }
}

export class GetSearchByFacilityResponseModel extends GeneralError implements GetSearchByFacilityResponseModelInterface {
  totalCount: number;
  facilities: FadFacilityInterface[];
  facets: FacetsFacilityList;
  costDetails: CostDetails;
  disclaimers: Disclaimers[];
  sort: string;
  pdfRequest: FadPdfRequest;
}

export class FadPdfRequest implements FadPdfRequestInterface {
  filters: string[];
  queryUrl: string;
  queue: boolean;
  source: string;
  searchParams: FadSearchParams;
}

export class FadSearchParams implements FadSearchParamsInterface {
  accountId: string;
  ci: string;
  dataLanguage: string;
  geoLocation: string;
  limit: string;
  memberNumber: string;
  name: string;
  networkId: string;
  page: string;
  radius: string;
  sort: string;
}

export interface FadFacility {
  id: string;
  facilityId: string;
  type: string;
  facilityName: string;
  specialty: string; // This is the name of the city
  locations: FadLocationDetails[];
  reviews: FadReviewsList;
  isDisabled: boolean;
  tiers: FadTiersInterface;
}

export class FacetsFacilityList implements FacetsFacilityListInterface {
  overallRating: FilterListItem[];
  fieldSpecialtyIds: FilterListItem[];
  locationGeo: FilterListItem[];
  inNetwork: FilterCheckboxItem;
  bdcTypeCodes: FilterListItem[];
  awardTypeCodes: FilterListItem[];
  cqms: FilterListItem[];
  tiers: FilterListItem[];
  expertiseTypeCodes: FilterListItem[];
}

export class FacilityFiltersMetadataModel implements FacilityFiltersMetadataInterface {
  filterInNetwork: FilterCheckboxItem;
  filterLocation: FilterListItem;
  filterRating: FilterListItem;
  filterSpecialities: FilterListItem;
  filterBDC: FilterListItem;
  filterAward: FilterListItem;
  filterCQMS: FilterListItem;
  filterTiers: FilterListItem;
}
