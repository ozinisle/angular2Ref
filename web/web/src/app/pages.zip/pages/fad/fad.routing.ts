import { RouterModule, Routes } from '@angular/router';
import { FadResolver } from '../landing/fad.resolver';
import { FadCostBreakdownComponent } from './fad-cost-breakdown/fad-cost-breakdown.component';
import { FadDoctorProfileComponent } from './fad-doctor-profile/fad-doctor-profile.component';
import { FadDoctorProfileResolver } from './fad-doctor-profile/fad-doctor-profile.resolver';
import { FadDoctorRatingComponent } from './fad-doctor-rating/fad-doctor-rating.component';
import { FadFacilityCompareResolver } from './fad-facility-compare/fad-facility-compare-resolver';
import { FadFacilityCompareComponent } from './fad-facility-compare/fad-facility-compare.component';
import { FadFacilityProfileComponent } from './fad-facility-profile/fad-facility-profile.component';
import { FadFacilityProfileResolver } from './fad-facility-profile/fad-facility-profile.resolver';
import { FadLandingPageComponent } from './fad-landing-page/fad-landing-page.component';
import { FadMedicalIndexComponent } from './fad-medical-index/fad-medical-index.component';
import { FadPastSearchQueryListComponent } from './fad-past-search-query-list/fad-past-search-query-list.component';
import { FadProfessionalCompareComponent } from './fad-professional-compare/fad-professional-compare.component';
import { FadProviderCompareResolver } from './fad-provider-compare/fad-provider-compare-resolver';
import { FadProviderCompareComponent } from './fad-provider-compare/fad-provider-compare.component';
import { FadReviewComponent } from './fad-review/fad-review.component';
import { FadSearchResultsComponent } from './fad-search-results/fad-search-results.component';
import { FadSearchResultsResolver } from './fad-search-results/fad-search-results.resolver';
import { FadGuard } from './fad.guard';

const FAD_ROUTES: Routes = [
  {
    path: '',
    component: FadLandingPageComponent,
    resolve: [FadResolver],
    canActivate: [FadGuard]
  },
  {
    path: 'search-results',
    component: FadSearchResultsComponent,
    runGuardsAndResolvers: 'always',
    canActivate: [FadGuard],

    resolve: {
      fadLandingPageSearchResults: FadSearchResultsResolver
    }
  },
  {
    path: 'doctor-profile',
    component: FadDoctorProfileComponent,
    canActivate: [FadGuard],

    resolve: {
      fadProfessionalResposeData: FadDoctorProfileResolver
    }
  },
  {
    path: 'facility-profile',
    component: FadFacilityProfileComponent,
    canActivate: [FadGuard],
    resolve: {
      fadFacilityResposeData: FadFacilityProfileResolver
    }
  },
  {
    path: 'rate-doctor',
    component: FadDoctorRatingComponent,
    canActivate: [FadGuard]
  },
  {
    path: 'medical-index/:type',
    component: FadMedicalIndexComponent,
    canActivate: [FadGuard]
  },
  {
    path: 'past-search-queries',
    component: FadPastSearchQueryListComponent,
    canActivate: [FadGuard]
  },
  {
    path: 'provider-compare',
    component: FadProviderCompareComponent,
    canActivate: [FadGuard],
    resolve: {
      compareData: FadProviderCompareResolver
    }
  },
  {
    path: 'facility-compare',
    component: FadFacilityCompareComponent,
    canActivate: [FadGuard],
    resolve: {
      facilityCompareData: FadFacilityCompareResolver
    }
  },
  {
    path: 'professional-compare',
    component: FadProfessionalCompareComponent,
    canActivate: [FadGuard]
  },
  {
    path: 'cost-breakdown',
    component: FadCostBreakdownComponent,
    canActivate: [FadGuard]
  },
  {
    path: 'review',
    component: FadReviewComponent,
    canActivate: [FadGuard]
  },
  {
    path: 'affiliated-doctors-search-results',
    component: FadSearchResultsComponent,
    runGuardsAndResolvers: 'always',
    canActivate: [FadGuard],
    resolve: {
      fadLandingPageSearchResults: FadSearchResultsResolver
    }
  }
];

export const FadRouter = RouterModule.forChild(FAD_ROUTES);
