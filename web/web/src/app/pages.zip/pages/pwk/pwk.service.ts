import { Injectable } from '@angular/core';
import { PWKStatus } from '../../shared/models/welcome-kit.model';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { AuthService, ConstantsService } from '../../shared/shared.module';

@Injectable()
export class PwkService {
  constructor(private http: AuthHttp, private authService: AuthService, private constants: ConstantsService) {}

  getPwkVideo() {
    const request = {
      useridin: this.authService.useridin
    };
    return this.http.encryptPost(this.constants.pwkUrl, request, null, null, false);
  }

  getPdf() {
    const request = {
      useridin: this.authService.useridin
    };
    return this.http.encryptPost(this.constants.pdfUrl, request, null, null, false);
  }

  setMedicare() {
    const pwkStatus: PWKStatus = JSON.parse(sessionStorage.getItem('pwkStatus'));
    const request = {
      useridin: this.authService.useridin,
      seenMedicareVideo: pwkStatus.seenMedicareVideo,
      seenMedicarePDF: pwkStatus.seenMedicarePDF
    };
    return this.http.encryptPost(this.constants.setUrl, request, null, null, false);
  }

  getMedicareDoc() {
    const request = {
      useridin: this.authService.useridin
    };
    return this.http.encryptPost(this.constants.medDoc, request, null, null, false);
  }
}
