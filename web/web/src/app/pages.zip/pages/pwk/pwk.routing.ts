import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../../shared/utils/auth.guard';
import { PwkComponent } from './pwk.component';

const Pwk_ROUTER: Routes = [
  {
    path: '',
    canActivate: [AuthGuard],
    component: PwkComponent
  }
];
export const PwkRouter = RouterModule.forChild(Pwk_ROUTER);
