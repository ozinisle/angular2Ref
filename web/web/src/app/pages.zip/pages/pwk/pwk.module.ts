import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { SharedModule } from '../../shared/shared.module';
import { PwkComponent } from './pwk.component';
import { PwkService } from './pwk.service';

@NgModule({
  imports: [CommonModule,  SharedModule
  ],
  exports: [PwkComponent],
  declarations: [PwkComponent],

  providers: [PwkService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class PwkModule {}
