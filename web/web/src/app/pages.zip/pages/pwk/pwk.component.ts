import { Component, OnInit } from '@angular/core';
import { DynamicScriptLoaderService } from '../../shared/services/dynamic-script-loader.service';
import { PwkService } from './pwk.service';

declare let $: any;
@Component({
  selector: 'app-pwk',
  templateUrl: './pwk.component.html',
  styleUrls: ['./pwk.component.scss']
})
export class PwkComponent implements OnInit {
  constructor(private pwkService: PwkService, private dynamicScriptLoaderService: DynamicScriptLoaderService) {
    this.dynamicScriptLoaderService.loadScript('sundaysky');
  }

  ngOnInit() {
    this.pwkService.getPwkVideo().subscribe(response => {
      if (response && response.programID && response.stream) {
        this.createPlayer(response);
      }
    });
    const pwkStatus = JSON.parse(sessionStorage.getItem('pwkStatus'));
    const videoSeen = JSON.parse(sessionStorage.getItem('seenVideo'));
    if (pwkStatus.medicareVideoExists && pwkStatus.seenMedicareVideo < 2) {
      if (videoSeen) {
        pwkStatus.seenMedicareVideo = ++pwkStatus.seenMedicareVideo;
        sessionStorage.setItem('pwkStatus', JSON.stringify(pwkStatus));
        this.pwkService.setMedicare().subscribe(res => {
          if (res) {
            sessionStorage.setItem('seenVideo', JSON.stringify(false));
          }
        });
      }
    }
  }
  createPlayer(sskyresponse) {
    const sskyplayer = document.createElement('sundaysky-video');
    sskyplayer.setAttribute('id', 'sskyplayer');
    sskyplayer.setAttribute('analytics-token', sskyresponse.programID);
    sskyplayer.setAttribute('session', sskyresponse.stream);
    sskyplayer.setAttribute('transcript-button', 'show');
    sskyplayer.setAttribute('poster', sskyresponse.poster);
    sskyplayer.setAttribute('no-autoplay', '');
    document.getElementById('sskydiv').appendChild(sskyplayer);
  }
}
