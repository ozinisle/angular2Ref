import { animate, state, style, transition, trigger } from '@angular/animations';
import { DatePipe } from '@angular/common';
import { Component, ElementRef, EventEmitter, HostListener, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatCalendar, MatRadioGroup, MatSelectionList, MatSelectionListChange, MatSidenav } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { InfiniteScrollDirective } from 'ngx-infinite-scroll';
import { ISubscription } from 'rxjs/Subscription';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { BreadCrumb } from '../../../shared/components/breadcrumbs/breadcrumbs';
import { FilterItem } from '../../../shared/models/filterItem.model';
import { MemberInfo } from '../../../shared/models/memberInfo.model';
import { Option } from '../../../shared/models/option.model';
import { AlertService } from '../../../shared/services/alert.service';
import { AuthHttp } from '../../../shared/services/auth-http.service';
import { ConstantsService } from '../../../shared/services/constants.service';
import { DependantsService } from '../../../shared/services/dependant.service';
import { FilterService } from '../../../shared/services/filter.service';
import { GlobalService } from '../../../shared/services/global.service';
import { AuthService } from '../../../shared/shared.module';
import { RadioList } from '../../myclaims/claims.model';
import { ClaimBenefitsLinkRequestModel } from '../../myclaims/models/claim-benefits-link.model';
import { EobsService } from '../eobs.service';
import { ClaimMemberRecord } from '../models/claims-summary-data.model';
import { DependentsResponseModel } from '../models/dependants.model';
import { ClaimBenefitsLinkRequestModelInterface } from '../models/interfaces/claim-benefits-link-model.interface';
import {
  ClaimStatusSearchListInterface,
  CustomDateRangeMetaInterface,
  DateMetaInterface,
  DateSearchListInterface,
  MemberTypeMetaInterface,
  MemberTypeSearchListInterface,
  PlanSearchListInterface,
  ProviderSearchListInterface,
  VisitTypeSearchListInterface
} from '../models/interfaces/claims-generic-models.interface';
import {
  ClaimFiltersMetadataInterface,
  ClaimMemberRecordInterface,
  ClaimsSummaryRequestModelInterface,
  ClaimsSummaryResponseModelInterface,
  ClaimSummaryMetadataInterface
} from '../models/interfaces/claims-summary-data-model.interface';
import { DependentsResponseModelInterface } from '../models/interfaces/dependants-model.interface';
import { ClaimSummarySortOrderType } from '../models/types/claims.types';
import { EOBRecord } from './eob-data-model.interface';

declare let $: any;

@Component({
  templateUrl: './eobs.component.html',
  styleUrls: ['./eobs.component.scss'],
  animations: [
    trigger('slideInOut', [
      state(
        'in',
        style({
          transform: 'translate3d(0,0,0)'
        })
      ),
      state(
        'out',
        style({
          transform: 'translate3d(-100%,0,0)',
          display: 'none'
        })
      ),
      transition('in => out', animate('100ms ease-in-out')),
      transition('out => in', animate('100ms ease-in-out'))
    ])
  ]
})
export class EobsComponent implements OnInit, OnDestroy {
  //#region
  public userString: 'User' = 'User';
  public dependant: string;
  public subscription: ISubscription;
  public claimsListing;
  public claims: ClaimMemberRecord[] = [];
  public filteredClaims: ClaimMemberRecordInterface[] = ClaimMemberRecord[''];
  public filteredClaimscount: number;
  public allClaims: ClaimMemberRecord[] = [];
  public memberData: MemberInfo;
  public sideNavHeight: string;
  public sideNavStatus: string;
  public noClaimsAvailable = false;
  public dateList: DateSearchListInterface[] = [];
  public showClose: boolean;
  public showCalender: boolean;
  public title = 'Explanation of Benefits';
  public sortList: RadioList[] = [
    {
      value: 'Most Recent',
      checked: true
    },
    {
      value: 'Oldest First',
      checked: false
    }
  ];
  public sortSelectedFilter: string;
  public searchval: string;
  public isautosearch: boolean;
  public isDisplayMessage = false;
  public isDisplayResults = false;
  public isInitialCount = false;
  public medicationsMessage: string;
  public breadCrumbsE: BreadCrumb[];
  public issearchShowing: boolean;
  public isfilterShowing: boolean;
  public dateSelectedFilter: DateSearchListInterface;
  public showDate: boolean;
  public fromMinDate: Date;
  public calendarMaxDate = new Date();
  public currentSelectedDate: Date = null;
  public isCustomDateRangeInValid = false;
  public isSelectedDateInvalid = false;
  public sideNavMode: string;
  public lastDate: Date;
  public fromDate: string;
  public toDate: string = moment().format('L');
  public autoCompleteSearchArray: string[] = [];
  public index: number;
  public isSidenavOpened: boolean;
  public ismobile: boolean;
  public errorMessage: string;
  public collapsedHeight: string;
  public collapsedSortHeight: string;
  public expandedHeight: string;
  public expandedSortHeight: string;
  public mobileViewPort = 992;
  public filterWidth: string;
  public isexpanded: boolean;
  public isSortExpanded: boolean;
  public isFormDateSelected = true;
  public dateFormat = 'MM/DD/YYYY';
  public currentSortValue: string;

  // Filters List
  public planList: PlanSearchListInterface[] = [];
  public selectedPlanList: Object[];
  public allPlansString = 'All Plans';

  // Filters List
  public visitTypeList: VisitTypeSearchListInterface[] = [];
  public selectedVisitTypeList: Object[];
  public selectedMemberList: Object[];
  public allVisitsString = 'All visits';

  public providerList: ProviderSearchListInterface[] = [];
  public selectedProviderList: Object[];
  public allProvidersString = 'All Providers';

  public allClaimsStatuesString = 'All statuses';
  public claimsStatuses = this.getDefaultClaimsStatuses();
  public claimsStatusList: ClaimStatusSearchListInterface[] = [];
  public selectedClaimsList: Object[];
  public allClaimsString = 'All Claims';
  public membersList: MemberTypeSearchListInterface[] = [];
  public dependentList: DependentsResponseModelInterface = new DependentsResponseModel();
  public selectedSortString: string;
  public myFocusTriggeringEventEmitter = new EventEmitter<boolean>();
  public showClearLink = false;
  public showResultsCount = false;
  public searchString: string;
  public bHasDependents = false;
  public claimsInfo: any;
  public allClaimsFilterOptions;
  public isDisplayCustomDateRange = false;
  public recordsPerPage = 50;
  public checkFromDate: boolean;
  public checkToDate: boolean;
  public isDisplaySpinner = false;
  public isClearFilter = false;
  public step = [];
  public fpoTargetUrl = '';
  public showFinancialLink = false;
  public showHEQALGFinancialLink = false;
  public ssoFinancialLink = '';
  public ssoALGFinancialLink: String = '';
  public ssoHEQFinancialLink: String = '';
  public initialClaimsCount: number;
  public claimsFormUrl: string = this.constants.claimsFormCommercialUrl;

  @ViewChild('searchDrpContainer') searchDrpContainer;
  @ViewChild('sideNavContainer') elementView: ElementRef;
  @ViewChild('filterWidth') filterElementView: ElementRef;
  @ViewChild('searchInput') searchInput;
  @ViewChild('sidenav') sideNav: MatSidenav;
  @ViewChild('dependantFilter') dependantFilterComponent: MatRadioGroup;
  @ViewChild('matcalender') picker: MatCalendar<Date>;
  @ViewChild('fromDateInput') fromInputDate: ElementRef;
  @ViewChild('toDateInput') toInputDate: ElementRef;
  @ViewChild('searchInput') inputSearch: ElementRef;
  @ViewChild('memberFilter') memberFilter;
  @ViewChild('providerFilter') providerFilter;
  @ViewChild('visitTypeFilter') visitTypeFilter;
  @ViewChild('claimStatusFilter') claimStatusFilter;
  @ViewChild(InfiniteScrollDirective) infiniteScroll: InfiniteScrollDirective;

  public contactus = this.constants.contactus + this.authService.authToken.scopename;
  public isMedicalPlanType = false;
  public isDentalPlanType = false;
  private dentalClaimsFormUrl = this.constants.dentalClaimFormCommercialUrl;
  public isBCBSMAEmployee = false;
  private empClaimsFormUrl = this.constants.empClaimsFormCommercialUrl;

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    if (event.target.innerWidth <= this.mobileViewPort) {
      this.ismobile = true;
    } else {
      this.ismobile = false;
      this.sideNavStatus = 'in';
    }
  }
  //#endregion

  constructor(
    private eobService: EobsService,
    public authService: AuthService,
    public http: AuthHttp,
    private router: Router,
    public dependantsService: DependantsService,
    public filterService: FilterService,
    public globalService: GlobalService,
    public constants: ConstantsService,
    private activatedRoute: ActivatedRoute,
    private alertService: AlertService,
    private datePipe: DatePipe) {
    this.claimsInfo = this.activatedRoute.snapshot.data.eobInfo;

    if (this.claimsInfo && this.claimsInfo[0] && this.claimsInfo[0].eobRecords) {
      this.initialClaimsCount = this.claimsInfo[0].eobMetaData.totalRecordCount;
      this.isInitialCount = true;
      this.isDisplayResults = false;
    }
    this.sortSelectedFilter = 'Most Recent';
    this.currentSortValue = this.sortSelectedFilter;
    this.isautosearch = false;
    this.isDisplayMessage = false;
    this.issearchShowing = false;
    this.showDate = false;
    this.sideNavMode = 'side';
    this.index = -1;
    this.isSidenavOpened = false;
    this.errorMessage = null;
    this.collapsedHeight = '32px';
    this.collapsedSortHeight = '48px';
    this.expandedHeight = '40px';
    this.expandedSortHeight = '48px';
    this.isexpanded = false;
    this.sideNavHeight = '600';
    this.showCalender = false;
    this.searchString = '';
    this.isSortExpanded = false;
    if (window.innerWidth <= this.mobileViewPort) {
      this.ismobile = true;
    }
    this.sideNavStatus = this.ismobile ? 'out' : 'in';
    this.dependentList = this.authService.getDependentsList();
    this.subscription = this.globalService.memberData$.subscribe(data => {
      this.memberData = data;
    });

    if (sessionStorage.getItem('claimsDepId')) {
      sessionStorage.removeItem('claimsDepId');
    }
    if (this.authService.authToken && this.authService.authToken.userType.toLowerCase() === 'medicare') {
      this.claimsFormUrl = this.constants.claimsFormMedicareUrl;
    } else if (this.authService.authToken && this.authService.authToken.userType.toLowerCase() === 'medex') {
      this.claimsFormUrl = this.constants.claimsFormMedexUrl;
    }
  }

  private handleFinanceLinksInSideBar() {
    const hasALG = this.authService.authToken ? this.authService.authToken.isALG === 'true' : false;
    const hasHEQ = this.authService.authToken ? this.authService.authToken.isHEQ === 'true' : false;

    this.showHEQALGFinancialLink = false;
    this.showFinancialLink = false;
    if (hasALG) {
      if (hasHEQ) {
        // both are true - show 2 links
        this.showHEQALGFinancialLink = true;
        this.showFinancialLink = false;
      } else {
        this.showHEQALGFinancialLink = false;
        this.showFinancialLink = true;
      }
    } else {
      if (hasHEQ) {
        this.showHEQALGFinancialLink = false;
        this.showFinancialLink = true;
      } else {
        // both are false - show no links
        this.showHEQALGFinancialLink = false;
        this.showFinancialLink = false;
      }
    }

    // this.showFinancialLink = (hasALG || hasHEQ) ? true : false;
    this.ssoFinancialLink = hasHEQ ? '/sso/heathequity' : '/sso/alegeus';
  }

  public openSSO(module?) {
    // Impersonation has SSO blocked
    const impersonate = this.authService.impersonation();
    console.log('SSO blocked in Impersonation');
    if (module === 'algOrHeq' && !impersonate) {
      if (this.ssoFinancialLink === '/sso/alegeus') {
        sessionStorage.setItem('consentLink', '/sso/alegeus');
        $('#openSsoAlgSite').modal('open');
      } else {
        sessionStorage.setItem('consentLink', '/sso/heathequity');
        $('#openSsoHeqSite').modal('open');
      }
    } else if (module === 'alg' && !impersonate) {
      sessionStorage.setItem('consentLink', '/sso/alegeus');
      $('#openSsoAlgSite').modal('open');
    } else if (module === 'heq' && !impersonate) {
      sessionStorage.setItem('consentLink', '/sso/heathequity');
      $('#openSsoHeqSite').modal('open');
    } else if (module === 'connecture' && !impersonate) {
      window.open('/sso/connecture', '_blank');
    }
  }

  ngOnInit() {
    this.initAllClaimsFilterOptions();
    this.manageClaimsListing();
    this.handleFinanceLinksInSideBar();
    const memberInfo = sessionStorage.getItem('authToken');
    if (memberInfo) {
      const authToken = JSON.parse(memberInfo);
      if (authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'true' && authToken.planTypes['dental'] === 'true') {
        this.title = 'Summary of Health Plan Payments';
      }
      if (
        (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
        authToken.planTypes['medical'] === 'true' &&
        authToken.planTypes['dental'] === 'true'
      ) {
        this.title = 'Explanation of Benefits';
      }
      if (authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'false' && authToken.planTypes['dental'] === 'false') {
        this.title = 'Summary of Health Plan Payments';
      }
      if (
        (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
        authToken.planTypes['medical'] === 'false' &&
        authToken.planTypes['dental'] === 'false'
      ) {
        this.title = 'Explanation of Benefits';
      }
      if (authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'true' && authToken.planTypes['dental'] === 'false') {
        this.title = 'Summary of Health Plan Payments';
      }
      if (
        (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
        authToken.planTypes['medical'] === 'true' &&
        authToken.planTypes['dental'] === 'false'
      ) {
        this.title = 'Explanation of Benefits';
      }
      if (authToken.userType === 'MEMBER' && authToken.planTypes['medical'] === 'false' && authToken.planTypes['dental'] === 'true') {
        this.title = 'Explanation of Your Dental Benefits';
      }
      if (
        (authToken.userType === 'MEDEX' || authToken.userType === 'MEDICARE') &&
        authToken.planTypes['medical'] === 'false' &&
        authToken.planTypes['dental'] === 'true'
      ) {
        this.title = 'Explanation of Your Dental Benefits';
      }
    }
    this.breadCrumbsE = [];
    this.breadCrumbsE = [
      {
        label: 'Home',
        url: ['/home']
      },
      {
        label: 'My Inbox',
        url: ['/message-center']
      },
      {
        label: 'My Documents',
        url: ['/message-center/documents/home']
      },
      {
        label: this.title,
        url: ['/myeobs']
      }
    ];
    const authToken = JSON.parse(memberInfo);
    if (authToken.planTypes['medical'] === 'true') {
      this.isMedicalPlanType = true;
    }
    if (authToken.planTypes['dental'] === 'true') {
      this.isDentalPlanType = true;
    }
    if (sessionStorage.getItem('isEE') === 'true') {
      this.isBCBSMAEmployee = true;
    }
  }

  public formattedData(value: string) {
    value = value.substring(0, 11);
    return this.datePipe.transform(value, 'MM/dd/yyyy');
  }

  public isSortOpened() {
    this.isSortExpanded = true;
  }

  public isSortClosed() {
    this.isSortExpanded = false;
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
    this.alertService.clearError();
  }

  // filter Logic below
  public toggleFilter(toggleStatus) {
    this.isSidenavOpened = !this.isSidenavOpened;
    this.sideNavStatus = this.sideNavStatus === 'out' ? 'in' : 'out';
    if (toggleStatus) {
      this.sideNavStatus = toggleStatus;
    }
    this.sideNavMode = window.innerWidth <= 992 ? 'over' : 'side';
  }

  public closeSideNavigation() {
    this.isSidenavOpened = false;
  }

  public closeFilter() {
    if (this.ismobile) {
      this.sideNavStatus = 'out';
      this.isSidenavOpened = false;
    }
  }

  public setShowClearLink() {
    this.showClearLink = false;
    if (this.dependant !== this.userString) {
      this.showClearLink = true;
    } else {
      if (this.searchval || this.sortSelectedFilter !== 'Most Recent') {
        this.showClearLink = true;
      }
    }
  }

  public setSortFiltervalue(sortValue: string = 'Most Recent') {
    for (let i = 0; i < this.sortList.length; i++) {
      if (this.sortList[i].value === sortValue) {
        this.sortSelectedFilter = sortValue;
        sessionStorage.setItem('sortSelectedFilter', this.sortSelectedFilter);
        this.sortList[i].checked = true;
      } else {
        this.sortList[i].checked = false;
      }
    }
  }

  public clearSessionStorageItems() {
    sessionStorage.removeItem('providerSelectedfilter');
    sessionStorage.removeItem('visitTypeSelectedfilter');
    sessionStorage.removeItem('claimStatusSelectedfilter');
    sessionStorage.removeItem('dateSelectedFilter');
    sessionStorage.removeItem('fromDate');
    sessionStorage.removeItem('toDate');
    sessionStorage.removeItem('sortSelectedFilter');
    if (sessionStorage.getItem('claimsSelectedUserId') !== 'User') {
      sessionStorage.removeItem('claimsSelectedUserId');
    }
  }

  public clearFilterList() {
    this.selectedPlanList = [];
    this.selectedProviderList = [];
    this.selectedVisitTypeList = [];
    this.selectedClaimsList = [];
    this.dateList = [];
    // this.dateSelectedFilter = '';
  }

  public isOpened(value) {
    switch (value) {
      case 1:
        this.step[1] = 1;
        break;
      case 2:
        this.step[2] = 2;
        break;
      case 3:
        this.step[3] = 3;
        break;
      case 4:
        this.step[4] = 4;
        break;
      case 5:
        this.step[5] = 5;
        break;
      case 6:
        this.step[6] = 6;
        break;
      default:
        break;
    }
  }

  public sortFilterChanged(selectedOption) {
    for (let i = 0; i < this.sortList.length; i++) {
      if (this.sortList[i].value === selectedOption.value) {
        this.sortList[i].checked = false;
        this.sortSelectedFilter = selectedOption.value;
      } else {
        this.sortList[i].checked = false;
      }
    }
    setTimeout(() => {
      const sortFilterItem = this.sortList.find(item => item.value === this.sortSelectedFilter);
      if (sortFilterItem) {
        sortFilterItem.checked = true;
      }
    }, 1);
  }

  public claimsErrorMessage() {
    if (this.filteredClaims.length === 0) {
      this.medicationsMessage = 'For further inquiries, please contact member services';
      this.isDisplayMessage = true;
    }
  }

  public getSelectedSort(): string {
    let selectedSort = '';
    if (this.sortList && this.sortList.length > 0) {
      const selectedItem = this.sortList.find(item => item.checked);
      selectedSort = selectedItem ? selectedItem.value : '';
    }
    return selectedSort;
  }

  public showClaimDetails(claim) {
    // Reset the request params
    sessionStorage.setItem('claimId', claim.claimId);
    this.router.navigate(['/myclaims/claimdetails']);
  }

  public saveFilterDetails() {
    const filterDetails = {
      selectedPlanList: this.selectedPlanList,
      selectedVisitTypeList: this.selectedVisitTypeList,
      selectedProviderList: this.selectedProviderList,
      selectedClaimsList: this.selectedClaimsList,
      dateSelectedFilter: this.dateSelectedFilter,
      toDate: this.toDate,
      fromDate: this.fromDate,
      searchval: this.searchval,
      sortSelectedFilter: this.sortSelectedFilter,
      dependant: this.dependant
    };
    sessionStorage.setItem('claims_filterState', JSON.stringify(filterDetails));
  }

  public dateFilterChanged(temp) {
    if (this.dateSelectedFilter && Object.keys(this.dateSelectedFilter).length) {
      if (!(this.dateSelectedFilter.dateRange.indexOf(this.allClaimsFilterOptions.date.custom.dateRange) !== -1)) {
        this.clearCustomDateRangeSelections();
        this.showCalender = false;
      } else {
        this.isDisplayCustomDateRange = true;
      }
      this.fromDate = '';
      this.isSelectedDateInvalid = false;
      this.isCustomDateRangeInValid = false;
    }
  }

  public fromDateChange(fromdate) {
    this.validateFromDate();
    this.validateCustomRange();
    if (!this.isCustomDateRangeInValid && !this.isSelectedDateInvalid) {
      this.showCalender = false;
    }
  }

  public validateFromDate() {
    const minFormDate = this.filterService.getMinimumFromDate();
    if (moment(this.fromDate).isValid()) {
      this.isSelectedDateInvalid =
        !this.fromDate ||
        this.fromDate.length !== 10 ||
        moment(this.fromDate, this.dateFormat).diff(moment(this.calendarMaxDate), "days") > 0 ||
        moment(this.fromDate, this.dateFormat).diff(moment(minFormDate), "days") < 0;
    } else {
      this.isSelectedDateInvalid = true;
    }

    return this.isSelectedDateInvalid;
  }

  public validateToDate() {
    const minFormDate = this.filterService.getMinimumFromDate();
    if (moment(this.toDate).isValid()) {
      this.isSelectedDateInvalid =
        !this.toDate ||
        moment(this.toDate, this.dateFormat).diff(moment(this.calendarMaxDate), "days") > 0 ||
        moment(this.fromDate, this.dateFormat).diff(moment(minFormDate), "days") < 0;
    } else {
      this.isSelectedDateInvalid = true;
    }
    return this.isSelectedDateInvalid;
  }

  public validateCustomRange() {
    if (this.toDate && this.fromDate) {
      this.isCustomDateRangeInValid = moment(this.toDate).diff(moment(this.fromDate)) < 0;
    }
  }

  public toDateChange(toDate) {
    this.validateCustomRange();
    this.validateToDate();
    if (!this.isCustomDateRangeInValid && !this.isSelectedDateInvalid) {
      this.showCalender = false;
    }
  }

  public clearCustomDateRangeSelections() {
    this.toDate = moment().format('L');
    this.fromDate = null;
    this.fromMinDate = null;
    this.isCustomDateRangeInValid = false;
    this.isSelectedDateInvalid = false;
    this.isDisplayCustomDateRange = false;
  }

  public clearSearchVal() {
    this.searchval = '';
    this.showClose = false;
    this.isautosearch = false;
    this.inputSearch.nativeElement.focus();
  }

  public toggleCalender(selectedDateType: string) {
    const isControlChanged =
      (selectedDateType === 'to' && this.isFormDateSelected) || (selectedDateType === 'from' && !this.isFormDateSelected);
    this.isFormDateSelected = selectedDateType === 'from';
    this.currentSelectedDate = this.isFormDateSelected ? new Date(this.fromDate) : new Date(this.toDate);
    this.setCalendarMinimumDate();
    if (isControlChanged) {
      this.toggleCalendarDisplay();
    } else {
      this.showCalender = true;
    }
  }

  public toggleCalendarDisplay() {
    this.showCalender = false;
    setTimeout(() => {
      this.showCalender = true;
      setTimeout(() => {
        if (this.isFormDateSelected) {
          this.fromInputDate.nativeElement.focus();
        } else {
          this.toInputDate.nativeElement.focus();
        }
      }, 1);
    }, 1);
  }

  public getSelectedValue(date) {
    this.isCustomDateRangeInValid = false;
    this.isSelectedDateInvalid = false;
    if (this.isFormDateSelected) {
      this.fromDate = this.filterService.getFormatDateString(date);
    } else {
      this.toDate = this.filterService.getFormatDateString(date);
    }
    this.setCalendarMinimumDate();
    this.showCalender = false;
  }

  public setCalendarMinimumDate() {
    if (!this.isFormDateSelected && this.fromDate) {
      this.fromMinDate = new Date(this.fromDate);
    } else {
      const minFormDate = this.filterService.getMinimumFromDate();
      this.fromMinDate = minFormDate;
    }
  }

  public formatInputFromDate(value) {
    const dateString = this.filterService.convertInputStringToDate(value);
    if (dateString) {
      this.fromDate = dateString;
    }
    if (this.fromDate.length >= 10) {
      this.validateFromDate();
      this.validateCustomRange();
      if (!this.isCustomDateRangeInValid && !this.isSelectedDateInvalid) {
        this.currentSelectedDate = new Date(this.fromDate);
        this.toggleCalendarDisplay();
      }
    }
  }

  public formatInputToDate(value) {
    const dateString = this.filterService.convertInputStringToDate(value);
    if (dateString) {
      this.toDate = dateString;
    }
    if (this.toDate.length >= 10) {
      this.validateToDate();
      this.validateCustomRange();
      if (!this.isCustomDateRangeInValid && !this.isSelectedDateInvalid) {
        this.currentSelectedDate = new Date(this.toDate);
        this.toggleCalendarDisplay();
      }
    }
  }

  public customDateInputKeyDownEvent(e) {
    return this.filterService.customDateInputKeyDownEvent(e);
  }

  public getDefaultClaimsStatusList() {
    return this.claimsStatuses.map(statusItem => {
      return FilterItem.getDefaultFilterItem(statusItem.value, statusItem.label);
    });
  }

  public getDefaultPlanList() {
    return [
      FilterItem.getDefaultFilterItem('Plan 1'),
      FilterItem.getDefaultFilterItem('Plan 2'),
      FilterItem.getDefaultFilterItem('Plan 3'),
      FilterItem.getDefaultFilterItem('Plan 4'),
      FilterItem.getDefaultFilterItem('Plan 5'),
      FilterItem.getDefaultFilterItem('All Plans')
    ];
  }

  public getDefaultClaimsStatuses() {
    return [
      Option.getOption('Pending', 'Pending'),
      Option.getOption('Adjusted', 'Adjusted'),
      Option.getOption('Completed', 'Completed'),
      Option.getOption('Denied', 'Denied'),
      Option.getOption(this.allClaimsStatuesString)
    ];
  }
  public formattedDate(date: string): string {
    if (date) {
      return this.datePipe.transform(date, 'MM/dd/yyyy');
    }
  }
  public showEOBDetails(eob: EOBRecord) {
    console.log(eob);

    const pdfReqParams: ClaimBenefitsLinkRequestModelInterface = new ClaimBenefitsLinkRequestModel();
    pdfReqParams.useridin = this.authService.useridin;
    pdfReqParams.eobClaimId = eob.eobClaimID;
    pdfReqParams.eobContractId = eob.nascoSubscriberNumber;
    pdfReqParams.claimProcessDate = eob.eobStatementDate;
    pdfReqParams.recordKey = sessionStorage.getItem('claimKey');

    console.log(pdfReqParams);
    this.eobService.getBenefitsDocument(pdfReqParams).subscribe(apiData => {
      console.log(apiData);

      if (apiData && Object.keys(apiData).length) {
        if (apiData.result && apiData.result !== 0) {
          $('#requestTimeoutError').modal('open');
          $('#timeOutErrorText')[0].innerHTML = apiData['displaymessage'];
          this.http.hideSpinnerLoading();
          this.isDisplaySpinner = false;
        } else {
          this.openPdfUrl(apiData['eobLink']);

          this.http.hideSpinnerLoading();
          this.isDisplaySpinner = false;
        }
      }
    });
  }

  public openUrl(url) {
    window.open(url, '_blank');
  }

  public trackByFn(index, claim) {
    return claim ? claim.id : index;
  }

  /* Initialize all filter option for members, providers
     visits,status etc.
     Initialize all filter flag for the filter options
  */
  private initAllClaimsFilterOptions(): void {
    this.allClaimsFilterOptions = {
      plan: { text: 'plan', allOptRequired: false, all: { planName: 'All Plans', planCount: 0 } },
      date: { text: 'date', allOptRequired: false, custom: { dateRange: 'Custom Date Range', dateCount: 0 } },
      member: { text: 'member', allOptRequired: false, all: { memberName: 'All Members', memberCount: 0 } },
      provider: { text: 'provider', allOptRequired: false, all: { providerName: 'All Providers', providerCount: 0 } },
      visitType: { text: 'visit', allOptRequired: false, all: { visitType: 'All Visits', visitTypeCount: 0 } },
      claimStatus: { text: 'status', allOptRequired: false, all: { status: 'All Statuses', statusCount: 0 } }
    };
  }

  /* TO show the claims listing or member record on page load
     To show the filter criteria on page load
     TO check whether it belongs to page load api data or filter api data
  */
  public manageClaimsListing(filterPaginationApiData?: ClaimsSummaryResponseModelInterface): void {
    if (!filterPaginationApiData) {
      if (this.claimsInfo && this.claimsInfo.length) {
        if (!this.claimsInfo[0].hasOwnProperty('result') && this.claimsInfo[0].result !== 0) {
          this.claimsListing = this.claimsInfo[0];
          if (!this.isClearFilter) {
            this.recordsPerPage = this.claimsListing.eobMetaData.recordEndIndex;
            this.manageClaimsFilter(this.claimsListing);
          }
        }
      }
    } else {
      this.claimsListing = filterPaginationApiData;
    }

    if (this.claimsListing && this.claimsListing.hasOwnProperty('eobRecords') && this.claimsListing.eobRecords.length) {
      this.filteredClaims = this.claimsListing.eobRecords;
      this.filteredClaimscount = this.claimsListing.eobMetaData.totalRecordCount;
      this.fpoTargetUrl = this.constants.drupalClaimsrUrl;
    } else {
      this.fpoTargetUrl = this.constants.drupalNoClaimsrUrl;
      this.noClaimsAvailable = true;
    }
  }

  /*
     To set/show the filter criteria on page load for date, members, providers,visits, claims status etc..
  */
  public manageClaimsFilter(claimsListing) {
    this.allClaimsFilterOptions.member.all.memberCount = claimsListing.eobMetaData.totalRecordCount;

    if (claimsListing.filtersMetaData.dateMetaData.hasOwnProperty('customDateRange')) {
      this.allClaimsFilterOptions.date.custom.dateCount = claimsListing.dateMetaData.customDateRange.customDateCount;
    }

    this.membersList = claimsListing.filtersMetaData.memberTypeMetaData.memberTypeMetaList;
    if (!this.checkExistingClaimsFilterOptions(this.membersList, this.allClaimsFilterOptions.member.all.memberName)) {
      this.membersList.push(this.allClaimsFilterOptions.member.all);
    }

    this.dateList = claimsListing.filtersMetaData.dateMetaData.dateMetaList;
    if (!this.checkExistingClaimsFilterOptions(this.dateList, this.allClaimsFilterOptions.date.custom.dateRange)) {
      this.dateList.push(this.allClaimsFilterOptions.date.custom);
    }
  }
  openPdfUrl(url) {
    if (url) {
      window.open(url, '_self');
    }
  }
  private checkExistingClaimsFilterOptions(filterList, allOptions: string) {
    return filterList.find(oFilterList => {
      return Object.values(oFilterList).includes(allOptions);
    });
  }

  /*
     To get the selected filter criteria from the view/template while changing the options
  */
  public manageSelectedClaimsFilter(selectionListChange: MatSelectionListChange, filterType: string) {
    switch (filterType) {
      case this.allClaimsFilterOptions.member.text:
        this.allClaimsFilterOptions.member.allOptRequired = this.checkClaimsFilterOptions(
          selectionListChange,
          this.allClaimsFilterOptions.member.all.memberName,
          this.membersList
        );
        break;
    }
  }

  /*
     To check whether the user selected the all options or individula options and
     make disabled other relevant options if user selected the all options and vice-versa
  */
  public checkClaimsFilterOptions(selectionListChange: MatSelectionListChange, allOptions: string, filterList) {
    const selectAllOption = selectionListChange.option;
    let allOptRequired = false;
    if (Object.values(selectAllOption.value).includes(allOptions)) {
      console.log('selection option selected', selectAllOption.selected);
      if (selectAllOption.selected) {
        allOptRequired = true;
        selectionListChange.source.selectAll();
      } else {
        selectionListChange.source.deselectAll();
      }
      filterList = filterList.map(filterObj => {
        if (selectAllOption.selected) {
          filterObj.selected = true;
          filterObj.disabled = !Object.values(filterObj).includes(allOptions);
          allOptRequired = true;
        } else {
          filterObj.selected = false;
          filterObj.disabled = false;
        }
        return filterObj;
      });
    } else if (selectAllOption.selected) {
      if (selectAllOption.selectionList.selectedOptions.selected.length === filterList.length - 1) {
        allOptRequired = true;
        switch (allOptions) {
          case 'All Members': {
            const selectedAllOption = filterList.find(listItem => listItem.memberName === allOptions);
            if (selectedAllOption && !selectedAllOption.selected) {
              selectedAllOption.selected = true;
            }
            break;
          }
        }
        return filterList;
      }
    } else {
      switch (allOptions) {
        case 'All Members': {
          const selectedAllOption = filterList.find(listItem => listItem.memberName === allOptions);

          if (selectedAllOption && selectedAllOption.selected) {
            selectedAllOption.selected = false;
            allOptRequired = false;
          }
          break;
        }
      }
      return allOptRequired;
    }

    return allOptRequired;
  }
  /*
     To get the selected filter criteria from the view/template to apply filter for all the filter criteria
  */

  private getSelectedClaimsFilterOptions(list: MatSelectionList, allOptions: string) {
    if (list && list.selectedOptions.selected.length > 0) {
      const filteredItems = list.selectedOptions.selected.filter(selectedItem => !Object.values(selectedItem.value).includes(allOptions));
      return filteredItems.map(filteredOptions => {
        const selectedFilterOptions = {};
        for (const prop in filteredOptions.value) {
          if (!(prop === 'selected' || prop === 'disabled')) {
            selectedFilterOptions[prop] = filteredOptions.value[prop];
          }
        }
        return selectedFilterOptions;
      });
    }
    return null;
  }

  /*
     To apply filter for all the selected filter criteria
  */
  public applyFilter(memberList: MatSelectionList) {
    // , clearSearch: boolean = true
    this.filterService.scrollToTop();
    this.closeFilter();
    this.closeSideNavigation();
    this.isDisplaySpinner = false;
    this.showCalender = false;
    this.isDisplayMessage = false;
    this.alertService.clearError();

    this.selectedMemberList = this.getSelectedClaimsFilterOptions(memberList, this.allClaimsFilterOptions.member.all.memberName);
    const pagination = false;
    const reqParams = this.claimsFilterPaginationReqParams(this.selectedMemberList, this.sortSelectedFilter, pagination);

    reqParams.eobMetaData.sortOrder = this.sortSelectedFilter as ClaimSummarySortOrderType;

    if (!this.isSelectedDateInvalid && !this.isCustomDateRangeInValid) {
      this.eobService.getClaims(reqParams).subscribe(apiData => {
        if (apiData && Object.keys(apiData).length) {
          if (!apiData.hasOwnProperty('result') && apiData.result !== 0) {
            this.manageClaimsListing(apiData);
            this.isDisplayResults = true;
            this.isInitialCount = false;
            this.showClearLink = true;
          } else {
            if (apiData.result === -90202) {
              this.isDisplayMessage = true;
              this.isDisplayResults = true;
              this.isInitialCount = false;
              this.showClearLink = true;
              this.filteredClaims = [];
            } else {
              this.alertService.setAlert('', apiData['displaymessage'], AlertType.Failure);
            }
          }
        }
      });
    }
  }

  /*
       To clear the filter for all the selected filter criteria
  */
  public clearFilter(memberList: MatSelectionList) {
    this.step = [];
    this.closeFilter();

    this.showClose = false;
    this.showCalender = false;
    this.showResultsCount = false;
    this.isSortExpanded = false;
    this.isClearFilter = true;
    this.isDisplayMessage = false;
    this.isDisplayResults = false;
    this.isInitialCount = true;
    this.showClearLink = false;

    if (this.dateSelectedFilter && Object.keys(this.dateSelectedFilter).length) {
      this.dateSelectedFilter = {} as DateSearchListInterface;
      this.clearCustomDateRangeSelections();
    }

    this.clearFilterOptionsFromView(memberList);

    this.initClearFilterOptions(this.membersList);

    this.selectedProviderList = [];
    this.selectedClaimsList = [];
    this.selectedVisitTypeList = [];
    this.selectedMemberList = [];

    this.manageClaimsListing();
    this.filterService.scrollToTop();
    this.closeSideNavigation();
    this.setSortFiltervalue();
    this.alertService.clearError();
  }

  /*
      Inner function of clear filter to clear the filter for all the selected filter criteria
  */
  private clearFilterOptionsFromView(filterList) {
    if (filterList && filterList.selectedOptions.selected.length > 0) {
      filterList = filterList.selectedOptions.selected.map(oFilterList => {
        oFilterList.selected = false;
        oFilterList.disabled = false;
        return oFilterList;
      });
    }
  }

  private initClearFilterOptions(filterList, filterType?: string) {
    if (filterList && filterList.length) {
      return filterList.map(oFilterList => {
        if (!filterType) {
          oFilterList.selected = false;
          oFilterList.disabled = false;
        } else {
          oFilterList.checked = false;
        }
        return oFilterList;
      });
    }
  }

  /*
    To get the another result set of records when scolling down
  */
  public paginationOnScrollDown() {
    this.infiniteScroll.ngOnDestroy();
    this.infiniteScroll.setup();
    this.alertService.clearError();

    if (
      this.claimsListing.eobMetaData.totalRecordCount > this.recordsPerPage &&
      this.filteredClaims &&
      this.filteredClaims.length >= this.recordsPerPage &&
      !this.isSidenavOpened
    ) {
      this.isDisplaySpinner = true;
      let reqParams;
      const pagination = true;
      reqParams = this.claimsFilterPaginationReqParams(this.selectedMemberList, this.sortSelectedFilter, pagination);
      reqParams.scrollIndicator = 'DOWN';

      this.eobService.getClaims(reqParams, true).subscribe(apiData => {
        this.isDisplaySpinner = false;
        if (apiData && Object.keys(apiData).length) {
          this.claimsListing.eobMetaData = apiData.eobMetaData;
          if (!apiData.hasOwnProperty('result') && apiData.result !== 0) {
            if (apiData.hasOwnProperty('eobRecords') && apiData.eobRecords.length) {
              apiData.eobRecords.map(oeobRecords => {
                this.filteredClaims.push(oeobRecords);
              });
            }
            this.filteredClaimscount = apiData.eobMetaData.totalRecordCount;
          } else {
            this.alertService.setAlert('', apiData['displaymessage'], AlertType.Failure);
          }
        }
      });
    }
  }

  /*
    To get the another result set of records when scolling up
  */
  public onScrollUp() {
    //NOOP
  }

  /*
     To create the request params for sorting, filter & pagination
  */
  private claimsFilterPaginationReqParams(selectedMemberList, sortSelectedFilter, pagination) {
    const memberTypeMetaReqParams = {} as MemberTypeMetaInterface,
      claimFiltersMetaReqParams = {} as ClaimFiltersMetadataInterface,
      dateMetaReqParams = {} as DateMetaInterface,
      dateSearchListReqParams = {} as DateSearchListInterface,
      customDateRangeMetaReqParams = {} as CustomDateRangeMetaInterface,
      claimSummaryMetaReqParams = {} as ClaimSummaryMetadataInterface,
      claimsSummaryReqParams = {} as ClaimsSummaryRequestModelInterface;

    this.isSelectedDateInvalid = false;
    this.isCustomDateRangeInValid = false;

    if (this.dateSelectedFilter && Object.keys(this.dateSelectedFilter).length) {
      if (this.dateSelectedFilter.dateRange.toLowerCase().indexOf('all') !== -1) {
        dateMetaReqParams.allDatesRequired = true;
      } else if (this.dateSelectedFilter.dateRange.indexOf(this.allClaimsFilterOptions.date.custom.dateRange) !== -1) {
        dateMetaReqParams.allDatesRequired = false;
        this.checkFromDate = this.validateFromDate();
        this.checkToDate = this.validateToDate();
        if (!this.checkFromDate && !this.checkToDate) {
          this.validateCustomRange();
          customDateRangeMetaReqParams.startDate = this.datePipe.transform(this.fromDate, 'yyyy-MM-dd');
          customDateRangeMetaReqParams.endDate = this.datePipe.transform(this.toDate, 'yyyy-MM-dd');
          dateMetaReqParams.customDateRange = customDateRangeMetaReqParams;
        } else {
          this.isSelectedDateInvalid = true;
        }
      } else {
        dateSearchListReqParams.dateRange = this.dateSelectedFilter.dateRange;
        dateMetaReqParams.dateMetaList = new Array(dateSearchListReqParams);
        dateMetaReqParams.allDatesRequired = false;
      }
      claimFiltersMetaReqParams.dateMetaData = dateMetaReqParams;
    }

    if (selectedMemberList && selectedMemberList.length) {
      memberTypeMetaReqParams.allmembersRequired = this.allClaimsFilterOptions.member.allOptRequired;
      if (!memberTypeMetaReqParams.allmembersRequired) {
        memberTypeMetaReqParams.memberTypeMetaList = selectedMemberList;
      }
      claimFiltersMetaReqParams.memberTypeMetaData = memberTypeMetaReqParams;
    }

    claimsSummaryReqParams.useridin = this.authService.useridin;
    // for pagination
    claimSummaryMetaReqParams.hasMoreRecords = this.claimsListing.eobMetaData.hasMoreRecords;

    claimSummaryMetaReqParams.recordStartIndex = this.claimsListing.eobMetaData.recordStartIndex;
    claimSummaryMetaReqParams.recordEndIndex = this.claimsListing.eobMetaData.recordEndIndex;

    claimSummaryMetaReqParams.totalRecordCount = this.claimsListing.eobMetaData.totalRecordCount;

    // check if here is a change in sort order?
    if (this.currentSortValue !== this.sortSelectedFilter) {
      this.currentSortValue = this.sortSelectedFilter;
      claimSummaryMetaReqParams.sortOrder = sortSelectedFilter;
    } else {
      delete claimSummaryMetaReqParams.sortOrder;
    }

    claimsSummaryReqParams.eobMetaData = claimSummaryMetaReqParams;
    if (Object.keys(claimFiltersMetaReqParams).length) {
      claimsSummaryReqParams.filtersMetadata = claimFiltersMetaReqParams;
    }

    return claimsSummaryReqParams;
  }

  public openPDF() {
    if (!this.authService.impersonation()) {
      if (!this.isBCBSMAEmployee) {
        window.location.href = this.claimsFormUrl;
      }
      else {
        window.location.href = this.empClaimsFormUrl;
      }
      return;
    }
  }

  public openDentalPDF() {
    if (!this.authService.impersonation()) {
      if (!this.isBCBSMAEmployee) {
        window.location.href = this.dentalClaimsFormUrl;
      }
      else {
        window.location.href = this.empClaimsFormUrl;
      }
      return;
    }
  }
}
