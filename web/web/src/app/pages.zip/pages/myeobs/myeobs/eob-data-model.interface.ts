import { MyBlueGeneralAPIRequestModelInterface } from '../../../shared/models/interfaces/generic-app-models.interface';

export interface EOBListRequestModelInterface {
  useridin?: string;
  statementDateRange?: CustomDateRangeMetaInterface;
  serviceDateRange?: CustomDateRangeMetaInterface;
}
export interface EOBLinkRequestModelInterface {
  useridin?: string;
  claimID?: string;
  nascoSubscriberNumber?: string;
  serviceDate?: string;
}
export interface EOBListResponseModelInterface {
  EOBList: EOBRecord[];
}
export interface CustomDateRangeMetaInterface {
  startDate?: string;
  endDate?: string;
}

export interface EOBRecord extends MyBlueGeneralAPIRequestModelInterface {
  result: number;
  errormessage: string;
  displaymessage: string;
  ServicingPlanCode: string;
  nascoSubscriberNumber: string;
  controlPlanCode: string;
  eobClaimID: string;
  providerName: string;
  eobStatementDate: string;
  serviceStartDate: string;
  serviceEndDate: string;
}

export interface EOBDocumentReqParams extends MyBlueGeneralAPIRequestModelInterface {
  eobClaimId: number;
  nascoSubscriberNumber: number;
  serviceDate: string;
}
