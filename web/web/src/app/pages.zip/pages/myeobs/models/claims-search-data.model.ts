import { MyBlueGeneralAPIRequestModel } from '../../../shared/models/generic-app.model';
import { ClaimStatusMeta, DateMeta, MemberTypeMeta, PlanMeta, ProviderMeta, VisitTypeMeta } from './claims-generics.model';
import {
  ClaimFiltersMetadataInterface,
  ClaimSearchResponseInterface,
  ClaimsSearchRequestModelInterface,
  ClaimsSearchResponseModelInterface
} from './interfaces/claims-search-data-model.interface';

export class ClaimsSearchRequestModel extends MyBlueGeneralAPIRequestModel implements ClaimsSearchRequestModelInterface {
  searchText: string;
  filtersMetadata: ClaimFiltersMetadata;
}

export class ClaimsSearchResponseModel implements ClaimsSearchResponseModelInterface {
  searchResponseList: ClaimSearchResponse[];
}

export class ClaimFiltersMetadata implements ClaimFiltersMetadataInterface {
  planMetaData: PlanMeta;
  dateMetaData: DateMeta;
  memberTypeMetaData: MemberTypeMeta;
  providerMetaData: ProviderMeta;
  visitTypeMetaData: VisitTypeMeta;
  claimStatusMetaData: ClaimStatusMeta;
}

export class ClaimSearchResponse implements ClaimSearchResponseInterface {
  key: string;
  name: string;
}
