import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { AuthService, ConstantsService } from '../../shared/shared.module';
import { ClaimsDetails, MockClaim } from './eobs.model';
import { ClaimsSummaryRequestModel, ClaimsSummaryResponseModel, ClaimSummaryMetadata } from './models/claims-summary-data.model';
import {
  ClaimsSummaryRequestModelInterface,
  ClaimsSummaryResponseModelInterface
} from './models/interfaces/claims-summary-data-model.interface';
import { EOBListRequestModelInterface } from './myeobs/eob-data-model.interface';

@Injectable()
export class EobsService {
  private claimDetails = new BehaviorSubject<ClaimsDetails>(null);
  public claimDetails$ = this.claimDetails.asObservable();

  private claimRecord = new BehaviorSubject<MockClaim>(null);
  public claimRecord$ = this.claimRecord.asObservable();

  constructor(private http: AuthHttp, private constants: ConstantsService, private authService: AuthService) { }
  //#region
  // DEAD CODE
  // getClaims1(): Observable<any> {
  //   const request = {
  //     useridin: this.authService.useridin
  //   };

  //   if (sessionStorage.getItem('prvName') === 'null' || sessionStorage.getItem('prvName') === null) {
  //   } else {
  //     request['param1'] = sessionStorage.getItem('prvName');
  //   }

  //   //noinspection TsLint
  //   return sessionStorage.getItem('prvName') === 'null' || sessionStorage.getItem('prvName') === null ?
  //     this.http.encryptPost(this.constants.claimsUrl, request).map(response => {
  //       if (response && response['result'] !== '-1') {
  //         if (response['ROWSET'] && response['ROWSET'].totRows <= 1) {
  //           return [response['ROWSET'].ROWS];
  //         } else if (response['ROWSET']) {
  //           return response['ROWSET'].ROWS;
  //         }
  //       } else {
  //         return [];
  //       }
  //     }) :
  //     this.http.encryptPost(this.constants.claimsforproviderUrl, request).map(response => {
  //       if (response && response['result'] !== '-1') {
  //         if (response['ROWSET'] && response['ROWSET'].totRows <= 1) {
  //           return [response['ROWSET'].ROWS];
  //         } else {
  //           return response['ROWSET'].ROWS;
  //         }
  //       } else {
  //         return [];
  //       }
  //     });
  // }

  // getClaimDetails1(body): Observable<any> {
  //   const url = body.depid ? this.constants.claimsdepdetailsUrl : this.constants.claimdetailsUrl;
  //   return this.http.encryptPost(url, body);
  // }

  // getClaimProcessingStatus1(requestParams) {
  //   const url = this.constants.claimProcessingStatusUrl;
  //   return this.http.encryptPost(url, requestParams);
  // }

  // getBenefitsDocument1(requestParams) {
  //   const url = this.constants.benefitsLinkUrl;
  //   return this.http.encryptPost(url, requestParams);
  // }

  // setClaimDetails1(details: ClaimsDetails) {
  //   this.claimDetails.next(details);
  // }

  // setClaimRecord1(record: MockClaim) {
  //   this.claimRecord.next(record);
  // }

  // getClaimsBenefitsLink1(body): Observable<any> {
  //   const url = this.constants.benefitsLinkUrl;
  //   return this.http.encryptPost(url, body);
  // }

  // getEOBDocumentLink1(reqParams): Observable<any> {
  //   console.log(reqParams);

  //   return this.http.encryptPost(this.constants.getEobLinkUrl, reqParams, null, null, true);
  // }
  //#endregion
  getEobList(reqParams?: EOBListRequestModelInterface): Observable<any> {
    const request = reqParams || {
      useridin: this.authService.useridin
      //statementDateRange:{startDate: '03/10/2017',endDate: '03/08/2017' }
    };
    console.log(request);
    //reqParams.statementDateRange = {startDate: '03/10/2017',endDate: '03/08/2017' };
    return this.http.encryptPost(this.constants.getEobListUrl, request, null, null, true).map(response => {
      const memProfileStr = sessionStorage.getItem('memProfile');
      let memProfile: JSON;
      try {
        memProfile = JSON.parse(memProfileStr);
        response.filtersMetaData.memberTypeMetaData.memberTypeMetaList =
          response.filtersMetaData.memberTypeMetaData.memberTypeMetaList.map((member) => {
            memProfile['dependents'].some(dependant => {
              if (dependant.fullName === member.memberName) {
                member.isDependant = true;
                return true;
              } else {
                member.isDependant = false;
              }
            });
            return member;
          });

        response.filtersMetaData.memberTypeMetaData.memberTypeMetaList.sort((mem1, mem2) => !mem1.isDependant ? -1 : 0);
      } finally {

      }

      return response;

    });
  }

  getEobList_resolver(
    filterPaginationReqParams?: ClaimsSummaryRequestModelInterface,
    pagination?: boolean
  ): Observable<ClaimsSummaryResponseModelInterface> {
    let request: ClaimsSummaryRequestModelInterface = new ClaimsSummaryRequestModel(),
      globalSpinner = true;
    if (!filterPaginationReqParams) {
      request.useridin = this.authService.useridin;
      const sortorder = 'Most Recent';
      request.eobMetaData = new ClaimSummaryMetadata();
      request.eobMetaData.sortOrder = sortorder;
    } else {
      request = filterPaginationReqParams;
      if (pagination) {
        globalSpinner = false;
      }
    }

    return this.http.encryptPost(this.constants.getEobListUrl, request, null, null, globalSpinner).map(response => {
      const memProfileStr = sessionStorage.getItem('memProfile');
      let memProfile: JSON;
      try {
        memProfile = JSON.parse(memProfileStr);
        response.filtersMetaData.memberTypeMetaData.memberTypeMetaList =
          response.filtersMetaData.memberTypeMetaData.memberTypeMetaList.map((member) => {
            memProfile['dependents'].some(dependant => {
              if (dependant.fullName === member.memberName) {
                member.isDependant = true;
                return true;
              } else {
                member.isDependant = false;
              }
            });
            return member;
          });

        response.filtersMetaData.memberTypeMetaData.memberTypeMetaList.sort((mem1, mem2) => !mem1.isDependant ? -1 : 0);
      } finally {

      }

      return response as ClaimsSummaryResponseModel;

    });
  }

  getBenefitsDocument(requestParams) {
    const url = this.constants.benefitsLinkUrl;
    return this.http.encryptPost(url, requestParams);
  }

  getClaims(
    filterPaginationReqParams?: ClaimsSummaryRequestModelInterface,
    pagination?: boolean
  ): Observable<ClaimsSummaryResponseModelInterface> {
    let request: ClaimsSummaryRequestModelInterface = new ClaimsSummaryRequestModel(),
      globalSpinner = true;
    if (!filterPaginationReqParams) {
      request.useridin = this.authService.useridin;
      const sortorder = 'Most Recent';
      request.eobMetaData = new ClaimSummaryMetadata();
      request.eobMetaData.sortOrder = sortorder;
    } else {
      request = filterPaginationReqParams;
      if (pagination) {
        globalSpinner = false;
      }
    }

    return this.http.encryptPost(this.constants.getEobListUrl, request, null, null, globalSpinner).map(response => {
      return response as ClaimsSummaryResponseModel;
    });
  }
}
