import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { forkJoin } from 'rxjs/observable/forkJoin';
// import {DependantsService} from '../../../shared/services/dependant.service';
// import {GlobalService} from '../../../shared/services/global.service';
import { EobsService } from './eobs.service';
// import {AuthService, ConstantsService} from '../../../shared/shared.module';

@Injectable()
export class EOBSResolverService implements Resolve<Observable<any>> {
  constructor(
    //      public dependantsService: DependantsService,
    //               public authService: AuthService,
    //               public globalService: GlobalService,
    private eobService: EobsService // private constantService: ConstantsService
  ) {}

  resolve() {
    return this.getEobList();
  }

  getEobList() {
    const obs = [];
    obs.push(this.eobService.getEobList());
    return forkJoin(obs);
  }
}
