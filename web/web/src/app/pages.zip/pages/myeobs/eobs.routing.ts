import { RouterModule, Routes } from '@angular/router';
import { EobsComponent } from './myeobs/eobs.component';

const EOBS_ROUTER: Routes = [
  {
    path: '',
    component: EobsComponent,
    data: {
      pageTitle: 'My Claims'
    }
  }
];

export const ClaimsRouter = RouterModule.forChild(EOBS_ROUTER);
