import { Component } from '@angular/core';

@Component({
  selector: 'landing-pages-bluefit-0001',
  templateUrl: './landing-pages-bluefit-0001.component.html',
  styleUrls: ['./landing-pages-bluefit-0001.component.scss']
})
export class LandingPagesBluefit0001Component {
  AppstoreUrl: string;
}