import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { LandingPagesBluefit0001Component } from './landing-pages-bluefit-0001.component';
import { LandingPagesBluefit0002Component } from './landing-pages-bluefit-0002.component';
import { LandingPagesBluefit0003Component } from './landing-pages-bluefit-0003.component';
import { LandingPagesBluefit0004Component } from './landing-pages-bluefit-0004.component';
import { landingPagesRouter } from './landing-pages.routing';

@NgModule({
  imports: [CommonModule, landingPagesRouter],
  declarations: [LandingPagesBluefit0001Component, LandingPagesBluefit0002Component, LandingPagesBluefit0003Component, LandingPagesBluefit0004Component],
  providers: []
})
export class LandingPagesModule {}
