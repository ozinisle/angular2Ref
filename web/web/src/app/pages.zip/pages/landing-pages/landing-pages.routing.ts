import { RouterModule, Routes } from '@angular/router';
import { LandingPagesBluefit0001Component } from './landing-pages-bluefit-0001.component';
import { LandingPagesBluefit0002Component } from './landing-pages-bluefit-0002.component';
import { LandingPagesBluefit0003Component } from './landing-pages-bluefit-0003.component';
import { LandingPagesBluefit0004Component } from './landing-pages-bluefit-0004.component';

const LANDING_PAGES_ROUTER: Routes = [
  {
    path: 'bluefit-0001',
    component: LandingPagesBluefit0001Component
  },

  {
    path: 'bluefit-0002',
    component: LandingPagesBluefit0002Component
  },
  
  {
    path: 'bluefit-0003',
    component: LandingPagesBluefit0003Component
  },
  {
    path: 'bluefit-0004',
    component: LandingPagesBluefit0004Component
  }
];

export const landingPagesRouter = RouterModule.forChild(LANDING_PAGES_ROUTER);
