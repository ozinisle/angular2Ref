import { Component } from '@angular/core';

@Component({
  selector: 'landing-pages-bluefit-0004',
  templateUrl: './landing-pages-bluefit-0004.component.html',
  styleUrls: ['./landing-pages-bluefit-0004.component.scss']
})
export class LandingPagesBluefit0004Component {
  AppstoreUrl: string;
}