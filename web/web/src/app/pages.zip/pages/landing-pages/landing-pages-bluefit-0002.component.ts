import { Component } from '@angular/core';

@Component({
  selector: 'landing-pages-bluefit-0002',
  templateUrl: './landing-pages-bluefit-0002.component.html',
  styleUrls: ['./landing-pages-bluefit-0002.component.scss']
})
export class LandingPagesBluefit0002Component {
  AppstoreUrl: string;
}