import { Component } from '@angular/core';

@Component({
  selector: 'landing-pages-bluefit-0003',
  templateUrl: './landing-pages-bluefit-0003.component.html',
  styleUrls: ['./landing-pages-bluefit-0003.component.scss']
})
export class LandingPagesBluefit0003Component {
  AppstoreUrl: string;
}