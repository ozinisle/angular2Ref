import { RouterModule, Routes } from '@angular/router';
import { BenefitSearchLandingComponent } from './benefit-search-landing/benefit-search-landing.component';

const BS_ROUTES: Routes = [
    {
        path: '',
        component: BenefitSearchLandingComponent
    }
];

export const BenefitSearchRouter = RouterModule.forChild(BS_ROUTES);