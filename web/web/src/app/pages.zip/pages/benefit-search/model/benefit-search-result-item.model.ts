export interface BenefitSearchResultItem {
    benefitShortDescription: string;
    benefitCategoryName: string;
    benefitCategoryID: number;
    cpcCode?: string;
    planName?: string;
    productType?: string;
}

export interface BenefitSearchResultGroup {
    cpcCode: string;
    planName: string;
    productType: string;
    benefits: BenefitSearchResultItem[];
}

export interface BenefitSearchResultResponse {
    searchResults: BenefitSearchResultGroup[];
}
