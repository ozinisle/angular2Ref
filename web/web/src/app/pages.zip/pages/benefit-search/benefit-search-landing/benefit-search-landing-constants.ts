export const OTHER_POPULAR_LINKS = [
  {
    url: '/message-center/documents/tax-forms',
    title: 'Tax Forms',
    external: false,
    sso: false
  },
  {
    url: '/fitness-and-weightloss',
    title: 'Fitness & Weight Loss Reimbursement',
    external: false,
    sso: false
  },
  {
    url: 'https://www.bluecrossma.org/myblue/find-care/care-options/video-call-a-doctor',
    title: 'Virtual Video Visits (Telehealth)',
    external: true,
    sso: false
  },
  {
    url: '/myclaims',
    title: 'My Claims',
    external: false,
    sso: false
  },
  {
    url: '/myeobs',
    title: 'Explanation of Benefits',
    external: false,
    sso: false
  },
  {
    url: 'https://www.bluecrossma.org/myblue/contact-us',
    title: 'Billing Address for Non-group Premium Payments',
    external: true,
    sso: false
  }
];
