import { HttpClient } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { SharedModule } from '../../shared/shared.module';
import { EarnAndSavePageComponent } from './earn-and-save-page.component';
import { EarnAndSavePageRouter } from './earn-and-save-page.routing';

export function createTranslateLoader(http: HttpClient): TranslateHttpLoader {
  return new TranslateHttpLoader(http);
}

/**
 * @deprecated Not used for now.
 */
@NgModule({
  imports: [
    SharedModule,
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: createTranslateLoader,
        deps: [HttpClient]
      },
      isolate: false
    }),
    EarnAndSavePageRouter
  ],
  declarations: [EarnAndSavePageComponent]
})
export class EarnAndSavePageModule {}
