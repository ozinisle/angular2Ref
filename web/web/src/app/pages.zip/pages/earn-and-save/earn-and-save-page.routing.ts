import { RouterModule, Routes } from '@angular/router';
import { EarnAndSavePageComponent } from './earn-and-save-page.component';

const routes: Routes = [
  {
    path: '',
    component: EarnAndSavePageComponent
  }
];

/**
 * @deprecated Not used for now.
 */
// tslint:disable-next-line:variable-name
export const EarnAndSavePageRouter = RouterModule.forChild(routes);
