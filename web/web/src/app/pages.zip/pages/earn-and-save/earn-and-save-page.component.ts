import { Component } from '@angular/core';
import { MatDialog } from '@angular/material';
import { EarnAndSaveService } from '../../shared/services/earn-and-save/earn-and-save.service';

/**
 * @deprecated Not used for now.
 */
@Component({
  selector: 'app-earn-and-save-page',
  templateUrl: './earn-and-save-page.component.html',
  styleUrls: ['./earn-and-save-page.component.scss']
})
export class EarnAndSavePageComponent {
  public isEarnAndSaveWidgetEnabled$ = this.earnAndSaveService.isEarnAndSaveWidgetEnabledForCurrentUser$;
  public isMaximizePlanWidgetEnabled$ = this.earnAndSaveService.isMaximizePlanWidgetEnabledForCurrentUser$;

  // prettier-ignore
  constructor(
    private earnAndSaveService: EarnAndSaveService,
    public dialog: MatDialog
  ) {}
}
