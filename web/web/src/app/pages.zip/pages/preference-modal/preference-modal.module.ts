
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ProfileEmailModule } from '../../components/profile-email/profile-email.module';
import { ProfilePhoneModule } from '../../components/profile-phone/profile-phone.module';
import { ProfileSelectPreferenceModule } from '../../components/profile-select-preference/profile-select-preference.module';
import { verifyEmail } from '../../components/verify-email-mobile/verifyEmail.module';
import { SharedModule } from '../../shared/shared.module';
import { PreferenceModalService } from './preference-modal.service';
import { PreferenceModalComponent } from './preference-modal/preference-modal.component';

@NgModule({
  imports: [
    SharedModule,
    CommonModule,
    ProfileEmailModule,
    ProfilePhoneModule,
    verifyEmail,
    ProfileSelectPreferenceModule,
  ],
  providers: [PreferenceModalService],
  declarations: [
    PreferenceModalComponent,
  ],
  exports: [PreferenceModalComponent]
})
export class PreferenceModalModule { }
