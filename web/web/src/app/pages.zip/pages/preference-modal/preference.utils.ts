import { DatePipe } from '@angular/common';
import * as moment from 'moment-timezone';
import { VALID_UPDATE_TYPES } from './preference-modal/preference-modal.constants';
import { PreferenceList, ProgramList, ProgramListFilters, SelectedPrefObject } from './preference-modal/preference.model';

export const dateFilter = new DatePipe('en-US');
export const EDT_TZ_OFFSET = moment(new Date())
  .tz('America/New_York')
  .format('Z');
export const PN_TS_FORMAT = 'M/d/yyyy h:m:s aa';
export const TS_LOCALE = 'en_US';

export const createSelectedPrefObject = (channel, program, value) => {
  let selectedPrefObj: SelectedPrefObject;
  selectedPrefObj = {
    channelId: channel,
    programId: program,
    checked: value
  };
  return selectedPrefObj;
};

export const extractProgramGroupData = programGroupsObj => {
  const programList: ProgramList[] = [];
  let programListObject;
  let displayName;
  if (programGroupsObj && programGroupsObj.ProgramGroup) {
    programGroupsObj.ProgramGroup.forEach(group => {
      if (group.ID !== 'Consents_Available' && group.Programs[0]) {
        const filters: ProgramListFilters[] = [];
        group.Programs[0].Filters.forEach(filter => {
          filters.push({ id: filter.ID, channelID: filter.ChannelID, selected: false });
        });
        group.Programs[0].Locales[0].DisplayTags.forEach(tag => {
          displayName = tag.Key === 'Name' ? tag.Value : '';
        });
        programListObject = {
          id: group.Programs[0].ID,
          filters: filters,
          displayName: displayName
        };
        programList.push(programListObject);
      }
    });
  }
  programList.forEach(program => {
    program.filters.forEach((f, index) => {
      reOrderFilterArray(program, f, index);
    });
  });
  return programList;
};

export const getPreferenceCID = preferences => {
  const prefCID =
    preferences && preferences.result === -92914
      ? preferences.errormessage.slice(preferences.errormessage.length - 40)
      : preferences.Preferences[0].CID;
  sessionStorage.setItem('prefCID', JSON.stringify(prefCID));
  return prefCID;
};

export const extractPreferenceData = preferences => {
  const preferenceList: PreferenceList[] = [];
  let prefListObj: PreferenceList;
  if (!(preferences && preferences.result === -92914)) {
    preferences = preferences.Preferences.filter(x => x.FilterID !== 'CONSENT_PAPERLESS_SOLICIT');
    if (preferences.length > 0) {
      preferences.forEach(preference => {
        prefListObj = {
          PreferenceType: preference.PreferenceType,
          FilterID: preference.FilterID,
          CustomerDate: preference.CustomerDate,
          PreferenceAttributes: preference.PreferenceAttributes,
          CID: preference.CID,
          LastModifiedDate: preference.LastModifiedDate
        };
        preferenceList.push(prefListObj);
      });
    }
  }
  return preferenceList;
};

export const selectedPrefFilter = (programList, preferenceList) => {
  programList.forEach(program => {
    program.filters.forEach(filter => {
      filter.selected = false;
      preferenceList.forEach(selectedchannel => {
        if (filter.id === selectedchannel.FilterID && selectedchannel.PreferenceType === 1) {
          filter.selected = true;
        }
      });
    });
  });
  return programList;
};

export const reOrderFilterArray = (program, item, index) => {
  return item.channelID === 'SOLICIT' || item.channelID === 'EMAIL'
    ? program.filters.splice(0, 0, program.filters.splice(index, 1)[0])
    : item.channelID === 'SMS'
    ? program.filters.splice(1, 0, program.filters.splice(index, 1)[0])
    : program.filters.splice(2, 0, program.filters.splice(index, 1)[0]);
};

export const createConsentObject = (reqParam, showConsent) => {
  const consent: any = {};
  consent.PreferenceType = '1';
  consent.FilterID = 'CONSENT_PAPERLESS_SOLICIT';
  consent.PreferenceAttributes = createPreferenceAttributes(reqParam, true);
  consent.CustomerDate = showConsent
    ? dateFilter.transform(new Date(reqParam.consentData.consentTS), PN_TS_FORMAT, EDT_TZ_OFFSET, TS_LOCALE)
    : reqParam.consentData.consentTS;
  consent.CID = reqParam.prefCID;
  return consent;
};

export const createPreferenceAttributes = (reqParam, fromConsent?) => {
  const drupalVersion = reqParam.consentData.consentLanguageId;
  const updateType =
    reqParam.lastModifiedDate && VALID_UPDATE_TYPES.includes(reqParam.lastUpdateType)
      ? new Date(reqParam.lastModifiedDate).getDate() === new Date().getDate()
        ? reqParam.lastUpdateType
        : 'U'
      : 'A';
  const updateConsentType =
    reqParam.consentData.consentTS && VALID_UPDATE_TYPES.includes(reqParam.lastUpdateType)
      ? new Date(reqParam.consentData.consentTS).getDate() === new Date().getDate()
        ? reqParam.lastUpdateType
        : 'U'
      : 'A';
  const attributes = [
    {
      Key: 'PS_Update_Type',
      Value: fromConsent ? updateConsentType : updateType
    },
    {
      Key: 'PS_EventID',
      Value: reqParam.sessionid
    },
    {
      Key: 'PS_SystemName',
      Value: 'MyBlue_PC_WEB'
    },
    {
      Key: 'ConsentVerNo',
      Value: drupalVersion
    }
  ];
  return attributes;
};

export const createUpdatePrefObject = (programList, reqParam, showConsent) => {
  let changedPreferences: any = [];
  let programObj: any = {};
  let consent: any = {};
  consent = createConsentObject(reqParam, showConsent);
  programList.forEach(program => {
    program.filters.forEach(filter => {
      programObj = {};
      programObj.PreferenceType = '';
      programObj.FilterID = filter.id;
      programObj.CustomerDate = dateFilter.transform(new Date(), PN_TS_FORMAT, EDT_TZ_OFFSET, TS_LOCALE);
      programObj.PreferenceAttributes = createPreferenceAttributes(reqParam);
      programObj.CID = reqParam.prefCID;
      programObj.PreferenceType = filter.selected ? '1' : '2';
      changedPreferences.push(programObj);
    });
  });
  changedPreferences = [...changedPreferences, consent];
  return changedPreferences;
};

export const disableBtnWithValue = (programList, isCDHenabledUser) => {
  let counter = 0;
  let healthCounter = 0;
  programList.forEach(program => {
    if (program.id === 'Documents_Plan') {
      program.filters.forEach(filter => {
        if (!(filter.channelID === 'MAIL' && isCDHenabledUser)) {
          counter = filter.selected ? counter + 1 : counter;
        }
      });
    }
    else if(program.id === 'Health_Benefits') {
      program.filters.forEach(filter => {
        healthCounter = filter.selected ? healthCounter + 1 : healthCounter;
      });
    }
  });
  return (counter === 0 || (isCDHenabledUser && healthCounter === 0));
};

export const updateConsentReqParam = (useridin, consentData, drupalConsent, showConsent?) => {
  const consent = JSON.parse(sessionStorage.getItem('consentData'));
  const timestamp =
    consent.consentFlag !== 'Y' || showConsent
      ? dateFilter.transform(new Date(consentData.consentTS), PN_TS_FORMAT, EDT_TZ_OFFSET, TS_LOCALE)
      : consentData.consentTS;
  const reqParamater = {
    useridin: useridin,
    consentLanguageId: consentData.consentLanguageId,
    consentLanguage: consent.consentFlag !== 'Y' ? encodeURI(drupalConsent.Body) : consentData.consentLanguage,
    consentFlag: 'Y',
    consentTS: timestamp,
    modalFlag: 'Y'
  };
  return reqParamater;
};

export const createParamObject = (sessionid, consentData, lastModifiedDate, lastUpdateType, prefCID) => {
  const object: any = {};
  object.sessionid = sessionid;
  object.consentData = consentData;
  object.lastModifiedDate = lastModifiedDate;
  object.prefCID = prefCID;
  object.lastUpdateType = lastUpdateType;
  return object;
};

export const generateToolTip = programList => {
  const toolTip = {
    Documents_Plan: false,
    Health_Benefits: false,
    BC_News: false
  };
  if (programList && programList.length) {
    programList.forEach(program => (toolTip[program.id] = false));
  }
  return toolTip;
};

export const isMobilePreferenceSelected = programList => {
  let isMobilePref = false;
  programList.forEach(program => {
    program.filters.forEach(filter => {
      if (filter.channelID === 'SMS' && filter.selected && !isMobilePref) {
        isMobilePref = true;
      }
    });
  });
  return isMobilePref;
};

export const getLastPreferenceUpdates = (preferences: any) => {
  const lastPrefUpdates = { lastPrefUpdateType: null, lastPrefModifiedDate: null };
  if (!(preferences && preferences.result === -92914)) {
    preferences.Preferences.filter(preference => preference.FilterID === 'DOCS_PLAN_ONLINE').forEach(preference => {
      lastPrefUpdates.lastPrefModifiedDate = preference.LastModifiedDate ? preference.LastModifiedDate : null;
      preference.PreferenceAttributes.filter(preferenceAttribute => preferenceAttribute.Key === 'PS_Update_Type').forEach(
        preferenceAttribute => {
          lastPrefUpdates.lastPrefUpdateType = preferenceAttribute.Value;
        }
      );
    });
  }
  return lastPrefUpdates;
};

export const hasConsentPreference = (preferences: any) => {
  return preferences.filter(preference => preference.FilterID === 'CONSENT_PAPERLESS_SOLICIT').length;
};
