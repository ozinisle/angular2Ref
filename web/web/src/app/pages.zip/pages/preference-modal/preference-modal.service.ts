import { DatePipe } from '@angular/common';
import { Injectable, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment-timezone';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { of } from 'rxjs/observable/of';
import { ConsentModalComponent } from '../../components/consent-modal/consent-modal.component';
import { PlanConfigService } from '../../services/plan-config/plan-config-service';
import { AboutMeModalService } from '../../shared/components/about-me-modal/about-me-modal.service';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { GlobalService } from '../../shared/services/global.service';
import { PreferencesService } from '../../shared/services/myprofile/preferences.service';
import { ProfileService } from '../../shared/services/myprofile/profile.service';
import { AuthService, ConstantsService } from '../../shared/shared.module';
import { PreferenceModalComponent } from './preference-modal/preference-modal.component';
import { hasConsentPreference } from './preference.utils';

@Injectable()
export class PreferenceModalService implements OnInit {
  prefCID: string;
  postLoginInfo;
  showCompleteVerification = false;
  timezoneOffset = moment(new Date())
    .tz('America/New_York')
    .format('Z');
  isCDHEnabledUser = false;

  constructor(
    private globalService: GlobalService,
    public authService: AuthService,
    public dialog: MatDialog,
    private profileService: ProfileService,
    private authHttp: AuthHttp,
    private constants: ConstantsService,
    private dateFilter: DatePipe,
    private preferenceService: PreferencesService,
    private aboutMeModalService: AboutMeModalService,
    private planConfigService: PlanConfigService
  ) {}


  ngOnInit(): void {
    this.planConfigService.getCurrentPlanConfig$().subscribe(config => this.isCDHEnabledUser = config != null? config.isDigitalFirstCDH : false);
  }

  showPreference() {
    this.postLoginInfo = JSON.parse(sessionStorage.getItem('postLoginInfo'));
    const hasNoAltAdd = this.postLoginInfo && this.postLoginInfo.repPayeeFalg.toLowerCase() === 'false';
    const isMedicare = this.authService.authToken.userType && this.authService.authToken.userType.toLowerCase() === 'medicare';
    const showPreference = !hasNoAltAdd ? false : !isMedicare;
    return showPreference;
  }

  initiatePreference() {
    const impersonate = this.authService.impersonation();
    if (!impersonate) {
      this.postLoginInfo = JSON.parse(sessionStorage.getItem('postLoginInfo'));
      if (this.postLoginInfo) {
        //Needed to avoid unnecessary looping through the initiatePreference for Alternate Address Members
        if (this.showPreference()) {
          this.fetchPreferenceModalInfo();
        } else {
          this.aboutMeModalService.initiateAboutMeModal();
        }
      } else {
        setTimeout(() => {
          this.initiatePreference();
        }, 1000);
      }
    }
  }

  initiatePromo() {
    this.postLoginInfo = JSON.parse(sessionStorage.getItem('postLoginInfo'));
    if (this.postLoginInfo) {
      if (this.showPreference()) {
        this.preferenceService.swapPromo();
      }
    } else {
      setTimeout(() => {
        this.initiatePromo();
      }, 1000);
    }
  }

  fetchPreferenceModalInfo() {
    localStorage.removeItem('destinationURL');
    const hasActivePlan = this.authService.isUserActive();
    return forkJoin([this.profileService.fetchProfileInfo(), this.preferenceService.getConsent()])
      .filter(responses => responses[0] && responses[1])
      .subscribe(responses => {
        sessionStorage.setItem('consentData', JSON.stringify(responses[1]));
        if (responses[1].modalFlag == null || responses[1].modalFlag === 'N') {
          sessionStorage.setItem('preferenceModalShown', 'true');
          this.fetchModalData(responses[0]);
          this.showCompleteVerification = false;
        } else {
          this.aboutMeModalService.initiateAboutMeModal();
        }
      });
  }

  // fetchModalData(profileResponse) {
  //   let prefObject: any = [];
  //   let consentObj;
  //   this.preferenceService
  //     .getPreferences()
  //     .filter(response => response.result === -92914 || response.message)
  //     .switchMap(response => {
  //       return forkJoin([of(profileResponse), of(response), this.preferenceService.getProgramGroups(), this.getConsentDrupal()]);
  //     })
  //     .filter(responses => responses[2].message && responses[3])
  //     .subscribe(responses => {
  //       prefObject = responses[1].result === -92914 ? responses[1] : this.extractPreferenceDetails(responses[1].message);
  //       this.prefCID =
  //         responses[1].result === -92914 ? prefObject.errormessage.slice(prefObject.errormessage.length - 40) : prefObject[0].CID;
  //       const reqParam = [];
  //       // && (consentObj.consentLanguageId !== responses[3][0].Version) Removing this condition from if for MEP-489
  //       consentObj = JSON.parse(sessionStorage.getItem('consentData'));
  //       if (responses[1].result === -92914 || !hasConsentPreference(responses[1].message.Preferences)) {
  //         this.preferenceService.updatePreferences([...reqParam, this.createConsentObject(consentObj, responses[3])]).subscribe();
  //       }
  //       if (this.authService.isUserActive() === 'true') {
  //         this.showModal(responses, consentObj);
  //       } else if (consentObj.consentFlag !== 'Y') {
  //         this.showConsentModal(responses, consentObj);
  //       }
  //       this.authHttp.hideSpinnerLoading();
  //     });
  // }
  fetchModalData(profileResponse) {
    let prefObject: any = [];
    let consentObj;
    let isSmsSelected: boolean = false;
    let isEmailSelected: boolean = false;
    this.preferenceService
      .getPreferences()
      .filter(response => response.result === -92914 || response.message)
      .switchMap(response => {
        return forkJoin([of(profileResponse), of(response), this.preferenceService.getProgramGroups(), this.getConsentDrupal()]);
      })
      .filter(responses => responses[2].message && responses[3])
      .subscribe(responses => {
        prefObject = responses[1].result === -92914 ? responses[1] : this.extractPreferenceDetails(responses[1].message);
        this.prefCID =
          responses[1].result === -92914 ? prefObject.errormessage.slice(prefObject.errormessage.length - 40) : prefObject[0].CID;
        const reqParam = [];
        // && (consentObj.consentLanguageId !== responses[3][0].Version) Removing this condition from if for MEP-489
        consentObj = JSON.parse(sessionStorage.getItem('consentData'));
        if (responses[1].result === -92914 || !hasConsentPreference(responses[1].message.Preferences)) { 
          //default set for modalpopup user for first time.
          isEmailSelected = true;
          isSmsSelected = true;
          this.preferenceService.updatePreferences([...reqParam, this.createConsentObject(consentObj, responses[3])]).subscribe();
        }
          if(responses[1] && responses[1].result !== -92914) {
            if (responses[1].message.Preferences.length > 1) {
              responses[1].message.Preferences.forEach(value => {
                if (value.PreferenceType === 2 && value.ProgramID === 'Documents_Plan' && value.ChannelID === 'SOLICIT') {
                  isEmailSelected = true;
                }
                if (value.PreferenceType === 2 && value.ProgramID === 'Documents_Plan' && value.ChannelID === 'SMS') {
                  isSmsSelected = true;
                }
              });
            } else {
              if (
                responses[1].message.Preferences[0].PreferenceType === 1 &&
                responses[1].message.Preferences[0].ProgramID === 'Consent_Paperless' &&
                responses[1].message.Preferences[0].ChannelID === 'SOLICIT'
              ) {
                isEmailSelected = true;
                isSmsSelected = true;
              }
            }
          }

          if (this.authService.isUserActive() === 'true') {
            if(this.isCDHEnabledUser) {
              if(isEmailSelected && isSmsSelected){
                this.showModal(responses, consentObj);
              }
            }else {
              this.showModal(responses, consentObj);
            }
            if(sessionStorage.getItem('fromContactInfo') && sessionStorage.getItem('fromContactInfo') === 'true' && this.isCDHEnabledUser){
              sessionStorage.removeItem('fromContactInfo');
              this.showModal(responses, consentObj);
            }
          } else if (consentObj.consentFlag !== 'Y') {
            this.showConsentModal(responses, consentObj);
          }
          this.authHttp.hideSpinnerLoading();
        });
    }
  


  showModal(responses: any[], res) {
    this.dialog.open(PreferenceModalComponent, {
      disableClose: true,
      maxWidth: this.showCompleteVerification ? '600px' : '900px',
      data: {
        profile: responses[0] ? responses[0] : responses,
        programGroupsObj: responses[2] ? responses[2].message : null,
        preferences: responses[1] ? (responses[1].errormessage ? responses[1] : responses[1].message) : null,
        drupalConsent: responses[3] ? responses[3] : null,
        getConsentRes: res
      }
    });
  }

  showConsentModal(responses: any[], res) {
    this.dialog.open(ConsentModalComponent, {
      disableClose: true,
      maxWidth: this.showCompleteVerification ? '600px' : '900px',
      data: {
        preferences: responses[1] ? (responses[1].errormessage ? responses[1] : responses[1].message) : null,
        drupalConsent: responses[3] ? responses[3] : null,
        getConsentRes: res
      }
    });
  }

  getConsentDrupal() {
    return this.authHttp.get(this.constants.getconsentDrupal).filter((response: any) => response && response.length);
  }

  extractPreferenceDetails(res) {
    const obj: any = [];
    if (res.Preferences) {
      res.Preferences.map(item => {
        const singleItem: any = {};
        singleItem.ProgramID = item.ProgramID;
        singleItem.ChannelID = item.ChannelID;
        singleItem.FilterID = item.FilterID;
        singleItem.PreferenceType = item.PreferenceType;
        singleItem.CID = item.CID;
        obj.push(singleItem);
      });
    }
    return obj;
  }

  createConsentObject(data, drupalConsent) {
    const consent: any = {};
    consent.PreferenceType = '1';
    consent.FilterID = 'CONSENT_PAPERLESS_SOLICIT';
    consent.PreferenceAttributes = this.createPreferenceAttributes(data, drupalConsent);
    consent.CustomerDate = data.consentTS
      ? data.consentTS
      : this.dateFilter.transform(new Date(), 'M/d/yyyy h:m:s aa', this.timezoneOffset);
    consent.CID = this.prefCID;
    return consent;
  }

  createPreferenceAttributes(data, drupalConsent) {
    const sessionId = this.authHttp.sessionid();
    const consentVersion = data.consentLanguageId ? data.consentLanguageId : drupalConsent[0].Version;
    const attributes = [
      {
        Key: 'PS_Update_Type',
        Value: 'A'
      },
      {
        Key: 'PS_EventID',
        Value: sessionId
      },
      {
        Key: 'PS_SystemName',
        Value: 'MyBlue_PC_WEB'
      },
      {
        Key: 'ConsentVerNo',
        Value: consentVersion
      }
    ];
    return attributes;
  }
}
