import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { DependantsService } from '../../shared/services/dependant.service';
import { AuthService } from '../../shared/shared.module';
import { RequestEstimateService } from './request-estimate.service';

@Injectable()
export class RequestEstimateResolver implements Resolve<Observable<any>> {
  observer: Array<Observable<any>> = [];
  basicInfo: any;
  constructor(
    private requestEstimateService: RequestEstimateService,
    private dependantsService: DependantsService,
    private authService: AuthService
  ) {}

  resolve() {
    const hasDependents = this.authService.authToken && this.authService.authToken.hasDependents;
    if (hasDependents && hasDependents === 'true') {
      return forkJoin([this.requestEstimateService.getMemBasicInfo(), this.dependantsService.fetchDependentsList()]);
    } else {
      return this.requestEstimateService.getMemBasicInfo();
    }
  }
}
