import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { AuthService } from '../../shared/services/auth.service';
import { ConstantsService } from '../../shared/services/constants.service';
import { SharedModule } from '../../shared/shared.module';
import { authHttpFactory } from '../../shared/utils/authHttp.factory';
import { LoginRouter } from '../login/login.routing';
import { LoginService } from '../login/login.service';

@NgModule({
  declarations: [],
  exports: [],
  imports: [
    CommonModule,
    LoginRouter,
    HttpClientModule,
    FormsModule,
    SharedModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule
  ],
  providers: [
    LoginService,
    {
      provide: AuthHttp,
      useFactory: authHttpFactory,
      deps: [HttpClient, AuthService, ConstantsService]
    }
  ]
})
export class LoginModule {}
