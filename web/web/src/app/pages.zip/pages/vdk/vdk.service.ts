import { Injectable } from '@angular/core';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { AuthService } from '../../shared/services/auth.service';
declare let $: any;

@Injectable()
export class VdkService {
  constructor(private authService: AuthService, private authHttp: AuthHttp) {}

  login(request) {
    this.authService.cryptoToken = null;
    return this.authHttp.login(request);
  }
}
