import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { MigrationGuardHelper } from '../../shared/utils/migration-guard-helper';

@Injectable()
export class MigrationGuard implements CanActivate {
  constructor(private router: Router) {}

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    return MigrationGuardHelper.naivgateToRequiredStep(this.router, state.url);
  }
}
