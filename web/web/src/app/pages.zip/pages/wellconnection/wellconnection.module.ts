import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { MatDialogModule } from '@angular/material';
import { MaterializeModule } from 'angular2-materialize';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { SharedModule } from '../../shared/shared.module';
import { WellconnectionComponent } from './wellconnection.component';
import { WellconnectionService } from './wellconnection.service';

@NgModule({
  imports: [CommonModule,  SharedModule, InfiniteScrollModule, MaterializeModule,MatDialogModule,
  ],
  declarations: [WellconnectionComponent],

  providers: [WellconnectionService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class WellconnectionModule {}
