import { Location } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ServiceFailureModalComponent } from '../../shared/components/service-failure-modal/service-failure-modal.component';
import { GlobalService } from '../../shared/services/global.service';
import { WellconnectionService } from './wellconnection.service';

declare let $: any;
@Component({
  selector: 'app-wellconnection',
  templateUrl: './wellconnection.component.html',
  styleUrls: ['./wellconnection.component.scss']
})
export class WellconnectionComponent implements OnInit, OnDestroy {
  disclaimerAccepted: boolean;
  showTermsOfUse = false;
  displayLoadingText = false;
  displayTermsContainer = false;
  ssoSignIn = false;
  searchEnableRetryCount = 0;
  consumerEnrollmentResponse: any;
  tocInfo: string;
  destroy$ = new Subject<void>();
  constructor(
    private wellConnectionService: WellconnectionService,
    private location: Location,
    private dialog: MatDialog,
    private globalService: GlobalService
  ) {}

  ngOnInit() {
    this.showTermsOfUse = JSON.parse(sessionStorage.getItem('vitalsResponse')).platformProvider.details.disclaimerFlag;
    this.wellConnectionService
      .getTOCText()
      .pipe(takeUntil(this.destroy$))
      .subscribe(response => {
        this.tocInfo = response[0].Body;
      });
    if (this.showTermsOfUse) {
      this.showTermsContainer();
    } else {
      this.displayTermsContainer = false;
      this.ssoSignIn = true;
      this.consumerEnrollmentLocalService();
    }
  }

  showTermsContainer() {
    this.displayTermsContainer = true;
  }

  onCancel() {
    this.location.back();
  }

  onSubmit() {
    this.disclaimerAccepted = true;
    this.displayTermsContainer = false;
    this.ssoSignIn = true;
    this.consumerEnrollmentLocalService();
  }

  consumerEnrollmentLocalService() {
    this.wellConnectionService
      .openVirtualVisit()
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.consumerEnrollmentResponse = response;
          this.navigateOnResponse();
        },
        error => {
          this.location.back();
          $('#requestTimeoutError').modal('open');
        }
      );
  }

  navigateOnResponse() {
    if (
      this.consumerEnrollmentResponse &&
      this.consumerEnrollmentResponse.result === '0' &&
      this.consumerEnrollmentResponse.isConsumerEnrolled
    ) {
      setTimeout(() => {
        setTimeout(() => {
          const vitalsResponse = JSON.parse(sessionStorage.getItem('vitalsResponse'));
          vitalsResponse.platformProvider.details.disclaimerFlag = false;
          sessionStorage.setItem('vitalsResponse', JSON.stringify(vitalsResponse));
          this.location.back();
        }, 100);
        window.open('sso/amwell', '_blank');
      }, 2000);
    } else {
      if (this.searchEnableRetryCount === 0) {
        this.location.back();
      }
      setTimeout(() => {
        this.showDialog();
      }, 100);
    }
  }

  consumerEnrollmentGlobalService() {
    this.globalService
      .openVirtualVisit()
      .pipe(takeUntil(this.destroy$))
      .subscribe(
        (response: any) => {
          this.consumerEnrollmentResponse = response;
          this.navigateOnResponse();
        },
        error => {
          this.location.back();
          $('#requestTimeoutError').modal('open');
        }
      );
  }

  showDialog() {
    const dialog = this.dialog.open(ServiceFailureModalComponent, {
      panelClass: 'service-failure-alert',
      data: {
        showRetry: this.searchEnableRetryCount === 0,
        title: 'Error Occurred',
        description: this.consumerEnrollmentResponse.displaymessage,
        ctaRetry: 'Retry',
        cta2Text: 'Close',
        result: this.consumerEnrollmentResponse.result
      }
    });
    this.searchEnableRetryCount++;
    dialog.componentInstance.onRetryClicked.pipe(takeUntil(this.destroy$)).subscribe(() => {
      dialog.close();
      this.globalService
        .openVirtualVisit()
        .pipe(takeUntil(this.destroy$))
        .subscribe(
          response => {
            this.consumerEnrollmentResponse = response;
            this.navigateOnResponse();
          },
          error => {
            $('#requestTimeoutError').modal('open');
          }
        );
    });
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
