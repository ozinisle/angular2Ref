import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../../shared/utils/auth.guard';
import { WellconnectionComponent } from './wellconnection.component';

const Wellconnection_ROUTER: Routes = [
  {
    path: '',
    canActivate: [AuthGuard],
    component: WellconnectionComponent
  }
];
export const WellconnectionRouter = RouterModule.forChild(Wellconnection_ROUTER);
