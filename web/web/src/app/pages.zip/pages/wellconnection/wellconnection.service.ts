import { Injectable } from '@angular/core';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { AuthService, ConstantsService } from '../../shared/shared.module';

@Injectable()
export class WellconnectionService {
  constructor(private http: AuthHttp, 
    private authService: AuthService,
    private constantsService: ConstantsService,
    ) {}

  openVirtualVisit(){
    const generatedRequest = {
        useridin: this.authService.useridin,
        channelId: 'web',
        disclaimerFlag: true
    };
    return this.http.post(this.constantsService.consumerEnrollment, this.http.handleRequest(generatedRequest),null,false);
  }

  getTOCText(){
    return this.http.get(this.constantsService.getTocText);
  }
}
