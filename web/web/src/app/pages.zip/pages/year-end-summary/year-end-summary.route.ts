import { RouterModule, Routes } from '@angular/router';
import { YesComponent } from './yes/yes.component';

const YES_ROUTER: Routes = [
  {
    path: '',
    component: YesComponent
  }
];
export const YesRouter = RouterModule.forChild(YES_ROUTER);
