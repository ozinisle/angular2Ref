import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { MaterializeModule } from 'angular2-materialize';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { SharedModule } from '../../shared/shared.module';
import { YesRouter } from './year-end-summary.route';
import { YesFinDedComponent } from './yes-fin-ded/yes-fin-ded.component';
import { YesComponent } from './yes/yes.component';

@NgModule({
  imports: [CommonModule, YesRouter, SharedModule, InfiniteScrollModule, MaterializeModule],
  declarations: [YesComponent, YesFinDedComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class YearEndSummaryModule {}
