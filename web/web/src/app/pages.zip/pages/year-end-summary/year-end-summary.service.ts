import { Injectable } from '@angular/core';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { AuthService } from '../../shared/shared.module';
import { YesConstants } from './constants/yes.constants';
import {
  ClaimsSummaryFiterModel,
  ClaimsSummaryQueryModel,
  ClaimsSummaryQueryRecordModel,
  ClaimsSummaryRequestModel,
  ClaimsSummarySortModel
} from './modals/claimsSummary.model';
import { GetClaimsSummaryAmountsRequestModel } from './modals/getClaimsSummaryAmountsRequest.model';
import {
  ClaimsSummaryFiterInterface,
  ClaimsSummaryQueryInterface,
  ClaimsSummaryQueryRecordInterface,
  ClaimsSummaryRequestModelInterface,
  ClaimsSummarySortInterface
} from './modals/interfaces/claimsSummary-models.interface';
import { GetClaimsSummaryAmountsRequestModelInterface } from './modals/interfaces/getClaimsSummaryAmounts-models.interface';

@Injectable()
export class YearEndSummaryService {
  constructor(private http: AuthHttp, private authService: AuthService) {}

  getClaimsSummaryAmounts() {
    const claimsSummaryAmountsReq: GetClaimsSummaryAmountsRequestModelInterface = new GetClaimsSummaryAmountsRequestModel();
    if (this.authService.useridin && this.authService.useridin !== 'undefined') {
      claimsSummaryAmountsReq.setUserId(this.authService.useridin);
    }
    const url = YesConstants.urls.claimsSummaryAmounts;
    return this.http.encryptPost(url, claimsSummaryAmountsReq, null, null, false);
  }
  getClaimsSummary(year, scrolIndex, sortField, sortFieldValue) {
    const url = YesConstants.urls.claimsSummary;

    const claimsSummaryReq: ClaimsSummaryRequestModelInterface = new ClaimsSummaryRequestModel();
    const filterCriteria: ClaimsSummaryFiterInterface = new ClaimsSummaryFiterModel();
    const queryCriteria: ClaimsSummaryQueryInterface = new ClaimsSummaryQueryModel();
    const sortCriteria: ClaimsSummarySortInterface = new ClaimsSummarySortModel();
    const scroll: ClaimsSummaryQueryRecordInterface = new ClaimsSummaryQueryRecordModel();

    if (this.authService.useridin && this.authService.useridin !== 'undefined') {
      claimsSummaryReq.setUserId(this.authService.useridin);
    }
    if (sortField && sortFieldValue) {
      sortCriteria.setField(sortField);
      sortCriteria.setDirectionValue(sortFieldValue);
      claimsSummaryReq.sortCriteria = sortCriteria;
    }
    if (year) {
      filterCriteria.setField('Year');
      filterCriteria.setYearValue(year.toString());
      claimsSummaryReq.filterCriteria = filterCriteria;
    }

    if (scrolIndex) {
      claimsSummaryReq.queryCriteria = queryCriteria;
      scroll.setRecordStartIndex(scrolIndex);
      claimsSummaryReq.queryCriteria.scroll = scroll;
    }
    return this.http.encryptPost(url, claimsSummaryReq, null, null, false);
  }
  getPromoContent() {
    const url = YesConstants.urls.promoUrl;
    return this.http.get(url);
  }
}
