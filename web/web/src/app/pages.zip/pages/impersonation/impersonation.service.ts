import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { AuthService } from '../../shared/services/auth.service';

@Injectable()
export class ImpersonationService {
  private _encryptSecretKey = '123456$#@$^@1ERF';
  private errorFlag: boolean;

  constructor(private authService: AuthService, private authHttp: AuthHttp) { }

  impersonation(request) {
    this.authService.cryptoToken = null;
    return this.authHttp.impersonation(request);
  }

  decryptData(data: string): string {
    try {
      const key = CryptoJS.enc.Utf16.parse(this._encryptSecretKey);
      const iv = CryptoJS.enc.Utf16.parse(this._encryptSecretKey);
      const decrypted = CryptoJS.AES.decrypt(data, key, {
        keySize: 128 / 8,
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
      });

      return decrypted.toString(CryptoJS.enc.Utf16);
      //const bytes = CryptoJS.AES.decrypt(data.trim(), this._encryptSecretKey.trim()).toString(CryptoJS.enc.Utf8);
      //return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
      // return bytes;
    } catch (e) {
      console.log('Impersonation Error on Decryption' + e);
    }
  }

  impersonationPostLogin() {
    return this.authHttp.postlogin();
  }

  hideSpinnerLoading() {
    this.authHttp.hideSpinnerLoading();
  }

  setErrorFlag(errorFlag: boolean) {
    this.errorFlag = errorFlag;
    return this.errorFlag;
  }

  getErrorFlag() {
    return this.errorFlag;
  }
}
