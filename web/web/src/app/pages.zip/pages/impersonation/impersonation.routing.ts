import { RouterModule, Routes } from '@angular/router';
import { ImpersonationGuard } from '../../shared/utils/impersonation.guard';
import { ImpersonationErrorComponent } from './impersonation-error/impersonation-error.component';
import { ImpersonationComponent } from './impersonation.component';

//TODO: Implement Guards properly register workflow
const Impersonation_ROUTER: Routes = [
  {
    path: 'error',
    component: ImpersonationErrorComponent
  },
  {
    path: ':useridin',
    canActivate: [ImpersonationGuard],
    component: ImpersonationComponent
  }
  // {
  //   path: 'impersonation/:useridin',
  //   canActivate: [ImpersonationGuard],
  //   component: ImpersonationComponent,
  // },
];

export const ImpersonationRouter = RouterModule.forChild(Impersonation_ROUTER);
