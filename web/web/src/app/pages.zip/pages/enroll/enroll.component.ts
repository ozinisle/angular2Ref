import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, ElementRef, HostListener, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { MatRadioChange, MatStepper } from '@angular/material';
import { Router } from '@angular/router';
import * as momenttz from 'moment-timezone';
import { Observable } from 'rxjs/Observable';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { map, pairwise, startWith } from 'rxjs/operators';
import { Subject } from 'rxjs/Subject';
import { AlertType } from '../../shared/alerts/alertType.model';
import { RegType } from '../../shared/models/regType.enum';
import { AlertService } from '../../shared/services/alert.service';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { ConstantsService } from '../../shared/services/constants.service';
import { GlobalService } from '../../shared/services/global.service';
import { PreferencesService } from '../../shared/services/myprofile/preferences.service';
import { ProfileService } from '../../shared/services/myprofile/profile.service';
import { AuthService, ValidationService } from '../../shared/shared.module';
import { LoginService } from '../login/login.service';
import {
  createUpdatePrefObject, extractPreferenceData,
  extractProgramGroupData,
  getLastPreferenceUpdates,
  getPreferenceCID,
  selectedPrefFilter
} from '../preference-modal/preference.utils';
import { RegistrationModuleConstants } from '../registration/constants/registration-module.constants';
import { FormGroupControlsModel, VerifyAccessCodeInputValidationResultModel } from '../registration/models/registrationModule.models';
import { RegistrationService } from '../registration/registration.module';
import { EnrollUserDetails, ServiceResponse, UpdateUserDetails } from './enroll.model';
declare let $: any;
@Component({
  selector: 'enroll',
  templateUrl: './enroll.component.html',
  styleUrls: ['./enroll.component.scss']
})
export class EnrollComponent implements OnInit, OnDestroy {
  activeExistingUser = 0;
  activeNewUser = 0;
  displayCog = true;
  displayUserPlus = true;
  planDocEmailCheckBox: boolean;
  planDocTextCheckBox: boolean;
  managingHealthEmailCheckBox: boolean;
  managingHealthTextCheckBox: boolean;
  displayInfo = true;
  isEncError = false;
  pwdErrorMessage: any;
  errorMessage = 'We\'re currently experiencing technical difficulties. Please try again later, or call 1-888-772-1722 for immediate assistance.';
  encryptionFailureCd = -95900;
  planIdMissingErrorCd = -95901;
  acctNumMissingErrorCd = -95902;
  redirectUrlMissingErrorCd = -95903;
  returnUrlMissingErrorCd = -95904;
  existingCommPreference = false;
  isProfileCreated: boolean;
  programList = [];
  preferenceList = [];
  preferences: any;
  consentDetails: any;
  programGroupsObj: any;
  prefCID: any;
  lastModifiedDate: any;
  public isMobileLayout = false;
  lastUpdateType: any;
  showConsent: boolean;
  drupalConsent: any;
  frmPageExistingUser: boolean;
  allowedSpecialCharters = '! @ # $ % ^ & * ( ) + ~ . , / [ ] { } -';
  phoneMask: any[];
  dobMask: any[];
  showageErrorMsg: boolean;
  programListNew = [];
  userPreferenceDiv: boolean;
  existinguserHeaderMsg: boolean;
  newuserHeaderMsg: boolean;
  isPrefSubEnabled: boolean;
  optionsChecked: number;
  userPrefFormGroup: FormGroup;
  modalErrorMsg: string;
  validatePWDErrMsg: boolean;
  enabletermsbtn: boolean;
  emailChannelSelected: boolean;
  mobileChannelSelected: boolean;
  path: any;
  fromVerifyChannelflow: boolean;
  isVerifyPhone: boolean;
  @ViewChild('conditions') elementView: ElementRef;
  passwordTypePlaceholder: string;
  passwordIcon: string;
  passwordType: string;
  passwordShowFlag: boolean;
  awesomeFontUser: string;
  awesomeFontCog: string;
  userSelectionDiv = true;
  signUpPlaceholder: string;
  registerUserHeaderMessage = true;
  profileUpdateHeaderMessage = false;
  existingUserDiv = false;
  emailRegistrationDiv = false;
  otcVerificationDiv = false;
  userProfileDiv = false;
  loginForm: FormGroup;
  newUserFormGroup: FormGroup;
  emailIdFormGroup: FormGroup;
  passwordFormGroup: FormGroup;
  otcFormGroup: FormGroup;
  userProfileFormGroup: FormGroup;
  userDetail: EnrollUserDetails;
  updateUserDetail: UpdateUserDetails;
  drupalres: any;
  redirectUrl: string;
  emailRegistration = false;
  mobileRegistration = false;
  userFirstName: string;
  private shiftKeyDown = false;
  @ViewChild('conditions') elementViewer: ElementRef;
  @ViewChild('accesscode1') accesscode1: ElementRef;
  @ViewChild('accesscode2') accesscode2: ElementRef;
  @ViewChild('accesscode3') accesscode3: ElementRef;
  @ViewChild('accesscode4') accesscode4: ElementRef;
  @ViewChild('accesscode5') accesscode5: ElementRef;
  @ViewChild('accesscode6') accesscode6: ElementRef;
  public verifyaccesscodeForm: FormGroup;
  public isFormSubmitted = false;
  public registrationModuleConstants;
  public verifyaccesscodeFormValidator: VerifyAccessCodeInputValidationResultModel = new VerifyAccessCodeInputValidationResultModel();
  @ViewChild('stepper') private myStepper: MatStepper;
  destroy$ = new Subject<void>();
  shopperFlag: boolean;
  memberFlag: boolean;
  flowType:String;
  showToolTip: boolean;
  showToolTip2: boolean;
  showToolTip3: boolean;
  
  constructor(
    private formBuilder: FormBuilder,
    private regService: RegistrationService,
    private loginService: LoginService,
    private alertService: AlertService,
    private http: HttpClient,
    private fb: FormBuilder,
    private datePipe: DatePipe,
    private constant: ConstantsService,
    private validationService: ValidationService,
    private authHttp: AuthHttp,
    private httpClient: HttpClient,
    private globalService: GlobalService,
    private preferencesService: PreferencesService,
    private authService: AuthService,
    private profileService: ProfileService,
    private router: Router,
    private dateFilter: DatePipe
  ) {

    this.phoneMask = this.validationService.enrollPhoneRegister;
    this.dobMask = this.validationService.dobMask;

    this.verifyaccesscodeForm = this.fb.group(
      {
        accesscode1: ['', [Validators.required]],
        accesscode2: ['', [Validators.required]],
        accesscode3: ['', [Validators.required]],
        accesscode4: ['', [Validators.required]],
        accesscode5: ['', [Validators.required]],
        accesscode6: ['', [Validators.required]]
      },
      {
        validator: this.validationService.accessCodeValidator()
      }
    );
    this.verifyaccesscodeForm.valueChanges.pipe(startWith(''), pairwise()).subscribe(accesscodes => {
      const prevVals = accesscodes[0];
      const newVals = accesscodes[1];
      Object.keys(newVals).forEach((key, index) => {
        const newItemValue = (newVals[key] ? newVals[key] : '').toString();
        const oldItemValue = (prevVals[key] ? prevVals[key] : '').toString();
        // if all validations work fine; newItemValue string length will never be more than 2 digits
        // code depends on previous validations to run without fail.
        if (newItemValue !== oldItemValue && newItemValue.length > 1) {
          const digits = newItemValue.split('');
          const currentIndex = index + 1;
          const allEqual = digits.every((val, i, arr) => val === arr[0]);
          if (allEqual) {
            this.verifyaccesscodeForm.get('accesscode' + currentIndex).setValue(digits[0], { emitEvent: false });
          } else {
            digits.forEach(digit => {
              if (digit !== oldItemValue) {
                this.verifyaccesscodeForm.get('accesscode' + currentIndex).setValue(digit, { emitEvent: false });
              }
            });
          }
          this.verifyaccesscodeForm.get('accesscode' + currentIndex).updateValueAndValidity();
        }
      });
    });
  }

  timezoneOffset = momenttz(new Date())
    .tz('America/New_York')
    .format('Z');

  hintQuestions = this.constant.hintQuestions;

  get registerFormArray(): AbstractControl | null {
    return this.emailIdFormGroup.get('registerFormArray');
  }
  get profileFormArray(): AbstractControl | null {
    return this.userProfileFormGroup.get('profileFormArray');
  }

  get preferenceFormArray(): AbstractControl | null {
    return this.userPrefFormGroup.get('preferenceFormArray');
  }
  onScroll() {
    if (
      this.elementViewer.nativeElement.offsetHeight + Math.round(this.elementViewer.nativeElement.scrollTop) >=
      this.elementViewer.nativeElement.scrollHeight
    ) {
      this.enabletermsbtn = true;
    } else {
      this.enabletermsbtn = false;
    }
  }

  public valueChangeplanDoc(event, stringType) {
    if (stringType === 'planDocEmailCheckBox') {
      this.planDocEmailCheckBox = event.checked;
      if (this.planDocTextCheckBox) {
        this.planDocTextCheckBox = !event.checked;
      }
    } else {
      this.planDocTextCheckBox = event.checked;
      if (this.planDocEmailCheckBox) {
        this.planDocEmailCheckBox = !event.checked;
      }
    }

  }

  ngOnInit() {
    $('#openEnrollServiceError').modal({ dismissible: true });
    $('#openPrefUpdateSuccessModal').modal({ dismissible: false });
    window.onresize = () => this.isMobileLayout = window.innerWidth <= 991;
    this.registrationModuleConstants = RegistrationModuleConstants;
    this.redirectUrl = sessionStorage.getItem('redirectUrl');
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    this.returnUrl = this.getURLs(urlParams.get('info'));
    if ((urlParams.get('info') === null) || (urlParams.get('info') === '')) {
      this.isEncError = true;
    }

    this.loginForm = this.formBuilder.group({
      useridin: ['', Validators.required],
      passwordin: ['', Validators.required]
    });

    this.userPrefFormGroup = this.formBuilder.group({
      Health_Benefits: ['', ''],
      Documents_Plan: ['', '']
    });

    this.newUserFormGroup = this.formBuilder.group({
      useridin: ['', Validators.required],
      password: ['', Validators.required]
    });
    this.emailIdFormGroup = this.formBuilder.group({
      registerFormArray: this.formBuilder.array([
        this.formBuilder.group({
          emailIdIn: ['', Validators.required],
          mobileNumberIn: ['', Validators.required]
        }),
        this.formBuilder.group({
          password: ['', Validators.email]
        }),
        this.formBuilder.group({
          receiveinfo: [false]
        })
      ])
    });
    this.otcFormGroup = this.formBuilder.group({
      code: ['', Validators.required]
    });

    this.userProfileFormGroup = this.formBuilder.group({
      profileFormArray: this.formBuilder.array([
        this.formBuilder.group({
          firstname: ['', [Validators.required, Validators.pattern(/^[a-zA-Z]+$/)]],
          lastname: ['', [Validators.required, Validators.pattern(/^[a-zA-Z]+$/)]]
        }),
        this.formBuilder.group({
          DOB: ['', [Validators.required, Validators.pattern(/^(0\d{1}|1[0-2])\/([0-2]\d{1}|3[0-1])\/(19|20)\d{2}$/)]]
        }),
        this.formBuilder.group({
          mobile: ['', [Validators.required, Validators.pattern(/^\([0-9]{3}\)-[0-9]{3}-[0-9]{4}$/)]],
          email: ['', [Validators.required, Validators.pattern(/^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/)]]
        }),
        this.formBuilder.group({
          hintQuestion: ['', Validators.required],
          hintAnswer: ['', [Validators.required, Validators.minLength(3)]]
        }),
        this.formBuilder.group({
          questionAnswerSelection: ['', Validators.required]
        })
      ])
    });
    this.http.get(this.constant.getconsentDrupal).takeUntil(this.destroy$).subscribe(drupalres => {
      this.drupalres = drupalres;
      sessionStorage.setItem('consentDrupalContent', JSON.stringify(drupalres));
    });

    // For Password show / hide
    this.passwordType = 'password';
    this.passwordTypePlaceholder = 'Show';
    this.passwordIcon = 'far fa-eye-slash'
    this.passwordShowFlag = false;
    this.clearSessionStorage();
  }

  clearSessionStorage() {
    console.log('removing redundant session storage items');
    sessionStorage.removeItem('_profileData_');
    sessionStorage.removeItem('postLoginInfo');
    sessionStorage.removeItem('email-password');
    sessionStorage.removeItem('memProfile');
    sessionStorage.removeItem('updatePrefData');
    sessionStorage.removeItem('consentData');
    sessionStorage.removeItem('authToken');
    sessionStorage.removeItem('consentDrupalContent');
    sessionStorage.removeItem('prefCID');
    sessionStorage.removeItem('consentDrupalData');
    sessionStorage.removeItem('token');
  }

  ngOnDestroy() {
    this.alertService.clearError();
    this.destroy$.next();
    this.destroy$.complete();
  }

  @HostListener("document: click")
  clickedOut() {
    this.showToolTip = false;
    this.showToolTip2 = false;
    this.showToolTip3 = false;
  }

  showToolTipToggle(programId, event) {
    if(programId==='Health_Benefits')
    {
      this.showToolTip = !this.showToolTip;
    }
    else if(programId==='Documents_Plan')
    {
      this.showToolTip2 = !this.showToolTip2;
    }
    else if(programId==='BC_News')
    {
      this.showToolTip3 = !this.showToolTip3;
    }
    event.stopPropagation()
  }
  
  togglePasswordVisibility() {
    const typeDetails = this.globalService.togglePasswordType(this.passwordType);
    this.passwordType = typeDetails.type;
    this.passwordTypePlaceholder = typeDetails.placeHolder;
    this.passwordIcon = this.passwordTypePlaceholder === 'Show' ? 'fas fa-eye' : 'far fa-eye-slash';
    this.passwordShowFlag = !this.passwordShowFlag;
  }

  hideUserSelection() {
    this.userSelectionDiv = false;
  }

  showUserSelection() {
    this.userSelectionDiv = true;
  }

  splitAndPlacePastedValues(event, materialForm): boolean {
    event.preventDefault();
    let pastedData = '';
    if (event.clipboardData) {
      pastedData = event.clipboardData.getData('text/plain');
    } else if (window['clipboardData']) {
      pastedData = window['clipboardData'].getData('Text');
    }
    pastedData = pastedData.replace(/\D/g, '');
    let pastedCharArr = pastedData.split('');
    if (pastedCharArr.length > 6) {
      pastedCharArr = pastedCharArr.splice(0, 6);
    }

    const accessCodeFields: NodeListOf<Element> = document.querySelectorAll('input.access-code');
    Object.keys(materialForm.controls).forEach((controlName, controlIndex) => {
      const pastedNumber: string = pastedCharArr[controlIndex];
      if (pastedNumber) {
        const formInputControl: FormControl = materialForm.get(controlName);
        // focus method does not work as such in ie11. hence requires a timeout block as fix/workaround for the same
        setTimeout(() => {
          (accessCodeFields[controlIndex] as HTMLInputElement).focus();
          formInputControl.setValue(pastedNumber);
        }, 10);
      } else {
        return false;
      }
    });

    this.getMatFormClass(materialForm);
    return true;
  }

  getMatFormClass(materialForm: FormGroup): VerifyAccessCodeInputValidationResultModel {
    this.verifyaccesscodeFormValidator = new VerifyAccessCodeInputValidationResultModel();

    if (!materialForm) {
      throw new Error(RegistrationModuleConstants.errorMessages.invalidMaterialFormError);
    }

    const controls: FormGroupControlsModel = materialForm.controls;
    const controlNames = RegistrationModuleConstants.controls;
    const accessCodeControl1 = controls[controlNames.accessCode1];
    const accessCodeControl2 = controls[controlNames.accessCode2];
    const accessCodeControl3 = controls[controlNames.accessCode3];
    const accessCodeControl4 = controls[controlNames.accessCode4];
    const accessCodeControl5 = controls[controlNames.accessCode5];
    const accessCodeControl6 = controls[controlNames.accessCode6];

    if (
      !(accessCodeControl1 && accessCodeControl2 && accessCodeControl3 && accessCodeControl4 && accessCodeControl5 && accessCodeControl6)
    ) {
      return this.verifyaccesscodeFormValidator;
    }

    const controlErrors: ValidationErrors =
      accessCodeControl1.errors ||
      accessCodeControl2.errors ||
      accessCodeControl3.errors ||
      accessCodeControl4.errors ||
      accessCodeControl5.errors ||
      accessCodeControl6.errors;

    const allTouched: boolean =
      accessCodeControl1.touched &&
      accessCodeControl2.touched &&
      accessCodeControl3.touched &&
      accessCodeControl4.touched &&
      accessCodeControl5.touched &&
      accessCodeControl6.touched;

    const errorFlag: boolean = controlErrors ? true : !allTouched;

    const hasRequiredErrorFlags: boolean =
      (accessCodeControl1.errors && accessCodeControl1.errors.required) ||
      (accessCodeControl2.errors && accessCodeControl2.errors.required) ||
      (accessCodeControl3.errors && accessCodeControl3.errors.required) ||
      (accessCodeControl4.errors && accessCodeControl4.errors.required) ||
      (accessCodeControl5.errors && accessCodeControl5.errors.required) ||
      (accessCodeControl6.errors && accessCodeControl6.errors.required);

    this.verifyaccesscodeFormValidator.isError = errorFlag;
    this.verifyaccesscodeFormValidator.hasErrors = hasRequiredErrorFlags;
  }
  onKeyDown(event) {
    if (event.keyCode === 16) {
      this.shiftKeyDown = true;
    }
    if (this.shiftKeyDown || !this.isValidKeyPressed(event)) {
      return false;
    }
  }

  onKeyUp(event, previousElement, nextElement, materialForm) {
    if (this.shiftKeyDown) {
      if (event.keyCode === 16) {
        this.shiftKeyDown = false;
      }
      return false;
    }

    if (event && event.target['value'] === '' && !this.isValidKeyPressed(event)) {
      return false;
    }
    this.getMatFormClass(materialForm);
    if ((event.key === 'Backspace' || event.which === 37 || event.key === 'ArrowLeft') && previousElement) {
      previousElement.focus();
    }
    if (
      (event.key === 'ArrowRight' ||
        event.which === 39 ||
        (event.keyCode >= 48 && event.keyCode <= 57) ||
        (event.keyCode >= 96 && event.keyCode <= 105)) &&
      nextElement
    ) {
      setTimeout(() => nextElement.focus(), 100);
    }
  }

  isValidKeyPressed(event) {
    const key = event.key;
    return (
      key === 'Backspace' ||
      key === 'Control' ||
      key === 'ArrowLeft' ||
      key === 'ArrowRight' ||
      (event.keyCode >= 48 && event.keyCode <= 57) ||
      (event.keyCode >= 96 && event.keyCode <= 105) || event.keyCode == 86
    );
  }

  onClickNewUser() {
    this.activeNewUser = 1;
    this.activeExistingUser = 0;
    this.displayUserPlus = !this.displayUserPlus;
    this.displayCog = true;
    this.emailRegistrationDiv = true;
    this.existingUserDiv = false;
  }
  onClickInfo() {
    this.displayInfo = !this.displayInfo;
  }

  onClickExistingUser() {
    this.activeNewUser = 0;
    this.activeExistingUser = 1;
    this.displayUserPlus = true;
    this.displayCog = !this.displayCog;
    this.existingUserDiv = true;
    this.emailRegistrationDiv = false;
    this.emailRegistration = false;
    this.mobileRegistration = false;
  }

  onChange(commChannel: MatRadioChange) {
    if (commChannel.value === 'mobile') {
      this.mobileRegistration = true;
      this.emailRegistration = false;
      this.signUpPlaceholder = '(###) - ### - ####';
    } else {
      this.emailRegistration = true;
      this.mobileRegistration = false;
      this.signUpPlaceholder = 'Enter your email address';
    }
  }

  onNewUserSubmit() {
    this.alertService.clearError();
    this.userDetail = new EnrollUserDetails;
    this.userDetail.useridin = this.emailRegistration ? this.userDetail.useridin = this.emailIdFormGroup.get('registerFormArray').get([0]).get('emailIdIn').value : this.emailIdFormGroup.get('registerFormArray').get([0]).get('mobileNumberIn').value.replace(/\D+/g, '');
    this.userDetail.password = this.emailIdFormGroup.get('registerFormArray').get([1]).get('password').value;
    this.userDetail.regType = this.emailRegistration ? RegType.EMAIL : RegType.MOBILE;
    this.regService
      .checkUser(this.userDetail)
      .takeUntil(this.destroy$)
      .subscribe((resp: ServiceResponse) => {
        if (resp.result === 0) {
          this.otcVerificationDiv = true;
          this.userSelectionDiv = false;
          this.emailRegistrationDiv = false;
        } else {
          if (this.mobileRegistration && resp.displaymessage !== 'Account already exists') {
            this.modalErrorMsg = 'The mobile number you have entered is invalid. Please enter a valid mobile number';
          }
          else {
            this.modalErrorMsg = resp.displaymessage;
          }
          $('#openEnrollServiceError').modal('open');
          this.myStepper.reset();
          this.showUserSelection();
        }
      });
  }

  onExistingUserSubmit() {
    const loginData = this.loginForm.value;
    sessionStorage.setItem('key', this.loginForm.controls.useridin.value);
    this.alertService.clearError();
    this.loginService
      .login(loginData)
      .subscribe(
        response => {
          //Signin succesful -redirect to commpref/profile page 
          this.checkProfileAndRedirect();
          //$('#openPrefUpdateSuccessModal').modal('open');
        },
        err => {
          this.authHttp.hideSpinnerLoading();
          console.log('Existing user error', err.error.displaymessage);
          this.modalErrorMsg = err.error.displaymessage;
          $('#openEnrollServiceError').modal('open');
        }
      );
  }

  checkProfileAndRedirect() {
    this.authService.useridin = this.loginForm.controls.useridin.value;
    this.alertService.clearError();
    this.profileService.fetchProfileInfo()
      .takeUntil(this.destroy$)
      .subscribe(profileInfo => {

        this.flowType = sessionStorage.getItem('flowType');
        console.log('profileInfo', profileInfo);
        
        if ((profileInfo.phoneNumber === '') || (profileInfo.emailAddress === '')) {
          this.handleShopperWithNoProfile();
        } else {
          this.handleShopperWithProfile();
        }
        
      },
        err => {
          this.authHttp.hideSpinnerLoading();
          this.modalErrorMsg = err.error.displaymessage;
          $('#openEnrollServiceError').modal('open');
        }
      );
    return
  }

  private handleShopperWithNoProfile() {
    this.userProfileDiv = true;
    this.shopperFlag = true;
    if (this.authService.useridin.indexOf('@') === -1) { //user registered with email
      this.mobileRegistration = true;
    }
    else {
      this.emailRegistration = true;
    }
    this.existingUserDiv = false
    this.userSelectionDiv = false;
    this.userDetail = new EnrollUserDetails;
    this.userDetail.useridin = this.loginForm.controls.useridin.value;
    this.frmPageExistingUser = true;
    this.registerUserHeaderMessage = false;
    this.profileUpdateHeaderMessage = true;
    this.existinguserHeaderMsg = false;
    this.newuserHeaderMsg = false;
    return;
  }

  private handleShopperWithProfile() {
    const flagRequest$ = this.flagUserWithExistingProfileAsShopper();
    flagRequest$.takeUntil(this.destroy$).
      subscribe((response: ServiceResponse) => {
        if (response.result === 0) {
          if (response.usr_prefcenterid != null && response.usr_prefcenterid != "") {
            this.setCID(response.usr_prefcenterid);
          }
        } else {
          console.error("Could not flag user as shopper", response);
        }
        console.log("Calling getPreferences");
        this.getPreferences(this.loginForm.controls.useridin.value);
        this.getConsent();
        this.memberFlag = true;
        this.existingCommPreference = true;
        this.existingUserDiv = false
        this.userSelectionDiv = false;
        this.userProfileDiv = false;
        this.registerUserHeaderMessage = false;
        this.existinguserHeaderMsg = true;
        this.newuserHeaderMsg = false;
      });
    return;
  }

  private setCID(cid: string) {
    console.log("setting CID: " + cid);
    sessionStorage.setItem('prefCID', cid);
    this.prefCID = cid;
  }

  private flagUserWithExistingProfileAsShopper(): Observable<ServiceResponse> {
      this.alertService.clearError();
      const urlParams = new URLSearchParams(window.location.search);
      const shoppingData = urlParams.get('info').toString();
      
      return this.profileService.updateProfileWithShopperFlag(shoppingData);
  }

  getTokens() {
    this.authHttp.showSpinnerLoading();
    this.authService
      .getTokens()
      .do(token => {
        this.authHttp.hideSpinnerLoading();
        this.authService.cryptoToken = token;
        this.authService.persistSession();
      });
  }

  getPreferences(useridin) {
    this.getTokens();
    this.authService.useridin = useridin;
    this.alertService.clearError();
    this.preferencesService
      .getPreferences()
      .takeUntil(this.destroy$)
      .subscribe(res => {//for get preference we dont get result as 0
        console.log("Preferences Res ::" + JSON.stringify(res));
        if (res.result === -92914) {
          this.existingCommPreference = false;
          const prefCID = res.errormessage.slice(res.errormessage.length - 40)
          sessionStorage.setItem('prefCID', prefCID);
          this.fetchPreferenceInfo();
        } else if (res.result === -92912){
          //this.modalErrorMsg = 'Error Fetching Communication Preferences';
          //$('#openEnrollServiceError').modal('open');
          this.fetchPreferenceInfo();
          this.existingCommPreference = false;
        } else {
          this.getProgramGroup(res);
        }
        return res;
      },
        err => {
          this.modalErrorMsg = 'Error Fetching Communication Preferences';
          $('#openEnrollServiceError').modal('open');
          return err;
        }
      );
  }

  getProgramGroup(res) {
    this.getTokens();
    this.preferences = Object.assign({}, res.message);
    this.preferencesService
      .getProgramGroups()
      .takeUntil(this.destroy$)
      .subscribe(response => {
        if (response.message) {
          this.programGroupsObj = response.message;
          this.handleInputData();
          this.authHttp.hideSpinnerLoading();
        } else {
          //this.preferenceFailure();
        }
      });
  }

  handleSubStatus = (programList, preferenceList) => {
    if(this.flowType==='CDH'){
      if ((this.programList[0].filters[0].selected || this.programList[0].filters[1].selected)
        && (this.programList[1].filters[0].selected || this.programList[1].filters[1].selected)) {
        this.isPrefSubEnabled = true;
      } else 
        { 
          this.isPrefSubEnabled = false; 
        }
    }
    if(this.flowType==='commercial'){
      if (this.programList[0].filters[0].selected || this.programList[0].filters[1].selected ||
        this.programList[0].filters[2].selected)  {
        this.isPrefSubEnabled = true;
      } else { 
        this.isPrefSubEnabled = false; 
      }
    }
  };

  getDrupalConsent() {
    this.authHttp
      .get(this.constant.getconsentDrupal)
      .takeUntil(this.destroy$)
      .subscribe(drupalData => {
        this.drupalConsent = drupalData[0];
        console.log('setting drupal consent');
        sessionStorage.setItem('consentDrupalData', JSON.stringify(drupalData));
      });
  }

  getConsent() {
    this.getTokens();
    this.preferencesService
      .getConsent()
      .takeUntil(this.destroy$)
      .subscribe(consent => {
        this.consentDetails = consent;
        console.log('setting consent in session',consent);
        sessionStorage.setItem('consentData', JSON.stringify(consent));
      });
  }

  handleInputData() {
    const programListData = extractProgramGroupData(this.programGroupsObj);
    if (sessionStorage.getItem('prefCID') === '') {
      this.prefCID = getPreferenceCID(this.preferences);
    } else {
      this.prefCID = sessionStorage.getItem('prefCID');
    }
    this.preferenceList = extractPreferenceData(this.preferences);
    this.programList = selectedPrefFilter(programListData, this.preferenceList);
    this.handleSubStatus(programListData, this.preferenceList);
    sessionStorage.setItem('updatePrefData', JSON.stringify(this.programList));
    const lastPreferenceUpdates = getLastPreferenceUpdates(this.preferences);
    this.lastModifiedDate = lastPreferenceUpdates.lastPrefModifiedDate;
    this.lastUpdateType = lastPreferenceUpdates.lastPrefUpdateType;
    sessionStorage.setItem('lastUpdateType', JSON.stringify(this.lastUpdateType));
    sessionStorage.setItem('lastModifiedDate', JSON.stringify(this.lastModifiedDate));
    sessionStorage.setItem('updatePrefData', JSON.stringify(this.programList));

    if (this.consentDetails && this.consentDetails.consentFlag !== 'Y') {
      this.showConsent = true;
      sessionStorage.setItem('showConsent', JSON.stringify(this.showConsent));
    }
    this.getDrupalConsent();
  }

  onChanged(event: any) {
    console.log(" inside onChanged " +JSON.stringify(this.programList));
    this.programList.forEach(program => {
      if (program.id === event.source.name) {
        program.filters.forEach(filter => {
          if (filter.channelID === event.source.value) {
            filter.selected = event.source.checked;
          } else if (event.source.checked && program.id === 'Documents_Plan') {
            filter.selected = false;
          }
          if (event.source.name === 'Documents_Plan' && filter.channelID === event.source.value) {
            event.source.checked = true;
            filter.selected = event.source.checked;
          }
        });
      }
    });

    //console.log("this.flowType:::::::::"+this.flowType);
  if(this.flowType==='CDH'){
    if ((this.programList[0].filters[0].selected || this.programList[0].filters[1].selected)
      && (this.programList[1].filters[0].selected || this.programList[1].filters[1].selected)) {
      this.isPrefSubEnabled = true;
    } else 
      { 
        this.isPrefSubEnabled = false; 
      }
  }
  if(this.flowType==='commercial'){
    if (this.programList[0].filters[0].selected || this.programList[0].filters[1].selected ||
      this.programList[0].filters[2].selected)  {
      this.isPrefSubEnabled = true;
    } else { 
      this.isPrefSubEnabled = false; 
    }
  }

    sessionStorage.setItem('updatePrefData', JSON.stringify(this.programList));
  }

  verifyUnverifiedChannel() {
    this.path = "EXISTING";
    this.profileService.fetchProfileInfo()
      .takeUntil(this.destroy$)
      .subscribe(profileInfo => {
        sessionStorage.setItem('_profileData_', JSON.stringify(profileInfo));
        this.identifySelectedChannel();
        if (profileInfo.isVerifiedEmail && profileInfo.isVerifiedMobile) {
          this.submitPreference();
        }
        else if (profileInfo.isVerifiedEmail) {
          if (this.mobileChannelSelected) {
            this.isVerifyPhone = true;
            this.otcVerificationDiv = true;
            this.profileUpdateHeaderMessage = false;
            this.userPreferenceDiv = false;
            this.existingCommPreference = false;
            this.newuserHeaderMsg = false;
            this.profileUpdateHeaderMessage = false;
            this.fromVerifyChannelflow = true;
            this.registerUserHeaderMessage = true;
            this.existinguserHeaderMsg=false;
            this.verifyaccesscodeForm.reset();
            this.verifyPhone();
            this.authHttp.hideSpinnerLoading();
            return;
          } else {
            this.fromVerifyChannelflow = true;
            this.submitPreference();
          }
        }
        else if (profileInfo.isVerifiedMobile) {
          if (this.emailChannelSelected) {
            this.isVerifyPhone = false;
            this.otcVerificationDiv = true;
            this.profileUpdateHeaderMessage = false;
            this.userPreferenceDiv = false;
            this.existingCommPreference = false;
            this.existinguserHeaderMsg=false;
            this.newuserHeaderMsg = false;
            this.profileUpdateHeaderMessage = false;
            this.fromVerifyChannelflow = true;
            this.registerUserHeaderMessage = true;
            this.verifyaccesscodeForm.reset();
            this.verifyEmail();
            this.authHttp.hideSpinnerLoading();
            return;
          } else {
            this.fromVerifyChannelflow = true;
            this.submitPreference();
          }
        }
      });
  }

  verifyUnverifiedChannelNew() {
    this.path = "NEW";
    this.profileService.fetchProfileInfo()
      .takeUntil(this.destroy$)
      .subscribe(profileInfo => {
        if (profileInfo.isVerifiedEmail && profileInfo.isVerifiedMobile) {
          this.submitPreferenceforNew;
        }
        this.identifySelectedChannel();
        if (profileInfo.isVerifiedEmail) {
          if (this.mobileChannelSelected) {
            this.isVerifyPhone = true;
            this.otcVerificationDiv = true;
            this.existingCommPreference = false;
            this.userPreferenceDiv = false;
            this.newuserHeaderMsg = false;
            this.profileUpdateHeaderMessage = false;
            this.registerUserHeaderMessage = true;
            this.fromVerifyChannelflow = true;
            this.verifyaccesscodeForm.reset();
            this.verifyPhone();
            this.authHttp.hideSpinnerLoading();
            return;
          } else {
            this.fromVerifyChannelflow = true;
            this.submitPreferenceforNew();
          }
        }
        else if (profileInfo.isVerifiedMobile) {
          if (this.emailChannelSelected) {
            this.otcVerificationDiv = true;
            this.isVerifyPhone = false;
            this.profileUpdateHeaderMessage = false;
            this.userPreferenceDiv = false;
            this.existingCommPreference = false;
            this.newuserHeaderMsg = false;
            this.fromVerifyChannelflow = true;
            this.registerUserHeaderMessage = true;
            this.verifyaccesscodeForm.reset();
            this.verifyEmail();
            this.authHttp.hideSpinnerLoading();
            return;
          } else {
            this.submitPreferenceforNew();
            this.fromVerifyChannelflow = true;
          }
        }
      });
  }

  identifySelectedChannel() {
    const programList = JSON.parse(sessionStorage.getItem('updatePrefData'));
    if (this.programList[0].filters[0].selected || this.programList[1].filters[0].selected) {
      this.emailChannelSelected = true;
    }
    if (this.programList[0].filters[1].selected || this.programList[1].filters[1].selected) {
      this.mobileChannelSelected = true;
    }
  }

  submitPreference() {
    this.authHttp.hideSpinnerLoading();
    this.updatePreferenceInfo();
  }

  submitPreferenceforNew() {
    this.authHttp.hideSpinnerLoading();
    this.getConsent();
    this.getDrupalConsent();
    this.updatePreferenceforNewuser();
  }

  //createNewParamObject
  createNewParamObject = (sessionid, consentData, lastModifiedDate, lastUpdateType, prefCID) => {
    const object: any = {};
    object.sessionid = sessionid;
    object.consentData = consentData;
    object.lastModifiedDate = lastModifiedDate;
    const prefCIDNew = sessionStorage.getItem("prefCID");
    object.prefCID = prefCIDNew;
    object.lastUpdateType = lastUpdateType;
    return object;
  };

  createParamObject = (sessionid, consentData, lastModifiedDate, lastUpdateType, prefCID) => {
    const object: any = {};
    object.sessionid = sessionid;
    object.consentData = consentData;
    object.lastModifiedDate = lastModifiedDate;
    if (prefCID === null) {
      prefCID = JSON.parse(sessionStorage.getItem("prefCID"));
      object.prefCID = prefCID;
    } else {
      if (prefCID.startsWith('"/')) {
        object.prefCID = JSON.parse(prefCID);
      }
      else {
        object.prefCID = prefCID;
      }
    }
    object.lastUpdateType = lastUpdateType;
    return object;
  };

  updatePreferenceInfo() {
    this.getTokens();
    const consent = JSON.parse(sessionStorage.getItem('consentData'));
    const drupalConsent = sessionStorage.getItem('consentDrupalData') ? JSON.parse(sessionStorage.getItem('consentDrupalData')) : '';
    const programList = JSON.parse(sessionStorage.getItem('updatePrefData'));
    this.prefCID = getPreferenceCID(this.preferences);
    const lastModifiedDate = JSON.parse(sessionStorage.getItem('lastModifiedDate'));
    const lastUpdateType = JSON.parse(sessionStorage.getItem('lastUpdateType'));
    const showConsent = JSON.parse(sessionStorage.getItem('showConsent'));
    let consentData = {};
    console.log('consent for existing mem ', consent);
    consentData = {
      consentLanguageId: this.drupalConsent.Version,
      consentTS: consent && consent.consentTS
      ? consent.consentTS
      : this.dateFilter.transform(new Date(), 'M/d/yyyy h:m:s aa', this.timezoneOffset)
    };
    const requiredParameters = this.createParamObject(this.authHttp.sessionid(), 
            consentData, lastModifiedDate, lastUpdateType, this.prefCID);
    const updatedPref = createUpdatePrefObject(programList, requiredParameters, showConsent);
    console.log('updatedPref',updatedPref);
    this.preferencesService
      .updatePreferences(updatedPref).subscribe(res => {
        if (res.result === 0) {
            //this.alertService.setAlert("Preferrence Updated Successfullly", '', AlertType.Success);
          $('#openPrefUpdateSuccessModal').modal('open');
          //this.redirecToEnrollment();
        }
        else {
          this.modalErrorMsg = 'Error Updating Communication Preferences';
          $('#openEnrollServiceError').modal('open');
        }
        this.authHttp.hideSpinnerLoading();
      });
  }

  updatePreferenceforNewuser() {
    this.getTokens();
    const consent = JSON.parse(sessionStorage.getItem('consentData'));
    const drupalConsent = sessionStorage.getItem('consentDrupalData') ? JSON.parse(sessionStorage.getItem('consentDrupalData')) : '';
    const programList = JSON.parse(sessionStorage.getItem('updatePrefData'));
    const prefCID = sessionStorage.getItem('prefCID');
    const lastModifiedDate = JSON.parse(sessionStorage.getItem('lastModifiedDate'));
    const lastUpdateType = JSON.parse(sessionStorage.getItem('lastUpdateType'));
    const showConsent = JSON.parse(sessionStorage.getItem('showConsent'));
    let consentData = {};
    console.log('consent for new mem', consent);
    consentData = {
      //consentLanguageId: this.drupalConsent.Version,
      consentLanguageId: 3.0,
      consentTS: consent && consent.consentTS
      ? consent.consentTS
      : this.dateFilter.transform(new Date(), 'M/d/yyyy h:m:s aa', this.timezoneOffset)
    };
    const requiredParameters = this.createNewParamObject(this.authHttp.sessionid(), consentData, lastModifiedDate, lastUpdateType, this.prefCID);
    const updatedPref = createUpdatePrefObject(programList, requiredParameters, showConsent);
    this.preferencesService
      .updatePreferences(updatedPref).subscribe(res => {
      
        if (res.result === -92927) {
          this.preferencesService
            .updatePreferences(updatedPref).subscribe(res => {
              if (res.result === 0) {
                console.log('update pref called again - success');
                $('#openPrefUpdateSuccessModal').modal('open');
                //this.redirecToEnrollment();
              } else {
                this.modalErrorMsg = 'Error while updating user preference';
                console.log('update pref called again - error');
                $('#openEnrollServiceError').modal('open');
              }
            });
        }
        if (res.result === 0) {
          //this.alertService.setAlert("Preferrence Updated Successfullly", '', AlertType.Success);
          //this.redirecToEnrollment();
          console.log('update pref called - success');
          $('#openPrefUpdateSuccessModal').modal('open');
        } else {
          console.log('update pref called - error');
          this.modalErrorMsg = 'Error while updating user preference';
          $('#openEnrollServiceError').modal('open');
        }
        this.authHttp.hideSpinnerLoading();
      });
  }
  fetchPreferenceInfo() {
    this.userProfileDiv = false;
    this.userPreferenceDiv = true;
    this.newuserHeaderMsg = false;
    this.registerUserHeaderMessage = false;
    this.isPrefSubEnabled = false;
    this.existinguserHeaderMsg = false;
    this.profileUpdateHeaderMessage = true;
    this.flowType=sessionStorage.getItem('flowType');
    const hasActivePlan = this.authService.isUserActive();
    return forkJoin([this.profileService.fetchProfileInfo(), this.preferencesService.getConsent()])
      .filter(responses => responses[0] && responses[1])
      .subscribe(responses => {
        sessionStorage.setItem('_profileData_', JSON.stringify(responses[0]));
        sessionStorage.setItem('consentData', JSON.stringify(responses[1]));
        this.fetchinitialPrefData();
      });
  }

  getConsentDrupal() {
    return this.authHttp.get(this.constant.getconsentDrupal).filter((response: any) => response && response.length);
  }

  fetchinitialPrefData() {
    this.programList = [{
      "id": "Documents_Plan", "filters": [{ "id": "DOCS_PLAN_ONLINE", "channelID": "SOLICIT", "selected": false }
        , { "id": "DOCS_PLAN_SMS", "channelID": "SMS", "selected": false },
      { "id": "DOCS_PLAN_MAIL", "channelID": "MAIL", "selected": false }], "displayName": "Plan Documents"
    },
    {
      "id": "Health_Benefits", "filters": [{ "id": "HLTH_BENEFITS_EMAIL", "channelID": "EMAIL", "selected": false },
      { "id": "HLTH_BENEFITS_SMS", "channelID": "SMS", "selected": false }], "displayName": "Manage Health & Maximize Benefits"
    },
    {
      "id": "BC_News", "filters": [{ "id": "BC_NEWS_EMAIL", "channelID": "EMAIL", "selected": false }
     ], "displayName": "Bluecross News"
    }
    ];
    this.authHttp.hideSpinnerLoading();

  }

  extractPreferenceDetails(res) {
    const obj: any = [];
    if (res.Preferences) {
      res.Preferences.map(item => {
        const singleItem: any = {};
        singleItem.ProgramID = item.ProgramID;
        singleItem.ChannelID = item.ChannelID;
        singleItem.FilterID = item.FilterID;
        singleItem.PreferenceType = item.PreferenceType;
        singleItem.CID = item.CID;
        obj.push(singleItem);
      });
    }
    return obj;
  }

  onOtcSubmit() {
    const accesscode = [
      this.verifyaccesscodeForm.value.accesscode1,
      this.verifyaccesscodeForm.value.accesscode2,
      this.verifyaccesscodeForm.value.accesscode3,
      this.verifyaccesscodeForm.value.accesscode4,
      this.verifyaccesscodeForm.value.accesscode5,
      this.verifyaccesscodeForm.value.accesscode6
    ].join('');

    //validate OTP and redirect
    if (this.fromVerifyChannelflow) {
      this.validateOTPBeforePrefernces(accesscode);
      return;
    }


    this.alertService.clearError();
    const registrationData = {
      useridin: this.userDetail.useridin,
      passwordin: this.userDetail.password,
      accessCode: accesscode,
      regType: this.emailRegistration ? RegType.EMAIL : RegType.MOBILE,
      consentLanguageId: this.drupalres[0].Version,
      consentLanguage: encodeURI(this.drupalres[0].Body),
      consentTS: this.datePipe.transform(new Date(), 'M/d/yyyy h:m:s aa', this.timezoneOffset)
    };
    this.regService
      .register(registrationData)
      .takeUntil(this.destroy$)
      .subscribe((response: ServiceResponse) => {
        if (response.result === 0) {
          this.userProfileDiv = true;
          this.shopperFlag = true;
          this.otcVerificationDiv = false;
          this.registerUserHeaderMessage = false;
          this.profileUpdateHeaderMessage = true;
          const loginRequest = {
            useridin: this.userDetail.useridin,
            passwordin: this.userDetail.password
          };
          sessionStorage.setItem('email-password', JSON.stringify(loginRequest));
          // Need to have auth token in order to call updateMemAuthInfo in reg service 
          // As per My Blue Registration process
          this.authHttp
            .newlogin(loginRequest)
            .takeUntil(this.destroy$)
            .subscribe(res => {

            });
        } else {
          this.modalErrorMsg = response.displaymessage;
          $('#openEnrollServiceError').modal('open');
        }
      });
  }

  validateOTPBeforePrefernces(accesscode) {
    const { emailAddress } = JSON.parse(sessionStorage.getItem('memProfile'));
    const { phoneNumber } = JSON.parse(sessionStorage.getItem('memProfile'));
    const verifiedUsers = ['AUTHENTICATED-AND-VERIFIED', 'REGISTERED-AND-VERIFIED'];
    const scopeName = this.authService.authToken ? this.authService.authToken.scopename : '';
    const commChannel = this.isVerifyPhone ? 'MOBILE' : 'EMAIL';
    const commChannelValue = this.isVerifyPhone ? phoneNumber : emailAddress;
    const verifyAccessCode = this.profileService.VerifyCommChlAccCode(accesscode, this.isVerifyPhone ? '' : commChannelValue, this.isVerifyPhone ? commChannelValue : '')

    if (this.verifyaccesscodeForm.valid) {
      verifyAccessCode.subscribe(response => {
        if (response['result'] == '0') {
          if (this.path == "NEW") {
            this.submitPreferenceforNew();
          } else if (this.path == "EXISTING") {
            this.submitPreference();
          }
        } else {
          if (response['displaymessage']) {

            this.modalErrorMsg = response['displaymessage'];
            $('#openEnrollServiceError').modal('open');

            this.verifyaccesscodeForm.setValue({
              accesscode1: '',
              accesscode2: '',
              accesscode3: '',
              accesscode4: '',
              accesscode5: '',
              accesscode6: ''
            });
          }
        }
      });
    }

  }


  formatMobileNumber(mobilenumber) {
    return (mobilenumber.replace(/[^0-9 ]/g, ""));
  }
  onUserProfileSubmit() {
    this.alertService.clearError();
    this.updateUserDetail = new UpdateUserDetails;
    this.updateUserDetail.useridin = this.userDetail.useridin;
    this.updateUserDetail.firstname = this.userProfileFormGroup.get('profileFormArray').get([0]).get('firstname').value;
    this.updateUserDetail.lastname = this.userProfileFormGroup.get('profileFormArray').get([0]).get('lastname').value;
    this.updateUserDetail.email = this.emailRegistration ? this.userDetail.useridin : this.userProfileFormGroup.get('profileFormArray').get([2]).get('email').value;
    this.updateUserDetail.mobile = this.formatMobileNumber(this.mobileRegistration ? this.userDetail.useridin : this.userProfileFormGroup.get('profileFormArray').get([2]).get('mobile').value);
    this.updateUserDetail.DOB = this.userProfileFormGroup.get('profileFormArray').get([1]).get('DOB').value;
    this.updateUserDetail.hintQuestion = this.userProfileFormGroup.get('profileFormArray').get([3]).get('hintQuestion').value;
    this.updateUserDetail.hintAnswer = this.userProfileFormGroup.get('profileFormArray').get([3]).get('hintAnswer').value;
    this.updateUserDetail.phoneNumberType = RegType.MOBILE;
    this.userFirstName = this.userProfileFormGroup.get('profileFormArray').get([0]).get('firstname').value;
    const date = this.datePipe.transform(this.updateUserDetail.DOB, 'MM/dd/yyyy');
    this.updateUserDetail.DOB = date;

    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    this.updateUserDetail.shoppingData = urlParams.get('info').toString();

    this.regService.updateMemAuthInfo(this.updateUserDetail).
      takeUntil(this.destroy$).
      subscribe((response: ServiceResponse) => {
        if (response.result === 0) {
          sessionStorage.setItem('prefCID', response.usr_prefcentercid);
          this.fetchPreferenceInfo();
        } else {
          this.modalErrorMsg = 'Profile Creation Failed';
          $('#openEnrollServiceError').modal('open');
        }
      });
  }

  //changes related to 1473 --Start
  returnUrl: Observable<string>;

  isUrlValid(decryptedUrl) {
    const res = decryptedUrl.match(/(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g);
    return (res !== null)
  }
  getURLs(infoFromMicroSite): Observable<any> {
    return this.geturlstodisplay(infoFromMicroSite).pipe(map(
      (urlDetailsResponse: any) => {
        if (urlDetailsResponse.result === 0) {
            sessionStorage.setItem('flowType', urlDetailsResponse.flowType);
          if (!this.isUrlValid(urlDetailsResponse.returnUrl)) {
            this.isEncError = true;
            return urlDetailsResponse.returnUrl;
          }
          return urlDetailsResponse.returnUrl;
        } else if (urlDetailsResponse.result === this.encryptionFailureCd) {
          this.isEncError = true;
          sessionStorage.setItem('flowType', urlDetailsResponse.flowType);
          return urlDetailsResponse.returnUrl;
        }
        else if (urlDetailsResponse.result === this.planIdMissingErrorCd ||
          urlDetailsResponse.result === this.acctNumMissingErrorCd ||
          urlDetailsResponse.result === this.returnUrlMissingErrorCd ||
          urlDetailsResponse.result === this.redirectUrlMissingErrorCd) {
          this.isEncError = true;
          sessionStorage.setItem('flowType', urlDetailsResponse.flowType);
          return urlDetailsResponse.returnUrl;
        }
        else {
          this.isEncError = true;
          sessionStorage.setItem('flowType', urlDetailsResponse.flowType);
          this.modalErrorMsg = this.errorMessage;
          $('#openEnrollServiceError').modal('open');
          return urlDetailsResponse.returnUrl;

        }
      }
    ));
  }

  geturlstodisplay(infoFromMicroSite): Observable<any> {
    const generatedRequest = {
      info: infoFromMicroSite
    };
    return this.httpClient.post<any>(this.constant.getdisplayurlAPI, generatedRequest);
  }
  // --End

  navigateToForgotPassword() {
    const userName = this.loginForm && this.loginForm.controls && this.loginForm.controls['useridin'] ? this.loginForm.controls['useridin'].value : '';
    let url;

    if (userName) {
      url = this.router.serializeUrl(
        this.router.createUrlTree(['/account/forgotPassword', userName]));
    } else {
      url = this.router.serializeUrl(
        this.router.createUrlTree(['/account/forgotPassword']));
    }
    window.open(url, '_blank');
  }

  navigateToForgotUsername() {
    const url = this.router.serializeUrl(
      this.router.createUrlTree(['/account/forgotusername'])
    );
    window.open(url, '_blank');
  }

  resendOTPforChannel() {
    console.log( JSON.parse(sessionStorage.getItem('_profileData_')));
    const _profileData =  JSON.parse(sessionStorage.getItem('_profileData_'));
  
    if(_profileData['isVerifiedEmail']===true){
      if(this.mobileChannelSelected){
        this.verifyPhone();
        this.alertService.setAlert("Verification Code resent Successfully", '', AlertType.Success);
      }

    }else if(_profileData['isVerifiedMobile']===true){
      if(this.emailChannelSelected){
        this.verifyEmail();
        this.alertService.setAlert("Verification Code resent Successfully", '', AlertType.Success);
      }
    }
  }
  resendOTPtoUser() {
    const checkUerRequest = {
      useridin: this.userDetail.useridin,
      regType: this.userDetail.regType
    };
    this.regService.checkUser(checkUerRequest).subscribe(res => {
       this.verifyaccesscodeForm.setValue({
        accesscode1: '',
        accesscode2: '',
        accesscode3: '',
        accesscode4: '',
        accesscode5: '',
        accesscode6: ''
      });
      this.alertService.clearError();
      if(res['result']==0){
        this.alertService.setAlert("Verification Code resent Successfully", '', AlertType.Success);
      }
    });
  }

  redirecToEnrollment() {
    window.open(sessionStorage.getItem('redirectUrl'), '_self');
  }


  public checkIsAgeEighteen(dobValue, formControl) {
    if (formControl.errors) {
      this.showageErrorMsg = false;
    } else {
      if (formControl.value) {
        const timeDiff = Math.abs(Date.now() - new Date(formControl.value).getTime());
        const age = Math.floor(timeDiff / (1000 * 3600 * 24) / 365.25);
        if (age >= 18) {
          this.showageErrorMsg = false;
        } else {
          this.showageErrorMsg = true;
        }
      }

    }
  }

  public passwordFieldChange(event) {
    console.log(event, this.emailIdFormGroup.get('registerFormArray').get([1]).get('password').value);
    this.pwdErrorMessage = this.validationService.passwordStatus(this.emailIdFormGroup.get('registerFormArray').get([1]).get('password').value);
    this.validatePWDErrMsg = this.checkPWDMsg(this.pwdErrorMessage)
  }

  public checkPWDMsg(pwderrobj) {
    if (pwderrobj && Object.keys(pwderrobj).length === 5) {

      const errorObj = pwderrobj;
      delete errorObj.hasSmall;
      let result = false;
      for (const i in errorObj) {
        if (errorObj[i] === false) {
          result = true;
          break;
        }
      }
      return result
    } else {
      return true
    }
  }

  verifyEmail() {
    const verifiedUsers = ['AUTHENTICATED-AND-VERIFIED', 'REGISTERED-AND-VERIFIED'];
    const { emailAddress } = JSON.parse(sessionStorage.getItem('memProfile'));
    const scopeName = this.authService.authToken ? this.authService.authToken.scopename : '';
    this.profileService.sendcommchlaccesscode(emailAddress, '')
      .takeUntil(this.destroy$)
      .subscribe(comm => {
        const decResponse = this.authHttp.handleDecryptedResponse(comm);
      });
  }


  verifyPhone() {
    const verifiedUsers = ['AUTHENTICATED-AND-VERIFIED', 'REGISTERED-AND-VERIFIED'];
    const { phoneNumber } = JSON.parse(sessionStorage.getItem('memProfile'));
    const scopeName = this.authService.authToken ? this.authService.authToken.scopename : '';
    this.profileService.sendcommchlaccesscode('', phoneNumber.replace(/\D/g, ''))
      .takeUntil(this.destroy$)
      .subscribe(comm => {
        const decResponse = this.authHttp.handleDecryptedResponse(comm);
      });
  }

  closeModal() {
    $('#openEnrollServiceError').modal('close');
  }

}
