
export class EnrollUserDetails {
  useridin: string;
  password: string;
  regType: string;
}

export class UpdateUserDetails {
  firstname: string;
  lastname: string;
  phoneNumberType: string;
  mobile: string;
  email: string;
  DOB: string;
  hintQuestion: string;
  hintAnswer: string;
  useridin: string;
  shoppingData: string;
}

export class ServiceResponse {
  result: number;
  errormessage: string;
  displaymessage: string;
  usr_prefcentercid: string; // when coming from updatememauthinfo
  usr_prefcenterid: string; // when coming from updatememprofile
}
