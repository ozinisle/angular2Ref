export const PREFERENCE_CONSTANTS = {
  lblEmailNotVerified:
    'After saving your preferences you will be asked verify your email address or' + ' mobile number in order to receive communications.',
  errorText:
    "We're sorry. We are experiencing technical difficulties. Please try again later," +
    ' or if this is urgent, please contact customer care.',
  successText: 'Thank you. Your selections have been saved.',
  emailPhoneNotAvailable: 'Before we can save your preferences, you must enter your email address or mobile number.'
};

export const REQUIRED_CATEGORY = ['Documents_Plan'];

export const PROFIE_CONSTANTS = {
  verifiedEmailMsg: 'Verified your email successfully.',
  verifiedPhoneMsg: 'Verified your mobile number successfully.',

  verificationCodeSent: 'Verification code sent!.',
  verificationCodeResent: 'Verification code resent! You may need to check your spam folder.',
  verificationCodeResentPhone: 'Verification code resent!',

  /* Verification Code Errors*/
  verifyCodeExpiredMsg: 'Your verification code has expired. Please request a new code.',
  verifyCodeCommErrorMsg:
    "We're currently experiencing technical difficulties. Please try again later," +
    " or call <a href='te:18887721722'>1-888-772-1722 </a> for immediate assistance.",
  verifyCodeFeatureNotAvailableMsg: 'This feature is not currently available. Please try again later.',
  verifyCodeDoesNotMach: 'The access code you entered does not match our records. Please try again.'
};

export const CONTACT_INFO_CONSTANTS = {
  addressPermanentMessages: {
    required: 'You must enter a valid permanent address.',
    invalidCharacters: 'You must enter a valid permanent address.'
  },
  addressMailingMessages: {
    required: 'You must enter a valid mailing address.',
    invalidCharacters: 'You must enter a valid mailing address.'
  },
  addressBillingMessages: {
    required: 'You must enter a valid billing address.',
    invalidCharacters: 'You must enter a valid billing address.'
  },
  cityMessages: {
    required: 'You must enter the city.',
    invalidCharacters: 'You must enter a valid city.'
  },
  stateMessages: {
    required: 'State is required'
  },
  zipMessages: {
    required: 'You must enter your ZIP code.',
    minlength: 'You must enter a valid ZIP code.'
  }
};

export const ADDRESS_STATELIST = [
  { label: 'Alabama', value: 'AL' },
  { label: 'Alaska', value: 'AK' },
  { label: 'Arizona', value: 'AZ' },
  { label: 'Arkansas', value: 'AR' },
  { label: 'California', value: 'CA' },
  { label: 'Colorado', value: 'CO' },
  { label: 'Connecticut', value: 'CT' },
  { label: 'Delaware', value: 'DE' },
  { label: 'District of Columbia', value: 'DC' },
  { label: 'Florida', value: 'FL' },
  { label: 'Georgia', value: 'GA' },
  { label: 'Hawaii', value: 'HI' },
  { label: 'Idaho', value: 'ID' },
  { label: 'Illinois', value: 'IL' },
  { label: 'Indiana', value: 'IN' },
  { label: 'Iowa', value: 'IA' },
  { label: 'Kansas', value: 'KS' },
  { label: 'Kentucky', value: 'KY' },
  { label: 'Louisiana', value: 'LA' },
  { label: 'Maine', value: 'ME' },
  { label: 'Maryland', value: 'MD' },
  { label: 'Massachusetts', value: 'MA' },
  { label: 'Michigan', value: 'MI' },
  { label: 'Minnesota', value: 'MN' },
  { label: 'Mississippi', value: 'MS' },
  { label: 'Missouri', value: 'MO' },
  { label: 'Montana', value: 'MT' },
  { label: 'Nebraska', value: 'NE' },
  { label: 'Nevada', value: 'NV' },
  { label: 'New Hampshire', value: 'NH' },
  { label: 'New Jersey', value: 'NJ' },
  { label: 'New Mexico', value: 'NM' },
  { label: 'New York', value: 'NY' },
  { label: 'North Carolina', value: 'NC' },
  { label: 'North Dakota', value: 'ND' },
  { label: 'Ohio', value: 'OH' },
  { label: 'Oklahoma', value: 'OK' },
  { label: 'Oregon', value: 'OR' },
  { label: 'Pennsylvania', value: 'PA' },
  { label: 'Rhode Island', value: 'RI' },
  { label: 'South Carolina', value: 'SC' },
  { label: 'South Dakota', value: 'SD' },
  { label: 'Tennessee', value: 'TN' },
  { label: 'Texas', value: 'TX' },
  { label: 'Utah', value: 'UT' },
  { label: 'Vermont', value: 'VT' },
  { label: 'Virginia', value: 'VA' },
  { label: 'Washington', value: 'WA' },
  { label: 'West Virginia', value: 'WV' },
  { label: 'Wisconsin', value: 'WI' },
  { label: 'Wyoming', value: 'WY' }
];
