import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatGridListModule } from '@angular/material/grid-list';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedModule } from '../../shared/shared.module';
import { profileHomeRouter } from './profile-home.routing';
import { ProfileComponent } from './profile/profile.component';

import {
  MatAutocompleteModule,
  MatCardModule,
  MatDialogModule,
  MatIconModule,
  MatRadioModule,
  MatSelectModule,
  MatSidenavModule,
  MatTooltipModule
} from '@angular/material';
import { StorageServiceModule } from 'angular-webstorage-service';
import { ProfileEmailModule } from '../../components/profile-email/profile-email.module';
import { ProfilePhoneModule } from '../../components/profile-phone/profile-phone.module';
import { verifyEmail } from '../../components/verify-email-mobile/verifyEmail.module';
import { MyprofileResolverService } from '../../shared/routeresolvers/myprofile-resolver.service';
import { MyprofileResolverServiceContact } from '../../shared/routeresolvers/myprofile-resolver.service.contact';
import { AboutMeComponent } from './about-me/about-me.component';
import { AccountSecurityComponent } from './account-security/account-security.component';
import { CommunicationPreferenceComponent } from './communication-preference/communication-preference.component';

import { ContactInformationComponent } from './contact-information/contact-information.component';
import { ContactInformationService } from './contact-information/contact-information.service';
import { ProfileSelectPreferenceModule } from '../../components/profile-select-preference/profile-select-preference.module';
import { LearnMoreModalComponent } from './about-me/learn-more-modal/learn-more-modal.component';
import { ConfirmModalComponent } from './about-me/confirm-modal/confirm-modal.component';
import { FpoLayoutModule } from '../../shared/layouts/FpoLayoutComponent/fpo-layout.module';

@NgModule({
  imports: [
    CommonModule,
    profileHomeRouter,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    TextMaskModule,
    MatAutocompleteModule,
    MatRadioModule,
    MatSelectModule,
    MatCardModule,
    MatIconModule,
    MatSidenavModule,
    MatTooltipModule,
    MatGridListModule,
    MatDialogModule,
    StorageServiceModule,
    SharedModule,
    verifyEmail,
    ProfileEmailModule,
    ProfilePhoneModule,
    ProfileSelectPreferenceModule,
    FpoLayoutModule
  ],
  providers: [MyprofileResolverService, ContactInformationService, MyprofileResolverServiceContact],
  declarations: [
    ProfileComponent,
    AboutMeComponent,
    AccountSecurityComponent,
    CommunicationPreferenceComponent,
    ContactInformationComponent,
    LearnMoreModalComponent,
    ConfirmModalComponent
  ],
  entryComponents: [
    LearnMoreModalComponent,
    ConfirmModalComponent
  ]
})
export class ProfileHomeModule {}
