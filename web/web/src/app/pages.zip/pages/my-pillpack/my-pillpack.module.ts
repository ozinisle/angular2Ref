import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule, MatFormFieldModule, MatInputModule, MatRadioModule } from '@angular/material';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatSelectModule } from '@angular/material/select';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { TextMaskModule } from 'angular2-text-mask';
import { verifyEmail } from '../../components/verify-email-mobile/verifyEmail.module';
import { SharedModule } from '../../shared/shared.module';
import { ContactInformationService } from '../my-profile/contact-information/contact-information.service';
import { AddOtcComponent } from './add-otc/add-otc.component';
import { CreditCardComponent } from './components/credit-card/credit-card.component';
import { MedicationDetailsComponent } from './components/medication-details/medication-details.component';
import { RxOrderSummaryComponent } from './components/rx-order-summary/rx-order-summary.component';
import { ConfirmationComponent } from './confirmation/confirmation.component';
import { LandingComponent } from './landing/landing.component';
import { MedicationsComponent } from './medications/medications.component';
import { PillpackRouter } from './my-pillpack.route';
import { PillpackEffects } from './store/effects';
import { reducer } from './store/reducer';
@NgModule({
  imports: [
    CommonModule,
    PillpackRouter,
    MatCheckboxModule,
    MatRadioModule,
    MatAutocompleteModule,
    TextMaskModule,
    ReactiveFormsModule,
    StoreModule.forFeature('pillpack', reducer),
    EffectsModule.forFeature([PillpackEffects]),
    MatExpansionModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    SharedModule,
    verifyEmail
  ],
  providers: [
    ContactInformationService
  ],
  declarations: [
    MedicationsComponent,
    AddOtcComponent,
    MedicationDetailsComponent,
    LandingComponent,
    ConfirmationComponent,
    RxOrderSummaryComponent,
    CreditCardComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class MyPillpackModule {}
