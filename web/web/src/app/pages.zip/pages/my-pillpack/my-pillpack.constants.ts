export const MyPillPackConstants = {
  Success: '',
  WelcomeMsg: 'Medication Delivery Made Easier',
  VerificationMsgSuccessForMobile: 'Verification code is resent!',
  VerificationResentMsgSuccess: 'Verification code resent! You may need to check your spam folder.',
  NotificationMsg: 'Please check your email account or mobile number for your username.'
};
