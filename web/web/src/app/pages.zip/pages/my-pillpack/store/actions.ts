import { Action } from '@ngrx/store';
import * as ActionTypes from './actionTypes';

export class LoadMedications implements Action {
  readonly type = ActionTypes.LOAD_MEDICATIONS;
}

export class UpdateMedications implements Action {
  readonly type = ActionTypes.UPDATE_MEDICATIONS;
  constructor(public payload: any) {}
}
