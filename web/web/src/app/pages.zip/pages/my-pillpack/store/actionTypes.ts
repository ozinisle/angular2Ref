export const LOAD_MEDICATIONS = '[PillPack] Load medications';
export const UPDATE_MEDICATIONS = '[PillPack] Update medications';
