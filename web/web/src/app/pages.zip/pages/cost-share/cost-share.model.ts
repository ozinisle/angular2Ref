export class CostShareLink {
  link: string;
  text: string;
  fontawsomeclass: string;
  group: string;
}

// tslint:disable-next-line: max-classes-per-file
export class CostShareContent {
  title: string;
  description: string;
  imageUrl: string;
  navLinks: CostShareLink[];
  
  
}
