import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import * as moment from 'moment';
import { Observable } from 'rxjs';
import { AlertType } from '../../shared/alerts/alertType.model';
import { ConstantsService } from '../../shared/services/constants.service';
import { AlertService } from '../../shared/shared.module';
import { PlanBenefitsListResponseModelInterface } from '../myplans/models/interfaces/plan-benefits-list-model.interface';
import { PlanBenefitsListResponseModel } from '../myplans/models/plan-benefits-list.model';
import { MyplansService } from '../myplans/myplans.service';
import { CostShareContent, CostShareLink } from './cost-share.model';

@Injectable()
export class CostShareService {
  constructor(private constantsService: ConstantsService,
    private http: HttpClient,
    private planDataService: MyplansService,
    private alertService: AlertService) {}

  getCostShareDrupalContent(): Observable<any> {
    return this.http.get(this.constantsService.drupalCostShareAssistanceUrl);
  }

  getCostShareContent(): Observable<CostShareContent> {
    const drupalContent$ = this.getCostShareDrupalContent();
    const planData$: Observable<PlanBenefitsListResponseModelInterface> =
               this.planDataService.getPlansData(moment().format('YYYY-MM-DD'));
    return Observable.forkJoin([drupalContent$, planData$]).map(([drupalContent, planData]) => {
      let costShareContent;
      if (planData.result < 0) {
        this.alertService.clearError();
        this.alertService.setAlert(planData.displaymessage, '', AlertType.Failure);
        costShareContent = null;
      } else {
        const memberGroups = this.getGroupMembers(planData);
        costShareContent = this.handleCostShareDrupal(drupalContent[0], memberGroups);
      }
      return costShareContent;
    });
  }

  private getGroupMembers(planResponse): string[] {
    const userGroupNumbers: string[] = [];
    const planResponseFromService = new PlanBenefitsListResponseModel();
    planResponseFromService.RowSet = planResponse.RowSet;
    planResponseFromService.RowSet.osplinPlans.plans.map(planValue => {
      planValue.groupInfo.group.map(groupValue => {
        userGroupNumbers.push(groupValue.groupNumber);
      });
    });
    return userGroupNumbers;
  }

  handleCostShareDrupal(content, memberGroups): CostShareContent {
    const costShareContent = new CostShareContent();
    costShareContent.title = content.Title;
    costShareContent.description = content.ShortDescription;
    costShareContent.imageUrl = this.constantsService.drupalTestUrl + content.RegularImage;
    const contentLinks = content.Links as CostShareLink[];
    const finalLinks: CostShareLink[] = [];
    let drupalGroupNumbers: string[] = [];
    contentLinks.map(values => {
      if (null != values.group && memberGroups.length > 0 ) {
        drupalGroupNumbers = values.group.split(',');
        if (memberGroups.every(group => drupalGroupNumbers.includes(group))) {
          finalLinks.push(values);
        }
      } else {
        finalLinks.push(values);
      }
    });
    costShareContent.navLinks = finalLinks;
    return costShareContent;
  }
}
