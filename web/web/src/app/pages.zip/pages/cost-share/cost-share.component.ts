import { Component, OnDestroy, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { CostShareContent } from './cost-share.model';
import { CostShareService } from './cost-share.service';

@Component({
  selector: 'app-cost-share',
  templateUrl: './cost-share.component.html',
  styleUrls: ['./cost-share.component.scss']
})
export class CostShareComponent implements OnInit {
  costShareContent$: Observable<CostShareContent>;

  constructor(
    private costSharePageService: CostShareService
  ) {}

  ngOnInit() {
    this.costShareContent$ = this.costSharePageService.getCostShareContent();
  }
  openUrl(url: string) {
    if (url) {
      window.open(url, url.includes('https') ? '_blank' : '_self');
    }
  }
}
