import { CommonModule, TitleCasePipe } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
  MatButtonModule,
  MatDatepickerModule,
  MatExpansionModule,
  MatListModule,
  MatNativeDateModule,
  MatRadioModule,
  MatSidenavModule
} from '@angular/material';
import { MaterializeModule } from 'angular2-materialize';
import { FpoLayoutModule } from '../../shared/layouts/FpoLayoutComponent/fpo-layout.module';
import { SharedModule } from '../../shared/shared.module';
import { CardComponent } from './card/card.component';
import { DentalCardDownloadComponent } from './dental-card-download/dental-card-download.component';
import { DentalCardComponent } from './dental-card/dental-card.component';
import { DownloadCardsComponent } from './download-cards/download-cards.component';
import { MedicalStandardDownloadComponent } from './medical-standard-download/medical-standard-download.component';
import { MedicalStandardComponent } from './medical-standard/medical-standard.component';
import { MycardsComponent } from './mycards.component';
import { MyCardsGuard } from './mycards.guard';
import { mycardsRouter } from './mycards.routing';
import { VisionCardDownloadComponent } from './vision-card-download/vision-card-download.component';
import { VisionCardComponent } from './vision-card/vision-card.component';

@NgModule({
  declarations: [
    MycardsComponent,
    CardComponent,
    MedicalStandardComponent,
    VisionCardComponent,
    DownloadCardsComponent,
    DentalCardComponent,
    MedicalStandardDownloadComponent,
    VisionCardDownloadComponent,
    DentalCardDownloadComponent],
  imports: [
    CommonModule,
    MaterializeModule,
    mycardsRouter,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    MatListModule,
    MatSidenavModule,
    MatExpansionModule,
    MatRadioModule,
    MatDatepickerModule,
    MatButtonModule,
    MatNativeDateModule,
    FpoLayoutModule
  ],
  providers: [TitleCasePipe, MyCardsGuard],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class MycardsModule { }
