import { RouterModule, Routes } from '@angular/router';
import { MycardsComponent } from './mycards.component';
import { MyCardsGuard } from './mycards.guard';
import { DownloadCardsComponent } from './download-cards/download-cards.component';

const MYCARDS_ROUTER: Routes = [
  {
    path: '',
    component: MycardsComponent,
    data: {
      breadcrumb: 'My Cards'
    },
    canActivate: [MyCardsGuard]
  },
  {
    path: 'download-cards',
    component: DownloadCardsComponent,
    data: {
      breadcrumb: 'Download ID Cards'
    },
    canActivate: [MyCardsGuard]
  }
];

export const mycardsRouter = RouterModule.forChild(MYCARDS_ROUTER);
