import {
  animate,
  state,
  style,
  transition,
  trigger
} from '@angular/animations';
import { TitleCasePipe } from '@angular/common';
import {
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  OnDestroy,
  OnInit,
  ViewChild
} from '@angular/core';
import {
  MatRadioGroup,
  MatSelectionList,
  MatSelectionListChange,
  MatSidenav
} from '@angular/material';
import * as pdfMake from 'pdfmake/build/pdfmake';
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
import {
  ActivatedRoute,
  Router
} from '../../../../node_modules/@angular/router';
import { environment } from '../../../environments/environment';
import { GetMemBasicInfoResponseModelInterface } from '../../pages/medications/models/interfaces/get-member-basic-info-model.interface';
import { AlertType } from '../../shared/alerts/alertType.model';
import { CardListResponse } from '../../shared/models/interfaces/cardDetails-model.interface';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { AuthService } from '../../shared/services/auth.service';
import { DependantsService } from '../../shared/services/dependant.service';
import { GlobalService } from '../../shared/services/global.service';
import { MyCardsService } from '../../shared/services/mycards/mycards.service';
import { OrderreplacementService } from '../../shared/services/orderreplacement/orderreplacement.service';
import { AlertService, ConstantsService } from '../../shared/shared.module';
import { DependentsModel } from '../myclaims/models/dependants.model';
import { DependentsModelInterface } from '../myclaims/models/interfaces/dependants-model.interface';
import { CardComponent } from './card/card.component';
declare let $: any;

@Component({
  templateUrl: './mycards.component.html',
  styleUrls: ['./mycards.component.scss'],
  animations: [
    trigger('slideInOut', [
      state(
        'in',
        style({
          transform: 'translate3d(0,0,0)'
        })
      ),
      state(
        'out',
        style({
          transform: 'translate3d(-100%,0,0)',
          display: 'none'
        })
      ),
      transition('in => out', animate('100ms ease-in-out')),
      transition('out => in', animate('100ms ease-in-out'))
    ])
  ]
})
export class MycardsComponent implements OnInit, OnDestroy {
  @ViewChild('cardfrontCanvas') canvasFrontRef: ElementRef;
  @ViewChild('cardbackCanvas') canvasBackRef: ElementRef;
  @ViewChild('cardsContainer') cardContainer: ElementRef;
  @ViewChild('cards') card: CardComponent;
  @ViewChild('members') members: MatSelectionList;
  @ViewChild('searchDrpContainer') searchDrpContainer;
  @ViewChild('sideNavContainer') elementView: ElementRef;
  @ViewChild('filterWidth') filterElementView: ElementRef;
  @ViewChild('searchInput') searchInput;
  @ViewChild('sidenav') sideNav: MatSidenav;
  @ViewChild('dependantFilter') dependantFilterComponent: MatRadioGroup;

  dependentList: DependentsModelInterface = new DependentsModel();
  res = [];
  cards: any[];
  membersList = [];
  isFrontView: boolean;
  currentView: string;
  memberName: string;
  dependant: string;
  sideNavHeight: string;
  sideNavStatus: string;
  sideNavMode: string;
  index: number;
  isSidenavOpened: boolean;
  ismobile: boolean;
  collapsedHeight: string;
  expandedHeight: string;
  mobileViewPort = 992;
  filterWidth: string;
  isexpanded: boolean;
  bHasDependents: boolean;
  aSelectedList = [];
  userString: string;
  isDataLoaded = false;
  showClearLink = false;
  memberFrontCard: any[];
  memberBackCard: any[];
  dependentBackCard: any[];
  dependentFrontCard: any[];
  changedCheckbox: boolean;
  contactNumber: any;
  downloadFileName: string;
  cardData = false;
  impersonate = true;
  public basicMemInfo: GetMemBasicInfoResponseModelInterface;
  fpoTargetUrl = environment.drupalTestUrl + '/page/mycards';
  myFocusTriggeringEventEmitter = new EventEmitter<boolean>();
  contactus = '';
  cardListResp: any;
  cardListResponse: any;
  cardListResponseCount: number;
  singlemem: boolean;
  downloadSingleCard: boolean;
  errorMessage: string;
  disableOrder = false;
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    if (event.target.innerWidth <= this.mobileViewPort) {
      this.ismobile = true;
    } else {
      this.ismobile = false;
      this.sideNavStatus = 'in';
    }
  }

  constructor(
    public dependantsService: DependantsService,
    private cardService: MyCardsService,
    private alertService: AlertService,
    public authService: AuthService,
    public globalService: GlobalService,
    public authHttp: AuthHttp,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private constants: ConstantsService,
    public titleCasePipe: TitleCasePipe,
    public orderreplacementService: OrderreplacementService
  ) {
    this.res = this.activatedRoute.snapshot.data.cardsInfo;
    this.contactus =
      this.constants.contactus + this.authService.authToken.scopename;

    this.sideNavMode = 'side';
    this.index = -1;
    this.isSidenavOpened = false;
    this.collapsedHeight = '32px';
    this.expandedHeight = '40px';
    this.isexpanded = true;
    this.sideNavHeight = '600';
    this.bHasDependents = false;
    this.dependentBackCard = [];
    this.dependentFrontCard = [];
    this.userString = '';
    this.cards = [];
    this.changedCheckbox = false;

    if (window.innerWidth <= this.mobileViewPort) {
      this.ismobile = true;
    }
    this.sideNavStatus = this.ismobile ? 'out' : 'in';
    pdfMake.vfs = pdfFonts.pdfMake.vfs;
    this.isFrontView = true;
    this.currentView = 'View Back';
    this.memberName = '';
  }
  ngOnDestroy() {
    this.alertService.clearError();
  }
  ngOnInit() {
    if (this.authService.getRtmsMode()) {
      this.orderreplacementService.getCardPage().subscribe(data => {
        if (data) {
          if (data.MemberDetails && data.MemberDetails.length === 1) {
            if (
              data.MemberDetails[0].RequestIDcardEligibilityIndicator ===
              'false'
            ) {
              this.alertService.setAlert(
                'Our records show that you have placed an order in the past 14 days.',
                'Too soon to order!',
                AlertType.Notification
              );
              this.disableOrder = true;
            }
          } else {
            this.disableOrder = false;
          }
        }
      });
    }
    this.res = this.activatedRoute.snapshot.data.cardsInfo;
    this.cardListResp = this.res[0] as CardListResponse;
    this.cardListResponse = this.cardListResp[0] as CardListResponse;
    // if (!this.cardListResponse.errormessage) {
    this.checkDependantCards(this.cardListResponse.familyMembers);
    this.cardListResponseCount = this.cardListResponse.familyMembers.length;
    if (this.cardListResponse.familyMembers[0].memberCards.length <= 1) {
      this.singlemem = true;
    }
    // } else {
    //   this.handleError(this.cardListResponse);
    // }
  }

  downloadIDCard() {
    if (this.cardListResponse.familyMembers.length > 1) {
      this.router.navigate(['mycards/download-cards']);
    }
    if (this.cardListResponse.familyMembers.length === 1) {
      if (this.cardListResponse.familyMembers[0].memberCards.length > 1) {
        this.router.navigate(['mycards/download-cards']);
      } else {
        const cardDetails = this.cardListResponse.familyMembers[0]
          .memberCards[0];
        this.authHttp.showSpinnerLoading();
        const fileName = this.transformCardName(cardDetails);
        cardDetails.fileName = fileName;

        this.card.downloadSelectedCards(
          cardDetails.forntCardId,
          cardDetails.backCardId,
          cardDetails.cardType,
          fileName
        );
      }
    }
  }

  transformCardName(carddata) {
    let name = this.titleCasePipe
      .transform(carddata.memberName)
      .replace(/\s/g, '_');
    name = name + '_' + this.titleCasePipe.transform(carddata.cardType);
    return name;
  }

  getMembersList() {
    const membersListItems = [];
    const memberSuffItems = [];

    this.memberFrontCard.forEach(member => {
      if (memberSuffItems.indexOf(member.MemSuff) !== -1) {
        return;
      }
      memberSuffItems.push(member.MemSuff);
      let memName = '';
      if (this.res[2].rxSummary && this.res[2].rxSummary.memMiddleInitial) {
        memName =
          this.res[2].rxSummary.memFirstName +
          ' ' +
          this.res[2].rxSummary.memMiddleInitial +
          ' ' +
          this.res[2].rxSummary.memLastName;
      } else {
        memName =
          this.res[2].rxSummary.memFirstName +
          ' ' +
          this.res[2].rxSummary.memLastName;
      }
      if (
        member.MemName === memName ||
        member.MemSuff.includes(this.res[2].rxSummary.suffix)
      ) {
        this.userString = member.RowNum.toString();
        membersListItems.push({
          value: member.MemSuff, // member.RowNum.toString(),
          selected: true,
          name: member.MemName,
          relationship: member.relationship
        });
      } else {
        membersListItems.push({
          value: member.MemSuff, // member.RowNum.toString(),
          selected: false,
          name: member.MemName,
          relationship: member.relationship
        });
      }
    });

    membersListItems.push({
      value: 'All',
      selected: this.dependant === 'All',
      name: 'All Members'
    });

    return membersListItems;
  }

  getSelectedMembers() {
    return this.members.selectedOptions.selected;
  }

  getCanvasElement() {
    return this.cardContainer.nativeElement.children[0];
  }

  toggleFilter(toggleStatus) {
    this.isSidenavOpened = !this.isSidenavOpened;
    this.sideNavStatus = this.sideNavStatus === 'out' ? 'in' : 'out';
    if (toggleStatus) {
      this.sideNavStatus = toggleStatus;
    }
    /*  if (window.innerWidth <= 992) {
       this.sideNavMode = 'over';
     } else {
       this.sideNavMode = 'side';
     } */
    this.sideNavMode = (window.innerWidth <= 992) ? 'over' : 'side';
  }

  handleError(errRes) {
    try {
      if (errRes && errRes['result'] && errRes['result'] < 0) {
        const displayMessage = errRes['displaymessage']
          ? errRes['displaymessage']
          : 'We\'re sorry, there\'s been a system error. Please try again.';
        this.alertService.setAlert(displayMessage, '', AlertType.Failure);
      }
    } catch (e) {
      console.log(e);
    }
  }

  closeSideNavigation() {
    this.isSidenavOpened = false;
  }

  closeFilter() {
    if (this.ismobile) {
      this.sideNavStatus = 'out';
      this.isSidenavOpened = false;
    }
  }

  clearFilter() {
    let memName = '';
    if (this.res[2].rxSummary && this.res[2].rxSummary.memMiddleInitial) {
      memName =
        this.res[2].rxSummary.memFirstName +
        ' ' +
        this.res[2].rxSummary.memMiddleInitial +
        ' ' +
        this.res[2].rxSummary.memLastName;
    } else {
      memName =
        this.res[2].rxSummary.memFirstName +
        ' ' +
        this.res[2].rxSummary.memLastName;
    }

    this.membersList = this.membersList.map(member => {
      member.selected =
        member.name === memName ||
        member.value.includes(this.res[2].rxSummary.suffix);
      return member;
    });

    this.showClearLink = false;

    this.applyFilter(false);
  }

  setShowClearLink() {
    this.showClearLink =
      this.aSelectedList.length > 1 ||
      (this.aSelectedList.length === 1 &&
        this.aSelectedList[0].value !== this.userString);
  }

  getDependentsCardData() {
    let count = 0;
    this.aSelectedList.forEach(selectedMember => {
      if (
        selectedMember.value !== 'User' &&
        selectedMember.value !== 'All' &&
        !this.checkDependentData(selectedMember.value)
      ) {
        count = count + 1;
        this.cardService
          .getDependentBackData$(selectedMember.value)
          .subscribe(data => {
            if (data) {
              this.dependentBackCard.push({
                depId: selectedMember.value,
                data: data
              });
            }
          });
        this.cardService
          .getDependentFrontData$(selectedMember.value)
          .subscribe(data => {
            if (data) {
              this.dependentFrontCard.push({
                depId: selectedMember.value,
                data: data
              });
            }
            count = count - 1;
            if (!count) {
              this.displaySelectedDependantData();
            }
          });
      }
      if (!count) {
        this.displaySelectedDependantData();
      }
    });
  }

  applyFilter(bApplyFilter: boolean) {
    this.closeFilter();
    this.closeSideNavigation();
    this.aSelectedList = this.getSelectedMembers();
    if (!bApplyFilter) {
      this.displaySelectedDependantData();

      return;
    }
    if (
      this.changedCheckbox &&
      (!this.aSelectedList.length ||
        (this.dependant === 'All' && this.aSelectedList.length === 1))
    ) {
      this.clearFilter();
      return;
    }

    this.displaySelectedDependantData();
    this.setShowClearLink();
  }

  displaySelectedDependantData() {
    const aTotalCards = [];
    let memberFrontData;
    this.downloadFileName = '';

    this.membersList.forEach(oMembers => {
      if (oMembers.value !== 'All' && oMembers.selected) {
        this.downloadFileName = this.downloadFileName ? 'All' : oMembers.name;
        memberFrontData = this.memberFrontCard.filter(
          member => member.MemSuff === oMembers.value
        );

        memberFrontData.forEach(memberData => {
          aTotalCards.push.apply(aTotalCards, [
            {
              cardType: 'Medical',
              memberCardFrontData: memberData ? memberData : [],
              memberCardBackData: this.contactNumber ? [this.contactNumber] : []
            }
          ]);
        });
      }
    });
    this.cards = aTotalCards;
  }

  checkDependentData(value) {
    const dependentObj = this.dependentFrontCard.find(
      dependentData => dependentData.depId.toString() === value.toString()
    );
    return !!dependentObj;
  }

  onMemberSelectionChange(selectionListChange: MatSelectionListChange) {
    this.changedCheckbox = true;
    const changeEvent = selectionListChange.option;
    this.dependant = changeEvent.value;
    this.aSelectedList = this.getSelectedMembers();
    this.selectAllMembers(changeEvent.selected, changeEvent.value);
  }

  selectAllMembers(select: boolean, dependent: string) {
    this.membersList = this.membersList.map(member => {
      if (dependent === 'All') {
        member.selected = select
          ? select
          : member.value === this.userString
            ? true
            : select;
      } else {
        member.selected =
          member.value.toString() === dependent ? select : member.selected;
      }

      if (
        dependent !== 'All' &&
        !select &&
        member.value === 'All' &&
        member.selected
      ) {
        member.selected = false;
      }
      if (
        this.aSelectedList.length === this.membersList.length - 1 &&
        dependent !== 'All' &&
        select &&
        member.value === 'All' &&
        !member.selected
      ) {
        member.selected = true;
      }
      return member;
    });
  }
  navigateToContactUs() {
    window.open(this.contactus, '_self');
  }

  impersonation() {
    this.impersonate = this.authService.impersonation();
    return this.impersonate;
  }
  navigateOrderCardPage() {
    if (!this.disableOrder) {
      this.router.navigate(['orderreplacement']);
    }
  }

  checkDependantCards(cardItems) {
    cardItems.forEach(item => {
      if (item.relationship === 'Dependent') {
        this.bHasDependents = true;
        return 0;
      }
    });
  }
}
