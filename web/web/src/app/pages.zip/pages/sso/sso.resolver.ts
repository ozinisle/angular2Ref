import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material';
import { ActivatedRouteSnapshot, Router } from '@angular/router';
import { AlertType } from '../../shared/alerts/alertType.model';
import { ServiceFailureModalComponent } from '../../shared/components/service-failure-modal/service-failure-modal.component';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { GlobalService } from '../../shared/services/global.service';
import { AlertService, AuthService } from '../../shared/shared.module';
import { SsoService } from './sso.service';

declare let $: any;

@Injectable()
export class SsoResolver {
  retryCount = JSON.parse(sessionStorage.getItem('searchEnableRetryCount'));
    searchEnableRetryCount: number = this.retryCount ? this.retryCount : 0;

  constructor(
    private ssoService: SsoService,
    private authService: AuthService,
    private router: Router,
    private httpService: AuthHttp,
    private alertService: AlertService,
    private dialog: MatDialog,
    private globalService: GlobalService
  ) {}

  resolve(routeInfo: ActivatedRouteSnapshot) {

    console.log('retryCount',this.retryCount);
    let ssoUrl;
    if (this.authService.authToken && this.authService.authToken.scopename === 'AUTHENTICATED-AND-VERIFIED' || (this.authService.authToken && (this.authService.authToken.scopename === 'REGISTERED-AND-VERIFIED' || this.authService.authToken.scopename === 'AUTHENTICATED-NOT-VERIFIED') && routeInfo && routeInfo.routeConfig && routeInfo.routeConfig.path === 'sso/medicare-plan-selection-wizard')) {
      ssoUrl = routeInfo && routeInfo.routeConfig && routeInfo.routeConfig.path ? routeInfo.routeConfig.path : '';
      ssoUrl = routeInfo && routeInfo.routeConfig && routeInfo.routeConfig.path === 'fad' ? 'sso/vitals': routeInfo && routeInfo.routeConfig && routeInfo.routeConfig.path === 'sso/medicare-plan-selection-wizard' ? 'sso/psw'  : routeInfo.routeConfig.path;
    }
    if(routeInfo.routeConfig.path === 'sso/medicare-plan-selection-wizard'){
        const isMPSW = routeInfo.queryParams.from === 'MPSW' ? true : false;
        routeInfo.queryParams.InstanceId !== undefined && routeInfo.queryParams.InstanceId !== "" && routeInfo.queryParams.InstanceId !== null ? sessionStorage.setItem('instanceId', routeInfo.queryParams.InstanceId) : '';
      sessionStorage.setItem('isPSW', JSON.stringify(isMPSW));
    }
    console.log(ssoUrl);
    return ssoUrl
      ? this.ssoService.getSsoDetails(ssoUrl).map(response => {
          console.log(response);
          if (response && response.error) {
            this.router.navigate(['/home']).then(() => {
              this.httpService.showServiceErrorModalPopup('requestTimeoutError');
            });
          } else {
            if (response && response.errormessage) {
              sessionStorage.getItem('')
              this.router.navigate(['/home']).then(() => {
                this.showDialog(response);
              });
          } else if (response['result'] < 0) {
              this.router.navigate([this.router.url]).then(() => {
                this.alertService.setAlert(response['displaymessage'], '', AlertType.Failure);
              });
            } else {
              return response;
            }
          }
        })
      : null;
  }
  showDialog(response : any ) {
    const dialog = this.dialog.open(ServiceFailureModalComponent, {
      panelClass: 'service-failure-alert',
      data: {
        showRetry: this.searchEnableRetryCount === 0,
        title: 'Error Occurred',
        description: response.displaymessage,
        ctaRetry: 'Retry',
        cta2Text: 'Close',
        disableClose: true,
      }
    });
    this.searchEnableRetryCount = this.searchEnableRetryCount++;
    sessionStorage.setItem('searchEnableRetryCount', JSON.stringify(this.searchEnableRetryCount));
    console.log(JSON.parse(sessionStorage.getItem('searchEnableRetryCount')));
    dialog.componentInstance.onRetryClicked.subscribe(() => {
        dialog.close();
        this.globalService.openVirtualVisit().subscribe((response:any) => {
          console.log('global resp',response);
          this.navigateOnResponse(response, this.searchEnableRetryCount);
        },
        error => {
          $('#requestTimeoutError').modal('open');
        // });
    });
  
    });
  }  

  navigateOnResponse(response : any, retryCount : number){
    if(response && response.result === "0"
     && response.isConsumerEnrolled){
      setTimeout(() => {
        this.router.navigate(['/home']);
      }, 100);
      
      window.open('sso/amwell', '_blank');
    }else {
      if(retryCount === 0){
      }
          setTimeout(() => {
            this.router.navigate(['/home']);
          this.showDialog(response);
      }, 100);
    }
  }
  }

