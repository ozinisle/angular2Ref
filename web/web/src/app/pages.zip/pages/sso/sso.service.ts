import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { AuthService } from '../../shared/services/auth.service';
import { ConstantsService } from '../../shared/services/constants.service';

@Injectable()
export class SsoService {
  url: any;
  teleHealthFlag = false;
  constructor(private constants: ConstantsService, private authService: AuthService, private http: AuthHttp) {}

  getSsoDetails(ssoUrl: string): Observable<any> {
    const targetLocation = JSON.parse(sessionStorage.getItem('targetHEQLocation'));
    const request =
      sessionStorage.getItem('instanceId') !== undefined &&
      sessionStorage.getItem('instanceId') !== '' &&
      sessionStorage.getItem('instanceId') !== null
        ? {
            useridin: this.authService.useridin,
            InstanceId: sessionStorage.getItem('instanceId')
          }
        : targetLocation
        ? {
            useridin: this.authService.useridin,
            targetContext: targetLocation.targetContext
          }
        : {
            useridin: this.authService.useridin
          };
    sessionStorage.removeItem('targetHEQLocation');
    switch (ssoUrl) {
      case 'sso/amwell':
        this.url = this.constants.teleHealthSSO;
        break;
      case 'sso/vitals':
        this.url = this.constants.serviceUrlV2 + ssoUrl;
        const vitalsResponse = JSON.parse(sessionStorage.getItem('vitalsResponse'));
        this.teleHealthFlag = vitalsResponse.teleHealthEligible;
        request['amwellTeleHealthFlag'] = this.teleHealthFlag && vitalsResponse.platformProvider.code === '01';
        console.log(request);
        break;
      case 'sso/ebilling':
        this.url = this.constants.serviceUrlV2 + ssoUrl;
        break;
      case 'sso/psw':
        this.url = this.constants.pswSSOUrl;
        break;
      case 'sso/virgin_pulse':
        this.url = this.constants.virginPulseSSO;
        break;
      default:
        this.url = this.constants.serviceUrl + ssoUrl;
    }
    return this.http.encryptPost(this.url, request).map(response => {
      if (response['ssomsg']) {
        response = this.http.decryptPayload(response);
        // return response['ssomsg'];
        console.log('SSO decrypted response', response);
      }
      console.log('SSO decrypted response (not if)', response);
      return response;
    });
  }

  callUrl(resp) {
    const myElement: HTMLElement = document.getElementById('ssoDiv');
    if (myElement) {
      // tslint:disable-next-line:max-line-length
      myElement.innerHTML = `<form method="post" action="${resp.samlUrl}"><input type="hidden" name="NameValue" value="${resp.samlValue}"></form>`;
      const currForm: HTMLFormElement = myElement.children[0] as HTMLFormElement;
      currForm.submit();
    }
  }
}
