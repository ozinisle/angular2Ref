import { RouterModule, Routes } from '@angular/router';
import { SsoGuard } from './sso.guard';
import { SsoComponent } from './sso/sso.component';

const SSO_ROUTER: Routes = [
  {
    path: '',
    canActivate: [SsoGuard],
    component: SsoComponent
  }
];

export const SsoRouter = RouterModule.forChild(SSO_ROUTER);
