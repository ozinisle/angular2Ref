import { AfterViewInit, Component, OnInit } from '@angular/core';
import { NavigationCancel, NavigationEnd, NavigationError, NavigationStart, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { environment } from '../environments/environment';
import { PreferenceModalService } from './pages/preference-modal/preference-modal.service';
import { AboutMeModalService } from './shared/components/about-me-modal/about-me-modal.service';
import { VerifyEmailModalService } from './shared/components/verify-email-modal/verify-email-modal.service';
import { AuthHttp } from './shared/services/auth-http.service';
import { LayoutService } from './shared/services/layout.service';
import { AuthService, ConstantsService } from './shared/shared.module';
declare let $: any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements AfterViewInit, OnInit {
  postLoginInfo;
  title = 'app';
  template =
    '<div class="row m-0 pd-0 spinner-height-100">' +
    '<div class="col s12 m4 l4 pd-0 spinner-height-0"></div>' +
    '<div class="col s12 m4 l4 pd-0 spinner-height-100 valign-wrapper justify-spinner-center">' +
    '<div class="row web30Spinner">' +
    '<div class="col s1 m1 l1 pd-0 mb-0"></div> <div class="col s1 m1 l1 pd-0 mb-0"></div> ' +
    '<div class="col s1 m1 l1 pd-0 mb-0"></div> <div class="col s1 m1 l1 pd-0 mb-0"></div> ' +
    '<div class="col s1 m1 l1 pd-0 mb-0"></div> <div class="col s1 m1 l1 pd-0 mb-0"></div> ' +
    '<div class="col s1 m1 l1 pd-0 mb-0"></div> <div class="col s1 m1 l1 pd-0 mb-0"></div> ' +
    '<div class="col s1 m1 l1 pd-0 mb-0"></div> <div class="col s1 m1 l1 pd-0 mb-0"></div> ' +
    '<div>Loading....</div>' +
    '</div>' +
    '</div>' +
    '<div class="col s12 l4 m4 pd-0"></div></div>';
  constructor(
    private router: Router,
    private layoutService: LayoutService,
    private authHttpService: AuthHttp,
    public authService: AuthService,
    public preferenceModalService: PreferenceModalService,
    private aboutMeModalService: AboutMeModalService,
    private constantService: ConstantsService,
    public verifyEmailModalService: VerifyEmailModalService,
    public translateService: TranslateService
  ) {
    this.translateService.setDefaultLang('en');

    if (environment.loadadrum) {
      window['adrum-start-time'] = new Date().getTime();
      window['adrum-config'] = {
        appKey: 'EUM-AAB-AUM',
        adrumExtUrlHttp: 'http://cdn.appdynamics.com',
        adrumExtUrlHttps: 'https://cdn.appdynamics.com',
        beaconUrlHttp: 'http://appdyn-prod-eum.bcbsma.com',
        beaconUrlHttps: 'https://appdyn-prod-eum.bcbsma.com',
        isZonePromise: true
      };
      const script = document.createElement('script');
      script.type = 'text/javascript';
      script.src = constantService.dynamicAdrumLink;
      script.async = true;
      document.body.appendChild(script);
    }
  }
  ngOnInit() {
    console.log('auth service getscope', this.authService.getScopeName());
    if (this.authService.getScopeName() !== 'REGISTERED-NOT-VERIFIED') {
      this.router.routeReuseStrategy.shouldReuseRoute = () => {
        return false;
      };
    }

    if(sessionStorage.getItem('isIPASelected')==="true"){
      this.authHttpService.postlogin().then(response =>{
        if (response && response.error !== true) {
          sessionStorage.setItem('postLoginInfo', JSON.stringify(response));
          // taking backup of IPA plans which is not required ****Defect 5746***
          //sessionStorage.setItem('postLoginInfoBackup', JSON.stringify(response));
        }
      })
    }

    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.layoutService.setPageMeta(this.router.routerState.snapshot.root);
        console.log('auth service getscope', this.authService.getScopeName());
        if (this.authService.getScopeName() !== 'REGISTERED-NOT-VERIFIED') {
          this.router.navigated = false;
        }
      }
    });

    // Adobe Dynamic Tagging
    if (environment.dynamicTagLink) {
      const script = document.createElement('script');
      script.type = 'text/javascript';
      script.src = environment.dynamicTagLink; // use this for linked script
      script.async = true;
      document.head.appendChild(script);
    }
  }
  showPreference() {
    const hasNoAltAdd = this.postLoginInfo && this.postLoginInfo.repPayeeFalg.toLowerCase() === 'false';
    const isMedicare = this.authService.authToken.userType && this.authService.authToken.userType.toLowerCase() === 'medicare';
    const showPreference = !hasNoAltAdd ? false : !isMedicare;
    return showPreference;
  }
  ngAfterViewInit() {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationStart) {
        this.authHttpService.showSpinnerLoading();
      } else if (event instanceof NavigationEnd) {
        setTimeout(() => {
          window.scrollTo(0, 0);
        }, 1);
        let noPreferenceModalUrl = ['/login', '/myprofile/verify', '/myprofile/communication-preferences', '/member-migration'];
        noPreferenceModalUrl = noPreferenceModalUrl.filter(url => url === event.url);
        if (
          noPreferenceModalUrl.length === 0 &&
          this.authService.authToken &&
          this.authService.authToken.scopename === 'AUTHENTICATED-AND-VERIFIED' && !event.url.includes('from=MPSW')
        ) {
          this.postLoginInfo = JSON.parse(sessionStorage.getItem('postLoginInfo'));
          const consent = JSON.parse(sessionStorage.getItem('consentData'));
          const profile = JSON.parse(sessionStorage.getItem('memProfile'));
          const postLoginInfo = JSON.parse(sessionStorage.getItem('postLoginInfo'));
          if (!consent || consent.modalFlag !== 'Y') {
            this.preferenceModalService.initiatePreference();
            if (this.postLoginInfo.showEmailVerifyModal && !this.showPreference()) {
              this.verifyEmailModalService.initiateVerifyEmailModal();
            }
            //Fix for KLO-2023
            //On first time Login the getMemberProfile API is being invoked twice but the ServiceCount is decreased only once
            //So only on the first time (when no consent), servicecount is reduced to stop the Spinner properly
            if (!consent) {
              this.authHttpService.serviceCount--;
            }
          } else if (this.authService.isUserActive() === 'true') {
            this.aboutMeModalService.initiateAboutMeModal();
          }
        }
        this.authHttpService.hideSpinnerLoading();
        //this.verifyEmailModalService.initiateVerifyEmailModal();
      } else if (event instanceof NavigationCancel) {
        setTimeout(() => {
          window.scrollTo(0, 0);
        }, 1);
        this.authHttpService.hideSpinnerLoading();
      } else if (event instanceof NavigationError) {
        setTimeout(() => {
          window.scrollTo(0, 0);
        }, 1);
        console.log('Error occcured: ' + event);
        this.authHttpService.hideSpinnerLoading();
      }
    });
  }
}
