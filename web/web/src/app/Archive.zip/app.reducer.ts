import { ActionReducerMap } from '@ngrx/store';
import { PostLoginInfo } from './shared/models/postlogininfo.model';

export const INIT_POSTLOGININFO = 'INIT_POSTLOGININFO';

export interface State {
  readonly postLoginInfo: PostLoginInfo;
}

export function initPostLoginInfoReducer(state: PostLoginInfo, action) {
  if (action.type === INIT_POSTLOGININFO) {
    return { ...state, ...action.payload };
  } else {
    return state;
  }
}

export const reducers: ActionReducerMap<State> = {
  postLoginInfo: initPostLoginInfoReducer
};
