import { CommonModule } from '@angular/common';
import { ModuleWithProviders, NgModule } from '@angular/core';
import { LoadingSpinnerComponent } from './loading-spinner.component';
import { LoadingSpinnerService } from './loading-spinner.service';

/**
 * Modified version of ng4-loading-spinner.
 * https://github.com/amitmahida92/ng4-loading-spinner
 *
 * Primary changes:
 * - Background timers run outside of the Angular zone, allowing
 *   Protractor to know when the browser is "stable" enough
 *   for automated testing.
 * - Renders obsolete various legacy workarouds that were used to
 *   disable opacity animations.
 */
@NgModule({
  imports: [CommonModule],
  declarations: [LoadingSpinnerComponent],
  exports: [LoadingSpinnerComponent],
  providers: [LoadingSpinnerService]
})
export class LoadingSpinnerModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: LoadingSpinnerModule,
      providers: [LoadingSpinnerService]
    };
  }
}
