import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NgModule, Optional, SkipSelf } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { NgxMaskModule } from 'ngx-mask';
import { reducers } from '../app.reducer';
import { MyplansService } from '../pages/myplans/myplans.service';
import { EnvironmentService } from '../services/environement/environment.service';
import { EarnAndSaveService } from '../shared/services/earn-and-save/earn-and-save.service';
import { LoadingSpinnerModule } from './components/loading-spinner';
import { FakeTranslateLoader } from './i18n/fake-translate.loader';

/**
 * Hosts singletons that are used througout the application, such as:
 *   - Services without a more appropriate parent feature module
 *   - Components only used in the template of AppComponent
 *   - Providers from third-party libraries (imported via ```forRoot()```)
 *   - HTTP interceptors
 */
@NgModule({
  imports: [
    BrowserAnimationsModule /* Keep this as first import */,
    HttpClientModule /* Keep this as second import */,
    EffectsModule.forRoot([]),
    NgIdleKeepaliveModule.forRoot(),
    NgxMaskModule.forRoot({ showMaskTyped: true }),
    StoreModule.forRoot(reducers),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useClass: FakeTranslateLoader,
        deps: [EnvironmentService, HttpClient]
      }
    }),
    LoadingSpinnerModule.forRoot()
  ],
  exports: [LoadingSpinnerModule],
  declarations: [],
  providers: [
    EarnAndSaveService,
    /* For testing only! Remove or comment out to use real service. */
    // { provide: EarnAndSaveService, useClass: EarnAndSaveMockService }
    MyplansService
  ]
})
export class CoreModule {
  constructor(@Optional() @SkipSelf() parentModule: CoreModule) {
    if (parentModule) {
      throw new Error('CoreModule has already been loaded. Import it from AppModule only.');
    }
  }
}
