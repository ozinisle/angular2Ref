import { TranslateLoader } from '@ngx-translate/core';
import { Observable } from 'rxjs';
import { of } from 'rxjs/observable/of';
import * as en from './en.json';

/**
 * This project's ServiceWorker config is preventing the dynamic loading of
 * JSON files. The CloudFront configuration might be interfering as well.
 *
 * This codebase will likely be deprecated before multiple languages
 * need to be supported, so this loader just provides baked-in English translations
 * instead of attempting to dynamically load them.
 */
export class FakeTranslateLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(en);
  }
}
