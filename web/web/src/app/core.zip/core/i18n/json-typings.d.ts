/**
 * Allows for the importing of JSON files.
 *
 * Example:
 * import * as foo from './bar.json';
 */
declare module '*.json' {
  const value: any;
  export = value;
}
