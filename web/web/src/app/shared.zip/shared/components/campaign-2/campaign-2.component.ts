import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { Image } from '../../../shared/models/image.model';
import { AlertService } from '../../../shared/services/alert.service';
import { AuthHttp } from '../../services/auth-http.service';
import { ConstantsService } from '../../services/constants.service';
import { Campaign2ComponentInputModelInterface } from './campaign-2.model';
@Component({
  selector: 'app-campaign-2',
  templateUrl: './campaign-2.component.html',
  styleUrls: ['./campaign-2.component.scss']
})
export class Campaign2Component implements OnInit, OnDestroy {
  @Input('componentInput') componentInput: Campaign2ComponentInputModelInterface;

  fpoTargetUrl: string;
  public fpocontentData1: Image;
  public fpocontentData2: Image;
  public environment: object;

  public isShowWellConnectionImage = true;
  public isShowFindCareImage = true;

  constructor(private alertService: AlertService, private constants: ConstantsService, private authHttp: AuthHttp) {
    this.environment = environment;
    this.fpoTargetUrl = this.constants.drupalContentCampaignUrl2;
  }
  ngOnInit() {
    if (this.componentInput) {
      if (this.componentInput.isShowOnlyWellNessConnectionImage()) {
        this.isShowWellConnectionImage = true;
        this.isShowFindCareImage = false;
      } else if (this.componentInput.isShowOnlyFindCareImage()) {
        this.isShowWellConnectionImage = false;
        this.isShowFindCareImage = true;
      }
    }

    this.authHttp.get(this.fpoTargetUrl).subscribe(response => {
      this.fpocontentData1 = response[0];
      this.fpocontentData2 = response[1];
      //this.authHttp.hideSpinnerLoading();
      console.log(this.fpocontentData1, this.fpocontentData2);
    });
  }
  openUrl(url) {
    if (url) {
      window.open(url, '_blank');
    }
  }

  ngOnDestroy() {
    this.alertService.clearError();
    //this.authHttp.hideSpinnerLoading(); Hiding the spinner is not required as the spinner is not shown during initialization
  }
}
