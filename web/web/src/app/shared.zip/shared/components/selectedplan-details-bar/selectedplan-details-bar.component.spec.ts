import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectedplanDetailsBarComponent } from './selectedplan-details-bar.component';

describe('SelectedplanDetailsBarComponent', () => {
  let component: SelectedplanDetailsBarComponent;
  let fixture: ComponentFixture<SelectedplanDetailsBarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectedplanDetailsBarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectedplanDetailsBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
