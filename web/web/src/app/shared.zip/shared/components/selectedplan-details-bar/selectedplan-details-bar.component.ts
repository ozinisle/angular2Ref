import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertType } from '../../alerts/alertType.model';
import { AuthToken } from '../../models/authToken';
import { AlertService } from '../../services/alert.service';
import { AuthService } from '../../services/auth.service';
import { SelectPlanModalService } from '../select-plan-modal/select-plan-modal.service';

declare let $: any;

$(window).scroll(function() {
  if ($(this).scrollTop() > 0) {
    $('.planDetails').fadeOut();
  } else {
    $('.planDetails').fadeIn();
  }
});

@Component({
  selector: 'app-selectedplan-details-bar',
  templateUrl: './selectedplan-details-bar.component.html',
  styleUrls: ['./selectedplan-details-bar.component.scss']
})
export class SelectedplanDetailsBarComponent implements OnInit {
  planName: string;
  planDates: string;
  showBlueBar: boolean;
  routerUrlArray = ['mydoctors', 'myclaims', 'myplans', 'mydedco', 'mymedications'];
  hasMemberPlans = JSON.parse(sessionStorage.getItem('selectedPlanDetails')) !== null &&
  JSON.parse(sessionStorage.getItem('defaultIPAPlan')) !== null;

  constructor(
    public router: Router,
    private authService: AuthService,
    public selectPlanSerice: SelectPlanModalService,
    private alertService: AlertService
    ) {
    this.routerUrlArray.forEach(item => {
      if (this.router.url.includes(item)) {
        this.showBlueBar = true;
      }
    });
  }

  ngOnInit() {
    if (
      this.hasMemberPlans &&
      JSON.parse(sessionStorage.getItem('selectedPlanDetails')).planName &&
      sessionStorage.getItem('selectedPlanEffectiveDate') &&
      JSON.parse(sessionStorage.getItem('selectedPlanDetails')).cardMemId &&
      JSON.parse(sessionStorage.getItem('selectedPlanDetails')).cardMemId !== JSON.parse(sessionStorage.getItem('defaultIPAPlan')).cardMemId
    ) {
      this.planName = JSON.parse(sessionStorage.getItem('selectedPlanDetails')).planName ;
      this.planDates = sessionStorage.getItem('selectedPlanEffectiveDate');
    }
  }

  navigateToDefault() {
    const defaultPlanObj = JSON.parse(sessionStorage.getItem('defaultIPAPlan'));
    this.selectPlanSerice.getSwitchPlanAPI(defaultPlanObj.cardMemId, defaultPlanObj.cardMemSuffix).subscribe(
      res => {
        if (res && res.result && res.result < 0) {
          this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
        } else {
          sessionStorage.setItem('isIPASelected', 'true');
          this.authService.authToken = new AuthToken(res);
          sessionStorage.setItem('authToken', JSON.stringify(this.authService.authToken));
          sessionStorage.setItem('postLoginInfo', sessionStorage.getItem('postLoginInfoBackup'));
          sessionStorage.setItem('currentPageReload', 'true');
          this.routerUrlArray.forEach(item => {
            if (this.router.url.includes(item)) {
              this.router.navigate([item]).then(() => {
                window.location.reload();
              });
            }
          });
        }
      },
      error => {
        console.warn(error);
      }
    );
    if (
      defaultPlanObj.activePlan === 'true' &&
      defaultPlanObj.futurePlan === 'false' &&
      this.hasMemberPlans &&
      JSON.parse(sessionStorage.getItem('defaultIPAPlan')).cardMemId === defaultPlanObj.cardMemId
    ) {
      sessionStorage.setItem('selectedPlanName', 'Current Plan');
    } else {
      sessionStorage.setItem('selectedPlanName', 'Other Plan');
    }
    
    sessionStorage.setItem('selectedPlanDetails', JSON.stringify(defaultPlanObj));
    sessionStorage.setItem('selectedPlanEffectiveDate',  defaultPlanObj.planEffectiveDate +`${(defaultPlanObj.planEndDate)?'-':''}`+ defaultPlanObj.planEndDate);
  }
}
