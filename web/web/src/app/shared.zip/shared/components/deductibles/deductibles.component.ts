import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { filter, finalize } from 'rxjs/operators';
import { LandingService } from '../../../pages/landing/landing.service';
import { GetFamilyDeductiblesResponseInterface } from '../../../pages/myded-co/models/interfaces/getFamilyDeductibles-model.interface';
import { DeductiblesAccumsInterface } from '../../../pages/myded-co/models/interfaces/myded-co-info-model.interface';
import { AccumChartType } from '../../../pages/myded-co/models/types/myded-co.types';
import { MyDedCoService } from '../../../pages/myded-co/myded-co.service';
import { GlobalService } from '../../services/global.service';
import { LineChartOptionsInterface } from '../line-chart/line-chart.interface';

declare let $: any;

@Component({
  selector: 'app-deductibles',
  templateUrl: './deductibles.component.html',
  styleUrls: ['./deductibles.component.scss']
})
export class DeductiblesComponent implements OnInit {
  @Input() ismobile = false;
  @Input() isHomePage = false;

  showDedcoSpinner: boolean;
  isFDCmem: boolean;
  isIndividual: boolean;
  isFamilyDed: boolean;
  dedCoName: string;
  dedCoInfo: DeductiblesAccumsInterface = null;
  deductibleChartDetails: LineChartOptionsInterface[];
  userState: string;
  deductibleChartCounter = 0;
  isFinancialView = false;
  hasMedicalPlan = false;
  hasDentalPlan = false;
  hasVisionPlan = false;
  dedCoInfoDental: DeductiblesAccumsInterface = null;
  dedCoInfoVision: DeductiblesAccumsInterface = null;
  dentalChartDetails: LineChartOptionsInterface[];
  visionChartDetails: LineChartOptionsInterface[];

  constructor(
    private landingService: LandingService,
    private myDedCoService: MyDedCoService,
    private router: Router,
    private globalService: GlobalService
  ) {}

  ngOnInit() {
    this.initDeductible();
  }

  initDeductible() {
    this.userState = this.landingService.memberInfo.userState;
    this.getDeductiblesAndCoinsuranceInfo();
  }

  getDeductiblesAndCoinsuranceInfo() {
    this.myDedCoService
      .getDeductiblesAndCoinsuranceInfo()
      .pipe(
        filter((response: any) => response && response.accums),
        finalize(() => (this.showDedcoSpinner = false))
      )
      .subscribe((response: GetFamilyDeductiblesResponseInterface) => {
        if (response.accums[0].overallDeductibles) {
          if (response.accums[0].overallDeductibles.some(deductible => deductible.isFirstCoverage && deductible.isFDCDollarsDeductible)) {
            this.isFDCmem = true;
          }
          if (response.accums[0].overallDeductibles.some(deductible => deductible.isIndividualOverallDeductible)) {
            this.isIndividual = true;
          }
          if (response.accums[0].overallDeductibles.some(deductible => deductible.isFamilyOverallDeductible)) {
            this.isFamilyDed = true;
          }
        }

        if (response.hasFamily && !this.isFDCmem) {
          this.dedCoName = 'Family';
        } else if (response.members) {
          this.dedCoName = response.members.reduce((acc, member) => (member.loggedinUserSuffix ? acc + member.name : acc), '');
        } else {
          this.dedCoName = 'Individual';
        }
        if (!response.hasFamily && response.members) {
          response.members.forEach(request => { 
              this.myDedCoService.getIndividualDedAndCoinInfo(request).subscribe(getIndividualDeductiblesResponse => {
                this.dedCoInfoDental = getIndividualDeductiblesResponse.accums.find(el => el.coverageType.toLowerCase() === 'dental');
                this.dedCoInfo = getIndividualDeductiblesResponse.accums.find(
                  el => el.coverageType.toLowerCase() !== 'dental' && el.coverageType.toLowerCase() !== 'vision'
                );
                this.dedCoInfoVision = getIndividualDeductiblesResponse.accums.find(el => el.coverageType.toLowerCase() === 'vision');
                this.prepareLineChart(getIndividualDeductiblesResponse);
              });
          });
        } else {
          this.dedCoInfoDental = response.accums.find(el => el.coverageType.toLowerCase() === 'dental');
          this.dedCoInfo = response.accums.find(
            el => el.coverageType.toLowerCase() !== 'dental' && el.coverageType.toLowerCase() !== 'vision'
          );
          this.dedCoInfoVision = response.accums.find(el => el.coverageType.toLowerCase() === 'vision');
          this.prepareLineChart(response);
        }
      });
  }

  private prepareLineChart(response) {
    this.dedCoInfoDental = response.accums.find(el => el.coverageType.toLowerCase() === 'dental');
    this.dedCoInfo = response.accums.find(el => el.coverageType.toLowerCase() !== 'dental' && el.coverageType.toLowerCase() !== 'vision');
    this.dedCoInfoVision = response.accums.find(el => el.coverageType.toLowerCase() === 'vision');
    if (this.dedCoInfo !== undefined) {
      this.hasMedicalPlan = true;
      this.deductibleChartDetails =
        this.dedCoInfo &&
        (this.dedCoInfo.overallDeductibles !== undefined || this.dedCoInfo.outOfPocket !== undefined || this.dedCoInfo.overallBenefit)
          ? this.getLineChartData(this.dedCoInfo).slice(0, 1)
          : [];
    }

    if (this.dedCoInfoDental !== undefined) {
      this.hasDentalPlan = true;
      this.dentalChartDetails =
        this.dedCoInfoDental &&
        (this.dedCoInfoDental.overallDeductibles !== undefined ||
          this.dedCoInfoDental.outOfPocket !== undefined ||
          this.dedCoInfoDental.overallBenefit)
          ? this.getLineChartData(this.dedCoInfoDental).slice(0, 1)
          : [];
    }

    if (this.dedCoInfoVision !== undefined) {
      this.hasVisionPlan = true;
      this.visionChartDetails =
        this.dedCoInfoVision &&
        (this.dedCoInfoVision.overallDeductibles !== undefined ||
          this.dedCoInfoVision.outOfPocket !== undefined ||
          this.dedCoInfoVision.overallBenefit)
          ? this.getLineChartData(this.dedCoInfoVision).slice(0, 1)
          : [];
    }
    if (this.hasDentalPlan || this.hasMedicalPlan || this.hasVisionPlan) {
      this.globalService.updateHasPlanFinancialDetails(true);
    }
  }

  getLineChartOptionsList(serviceLineOptionsList, chartType: AccumChartType, lineChartOptions): LineChartOptionsInterface[] {
    let isFirstCoverage = false;
    if (serviceLineOptionsList && serviceLineOptionsList.length > 0) {
      for (const option of serviceLineOptionsList) {
        isFirstCoverage = option.isFDCDollarsDeductible && option.isFirstCoverage;
        lineChartOptions.push(this.landingService.getLineChartOptions(option, isFirstCoverage ? AccumChartType.firstCoverage : chartType));
      }
    }
    return lineChartOptions;
  }

  getLineChartData(accum): LineChartOptionsInterface[] {
    let dedCoResponse = [];
    let lineChartOptions = [];
    lineChartOptions = this.getLineChartOptionsList(accum.coinsurance, AccumChartType.Coinsurance, lineChartOptions);
    if (accum.overallDeductibles) {
      if (
        (this.isIndividual && this.isFDCmem && this.dedCoName !== 'Family') ||
        (this.isIndividual && !this.isFDCmem && this.dedCoName !== 'Family')
      ) {
        accum.overallDeductibles = accum.overallDeductibles.filter(
          deductible => deductible.isFirstCoverage || deductible.isIndividualOverallDeductible
        );
        accum.overallDeductibles = accum.overallDeductibles.sort((a, b) => {
          return Number(a.deductibleRemainingToMeet) - Number(b.deductibleRemainingToMeet);
        });
        if (
          this.isFDCmem &&
          accum.overallDeductibles.some(
            deductible =>
              deductible.isFirstCoverage && deductible.isFDCDollarsDeductible && Number(deductible.deductibleRemainingToMeet) === 0
          ) &&
          this.isIndividual
        ) {
          accum.overallDeductibles.reverse();
        }
      }
    }
    if (this.isFamilyDed && !this.isFDCmem && this.dedCoName === 'Family') {
      accum.overallDeductibles = accum.overallDeductibles.filter(deductible => deductible.isFamilyOverallDeductible);
    }
    lineChartOptions = this.getLineChartOptionsList(accum.overallDeductibles, AccumChartType.overallDeductables, lineChartOptions);
    if (!this.isFDCmem) {
      lineChartOptions = this.getLineChartOptionsList(accum.outOfPocket, AccumChartType.outOfPocket, lineChartOptions);
    }
    lineChartOptions = this.getLineChartOptionsList(accum.overallBenefit, AccumChartType.overallBenefit, lineChartOptions);

    dedCoResponse = lineChartOptions.length === 1 ? [lineChartOptions[0]] : lineChartOptions.slice(0, 2);
    return dedCoResponse;
  }

  incrementDeductibleDetailsCounter() {
    if (this.deductibleChartCounter !== this.deductibleChartDetails.length - 1) {
      this.deductibleChartCounter =
        this.deductibleChartCounter === this.deductibleChartDetails.length - 1 ? 0 : this.deductibleChartCounter + 1;
      $('.deduction-item-details .carousel').carousel('next');
    }
  }

  decrementDeductibleDetailsCounter() {
    if (this.deductibleChartCounter > 0) {
      this.deductibleChartCounter =
        this.deductibleChartCounter === 0 ? this.deductibleChartDetails.length - 1 : this.deductibleChartCounter - 1;
      $('.deduction-item-details .carousel').carousel('prev');
    }
  }

  navigate(url) {
    this.router.navigate([url]);
  }
}
