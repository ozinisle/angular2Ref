import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { mocks } from '../../../../jasmine/constants/mocks.service';
import { LandingService } from '../../../pages/landing/landing.service';
import { MyDedCoService } from '../../../pages/myded-co/myded-co.service';

import { DeductiblesComponent } from './deductibles.component';

describe('DeductiblesComponent', () => {
  let component: DeductiblesComponent;
  let fixture: ComponentFixture<DeductiblesComponent>;
  const mockLandingService = mocks.service.landingService;
  const mockDedcoService = mocks.service.myDedCoService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeductiblesComponent ],
      providers: [
        { provide: LandingService, useValue: mockLandingService },
        { provide: MyDedCoService, useValue: mockDedcoService }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeductiblesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('getDeductiblesAndCoinsuranceInfo', () => {
    beforeAll(() => {
      spyOn(DeductiblesComponent.prototype, 'financialChartLength').and.returnValue(2);
      fixture = TestBed.createComponent(DeductiblesComponent);
      component = fixture.componentInstance;
    });

    it('should call the financial data api', fakeAsync(() => {
      component.initDeductible();
      expect(component.myDedCoService.getDeductiblesAndCoinsuranceInfo).toHaveBeenCalled();
      tick(1000);
      expect(component.deductibleChartDetails).toBeTruthy();
    }));

  });

});
