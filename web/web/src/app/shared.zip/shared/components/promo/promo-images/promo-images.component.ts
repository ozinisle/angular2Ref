import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PromosService } from '../promos.service';
declare let $: any;
@Component({
  selector: 'app-promo-images',
  templateUrl: './promo-images.component.html',
  styleUrls: ['./promo-images.component.scss']
})
export class PromoImagesComponent implements OnInit {
  @Input() images: any[];
  @Input() type: string;
  imagesResponse: any[];
  carouselVideoSource = '';
  preferenceObject: any;
  mailSelected = false;
  selectedFilterId: string;

  constructor(private promoService: PromosService, private router: Router) { }

  ngOnInit() {
    $('#imageVideoModal').modal({
      dismissible: true, // Modal can be dismissed by clicking outside of the modal
      opacity: 0.5, // Opacity of modal background
      inDuration: 300, // Transition in duration
      outDuration: 200, // Transition out duration
      startingTop: '0%', // Starting top style attribute
      endingTop: '0%', // Ending top style attribute
      ready: (modal, trigger) => {
        // Callback for Modal open. Modal and trigger parameters available.
        console.log(modal, trigger);
        // this.promoService.playPauseVideo($('#imageVideoModal video'), true);
      },
      complete: () => { }
    });

    if (this.images) {
      this.imagesResponse = [];
      for (const image of this.images) {
        image.subscribe(response => {
          const currentItemIndex = this.imagesResponse.findIndex(img => img.Index === response.Index);
          if (currentItemIndex > -1) {
            this.imagesResponse[currentItemIndex] = response;
          } else {
            this.imagesResponse.push(response);
          }
        });
      }
    }
  }

  openUrl(url) {
    const paperlessPromo = sessionStorage.getItem('paperlessPromo') ?
      JSON.parse(sessionStorage.getItem('paperlessPromo')) : true;
    if (this.type === 'preferencespromo') {
      if (paperlessPromo) {
        this.router.navigate(['myprofile/communication-preferences'])
      } else {
        this.promoService.openUrl(url);
      }
    } else {
      this.promoService.openUrl(url);
    }
  }

  openVideoModal(event, videoSourceUrl: string) {
    event.stopPropagation();
    this.carouselVideoSource = videoSourceUrl;
    this.promoService.openVideoModal('#imageVideoModal');
  }

  closeVideoModal() {
    this.promoService.closeVideoModal('#imageVideoModal');
    this.carouselVideoSource = '';
  }
}
