import { AfterViewInit, Component, ElementRef, HostListener, Input, OnDestroy, Renderer2, ViewChild } from '@angular/core';
import { Observable, Subject } from 'rxjs';

interface PositionValues {
  x: number;
  left: number;
}

enum ScrollAxis {
  Left,
  Right
}

@Component({
  selector: 'app-drag-to-scroll',
  templateUrl: './drag-to-scroll.component.html',
  styleUrls: ['./drag-to-scroll.component.scss']
})
export class DragToScrollComponent implements AfterViewInit, OnDestroy {
  private updateNavigationAnimationFrame: number;
  private updateScrollAnimationFrame: number;
  private isDestroyed$ = new Subject<void>();
  private position: PositionValues;
  private removeMouseMoveListenerFn: () => void;
  private removeScrollListenerFn: () => void;

  @ViewChild('scrollContainer') private scrollContainer: ElementRef;

  @Input() public navButtons = true;
  @Input() public scrollDistance = 250;

  public scrollAxis = ScrollAxis;
  public showLeftNav = false;
  public showRightNav = true;

  constructor(private hostElementRef: ElementRef, private renderer: Renderer2) {}

  ngAfterViewInit() {
    this.renderer.setStyle(this.hostElementRef.nativeElement, 'cursor', 'grab');
    this.removeScrollListenerFn = this.renderer.listen(this.scrollContainer.nativeElement, 'scroll', () => {
      if (this.updateNavigationAnimationFrame) {
        window.cancelAnimationFrame(this.updateNavigationAnimationFrame);
      }
      this.updateNavigationAnimationFrame = window.requestAnimationFrame(() => {
        this.checkNavigation();
      });
    });
    this.checkNavigation();
  }

  ngOnDestroy() {
    this.isDestroyed$.next();
    this.isDestroyed$.complete();

    if (this.removeMouseMoveListenerFn) {
      this.removeMouseMoveListenerFn();
    }

    if (this.removeScrollListenerFn) {
      this.removeScrollListenerFn();
    }
  }

  onContentChange() {
    this.checkNavigation();
  }

  @HostListener('mousedown', ['$event'])
  onMouseDown(mouseDownEvent: MouseEvent) {
    this.position = {
      x: mouseDownEvent.clientX,
      left: this.scrollContainer.nativeElement.scrollLeft
    };
    this.renderer.setStyle(this.hostElementRef.nativeElement, 'cursor', 'grabbing');

    if (this.removeMouseMoveListenerFn) {
      this.removeMouseMoveListenerFn();
    }
    this.removeMouseMoveListenerFn = this.renderer.listen(this.hostElementRef.nativeElement, 'mousemove', (mouseMoveEvent: MouseEvent) => {
      /* Disable click events for children when dragging. */
      this.renderer.setStyle(this.scrollContainer.nativeElement, 'pointer-events', 'none');

      /*
       * For best performance, only update scroll position when browser repaints.
       */
      if (this.updateScrollAnimationFrame) {
        window.cancelAnimationFrame(this.updateScrollAnimationFrame);
      }
      this.updateScrollAnimationFrame = window.requestAnimationFrame(() => {
        const dx = mouseMoveEvent.clientX - this.position.x;
        let newScrollLeft = Math.max(0, this.position.left - dx);
        newScrollLeft = Math.min(newScrollLeft, this.scrollContainer.nativeElement.scrollWidth);
        this.renderer.setProperty(this.scrollContainer.nativeElement, 'scrollLeft', newScrollLeft);
      });
    });
  }

  @HostListener('document:mouseup', ['$event'])
  onMouseUp(e: MouseEvent) {
    if (this.removeMouseMoveListenerFn) {
      this.removeMouseMoveListenerFn();
    }

    /* Delay cleanup so that child "click" events will be intercepted. */
    Observable.of(true)
      .takeUntil(this.isDestroyed$)
      .delay(100)
      .subscribe(() => {
        this.renderer.setStyle(this.hostElementRef.nativeElement, 'cursor', 'grab');

        /* Re-enable mouse events for children. */
        this.renderer.setStyle(this.scrollContainer.nativeElement, 'pointer-events', 'auto');
      });
  }

  @HostListener('window:resize', ['$event'])
  onResize(e: UIEvent) {
    this.checkNavigation();
  }

  scroll(axis: ScrollAxis) {
    const currentScrollLeft = this.scrollContainer.nativeElement.scrollLeft;
    const options: ScrollToOptions = { left: 0, behavior: 'smooth' };
    // tslint:disable-next-line:prefer-conditional-expression
    if (axis === ScrollAxis.Left) {
      options.left = Math.max(currentScrollLeft - this.scrollDistance, 0);
    } else {
      options.left = Math.min(currentScrollLeft + this.scrollDistance, this.scrollContainer.nativeElement.scrollWidth);
    }
    this.scrollContainer.nativeElement.scrollTo(options);
  }

  checkNavigation() {
    const { scrollWidth, scrollLeft, offsetWidth } = this.scrollContainer.nativeElement;

    /* On systems using display scaling, scrollLeft may give you a decimal value. */
    this.showRightNav = Math.floor(scrollLeft) + offsetWidth < scrollWidth;
    this.showLeftNav = Math.round(scrollLeft) > 0;
  }
}
