import { Component, OnInit } from "@angular/core";
import { AuthHttp } from "../../services/auth-http.service";
import { ConstantsService } from "../../services/constants.service";
import { Image } from "../../../shared/models/image.model";
import { AlertService } from "../../../shared/services/alert.service";
import { environment } from "../../../../environments/environment";
import { ActivatedRoute, Router } from "@angular/router";

@Component({
  selector: "app-campaign-telehealth",
  templateUrl: "./campaign-telehealth.component.html",
  styleUrls: ["./campaign-telehealth.component.scss"]
})
export class CampaignTelehealthComponent implements OnInit {
  fpoTargetUrl: string;
  public fpocontentData1: Image;
  public fpocontentData2: Image;
  public environment: object;
  public telehelathCode: string;
  private showwellConnection: boolean = false;

  constructor(
    private authHttp: AuthHttp,
    private alertService: AlertService,
    private constants: ConstantsService,
    private router: Router
  ) {
    this.environment = environment;
  }

  ngOnInit() {
    const vitalsResponse = JSON.parse(sessionStorage.getItem("vitalsResponse"));
    this.telehelathCode = vitalsResponse.platformProvider.code;
    if (this.telehelathCode === "01") {
      this.showwellConnection = true;
      this.fpoTargetUrl = this.constants.drupalContentTeleHealthUrl;
    } else {
      this.fpoTargetUrl = this.constants.drupalContentTeleHealthWithOutWellConnectionUrl;
    }
    this.authHttp.get(this.fpoTargetUrl).subscribe(response => {
      this.fpocontentData1 = response[0];
      //this.authHttp.hideSpinnerLoading();
      console.log(this.fpocontentData1);
    });
  }
  memberLinkOpenUrl() {
    this.router.navigateByUrl("/virtual-visit");
  }

  openUrl(url) {
    if (url) {
      window.open(url, "_blank");
    }
  }
  ngOnDestroy() {
    this.alertService.clearError();
    //this.authHttp.hideSpinnerLoading(); Hiding the spinner is not required as the spinner is not shown during initialization
  }
}
