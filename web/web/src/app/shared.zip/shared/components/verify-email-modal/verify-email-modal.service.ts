import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material';
import { Router } from '@angular/router';
import { PostLoginInfo } from '../../models/postlogininfo.model';
import { AlertService } from '../../services/alert.service';
import { AuthHttp } from '../../services/auth-http.service';
import { AuthService } from '../../services/auth.service';
import { ProfileService } from '../../services/myprofile/profile.service';
import { VerifyEmailModalComponent } from './verify-email-modal.component';

@Injectable()
export class VerifyEmailModalService {
  private postLoginInfo: PostLoginInfo;
  maskedVerify = '';

  constructor(
    private dialog: MatDialog,
    private authService: AuthService,
    private profileService: ProfileService,
    private alertService: AlertService,
    private http: AuthHttp,
    private router: Router
  ) {}

  showModal() {
    this.dialog.open(VerifyEmailModalComponent, {
      disableClose: true
    });
  }

  initiateVerifyEmailModal() {
    this.postLoginInfo = this.authService.postLoginInfo;
    if (this.postLoginInfo) {
      this.showModal();
    } else {
      setTimeout(() => {
        this.initiateVerifyEmailModal();
      }, 1000);
    }
  }
}
