import { TitleCasePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material';
import { MatDialog } from '@angular/material/dialog';
import { pairwise, startWith } from 'rxjs/operators';
import { PROFIE_CONSTANTS } from '../../../pages/my-profile/profile-home.constants';
import { AboutMeModalService } from '../../../shared/components/about-me-modal/about-me-modal.service';
import { AlertType } from '../../alerts/alertType.model';
import { AlertService } from '../../services/alert.service';
import { AuthHttp } from '../../services/auth-http.service';
import { AuthService } from '../../services/auth.service';
import { ProfileService } from '../../services/myprofile/profile.service';
import { ValidationService } from '../../services/validation.service';

@Component({
  selector: 'app-verify-email-modal',
  templateUrl: './verify-email-modal.component.html',
  styleUrls: ['./verify-email-modal.component.scss']
})
export class VerifyEmailModalComponent implements OnInit {
  public verifyaccesscodeForm: FormGroup;
  private shiftKeyDown = false;
  alertDisplayContainer;
  maskedVerifiable: string;
  loggedInEmail;
  isVerified = undefined;
  codeResent = false;

  constructor(
    private dialogRef: MatDialogRef<VerifyEmailModalComponent>,
    private validationService: ValidationService,
    private fb: FormBuilder,
    private profileService: ProfileService,
    private alertService: AlertService,
    private authHttp: AuthHttp,
    private authService: AuthService,
    private titleCase: TitleCasePipe,
    public dialog: MatDialog,
    private aboutMeModalService: AboutMeModalService
  ) {
    this.alertService.clearError();
    this.verifyaccesscodeForm = this.fb.group(
      {
        accesscode1: ['', [Validators.required]],
        accesscode2: ['', [Validators.required]],
        accesscode3: ['', [Validators.required]],
        accesscode4: ['', [Validators.required]],
        accesscode5: ['', [Validators.required]],
        accesscode6: ['', [Validators.required]]
      },
      {
        validator: this.validationService.accessCodeValidator()
      }
    );
    this.verifyaccesscodeForm.valueChanges.pipe(startWith(''), pairwise()).subscribe(accesscodes => {
      const prevVals = accesscodes[0];
      const newVals = accesscodes[1];
      Object.keys(newVals).forEach((key, index) => {
        const newItemValue = (newVals[key] ? newVals[key] : '').toString();
        const oldItemValue = (prevVals[key] ? prevVals[key] : '').toString();
        // if all validations work fine; newItemValue string length will never be more than 2 digits
        // code depends on previous validations to run without fail.
        if (newItemValue !== oldItemValue && newItemValue.length > 1) {
          const digits = newItemValue.split('');
          const currentIndex = index + 1;
          const allEqual = digits.every((val, i, arr) => val === arr[0]);
          if (allEqual) {
            this.verifyaccesscodeForm.get('accesscode' + currentIndex).setValue(digits[0], { emitEvent: false });
          } else {
            digits.forEach(digit => {
              if (digit !== oldItemValue) {
                this.verifyaccesscodeForm.get('accesscode' + currentIndex).setValue(digit, { emitEvent: false });
              }
            });
          }
          this.verifyaccesscodeForm.get('accesscode' + currentIndex).updateValueAndValidity();
        }
      });
    });
  }

  ngOnInit() {
    this.alertDisplayContainer = 'modalAlert';
    if (sessionStorage.getItem('memProfile')) {
      this.loggedInEmail = JSON.parse(sessionStorage.getItem('memProfile')).emailAddress;
      this.maskedVerifiable = this.maskEmailId(this.loggedInEmail);
      this.sendcommchlaccesscode(this.loggedInEmail).subscribe(
        res => {
          if (res['result'] === '0') {
            this.alertService.clearError();
          } else {
            if (res['displaymessage']) {
              this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
            }
          }
        },
        err => {
          console.log('error', err);
        }
      );
    }
  }
  private sendcommchlaccesscode(email) {
    return this.profileService.sendcommchlaccesscode(email, '');
  }

  maskEmailId(userId: string): string {
    const sentMailId = JSON.parse(sessionStorage.getItem('sendCodeRes'));
    userId = sentMailId && sentMailId['commChannel'] ? sentMailId['commChannel'] : userId;
    const maskedUserId = userId
      ? userId.replace(/^(.{3})(.*)(@.*)$/, (_, firstCharacter, charToMasked, domain) => {
          return `${firstCharacter}${charToMasked.replace(/./g, '*')}${domain}`;
        })
      : userId;
    return maskedUserId;
  }

  close() {
    this.dialogRef.close();
  }

  private sendNotification(isEmailEdit: boolean, commChannelType: string, commChannel: string) {
    // const myProfileURL = this.getMyProfileUrl();
    const notificationRequest = {
      useridin: this.authService.useridin,
      commChannel: commChannel,
      commChannelType: commChannelType,
      templateKeyword: 'UPDATENOTIFICATION_EMAIL',
      notificationParms: [
        {
          keyName: 'firstName',
          keyValue:
            this.authService && this.authService.authToken && this.authService.authToken.firstName
              ? this.titleCase.transform(this.authService.authToken.firstName)
              : ''
        },
        {
          keyName: 'updatedFields',
          keyValue: ['Email']
        }
      ]
    };
    this.profileService.sendUpdateNotification(notificationRequest).subscribe(res => {});
  }

  resetForm() {
    this.verifyaccesscodeForm.setValue({
      accesscode1: '',
      accesscode2: '',
      accesscode3: '',
      accesscode4: '',
      accesscode5: '',
      accesscode6: ''
    });
  }

  private updateProfileInfo() {
    this.resetForm();
    let profile = JSON.parse(sessionStorage.getItem('memProfile'));
    profile = { ...profile, isVerifiedEmail: true };
    sessionStorage.setItem('memProfile', JSON.stringify(profile));
  }

  onSubmit() {
    this.alertService.clearError();
    const accessCode = [
      this.verifyaccesscodeForm.value.accesscode1,
      this.verifyaccesscodeForm.value.accesscode2,
      this.verifyaccesscodeForm.value.accesscode3,
      this.verifyaccesscodeForm.value.accesscode4,
      this.verifyaccesscodeForm.value.accesscode5,
      this.verifyaccesscodeForm.value.accesscode6
    ].join('');

    const { emailAddress } = JSON.parse(sessionStorage.getItem('memProfile'));
    const commChannel = 'EMAIL';
    const commChannelValue = emailAddress;
    const verifiedUsers = ['AUTHENTICATED-AND-VERIFIED', 'REGISTERED-AND-VERIFIED'];
    const scopeName = this.authService.authToken ? this.authService.authToken.scopename : '';
    const isVerifyAccessCodeApi = !verifiedUsers.includes(scopeName);
    const verifyAccessCode = verifiedUsers.includes(scopeName)
      ? this.profileService.VerifyCommChlAccCode(accessCode, commChannelValue, '')
      : this.profileService.VerifyAccessCode(accessCode, commChannel, commChannelValue);

    if (this.verifyaccesscodeForm.valid) {
      verifyAccessCode.subscribe((response: any) => {
        if (response.result === '0') {
          const msg = PROFIE_CONSTANTS.verifiedEmailMsg;
          this.isVerified = true;
          isVerifyAccessCodeApi ? sessionStorage.removeItem('sendCodeRes') : this.sendNotification(true, commChannel, commChannelValue);

          if (sessionStorage.getItem('isPendingEmail') === 'true') {
            this.updateProfileInfo();
            sessionStorage.removeItem('isPendingEmail');
          }
          this.authHttp.hideSpinnerLoading();
          const postLoginInfo = JSON.parse(sessionStorage.getItem('postLoginInfo'));
          if (postLoginInfo.showDemographicModel) {
            this.dismissModal();
            this.authHttp.postlogin().then(response => {
              if (response && response.error !== true) {
                sessionStorage.setItem('postLoginInfo', JSON.stringify(response));
                this.aboutMeModalService.initiateAboutMeModal();
              }
            });
          }
        } else {
          this.isVerified = false;
          this.mapSendAccessErrorCode(response);
          this.authHttp.hideSpinnerLoading();
        }
      });
    }
  }
  dismissModal() {
    this.dialog.closeAll();
  }
  mapSendAccessErrorCode(response) {
    if (response['result'] === '-1') {
      this.alertService.setAlert(PROFIE_CONSTANTS.verifyCodeExpiredMsg, '', AlertType.Failure, 'component', this.alertDisplayContainer);
    } else if (response['result'] === '-2') {
      this.alertService.setAlert(PROFIE_CONSTANTS.verifyCodeCommErrorMsg, '', AlertType.Failure, 'component', this.alertDisplayContainer);
    } else if (response['result'] === '-3') {
      this.alertService.setAlert(
        PROFIE_CONSTANTS.verifyCodeFeatureNotAvailableMsg,
        '',
        AlertType.Failure,
        'component',
        this.alertDisplayContainer
      );
    } else if (response['result'] === '-4') {
      this.alertService.setAlert(PROFIE_CONSTANTS.verifyCodeDoesNotMach, '', AlertType.Failure, 'component', this.alertDisplayContainer);
    } else {
      this.alertService.setAlert(response['displaymessage'], '', AlertType.Failure, 'component', this.alertDisplayContainer);
    }
    this.resetForm();
    this.validationService.focusFirstError();
  }

  sendaccesscode() {
    this.codeResent = false;
    this.profileService.sendcommchlaccesscode(this.loggedInEmail, '').subscribe(
      res => {
        if (res['result'] === '0' || res['result'] === 0) {
          this.alertService.clearError();
          this.codeResent = true;
          this.alertService.setAlert(
            PROFIE_CONSTANTS.verificationCodeResent,
            '',
            AlertType.Success,
            'component',
            this.alertDisplayContainer
          );
        } else {
          if (res['displaymessage']) {
            this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure, 'component', this.alertDisplayContainer);
          }
        }
        this.authHttp.hideSpinnerLoading();
      },
      err => {
        this.authHttp.hideSpinnerLoading();
      }
    );
  }

  splitAndPlacePastedValues(event, materialForm): boolean {
    event.preventDefault();
    let pastedData = '';
    if (event.clipboardData) {
      pastedData = event.clipboardData.getData('text/plain');
    } else if (window['clipboardData']) {
      pastedData = window['clipboardData'].getData('Text');
    }
    pastedData = pastedData.replace(/\D/g, '');
    let pastedCharArr = pastedData.split('');
    if (pastedCharArr.length > 6) {
      pastedCharArr = pastedCharArr.splice(0, 6);
    }

    const accessCodeFields: NodeListOf<Element> = document.querySelectorAll('input.access-code');
    Object.keys(materialForm.controls).forEach((controlName, controlIndex) => {
      const pastedNumber: string = pastedCharArr[controlIndex];
      if (pastedNumber) {
        const formInputControl: FormControl = materialForm.get(controlName);
        // focus method does not work as such in ie11. hence requires a timeout block as fix/workaround for the same
        setTimeout(() => {
          (accessCodeFields[controlIndex] as HTMLInputElement).focus();
          formInputControl.setValue(pastedNumber);
        }, 10);
      } else {
        return false;
      }
    });

    // this.getMatFormClass(materialForm);
    return true;
  }

  onKeyDown(event) {
    if (event.keyCode === 16) {
      this.shiftKeyDown = true;
    }
    if (this.shiftKeyDown || !this.isValidKeyPressed(event)) {
      return false;
    }
  }

  onKeyUp(event, previousElement, nextElement, materialForm) {
    if (this.shiftKeyDown) {
      if (event.keyCode === 16) {
        this.shiftKeyDown = false;
      }
      return false;
    }

    if (event && event.target['value'] === '' && !this.isValidKeyPressed(event)) {
      return false;
    }
    // this.getMatFormClass(materialForm);
    if ((event.key === 'Backspace' || event.which === 37 || event.key === 'ArrowLeft') && previousElement) {
      previousElement.focus();
    }
    if (
      (event.key === 'ArrowRight' ||
        event.which === 39 ||
        (event.keyCode >= 48 && event.keyCode <= 57) ||
        (event.keyCode >= 96 && event.keyCode <= 105)) &&
      nextElement
    ) {
      setTimeout(() => nextElement.focus(), 100);
    }
  }

  isValidKeyPressed(event) {
    const key = event.key;
    return (
      key === 'Backspace' ||
      key === 'Control' ||
      key === 'ArrowLeft' ||
      key === 'ArrowRight' ||
      (event.keyCode >= 48 && event.keyCode <= 57) ||
      (event.keyCode >= 96 && event.keyCode <= 105) || event.keyCode == 86
    );
  }

  openOtpBlock() {
    this.isVerified = undefined;
  }
}
