import { AfterViewInit, Component, ElementRef, Input, OnChanges, Renderer2, ViewChild } from '@angular/core';

/**
 * Exposed styles:
 *
 * | CSS Variable                | Description |
 * | :-------------------------  | :---------- |
 * | ```--fill-color-active```   | Circle fill color (normal) |
 * | ```--fill-color-hover```    | Circle fill color (when .hover class is applied) |
 * | ```--fill-color-inactive``` | Circle fill color (when .inactive class is applied) |
 * | ```--fill-color-complete``` | Circle fill color (when ```percent === 100```) |
 * | ```--stroke-color-active``` | Circle stroke color (normal) |
 * | ```--icon-color-active```   | Icon fill color (normal) |
 * | ```--icon-color-hover```    | Icon fill color (when .hover class is applied) |
 * | ```--icon-color-inactive``` | Icon fill color (when .inactive class is applied) |
 * | ```--icon-color-complete``` | Icon fill color (when ```percent === 100```) |
 * | ```--icon-class-active```   | Font Awesome class(es) to apply to the icon (normal) |
 * | ```--icon-class-inactive``` | Font Awesome class(es) to apply to the icon (when ```inactive === true```) |
 * | ```--icon-class-complete``` | Font Awesome class(es) to apply to the icon (when ```percent === 100```) |
 */
@Component({
  selector: 'app-radial-progress',
  templateUrl: './radial-progress.component.html',
  styleUrls: ['./radial-progress.component.scss']
})
export class RadialProgressComponent implements AfterViewInit, OnChanges {
  public readonly DEFAULT_ICON_CLASS_ACTIVE = 'fas fa-question-circle';
  public readonly DEFAULT_ICON_CLASS_INACTIVE = 'far fa-question-circle';
  public readonly DEFAULT_ICON_CLASS_COMPLETE = 'fal fa-check';

  @Input() circleSize = 64;
  @Input() percent = 0;
  @Input() iconSize = 28;
  @Input() strokeWidth = 8;
  @Input() inactive = false;

  @ViewChild('svg') svgElementRef: ElementRef;
  @ViewChild('fill') fillElementRef: ElementRef;
  @ViewChild('stroke') strokeElementRef: ElementRef;
  @ViewChild('iconWrapper') iconWrapperElementRef: ElementRef;
  @ViewChild('icon') iconElementRef: ElementRef;

  public isComplete = false;

  private get hostElement(): HTMLElement {
    return this.elementRef.nativeElement;
  }

  private get svgElement(): SVGElement {
    return this.svgElementRef.nativeElement;
  }

  private get fillElement(): SVGCircleElement {
    return this.fillElementRef.nativeElement;
  }

  private get strokeElement(): SVGPathElement {
    return this.strokeElementRef.nativeElement;
  }

  private get iconWrapperElement(): HTMLElement {
    return this.iconWrapperElementRef.nativeElement;
  }

  private get iconElement(): HTMLElement {
    return this.iconElementRef.nativeElement;
  }

  // prettier-ignore
  constructor(
    private elementRef: ElementRef,
    private renderer: Renderer2,
  ) {}

  ngAfterViewInit() {
    this.updateDisplay();
  }

  ngOnChanges() {
    this.updateDisplay();
  }

  private updateDisplay() {
    this.isComplete = this.percent >= 100;

    const hostStyle = window.getComputedStyle(this.hostElement);
    const iconClassActive = hostStyle.getPropertyValue('--icon-class-active') || this.DEFAULT_ICON_CLASS_ACTIVE;
    const iconClassInactive = hostStyle.getPropertyValue('--icon-class-inactive') || this.DEFAULT_ICON_CLASS_INACTIVE;
    const iconClassComplete = hostStyle.getPropertyValue('--icon-class-complete') || this.DEFAULT_ICON_CLASS_COMPLETE;

    const widthCss = `${this.circleSize}px`;
    const heightCss = `${this.circleSize}px`;

    this.renderer.setStyle(this.hostElement, 'width', widthCss);
    this.renderer.setStyle(this.hostElement, 'height', heightCss);

    this.renderer.setStyle(this.iconWrapperElement, 'width', widthCss);
    this.renderer.setStyle(this.iconWrapperElement, 'height', heightCss);
    this.renderer.setStyle(this.iconWrapperElement, 'font-size', `${this.iconSize}px`);
    if (this.percent >= 100) {
      this.renderer.setAttribute(this.iconElement, 'class', iconClassComplete);
    } else {
      if (this.inactive) {
        this.renderer.setAttribute(this.iconElement, 'class', iconClassInactive);
      } else {
        this.renderer.setAttribute(this.iconElement, 'class', iconClassActive);
      }
    }

    this.renderer.setStyle(this.svgElement, 'width', widthCss);
    this.renderer.setStyle(this.svgElement, 'height', heightCss);
    this.renderer.setAttribute(this.svgElement, 'viewbox', `0, 0, ${this.circleSize}, ${this.circleSize}`);

    const radius = (this.circleSize - this.strokeWidth) / 2;
    const diameter = radius * 2;
    const circumference = 2 * Math.PI * radius;
    const centerXY = this.circleSize / 2;
    this.renderer.setAttribute(this.fillElement, 'cx', centerXY.toString());
    this.renderer.setAttribute(this.fillElement, 'cy', centerXY.toString());
    this.renderer.setAttribute(this.fillElement, 'r', radius.toString());

    const strokeVisibility = this.percent > 0 ? 'visible' : 'hidden';
    this.renderer.setStyle(this.strokeElement, 'visibility', strokeVisibility);

    const halfStrokeWidth = this.strokeWidth / 2;
    const d = `M${centerXY} ${halfStrokeWidth}
      a ${radius} ${radius} 0 0 1 0 ${diameter}
      a ${radius} ${radius} 0 0 1 0 -${diameter}`;
    this.renderer.setAttribute(this.strokeElementRef.nativeElement, 'd', d);

    const strokeLength = (this.percent / 100) * circumference;
    const dashArrayValue = `${strokeLength}, ${circumference}`;
    this.renderer.setAttribute(this.strokeElement, 'stroke-dasharray', dashArrayValue);
    this.renderer.setAttribute(this.strokeElement, 'stroke-width', this.strokeWidth.toString());
  }
}
