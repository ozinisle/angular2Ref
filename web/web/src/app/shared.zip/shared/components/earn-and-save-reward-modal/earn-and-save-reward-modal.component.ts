import { Component, Inject, OnChanges, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { RewardCode } from '../../services/earn-and-save/models/reward-code.enum';
import { RewardSource } from '../../services/earn-and-save/models/reward-source.enum';
import { SimpleRewardStatus } from '../../services/earn-and-save/models/simple-reward-status.enum';
import { SimpleReward } from '../../services/earn-and-save/models/simple-reward.model';
import { JumpScreenComponent } from '../jump-screen/jump-screen.component';

interface ModalData {
  reward: SimpleReward;
}

@Component({
  selector: 'app-earn-and-save-reward-modal',
  templateUrl: './earn-and-save-reward-modal.component.html',
  styleUrls: ['./earn-and-save-reward-modal.component.scss']
})
export class EarnAndSaveRewardModalComponent implements OnInit, OnChanges {
  public RewardSource = RewardSource;
  public SimpleRewardStatus = SimpleRewardStatus;

  public currentQuarter = Math.floor((new Date().getMonth() + 1) / 3) + 1;
  public currentYear = new Date().getFullYear();
  public RewardCode = RewardCode;
  targetContext = {};
  constructor(
    private matDialog: MatDialog,
    private matDialogRef: MatDialogRef<EarnAndSaveRewardModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: ModalData
  ) {}

  public ngOnInit() {
    this.updateProgress();
  }

  public ngOnChanges() {
    this.updateProgress();
  }

  public callToActionClicked() {
    if (this.data.reward.code !== this.RewardCode.VIRGIN_PULSE) {
      this.targetContext = {
        location:
          this.data.reward.status === this.SimpleRewardStatus.COMPLETED
            ? 'TRANSACTION'
            : this.data.reward.source === this.RewardSource.HEQ && this.data.reward.code.includes(this.RewardCode.HEQ_OPTIMIZER)
            ? 'OPTIMIZER'
            : this.data.reward.code.includes(this.RewardCode.HEQ_FIRST_DEPOSIT)
            ? 'CONTRIBUTION'
            : '',
        accountType: 'HSA',
        accountNumber: ''
      };
    }
    const dialogRef = this.matDialog.open(JumpScreenComponent, {
      maxWidth: '100%',
      panelClass: 'menu-dialog',
      autoFocus: false,
      data: {
        url: 'sso/heathequity',
        module: 'heq',
        targetContext: this.targetContext
      }
    });
    this.matDialogRef.close();
  }

  public closeButtonClicked() {
    this.matDialogRef.close();
  }

  private updateProgress() {
    if (!this.data) {
      return;
    }
  }
}
