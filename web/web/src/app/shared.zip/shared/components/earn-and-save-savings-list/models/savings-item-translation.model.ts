export interface SavingsItemTranslation {
  title: string;
  description: string;
  callToAction: string;
}
