import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Subject } from 'rxjs';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { from } from 'rxjs/observable/from';
import { LoadingSpinnerService } from '../../../core/components/loading-spinner';
import { GetPlansBenefitsListResponseModel } from '../../../pages/message-center/modals/get-plans-benefits-list.model';
import { PlanEntityInterface } from '../../../pages/myplans/models/interfaces/plan-benefits-page-adapted-data-model.inteface';
import { PlanBenefitsListResponseModel } from '../../../pages/myplans/models/plan-benefits-list.model';
import { GetPlanBenefitServicesRequestModel } from '../../../pages/myplans/models/plans-benefits-service.model';
import { MyplansService } from '../../../pages/myplans/myplans.service';
import { PlanConfigService } from '../../../services/plan-config/plan-config-service';
import { AlertType } from '../../alerts/alertType.model';
import { AlertService } from '../../services/alert.service';
import { AuthService } from '../../services/auth.service';
import { SavingsItemTranslation } from './models/savings-item-translation.model';
import { SavingsItemType } from './models/savings-item-type.enum';
import { SavingsItem } from './models/savings-item.model';

declare let $: any;

@Component({
  selector: 'app-earn-and-save-savings-list',
  templateUrl: './earn-and-save-savings-list.component.html',
  styleUrls: ['./earn-and-save-savings-list.component.scss']
})
export class EarnAndSaveSavingsListComponent implements OnInit, OnDestroy {
  private isDestroyed$ = new Subject<boolean>();
  private savingsItemPartials: { [key in SavingsItemType]: Partial<SavingsItem> } = {
    TOOTHPIC: {
      icon: 'fas fa-tooth',
      destination: 'https://member.toothpic.com/create-account?ci=onlinedentalvisit'
    },
    LEARN_TO_LIVE: {
      icon: 'fas fa-head-side-brain',
      destination: '**special case**'
    },
    WELL_CONNECTION: {
      icon: 'fas fa-video-plus',
      destination: '/virtual-visit'
    },
    FITNESS_REIMBURSEMENT: {
      icon: 'fas fa-weight',
      destination: '/fitness-and-weightloss'
    },
    BLUE365: {
      icon: 'fas fa-hand-holding-usd',
      destination: 'https://www.blue365deals.com/'
    },
    HOLISTIC_CARE: {
      icon: 'fas fa-hand-holding-heart',
      destination: 'https://www.bluecrossma.org/myblue/find-care/care-options/find-holistic-care/find-alternative-care'
    },
    EMERGENCY_COVERAGE: {
      icon: 'fas fa-first-aid',
      destination: '**special case**'
    },
    PILLPACK: {
      icon: 'fas fa-pills',
      destination: '/my-pillpack/landing'
    }
  };

  public savingsItems: SavingsItem[];

  // prettier-ignore
  constructor(
    private alertService: AlertService,
    private authService: AuthService,
    private translate: TranslateService,
    private loadingSpinnerService: LoadingSpinnerService,
    private myPlansService: MyplansService,
    private planConfigService: PlanConfigService,
    private router: Router,
  ) {}

  public ngOnInit() {
    this.translate
      .get('earnAndSave.savings')
      .takeUntil(this.isDestroyed$)
      .subscribe(
        (translations: SavingsItemTranslation[]) => {
          const savingsTypes = Object.values(SavingsItemType);
          this.savingsItems = savingsTypes.map(savingsItemType => {
            return {
              savingsItemType,
              ...translations[savingsItemType],
              ...this.savingsItemPartials[savingsItemType]
            } as SavingsItem;
          });
        },
        error => {} /* noop: Savings list will remain hidden */
      );
  }

  public ngOnDestroy() {
    this.isDestroyed$.next(true);
    this.isDestroyed$.complete();
  }

  public savingsItemTrackByFn(index: number, savingsItem: SavingsItem) {
    return index;
  }

  public onSavingsItemClick(savingsItemType: SavingsItemType) {
    switch (savingsItemType) {
      case SavingsItemType.LEARN_TO_LIVE:
        $('#openLearnToLive').modal('open');
        break;
      case SavingsItemType.EMERGENCY_COVERAGE:
        this.goToPlanBenefits();
        break;
      default:
        const savingsItem: SavingsItem = this.savingsItems.find(i => i.savingsItemType === savingsItemType);
        if (savingsItem.destination.startsWith('/')) {
          this.router.navigate([savingsItem.destination]);
        } else {
          window.open(savingsItem.destination, '_blank');
        }
        break;
    }
  }

  private goToPlanBenefits() {
    this.loadingSpinnerService.show();
    const today = new Date().toISOString().slice(0, 10);
    forkJoin(this.planConfigService.getCurrentPlanConfig$(), this.myPlansService.getPlansData(today))
      .takeUntil(this.isDestroyed$)
      .map(([currentPlan, plansData]) => {
        if (plansData.result < 0) {
          this.alertService.clearError();
          this.alertService.setAlert(plansData.displaymessage, '', AlertType.Failure);
          throw new Error(plansData.displaymessage);
        }

        /*
         * The "myplans" section was built assuming the user would drill down
         * through the pages to get to the benefits page -- so we have to
         * duplicate the application state that would have resulted from
         * searching plans and then selecting a plan to view.
         */
        const typedPlansData = (plansData as any) as GetPlansBenefitsListResponseModel;
        const currentPlanBenefits = typedPlansData.RowSet.osplinPlans.plans.find(
          plan => plan.coveragePackageCode === currentPlan.coveragePackageCode
        );
        const getPlanBenefitRequest = new GetPlanBenefitServicesRequestModel();
        getPlanBenefitRequest.coveragePackageCode = currentPlan.coveragePackageCode;
        getPlanBenefitRequest.planName = currentPlanBenefits.planName;
        getPlanBenefitRequest.useridin = this.authService.useridin;
        this.myPlansService.setPlanBenefitRequest(getPlanBenefitRequest);

        // tslint:disable-next-line:max-line-length
        const transformedResponse = this.myPlansService.mapPlanBenefitsResponse(typedPlansData as PlanBenefitsListResponseModel);
        const planEntity: PlanEntityInterface = transformedResponse.find(
          transformedPlan => transformedPlan.coveragePackageCode === currentPlan.coveragePackageCode
        );
        this.myPlansService.setSelectedPlanEntity(planEntity);

        return from(this.router.navigateByUrl('/myplans/benefits'));
      })
      .subscribe(
        () => {
          this.loadingSpinnerService.hide();
        },
        error => {
          this.loadingSpinnerService.hide();
          console.log(error);
        }
      );
  }
}
