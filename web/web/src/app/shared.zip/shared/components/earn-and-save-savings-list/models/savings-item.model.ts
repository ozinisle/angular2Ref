import { SavingsItemTranslation } from './savings-item-translation.model';
import { SavingsItemType } from './savings-item-type.enum';

export interface SavingsItem extends SavingsItemTranslation {
  savingsItemType: SavingsItemType;
  destination: string;
  icon: string;
}
