import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-award-details',
  templateUrl: './award-details.component.html',
  styleUrls: ['./award-details.component.scss']
})
export class AwardDetails implements OnInit {
  @Input() public awardDetails: { name: string; url: string; typeCode?: string; subcategory?: string[] };
  @Input() public categoryName: string;
  public profileTooltip = new Array();
  public fasFlagAward = false;
  public toolTipDescription = '';
  constructor() {}
  ngOnInit() {
    if (JSON.parse(sessionStorage.getItem('profileLabel'))) {
      this.profileTooltip = JSON.parse(sessionStorage.getItem('profileLabel'));
    }
    if (this.awardDetails.name && this.awardDetails.name.indexOf('Blue Distinction') >= 0) {
      this.getNPToolTipDescription('PBDC');
    } else if (this.awardDetails.typeCode === 'JCAHO') {
      this.getNPToolTipDescription('PTJC');
    } else if (
      this.awardDetails.typeCode !== 'JCAHO' &&
      this.awardDetails.typeCode !== 'CAR' &&
      this.awardDetails.typeCode !== 'CAO' &&
      this.categoryName === 'ACCREDITATIONS'
    ) {
      this.getNPToolTipDescription('PDNV');
    }
  }

  getNPToolTipDescription(code) {
    if (this.profileTooltip) {
      this.profileTooltip.forEach(tooltip => {
        if (tooltip.toolTip.code === code) {
          this.toolTipDescription = tooltip.toolTip.description;
        }
      });
    }
  }

  fasIconAward() {
    this.fasFlagAward = !this.fasFlagAward;
  }
}
