import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dynamic-promotional-content',
  templateUrl: './dynamic-promotional-content.component.html',
  styleUrls: ['./dynamic-promotional-content.component.scss']
})
export class DynamicPromotionalContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
