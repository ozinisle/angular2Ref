import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-document-upload',
  templateUrl: './document-upload.component.html',
  styleUrls: ['./document-upload.component.scss']
})
export class DocumentUploadComponent {
  @Input() parentForm: FormGroup;
  @Input() programType: string;
  @Input() receiptRequired: boolean;
  @Output() displayCount: EventEmitter<{ imagesCount: number }> = new EventEmitter();
  @Output() disableSubmit = new EventEmitter();

  photos = [];
  disableUpload = false;
  totalSize = 0;
  isInvalidFileTypeError = false;

  deleteImage(index) {
    this.photos.splice(index, 1);
    let sizeError = false;
    this.disableUpload = false;
    this.totalSize = 0;
    this.disableSubmit.emit(false);

    if (this.photos.length === 0) {
      this.displayCount.emit({ imagesCount: this.photos.length });
      this.parentForm.patchValue({ images: '' });
      this.totalSize = 0;
      this.disableUpload = false;
    } else {
      for (let i = 0; i < this.photos.length; i++) {
        const photoString = this.photos[i].imageString;
        const base64Length = photoString.length - (photoString.indexOf(',') + 1);
        const padding = photoString.charAt(photoString.length - 2) === '=' ? 2 : photoString.charAt(photoString.length - 1) === '=' ? 1 : 0;
        const fileSize = base64Length * 0.75 - padding;
        this.totalSize += fileSize;

        if (this.totalSize > 9000000) {
          sizeError = this.disableUpload = true;
          this.disableSubmit.emit(true);
        }

        this.photos[i].error = sizeError;
      }
    }
    this.displayCount.emit({ imagesCount: this.photos.length });
    this.parentForm.patchValue({ images: this.photos });
  }
  importFile(event) {
    this.isInvalidFileTypeError = false;
    if (event.target.files.length === 0) {
      return;
    }
    if (event.target.files && event.target.files[0]) {
      const totalFiles = event.target.files.length;

      let sizeError = false;

      for (let i = 0; i < totalFiles; i++) {
        const reader: FileReader = new FileReader();

        const name:string = event.target.files[i].name || '';
        const lastDot:number = name.lastIndexOf('.');
        const ext:string = name.substring(lastDot + 1) || '';

        if(["PDF","JPEG","TIFF","PNG","JPG"].indexOf(ext.toUpperCase()) === -1) {
          this.isInvalidFileTypeError = true;
          return;
        }

        reader.onload = (event: any) => {
          const photoString: string = event.target.result;
          const base64Length = photoString.length - (photoString.indexOf(',') + 1);
          const padding =
            photoString.charAt(photoString.length - 2) === '=' ? 2 : photoString.charAt(photoString.length - 1) === '=' ? 1 : 0;
          const fileSize = base64Length * 0.75 - padding;
          this.totalSize += fileSize;

          let size = '0';
          if (fileSize < 1000) {
            size = fileSize + ' B';
          } else if (fileSize >= 1000 && fileSize < 1000000) {
            size = Math.round(fileSize / 1000) + ' KB';
          } else if (fileSize >= 1000000) {
            size = Math.round(fileSize / 1000000) + ' MB';
          }

          if (this.totalSize > 9000000) {
            sizeError = this.disableUpload = true;
            this.disableSubmit.emit(true);
          }

          const fileType = photoString.slice(photoString.indexOf(':') + 1, photoString.indexOf(';'));
          const imageString = event.target.result.slice(photoString.indexOf(',') + 1, photoString.length);
          const photo = {
            image: event.target.result,
            type: fileType,
            ext: ext,
            size: size,
            imageString: imageString,
            error: sizeError
          };
          this.photos.push(photo);

          this.displayCount.emit({ imagesCount: this.photos.length });
          this.parentForm.patchValue({ images: this.photos });
        };

        reader.readAsDataURL(event.target.files[i]);
      }
    }
  }
}
