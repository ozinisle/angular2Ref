import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { JUMP_SCREEN_TEXT } from './jump-screen-text';

interface ModalData {
  module?: string;
  url?: string;
  targetContext?: string;
}

@Component({
  selector: 'app-jump-screen',
  templateUrl: './jump-screen.component.html',
  styleUrls: ['./jump-screen.component.scss']
})
export class JumpScreenComponent implements OnInit {
  moduleName: string;
  moduleDescription: string;
  consent1: string;
  consent1Link: string;
  consent2: string;

  constructor(@Inject(MAT_DIALOG_DATA) private data: ModalData, private dialogRef: MatDialogRef<JumpScreenComponent>) {}

  ngOnInit() {
    if(this.data) {
      this.moduleName = JUMP_SCREEN_TEXT['moduleName_' + this.data.module];
      this.moduleDescription = JUMP_SCREEN_TEXT['moduleDesc_' + this.data.module];
      this.consent1Link = JUMP_SCREEN_TEXT['consent1Link_' + this.data.module];
    }
  }

  dismissModal() {
    this.dialogRef.close('Cancel');
  }

  callToActionClicked() {
    this.dismissModal();
    console.log('this.data',this.data);
    sessionStorage.setItem('targetHEQLocation', JSON.stringify(this.data));
    window.open(this.data.url, '_blank');
  }
}
