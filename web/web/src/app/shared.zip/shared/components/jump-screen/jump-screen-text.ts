export const JUMP_SCREEN_TEXT = {
  //Virgin Pulse
  moduleName_virginPulse: 'virginpulse.com',
  moduleDesc_virginPulse:
  'Virgin Pulse® ́ is an independent company that administers your wellness rewards program on behalf of Blue Cross Blue Shield of Massachusetts.',
  consent1Link_virginPulse:
    "Virgin Pulse's site.",
  //Health Equity
  moduleName_heq: 'HealthEquity Member Website',
  moduleDesc_heq:
    'The purpose of the website is to provide members with information related to their financial accounts at HealthEquity.',
  consent1Link_heq:
    "HealthEquity’s site.",
};
 