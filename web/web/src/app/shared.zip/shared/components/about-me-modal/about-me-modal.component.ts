import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ProfileService } from '../../services/myprofile/profile.service';

@Component({
  selector: 'app-about-me-modal',
  templateUrl: './about-me-modal.component.html',
  styleUrls: ['./about-me-modal.component.scss']
})
export class AboutMeModalComponent implements OnInit {
  public showRELAfterPrefModal = false;
  constructor(
    private router: Router,
    private dialogRef: MatDialogRef<AboutMeModalComponent>,
    private profileService: ProfileService,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.showRELAfterPrefModal = this.profileService.showRELAfterPrefModal;
    this.profileService.notifyDemographicsModelDisplayed().subscribe(response => {
      this.authService.setShowDemographicModel(false);
    });
  }

  navigateToAboutMe() {
    this.dialogRef.close();
    sessionStorage.setItem('toggleAboutMe', 'true');
    this.router.navigate(['/myprofile/about-me']);
  }

  close() {
    this.profileService.showRELAfterPrefModal = false;
    this.dialogRef.close();
  }
}
