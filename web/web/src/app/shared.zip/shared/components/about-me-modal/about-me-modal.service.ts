import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material';
import { PostLoginInfo } from '../../models/postlogininfo.model';
import { AuthService } from '../../services/auth.service';
import { AboutMeModalComponent } from './about-me-modal.component';

@Injectable()
export class AboutMeModalService {
  private postLoginInfo: PostLoginInfo;

  constructor(private dialog: MatDialog, private authService: AuthService) {}

  showModal() {
    if (this.postLoginInfo.showDemographicModel && this.authService.isUserActive()) {
      this.dialog.open(AboutMeModalComponent, {
        disableClose: true
      });
    }
  }

  initiateAboutMeModal() {
    const hasInitiated = sessionStorage.getItem('hasAboutMeModalInitiated');
    const hasShownPreferenceModal = sessionStorage.getItem('preferenceModalShown');
    if ((hasInitiated && hasInitiated === 'true') || hasShownPreferenceModal === 'true') {
      return;
    }
    this.postLoginInfo = this.authService.postLoginInfo;
    if (this.postLoginInfo) {
      this.showModal();
    } else {
      setTimeout(() => {
        this.initiateAboutMeModal();
      }, 1000);
    }
  }
}
