import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Image } from '../../../shared/models/image.model';
import { environment } from '../../../../environments/environment';
import { ConstantsService } from '../../services/constants.service';
import { AuthHttp } from '../../services/auth-http.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-campaign-telehealth-search-results',
  templateUrl: './campaign-telehealth-search-results.component.html',
  styleUrls: ['./campaign-telehealth-search-results.component.scss']
})
export class CampaignTelehealthSearchResultsComponent implements OnInit {
  public fpocontentData1: Image;
  fpoTargetUrl: string;
  public environment: object;
  public telehelathCode: string;
  private showwellConnection: boolean = false;
  public displayCampaignTelehealth: boolean = true;
  flagshowhidetelehealthsearchBanner = true;
  @Output() valueChange = new EventEmitter();

  constructor(private authHttp: AuthHttp, private constants: ConstantsService, private router: Router) {
    this.environment = environment;
  }

  ngOnInit() {
    const vitalsResponse = JSON.parse(sessionStorage.getItem('vitalsResponse'));
    this.telehelathCode = vitalsResponse.platformProvider.code;
    if (this.telehelathCode === '01') {
      this.showwellConnection = true;
      this.fpoTargetUrl = this.constants.drupalContentTeleHealthUrl;
    } else {
      this.fpoTargetUrl = this.constants.drupalContentTeleHealthWithOutWellConnectionUrl;
    }

    this.authHttp.get(this.fpoTargetUrl).subscribe(response => {
      this.fpocontentData1 = response[0];
      //this.authHttp.hideSpinnerLoading();
      console.log(this.fpocontentData1);
    });
  }

  close() {
    //this.displayCampaignTelehealth = false;
    this.flagshowhidetelehealthsearchBanner = false;
    this.valueChange.emit(this.flagshowhidetelehealthsearchBanner);
  }
  memberLinkOpenUrl() {
    this.router.navigateByUrl('/virtual-visit');
  }
}
