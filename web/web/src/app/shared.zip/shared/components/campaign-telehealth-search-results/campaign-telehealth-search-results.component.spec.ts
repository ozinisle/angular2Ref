import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CampaignTelehealthSearchResultsComponent } from './campaign-telehealth-search-results.component';

describe('CampaignTelehealthSearchResultsComponent', () => {
  let component: CampaignTelehealthSearchResultsComponent;
  let fixture: ComponentFixture<CampaignTelehealthSearchResultsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CampaignTelehealthSearchResultsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CampaignTelehealthSearchResultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
