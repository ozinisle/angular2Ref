import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { mocks } from '../../../../jasmine/constants/mocks.service';
import { LandingService } from '../../../pages/landing/landing.service';
import { Finanical } from '../../models/finanical.model';

import { FinancialsComponent } from './financials.component';

describe('FinancialsComponent', () => {
  let component: FinancialsComponent;
  let fixture: ComponentFixture<FinancialsComponent>;
  const mockLandingService = mocks.service.landingService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinancialsComponent ],
      providers: [
        { provide: LandingService, useValue: mockLandingService },
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinancialsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('getFinanicalData', () => {

      beforeAll(() => {
        spyOn(FinancialsComponent.prototype, 'hasFinancialsData').and.returnValue(true);
        fixture = TestBed.createComponent(FinancialsComponent);
        component = fixture.componentInstance;
      });

      it('should call the financial data api', () => {
        component.getFinancialData();
        expect(component.landingService.getFinanceBalanceData).toHaveBeenCalled();
      });

      it('should assign the financial data to component', fakeAsync(() => {
        component.getFinancialData();
        tick(1000);
        expect(component.financialChartDetails).toBeTruthy();
        const financial = new Finanical();
        financial.isALGAccount = false;
        financial.Type = 'DCRA';
        financial.PlanStartDate = '2020-01-01 - 2020-12-31';
        financial.PlanEndDate = '';
        financial.chartOptions.headerText = 'Annual Election';
        financial.chartOptions.headerText1 = 'Dependant Care Reimbursement Account';
        financial.chartOptions.totalValue =  2307.72;
        financial.chartOptions.chartValue = 0;
        financial.chartOptions.AnnualElection = 5000;
        financial.chartOptions.chartColor = '#3DA148';
        financial.chartOptions.chartBackgroundColor = '#FFFFFF';
        financial.chartOptions.chartOption1Text = 'Available';
        financial.chartOptions.chartOption2Text = 'Spent';
        expect(component.financialChartDetails[0]).toEqual(jasmine.objectContaining(financial));
      }));
    });

});
