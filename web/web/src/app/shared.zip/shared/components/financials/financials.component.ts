import { Component, ElementRef, Input, OnInit, QueryList, Renderer2, ViewChild, ViewChildren } from '@angular/core';
import { MatDialog } from '@angular/material';
import { finalize } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import { LandingService } from '../../../pages/landing/landing.service';
import { Finanical } from '../../models/finanical.model';
import { AuthService } from '../../services/auth.service';
import { GlobalService } from '../../services/global.service';
import { JumpScreenComponent } from '../jump-screen/jump-screen.component';

declare var $: any;

interface ModalData {
  url?: string;
}

@Component({
  selector: 'app-financials',
  templateUrl: './financials.component.html',
  styleUrls: ['./financials.component.scss']
})
export class FinancialsComponent implements OnInit {
  @Input() ismobile = false;
  @Input() isHomePage = false;
  @Input() hideNonMedicalAccounts = true;
  @Input() showBalance = false;

  isFinancialView = false;
  userState: string;
  hasMedicalAccounts = false;

  isDisplayFinanceLoader = true;
  financialChartDetails: Finanical[] = [];
  financialChartCounter = 0;
  isHeqTransactionsEnabled: boolean;
  isFinancialWidgetEnabled: boolean;
  @ViewChildren('transactions', {read: ElementRef}) transactions: QueryList<ElementRef>;
  @ViewChildren('wrapper') wrapper: QueryList<ElementRef>;
  @ViewChild('financeSection') financeSection: ElementRef;
  targetContext = {};

  constructor(
    private landingService: LandingService,
    private authService: AuthService,
    private globalService: GlobalService,
    private renderer: Renderer2,
    private matDialog: MatDialog,

  ) {
    this.isHeqTransactionsEnabled = environment.showHeqTransactions;
    this.isFinancialWidgetEnabled = environment.enableFinancialWidget;
  }

  ngOnInit() {
    this.initFinancials();
  }

  initFinancials() {
    this.userState = this.landingService.memberInfo.userState;
    this.getFinancialData();
  }

  hasFinancialsData(): boolean {
    const hasALG = this.landingService.memberInfo.hasALG.toString().toLowerCase();
    const hasHEQ = this.landingService.memberInfo.hasHEQ.toString().toLowerCase();
    const result = this.landingService.memberInfo && (hasALG === 'yes' || hasHEQ === 'yes' || hasHEQ === 'true' || hasALG === 'true');
    sessionStorage.setItem('hasALG', hasALG);
    sessionStorage.setItem('hasHEQ', hasHEQ);
    this.isFinancialView = result;
    this.landingService.hasFinancialView$.next(this.isFinancialView);
    return result;
  }

  getFinancialData() {
    this.landingService.hasMedicalAccounts$.next(false);
    if (this.hasFinancialsData()) {
      this.globalService.updateHasPlanFinancialDetails(true);
      this.isFinancialView = true;
      this.isDisplayFinanceLoader = true;
      this.landingService
        .getFinanceBalancChartData()
        .pipe(finalize(() => (this.isDisplayFinanceLoader = false)))
        .subscribe(response => {
          this.financialChartDetails = response && response.financialInfo ? response.financialInfo : [];
          this.hasMedicalAccounts = response.hasMedicalAccounts;
          if(!this.hasMedicalAccounts) {
            this.isFinancialView = !this.hideNonMedicalAccounts;
          }
          if (this.isFinancialWidgetEnabled && !this.ismobile && this.showBalance) {
            setTimeout(() => this.calculateMaximumHeight(), 0);
          }
        });
    } else {
      this.financialChartDetails = [];
      setTimeout(() => this.landingService.financialInfoLength$.next(0));
    }
  }

  calculateMaximumHeight() {
    let maxHeight = Math.max(...this.transactions.map((elm) => elm.nativeElement.offsetHeight));
    if (!isNaN(maxHeight)) {
      maxHeight =  maxHeight < 259 ? 259 : maxHeight;
      this.transactions.forEach((elm) => {
        this.renderer.setStyle(elm.nativeElement, 'height', `${maxHeight}px`);
        this.renderer.setStyle(elm.nativeElement, 'min-height', `220px`);
      });    
      this.wrapper.forEach((elm) => {
        this.renderer.setStyle(elm.nativeElement, 'min-height', `${maxHeight}px`);
      });      
      this.renderer.setStyle(this.financeSection.nativeElement, 'min-height', `${maxHeight}px`);
    }
  }

  incrementFinancialDetailsCounter() {
    if (this.financialChartCounter !== this.financialChartDetails.length - 1) {
      this.financialChartCounter =
        this.financialChartCounter === this.financialChartDetails.length - 1 ? 0 : this.financialChartCounter + 1;
    }
  }

  decrementFinancialDetailsCounter() {
    if (this.financialChartCounter > 0) {
      this.financialChartCounter =
        this.financialChartCounter === 0 ? this.financialChartDetails.length : this.financialChartCounter - 1;
    }
  }
  setSlider(i: number) {
    this.financialChartCounter = i;
  }

  isHsaAccount(accountType) {
    return ['ABH', 'HSA', 'AB2'].includes(accountType);
  }

  navigateToAlegeus(lineChart: Finanical, isTransaction = false): void {
    if (!lineChart) {
      lineChart = this.financialChartDetails[this.financialChartCounter];
    }
    if (isTransaction) {
      const targetContext = {
        location: 'Transaction',
        accountType: lineChart.Type,
      };
      localStorage.setItem('targetContext', JSON.stringify(targetContext));
    }
    const impersonate = this.authService.impersonation();
    if (lineChart && !impersonate) {
      if (lineChart.isALGAccount) {
        $('#openSsoAlgSite').modal('open');
      } else {
          this.targetContext = {
            location: 'Transaction',
            accountType: 'HSA',
            accountNumber: ''
          }; 
        this.matDialog.open(JumpScreenComponent, {
          maxWidth: '100%',
          panelClass: 'menu-dialog',
          autoFocus: false,
          data: {
            url: 'sso/heathequity',
            module: 'heq',
            targetContext: this.targetContext
          }
        });
          }
    }
  }
}