import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectPlanModalComponent } from './select-plan-modal.component';

describe('SelectPlanModalComponent', () => {
  let component: SelectPlanModalComponent;
  let fixture: ComponentFixture<SelectPlanModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectPlanModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectPlanModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
