import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material';
import { Router } from '@angular/router';
import { AlertType } from '../../../shared/alerts/alertType.model';
import { HeaderService } from '../../layouts/header/header.service';
import { AuthToken } from '../../models/authToken';
import { AlertService } from '../../services/alert.service';
import { AuthHttp } from '../../services/auth-http.service';
import { AuthService } from '../../services/auth.service';
import { SelectPlanModalService } from './select-plan-modal.service';

@Component({
  selector: 'app-select-plan-modal',
  templateUrl: './select-plan-modal.component.html',
  styleUrls: ['./select-plan-modal.component.scss']
})
export class SelectPlanModalComponent implements OnInit {
  @ViewChild('openPlansSelectModal')
  private openPlansSelectModall: TemplateRef<any>;
  refDialogue: MatDialogRef<any, any>;
  getmemberPlans: any;
  isPlansErrorFound: boolean;
  getAllMemberPlans: any;
  memberPlans: any;
  selectedPlan: any;
  selectedRadioValue: any;
  currentUrl: string;
  memId: string;
  currentPlansArray = [];
  previousPlansArray = [];
  futurePlansArray = [];
  plansArrayy: any[];
  buttonDisable = true;
  radioSelected: any;
  selectedPlanEffectiveDate: any;
  hasMemberPlans = JSON.parse(sessionStorage.getItem('selectedPlanDetails')) !== null &&
  JSON.parse(sessionStorage.getItem('defaultIPAPlan')) !== null;

  constructor(
    private dialogRef: MatDialog,
    public headerService: HeaderService,
    private selectPlanSerice: SelectPlanModalService,
    private authService: AuthService,
    private authHttpService: AuthHttp,
    private router: Router,
    private alertService: AlertService
  ) {}

  ngOnInit() {
    sessionStorage.setItem('currentPageReload', 'false');

    this.getmemberPlans = JSON.parse(sessionStorage.getItem('getMemberPlans'));
    if (sessionStorage.getItem('selectedPlanName') !== null) {
      this.selectedPlan = sessionStorage.getItem('selectedPlanName');
      this.selectedPlanEffectiveDate = sessionStorage.getItem('selectedPlanEffectiveDate');
      this.memId = JSON.parse(sessionStorage.getItem('selectedPlanDetails')).cardMemId;
      this.memberPlans = this.getMemberPlans(this.getmemberPlans.plans);
    } else {
      if (this.getmemberPlans && this.getmemberPlans.result && this.getmemberPlans.result < 0) {
        this.isPlansErrorFound = true;
      } else {
        this.isPlansErrorFound = false;
        this.memberPlans = this.hasMemberPlans && this.getMemberPlans(this.getmemberPlans.plans);
      }
    }
  }

  getMemberPlans(memberplans) {
    memberplans.forEach(element => {
      if (element.defaultPlan === 'true') {
        if (element.defaultPlan === 'true' && sessionStorage.getItem('selectedPlanName') === null) {
          sessionStorage.setItem('defaultIPAPlan', JSON.stringify(element));
          this.selectedPlan = 'Current Plan';
          sessionStorage.setItem('defaultPlan', 'Current Plan');
          this.selectedPlanEffectiveDate = element.planEffectiveDate +`${(element.planEndDate)?'-':''}` + element.planEndDate;
          this.memId = element.cardMemId;
          this.buttonDisable = true;
        }
        this.currentPlansArray.push(element);
      } else if (element.defaultPlan === 'false' && element.activePlan === 'true' && element.futurePlan === 'false') {
        if (element.defaultPlan === 'true' && sessionStorage.getItem('selectedPlanName') === null) {
          sessionStorage.setItem('defaultIPAPlan', JSON.stringify(element));
          this.selectedPlan = 'Other Plan';
          sessionStorage.setItem('defaultPlan', 'Other Plan');
          this.selectedPlanEffectiveDate = element.planEffectiveDate +`${(element.planEndDate)?'-':''}` + element.planEndDate;
          this.memId = element.cardMemId;
          this.buttonDisable = true;
        }
        this.previousPlansArray.push(element);
      } else {
        this.futurePlansArray.push(element);
      }
    });
    // this.previousPlansArray.concat(this.futurePlansArray);
    this.previousPlansArray.push(...this.futurePlansArray);
    this.plansArrayy = this.currentPlansArray.concat(this.previousPlansArray, this.futurePlansArray);
    return this.plansArrayy;
  }

  radioSelection(event) {
    this.radioSelected = event.value.cardMemId;
    sessionStorage.setItem('radioSelected', this.radioSelected);
    if (event.value.cardMemId === this.memId || (event.value.activePlan === null && event.value.futurePlan === 'true')) {
      this.buttonDisable = true;
    } else {
      this.buttonDisable = false;
      this.radioSelected = this.memId;
      sessionStorage.setItem('radioSelected', this.radioSelected);
    }
    this.selectedRadioValue = event;
  }

  onSubmitPlanSelection() {
    this.selectPlanSerice.getSwitchPlanAPI(this.selectedRadioValue.value.cardMemId, this.selectedRadioValue.value.cardMemSuffix).subscribe(
      res => {
        if (res && res.result && res.result < 0) {
          this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
        } else {
          sessionStorage.setItem('isIPASelected', 'true');
          this.authService.authToken = new AuthToken(res);
          sessionStorage.setItem('authToken', JSON.stringify(this.authService.authToken));
          const currentUrl = this.router.url;

          //The below approach seems to not be loading all the data as expected hence we are switching back to reloading on plan switching

          // this.router.navigateByUrl('/home', { skipLocationChange: true }).then(() => {
          // this.router.navigate([currentUrl]);
          // })
          sessionStorage.setItem('currentPageReload', 'true');
          window.location.reload();
        }
      },
      error => {
        console.warn(error);
      }
    );
    if (
      this.hasMemberPlans &&
      this.selectedRadioValue.value.activePlan === 'true' &&
      this.selectedRadioValue.value.futurePlan === 'false' &&
      JSON.parse(sessionStorage.getItem('defaultIPAPlan')).cardMemId === this.selectedRadioValue.value.cardMemId
    ) {
      sessionStorage.setItem('selectedPlanName', 'Current Plan');
    } else {
      sessionStorage.setItem('selectedPlanName', 'Other Plan');
    }

    sessionStorage.setItem('selectedPlanDetails', JSON.stringify(this.selectedRadioValue.value));
    //remove the below sessionstorage elements and use the above session object ( reduces complexity)
    sessionStorage.setItem(
      'selectedPlanEffectiveDate',
      this.selectedRadioValue.value.planEffectiveDate + `${(this.selectedRadioValue.value.planEndDate)?'-':''}` + this.selectedRadioValue.value.planEndDate
    );
    this.selectedPlan = sessionStorage.getItem('selectedPlanName');
    this.selectedPlanEffectiveDate = sessionStorage.getItem('selectedPlanEffectiveDate');
    this.memId = JSON.parse(sessionStorage.getItem('selectedPlanDetails')).cardMemId;;
    this.refDialogue.close();
  }

  openModal() {
    this.refDialogue = this.dialogRef.open(this.openPlansSelectModall, {
      width: '575px',
      panelClass: 'modal-template',
      disableClose: true
    });
    this.radioSelected = sessionStorage.getItem('radioSelected');
    if (this.radioSelected === this.memId) {
      this.buttonDisable = true;
    }
  }
  closeModals() {
    this.refDialogue.close();
  }
}
