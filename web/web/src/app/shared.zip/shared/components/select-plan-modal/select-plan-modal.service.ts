import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { AuthHttp } from '../../services/auth-http.service';
import { AuthService } from '../../services/auth.service';
import { ConstantsService } from '../../services/constants.service';

@Injectable()
export class SelectPlanModalService {

  constructor(
    private authService: AuthService,
    private constants: ConstantsService,
    private http: AuthHttp,
  ) { }

  getSwitchPlanAPI(memberId, memberSuffix ): Observable<any> {
    const request = {
      mesg: {
      useridin: this.authService.useridin,
      cardMemId: memberId,
      cardMemSuffix: memberSuffix,
      migrationType : this.authService.authToken.migrationtype,
      destinationURL : this.authService.authToken.destinationURL,
      key2id: this.authService.cryptoToken.key2id
    },
    key1id: this.authService.cryptoToken.key1id
    };
    return this.http.encryptPost(this.constants.switchPlanAPI, request).pipe(map(data=> {return data}));
  }

}
