export interface EmailAddress {
  title: string;
  emailAddress: string;
  hide: boolean;
  formName: string;
  editable: boolean;
}
