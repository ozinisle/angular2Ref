import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs/Subject';
import { EmailAddress } from '../../../shared/components/email/EmailAddressInterface';

@Component({
  selector: 'email-addresses',
  templateUrl: './email.component.html',
  styleUrls: ['./email.component.scss']
})
export class EmailComponent implements OnInit, OnDestroy {
  // private emailAddress: string;
  @Input() parentForm: FormGroup;
  @Input() emailAddress: EmailAddress;
  @Input() emailAddresses: EmailAddress[] = [];
  @Input() isMedicare: boolean;

  @Output() emailRemoveClick: EventEmitter<{
    email: EmailAddress;
    e: any;
  }> = new EventEmitter();

  destroy$: Subject<boolean> = new Subject<boolean>();

  emailCount: number;
  emailExist: boolean;
  title: string;
  emailRegex: RegExp;

  ngOnInit() {
    this.transformEmail(this.emailAddresses);
    this.emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    this.parentForm.valueChanges.pipe(takeUntil(this.destroy$)).subscribe(value => {
      if (value && value.email) {
        this.emailAddresses[0].emailAddress = value.email;
      }
    });
  }

  transformEmail(emailAddresses: EmailAddress[]) {
    if (this.emailAddresses && emailAddresses.length > 0) {
      this.emailAddresses.map((emailAddress: EmailAddress, i: number) => {
        this.setEmailAddress(emailAddress, i);
        this.setFormValue(emailAddress, i);
      });
    } else {
      this.addEmail();
    }
  }

  setEmailAddress(emailAddress: EmailAddress, i: number) {
    this.title = this.isMedicare ? 'Member Email*:' : 'Subscriber Email*:';
    emailAddress.title = i === 0 ? this.title : 'Additional Email:';
    emailAddress.formName = i === 0 ? 'email' : 'additionalemail';
    emailAddress.hide = i <= 1;
    this.emailExist = true;
    this.emailCount = i;
    this.setEditable(emailAddress, i);
  }

  setEditable(emailAddress: EmailAddress, i: number) {
    if (emailAddress.editable && i === 0) {
      this.parentForm.controls['email'].enable();
    }
  }

  setFormValue(emailAddress: EmailAddress, i: number) {
    i === 0
      ? this.parentForm.patchValue({ email: emailAddress.emailAddress })
      : this.parentForm.patchValue({ additionalemail: emailAddress.emailAddress });
  }

  addEmail() {
    this.emailAddress = {} as EmailAddress;
    this.emailCount = this.emailAddresses ? this.emailAddresses.length : 0;
    this.emailAddress.title = this.emailCount === 0 ? 'Subscriber Email*:' : 'Additional Email:';
    this.emailAddress.formName = this.emailCount === 0 ? 'email' : 'additionalemail';
    this.emailAddress.hide = this.emailCount === 0 ? true : false;
    this.emailExist = false;
    this.emailAddress.emailAddress = '';
    this.emailAddresses.push(this.emailAddress);
  }

  emailSelectedClick(item, e) {
    this.delete(item, e);
  }

  delete(item: EmailAddress, e) {
    this.parentForm.get(item.formName).setValue('');
  }

  toggleEdit() {
    this.addEmail();
  }

  ngOnDestroy() {
    this.destroy$.next(true);
    // Now let's also unsubscribe from the subject itself:
    this.destroy$.unsubscribe();
  }
}
