import { Component, OnInit } from '@angular/core';

/**
 * Directive for styling semantic HTML elements as visual "buttons"
 * that adhere to the BCBSMA 2021 Visual Development Kit (VDK).
 */
@Component({
  selector: 'a[vdk-button], button[vdk-button], input[vdk-button]',
  templateUrl: './vdk-button.component.html',
  styleUrls: ['./vdk-button.component.scss']
})
export class VdkButtonComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
