import {
  RatingBarStylesInterface,
  SolidStarStylesInterface,
  StarRatingComponentDataModelInterface,
  StarRatingComponentInputModelInterface
} from './star-rating.interface';

export class StarRatingComponentInputModel implements StarRatingComponentInputModelInterface {
  public numberOfStars = 5;
  public starColor = '#F68C0B';
  public inActiveStarColor = '#DDDDDD';
  public emptyStarBackgroundColor = 'inherit';
  public ratingInPercentage: number;
  public isInActive = false;
  public totalRatings = 0;
  public overAllRating = 0;
  public showReviewCount = true;
  public from = '';
}

export class StarRatingComponentDataModel implements StarRatingComponentDataModelInterface {
  ratingBarStyles: RatingBarStylesInterface;
  inActiveRatingBarStyles: RatingBarStylesInterface;
  solidStarStyles: SolidStarStylesInterface;
  starNumberRange: number[];
  starRating: number;
  totalRatings: number;
  isInActive: boolean;
  showReviewCount: boolean;
}
