import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceFailureModalComponent } from './service-failure-modal.component';

describe('ServiceFailureModalComponent', () => {
  let component: ServiceFailureModalComponent;
  let fixture: ComponentFixture<ServiceFailureModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServiceFailureModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServiceFailureModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
