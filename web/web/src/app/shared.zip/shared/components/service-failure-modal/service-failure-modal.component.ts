import { Component, EventEmitter, Inject, OnInit, Output } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-service-failure-modal',
  templateUrl: './service-failure-modal.component.html',
  styleUrls: ['./service-failure-modal.component.scss']
})
export class ServiceFailureModalComponent implements OnInit {

  isSameEmailError: boolean = false;
  @Output() onRetryClicked = new EventEmitter();

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialog: MatDialogRef<ServiceFailureModalComponent>
  ) { }

  ngOnInit() {
    if (this.data.result === -95718) {
      this.isSameEmailError = true;
    }
  }

  retry() {
    this.onRetryClicked.emit();
  }

  close() {
    this.dialog.close();
  }

}
