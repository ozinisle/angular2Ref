import { Component, ElementRef, Input, OnChanges, OnInit, Renderer2, ViewChild } from '@angular/core';

@Component({
  selector: 'vdk-tab-button',
  templateUrl: './vdk-tab-button.component.html',
  styleUrls: ['./vdk-tab-button.component.scss']
})
export class VdkTabButtonComponent implements OnInit, OnChanges {
  private readonly CLASS_SELECTED = 'selected';

  @Input() public selected: boolean;

  @ViewChild('link') linkElementRef: ElementRef;

  constructor(private renderer: Renderer2) {}

  ngOnInit() {}

  ngOnChanges() {
    const linkElement = this.linkElementRef.nativeElement;

    if (linkElement) {
      if (this.selected) {
        this.renderer.addClass(linkElement, this.CLASS_SELECTED);
      } else {
        this.renderer.removeClass(linkElement, this.CLASS_SELECTED);
      }
    }
  }
}
