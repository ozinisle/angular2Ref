import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-fw-modal',
  templateUrl: './fw-modal.component.html',
  styleUrls: ['./fw-modal.component.scss']
})
export class FwModalComponent implements OnInit {
  @Input() showEligibility: boolean;
  @Input() showCertification: boolean;
  @Input() collateralText: string;
  @Output() showModalClick: EventEmitter<{ showModal: boolean }> = new EventEmitter();
  constructor() {}

  ngOnInit() {}

  closeEligibility() {
    this.showEligibility = false;
    this.showModalClick.emit({ showModal: this.showEligibility });
  }

  closeCertification() {
    this.showCertification = false;
    this.showModalClick.emit({ showModal: this.showCertification });
  }
}
