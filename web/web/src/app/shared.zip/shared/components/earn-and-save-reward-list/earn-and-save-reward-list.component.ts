import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { EarnAndSaveService } from '../../services/earn-and-save/earn-and-save.service';
import { RewardCode } from '../../services/earn-and-save/models/reward-code.enum';
import { SimpleRewardStatus } from '../../services/earn-and-save/models/simple-reward-status.enum';
import { SimpleReward } from '../../services/earn-and-save/models/simple-reward.model';
import { EarnAndSaveRewardModalComponent } from '../earn-and-save-reward-modal/earn-and-save-reward-modal.component';
import { JumpScreenComponent } from '../jump-screen/jump-screen.component';

@Component({
  selector: 'app-earn-and-save-reward-list',
  templateUrl: './earn-and-save-reward-list.component.html',
  styleUrls: ['./earn-and-save-reward-list.component.scss']
})
export class EarnAndSaveRewardListComponent implements OnInit, OnDestroy {
  private isDestroyed$ = new Subject<boolean>();

  public SimpleRewardStatus = SimpleRewardStatus;

  @Input() public filter: 'active' | 'inactive' = 'active';
  @Input() public isActive = true;
  @Input() public categoryText = '';
  @Input() public counterText = '';
  @Input() public headerLevel = 2;

  public rewards: SimpleReward[];
  public shouldShowError = false;

  // prettier-ignore
  constructor(
    public earnAndSaveService: EarnAndSaveService,
    public matDialog: MatDialog,
    private router: Router,
  ) {}

  ngOnInit() {
    this.earnAndSaveService
      .fetchRewards()
      .takeUntil(this.isDestroyed$)
      .subscribe(
        rewards => {
          if (rewards) {
            // tslint:disable-next-line:prefer-conditional-expression
            if (this.filter === 'active') {
              this.rewards = rewards.filter(reward => reward.status !== SimpleRewardStatus.NOT_READY);
            } else {
              this.rewards = rewards.filter(reward => reward.status === SimpleRewardStatus.NOT_READY);
            }
          } else {
            this.shouldShowError = true;
          }
        },
        () => (this.shouldShowError = true)
      );
  }

  ngOnDestroy() {
    this.isDestroyed$.next(true);
    this.isDestroyed$.complete();
  }

  public onRewardClick(rewardCode: string) {
    const selectedReward = this.rewards.find(reward => reward.code === rewardCode);
    if (!selectedReward) {
      return;
    }

    if (selectedReward.code === RewardCode.VIRGIN_PULSE) {
      const dialogRef = this.matDialog.open(JumpScreenComponent, {
        maxWidth: '100%',
        panelClass: 'menu-dialog',
        autoFocus: false,
        data: {
          module: 'virginPulse',
          url: environment.featureVirginPulseSsoEnabled ? '/sso/virgin_pulse' : 'https://www.join.virginpulse.com/wellness'
        }
      });
      return;
    }

    this.matDialog.open(EarnAndSaveRewardModalComponent, {
      // maxWidth: '100%' /* remove dynamic restriction so stylesheet gets more control */,
      // maxHeight: '100%' /* remove dynamic restriction so stylesheet gets more control */,
      panelClass: 'earn-and-save-reward-modal' /* defined in global stylesheet */,
      data: {
        reward: selectedReward
      }
    });
  }

  public onReloadPageClick() {
    this.shouldShowError = false;
    this.earnAndSaveService.refreshRewards();
  }

  public rewardTrackByFn(index: number, reward: SimpleReward) {
    return reward.code;
  }
}
