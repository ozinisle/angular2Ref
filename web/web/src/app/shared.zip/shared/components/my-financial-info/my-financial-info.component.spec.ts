import { DebugElement } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { MyFinancialInfoComponent } from './my-financial-info.component';

describe('MyFinancialInfoComponent', () => {
  let component: MyFinancialInfoComponent;
  let fixture: ComponentFixture<MyFinancialInfoComponent>;
  let financialInfo: DebugElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyFinancialInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyFinancialInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    financialInfo = fixture.debugElement.query(By.css('.finacial-info'));
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('hide/show my financial info based on showFinancialinfo', () => {
    component.hasMedicalAccounts = true;
    fixture.detectChanges();
    expect(financialInfo).toBeTruthy();
    component.hasMedicalAccounts = false;
    fixture.detectChanges();
    expect(financialInfo).toBeNull();
  });
});
