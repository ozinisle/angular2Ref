import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { ConstantsService } from '../../services/constants.service';
import { LandingService } from '../../../pages/landing/landing.service';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-my-financial-info',
  templateUrl: './my-financial-info.component.html',
  styleUrls: ['./my-financial-info.component.scss']
})
export class MyFinancialInfoComponent implements OnInit, OnDestroy {

  destroy$ = new Subject<void>();
  @Input() isDisclaimer = false;
  fpoTargetUrl: string;
  hasMedicalAccounts = false;

  constructor(
    private constantService: ConstantsService,
    private landingService: LandingService
  ) { }

  ngOnInit() {
    this.landingService.hasMedicalAccounts$.
    pipe(takeUntil(this.destroy$))
    .subscribe((hasMedicalAccounts) => {
      this.hasMedicalAccounts = hasMedicalAccounts;
    });
    this.fpoTargetUrl = this.constantService.drupalFinancialInfoUrl;
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

}
