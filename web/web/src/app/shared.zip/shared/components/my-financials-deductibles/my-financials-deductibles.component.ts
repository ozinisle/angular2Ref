import { Component, Input, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { take } from 'rxjs/operators';
import { LandingService } from '../../../pages/landing/landing.service';
import { AuthService } from '../../services/auth.service';
import { GlobalService } from '../../services/global.service';

@Component({
  selector: 'app-my-financials-deductibles',
  templateUrl: './my-financials-deductibles.component.html',
  styleUrls: ['./my-financials-deductibles.component.scss']
})
export class MyFinancialsComponent implements OnInit {
  @Input() ismobile = false;
  @Input() isHomePage = false;
  @Input() showHeader = false;
  @Input() showFinancialInfo = false;
  @Input() hideNonMedicalAccounts = false;
  hasMedicalAccounts: boolean;
  hasMemberInfo = false;
  isAuthenticatedUser = false;
  hasPlanFinancialDetails$: Observable<boolean>;

  constructor(private landingService: LandingService, private authService: AuthService, private globalService: GlobalService) {}

  ngOnInit() {
    this.landingService.hasMedicalAccounts$.pipe(take(1)).subscribe(value => {
      this.hasMedicalAccounts = value;
    });
    this.isAuthenticatedUser = this.authService.getScopeName() === 'AUTHENTICATED-AND-VERIFIED';
    this.hasPlanFinancialDetails$ = this.globalService.hasPlanFinancialDetails$;
    if (this.isAuthenticatedUser) {
      if (this.landingService.memberInfo) {
        this.hasMemberInfo = true;
      } else {
        this.landingService.getHomePageInfo().subscribe(() => {
          this.hasMemberInfo = true;
        });
      }
    }
  }
}
