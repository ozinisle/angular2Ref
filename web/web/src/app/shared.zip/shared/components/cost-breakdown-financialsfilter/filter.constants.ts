export class FilterComponentConstants {
    public static ALL = 'ALL';
    public static CUSTOM = 'CUSTOM';
    public static CLEAR = 'CLEAR';
}
