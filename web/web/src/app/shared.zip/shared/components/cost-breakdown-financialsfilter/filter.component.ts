import { animate, state, style, transition, trigger } from '@angular/animations';
import {
  AfterViewInit,
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  Input,
  OnChanges,
  OnInit,
  Output,
  QueryList,
  ViewChild,
  ViewChildren
} from '@angular/core';
import { MatCalendar, MatListOption, MatRadioChange, MatRadioGroup, MatSelectionList, MatSelectionListChange } from '@angular/material';
import * as moment from 'moment';
import { FilterService } from '../../services/filter.service';
import { GlobalService } from '../../services/global.service';
import { FilterComponentConstants } from './filter.constants';
import { FilterInterface, FilterItemInterface, FilterOptionInterface, FilterSelectionItemInterface } from './filter.model';

@Component({
  selector: 'app-cost-breakdown-financials-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss'],
  animations: [
    trigger('slideInOut', [
      state(
        'in',
        style({
          transform: 'translate3d(0,0,0)'
        })
      ),
      state(
        'out',
        style({
          transform: 'translate3d(-100%,0,0)',
          display: 'none'
        })
      ),
      transition('in => out', animate('100ms ease-in-out')),
      transition('out => in', animate('100ms ease-in-out'))
    ])
  ]
})
export class CostBreakdownFilterComponent implements OnInit, OnChanges, AfterViewInit {
  @Input() filterConfig: FilterInterface;
  @Input() dispatchEvent: string;
  @Output() radioChange = new EventEmitter();
  @Output() toggleFilter = new EventEmitter(); // Mobile & Tablet
  @ViewChildren(MatSelectionList) matSelectionLists: QueryList<MatSelectionList>;
  @ViewChildren(MatRadioGroup) matRadioGroups: QueryList<MatRadioGroup>;
  private defaultOptions = {
    items: []
  };
  private filterConfigClone: FilterInterface;
  _filterConfig: FilterInterface;
  myFocusTriggeringEventEmitter = new EventEmitter<boolean>();

  isSidenavOpened = false;
  sideNavMode: string;
  sideNavStatus: string;
  searchVal: string;
  searchValWhenFilterApplied: string;
  showClearLink: boolean;
  mobileViewPort = 992;
  ismobile: boolean;
  isAutoSearch: boolean;
  showClose: boolean;
  autoCompleteSearchArray: string[] = [];
  dateSelectedFilter: string;
  showCalender: boolean;
  showDate: boolean;
  fromMinDate: Date;
  calendarMaxDate = new Date();
  currentSelectedDate: Date = null;
  isCustomDateRangeInValid = false;
  isSelectedDateInvalid = false;
  lastDate: Date;
  fromDate: string;
  toDate: string = moment().format('L');
  dateFormat = 'MM/DD/YYYY';
  isFormDateSelected = true;
  errorMessage = null;
  defaultSort: FilterOptionInterface;

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    if (event.target.innerWidth <= this.mobileViewPort) {
      this.ismobile = true;
    } else {
      this.ismobile = false;
      this.sideNavStatus = 'in';
    }
  }

  constructor(private filterService: FilterService, private globalService: GlobalService) {
    if (window.innerWidth <= this.mobileViewPort) {
      this.ismobile = true;
    }
    this.sideNavStatus = this.ismobile ? 'out' : 'in';
  }

  ngOnInit() {
    this._filterConfig = Object.assign(this.defaultOptions, this.filterConfig);
    console.log(this.filterConfig, ' config item ');

    this.addAdditionalProp();
    this.filterConfigClone = JSON.parse(JSON.stringify(this.filterConfig));
    if (this._filterConfig.saveFilterState === true && this.globalService.filterState[this._filterConfig.filterStatePropName]) {
      this._filterConfig = this.globalService.filterState[this._filterConfig.filterStatePropName];
      this.searchVal = this._filterConfig['searchVal'];
      this.fromDate = this._filterConfig['fromDate'];
      this.toDate = this._filterConfig['toDate'];
    }
  }

  ngAfterViewInit() {}

  ngOnChanges(change) {
    setTimeout(() => {
      if (change.dispatchEvent) {
        if (change.dispatchEvent.currentValue === FilterComponentConstants.CLEAR) {
          this.clearFilterHandler();
        }
      }
    }, 1);
  }

  radioChangeHandler(selectedOption: MatRadioChange, index: number): void {
    if (this._filterConfig.items[index] && selectedOption) {
      const list = this._filterConfig.items[index].list;
      for (let i = 0; i < list.length; i++) {
        if (list[i].value === selectedOption.value) {
          list[i].selected = true;
        } else {
          list[i].selected = false;
        }
      }
    }
    this.radioChange.emit({
      selectedOption: selectedOption,
      filterItemNumber: index
    });
    this.closeFilter();
  }

  addAdditionalProp(): void {
    this._filterConfig.items = this._filterConfig.items.map((obj: FilterItemInterface) => {
      const selected = obj.list.filter((option: FilterOptionInterface) => option.selected === true);
      obj.model = selected[0] ? selected[0].value : '';
      if (obj.type === 'checkbox') {
        obj['selectedOptions'] = [];
      }
      if (obj.type === 'radio' && obj.sortBy === true) {
        this.defaultSort = obj.list.filter(item => {
          return item.selected === true;
        })[0];
      }
      return { ...obj };
    });
  }

  isOpened(index: number) {
    this._filterConfig.items[index].expanded = true;
  }

  isClosed(index: number) {
    this._filterConfig.items[index].expanded = false;
  }

  triggerChange(): void {
    this._filterConfig = Object.assign({}, this._filterConfig);
  }

  getSelections(): FilterSelectionItemInterface[] {
    const selectedArray: FilterSelectionItemInterface[] = [];
    if (this._filterConfig.items.length > 0) {
      this._filterConfig.items.forEach((item, index) => {
        if (item.type === 'radio') {
          if (item.list && item.list.length > 0) {
            let selectedRadioArray: any[] = [];
            selectedRadioArray = item.list.filter(option => option.selected === true);
            selectedArray.push({
              selectedOption: selectedRadioArray[0],
              filterItemNumber: index
            });
          } else {
            selectedArray.push({
              selectedOption: {
                text: '',
                value: '',
                selected: false,
                disabled: false
              },
              filterItemNumber: index
            });
          }
        }
      });
    }
    return selectedArray;
  }

  clearFilterList(fromSearch?: boolean) {
    this.matSelectionLists.forEach((selectionList: MatSelectionList) => {
      selectionList.deselectAll();
    });
    if (fromSearch && this._filterConfig.items.length > 0) {
      this._filterConfig.items.forEach((item, index) => {
        if (item.type === 'radio' || item.type === 'calendar') {
          if (!item.sortBy) {
            item.model = '';
            item.list.forEach(listItem => {
              listItem.selected = false;
            });
          } else {
            item.model = this.defaultSort ? this.defaultSort.value : '';
            item.list.forEach(listItem => {
              listItem.selected = false;
              if (listItem.value === item.model) {
                listItem.selected = true;
              }
            });
          }
        }
      });
      this._filterConfig = this._filterConfig;
    } else {
      this._filterConfig = JSON.parse(JSON.stringify(this.filterConfigClone));
    }
  }

  clearSearch(value: boolean = true) {
    this.searchVal = '';
    this.isAutoSearch = false;
    sessionStorage.removeItem('searchval');
  }

  closeFilter() {
    if (this.ismobile) {
      this.sideNavStatus = 'out';
      this.isSidenavOpened = false;
    }
  }

  closeSideNavigation() {
    this.isSidenavOpened = false;
  }

  setShowClearLink() {
    this.showClearLink = false;
    if (this._filterConfig.items.some(this.filterModelCheck)) {
      this.showClearLink = true;
    }
  }

  filterModelCheck(item: FilterItemInterface): boolean {
    return item.model !== null && item.model !== undefined;
  }

  clearFilterHandler() {
    this.closeFilter();
    this.clearFilterList();
    this.clearSearch();
    this.showClearLink = false;
    this.showClose = false;
    this.isCustomDateRangeInValid = false;
    this.showClose = false;
    this.filterService.scrollToTop();
  }

  toggleFilterHandler(toggleStatus: string) {
    this.isSidenavOpened = !this.isSidenavOpened;
    this.sideNavStatus = this.sideNavStatus === 'out' ? 'in' : 'out';
    if (toggleStatus) {
      this.sideNavStatus = toggleStatus;
    }
    if (window.innerWidth <= 992) {
      this.sideNavMode = 'over';
    } else {
      this.sideNavMode = 'side';
    }
    this.toggleFilter.emit({
      toggle: toggleStatus
    });
  }

  uniqueArray(array) {
    const j = {};
    array.forEach(function(item) {
      j[item + '::' + typeof item] = item;
    });
    return Object.keys(j).map(function(item) {
      return j[item];
    });
  }
}
