export class FooterGlobalModel {
  Title: string;
  Bcbslogo: string;
  BcbslogoUrl: string;
  FacebookIcon: string;
  FacebookUrl: string;
  TwitterIcon: string;
  TwitterUrl: string;
  LinkedInIcon: string;
  LinkedInUrl: string;
  YoutubeIcon: string;
  YoutubeUrl: string;
  AppstoreIcon: string;
  AppstoreUrl: string;
  GooglePlayIcon: string;
  GooglePlayUrl: string;
  FooterContent: string;
  FacebookBrandIcon: string;
  TwitterBrandIcon: string;
  LinkedInBrandIcon: string;
  YoutubeBrandIcon: string;
}
