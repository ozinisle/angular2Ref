export type PolarDataType = 'Yes' | 'No';
