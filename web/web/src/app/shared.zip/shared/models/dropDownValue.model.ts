export class DropDownValue {
  name: string;
  value: string;

  constructor(value: string, name: string) {
    this.name = name;
    this.value = value;
  }
}
