import { state } from '@angular/animations';
export class CommStatusModel {
    UserState: string;
    MemEmailAddress: string;
    IsVerifiedEmail: string;
    MemPhoneNumber: string;
    MemPhoneType: string;
    IsVerifiedMobile: string;
    EmailOptInStatus: string;
    MobileOptInStatus: string;
}
