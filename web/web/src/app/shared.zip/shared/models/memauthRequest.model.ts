export class MemauthRequest {
  accesscode = '';
  commChannel = '';
  commChannelType = '';
}
