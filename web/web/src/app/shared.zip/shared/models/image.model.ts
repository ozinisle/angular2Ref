export class Image {
    text: string;
    src: string;
    isVideo: boolean;
    VideoUrl: string;
    VIdeoUrl: string;
    urlLink: string;
    ArticleText: string;
    RegularImages: string;
    ArticleUrl: string;
    Title: string;
    TabletImage: string;
    MobileImages: string;
    mobilesrc: string;
    Body: string;
}

