export class updatestudentidModel {
  useridin: '';
  studentid: '';
}
