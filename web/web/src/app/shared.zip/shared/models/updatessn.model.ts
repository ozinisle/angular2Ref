export class updatessnModel {
  useridin: '';
  ssn: '';
}
