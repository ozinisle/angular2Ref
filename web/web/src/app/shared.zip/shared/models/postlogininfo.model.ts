export class PhoneNumber {
  text: string;
  number: string;
}
// tslint:disable-next-line: max-classes-per-file
export class PharmacyLink {
  text: string;
  url: string;
  img?: string;
}
// tslint:disable-next-line: max-classes-per-file
export class WellnessProgram {
  text: string;
  url: string;
}
// tslint:disable-next-line: max-classes-per-file
export class PostLoginInfo {
  hasCI: boolean;
  hasSS: boolean;
  hasSSO: boolean;
  isCPDPEnrolled: boolean;
  isCPDPHandedoff: boolean;
  isCPDPPromotion: boolean;
  isKYMember: boolean;
  showDemographicModel: boolean;
  phoneNumbers: PhoneNumber[];
  pharmacyLinks: PharmacyLink[];
  wellnessPrograms: WellnessProgram[];
  coverageEffecDt: string;

  constructor(response: any) {
    this.hasCI = response.hasCI;
    this.hasSS = response.hasSS;
    this.hasSSO = response.hasSSO;
    this.isCPDPEnrolled = response.isCPDPEnrolled;
    this.isCPDPHandedoff = response.isCPDPEnrolled;
    this.isCPDPPromotion = response.isCPDPPromotion;
    this.isKYMember = response.isKYMember;
    this.showDemographicModel = response.showDemographicModel;
    this.phoneNumbers = response.phoneNumbers;
    this.pharmacyLinks = response.pharmacyLinks;
    this.wellnessPrograms = response.wellnessPrograms;
    this.coverageEffecDt = response.coverageEffecDt;
  }
}
