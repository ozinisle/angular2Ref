export class MultiLingualFooterModel {
    Translation: string;
    IntlLanguage: string;
    Footertext: string;
}
export class GetVitalsDataUpdatesRequestModel {
    useridin: string;
}

export class GetVitalsDataUpdatesResponseModel {
    dataLoadedDate: string;
}

export class SessionFadDataUpdatesModel {
    dataLoadedDate: string;
    lastUpdateDate: string;
}
