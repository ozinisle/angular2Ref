export interface PWKVideo {
  poster: string;
  programID: string;
  stream: string;
}

export interface PWKStatus {
  medicareDocExists: boolean;
  medicareVideoExists: boolean;
  seenMedicarePDF: number;
  seenMedicareVideo: number;
  displaymessage?: string;
}
