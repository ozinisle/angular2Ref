export class LoginRequest {
  useridin = '';
  passwordin = '';
}
