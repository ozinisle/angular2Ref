export class ImpersonationRequest {
  imperPayload = '';
}
