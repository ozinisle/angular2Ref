export class rxOrderSummaryModel {
  yourMedicationsAmount: number;
  yourOtcsAmount: number;
  isOTCs: boolean;
  yourTotalAmount: number;
  shippingAmount: number;
  dispenserAmount: number;
  constructor(
    yourOtcsAmount: number,
    yourmedicationsamount: number,
    isotcs: boolean,
    yourtotalamount: number,
    shippingamount: number,
    dispenseamount: number
  ) {
    this.yourMedicationsAmount = yourmedicationsamount;
    this.yourOtcsAmount = yourOtcsAmount;
    this.isOTCs = isotcs;
    this.yourTotalAmount = yourtotalamount;
    this.shippingAmount = shippingamount;
    this.dispenserAmount = dispenseamount;
  }
}
