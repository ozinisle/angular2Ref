export class memberInfo {
  memberid: string;
  suffix: string;
}
