export class FooterLinkModel {
    title: string;
    absolute: string;
    enabled?: boolean;
  }
