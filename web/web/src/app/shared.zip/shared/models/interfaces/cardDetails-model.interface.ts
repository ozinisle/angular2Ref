export interface FamilyMember {
  memberName: string;
  isDependent: boolean;
  relationship: string;
  hasDependents: boolean;
  memberCards: MemberCard[];
}

export interface CardSlot {
  name: string;
  values: string[];
}

export interface MemberCard {
  cardType: string;
  templateId: string;
  cardSlots: CardSlot[];
}
export interface CardListResponse {
  cardList: FamilyMember[];
}
