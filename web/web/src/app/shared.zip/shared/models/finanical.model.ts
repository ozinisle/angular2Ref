import { LineChartOptionsInterface } from '../components/alegeus-line-chart/line-chart.interface';

export class TransactionInfo {
  amount: number;
  date: string;
  description: string;
  balance: number;
}

export class Finanical {
  acountNumber: string;
  PlanStartDate: string;
  PlanEndDate: string;
  chartOptions: LineChartOptionsInterface;
  Description: string;
  Type: string;
  isALGAccount = false;
  transactions: TransactionInfo[];
}
