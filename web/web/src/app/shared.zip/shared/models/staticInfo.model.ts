export interface StaticInfo {
  title: string;
  body: string;
}
