export class UpdateMemAuthInfoRequest {
  useridin = '';
  fname = '';
  lname = '';
  dob = '';
  email = '';
  mobile = '';
}
