import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router } from '@angular/router';
import { AlertService } from '../services/alert.service';

@Component({
  selector: 'app-alerts',
  templateUrl: './alerts.component.html',
  styleUrls: ['./alerts.component.scss']
})
export class AlertsComponent {
  @Input() scope: string;
  @Input() slot = '';
  @Output() callBack: EventEmitter<any> = new EventEmitter();

  constructor(private alertService: AlertService, private router: Router) {}

  get alert() {
    return this.alertService.getAlert(this.scope);
  }
  navigate(event: any) {
    if (event && event.target && event.target.dataset && event.target.dataset.routerLink) {
      this.router.navigateByUrl(event.target.dataset.routerLink);
    } else if (event.target.id === 'register') {
      this.router.navigateByUrl('/register');
    } else if (event.target.id === 'callback') {
      this.callBack.emit();
    }
  }
}
