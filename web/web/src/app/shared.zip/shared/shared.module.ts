import { ObserversModule } from '@angular/cdk/observers';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { MaterializeModule } from 'angular2-materialize';
import { TextMaskModule } from 'angular2-text-mask';
import { NgxMaskModule } from 'ngx-mask';
import { MaterialModule } from '../material.module';
import { CmsHeaderComponent } from '../pages/cms-interop/cms-header/cms-header.component';
import { FadTooltipComponent } from '../pages/fad/fad-tooltip/fad-tooltip.component';
import { TooltipService } from '../pages/fad/fad-tooltip/fad-tooltip.service';
// tslint:disable-next-line:max-line-length
import { SendProviderEmailInquiryConfirmationPopupComponent } from '../pages/fad/send-provider-email-inquiry-confirmation-popup/send-provider-email-inquiry-confirmation-popup.component';
import { SendProviderEmailInquiryComponent } from '../pages/fad/send-provider-email-inquiry/send-provider-email-inquiry.component';
import { MyDoctorsPcpService } from '../pages/mydoctors-pcp/mydoctors-pcp.service';
import { VerifyaccesscodeComponent } from '../pages/registration/verifyaccesscode/verifyaccesscode.component';
import { BreadcrumbsComponent } from '../shared/components/breadcrumbs/breadcrumbs.component';
import { AlertsComponent } from './alerts/alerts.component';
import { ControlMessagesComponent } from './app-control-messages/app-control-messages.component';
import { ChatComponent } from './chat/chat.component';
import { AboutMeModalComponent } from './components/about-me-modal/about-me-modal.component';
import { AboutMeModalService } from './components/about-me-modal/about-me-modal.service';
import { AlegeusLineChartComponent } from './components/alegeus-line-chart/line-chart.component';
import { AwardDetails } from './components/award-details/award-details.component';
import { Campaign2Component } from './components/campaign-2/campaign-2.component';
import { CostBreakdownFilterComponent } from './components/cost-breakdown-financialsfilter/filter.component';
import { DedcoFilterComponent } from './components/dedcofilter/dedco-filter.component';
import { DeductiblesComponent } from './components/deductibles/deductibles.component';
import { DocumentUploadComponent } from './components/document-upload/document-upload.component';
import { DragToScrollComponent } from './components/drag-to-scroll/drag-to-scroll.component';
import { DynamicPromotionalContentComponent } from './components/dynamic-promotional-content/dynamic-promotional-content.component';
import { EarnAndSaveRewardListComponent } from './components/earn-and-save-reward-list/earn-and-save-reward-list.component';
import { EarnAndSaveRewardModalComponent } from './components/earn-and-save-reward-modal/earn-and-save-reward-modal.component';
import { EarnAndSaveSavingsListComponent } from './components/earn-and-save-savings-list/earn-and-save-savings-list.component';
import { EarnAndSaveWidgetComponent } from './components/earn-and-save-widget/earn-and-save-widget.component';
import { EmailComponent } from './components/email/email.component';
import { FilterComponent } from './components/filter/filter.component';
import { FinancialChartComponent } from './components/financial-chart/line-chart.component';
import { FinancialsComponent } from './components/financials/financials.component';
import { FinancialFilterComponent } from './components/financialsfilter/filter.component';
import { FwModalComponent } from './components/fw-modal/fw-modal.component';
import { JumpScreenComponent } from './components/jump-screen/jump-screen.component';
import { LineChartComponent } from './components/line-chart/line-chart.component';
import { MyFinancialInfoComponent } from './components/my-financial-info/my-financial-info.component';
import { MyFinancialsComponent } from './components/my-financials-deductibles/my-financials-deductibles.component';
import { ProgramInformationComponent } from './components/program-information/program-information.component';
import { ProgressModalComponent } from './components/progress-modal/progress-modal.component';
import { PromoBlocksComponent } from './components/promo/promo-blocks/promo-blocks.component';
import { PromoCarouselComponent } from './components/promo/promo-carousel/promo-carousel.component';
import { PromoImagesComponent } from './components/promo/promo-images/promo-images.component';
import { PromosService } from './components/promo/promos.service';
import { RadialProgressComponent } from './components/radial-progress/radial-progress.component';
import { SelectPlanModalComponent } from './components/select-plan-modal/select-plan-modal.component';
import { SelectPlanModalService } from './components/select-plan-modal/select-plan-modal.service';
import { SelectedplanDetailsBarComponent } from './components/selectedplan-details-bar/selectedplan-details-bar.component';
import { ServiceFailureModalComponent } from './components/service-failure-modal/service-failure-modal.component';
import { SpinnerComponent } from './components/spinner/spinner.component';
import { StarRatingComponent } from './components/star-rating/star-rating.component';
import { VdkButtonComponent } from './components/vdk-button/vdk-button.component';
import { VdkHrComponent } from './components/vdk-hr/vdk-hr.component';
import { VdkTabBarComponent } from './components/vdk-tab-bar/vdk-tab-bar.component';
import { VdkTabButtonComponent } from './components/vdk-tab-button/vdk-tab-button.component';
import { VerifyEmailModalComponent } from './components/verify-email-modal/verify-email-modal.component';
import { VerifyEmailModalService } from './components/verify-email-modal/verify-email-modal.service';
import { DefaultlandingComponent } from './defaultlanding/defaultlanding.component';
import { AutofocusDirective } from './directives/autofocus.directive';
import { DateFormatValidation } from './directives/dateformatvalidation.directive';
import { drupalDirective } from './directives/drupal.directive';
import { FocusDirective } from './directives/focus.directive';
import { AppMatSelectChangeDirective } from './directives/mat-select-change.directive';
import { NoFirstPoundDirective } from './directives/no-first-pound.directive';
import { NumberOnlyDirective } from './directives/number-only.directive';
import { AuthCentralLayoutComponent } from './layouts/AuthCentralLayoutComponent/AuthCenralLayout.component';
import { AuthenticatedLayoutComponent } from './layouts/AuthenticatedLayoutComponent/AuthenticatedLayout.component';
import { EnrollHeaderComponent } from './layouts/enroll-header/enroll-header.component';
import { EnrollLayoutComponent } from './layouts/EnrollLayout/EnrollLayout.component';
import { FooterComponent } from './layouts/footer/footer.component';
import { FooterService } from './layouts/footer/footer.service';
import { FpoLayoutModule } from './layouts/FpoLayoutComponent/fpo-layout.module';
import { HeaderComponent } from './layouts/header/header.component';
import { InactiveHomePageFpoLayoutComponent } from './layouts/InactiveHomePageFpoLayoutComponent/inactive-homepage-fpo-layout.component';
import { OrderIdCardLayoutComponent } from './layouts/OrderIdCardLayoutComponent/OrderIdCardLayout.component';
import { UnauthenticatedLayoutComponent } from './layouts/UnauthenticatedLayoutComponent/UnauthenticatedLayout.component';
import { LogoDialogComponent } from './logo-dialog/logo-dialog.component';
import { MenuDialogComponent } from './menu-dialog/menu-dialog.component';
import { PasswordControlMessagesComponent } from './password-control-messages/password-control-messages.component';
import { AbsoluteNumberPipe } from './pipes/absolute-number/absolute-number.pipe';
import { AutoCompleteHighlightPipe } from './pipes/autoCompleteHighlight/autoCompleteHighlight.pipe';
import { CamelcasePipe } from './pipes/camelcase/camelcase.pipe';
import { CasingForFilterPipe } from './pipes/casingForFilter/casingForFilter.pipe';
import { ClaimidPipe } from './pipes/claimid/claimid.pipe';
import { CustomdatePipe, HomedatePipe } from './pipes/date/date.pipe';
import { YyyymmddTommddyyyyPipe } from './pipes/date/yyyymmdd-to-mmddyyyy.pipe';
import { FilterByCallbackPipe } from './pipes/filter/filterByCallback.pipe';
import { MatchTextHighlightPipe } from './pipes/match-text-highlight/match-text-highlight.pipe';
import { OrderPipe } from './pipes/order/order.pipe';
import { PhonePipe } from './pipes/phone/phone.pipe';
import { PhoneNumberPipe } from './pipes/phone/phoneNumber.pipe';
import { SafePipe } from './pipes/safe.pipe';
import { DoctorNameFormatter } from './pipes/stringUtilityPipes/doctor-name-formatter';
import { JoinPipe } from './pipes/stringUtilityPipes/join-pipe';
import { SplitPipe } from './pipes/stringUtilityPipes/split-pipe';
import { TrimPipe } from './pipes/stringUtilityPipes/trim-pipe';
import { AuthHttp } from './services/auth-http.service';
import { AuthService } from './services/auth.service';
import { BcbsmaHttpService } from './services/bcbsma-http.service';
import { BcbsmaerrorHandlerService } from './services/bcbsmaerror-handler.service';
import { ConstantsService } from './services/constants.service';
import { FpocontentService } from './services/fpocontent.service';
import { MyPillpackService } from './services/mypillpack/';
import { PreferencesService } from './services/myprofile/preferences.service';
import { StorageService } from './services/storage.service';
import { TimerService } from './services/timer.service';
import { ValidationService } from './services/validation.service';
import { SessionComponent } from './session/session.component';
import { AuthGuard } from './utils/auth.guard';
import { authHttpFactory } from './utils/authHttp.factory';
import { CdhGuard } from './utils/cdh.guard';
import { CostShareGuard } from './utils/cost-share.guard';
import { EarnAndSavePageGuard } from './utils/earn-and-save-page.guard';
import { GlobalUtils } from './utils/global.utils';
import { HasHadCoverageGuard } from './utils/has-had-coverage.guard';
import { ImpersonationLoginGuard } from './utils/impersonation-login.guard';
import { ImpersonationGuard } from './utils/impersonation.guard';
import { PillGuard } from './utils/pill.guard';
import { PlanAccessEntryGurad } from './utils/plan-access-entry.guard';
import { PlanAccessGuard } from './utils/plan-access.guard';
import { ScopeGuard } from './utils/scope.guard';
import { SubscriberGuard } from './utils/subscriber.guard';
import { VirtualVisitGuard } from './utils/virtual-visit.guard';
import { YesGuard } from './utils/yes.guard';
import { CampaignTelehealthComponent } from './components/campaign-telehealth/campaign-telehealth.component';
import { CampaignTelehealthSearchResultsComponent } from './components/campaign-telehealth-search-results/campaign-telehealth-search-results.component';

export { AlertService } from './services/alert.service';
export { ConstantsService, ValidationService, AuthService };

const CORE_ROUTER: Routes = [];

const angular = [CommonModule, FormsModule, MaterialModule, ObserversModule, ReactiveFormsModule];

const thirdParty = [MaterializeModule, NgxMaskModule, TextMaskModule, TranslateModule];

const declarations = [
  AboutMeModalComponent,
  AbsoluteNumberPipe,
  AlegeusLineChartComponent,
  AlertsComponent,
  AppMatSelectChangeDirective,
  AuthCentralLayoutComponent,
  AuthenticatedLayoutComponent,
  AutoCompleteHighlightPipe,
  AutofocusDirective,
  AwardDetails,
  BreadcrumbsComponent,
  CamelcasePipe,
  Campaign2Component,
  CasingForFilterPipe,
  ChatComponent,
  ClaimidPipe,
  CmsHeaderComponent,
  ControlMessagesComponent,
  CostBreakdownFilterComponent,
  CustomdatePipe,
  DateFormatValidation,
  DedcoFilterComponent,
  DeductiblesComponent,
  DefaultlandingComponent,
  DoctorNameFormatter,
  DocumentUploadComponent,
  DragToScrollComponent,
  drupalDirective,
  DynamicPromotionalContentComponent,
  EarnAndSaveRewardListComponent,
  EarnAndSaveRewardModalComponent,
  EarnAndSaveSavingsListComponent,
  EarnAndSaveWidgetComponent,
  EmailComponent,
  EnrollHeaderComponent,
  EnrollLayoutComponent,
  FadTooltipComponent,
  FilterByCallbackPipe,
  FilterComponent,
  FinancialChartComponent,
  FinancialFilterComponent,
  FinancialsComponent,
  FocusDirective,
  FooterComponent,
  FwModalComponent,
  HeaderComponent,
  HomedatePipe,
  InactiveHomePageFpoLayoutComponent,
  JoinPipe,
  JumpScreenComponent,
  LineChartComponent,
  LogoDialogComponent,
  MatchTextHighlightPipe,
  MenuDialogComponent,
  MyFinancialInfoComponent,
  MyFinancialsComponent,
  NoFirstPoundDirective,
  NumberOnlyDirective,
  OrderIdCardLayoutComponent,
  OrderPipe,
  PasswordControlMessagesComponent,
  PhoneNumberPipe,
  PhonePipe,
  ProgramInformationComponent,
  ProgressModalComponent,
  PromoBlocksComponent,
  PromoCarouselComponent,
  PromoImagesComponent,
  RadialProgressComponent,
  SafePipe,
  SelectedplanDetailsBarComponent,
  SelectPlanModalComponent,
  SendProviderEmailInquiryComponent,
  SendProviderEmailInquiryConfirmationPopupComponent,
  ServiceFailureModalComponent,
  SessionComponent,
  SpinnerComponent,
  SplitPipe,
  StarRatingComponent,
  TrimPipe,
  UnauthenticatedLayoutComponent,
  VdkButtonComponent,
  VdkHrComponent,
  VdkTabBarComponent,
  VdkTabButtonComponent,
  VerifyaccesscodeComponent,
  VerifyEmailModalComponent,
  YyyymmddTommddyyyyPipe,
  CampaignTelehealthComponent,
  CampaignTelehealthSearchResultsComponent
];

// prettier-ignore
@NgModule({
  imports: [
    ...angular,
    ...thirdParty,
    FpoLayoutModule,
    RouterModule.forChild(CORE_ROUTER),
  ],
  declarations: [
    ...declarations,
  ],
  exports: [
    ...angular,
    ...thirdParty,
    ...declarations,
  ],
  entryComponents: [
    AboutMeModalComponent,
    EarnAndSaveRewardModalComponent,
    JumpScreenComponent,
    SendProviderEmailInquiryComponent,
    SendProviderEmailInquiryConfirmationPopupComponent,
    ServiceFailureModalComponent,
    VerifyEmailModalComponent,
  ],
  providers: [
    {
      provide: AuthHttp,
      useFactory: authHttpFactory,
      deps: [HttpClient, AuthService, ConstantsService, AuthHttp]
    },
    AboutMeModalService,
    AuthGuard,
    AuthHttp,
    BcbsmaerrorHandlerService,
    BcbsmaHttpService,
    CdhGuard,
    ConstantsService,
    CostShareGuard,
    EarnAndSavePageGuard,
    FooterService,
    FpocontentService,
    GlobalUtils,
    HasHadCoverageGuard,
    ImpersonationGuard,
    ImpersonationLoginGuard,
    MyDoctorsPcpService,
    MyPillpackService,
    PillGuard,
    PlanAccessEntryGurad,
    PlanAccessGuard,
    PreferencesService,
    PromosService,
    ScopeGuard,
    SelectPlanModalService,
    StorageService,
    SubscriberGuard,
    TimerService,
    TooltipService,
    ValidationService,
    VerifyEmailModalService,
    VirtualVisitGuard,
    YesGuard,
  ],
})
export class SharedModule {}
