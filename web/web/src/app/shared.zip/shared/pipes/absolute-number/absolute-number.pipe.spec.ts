import { AbsoluteNumberPipe } from './absolute-number.pipe';

describe('AbsoluteNumberPipe', () => {
  it('create an instance', () => {
    const pipe = new AbsoluteNumberPipe();
    expect(pipe).toBeTruthy();
  });
  it('should return the same value passed if not an number', () => {
    const pipe = new AbsoluteNumberPipe();
    expect(pipe.transform("")).toBe("");
    expect(pipe.transform(undefined)).toBe(undefined);
  });
  it('should return the absolute value of an number', () => {
    const pipe = new AbsoluteNumberPipe();
    expect(pipe.transform("-2")).toBe(2);
    expect(pipe.transform(-10)).toBe(10);
  });
});
