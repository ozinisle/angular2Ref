import { Pipe, PipeTransform } from '@angular/core';
import { FadConstants } from '../../../pages/fad/constants/fad.constants';
import { BcbsmaConstants } from '../../constants/bcbsma.constants';

@Pipe({
  name: 'matchTextHighlight'
})
export class MatchTextHighlightPipe implements PipeTransform {
  constructor() {}

  transform(text: string, search): string {
    let resultText: string = text;
    try {
      if (search && search.replace) {
        let pattern = search.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, '\\$&');
        pattern = pattern
          .split(' ')
          .filter(t => {
            return t.length > 0;
          })
          .join('|');
        const regex: RegExp = new RegExp(pattern, 'gi');
        resultText =
          search && text ? resultText.replace(regex, match => `<span class='highlight-matching-text'>${match}</span>`) : resultText;
      }
    } catch (exception) {
      let detailedAppError = '';

      detailedAppError = `Error :: "${exception.message}" has occured in module >> "${BcbsmaConstants.modules.sharedModule}"
      - component >> "${FadConstants.pipes.matchTextHighlightPipe}"
      - method >> "${FadConstants.methods.getMatchHighlightedTextInPlanOption}"`;
      if (console && console.error) {
        console.error(detailedAppError);
      }
    } finally {
      return resultText;
    }
  }
}
