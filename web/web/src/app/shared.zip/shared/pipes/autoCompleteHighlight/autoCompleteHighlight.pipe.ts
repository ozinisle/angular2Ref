import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'autoCompleteHighlight'
})
export class AutoCompleteHighlightPipe implements PipeTransform {
  transform(value: string, matchStr?: string): string {
    if (!value || !matchStr) {
      return value;
    }

    return value.replace(new RegExp(matchStr, 'gi'), match => `<span>${match}</span>`);
  }
}
