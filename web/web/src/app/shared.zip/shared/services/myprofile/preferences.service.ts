import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable } from 'rxjs';
import { PREFERENCE_CONSTANTS } from '../../../pages/my-profile/profile-home.constants';
import { createParamObject, createUpdatePrefObject, updateConsentReqParam } from '../../../pages/preference-modal/preference.utils';
import { AlertType } from '../../alerts/alertType.model';
import { AlertService } from '../alert.service';
import { AuthHttp } from '../auth-http.service';
import { AuthService } from '../auth.service';
import { ConstantsService } from '../constants.service';
import { ProfileService } from './profile.service';

@Injectable()
export class PreferencesService {

  isChannelEditCancelledD = new BehaviorSubject<any>({
    channel: '',
    status: null
  });

  closeChannelEdit = new BehaviorSubject<any>({
    channel: '',
    status: null
  });

  isChannelEditSaved = new BehaviorSubject<any>({
    channel: '',
    status: null
  });

  userIdIn: '';
  phoneNumber: '';

  existingPreferenceSelected = [];
  newPreferenceSelected = [];

  constructor(
    private http: AuthHttp,
    private constants: ConstantsService,
    private authService: AuthService,
    private profileService: ProfileService,
    private alertService: AlertService,
    private router: Router
  ) {}

  isUnionBlueMember(): boolean {
    const postLoginInfo = sessionStorage.getItem('postLoginInfo');
    return postLoginInfo ? JSON.parse(postLoginInfo).isUnionBlueMember : false;
  }

  getProgramGroups(): Observable<any> {
    const request = {
      useridin: this.authService.useridin
    };
    return this.http
      .encryptPostJwt(this.constants.programgroups, request)
      .map(res => {
        return res;
      })
      .catch(err => {
        return err;
      });
  }
  getPreferences(): Observable<any> {
    const request = {
      useridin: this.authService.useridin
    };
    return this.http
      .encryptPostJwt(this.constants.preferences, request)
      .map(res => {
        this.http.hideSpinnerLoading();
        return res;
      })
      .catch(err => {
        return err;
      });
  }
  updatePreferences(data): Observable<any> {
    const request = {
      useridin: this.authService.useridin,
      preferences: data
    };
    return this.http
      .encryptPost(this.constants.updatepreferences, request)
      .map(res => {
        return res;
      })
      .catch(err => {
        return err;
      });
  }
  getConsent(): Observable<any> {
    const request = {
      useridin: this.authService.useridin
    };
    return this.http
      .encryptPost(this.constants.getconsent, request)
      .map(res => {
        // if(res) {
        //   res.modalFlag = "N"
        // }
        return res;
      })
      .catch(err => {
        return err;
      });
  }
  updateConsent(requestParam): Observable<any> {
    return this.http
      .encryptPost(this.constants.updateConsent, requestParam)
      .map(res => {
        return res;
      })
      .catch(err => {
        return err;
      });
  }

  setPreferencePromo(value?: boolean) {
    let fpoPreferenceUrl = null;
    const paperlessPromo = sessionStorage.getItem('paperlessPromo') ? JSON.parse(sessionStorage.getItem('paperlessPromo')) : value;
    if(paperlessPromo) {
      fpoPreferenceUrl = this.constants.drupalTestUrl + '/page/preference-center';
    this.profileService.preferencePromo(fpoPreferenceUrl);
  }
  }

  swapPromo() {
    if (sessionStorage.getItem('paperlessPromo')) {
      this.setPreferencePromo();
    } else {
      if (!sessionStorage.getItem('paperlessPromo')) {
        this.fetchPreference().subscribe(res => {
          if (res.result === -92914) {
            this.setPreferencePromo(true);
          } else {
            this.setPreferencePromo();
          }
        });
      }
    }
  }

  extractPreferenceObject(res) {
    let value;
    if (res.errormessage) {
      value = [];
    } else {
      if (res.message) {
        value = res.message.Preferences.filter(item => item.PreferenceType === 1 && item.FilterID === 'DOCS_PLAN_MAIL');
      } else {
        value = res.filter(item => item.PreferenceType === 1 && item.FilterID === 'DOCS_PLAN_MAIL');
      }
    }
    return value.length > 0;
  }

  fetchPreference() {
    return this.getPreferences().map(res => {
      sessionStorage.setItem('paperlessPromo', JSON.stringify(this.extractPreferenceObject(res)));
      return res;
    });
  }

  updatePreferenceInfo() {
    const consent = JSON.parse(sessionStorage.getItem('consentData'));
    const drupalConsent = sessionStorage.getItem('consentDrupalData') ? JSON.parse(sessionStorage.getItem('consentDrupalData')) : '';
    const programList = JSON.parse(sessionStorage.getItem('updatePrefData'));
    const prefCID = JSON.parse(sessionStorage.getItem('prefCID'));
    const lastModifiedDate = JSON.parse(sessionStorage.getItem('lastModifiedDate'));
    const lastUpdateType = JSON.parse(sessionStorage.getItem('lastUpdateType'));
    const showConsent = JSON.parse(sessionStorage.getItem('showConsent'));
    let consentData = {};
    if (consent.consentFlag !== 'Y' || showConsent) {
      consentData = {
        consentLanguageId: drupalConsent[0].Version,
        consentTS: new Date()
      };
    } else {
      consentData = consent;
    }
    const requiredParameters = createParamObject(this.http.sessionid(), consentData, lastModifiedDate, lastUpdateType, prefCID);
    const updatedPref = createUpdatePrefObject(programList, requiredParameters, showConsent);
    this.updatePreferences(updatedPref).subscribe(res => {
      if (res.result === 0) {
        this.userIdIn = JSON.parse(sessionStorage.memProfile).useridin;
        this.phoneNumber = JSON.parse(sessionStorage.memProfile).phoneNumber;
        if (this.existingPreferenceSelected.length !== 0 && this.newPreferenceSelected.length !== 0) {
          if (this.existingPreferenceSelected[0].channelID === 'SMS' &&
        this.newPreferenceSelected[0].channelID !== 'SMS') {
          this.eobOptOut().subscribe(response => {
            return response;
          })
        } else if (this.existingPreferenceSelected[0].channelID !== 'SMS' &&
          this.newPreferenceSelected[0].channelID === 'SMS') {
            this.eobOptIn().subscribe(response => {
              return response;
            });
          }
        }
        sessionStorage.setItem('paperlessPromo', JSON.stringify(this.extractPreferenceObject(updatedPref)));
        this.updateConsentInfo(consentData, showConsent);
        this.navigateToProfile(res);
      } else {
        this.navigateToProfile(res);
      }
      this.http.hideSpinnerLoading();
    });
  }

  eobOptIn(): Observable<any> {
    const key2id = this.authService.cryptoToken.key2id;
    const request: any = {
      "useridin": this.authService.useridin,
      "destinationPhoneNumber": this.phoneNumber,
      "params": {
        "messagingServiceSid": "TW_EOB_MESSAGING_SERVICE_SID",
        "body": "TW_EOB_OPT_IN_BODY",
      },
      "key2id": key2id
    }
    const uitxnid = "WEB_v3.0_" + this.http.uuid();
      return this.http
      .encryptPost(this.constants.sendsms, request, uitxnid)
      .map(res => {
        return res;
      })
      .catch(err => {
        return err;
      });
  }

  eobOptOut(): Observable<any> {
    const key2id = this.authService.cryptoToken.key2id;
    const request: any = {
      "useridin": this.authService.useridin,
      "destinationPhoneNumber": this.phoneNumber,
      "params": {
        "messagingServiceSid": "TW_EOB_MESSAGING_SERVICE_SID",
        "body": "TW_EOB_OPT_OUT_BODY",
      },
      "key2id": key2id
    };
    const uitxnid = "WEB_v3.0_" + this.http.uuid();
      return this.http
      .encryptPost(this.constants.sendsms, request, uitxnid)
      .map(res => {
        return res;
      })
      .catch(err => {
        return err;
      });
  }


  updateConsentInfo(consent, showConsent) {
    const drupalConsent = sessionStorage.getItem('consentDrupalData') ? JSON.parse(sessionStorage.getItem('consentDrupalData')) : consent;
    const reqParamater = updateConsentReqParam(this.authService.useridin, consent, drupalConsent[0], showConsent);
    this.updateConsent(reqParamater).subscribe(() => {
      sessionStorage.setItem('consentData', JSON.stringify(reqParamater));
    });
  }

  navigateToProfile(response) {
    const alertMsg = response.result === 0 ? PREFERENCE_CONSTANTS.successText : PREFERENCE_CONSTANTS.errorText;
    const alertType = response.result === 0 ? AlertType.Success : AlertType.Failure;
    this.router.navigate(['/myprofile']).then(() => {
      this.alertService.setAlert(alertMsg, '', alertType);
    });
    this.http.hideSpinnerLoading();
  }
}
