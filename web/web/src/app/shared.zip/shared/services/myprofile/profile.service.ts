import { Inject, Injectable } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { SESSION_STORAGE, StorageService } from 'angular-webstorage-service';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { ArticleModel } from '../../../pages/landing/landing.model';
import {
  GetDemographicInfoRequestModel,
  GetDemographicInfoResponseModel
} from '../../../pages/my-profile/models/get-demographic-info.model';
import {
  GetMemberProfileRequestModel,
  GetMemberProfileResponseModel
} from '../../../pages/my-profile/models/get-member-profile-request.model';
import { BaseProfilesRequestModelInterface } from '../../../pages/my-profile/models/interfaces/member-profile-generics.interface';
import { MemberProfileGenericResponseModel } from '../../../pages/my-profile/models/member-profile-generics.model';
import {
  UpdateAddressProfileRequestModel,
  UpdateEmailProfileRequestModel,
  UpdateHandAProfileRequestModel,
  UpdateHealthInfoProfileRequestModel,
  UpdateMemberProfileRequestModel,
  UpdateMemberProfileResponseModel,
  UpdatePhoneProfileRequestModel
} from '../../../pages/my-profile/models/update-member-profile.model';
import { AuthHttp } from '../auth-http.service';
import { AuthService } from '../auth.service';
import { ConstantsService } from '../constants.service';

@Injectable()
export class ProfileService {
  private profileSubject: BehaviorSubject<GetMemberProfileResponseModel> = new BehaviorSubject(this.storage.get('memProfile'));
  private shiftKeyDown = false;

  /**
   * Whether the current user is the primary subscriber of their health plan
   * (i.e., not a spouse or dependent), as an Observable that emits whenever
   * the known status is updated.
   *
   * Note: This is a _hot_ Observable -- use rxjs operator take(1)
   * if you only need the current value.
   */
  public get isSubscriber$(): Observable<boolean> {
    return this.profile$.map(profile => {
      return profile && profile.memberSuffix === '00';
    });
  }

  /**
   * The current user's profile, as an Observable that emits whenever the profile
   * is updated.
   *
   * Note: This is a _hot_ Observable -- use rxjs operator take(1)
   * if you only need the current value.
   */
  public get profile$(): Observable<GetMemberProfileResponseModel | null> {
    return this.profileSubject.asObservable();
  }

  // used in medication.component.ts by pillpack
  public maskedVerify = '';

  private profileDataChange = new BehaviorSubject<any>(null);
  public profileDataChange$ = this.profileDataChange;

  private article1Subject: BehaviorSubject<ArticleModel>;
  public article1$: Observable<ArticleModel>;
  public articles: any;
  public showRELAfterPrefModal = false;

  preferenceData = {
    emailSelected: false,
    phoneSelected: false,
    selectedPreferences: null
  };

  constructor(
    private http: AuthHttp,
    private constants: ConstantsService,
    public authService: AuthService,
    private sanitizer: DomSanitizer,
    @Inject(SESSION_STORAGE) private storage: StorageService
  ) {
    this.article1Subject = new BehaviorSubject(new ArticleModel(1));
    this.article1$ = this.article1Subject.asObservable();
    this.articles = [];
    this.articles.push(this.article1$);
  }

  private modifyScopeDataInRequest(request: BaseProfilesRequestModelInterface): BaseProfilesRequestModelInterface {
    request.scope = this.deriveShortScopeNameForRealScope(request.scope);
    return request;
  }

  // https://documenter.getpostman.com/view/2915912/RWTrMbWj#6bedc4f3-42b0-4635-b6b4-3a5168528517

  getUserRole() {
    return this.authService.authToken.scopename;
  }

  getcommStatus(): any {
    const request = {
      useridin: this.authService.useridin
    };
    return this.http.encryptPost(this.constants.getCommPreferenceUrl, request, null, null, false);
  }

  getProfile() {
    return this.storage.get('memProfile');
  }

  setProfile(profile: GetMemberProfileResponseModel) {
    this.profileSubject.next(profile);
    this.storage.set('memProfile', profile);
  }

  fetchProfileInfo(): Observable<GetMemberProfileResponseModel> {
    const request: GetMemberProfileRequestModel = new GetMemberProfileRequestModel();
    request.useridin = this.authService.useridin;
    console.log('fetcg profile', request);
    return this.http
      .post(this.constants.getmemprofile, this.http.handleRequest(request))
      .map(res1 => this.http.handleDecryptedResponse(res1))
      .flatMap(res => {
        if (!(res as GetMemberProfileResponseModel).useridin) {
          const errorRsp: MemberProfileGenericResponseModel = res as MemberProfileGenericResponseModel;
          throw new Error(errorRsp.displaymessage);
        }
        this.setProfile(res as GetMemberProfileResponseModel);
        return Observable.of(res as GetMemberProfileResponseModel);
      });
  }

  updateProfileWithShopperFlag(shoppingData: string) {
    const request = {
      useridin: this.authService.useridin,
      shoppingData: shoppingData
    };
    return this.http.post(this.constants.updatememprofile, this.http.handleRequest(request)) as Observable<any>;
  }

  fetchProfileInfoV2(): Observable<any> {
    const request: GetMemberProfileRequestModel = new GetMemberProfileRequestModel();
    request.useridin = this.authService.useridin;
    console.log('fetch profile', request);
    return this.http
      .post(this.constants.getmemprofile2, this.http.handleRequest(request))
      .map(res1 => this.http.handleDecryptedResponse(res1))
      .flatMap(res => {
        if (!(res as any).useridin) {
          const errorRsp: MemberProfileGenericResponseModel = res as MemberProfileGenericResponseModel;
          throw new Error(errorRsp.displaymessage);
        }
        this.setProfile(res as any);
        return Observable.of(res as any);
      });
  }
  updateProfile2(obj) {
    obj.useridin = this.authService.useridin;
    return this.http.post(this.constants.updatememprofile, this.http.handleRequest(obj)) as Observable<any>;
  }

  updateProfile(
    updateProfileObj,
    editAddress,
    editEmail,
    editPhone,
    editHint,
    editHealthInfo = false
  ): Observable<UpdateMemberProfileResponseModel> {
    const updateHandAProfileRequestModel = new UpdateHandAProfileRequestModel();
    const updateEmailProfileRequestModel = new UpdateEmailProfileRequestModel();
    const updatePhoneProfileRequestModel = new UpdatePhoneProfileRequestModel();
    const updateAddressProfileRequestModel = new UpdateAddressProfileRequestModel();
    const updateHealthInfoProfileRequestModel = new UpdateHealthInfoProfileRequestModel();

    // do data massaging:
    if (editAddress) {
      this.updateProfile2(updateProfileObj);
    }
    if (editEmail) {
      updateEmailProfileRequestModel.useridin = updateProfileObj.useridin;
      updateEmailProfileRequestModel.emailAddress = updateProfileObj.emailAddress;

      return this.http.post(this.constants.updatememprofile, this.http.handleRequest(updateEmailProfileRequestModel)) as Observable<
        UpdateMemberProfileResponseModel
      >;
    }
    if (editPhone) {
      updatePhoneProfileRequestModel.useridin = updateProfileObj.useridin;
      updatePhoneProfileRequestModel.phoneNumber = updateProfileObj.phoneNumber;
      updatePhoneProfileRequestModel.phoneType = updateProfileObj.phoneType;

      return this.http.post(this.constants.updatememprofile, this.http.handleRequest(updatePhoneProfileRequestModel)) as Observable<
        UpdateMemberProfileResponseModel
      >;
    }
    if (editHint) {
      updateHandAProfileRequestModel.useridin = updateProfileObj.useridin;
      updateHandAProfileRequestModel.hintAnswer = updateProfileObj.hintAnswer;
      updateHandAProfileRequestModel.hintQuestion = updateProfileObj.hintQuestion;

      return this.http.post(this.constants.updatememprofile, this.http.handleRequest(updateHandAProfileRequestModel)) as Observable<
        UpdateMemberProfileResponseModel
      >;
    }

    if (editHealthInfo) {
      updateHealthInfoProfileRequestModel.useridin = updateProfileObj.useridin;
      updateHealthInfoProfileRequestModel.allergies = updateProfileObj.health.allergies + '';
      updateHealthInfoProfileRequestModel.conditions = updateProfileObj.health.conditions + '';
      return this.http.post(this.constants.updatememprofile, this.http.handleRequest(updateHealthInfoProfileRequestModel)) as Observable<
        UpdateMemberProfileResponseModel
      >;
    }
  }

  getDemoGraphicInfo(): Observable<GetDemographicInfoResponseModel> {
    const request: GetDemographicInfoRequestModel = new GetDemographicInfoRequestModel();
    request.useridin = this.profileSubject.value.useridin;

    return this.http
      .post(this.constants.getDemoGraphicInfo, this.http.handleRequest(request))
      .map(encryptedResp => {
        return this.http.handleDecryptedResponse(encryptedResp);
      })
      .flatMap(demographicInfoResponse => {
        if (!(demographicInfoResponse as GetDemographicInfoResponseModel).raceList) {
          const errorRsp: MemberProfileGenericResponseModel = demographicInfoResponse as MemberProfileGenericResponseModel;
          throw new Error(errorRsp.errormessage);
        }
        return Observable.of(demographicInfoResponse as GetDemographicInfoResponseModel);
      });
  }

  updateDemographicInfo(demographicInfoRequest: any): Observable<GetDemographicInfoResponseModel> {
    return this.http.post(this.constants.updateDemographicInfoUrl, this.http.handleRequest(demographicInfoRequest)) as Observable<
      GetDemographicInfoResponseModel
    >;
  }

  updatePassword(request): Observable<UpdateMemberProfileResponseModel> {
    let updatePasswordReq: UpdateMemberProfileRequestModel;
    updatePasswordReq = Object.assign(request, {
      useridin: this.authService.useridin,
      userState: this.authService.authToken.scopename
    });
    // commented this as this is not avail in swagger..
    // key2id: this.authService.cryptoToken.key2id
    return this.http.post(this.constants.changepassword, this.http.handleRequest(updatePasswordReq)) as Observable<
      UpdateMemberProfileResponseModel
    >;
  }

  verifyAccessCode(request) {
    const generatedRequest = {
      ...request,
      useridin: this.authService.useridin,
      key2id: this.authService.cryptoToken.key2id
    };
    return this.http.post(this.constants.verifyResetUrl, this.http.handleRequest(generatedRequest));
  }

  VerifyAccessCode(accesscode, commChannelType, commChannel) {
    const generatedRequest = {
      useridin: this.authService.useridin,
      commChannel: commChannel,
      commChannelType: commChannelType,
      userIDToVerify: this.authService.useridin,
      accesscode: accesscode
    };

    return this.http.post(this.constants.verifyAccessCodeUrl, this.http.handleRequest(generatedRequest));
  }

  VerifyCommChlAccCode(accesscode, email, mobile) {
    const generatedRequest = {
      useridin: this.authService.useridin,
      email: email,
      mobile: mobile,
      userIDToVerify: this.authService.useridin,
      accesscode: accesscode
    };

    return this.http.post(this.constants.verfiyCommChlAccesscode, this.http.handleRequest(generatedRequest));
  }

  sendaccesscode(commChannelType, commChannel) {
    const request = {
      useridin: this.authService.useridin,
      commChannel: commChannel,
      commChannelType: commChannelType,
      userIDToVerify: this.authService.useridin
    };
    return this.http.post(this.constants.sendaccesscodeUrl, this.http.handleRequest(request));
  }

  sendcommchlaccesscode(email, mobile) {
    const request = {
      useridin: this.authService.useridin,
      email: email,
      mobile: mobile,
      userIDToVerify: this.authService.useridin
    };
    return this.http.post(this.constants.sendCommChlAccesscode, this.http.handleRequest(request));
  }

  public deriveShortScopeNameForRealScope(scope): string {
    const shortScope = {
      'REGISTERED-AND-VERIFIED': 'RV',
      'AUTHENTICATED-NOT-VERIFIED': 'ANV',
      'AUTHENTICATED-AND-VERIFIED': 'AV'
    };
    return shortScope[scope];
  }

  public updateCommChannel(updateCommChannelReqParams) {
    return this.http.post(this.constants.updatememprofile, this.http.handleRequest(updateCommChannelReqParams)) as Observable<
      UpdateMemberProfileResponseModel
    >;
  }

  sendUpdateNotification(request) {
    return this.http.post(this.constants.sendUpdateNotification, this.http.handleRequest(request));
  }

  maskPhoneNumber(userId: string): string {
    const regex = /^(.{3})(.{3})(.{4})(.*)/;
    let maskedUserId = userId
      ? userId.replace(/^(.*)(.{4})$/, (_, digitsToMasked, lastFourDigits) => {
          return `${digitsToMasked.replace(/./g, '*')}${lastFourDigits}`;
        })
      : userId;
    const str = maskedUserId;
    const subst = `$1-$2-$3`;
    maskedUserId = str.replace(regex, subst);
    return maskedUserId;
  }

  maskEmailId(userId: string): string {
    const maskedUserId = userId
      ? userId.replace(/^(.{3})(.*)(@.*)$/, (_, firstCharacter, charToMasked, domain) => {
          return `${firstCharacter}${charToMasked.replace(/./g, '*')}${domain}`;
        })
      : userId;
    return maskedUserId;
  }

  initiateUpdateProfile() {
    this.profileDataChange.next(new Date().toString());
  }

  onKeyDown(event) {
    // @purpose
    // onkey up event does not fire up for shift key in chrome alone
    // hence this work around is necessary
    // Fix for KLO-180
    if (event.keyCode === 16) {
      // if shift key is pressed block it
      this.shiftKeyDown = true;
    }
    if (this.shiftKeyDown || !this.isValidKeyPressed(event)) {
      return false;
    }
  }

  onKeyUp(event, previousElement, nextElement) {
    if (this.shiftKeyDown) {
      if (event.keyCode === 16) {
        this.shiftKeyDown = false;
      }
      return false;
    }
    if (event && event.target['value'] === '' && !this.isValidKeyPressed(event)) {
      return false;
    }
    if ((event.key === 'Backspace' || event.which === 37 || event.key === 'ArrowLeft') && previousElement) {
      previousElement.focus();
    }
    if (
      (event.key === 'ArrowRight' ||
        event.which === 39 ||
        (event.which >= 48 && event.which <= 57) ||
        (event.which >= 96 && event.which <= 105)) &&
      nextElement
    ) {
      setTimeout(() => nextElement.focus(), 100);
    }
  }

  private isValidKeyPressed(event): boolean {
    const key = event.key;
    return key === 'Backspace' ||
      key === 'ArrowLeft' ||
      key === 'ArrowRight' ||
      (event.keyCode >= 48 && event.keyCode <= 57) ||
      (event.keyCode >= 96 && event.keyCode <= 105)
      ? true
      : false;
  }

  preferencePromo(url) {
    this.http.get(url).subscribe(item => {
      this[`article1Subject`].next(new ArticleModel(1).deserialize(item[0], this.sanitizer));
      this.http.hideSpinnerLoading();
    });
  }

  notifyDemographicsModelDisplayed() {
    const payload = {
      useridin: this.authService.useridin
    };
    return this.http.encryptPost(this.constants.notifydemographicsmodeldisplayed, payload);
  }
}
