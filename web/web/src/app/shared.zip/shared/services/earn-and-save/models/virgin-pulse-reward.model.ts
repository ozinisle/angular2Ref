import { Reward } from './reward.model';
import { VirginPulseRewardTransaction } from './virgin-pulse-reward-transaction.model';

export interface VirginPulseReward extends Reward {
  source: 'VP';
  quarter: 1 | 2 | 3 | 4;
  numberOfLevels: number;
  transactions?: VirginPulseRewardTransaction[];
}

/**
 * A type guard for VirginPulseReward.
 */
export function isVirginPulseReward(obj: any): obj is VirginPulseReward {
  return !!obj && (obj as VirginPulseReward).source === 'VP';
}
