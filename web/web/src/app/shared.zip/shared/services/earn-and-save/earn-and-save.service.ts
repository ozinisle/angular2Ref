import { HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { combineLatest } from 'rxjs/observable/combineLatest';
import { of } from 'rxjs/observable/of';
import { environment } from '../../../../environments/environment';
import { CdhGuard } from '../../utils/cdh.guard';
import { HasHadCoverageGuard } from '../../utils/has-had-coverage.guard';
import { AuthHttp } from '../auth-http.service';
import { AuthService } from '../auth.service';
import { ProfileService } from '../myprofile/profile.service';
import { EarnAndSaveMockService } from './earn-and-save-mock.service';
import { FetchRewardsResponse } from './models/fetch-rewards-response.model';
import { SimpleReward } from './models/simple-reward.model';

@Injectable()
export class EarnAndSaveService extends EarnAndSaveMockService {
  private apiResponse$: Observable<FetchRewardsResponse>;
  private refreshRewardsSubject: BehaviorSubject<boolean> = new BehaviorSubject(true);
  private useridin$ = this.authService.authToken$.map(() => this.authService.useridin).distinctUntilChanged();

  /**
   * Whether the "Earn and Save" widget should be shown for the current user.
   * Defaults to ```false``` if we don't yet have enough information to
   * know for sure.
   *
   * Note: This is a _hot_ Observable -- use rxjs operator take(1)
   * if you only need the current value.
   */
  public isEarnAndSaveWidgetEnabledForCurrentUser$: Observable<boolean>;

  /**
   * Whether the "Maximize Plan" widget should be shown for the current user.
   * Defaults to ```false``` if we don't yet have enough information to
   * know for sure.
   *
   * Note: This is a _hot_ Observable -- use rxjs operator take(1)
   * if you only need the current value.
   */
  public isMaximizePlanWidgetEnabledForCurrentUser$: Observable<boolean>;

  constructor(
    private authHttp: AuthHttp,
    private authService: AuthService,
    private cdhGuard: CdhGuard,
    private hasHadCoverageGuard: HasHadCoverageGuard,
    private profileService: ProfileService
  ) {
    super();

    this.apiResponse$ = combineLatest([this.useridin$, this.refreshRewardsSubject])
      .filter(([useridin, refresh]) => !!useridin)
      .switchMap(() => {
        const options = {
          headers: new HttpHeaders({
            Authorization: `Bearer ${this.authService.getAuthToken()}`,
            uitxnid: 'WEB_v3.0_' + this.authHttp.uuid()
          })
        };
        return this.authHttp.get<FetchRewardsResponse>(environment.rewardsServiceUrl, options, true);
      })
      .map(result => {
        if (((result as any) as { error: any }).error) {
          return null;
        } else {
          return result;
        }
      })
      .shareReplay(1);

    this.isEarnAndSaveWidgetEnabledForCurrentUser$ = combineLatest([
      of(environment.enableNewPersonalizedHub),
      this.cdhGuard.isCdhPlanMember$,
      this.hasHadCoverageGuard.hasHadCoverage$,
      this.profileService.isSubscriber$
    ])
      .map(([isFeatureEnabled, isCdhPlanMember, hasHadCoverage, isSubscriber]) => {
        return isFeatureEnabled && isCdhPlanMember && hasHadCoverage && isSubscriber;
      })
      .startWith(false);

    this.isMaximizePlanWidgetEnabledForCurrentUser$ = combineLatest([
      of(environment.enableNewPersonalizedHub),
      this.cdhGuard.isCdhPlanMember$,
      this.hasHadCoverageGuard.hasHadCoverage$
    ])
      .map(([isFeatureEnabled, hasHadCoverage, isSubscriber]) => {
        return isFeatureEnabled && hasHadCoverage && isSubscriber;
      })
      .startWith(false);
  }

  fetchRewards(): Observable<SimpleReward[]> {
    return super.fetchRewards();
  }

  fetchRewardsRaw(): Observable<FetchRewardsResponse> {
    return this.apiResponse$;
  }

  refreshRewards() {
    this.refreshRewardsSubject.next(true);
  }
}
