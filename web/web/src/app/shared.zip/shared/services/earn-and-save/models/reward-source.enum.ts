export enum RewardSource {
  BCBSMA = 'BCBSMA',
  VIRGIN_PULSE = 'VP',
  HEQ = 'HEQ'
}
