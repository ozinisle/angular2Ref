export interface RewardTransaction {
  id: string | number;
  amount: number;
  status: 'COMPLETED' | 'TERMED' | 'FAILED';
  earnedDate: string;
  depositDate?: string;
}
