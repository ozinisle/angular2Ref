import { CouponReward } from './coupon-reward.model';
import { Reward } from './reward.model';
import { VirginPulseReward } from './virgin-pulse-reward.model';

export interface FetchRewardsResponse {
  member: {
    id: string;
    mdmId: string;
    subNum: string;
    firstName: string;
    lastName: string;
    accountType: string;
  };
  incentives: (Reward | VirginPulseReward | CouponReward)[];
}
