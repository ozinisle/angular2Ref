import { RewardTransaction } from './reward-transaction.model';
import { VirginPulseRewardLevel } from './virgin-pulse-reward-level.model';

export interface VirginPulseRewardTransaction extends RewardTransaction {
  levelDetails: VirginPulseRewardLevel;
}
