import { Observable } from 'rxjs';
import { FetchRewardsResponse } from './fetch-rewards-response.model';
import { SimpleReward } from './simple-reward.model';

export interface EarnAndSaveServiceContract {
  /**
   * Whether the "Earn and Save" widget should be shown for the current user.
   */
  isEarnAndSaveWidgetEnabledForCurrentUser$: Observable<boolean>;

  /**
   * Whether the "Maximize Plan" widget should be shown for the current user.
   */
  isMaximizePlanWidgetEnabledForCurrentUser$: Observable<boolean>;

  /**
   * Simplification of the rewards API to only return what the UI needs.
   */
  fetchRewards(whichYear: number): Observable<SimpleReward[]>;

  /**
   * Returns an unprocessed response from the rewards API.
   */
  fetchRewardsRaw(whichYear: number): Observable<FetchRewardsResponse>;
}
