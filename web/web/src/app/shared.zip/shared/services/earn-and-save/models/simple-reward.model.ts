import { RewardCode } from './reward-code.enum';
import { RewardSource } from './reward-source.enum';
import { SimpleRewardStatus } from './simple-reward-status.enum';

/**
 * Simplified version of data from the rewards API.
 */
export interface SimpleReward {
  /**
   * A unique code for the reward.
   */
  code: RewardCode;

  /**
   * A unique code for the organization associated with the reward.
   */
  source: RewardSource;

  /**
   * Enumerable status of the reward.
   */
  status: SimpleRewardStatus;

  /**
   * The year in which the reward may be earned.
   */
  year: number;

  /**
   * The year's quarter in which the reward may be earned.
   */
  quarter?: 1 | 2 | 3 | 4;

  /**
   * The date on and after which the reward can be earned.
   */
  enabledOn?: Date;

  /**
   * The time (if any) at which the reward was completed.
   */
  completedAt?: Date;

  /**
   * The amount of the reward that the user has earned (in USD).
   */
  earnedAmount: number;

  /**
   * The maximum amount earnable for the reward (in USD).
   */
  maxAmount: number;

  /**
   * The user's progress towards earning the full reward.
   *
   * For Virgin Pulse rewards, this should be calculated based on "level"
   * progress (which is based on "points"):
   *
   * ```
   * ([level 1 %] + [level 2 %] + [level 3 %] + [level 4 %]) * .25
   * ```
   *
   * For all other rewards, this should be calculated based on dollars:
   *
   * ```
   * (earnedAmount / maxAmount) * 100
   * ```
   */
  progressPercent: number;
}
