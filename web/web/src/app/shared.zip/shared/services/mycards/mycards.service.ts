import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { GetMemBasicInfoRequestModel, GetMemBasicInfoResponseModel } from '../../../pages/medications/models/get-member-basic-info.model';
import {
  GetMemBasicInfoRequestModelInterface,
  GetMemBasicInfoResponseModelInterface
} from '../../../pages/medications/models/interfaces/get-member-basic-info-model.interface';
import { AuthHttp } from '../auth-http.service';
import { AuthService } from '../../shared.module';
import { ConstantsService } from '../constants.service';
import { forkJoin } from 'rxjs/observable/forkJoin';

@Injectable()
export class MyCardsService {
  constructor(private http: AuthHttp, private authService: AuthService, private constants: ConstantsService) {}

  getMemberFrontData$() {
    const request = {
      useridin: this.authService.useridin
    };
    return this.http.encryptPost(this.constants.cardFrontFamily, request).map(response => {
      if (response.result < 0) {
        return response;
      } else {
        if (response && response.error !== true) {
          if (response['fault'] && response['fault'].faultstring) {
            return;
          } else if (response && response['ROWSET'] && response['ROWSET'].totRows <= 1) {
            return [response['ROWSET'].ROWS];
          } else if (response && response['ROWSET']) {
            return response['ROWSET'].ROWS;
          }
        }
      }
    });
  }

  getMemBasicInfo(): Observable<GetMemBasicInfoResponseModelInterface> {
    if (this.authService.basicMemInfo) {
      return Observable.of(this.authService.basicMemInfo);
    }
    const request: GetMemBasicInfoRequestModelInterface = new GetMemBasicInfoRequestModel();
    request.useridin = this.authService.useridin;

    return this.http.encryptPost(this.constants.getMemBasicInfoUrl, request).map(response => {
      if (response.result < 0) {
        return new GetMemBasicInfoResponseModel();
      } else {
        const basicInfo = new GetMemBasicInfoResponseModel();
        basicInfo.rxSummary = response.getMemBasicInfoResponse;
        this.authService.basicMemInfo = basicInfo;
        return basicInfo as GetMemBasicInfoResponseModel;
      }
    });
  }

  getDependents$() {
    const request = {
      useridin: this.authService.useridin
    };
    return this.http.encryptPost(this.constants.dependentsUrl, request).map(response => {
      console.log('@@', response);
      return response;
    });
  }
  getDependentFrontData$(sDepID) {
    const request = {
      useridin: this.authService.useridin,
      depid: sDepID
    };
    return this.http.encryptPost(this.constants.depedentFrontUrl, request).map(response => {
      if (response.type !== 'error') {
        if (response['fault'] && response['fault'].faultstring) {
          return;
        } else if (response && response['ROWSET'].totRows <= 1) {
          return [response['ROWSET'].ROWS];
        } else if (response && response['ROWSET']) {
          return response['ROWSET'].ROWS;
        }
      }
    });
  }
  getDependentBackData$(sDepId) {
    const request = {
      useridin: this.authService.useridin,
      depid: sDepId
    };
    return this.http.encryptPost(this.constants.depedentBackUrl, request).map(response => {
      if (response.type !== 'error') {
        if (response['fault'] && response['fault'].faultstring) {
          return;
        } else if (response && response['ROWSET'].totRows <= 1) {
          return [response['ROWSET'].ROWS];
        } else if (response && response['ROWSET']) {
          return response['ROWSET'].ROWS;
        }
      }
    });
  }

  getMemberBackData$() {
    const request = {
      useridin: this.authService.useridin
    };
    return this.http.encryptPost(this.constants.cardbackUrl, request).map(response => {
      if (response.result < 0) {
        return response;
      } else {
        if (response && response.error !== true) {
          if (response['fault'] && response['fault'].faultstring) {
            return;
          } else if (response && response['ROWSET'] && response['ROWSET'].totRows <= 1) {
            return [response['ROWSET'].ROWS];
          } else if (response && response['ROWSET']) {
            return response['ROWSET'].ROWS;
          }
        }
      }
    });
  }

  wrapText(context: any, text: string, x: number, y: number, maxWidth: number, lineHeight: number) {
    const words = text.split(' ');
    let line = '';

    for (let n = 0; n < words.length; n++) {
      const testLine = line + words[n] + ' ';
      const metrics = context.measureText(testLine);
      const testWidth = metrics.width;
      if (testWidth > maxWidth && n > 0) {
        context.fillText(line, x, y);
        line = words[n] + ' ';
        y += lineHeight;
      } else {
        line = testLine;
      }
    }
    context.fillText(line, x, y);
  }

  removeLeadingJunkChar(val) {
    if (val && val.length > 0 && val.charCodeAt(0) === 127) {
      val = val.substring(1, val.length);
    }
    return val;
  }

  getCardsInfo(): Observable<any> {
    const request = {
      useridin: this.authService.useridin
    };

    return forkJoin([this.http.encryptPost(this.constants.getFamilyCards, request), this.getMemBasicInfo()]);
  }

  postPdfCardsInfo(postObject): Observable<any> {
    postObject.useridin = this.authService.useridin;
    return this.http.encryptPost(this.constants.postCardImageToPDF, postObject);
  }
}
