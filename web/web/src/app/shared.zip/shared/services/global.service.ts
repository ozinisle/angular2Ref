import { DatePipe } from '@angular/common';
import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { Router } from '@angular/router';
import * as moment from 'moment';
import * as momenttz from 'moment-timezone';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError } from 'rxjs/operators';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import { environment } from '../../../environments/environment';
import { BenefitSearchResultResponse } from '../../pages/benefit-search/model/benefit-search-result-item.model';
import { HomePageInfoModel } from '../../pages/landing/landing.model';
import { AlertType } from '../alerts/alertType.model';
import { MemberInfo } from '../models/memberInfo.model';
import { RegType } from '../models/regType.enum';
import { AlertService } from './alert.service';
import { AuthHttp } from './auth-http.service';
import { AuthService } from './auth.service';
import { ConstantsService } from './constants.service';
import { DependantsService } from './dependant.service';
import { LogRocketService } from './logrocket.service';
import { TimerService } from './timer.service';
import { FadLandingPageService } from '../../pages/fad/fad-landing-page/fad-landing-page.service';

declare let $: any;

@Injectable()
export class GlobalService {
  memberInfo: ReplaySubject<MemberInfo>;
  public landingPageService: FadLandingPageService;
  public waDataLayer: any;
  public userData: any;
  private memberData = new BehaviorSubject<MemberInfo>(null);
  public memberData$ = this.memberData.asObservable();
  public memberDataObject;
  public filterState = {};
  public landingPageMemberInfo: HomePageInfoModel;
  private REDIRECTION_URLS = {
    LOCKED_OUT: '../register/updatessn',
    SSN_MISMATCH: '../register/updatessn',
    DOB_NOT_FOUND: '../register/register-detail',
    MEMBER_NOT_FOUND: '../register/memberinfo'
  };
  private API_INVALID_IDENTIFITERS = {
    dateOfBirth: 'MEM_DOB',
    firstName: 'MEM_FNAME',
    lastName: 'MEM_LNAME',
    memberId: 'MEM_NUM'
  };
  maskedVerify = '';
  private isFadLoaded = new BehaviorSubject(false);
  fadLoaded$ = this.isFadLoaded.asObservable();

  private initialSearchableCPC = { hasError: false, searchableCpcs: [] };
  private seachableCpcs = new BehaviorSubject(this.initialSearchableCPC);
  seachableCpcs$ = this.seachableCpcs.asObservable();

  private hasPlanFinancialDetails = new BehaviorSubject(false);
  hasPlanFinancialDetails$ = this.hasPlanFinancialDetails.asObservable();

  timezoneOffset = momenttz(new Date())
    .tz('America/New_York')
    .format('Z');
  searchEnableRetryCount = 0;

  constructor(
    private alertService: AlertService,
    private http: AuthHttp,
    private constants: ConstantsService,
    private authService: AuthService,
    private router: Router,
    private datePipe: DatePipe,
    private dependantService: DependantsService,
    private timerService: TimerService,
    private logRocketService: LogRocketService,
    private dialog: MatDialog
  ) {
    this.memberInfo = new ReplaySubject<MemberInfo>(1);
    this.clearGlobalSessionDetails();
  }

  updateFADStatus(isLoaded: boolean) {
    this.isFadLoaded.next(isLoaded);
  }

  updateSearchableCpcs(hasError, searchableCpcs: string[]) {
    this.seachableCpcs.next({ hasError, searchableCpcs });
  }

  updateHasPlanFinancialDetails(hasPlanFinancialDetails: boolean) {
    this.hasPlanFinancialDetails.next(hasPlanFinancialDetails);
  }

  setAdobe() {
    // Declare programatically
    (window as any)._waDataLayer = new Object();
    let userId = 'Anonymous';
    const userInfo = {
      firstName: null
    };
    if (this.isAuthenticated() && this.authService.authToken.syntheticID) {
      (window as any)._waDataLayer.UID = this.authService.authToken.syntheticID;
      userId = this.authService.authToken.syntheticID;
      // userInfo.firstName = this.authService.authToken.firstName;
    } else {
      (window as any)._waDataLayer.UID = 'Anonymous';
    }

    this.logRocketService.identify(userId, userInfo);

    this.timerService.setTimeout(() => {
      if ((window as any)._satellite) {
        (window as any)._satellite.track('mbwLogin');
      }
    }, 3000);
  }

  setUserData(userData) {
    this.userData = userData;
  }

  getUserData() {
    return this.userData;
  }

  callSatellite() {
    if ((window as any)._satellite) {
      (window as any)._satellite.track('mbwLogin');
    }
  }

  get memberInfo$() {
    return this.memberInfo.asObservable();
  }

  clearMemberData() {
    this.memberData.next(null);
  }

  fetchMemberData() {
    const request = {
      useridin: this.authService.useridin
    };
    return this.http.post(this.constants.getmemberinfo, this.http.handleRequest(request), null).map(res1 => {
      return this.http.handleDecryptedResponse(res1);
    });
  }

  getVitaminsAndOTCLocalObject() {
    if (!sessionStorage.getItem('vitaminsAndOTCs')) {
      this.http
        .getVitaminsAndOTCs()
        .then(response => {
          if (response) {
            sessionStorage.setItem('vitaminsAndOTCs', JSON.stringify(response));
            return sessionStorage.getItem('vitaminsAndOTCs');
          } else {
            return '';
          }
        })
        .catch(error => {});
    } else {
      return sessionStorage.getItem('vitaminsAndOTCs');
    }
  }

  // here we set/change value of the observable
  setMemberData(data) {
    if (data && data['ROWSET']) {
      const member = new MemberInfo().deserialize(data['ROWSET'].ROWS);
      this.memberDataObject = member;
      const info: MemberInfo = data['ROWSET'].ROWS as MemberInfo;
      this.authService.isSubscriber = info.relationship === 'Subscriber';
      this.memberInfo.next(member);
      this.memberData.next(member);
    }
  }

  handleError(response, errorCodes = null, errorMsg?: boolean) {
    const responseJson = response;
    if (errorMsg) {
      if (errorCodes[responseJson.errormessage]) {
        this.alertService.setAlertObj(errorCodes[responseJson.errormessage], 'component');
        this.http.CaptureAPIErrorInAdobe('', errorCodes[responseJson.errormessage], '');
      } else {
        this.alertService.setError(responseJson.errormessage);
        this.http.CaptureAPIErrorInAdobe('', errorCodes[responseJson.errormessage], '');
      }
    } else if (errorCodes && responseJson && errorCodes[responseJson.displaymessage]) {
      this.alertService.setAlertObj(errorCodes[responseJson.displaymessage], 'component');
      this.http.CaptureAPIErrorInAdobe('', errorCodes[responseJson.displaymessage], '');
    } else {
      if (errorMsg) {
        this.alertService.setAlertObj(errorCodes[responseJson.errormessage], 'component');
        this.http.CaptureAPIErrorInAdobe('', errorCodes[responseJson.errormessage], '');
      } else if (responseJson) {
        this.alertService.setError(responseJson.displaymessage);
        this.http.CaptureAPIErrorInAdobe('', errorCodes[responseJson.displaymessage], '');
      } else {
        this.alertService.setError('Unexpected error');
      }
    }
    this.http.hideSpinnerLoading();
    return Observable.throw(responseJson);
  }

  handleLogin(response?) {
    return this.redirectionRoute().then(
      redirectRoute => {
        this.router.navigate([redirectRoute]);
      },
      redirectRoute => {
        this.router.navigate([redirectRoute]);
      }
    );
  }

  login(request, userType?: RegType, drupalres?: any) {
    this.http.login(request).subscribe(
      response => {
        if (drupalres) {
          const reqParamater = {
            useridin: request.useridin,
            consentLanguageId: drupalres[0].Version,
            consentLanguage: encodeURI(drupalres[0].Body),
            consentFlag: 'Y',
            consentTS: this.datePipe.transform(new Date(), 'M/d/yyyy h:m:s aa', this.timezoneOffset)
          };
          this.updateConsent(reqParamater).subscribe();
        }
        this.router.navigate(['/home']);
      },
      err => {
        this.http.hideSpinnerLoading();
        if (err.status === 404) {
          $('#globalError').modal('open');
          return Observable.throw(err.error);
        } else if (err.status >= 500) {
          $('#requestTimeoutError').modal('open');
          return Observable.throw(err.error);
        } else {
          this.handleError(err.error, this.constants.displayMessage);
          return Observable.throw(err.error);
        }
      }
    );
  }

  verifyPhone(phoneNumber?: string) {
    const verifiedUsers = ['AUTHENTICATED-AND-VERIFIED', 'REGISTERED-AND-VERIFIED'];
    const scopeName = this.authService.authToken ? this.authService.authToken.scopename : '';
    const verifyPhoneService = verifiedUsers.includes(scopeName)
      ? this.sendcommchlaccesscode('', phoneNumber ? phoneNumber : phoneNumber.replace(/\D/g, ''))
      : this.sendaccesscodeIn('MOBILE', phoneNumber ? phoneNumber : phoneNumber.replace(/\D/g, ''));
    const isSendAccessCodeService = !verifiedUsers.includes(scopeName);

    verifyPhoneService.subscribe((response: any) => {
      let userId;
      if (response.result === '0') {
        if (isSendAccessCodeService) {
          const communicationChannel = this.http.handleDecryptedResponse(response);
          sessionStorage.setItem('sendCodeRes', JSON.stringify(communicationChannel));
          const sentMailId = JSON.parse(sessionStorage.getItem('sendCodeRes'));
          userId = sentMailId && sentMailId['commChannel'];
        }
        this.alertService.clearError();
        this.maskedVerify = this.maskPhoneNumber(phoneNumber ? phoneNumber : userId);
        sessionStorage.setItem('maskedVerify', this.maskedVerify);
        sessionStorage.setItem('maskedVerifyPhone', 'Y');
        this.navigateToVerifyScreen();
      } else {
        if (response.displaymessage) {
          this.alertService.setAlert(response.displaymessage, '', AlertType.Failure);
          window.scrollTo(0, 0);
        }
      }
    });
  }

  verifyEmail(emailId?: string) {
    const verifiedUsers = ['AUTHENTICATED-AND-VERIFIED', 'REGISTERED-AND-VERIFIED'];
    const scopeName = this.authService.authToken ? this.authService.authToken.scopename : '';
    const verifyEmailService = verifiedUsers.includes(scopeName)
      ? this.sendcommchlaccesscode(emailId, '')
      : this.sendaccesscodeIn('EMAIL', emailId);
    const isSendAccessCodeService = !verifiedUsers.includes(scopeName);

    verifyEmailService.subscribe((response: any) => {
      if (response.result === '0') {
        let userId;
        if (isSendAccessCodeService) {
          const communicationChannel = this.http.handleDecryptedResponse(response);
          sessionStorage.setItem('sendCodeRes', JSON.stringify(communicationChannel));
          const sentMailId = JSON.parse(sessionStorage.getItem('sendCodeRes'));
          userId = sentMailId && sentMailId['commChannel'];
        }
        this.alertService.clearError();
        this.maskedVerify = this.maskEmailId(emailId ? emailId : userId);
        sessionStorage.setItem('maskedVerifyPhone', 'N');
        sessionStorage.setItem('maskedVerify', this.maskedVerify);
        this.navigateToVerifyScreen();
      } else {
        if (response.displaymessage) {
          this.alertService.setAlert(response.displaymessage, '', AlertType.Failure);
          window.scrollTo(0, 0);
        }
      }
    });
  }

  navigateToVerifyScreen() {
    this.router.navigate(['/register/verifyaccesscode']).then(() => {
      this.alertService.setAlert('Verification code sent!.', '', AlertType.Success);
    });
  }

  maskEmailId(userId: string): string {
    const maskedUserId = userId
      ? userId.replace(/^(.{3})(.*)(@.*)$/, (_, firstCharacter, charToMasked, domain) => {
          return `${firstCharacter}${charToMasked.replace(/./g, '*')}${domain}`;
        })
      : userId;
    return maskedUserId;
  }

  maskPhoneNumber(userId: string): string {
    const regex = /^(.{3})(.{3})(.{4})(.*)/;
    let maskedUserId = userId
      ? userId.replace(/^(.*)(.{4})$/, (_, digitsToMasked, lastFourDigits) => {
          return `${digitsToMasked.replace(/./g, '*')}${lastFourDigits}`;
        })
      : userId;
    const str = maskedUserId;
    const subst = `$1-$2-$3`;
    maskedUserId = str.replace(regex, subst);
    return maskedUserId;
  }

  private sendaccesscodeIn(commChannelType, commChannel) {
    return this.sendaccesscode1(commChannelType, commChannel);
  }

  private sendcommchlaccesscode(email, mobile) {
    return this.sendcommchlaccesscode1(email, mobile.replace(/\D/g, ''));
  }

  sendaccesscode1(commChannelType, commChannel) {
    const request = {
      useridin: this.authService.useridin,
      commChannel: commChannel,
      commChannelType: commChannelType,
      userIDToVerify: this.authService.useridin
    };
    return this.http.post(this.constants.sendaccesscodeUrl, this.http.handleRequest(request));
  }

  sendcommchlaccesscode1(email, mobile) {
    const request = {
      useridin: this.authService.useridin,
      email: email,
      mobile: mobile,
      userIDToVerify: this.authService.useridin
    };
    return this.http.post(this.constants.sendCommChlAccesscode, this.http.handleRequest(request));
  }

  isAuthenticated() {
    return this.authService.isAuthenticated();
  }

  redirectionRoute() {
    const scopename = this.authService.authToken ? this.authService.authToken.scopename : '';

    return new Promise((resolve, reject) => {
      const scopeNames = ['INACTIVE-AUTHENTICATED-AND-VERIFIED', 'REGISTERED-AND-VERIFIED'];
      const unverifiedUsers = ['AUTHENTICATED-NOT-VERIFIED'];

      if (unverifiedUsers.indexOf(scopename) > -1) {
        sessionStorage.setItem('isReqCode', 'true');
        sessionStorage.setItem('isUserLogginIn', 'true');
        reject('../register/verifyaccesscode');
        return;
      }
      if (scopeNames.indexOf(scopename) >= 0) {
        this.memAuth().subscribe(memAuthResponse => {
          if (memAuthResponse && memAuthResponse['ROWSET'] && memAuthResponse['ROWSET'].ROWS && memAuthResponse['ROWSET'].ROWS.userType) {
            sessionStorage.setItem('userType', memAuthResponse['ROWSET'].ROWS.userType);
          }
          if (memAuthResponse['errormessage']) {
            reject('../register/register-detail');
            return;
          }
          if (memAuthResponse['ROWSET']) {
            const redirectionUrl = this.getRedirectionPageUrl(memAuthResponse);
            if (redirectionUrl) {
              reject(redirectionUrl);
            }
          } else {
            resolve();
          }
        });
      } else if (scopename === 'AUTHENTICATED-NOT-VERIFIED') {
        reject('../register/verifyaccesscode');
      } else if (scopename === 'AUTHENTICATED-AND-VERIFIED') {
        this.fetchMemberData();
        if (localStorage.getItem('targetRoute')) {
          const targetRoute = localStorage.getItem('targetRoute');
          localStorage.removeItem('targetRoute');
          resolve('../' + targetRoute);
        } else {
          resolve('../home');
        }
      }
    });
  }

  getRedirectionPageUrl(memberAuthResponse) {
    const memberDetails = memberAuthResponse['ROWSET'].ROWS;
    let redirectionUrl = '';
    this.authService.memAuthInfo = memberDetails;

    redirectionUrl =
      memberDetails.memNum && memberDetails.memNum !== 'null'
        ? this.getUrlBasedUponLastAuthText(memberDetails)
        : this.getUrlWhenMemberIdIsNull(memberDetails);

    return redirectionUrl;
  }

  getUrlBasedUponLastAuthText(memberDetails) {
    const lastMemResult = memberDetails.lastMemResult;
    const lastAuthFailText = memberDetails.lastAuthFailtxt;
    const authAttemptCnt = memberDetails.authAttemptCnt;
    let url = '';
    if (
      (lastMemResult.indexOf(this.API_INVALID_IDENTIFITERS.dateOfBirth) > -1 ||
        lastMemResult.indexOf(this.API_INVALID_IDENTIFITERS.firstName) > -1 ||
        lastMemResult.indexOf('FIRST_SCREEN') > -1 ||
        lastMemResult.indexOf(this.API_INVALID_IDENTIFITERS.lastName) > -1) &&
      lastAuthFailText.indexOf('NO_LOGIN') > -1 &&
      !(lastMemResult.indexOf(this.API_INVALID_IDENTIFITERS.memberId) > -1)
    ) {
      url = this.REDIRECTION_URLS['DOB_NOT_FOUND'];
    } else if (lastMemResult.indexOf(this.API_INVALID_IDENTIFITERS.memberId) > -1) {
      url = this.REDIRECTION_URLS['MEMBER_NOT_FOUND'];
    } else {
      sessionStorage.setItem('updatessn', 'true');
      url = this.REDIRECTION_URLS['SSN_MISMATCH'];
    }
    return url;
  }

  getUrlWhenNoLogin(memberDetails) {
    let url = null;
    url = this.isValidNameEntered(memberDetails)
      ? this.isValidMemberIdEntered(memberDetails)
        ? this.REDIRECTION_URLS.SSN_MISMATCH
        : this.REDIRECTION_URLS.MEMBER_NOT_FOUND
      : this.REDIRECTION_URLS.DOB_NOT_FOUND;
    return url;
  }

  isValidMemberIdEntered(memberDetails) {
    return memberDetails.memNum && memberDetails.memSuffix && memberDetails.memSuffix.toString().indexOf('null') === -1;
  }

  isValidNameEntered(memberDetails) {
    return memberDetails.firstName && memberDetails.lastName && memberDetails.DOB;
  }

  getUrlWhenMemberIdIsNull(memberDetails) {
    return memberDetails && memberDetails.lastName && memberDetails.lastName !== 'null'
      ? '../register/memberinfo'
      : '../register/register-detail';
  }

  getUrlBasedUponLastAuthResult(memberDetails) {
    const lastAuthResult = memberDetails.lastAuthResult;
    return lastAuthResult && memberDetails.lastName && lastAuthResult.split(',').indexOf('0') >= 0 ? '../register/verifyaccesscode' : '';
  }

  memAuth() {
    const request = {
      useridin: this.authService.useridin
    };
    return this.http.post(this.constants.memAuthUrl, this.http.handleRequest(request)).map(res1 => this.http.handleDecryptedResponse(res1));
  }

  sendaccesscode() {
    const request = {
      useridin: this.authService.useridin
    };
    return this.http.post(this.constants.sendaccesscodeUrl, this.http.handleRequest(request));
  }

  markFormGroupTouched(formGroup: FormGroup) {
    let myObjects;
    myObjects = Object.keys(formGroup.controls).map(itm => formGroup.controls[itm]);
    myObjects.forEach(control => {
      control.markAsTouched();
      control.markAsDirty();
      if (control.controls) {
        control.controls.forEach(c => this.markFormGroupTouched(c));
      }
    });
  }

  markFormGroupUnTouched(formGroup: FormGroup) {
    let myObjects;
    myObjects = Object.keys(formGroup.controls).map(itm => formGroup.controls[itm]);
    formGroup.markAsUntouched();
  }

  logout() {
    this.http.postWithCallBack(this.constants.logoutUrl, null, null, this.onLogoutCallBack).subscribe(
      () => {
        // delete this.dependantService.dependants;
        this.dependantService.clearDependantsList();
        this.authService.logout();
        this.memberData.next(null);
        this.router.navigate(['./login']);
        // $('#tokenexpires').modal('close');
        //window.open(this.constants.drupalHomeUrl, '_self');
      },
      () => {
        // delete this.dependantService.dependants;
        this.dependantService.clearDependantsList();
        this.authService.logout();
        // this.memberData.next(null);
        this.router.navigate(['./login']);
        // $('#tokenexpires').modal('close');
        //window.open(this.constants.drupalHomeUrl, '_self');
      }
    );
  }

  onLogoutCallBack() {
    $('#tokenExpiryModal').modal('close');
  }

  isMobile() {
    return !!(
      navigator.userAgent.match(/Android/i) ||
      navigator.userAgent.match(/iPhone/i) ||
      navigator.userAgent.match(/iPad/i) ||
      navigator.userAgent.match(/iPod/i)
    );
  }

  getConfidentiality() {
    return this.http.get(this.constants.confidentiality);
  }

  getTermsAndConditions() {
    return this.http.get(this.constants.termsAndConditions);
  }

  clearGlobalSessionDetails() {
    // sessionStorage.removeItem('med_filterState');
    sessionStorage.removeItem('claims_filterState');
  }

  togglePasswordType(type: string) {
    return type === 'text' ? { type: 'password', placeHolder: 'Show' } : { type: 'text', placeHolder: 'Hide' };
  }

  getUTCDate(localDate: any): string {
    return moment.utc(localDate, 'MM/DD/YYYY').format('YYYY-MM-DD');
  }

  groupBy(xs, prop) {
    const grouped = {};
    for (let i = 0; i < xs.length; i++) {
      const p = xs[i][prop];
      if (!grouped[p]) {
        grouped[p] = [];
      }
      grouped[p].push(xs[i]);
    }
    return grouped;
  }

  updateConsent(requestParam): Observable<any> {
    return this.http
      .encryptPost(this.constants.updateConsent, requestParam)
      .map(res => {
        return res;
      })
      .catch(err => {
        return err;
      });
  }

  initIsSearchEnabled() {
    return new Promise<void>((resolve, reject) => {
      if (this.authService.getScopeName() === 'AUTHENTICATED-AND-VERIFIED') {
        return this.isSearchEnabled().subscribe(res => {
          if (res && res.cpcCodeList && res.cpcCodeList.searchableCPCs) {
            const searchableCPCs = res.cpcCodeList.searchableCPCs;
            this.updateSearchableCpcs(false, searchableCPCs);
            sessionStorage.setItem('searchableCPCsResult', JSON.stringify(searchableCPCs));
            resolve();
          } else if (res && res.cpcCodeList) {
            this.updateSearchableCpcs(false, []);
            resolve();
          } else {
            this.updateSearchableCpcs(true, []);
            reject();
          }
        });
      }
    });
  }

  isSearchEnabled(): Observable<any> {
    const request = {
      useridin: this.authService.useridin,
      effectiveDate: moment().format('YYYY-MM-DD')
    };
    return this.http.encryptPost(this.constants.isBenefitSearchEnabled, request).pipe(
      catchError(error => {
        return of(false);
      })
    );
  }

  getSearchResults(query: string): Observable<BenefitSearchResultResponse> {
    this.http.showSpinnerLoading();
    const cpcArray = JSON.parse(sessionStorage.getItem('searchableCPCsResult')) || [];
    if (cpcArray.length) {
      const cpcCodes = cpcArray.map(cpc => ({ cpcCode: cpc.cpcCode }));
      const payload = {
        useridin: this.authService.useridin,
        searchKeyword: query,
        searchableCPCs: cpcCodes
      };
      return this.http.encryptPost(this.constants.benefitsKeywordsearch, payload).pipe(
        catchError(error => {
          console.log(error);
          return of([]);
        })
      );
    } else {
      return of({ searchResults: [] });
    }
  }

  resetObservables() {
    this.isFadLoaded.next(false);
    this.hasPlanFinancialDetails.next(false);
    this.seachableCpcs.next(this.initialSearchableCPC);
  }

  openVirtualVisit() {
    const generatedRequest = {
      useridin: this.authService.useridin,
      channelId: 'web',
      disclaimerFlag: true
    };
    return this.http.post(this.constants.consumerEnrollment, this.http.handleRequest(generatedRequest), null, false);
  }

  initTelehealthEligibility() {
    if (environment.displayVirtualVisit && this.authService.getScopeName() === 'AUTHENTICATED-AND-VERIFIED') {
      return this.getTelehealthEligibilityDetails().subscribe(res => {
        sessionStorage.setItem('vitalsResponse', JSON.stringify(res));
      });
    }
  }

  getTelehealthEligibilityDetails(): Observable<any> {
    const request = { useridin: '' };
    request.useridin = this.authService.useridin && this.authService.useridin !== 'undefined' ? this.authService.useridin : '';
    const url = this.constants.getTelehealthEligibilityDetailsUrl;
    if (request.useridin && this.authService.getScopeName() === 'AUTHENTICATED-AND-VERIFIED') {
      return this.http.encryptPost(url, request, null, null, false);
    } else {
      return of({});
    }
  }
}
