import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import { filter, map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { State } from '../../app.reducer';
import { LoadingSpinnerService } from '../../core/components/loading-spinner';
import { PlanConfig, PlanConfigService } from '../../services/plan-config/plan-config-service';
import { AuthToken } from '../models/authToken';
import { EncryptedRequest } from '../models/encryptedRequest.model';
import { LoginRequest } from '../models/loginRequest.model';
import { PostLoginInfo } from '../models/postlogininfo.model';
import { AuthService } from './auth.service';
import { ConstantsService } from './constants.service';
import { TimerService } from './timer.service';

declare let $: any;

/* tslint:disable */
export interface IRequestOptions {
  headers?: HttpHeaders;
  observe?: 'body';
  params?: HttpParams;
  reportProgress?: boolean;
  responseType?: 'json';
  withCredentials?: boolean;
  body?: any;
}

@Injectable()
export class AuthHttp {
  api: string;
  postLoginInfo: PostLoginInfo;
  public serviceCount = 0;
  private getCallServiceCount = 0;
  spinnerStarted = false;
  memberPlans: any;

  // Extending the HttpClient through the Angular DI.
  public constructor(
    public http: HttpClient,
    public authService: AuthService,
    public constantService: ConstantsService,
    public spinner: LoadingSpinnerService,
    public store: Store<State>,
    private timerService: TimerService,
    private planConfigService: PlanConfigService
  ) {}

  /**
   * GET request
   * @param {string} endPoint it doesn't need / in front of the end point
   * @param {IRequestOptions} options options of the request like headers, body, etc.
   * @param {string} api use if there is needed to send request to different back-end than the default one.
   * @returns {Observable<T>}
   */
  public get<T>(endUrl: string, options?: IRequestOptions, useGlobalSpinner?: boolean): Observable<T> {
    // There is no reason useGlobalSpinner needs to be true all time because though the param value comes as FALSE, its becoming TRUE
    // Anyhow isArgument() will make the value as TRUE true default, so commenting the below line
    //useGlobalSpinner = true;
    useGlobalSpinner = this.isArgument(useGlobalSpinner);
    if (useGlobalSpinner && !this.spinnerStarted) {
      this.showSpinnerLoading();
    }
    this.getCallServiceCount++;
    console.log(
      'TOKEN: calling service:',
      endUrl,
      new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: 'numeric' })
    );
    return this.http
      .get<T>(endUrl, options)
      .do(() => {
        this.getCallServiceCount--;
        if (this.getCallServiceCount <= 0 && useGlobalSpinner && this.spinnerStarted) {
          this.getCallServiceCount = 0; // Resets the count to 0, even if it becomes negative
          this.hideSpinnerLoading();
        }
      })
      .catch(error => {
        this.getCallServiceCount--;
        if (this.getCallServiceCount <= 0 && useGlobalSpinner && this.spinnerStarted) {
          this.getCallServiceCount = 0;
          this.hideSpinnerLoading();
        }
        if (endUrl.indexOf(environment.drupalTestUrl) < 0) {
          // If not Drupal Failure handle the response and throw the error
          this.handleError(error);
        }
        return Observable.of(error.error);
      });
  }

  public postWithCallBack<T>(endUrl: string, params: Object, options?: IRequestOptions, callBackFunction?: Function): Observable<T> {
    return this.post<T>(endUrl, params, options).do(() => {
      if (callBackFunction) {
        callBackFunction();
      }
    });
  }

  /**
   * POST request
   * @param {string} endPoint end point of the api
   * @param {Object} params body of the request.
   * @param {IRequestOptions} options options of the request like headers, body, etc.
   * @returns {Observable<T>}
   */

  public post<T>(
    endUrl: string,
    params: any,
    requestOptions?: IRequestOptions,
    useGlobalSpinner?: boolean,
    FWB?: boolean,
    reportProgress?: boolean
  ): Observable<T> {
    if (!FWB) {
      FWB = false;
    }
    useGlobalSpinner = this.isArgument(useGlobalSpinner);
    if (useGlobalSpinner && !this.spinnerStarted) {
      this.showSpinnerLoading();
    }
    this.serviceCount++;

    if (!FWB) {
      return this.http
        .post<T>(endUrl, params, { headers: this.getRequestOptionArgs(requestOptions, endUrl) })
        .do(() => {
          this.serviceCount--;
          // console.log(endPoint + ' serviceCOUNT-' +  this.serviceCount );
          if (this.serviceCount <= 0 && useGlobalSpinner && this.spinnerStarted) {
            this.serviceCount = 0;
            this.hideSpinnerLoading();
          }
        })
        .catch(error => {
          this.serviceCount--;
          if (this.serviceCount <= 0 && useGlobalSpinner && this.spinnerStarted) {
            this.serviceCount = 0;
            this.hideSpinnerLoading();
          }
          this.handleError(error);
          return Observable.of(error.error);
        });
    } else {
      const options: any = {
        headers: new HttpHeaders({
          Authorization: `Bearer ${this.authService.getAuthToken()}`,
          uitxnid: 'WEB_v3.0_' + this.uuid()
        })
      };
      options.headers = this.addHeaderForImpersonation(options.headers);
      if (reportProgress) {
        options.reportProgress = true;
        options.observe = 'events';
      }

      return this.http
        .post<T>(endUrl, params, options)
        .do(() => {
          this.serviceCount--;
          // console.log(endPoint + ' serviceCOUNT-' +  this.serviceCount );
          if (this.serviceCount <= 0 && useGlobalSpinner && this.spinnerStarted) {
            this.serviceCount = 0;
            this.hideSpinnerLoading();
          }
        })
        .catch(error => {
          this.serviceCount--;
          if (this.serviceCount <= 0 && useGlobalSpinner && this.spinnerStarted) {
            this.serviceCount = 0;
            this.hideSpinnerLoading();
          }
          this.handleError(error);
          return Observable.of(error.error);
        });
    }
  }

  isAnyErrorModalAlreadyOpen(): boolean {
    return (
      this.isModalOpen('tokenExpiryModal') ||
      this.isModalOpen('globalError') ||
      this.isModalOpen('internetconnection') ||
      this.isModalOpen('requestTimeoutError') ||
      this.isModalOpen('communicationPreference')
    );
  }

  isModalOpen(modalId: string): boolean {
    const modal = $('#' + modalId);
    if (modal && modal[0] && modal[0].className && modal[0].className.indexOf('open') > -1) {
      return true;
    }
    return false;
  }

  showServiceErrorModalPopup(modalType: string) {
    if (!this.isAnyErrorModalAlreadyOpen()) {
      switch (modalType) {
        case 'tokenExpiryModal':
          $('#tokenExpiryModal').modal('open');
          break;
        case 'globalError':
          $('#globalError').modal('open');
          break;
        case 'internetconnection':
          $('#internetconnection').modal('open');
          break;
        case 'requestTimeoutError':
          $('#requestTimeoutError').modal('open');
          break;
      }
    }
  }

  handleError(error: HttpErrorResponse, serviceUrl?: string) {
    //hideSpinnerLoading is removed below because in GET/POST calls we call handleError() after hideSpinner is called
    if (this.constantService.skipHandleErrorUrls.indexOf(error.url) === -1) {
      if (error && error.error && error.error.result === '-1') {
        if (error.status === 401) {
          this.showServiceErrorModalPopup('tokenExpiryModal');
        }
      } else if (error.status === 401 && !error.url.includes('/inbound/authorize')) {
        this.showServiceErrorModalPopup('tokenExpiryModal');
        this.authService.tokenError = true;
      } else if (error.status === 404) {
        this.showServiceErrorModalPopup('globalError');
        // $('#requestTimeoutError').modal('open');
      } else if (error.status === 408) {
        this.showServiceErrorModalPopup('globalError');
      } else if (navigator.onLine === false) {
        this.showServiceErrorModalPopup('internetconnection');
      } else if (error.status >= 500) {
        let message = 'Oops Something went wrong. Please try again!';
        if (error && error.error && error.error.result) {
          message = message + ' (' + error.error.result + ')';
          this.CaptureAPIErrorInAdobe(error.status.toString(), error.error.result, message);
        }
        this.showServiceErrorModalPopup('requestTimeoutError');
        if ($('#timeOutErrorText') && $('#timeOutErrorText')[0]) {
          $('#timeOutErrorText')[0].innerHTML = message;
        }
      } else {
        // $('#requestTimeoutError').modal('open');
        if (serviceUrl && serviceUrl.indexOf('/sso/') === -1) {
          this.showServiceErrorModalPopup('globalError');
        }
        this.CaptureAPIErrorInAdobe(error.status.toString(), error.error, '');
      }
    }
    if (error && error.error && typeof error.error === 'object') {
      error.error['error'] = true;
    }
    //Capture the error only if error status and error message is available
    if (error && error.status && error.error) {
      this.CaptureAPIErrorInAdobe(error.status.toString(), error.error, '');
    }
  }

  /**
   * PUT request
   * @param {string} endPoint end point of the api
   * @param {Object} params body of the request.
   * @param {IRequestOptions} options options of the request like headers, body, etc.
   * @returns {Observable<T>}
   */
  public put<T>(endPoint: string, params: Object, options?: IRequestOptions): Observable<T> {
    return this.http.put<T>(this.api + endPoint, params, options);
  }

  /**
   * DELETE request
   * @param {string} endPoint end point of the api
   * @param {IRequestOptions} options options of the request like headers, body, etc.
   * @returns {Observable<T>}
   */
  public delete<T>(endPoint: string, options?: IRequestOptions): Observable<T> {
    return this.http.delete<T>(this.api + endPoint, options);
  }

  private getRequestOptionArgs(param_options, url) {
    let options;
    const apigeeUrl = environment.serviceUrl;
    const samlUrl = environment.ssoInboundAuthUrl;
    if (url.indexOf('sso/inbound/authorize') > -1) {
      param_options['Authorization'] = param_options.headers.get('Authorization');
      param_options['Content-Type'] = 'application/json';
      options = new HttpHeaders(param_options);
    } else if (param_options) {
      if (this.authService.isAuthenticated()) {
        param_options['Authorization'] = `Bearer ${this.authService.getAuthToken()}`;
        param_options['Content-Type'] = 'application/json';
      } else {
        param_options['Content-Type'] = 'application/json';
      }
      options = new HttpHeaders(param_options);
    } else {
      if (this.authService.isAuthenticated()) {
        options = new HttpHeaders({
          Authorization: `Bearer ${this.authService.getAuthToken()}`,
          'Content-Type': 'application/json'
        });
        if (url && environment.uitxnid) {
          options = new HttpHeaders({
            Authorization: `Bearer ${this.authService.getAuthToken()}`,
            'Content-Type': 'application/json',
            uitxnid: 'WEB_v3.0_' + this.uuid()
            // 'uisessionid': 'WEB_v3.0_' + this.sessionid()
          });
        }
      } else {
        options = new HttpHeaders({
          'Content-Type': 'application/json'
        });
        if (url && environment.uitxnid) {
          options = new HttpHeaders({
            'Content-Type': 'application/json',
            uitxnid: 'WEB_v3.0_' + this.uuid()
          });
        }

        if (url && url.indexOf('ssomyblue') !== -1) {
          options = new HttpHeaders({
            'Content-Type': 'application/json',
            uitxnid: 'WEB_v3.0_' + this.uuid()
          });
        }
      }
    }
    // // framing uxid for apigee URLs.
    // if (url && !(url.indexOf(apigeeUrl) === -1) && environment.uitxnid) {
    //   options['uitxnid'] = 'WEB_v3.0_' + this.uuid();
    // }
    // console.log('Final headers', url, options);
    options = this.addHeaderForImpersonation(options);
    return options;
  }

  encryptPostJwt(url: string, body: any, headers?: string, type?: string) {
    const msg = this.encryptPayload(body);
    return this.http.post(url, JSON.stringify(msg), this.jwt()).pipe(map(response => this.handleDecryptedResponse(response)));
  }

  encryptPostHdw(url: string, body: any, headers?: string, type?: string) {
    const msg = this.encryptPayload(body);
    return this.http.post(url, JSON.stringify(msg), this.hdw()).pipe(map(response => this.handleDecryptedResponse(response)));
  }

  public uuid() {
    let uuid = '',
      i,
      random;
    for (i = 0; i < 32; i++) {
      // tslint:disable-next-line:no-bitwise
      random = (Math.random() * 16) | 0;
      if (i === 8 || i === 12 || i === 16 || i === 20) {
        uuid += '-';
      }
      // tslint:disable-next-line:no-bitwise
      uuid += (i === 12 ? 4 : i === 16 ? (random & 3) | 8 : random).toString(16);
    }
    if (uuid) {
      localStorage['browserID'] = uuid;
    }
    return uuid;
  }

  sessionid() {
    let sessionid = '',
      i,
      random;
    for (i = 0; i < 32; i++) {
      // tslint:disable-next-line:no-bitwise
      random = (Math.random() * 16) | 0;
      if (i === 8 || i === 12 || i === 16 || i === 20) {
        sessionid += '-';
      }
      // tslint:disable-next-line:no-bitwise
      sessionid += (i === 12 ? 4 : i === 16 ? (random & 3) | 8 : random).toString(16);
    }
    if (sessionid && !sessionStorage.getItem('uisessionid')) {
      sessionStorage.setItem('uisessionid', sessionid);
    }
    return sessionid;
  }

  base64toBlob(base64Data, contentType) {
    contentType = contentType || '';
    const sliceSize = 1024;
    const byteCharacters = atob(base64Data);
    const bytesLength = byteCharacters.length;
    const slicesCount = Math.ceil(bytesLength / sliceSize);
    const byteArrays = new Array(slicesCount);

    for (let sliceIndex = 0; sliceIndex < slicesCount; ++sliceIndex) {
      const begin = sliceIndex * sliceSize;
      const end = Math.min(begin + sliceSize, bytesLength);

      const bytes = new Array(end - begin);
      for (let offset = begin, i = 0; offset < end; ++i, ++offset) {
        bytes[i] = byteCharacters[offset].charCodeAt(0);
      }
      byteArrays[sliceIndex] = new Uint8Array(bytes);
    }
    return new Blob(byteArrays, { type: contentType });
  }

  // adhoc fix for KLO-1722, KLO-1945
  // encryptFadPost added as part of the adhoc fix for KLO-1722
  // The primary purpose of this method is to send out an empty useridin in the request as the
  // user does not have his user record created in Fad database
  encryptFadPost(
    url: string,
    body: any,
    headers?: string,
    type?: string,
    useGlobalSpinner?: boolean,
    FWB?: boolean,
    reportProgress: boolean = null
  ) {
    if (this.authService.isUserNotMemberInCHC || sessionStorage.getItem('isUserNotMemberInCHC') === 'true') {
      body.useridin = '';
    }
    return this.encryptPost(url, body, headers, type, useGlobalSpinner, FWB, reportProgress);
  }

  encryptPost(
    url: string,
    body: any,
    headers?: string,
    type?: string,
    useGlobalSpinner?: boolean,
    FWB?: boolean,
    reportProgress: boolean = null
  ) {
    let request: string | FormData;
    let msg;
    // If sending blob/images send encrypted JSON with blob as multiform
    if (FWB) {
      const formData = new FormData();
      if (body.images) {
        body.images.forEach(image => {
          formData.append('imageFiles', this.base64toBlob(image.imageString, image.type), image.fileName);
        });
      }
      body.images = '';
      msg = this.encryptPayload(body, false);
      formData.append('FWLBenefitClaim', JSON.stringify(msg));
      request = formData;
    } else {
      msg = this.encryptPayload(body, false, useGlobalSpinner);
      request = JSON.stringify(msg);
    }

    let options = null;
    const apigeeUrl = environment.serviceUrl;
    // framing uxid for apigee URLs.
    if (!(url.indexOf(apigeeUrl) === -1) && environment.uitxnid) {
      options = {
        uitxnid: 'WEB_v3.0_' + this.uuid()
      };
      if (environment.impersonation) {
        options['impersonation'] = 'true';
      }
    }
    return this.post(url, request, null, useGlobalSpinner, FWB, reportProgress)
      .map((response: HttpResponse<any>) => this.handleDecryptedResponse(reportProgress && response.body ? response.body : response))
      .do(res => {
        if (res['displaymessage'] && res['errormessage'] && res['result']) {
          this.CaptureAPIErrorInAdobe(res['result'], res['displaymessage'], res['errormessage']);
        }
      })
      .catch(error => {
        console.log('Error =' + error.error);
        this.handleError(error, url);
        return Observable.of(error.error);
      });
  }

  public CaptureAPIErrorInAdobe(result: string, displaymessage: string, errormessage: string) {
    // Declare programatically
    if ((window as any)._waDataLayer) {
      console.log('wa data layer', (window as any)._waDataLayer);
    } else {
      (window as any)._waDataLayer = new Object();
      console.log('NEW wa data layer', (window as any)._waDataLayer);
    }
    (window as any)._waDataLayer.errormessage = errormessage;
    (window as any)._waDataLayer.result = result;
    (window as any)._waDataLayer.displaymessage = displaymessage;
    this.timerService.setTimeout(function() {
      if ((window as any)._satellite) {
        (window as any)._satellite.track('errormessage');
      }
    }, 3000);
    console.log('ERROR response sent to adobe', result, displaymessage, errormessage);
  }

  handleDecryptedResponse(response): Object {
    if (response && (response['message'] || response['algmsg'] || response['heqmsg'] || response['lnmessage'])) {
      return this.decryptPayload(response);
    } else {
      return response;
    }
  }

  handleRequest(request, key2NotRequired = false, useGlobalSpinner?: boolean) {
    useGlobalSpinner = this.isArgument(useGlobalSpinner);
    if (useGlobalSpinner && !this.spinnerStarted) {
      this.showSpinnerLoading();
    }
    console.log('profile request', request);
    return JSON.stringify(this.encryptPayload(request, key2NotRequired, useGlobalSpinner));
  }

  encryptPayload(request: object, isKey2NotReq = false, useGlobalSpinner?: boolean) {
    // Step 2 Perform Encryption

    //KLO-Spinner loading not required during Encryption, so commenting out the below
    //useGlobalSpinner = this.isArgument(useGlobalSpinner);
    // if (useGlobalSpinner && !this.spinnerStarted) {
    //   this.showSpinnerLoading();
    // }
    const encryptedRequest = new EncryptedRequest();

    encryptedRequest.generateEncryptedMessage(request, this.authService.cryptoToken, isKey2NotReq);
    return encryptedRequest;
  }

  decryptPayload(response) {
    const decryptedResponse = new EncryptedRequest();
    let responseMsg = {};

    if (response.message) {
      responseMsg = decryptedResponse.generateDecryptedMessage(response.message, this.authService.cryptoToken);
    }

    if (response['algmsg']) {
      responseMsg['algmsg'] = decryptedResponse.generateDecryptedMessage(response['algmsg'], this.authService.cryptoToken);
    }
    if (response['heqmsg']) {
      responseMsg['heqmsg'] = decryptedResponse.generateDecryptedMessage(response['heqmsg'], this.authService.cryptoToken);
    }
    if (response['lnmessage']) {
      responseMsg['lnmessage'] = decryptedResponse.generateDecryptedMessage(response['lnmessage'], this.authService.cryptoToken);
    }
    if (response['ssomsg']) {
      responseMsg['ssomsg'] = decryptedResponse.generateDecryptedMessage(response['ssomsg'], this.authService.cryptoToken);
    }

    // console.log('Decrypted Response', JSON.stringify(responseMsg, null, 2));
    return responseMsg;
  }

  decryptSingleValue(value) {
    const decryptedResponse = new EncryptedRequest();
    return decryptedResponse.generateDecryptedMessageSingleValue(value, this.authService.cryptoToken);
  }

  hideSpinnerLoading() {
    this.spinner.hide();
    this.spinnerStarted = false;
    sessionStorage.removeItem('spinnerStart');
    sessionStorage.removeItem('spinnerEnd');
  }

  showSpinnerLoading() {
    if (!this.spinnerStarted) {
      this.spinner.show();
      this.spinnerStarted = true;
      const num = Date.now();
      sessionStorage['spinnerStart'] = num;
      sessionStorage['spinnerEnd'] = num + environment.screenNavigationSLA;
    }
  }

  isArgument(useGlobalSpinner) {
    if (useGlobalSpinner === null || useGlobalSpinner === undefined) {
      return true;
    } else {
      return useGlobalSpinner;
    }
  }

  public jwt() {
    // create authorization header with jwt token
    const headerJson = {
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + this.authService.authToken.access_token,
      'Release-Version': 'D2',
      uitxnid: 'WEB_v3.0_9cd50803-73ed-4e7b-8ca7-fbbb0ecee03b'
    };

    let headers = new HttpHeaders(headerJson);
    headers = this.addHeaderForImpersonation(headers);
    return { headers };
  }

  public hdw() {
    // create authorization header with hdw token
    const headerJson = {
      'Release-Version': 'D2'
    };

    const headers = new HttpHeaders(headerJson);
    return { headers: headers };
  }

  login(request: LoginRequest) {
    this.authService.useridin = request.useridin !== null && request.useridin !== undefined ? request.useridin.toString() : '';
    return this.authService
      .getTokens()
      .do(token => {
        this.authService.cryptoToken = token;
        this.authService.persistSession();
      })
      .flatMap(() => {
        return this.http.post(this.constantService.loginUserUrl, this.handleRequest(request), {
          headers: this.getRequestLoginOptionArgs(this.constantService.loginUserUrl)
        });
      })
      .flatMap((res: any) => {
        // Need to handle Login Data
        // if(res['planTypes'] && res['planTypes']['CDH']){
        //   res['planTypes']['CDH'] = true;
        // }
        if (res && res.memberPlans) {
          this.memberPlans = this.decryptSingleValue(res.memberPlans);
          sessionStorage.setItem('getMemberPlans', this.memberPlans);
          sessionStorage.setItem('defaultIPAPlan', JSON.stringify(JSON.parse(this.memberPlans).plans[0]));
          sessionStorage.setItem('selectedPlanDetails', JSON.stringify(JSON.parse(this.memberPlans).plans[0]));
        }

        sessionStorage.setItem('isCDHenabledUser', res['planTypes'] && res['planTypes']['CDH'] ? res['planTypes']['CDH'] : false);
        // sessionStorage.setItem('isCDHenabledUser','false');

        this.authService.authToken = new AuthToken(res);
        this.authService.useridin = request.useridin != null ? request.useridin.toString() : '';
        this.authService.persistSession();

        if (
          !localStorage.getItem('targetRoute') ||
          (localStorage.getItem('targetRoute') && !localStorage.getItem('targetRoute').includes('from=MPSW'))
        ) {
          return this.postlogin().then(response => {
            if (response && response.error !== true && response['result'] !== -92754) {
              this.authService.postLoginInfo = response;
              sessionStorage.setItem('postLoginInfoBackup', JSON.stringify(response));
              this.hideSpinnerLoading(); // Hiding the spinner without closing it
              return this.authService.authToken;
            } else {
              // returning response instead of auth token to handle in component
              return response;
            }
          });
        } else {
          return Observable.of(res as any);
        }
      });
  }

  newlogin(request): Observable<any> {
    console.log('Inside it');
    return this.http
      .post(this.constantService.loginUserUrl, this.handleRequest(request), {
        headers: this.getRequestLoginOptionArgs(this.constantService.loginUserUrl)
      })
      .flatMap(res => {
        // Need to handle Login Data
        this.authService.authToken = new AuthToken(res);
        this.authService.useridin = request.useridin != null ? request.useridin.toString() : '';
        this.authService.persistSession();
        return this.postlogin().then(response => {
          if (response && response.error !== true) {
            this.authService.postLoginInfo = response;
            this.hideSpinnerLoading(); //Hiding the Spinner without showing it
            return this.authService.authToken;
          }
        });
      });
  }

  impersonation(request) {
    this.authService.useridin = '';
    let impersonationHeaders = this.getRequestLoginOptionArgs(this.constantService.impersonationUserUrl);
    return this.authService
      .getTokens()
      .do(token => {
        this.authService.cryptoToken = token;
        this.authService.persistSession();
      })
      .flatMap(() => {
        return this.http
          .post(this.constantService.impersonationUserUrl, this.handleRequest(request), {
            headers: impersonationHeaders
          })
          .pipe(
            map(res => {
              // Need to handle Login Data
              this.authService.authToken = new AuthToken(res);
              this.authService.useridin = res['ctuseridin'];
              sessionStorage.setItem('impersonatingUser', 'true');
              this.authService.persistSession();
              return this.authService.authToken;
            })
          );
      });
  }

  async postlogin() {
    const req = {
      useridin: this.authService.useridin
    };
    this.checkWelcomeKitStatus();
    return this.encryptPost(this.constantService.getpostloginUrl, req).toPromise();
  }

  async checkWelcomeKitStatus() {
    this.planConfigService
      .getCurrentPlanConfig$()
      .pipe(filter((planConfig: PlanConfig) => planConfig.isWelcomeKitEnabled))
      .subscribe(() => {
        this.getMedicareWKservice().then(responsewk => {
          if (responsewk) {
            console.log('inside auth service getMedicareService-----------------------------------', responsewk);
            sessionStorage.setItem('pwkStatus', JSON.stringify(responsewk));
            sessionStorage.setItem('seenVideo', JSON.stringify(true));
          }
        });
      });
  }

  async getMedicareWKservice() {
    // this.authService.authToken.userType.toLowerCase() === 'medicare'
    const req = {
      useridin: this.authService.useridin
    };
    return this.encryptPost(this.constantService.pdfUrl, req).toPromise();
  }

  async getVitaminsAndOTCs() {
    const request = {
      useridin: this.authService.useridin
    };
    return this.encryptPost(this.constantService.getVitaminsandOtcsUrl, request).toPromise();
  }

  getRequestLoginOptionArgs(url) {
    let options;
    options = new HttpHeaders({
      uitxnid: 'WEB_v3.0_' + this.uuid(),
      'Content-Type': 'application/json'
    });
    options = this.addHeaderForImpersonation(options);
    return options;
  }

  public addHeaderForImpersonation(headers: HttpHeaders): HttpHeaders {
    return environment.impersonation ? headers.append('impersonation', 'true') : headers;
  }
}
