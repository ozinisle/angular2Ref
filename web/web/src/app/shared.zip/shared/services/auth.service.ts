import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material';
import * as moment from 'moment';
import * as momentTime from 'moment-timezone';
import 'rxjs/add/operator/map';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Rx';
import { environment } from '../../../environments/environment';
import { GetMemBasicInfoResponseModelInterface } from '../../pages/medications/models/interfaces/get-member-basic-info-model.interface';
import { DependentsResponseModel } from '../../pages/myclaims/models/dependants.model';
import { DependentsModelInterface } from '../../pages/myclaims/models/interfaces/dependants-model.interface';
import { AuthToken } from '../models/authToken';
import { PostLoginInfo } from '../models/postlogininfo.model';
import { RegType } from '../models/regType.enum';
import { CryptoToken } from '../models/token.model';
import { ConstantsService } from './constants.service';
import { TimerService } from './timer.service';

@Injectable()
export class AuthService {
  private authTokenSubject: BehaviorSubject<AuthToken> = new BehaviorSubject(undefined);
  private postLoginInfoSubject: BehaviorSubject<PostLoginInfo>;

  /**
   * The current user's AuthToken, as an Observable that emits whenever the value
   * is updated.
   *
   * Note: This is a _hot_ Observable -- use rxjs operator take(1)
   * if you only need the current value.
   */
  public get authToken$(): Observable<AuthToken | null> {
    return this.authTokenSubject.asObservable();
  }

  /**
   * The current user's "post login info", as an Observable that emits whenever
   * the value is updated.
   *
   * Note: This is a _hot_ Observable -- use either the rxjs operator ```take(1)```
   * or the property ```postLoginInfo``` if you only need the current value.
   */
  public get postLoginInfo$(): Observable<PostLoginInfo | null> {
    return this.postLoginInfoSubject.asObservable();
  }

  /**
   * The latest value of the current user's "post login info".
   * Use this accessor instead of directly accessing sessionStorage.
   *
   * Consider using the Observable ```postLoginInfo$``` instead.
   */
  public get postLoginInfo(): PostLoginInfo {
    return this.postLoginInfoSubject.value;
  }

  /**
   * Updates the value of the current user's "post login info".
   *
   * Use this mutator instead of directly accessing sessionStorage, so the
   * rest of the app can react when changes are made.
   */
  public set postLoginInfo(value: PostLoginInfo) {
    sessionStorage.setItem('postLoginInfo', JSON.stringify(value));
    this.postLoginInfoSubject.next(value);
  }

  cryptoToken: CryptoToken;
  memAuthInfo: any;
  useridin: string;
  refreshTimer: number;
  dependentsList: DependentsModelInterface = null;
  isSubscriber = false;
  depId: number;
  tokenError = false;
  basicMemInfo: GetMemBasicInfoResponseModelInterface = null;
  authRestartScreen = '/register/register-detail';
  userState: string;
  impersonate: boolean;
  private teleHealthData = new BehaviorSubject(null);
  teleHealthDataLoaded$ = this.teleHealthData.asObservable();

  public isUserNotMemberInCHC = false;

  constructor(
    private http: HttpClient,
    private constantService: ConstantsService,
    private timerService: TimerService,
    private dialogRef: MatDialog
  ) {
    this.fetchSession();
    this.getTokens().subscribe(token => {
      this.cryptoToken = token;
      this.persistSession();
      console.log('ATOKEN: Crypto token called! whats in UI session storage: ', sessionStorage['token']);
    });

    const storedPostLoginInfo = JSON.parse(sessionStorage.getItem('postLoginInfo'));
    this.postLoginInfoSubject = new BehaviorSubject(storedPostLoginInfo);
  }

  setShowDemographicModel(value: boolean) {
    const postLoginInfo = this.postLoginInfoSubject.value;
    postLoginInfo.showDemographicModel = value;
    this.postLoginInfoSubject.next(postLoginInfo);
  }

  /**
   * Get and parse the covergae effective date from post login details.
   * If not present or invalid returns null.
   */
  getStartDate(): Date {
    if (this.postLoginInfo) {
      const startMoment = moment(this.postLoginInfo.coverageEffecDt, 'YYYY-MM-DD');
      if (startMoment.isValid()) {
        return startMoment.toDate();
      }
    }
    return null;
  }

  /**
   * Check if the member has his coverage started.
   * If no coverage date was returned then we assume it has started for backward compatibility.
   */
  hasMembershipStarted(): boolean {
    const startDate = this.getStartDate();
    if (startDate == null) {
      return true;
    }
    const currentDate = new Date();
    return startDate.getTime() <= currentDate.getTime();
  }

  impersonation(): boolean {
    this.impersonate = environment.impersonation;
    return this.impersonate;
  }

  fetchSession() {
    if (sessionStorage['authToken'] !== undefined && sessionStorage['authToken'] !== 'undefined') {
      this.authToken = JSON.parse(sessionStorage['authToken']);
    }
    if (sessionStorage['useridin']) {
      this.useridin = sessionStorage['useridin'];
    }

    if (sessionStorage['token']) {
      this.cryptoToken = sessionStorage['token'] !== 'undefined' ? JSON.parse(sessionStorage['token']) : null;
    }
  }

  getTokens(): Observable<any> {
    if (this.cryptoToken) {
      return Observable.of(this.cryptoToken);
    } else {
      console.log(
        'ATOKEN: calling service:',
        this.constantService.tokenbaseurl + this.constantService.tokensEndPoint,
        new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: 'numeric' })
      );
      return this.http.get(this.constantService.tokenbaseurl + this.constantService.tokensEndPoint);
    }
  }

  isUserActive() {
    return this.authToken.HasActivePlan;
  }

  persistSession() {
    sessionStorage.setItem('authToken', JSON.stringify(this.authToken));
    sessionStorage.setItem('token', JSON.stringify(this.cryptoToken));
    sessionStorage.setItem('useridin', this.useridin);
  }

  private uuid() {
    let uuid = '';
    for (let i = 0; i < 32; i++) {
      // tslint:disable-next-line:no-bitwise
      const randomNum = (Math.random() * 16) | 0;
      if (i === 8 || i === 12 || i === 16 || i === 20) {
        uuid += '-';
      }
      // tslint:disable-next-line:no-bitwise
      uuid += (i === 12 ? 4 : i === 16 ? (randomNum & 3) | 8 : randomNum).toString(16);
    }
    if (uuid) {
      localStorage['browserID'] = uuid;
    }
    return uuid;
  }

  get authToken() {
    return this.authTokenSubject.value;
  }

  set authToken(val: AuthToken) {
    this.authTokenSubject.next(val);

    // Register timer to update token
    if (!this.refreshTimer && val && val.access_token && this.getExpAccessTokenTime() > 0) {
      this.refreshTimer = this.timerService.setTimeout(this.refreshToken.bind(this), this.getExpAccessTokenTime());
    }
  }

  get userRegType() {
    const registeredUserID = sessionStorage['registeredUserId'] ? JSON.parse(sessionStorage.getItem('registeredUserId')) : this.useridin;
    return registeredUserID && registeredUserID.indexOf('@') === -1 ? RegType.MOBILE : RegType.EMAIL;
  }

  getUpdatedTokens(): Observable<any> {
    console.log(
      'ATOKEN:calling service:',
      this.constantService.tokenbaseurl + this.constantService.tokensEndPoint,
      new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: 'numeric' })
    );
    return this.http.get(this.constantService.tokenbaseurl + this.constantService.tokensEndPoint);
  }

  isAuthenticated(): boolean {
    this.fetchSession();
    return !!this.authToken;
  }

  getScopeName(): string {
    this.fetchSession();
    return this.authToken ? this.authToken.scopename : '';
  }

  getAuthToken() {
    return this.authToken.access_token;
  }

  getRefreshToken() {
    return this.authToken ? this.authToken.refresh_token : '';
  }

  getExpAccessTokenTime() {
    const accessTokenExpires = moment(this.authToken.access_token_expires, 'YYYY-MMM-DDTHH:mm:ss.SSSZ');
    return accessTokenExpires.diff(+moment() + 630000, 'milliseconds');
  }

  refreshToken() {
    console.log('refresh token called!');
    this.refreshTimer = null;
    const body = new URLSearchParams();
    body.set('grant_type', 'refresh_token');
    body.set('refresh_token', this.getRefreshToken());
    this.getUpdatedTokens().subscribe(token => {
      // this.cryptoToken = token;
      // this.persistSession();
      console.log('ATOKEN: Crypto token called! whats in UI session storage: ', sessionStorage['token']);
      if (this.authToken) {
        return this.http.post(this.constantService.refreshtokenurl, body.toString(), this.jwtContentTypeEncoded()).subscribe(res => {
          this.updateRefreshTokenRes(res);
          // this.authToken = new AuthToken(res);
          this.authTokenInfoFromSession();
          this.persistSession();
          console.log(
            'ATOKEN: Auth token (refresh) called! new AUTHtoken ',
            this.authToken.access_token,
            ' will expires by ',
            new Date(this.authToken.access_token_expires.replace('T', ' ') + ' GMT').toLocaleTimeString([], {
              hour: '2-digit',
              minute: '2-digit',
              second: 'numeric'
            }),
            ' --- Issued Time:',
            new Date(this.authToken.issued.replace('T', ' ') + ' GMT').toLocaleTimeString([], {
              hour: '2-digit',
              minute: '2-digit',
              second: 'numeric'
            }),
            ' --- CurrentTime:',
            new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: 'numeric' })
          );
          return this.authToken;
        });
      }
      // this.cryptoToken = token;
      // this.persistSession();
    });
  }

  /**
   *
   * @param res - this will have 6 param in response.
   * Updateing the refreshToken with 6 parameter in authToken
   */
  updateRefreshTokenRes(res) {
    this.authToken = {
      ...this.authToken,
      scopename: res.scopename,
      refresh_count: res.refresh_count,
      access_token: res.access_token,
      refresh_token: res.refresh_token,
      issued: res.issued,
      access_token_expires: res.access_token_expires,
      refresh_token_expires: res.refresh_token_expires
    };
  }

  authTokenInfoFromSession() {
    // reading the information from the previous session
    // which is not part of refresh token
    // like planTypes, userType, HasActivePlan
    const authTokenSession = sessionStorage.getItem('authToken');
    if (authTokenSession) {
      try {
        const authTokenSessionJson = JSON.parse(authTokenSession);
        if (authTokenSessionJson) {
          this.authToken.HasActivePlan = authTokenSessionJson.HasActivePlan;
          this.authToken.planTypes = authTokenSessionJson.planTypes;
          this.authToken.userType = authTokenSessionJson.userType;
        }
      } catch (ex) {
        // TODO
      }
    }
  }

  public jwtContentTypeEncoded() {
    // create authorization header with jwt token
    const headerJson = {
      'Content-Type': 'application/x-www-form-urlencoded',
      Authorization: 'Bearer ' + this.authToken.access_token,
      uitxnid: 'WEB_v3.0_' + this.uuid(),
      impersonation: String(environment.impersonation)
    };
    if (environment.impersonation) {
      headerJson['impersonation'] = 'true';
    }
    const headers = new HttpHeaders(headerJson);
    return { headers: headers };
  }

  setDependentsList(dependentsList: DependentsModelInterface) {
    const temp: DependentsModelInterface = new DependentsResponseModel();
    dependentsList.dependents.forEach(element => {
      if (element.dependent.firstName) {
        element.dependent.firstName = element.dependent.firstName.replace(/\w\S*/g, txt => {
          return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
        });
      }

      if (element.dependent.lastName) {
        element.dependent.lastName = element.dependent.lastName.replace(/\w\S*/g, txt => {
          return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
        });
      }

      temp.dependents.push(element);
    });

    this.dependentsList = temp;
    // sessionStorage.setItem('dependentsList', JSON.stringify(this.dependentsList));
  }

  getDependentsList(): DependentsModelInterface {
    if (!this.dependentsList) {
      // this.dependentsList = JSON.parse(sessionStorage.getItem('dependentsList'));
    }
    return this.dependentsList;
  }

  logout() {
    if (this.refreshTimer) {
      clearTimeout(this.refreshTimer);
      this.refreshTimer = null;
    }
    window.sessionStorage.clear();
    //this.alertService.clearError();

    //localStorage.clear();
    this.dialogRef.closeAll();
    this.clearSession();
  }

  clearSession() {
    this.cryptoToken = null;
    this.authToken = null;
    this.useridin = null;
    this.dependentsList = null;
    this.tokenError = false;
    sessionStorage.clear();
    this.basicMemInfo = null;
    this.isUserNotMemberInCHC = false;
  }

  getBasicMemInfo(): GetMemBasicInfoResponseModelInterface {
    return this.basicMemInfo;
  }

  storeUserState(userState) {
    sessionStorage['userState'] = userState;
  }

  fetchUserState() {
    return sessionStorage['userState'];
  }

  setRtmsMode() {
    window.sessionStorage.setItem('rtmsMode', 'true');
  }

  removeRtmsMode() {
    window.sessionStorage.removeItem('rtmsMode');
  }

  setUserFullName(firstName, lastName) {
    sessionStorage['userFullName'] = firstName + ' ' + lastName;
  }

  fetchUserFullName() {
    return sessionStorage['userFullName'];
  }

  getRtmsMode() {
    const hour = momentTime.tz(new Date(), 'America/New_York').hour();
    const minute = momentTime.tz(new Date(), 'America/New_York').minute();
    const currentTime = parseFloat(parseFloat(`${hour}.${minute}`).toFixed(2));
    return currentTime >= 6 && currentTime <= 20 ? true : false;
  }

  isLogin(): boolean {
    return this.authToken ? true : false;
  }

  getMLEIndicator() {
    return sessionStorage.getItem('mleIndicator') || '';
  }

  setMLEIndicator(mleIndicator) {
    sessionStorage.setItem('mleIndicator', mleIndicator);
  }

  setMleEligibility(mleIndicator) {
    sessionStorage.setItem('mleEligibility', mleIndicator);
  }

  getMleEligibility() {
    return sessionStorage.getItem('mleEligibility');
  }

  // Fetching useridin for FAD services. Sending empty string if user isn't Authenticated
  getUseridin(): string {
    let fadUserIdIn = '';
    const scopeName = this.getScopeName();
    /* getting  mleIndicator*/

    const mleIndicator = this.getMLEIndicator();
    if (
      mleIndicator &&
      (mleIndicator === 'Y' || mleIndicator === 'lite' || mleIndicator === 'N') &&
      (scopeName === this.constantService['AUTHENTICATED_AND_VERIFIED'] || scopeName === this.constantService['AUTHENTICATED_NOT_VERIFIED'])
    ) {
      fadUserIdIn = this.useridin;
    }
    return fadUserIdIn;
  }

  isUserScopeAuthenticated() {
    const scopeName = this.getScopeName();
    if (
      scopeName === this.constantService['AUTHENTICATED_AND_VERIFIED'] ||
      scopeName === this.constantService['AUTHENTICATED_NOT_VERIFIED']
    ) {
      return true;
    } else {
      return false;
    }
  }

  isMLEIndicator() {
    const mleIndicator = this.getMLEIndicator();
    if (this.isUserScopeAuthenticated()) {
      if (mleIndicator === 'Y' || mleIndicator === 'lite') {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  isFadAccessTokenRequired(): boolean {
    const mleIndicator = this.getMLEIndicator();
    const scopeName = this.getScopeName();
    if (scopeName === 'REGISTERED-AND-VERIFIED') {
      return true;
    } else {
      return (
        (scopeName === this.constantService['AUTHENTICATED_AND_VERIFIED'] ||
          scopeName === this.constantService['AUTHENTICATED_NOT_VERIFIED']) &&
        mleIndicator &&
        (mleIndicator === 'Y' || mleIndicator === 'lite')
      );
    }
  }

  getFadHccsFlag() {
    if (sessionStorage.getItem('hccsFlag') && this.getUseridin() !== '') {
      return sessionStorage.getItem('hccsFlag') === 'false' ? false : true;
    } else if (sessionStorage.getItem('hccsFlag') && this.getUseridin() === '') {
      return null;
    } else {
      return sessionStorage.getItem('hccsFlag');
    }
  }

  updateTeleHealthData(teleHealthValue: any) {
    this.teleHealthData.next(teleHealthValue);
  }

  isAnonymousUser() {
    const userid = this.useridin;
    return userid && userid !== 'undefined' && userid !== 'null' ? false : true;
  }
}
