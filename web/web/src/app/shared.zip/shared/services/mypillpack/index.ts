import { MyPillpackService } from './my-pillpack.service';

export { MyPillpackService };
