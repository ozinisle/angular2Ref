import { DatePipe } from '@angular/common';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { of } from 'rxjs/observable/of';
import { DependentRecentRxRequestModel } from '../../../pages/medications/models/dependant-recent-rx.model';
import { GetMemBasicInfoRequestModel, GetMemBasicInfoResponseModel } from '../../../pages/medications/models/get-member-basic-info.model';
import {
  DependentRecentRxRequestModelInterface,
  DependentRecentRxResponseModelInterface
} from '../../../pages/medications/models/interfaces/dependant-recent-rx-model.interface';
import {
  GetMemBasicInfoRequestModelInterface,
  GetMemBasicInfoResponseModelInterface
} from '../../../pages/medications/models/interfaces/get-member-basic-info-model.interface';
import {
  RecentRxRequestModelInterface,
  RecentRxResponseModelInterface
} from '../../../pages/medications/models/interfaces/recent-rx-model.interface';
import { RecentRxRequestModel, RecentRxResponseModel } from '../../../pages/medications/models/recent-rx.model';
import { OTCMedications } from '../../../pages/my-pillpack/model/overthecounter.interface';
import { GlobalService } from '../../../shared/services/global.service';
import { AuthHttp } from '../auth-http.service';
import { MedicationsModelInterface } from './../../../pages/my-pillpack/model/medications.interface';
import { AuthService } from './../auth.service';
import { ConstantsService } from './../constants.service';

@Injectable()
export class MyPillpackService {
  constructor(
    private http: AuthHttp,
    private globalService: GlobalService,
    private constants: ConstantsService,
    private authService: AuthService,
    private datePipe: DatePipe
  ) {}

  getVitaminsAndOTC(query: string) {
    const vitaminsAndOtcs = this.globalService.getVitaminsAndOTCLocalObject();
    const otcs = vitaminsAndOtcs ? JSON.parse(vitaminsAndOtcs).otcs : [];
    const otcsr = otcs.filter(otcs => otcs.name.toLowerCase().indexOf(query.toLowerCase()) > -1);
    const otcsu = [];
    otcsr.forEach((item, index) => {
      if (otcsu.indexOf(item.name) == -1) {
        otcsu.push(item.name);
      }
    });
    console.log('otcs getVitaminsAndOTC unique::' + JSON.stringify(otcsu));
    return Observable.of(otcsu);
  }

  getDiscountedVitaminsAndOTCs() {
    const vitaminsAndOtcs = this.globalService.getVitaminsAndOTCLocalObject();
    const otcs = vitaminsAndOtcs ? JSON.parse(vitaminsAndOtcs).otcs : [];
    const otcsr = otcs.filter(otcs => otcs.isDiscounted == true);
    const otcsu = [];
    otcsr.forEach((item, index) => {
      if (otcsu.indexOf(item.name) == -1) {
        otcsu.push(item.name);
      }
    });
    return otcsu;
  }

  getSelectedVitaminsAndOTC(query: string, isDiscounted?: boolean) {
    console.log('otcs seleted getVitaminsAndOTC query ::' + query);
    const vitaminsAndOtcs = this.globalService.getVitaminsAndOTCLocalObject();
    let otcs = vitaminsAndOtcs ? JSON.parse(vitaminsAndOtcs).otcs : [];
    if (isDiscounted) {
      otcs = otcs.filter(otcs => otcs.name.toLowerCase() == query.toLowerCase() && otcs.isDiscounted == true);
    } else {
      otcs = otcs.filter(otcs => otcs.name.toLowerCase() == query.toLowerCase());
    }
    //otcs = otcs.filter((otcs) => otcs.name.toLowerCase() ==  query.toLowerCase() && otcs.isDiscounted==true);
    console.log('otcs seleted getVitaminsAndOTC ::' + JSON.stringify(otcs));
    return otcs;
  }

  async createPharmacyUser() {
    const req = {
      useridin: this.authService.useridin
    };

    return this.http.encryptPost(this.constants.createPharmacyUserUrl, req).toPromise();
  }

  async addMedications(req) {
    const thisResponse = this.http.encryptPost(this.constants.addMedicationsUrl, req).toPromise();
    return thisResponse;
  }

  updatePharmacyUser(req: any) {
    const thisResponse = this.http.encryptPost(this.constants.updatePharmacyUserUrl, req);
    return thisResponse;
  }

  async completePillPackHandoff(req) {
    const thisResponse = this.http.encryptPost(this.constants.completePillPackHandoff, req).toPromise();
    return thisResponse;
  }

  getMemBasicInfo(): Observable<GetMemBasicInfoResponseModelInterface> {
    if (this.authService.basicMemInfo) {
      return Observable.of(this.authService.basicMemInfo);
    }
    const request: GetMemBasicInfoRequestModelInterface = new GetMemBasicInfoRequestModel();
    request.useridin = this.authService.useridin;

    return this.http.encryptPost(this.constants.getMemBasicInfoUrl, request).map(response => {
      if (response.result < 0) {
        return new GetMemBasicInfoResponseModel();
      } else {
        const basicInfo = new GetMemBasicInfoResponseModel();
        basicInfo.rxSummary = response.getMemBasicInfoResponse;
        this.authService.basicMemInfo = basicInfo;
        return basicInfo as GetMemBasicInfoResponseModel;
      }
    });
  }

  /**
   * @name: getDependents
   * @param: { }
   * @description: Get the list of dependents for the logged in user.
   */
  getDependents() {
    return this.http.encryptPost(this.constants.dependentsUrl, {
      useridin: this.authService.useridin
    });
  }

  /**
   * @name: getMedicationsForDependentAndSelf
   * @param: { dependents: list of dependents for logged in user, default is empty }
   * @description: This method takes the list of dependents and initiate the getrecentrx service for
   * self and all depeendents
   */
  getMedicationsForSelf() {
    const handleResponse = response => {
      if (response.result < 0) {
        return new RecentRxResponseModel();
      } else {
        return response.rxSummary as RecentRxResponseModel;
      }
    };

    const request: RecentRxRequestModelInterface = new RecentRxRequestModel();
    request.useridin = this.authService.useridin;

    return this.http.encryptPost(this.constants.recentRxMedicationsUrl, request).map(handleResponse);
  }
}
