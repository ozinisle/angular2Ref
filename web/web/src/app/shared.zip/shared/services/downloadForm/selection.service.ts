import { Injectable } from '@angular/core';
import { AbstractControl } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { FormModel } from '../../../pages/fitness-and-weightloss/form-model';
import { AuthService, ConstantsService } from '../../shared.module';
import { AuthHttp } from '../auth-http.service';

@Injectable()
export class SelectionService {
  public benefitData: any;
  public selectedBenefit: any;
  public overallBenefits: any = [];
  public data: any;

  constructor(private http: AuthHttp, private constants: ConstantsService, private authService: AuthService) {}

  getYear(): Observable<any> {
    const request = {
      useridin: this.authService.useridin
    };
    return this.http.encryptPost(this.constants.selectionUrl, request, null, null, false);
  }

  setOverallBenefits(overallBenefits) {
    this.overallBenefits = overallBenefits;
    localStorage.setItem('overallBenefits', JSON.stringify(overallBenefits));
  }

  getOverallBenefits() {
    return this.overallBenefits.length >= 1 ? this.overallBenefits : JSON.parse(localStorage.getItem('overallBenefits'));
  }

  getBenefitData() {
    return this.benefitData ? this.benefitData : JSON.parse(localStorage.getItem('benefitData'));
  }

  setBenefitData(data) {
    localStorage.setItem('benefitData', JSON.stringify(data));
    this.benefitData = data;
  }

  getSelectedBenefit() {
    if (!this.selectedBenefit) {
      this.selectedBenefit = JSON.parse(localStorage.getItem('selectedBenefit'));
    }
    if (this.selectedBenefit.typeOfReimbursement === 'Weight Loss') {
      this.selectedBenefit.typeOfReimbursement = 'WEIGHTLOSS';
    }
    return this.selectedBenefit;
  }

  submitForm(data, isEHB: boolean, groupNumber: string) {
    const url = this.constants.formPost;
    const request = this.createFormData(data, isEHB, groupNumber);
    return this.http.encryptPost(url, request, null, null, false, true, true);
  }

  createFormData(formData, isEHB, groupNumber): FormModel {
    return isEHB ? this.generateEHBFormData(formData, groupNumber) : this.generateNonEHBFormData(formData, groupNumber);
  }

  generateNonEHBFormData(formData, groupNumber): FormModel {
    const benefitData = this.getBenefitData();
    const selectedBenefit = this.getSelectedBenefit();
    const selectedMember = formData.member;
    selectedMember.groupNumber = groupNumber;
    const benefitByYear = benefitData.benefits.find(benefit => benefit.year === selectedBenefit.year);
    const requestData: any = {
      useridin: this.authService.useridin,
      claim: {
        year: selectedBenefit.year,
        type: selectedBenefit.typeOfReimbursement.toUpperCase(),
        forMember: selectedMember,
        isEHB: false,
        totalAmount: formData.totalrequestamount,
        planCancelDate: benefitByYear ? benefitByYear.cancelDate : "",
        collateralName: this.getCollateralName(selectedBenefit.typeOfReimbursement, benefitByYear)
      },
      programInformation: {
        programName: formData.programName,
        address: formData.address,
        state: formData.state,
        zip: formData.zip.toString(),
        phoneNumber: formData.phoneNumber
      },
      images: formData.images
    };

    if (formData.email) {
      requestData.claim.subscriberAlternateEmail = formData.email;
    }
    if (formData.additionalemail) {
      requestData.claim.memberAlternateEmail = formData.additionalemail;
    }

    return requestData;
  }

  generateEHBFormData(formData, groupNumber): FormModel {
    if (!formData.fitnessType) {
      formData.fitnessType = 'MONTHLY';
    }
    if (!formData.fitnessCostAmount) {
      formData.fitnessCostAmount = 0;
    }
    if (!formData.annualFee) {
      formData.annualFee = 0;
    }

    const benefitData = this.getBenefitData();
    const selectedBenefit = this.getSelectedBenefit();
    const benefitByYear = benefitData.benefits.find(benefit => benefit.year === selectedBenefit.year);
    const requestData: any = {
      useridin: this.authService.useridin,
      claim: {
        year: selectedBenefit.year,
        type: selectedBenefit.typeOfReimbursement.toUpperCase(),
        forMember: formData.member,
        groupNumber: groupNumber,
        isEHB: true,
        totalAmount: formData.totalrequestamount,
        planCancelDate: benefitByYear ? benefitByYear.cancelDate : "",
        collateralName: this.getCollateralName(selectedBenefit.typeOfReimbursement, benefitByYear),
        category: formData.fitnessType,
        unitAmount: formData.fitnessCostAmount,
        annualFeeAmount: formData.annualFee
      },
      programInformation: {
        programName: formData.programName,
        address: formData.address,
        state: formData.state,
        zip: formData.zip,
        phoneNumber: formData.phoneNumber
      },
      images: formData.images
    };
    if (formData.email) {
      requestData.claim.subscriberAlternateEmail = formData.email;
    }
    if (formData.additionalemail) {
      requestData.claim.memberAlternateEmail = formData.additionalemail;
    }
    return requestData;
  }

  getCollateralName(typeOfReimbursement: string, benefitData) {
    return typeOfReimbursement === 'Fitness'
      ? (benefitData && benefitData.fitness ? benefitData.fitness.collateralName : "")
      : (benefitData && benefitData.weightloss ? benefitData.weightloss.collateralName: "");
  }

  setBenefitModelData(data) {
    localStorage.setItem('data', JSON.stringify(data));
    this.data = data;
  }

  getBenefitModelData() {
    return this.data ? this.data : JSON.parse(localStorage.getItem('data'));
  }

  setSelectedBenefitData(selectedBenefit) {
    this.selectedBenefit = selectedBenefit;
    localStorage.setItem('selectedBenefit', JSON.stringify(selectedBenefit));
  }

  checkAnnualFee() {
    return (control: AbstractControl): { [key: string]: any } => {
      let hasError = false;
      if (control.value && control.value > 0 && control.value < 1) {
        hasError = true;
      }
      return hasError ? { minValue: { value: true } } : null;
    };
  }
}
