import { Injectable, NgZone } from "@angular/core";
import * as LRSetup from 'logrocket/setup';
import { environment } from "../../../environments/environment";

@Injectable()
export class LogRocketService {

    private logRocket;

    constructor(
        private ngZone: NgZone
    ) { }

    init() {
        this.ngZone.runOutsideAngular(() => {
            this.logRocket = LRSetup({
                sdkServer: environment.LogRocketEndPoint,
                ingestServer: environment.LogRocketEndPoint
            });
            this.logRocket.init(environment.LogRocketAppID, {
                dom: { baseHref: 'https://' + location.hostname },
                console: {
                    isEnabled: false,
                }
            });
        });
    }

    identify(userId, userInfo) {
        if (this.logRocket) {
            this.logRocket.identify(userId, userInfo);
        }
    }
}