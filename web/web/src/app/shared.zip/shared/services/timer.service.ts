import { Injectable, NgZone } from '@angular/core';

@Injectable()
export class TimerService {
  constructor(private ngZone: NgZone) {}

  /**
   * Sets an interval outside of the Angular zone, preventing it from destabilizing
   * the zone during Protractor tests.
   *
   * @param callback
   *   The code to run inside the Angular zone after each interval.
   * @param ms
   *   The delay, in milliseconds.
   * @param args
   *   Argument values to pass to the callback.
   */
  public setInterval(callback: (...args: any[]) => void, ms: number, ...args: any[]): number {
    return this.ngZone.runOutsideAngular(() => window.setInterval(() => this.ngZone.run(() => callback(...args)), ms));
  }

  /**
   * Sets a timer outside of the Angular zone, preventing it from destabilizing
   * the zone during Protractor tests.
   *
   * @param callback
   *   The code to run inside the Angular zone when the timer runs out.
   * @param ms
   *   The delay, in milliseconds.
   * @param args
   *   Argument values to pass to the callback.
   */
  public setTimeout(callback: (...args: any[]) => void, ms: number, ...args: any[]): number {
    return this.ngZone.runOutsideAngular(() => window.setTimeout(() => this.ngZone.run(() => callback(...args)), ms));
  }
}
