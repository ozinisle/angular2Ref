export const MENULIST = {
  plans: [
    {
      planTitle: 'Using My Plan',
      linkUrl: '',
      subCategory: [
        {
          menuName: 'Manage My Plan',
          categoryUrl: ''
        },
        {
          menuName: 'Doctors and Hospitals',
          categoryUrl: ''
        },
        {
          menuName: 'Discounts and Savings',
          categoryUrl: ''
        }
      ]
    },
    {
      planTitle: 'Amazing Spiderman',
      linkUrl: '',
      subCategory: [
        {
          menuName: 'Vegeta',
          categoryUrl: ''
        },
        {
          menuName: 'Picolo',
          categoryUrl: ''
        },
        {
          menuName: 'Trunks',
          categoryUrl: ''
        }
      ]
    }
  ]
};
