import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { HomePageInfoModel } from '../../pages/landing/landing.model';
import { LandingService } from '../../pages/landing/landing.service';
import { ProfileService } from '../services/myprofile/profile.service';
import { AuthService } from '../shared.module';

@Injectable()
export class HomepageResolver implements Resolve<Observable<HomePageInfoModel | {}>> {
  isRegisteredUser: boolean;

  constructor(private landingService: LandingService, private profileService: ProfileService, private authService: AuthService) {}

  resolve(): Observable<HomePageInfoModel | {}> {
    return this.fetchHomePageInfo();
  }

  fetchHomePageInfo() {
    this.isRegisteredUser = this.authService.getScopeName().includes('REGISTERED');
    return this.profileService.fetchProfileInfo().switchMap(() => {
      const profileInfo = this.profileService.getProfile();
      //KLO-2023
      //Fetch the member profile only if already not available
      if (!profileInfo) {
        this.profileService.fetchProfileInfo();
      }
      if (!this.isRegisteredUser) {
        return this.landingService.getHomePageInfo();
      } else {
        return Observable.of({});
      }
    });
  }
}
