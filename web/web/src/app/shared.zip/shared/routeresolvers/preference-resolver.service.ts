import { Injectable } from '@angular/core';
import { PreferencesService } from '../services/myprofile/preferences.service';

@Injectable()
export class PreferenceResolverService {

  constructor(private preferenceService: PreferencesService) { }

  resolve() {
    return this.preferenceService.fetchPreference().map(res => {
      if (res.message) {
        return res;
      } else {
        return false;
      }
    });
  }
}
