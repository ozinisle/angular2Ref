import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { EobsService } from '../../pages/myeobs/eobs.service';
import { DependantsService } from '../services/dependant.service';
import { GlobalService } from '../services/global.service';
import { AuthService } from '../shared.module';

@Injectable()
export class MyEobsResolverService implements Resolve<Observable<any>> {
  constructor(
    public dependantsService: DependantsService,
    public authService: AuthService,
    public globalService: GlobalService,
    private eobsService: EobsService
  ) {}

  resolve() {
    return this.getEobList();
  }

  getEobList() {
    const obs = [];
    obs.push(this.eobsService.getEobList_resolver());
    return forkJoin(obs);
  }
}
