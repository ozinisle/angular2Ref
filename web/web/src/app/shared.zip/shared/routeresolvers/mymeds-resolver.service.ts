import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { DependentRecentRxResponseModelInterface } from '../../pages/medications/models/interfaces/dependant-recent-rx-model.interface';
import { MyAccountService } from '../../pages/myaccount/myaccount.service';
import { AuthService, ConstantsService } from '../../shared/shared.module';
import { AuthHttp } from '../services/auth-http.service';
import { DependantsService } from '../services/dependant.service';
import { GlobalService } from '../services/global.service';
import { MedicationsService } from '../services/medications/medications.service';

@Injectable()
export class MymedsResolverService {
  observer: Array<Observable<DependentRecentRxResponseModelInterface>> = [];

  constructor(
    public dependantsService: DependantsService,
    public authService: AuthService,
    public authHttp: AuthHttp,
    public globalService: GlobalService,
    private medicationsService: MedicationsService,
    private constantService: ConstantsService,
    private myAccountService: MyAccountService
  ) {}

  async resolve() {
    await this.getAllMedications();
    //start: Added to facilitate a solution for the new request https://bcbsma.atlassian.net/browse/KLO-470
    await this.fetchMyAccountInfoInCache();
    //end: Added to facilitate a solution for the new request https://bcbsma.atlassian.net/browse/KLO-470
    console.log('Fetch All medications', this.observer);
    return forkJoin(this.observer)
      .map(results => ({
        MemBasicInfo: results[0],
        MedRecords: results.slice(1)
      }))
      .toPromise();
  }

  async getAllMedications() {
    const obs: Array<Observable<any>> = [];
    const hasDependents = this.authService.authToken && this.authService.authToken.hasDependents;
    if (hasDependents === 'true') {
      const depependentResponse = await this.getDependents();
      this.dependantsService.setDependentList(depependentResponse);
    }
    const dependantsInfo = this.authService.getDependentsList();
    obs.push(this.medicationsService.getMemBasicInfo());
    obs.push(this.medicationsService.getMedications());
    if (dependantsInfo && dependantsInfo.dependents) {
      dependantsInfo.dependents.forEach(dependant =>
        obs.push(this.dependantsService.loadDependantRecords(dependant.dependent.depId, this.constantService.depMedicationsUrl))
      );
    }
    this.observer = obs;
  }

  async getDependents() {
    const depependentInfo = await this.dependantsService.fetchDependentsList().toPromise();
    return depependentInfo;
  }

  private async fetchMyAccountInfoInCache() {
    /**
     * Added to facilitate a solution for the new request https://bcbsma.atlassian.net/browse/KLO-470
     */
    const cachedMyAccountInfo = sessionStorage.getItem('myAccountInfo');
    if (!cachedMyAccountInfo) {
      const isRegisteredUser = this.authService.getScopeName().includes('REGISTERED');
      if (!isRegisteredUser) {
        const myAccountInfo = await forkJoin([this.myAccountService.getAccountInfo()]).toPromise();

        sessionStorage.setItem('myAccountInfo', JSON.stringify(myAccountInfo));
      }
    }
  }
}
