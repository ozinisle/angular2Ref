import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import * as moment from 'moment';
import { Observable } from 'rxjs/Observable';
import { PlanBenefitsListResponseModelInterface } from '../../pages/myplans/models/interfaces/plan-benefits-list-model.interface';
import { MyplansService } from '../../pages/myplans/myplans.service';
import { AuthService } from '../services/auth.service';
import { GlobalService } from '../services/global.service';
@Injectable()
export class MyPlansResolverService implements Resolve<Observable<PlanBenefitsListResponseModelInterface | {}>> {
  plan: PlanBenefitsListResponseModelInterface;
  date: string;
  constructor(public authService: AuthService, public globalService: GlobalService, public plansService: MyplansService) {}

  resolve() {

  const selectedPlanDetails = JSON.parse(sessionStorage.getItem('selectedPlanDetails'));
  const defaultIPAPlan = JSON.parse(sessionStorage.getItem('defaultIPAPlan'));

    this.date = (selectedPlanDetails &&
      defaultIPAPlan &&
      selectedPlanDetails.planEffectiveDate &&
      defaultIPAPlan.cardMemId !== selectedPlanDetails.cardMemId)
      ? moment(selectedPlanDetails.planEffectiveDate).format('YYYY-MM-DD')
        : moment().format('YYYY-MM-DD');
    return this.plansService.getPlansData(this.date).catch(() => {
      return Observable.empty();
    });
  }
}
