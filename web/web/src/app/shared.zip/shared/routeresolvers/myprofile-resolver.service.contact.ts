import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { GetMemberProfileResponseModel } from '../../pages/my-profile/models/get-member-profile-request.model';
import { ProfileService } from '../services/myprofile/profile.service';

@Injectable()
export class MyprofileResolverServiceContact implements Resolve<Observable<GetMemberProfileResponseModel>> {
  constructor(private profileService: ProfileService, private router: Router) {}

  resolve() {
    return this.fetchProfileInfoV2();
  }

  fetchProfileInfoV2() {
    return this.profileService.fetchProfileInfoV2();
  }
}
