import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { MAT_DIALOG_DATA } from '@angular/material';
import { MaterialModule } from '../../material.module';

declare let $: any;

@Component({
  selector: 'app-menu-dialog',
  templateUrl: './menu-dialog.component.html',
  styleUrls: ['./menu-dialog.component.scss']
})
export class MenuDialogComponent implements OnInit {
  welcome: string;
  games: [
    {
      game: string;
      platform: string;
      release: string;
    }
  ];
  constructor(public thisDialogRef: MatDialogRef<MenuDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: string) {
    this.welcome = 'Display List using ngFor in Angular 2';
  }

  ngOnInit() {}

  onCloseConfirm() {
    this.thisDialogRef.close('Confirm');
  }

  onCloseCancel() {
    this.thisDialogRef.close('Cancel');
  }

  closeMobileMenu(e) {
    this.thisDialogRef.close('Close');
  }
}
