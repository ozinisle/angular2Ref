import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class AppModalsProfileService {
  private preferenceDataChange = new BehaviorSubject<any>(null);
  public preferenceDataChange$ = this.preferenceDataChange;

  constructor() {}

  setDataChange() {
    this.preferenceDataChange.next(new Date().toString());
  }
}
