import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class AppModalsService {
  private appmodalDataChange = new BehaviorSubject<any>(null);
  public appmodalDataChange$ = this.appmodalDataChange.asObservable();

  constructor() {}

  setModalDataChange() {
    this.appmodalDataChange.next(new Date().toString());
  }
}
