import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../../shared/services/validation.service';
import { AlertService } from '../services/alert.service';
import { AuthHttp } from '../services/auth-http.service';
import { AuthService } from '../services/auth.service';
import { ConstantsService } from '../services/constants.service';

declare let $: any;

@Component({
  selector: 'app-modals',
  templateUrl: './appmodals.component.html',
  styleUrls: ['./appmodals.component.scss']
})
export class AppmodalsComponent implements OnInit {
  profile: any;
  currentPage: string;
  location: string;
  codeMask = { mask: this.validationService.numericMask, guide: false };

  constructor(
    private router: Router,
    private authService: AuthService,
    private alertService: AlertService,
    private constants: ConstantsService,
    private authHttp: AuthHttp,
    private validationService: ValidationService
  ) {
    router.events.subscribe((data: any) => {
      this.currentPage = data.url === '/claims' ? 'Claims' : 'Home Page';
    });
  }

  openSsoIsiLink() {
    this.closeModal();
    if (!this.authService.impersonation()) {
      window.open('/sso/expressscript', '_blank');
    }
  }

  openEyeMedExtLink() {
    this.closeModal();
    if (!this.authService.impersonation()) {
      window.open(this.constants.eyeMedNavLink, '_blank');
    }
  }

  openSsoAlgLink() {
    this.closeModal();
    if (!this.authService.impersonation()) {
      window.open('/sso/alegeus', '_blank');
    }
  }

  openSsoEbillingLink() {
    this.closeModal();
    if (!this.authService.impersonation()) {
      window.open('sso/ebilling', '_blank');
    }
  }

  openSsoHeqLink() {
    this.closeModal();
    if (!this.authService.impersonation()) {
      window.open('/sso/heathequity', '_blank');
    }
  }
  closeSsoHeqLink() {
    event.stopPropagation();
    $('#openSsoHeqSite').modal('close');
  }
  closeSsoAlgLink() {
    event.stopPropagation();
    $('#openSsoAlgSite').modal('close');
    localStorage.removeItem('targetContext');
  }
  closeSsoEbilling() {
    event.stopPropagation();
    $('#openSsoEbilling').modal('close');
  }

  openSsoFadLink() {
    this.closeModal();
    if (!this.authService.impersonation()) {
      window.open('/sso/vitals', '_blank');
    }
  }

  closeSsoFadLink() {
    event.stopPropagation();
    $('#openSsoFadSite').modal('close');
  }
  openPswLink() {
    this.closeModal();
    if (!this.authService.impersonation()) {
      window.open('sso/medicare-plan-selection-wizard', '_blank');
    }
  }
  closePsw() {
    event.stopPropagation();
    $('#openPsw').modal('close');
  }

  ngOnInit() {
    $('#tokenExpiryModal').modal({ dismissible: false });
    $('#requestTimeoutError').modal({ dismissible: true });
    $('#openOtherPartySite').modal({ dismissible: true });
    $('#openPillPackSite').modal({ dismissible: true });
    $('#internetconnection').modal({ dismissible: true });
    $('#globalError').modal({ dismissible: true });
    $('#consentToReceiveCommunications').modal({ dismissible: true });
    $('#openSsoEsiSite').modal({ dismissible: true });
    $('#openSsoFadSite').modal({ dismissible: true });
    $('#openTaxformFalse').modal({ dismissible: true });
    $('#openLearnToLive').modal({ dismissible: true });
    $('#openMentalHealthLink').modal({ dismissible: true });
    $('#wellnessRewardsProgram').modal({ dismissible: true });
    $('#openSsoAlgSite').modal({ dismissible: true });
    $('#openSsoEbilling').modal({ dismissable: true });
    $('#openSsoHeqSite').modal({ dismissible: true });
    $('#openEyeMedExtLink').modal({ dismissible: true });
    $('#openPsw').modal({ dismissable: true });
    $('#openOtcCvsLink').modal({ dismissable: true });
  }

  reset() {
    this.alertService.clearError();
    this.authHttp.hideSpinnerLoading();
    this.authService.logout();
    this.closeTokenError();
    this.router.navigate(['./login']);
  }

  close() {
    $('#requestTimeoutError').modal('close');
  }

  closeModal() {
    $('#openTaxformFalse').modal('close');
    $('#openSsoFadSite').modal('close');
    $('#openPillPackSite').modal('close');
    $('#openOtherPartySite').modal('close');
    $('#openLearnToLive').modal('close');
    $('#openMentalHealthLink').modal('close');
    $('#wellnessRewardsProgram').modal('close');
    $('#openSsoAlgSite').modal('close');
    $('#openSsoEbilling').modal('close');
    $('#openSsoHeqSite').modal('close');
    $('#openEyeMedExtLink').modal('close');
    $('#openPsw').modal('close');
    $('#openOtcCvsLink').modal('close');
  }

  communicationModal() {
    $('#consentToReceiveCommunications').modal('close');
  }

  modalClose() {
    $('#requestTimeoutError').modal('close');
  }

  openbluehome() {
    this.closeModal();
    window.open(this.constants.drupalHomeUrl, '_self');
  }

  openHome() {
    this.closeTokenError();
    window.open(this.constants.drupalHomeUrl, '_self');
  }

  closeTokenError() {
    $('#tokenExpiryModal').modal('close');
  }

  openLearnToLive() {
    this.closeModal();
    const postLoginInfo = JSON.parse(sessionStorage.getItem('postLoginInfo'));
    if (postLoginInfo && postLoginInfo.wellnessPrograms) {
      window.open(postLoginInfo.wellnessPrograms[0].url, '_blank');
    }
  }

  openCVSLink() {
    this.closeModal();
    window.open(this.constants.cvsLink, '_blank');
  }

  openMentalHealth() {
    this.closeModal();
    const memberLink = sessionStorage.getItem('memberLinkLearnToLive');
    if (memberLink && memberLink !== '') {
      window.open(memberLink, '_blank');
    }
  }

  openPillPackLink() {
    this.closeModal();
    if (sessionStorage.getItem('consentLink')) {
      const consentLink = sessionStorage.getItem('consentLink');
      if (consentLink === 'https://www.pillpack.com') {
        window.open(consentLink, '_self');
      } else {
        window.open(consentLink, '_blank');
      }
    }
  }

  openWellnessRewardsProgram() {
    this.closeModal();
    const wellnessVendorCd = sessionStorage.getItem('wellnessVendorCd');
    if (wellnessVendorCd === 'VP') {
      if (environment.featureVirginPulseSsoEnabled === true) {
        window.open('/sso/virgin_pulse', '_blank');
      } else {
        window.open('https://www.join.virginpulse.com/wellness', '_blank');
      }
    }
  }

  closeSsoIsiLink() {
    event.stopPropagation();
    $('#openSsoEsiSite').modal('close');
  }

  closeEyeMedExtLink() {
    event.stopPropagation();
    $('#openEyeMedExtLink').modal('close');
  }

  closePillPackModal() {
    event.stopPropagation();
    $('#openPillPackSite').modal('close');
  }
  closeWellnessRewardsProgramModal() {
    event.stopPropagation();
    $('#wellnessRewardsProgram').modal('close');
  }

  reloadPage() {
    window.location.reload();
  }
}
