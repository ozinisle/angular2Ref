import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from '../../../../environments/environment';
import { AuthService } from '../../services/auth.service';



@Component({
  selector: 'app-authenticated-home',
  templateUrl: './AuthenticatedLayout.component.html',
  styleUrls: ['./AuthenticatedLayout.component.scss']
})

export class AuthenticatedLayoutComponent {

  enableLiveChat: boolean = environment.enableLiveChat
  isAuthUser: boolean;

  constructor(public router: Router,
    public authService: AuthService) {
  }

  ngOnInit() {
    this.isAuthUser = this.authService.getScopeName() !== 'REGISTERED-AND-VERIFIED' ? true : false;
  }

  public isAnonymousUser() {
    return this.authService.isAnonymousUser();
  }

}
