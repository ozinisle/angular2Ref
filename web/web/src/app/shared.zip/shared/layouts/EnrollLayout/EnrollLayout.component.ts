import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enrollLayout-home',
  templateUrl: './EnrollLayout.component.html',
  styleUrls: ['./EnrollLayout.component.scss']
})
export class EnrollLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
