import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { EnrollLayoutComponent } from './EnrollLayout.component';

describe('EnrollLayoutComponent', () => {
  let component: EnrollLayoutComponent;
  let fixture: ComponentFixture<EnrollLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [EnrollLayoutComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnrollLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
