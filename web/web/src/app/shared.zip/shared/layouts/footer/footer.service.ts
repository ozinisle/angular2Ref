import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../../../environments/environment';
import { FadConstants } from '../../../pages/fad/constants/fad.constants';
import { FooterGlobalModel } from '../../models/footerGlobalModel';
import { FooterLinkModel } from '../../models/footerLinkModel';
import { GetVitalsDataUpdatesRequestModel, GetVitalsDataUpdatesResponseModel, MultiLingualFooterModel } from '../../models/multilingual-footer.model';
import { AuthHttp } from '../../services/auth-http.service';
import { AuthService } from '../../services/auth.service';
import { ConstantsService } from '../../services/constants.service';

@Injectable()
export class FooterService {
  public globalFooterData;
  public multiLingualFooterData;
  public footerLinksData: any;

  constructor(private http: AuthHttp, private constants: ConstantsService, public authService: AuthService) { }

  getGlobalFooter(): Observable<FooterGlobalModel[]> {
    const targetUrl = environment.drupalTestUrl + '/global/brand-footer';
    return this.http.get<FooterGlobalModel[]>(targetUrl);
  }

  getMultiLingualFooter(): Observable<MultiLingualFooterModel[]> {
    const targetUrl = environment.drupalTestUrl + '/multilingual-footer';
    return this.http.get<MultiLingualFooterModel[]>(targetUrl);
  }

  getFooterLinks(): Observable<FooterLinkModel[]> {
    const targetUrl = environment.drupalTestUrl + '/api/menu_items/footermenu2?_format=json';
    return this.http.get<FooterLinkModel[]>(targetUrl);
  }

  getFadDataUpdates(): Observable<GetVitalsDataUpdatesResponseModel> {
    const getVitalsDataUpdatesParams: GetVitalsDataUpdatesRequestModel = new GetVitalsDataUpdatesRequestModel();
    const authUserId = this.authService.useridin;
    console.log(authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null);
    if (authUserId && authUserId !== 'undefined' && authUserId !== 'null' && authUserId !== null) {
      getVitalsDataUpdatesParams.useridin = this.authService.useridin;
    }
    if (this.authService.getFadHccsFlag() !== null) {
      getVitalsDataUpdatesParams['hccsFlag'] = this.authService.getFadHccsFlag();
    }
    return this.http.encryptPost(FadConstants.urls.fadGetFadDataUpdates, getVitalsDataUpdatesParams, '', '', false).map(response => {
      return response as GetVitalsDataUpdatesResponseModel;
    });
  }
}
