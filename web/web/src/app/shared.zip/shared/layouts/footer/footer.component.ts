import { Component, OnInit, HostListener } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { environment } from '../../../../environments/environment';
import { SendProviderInquiryDialogConfirmation_InputDataInterface, SendProviderInquiryDialog_InputDataInterface } from '../../../pages/fad/modals/interfaces/send-provider-inquiry-dialogs.interface';
import { SendProviderInquiryDialogConfirmation_InputData, SendProviderInquiryDialog_InputData } from '../../../pages/fad/modals/send-provider-inquiry-dialogs.model';
import { SendProviderEmailInquiryConfirmationPopupComponent } from '../../../pages/fad/send-provider-email-inquiry-confirmation-popup/send-provider-email-inquiry-confirmation-popup.component';
import { SendProviderEmailInquiryComponent } from '../../../pages/fad/send-provider-email-inquiry/send-provider-email-inquiry.component';
import { BcbsmaerrorHandlerService } from '../../../shared/services/bcbsmaerror-handler.service';
import { FooterGlobalModel } from '../../models/footerGlobalModel';
import { FooterLinkModel } from '../../models/footerLinkModel';
import { MultiLingualFooterModel, SessionFadDataUpdatesModel } from '../../models/multilingual-footer.model';
import { AuthService } from '../../services/auth.service';
import { FooterService } from './footer.service';

declare let $: any;

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  public isAuthenticated = true;
  isLogin = false;
  currentYear: any = '';
  langTranslation: any;
  footerGlobalLinks: FooterGlobalModel;
  multiLingualFooter: MultiLingualFooterModel;
  footerLinks: FooterLinkModel[];
  drupalUrl: string = environment.drupalTestUrl;
  // tslint:disable-next-line:max-line-length
  langFooterText: Object;
  isFadModule = false;
  vitalsLastDateUpdate: string;
  href: any;
  public fadModuleBeingDisplayedFlag: boolean = false;

  constructor(
    private authService: AuthService,
    private footerService: FooterService,
    private route: ActivatedRoute,
    private router: Router,
    private bcbsmaErrorHandler: BcbsmaerrorHandlerService,
    public dialogRef: MatDialog
  ) { }

  ngOnInit() {
    $('#openOtherPartySiteWithExternalLink').modal({ dismissible: true });
    this.authService.getScopeName() === 'AUTHENTICATED-AND-VERIFIED' ? (this.isLogin = true) : (this.isLogin = false);
    this.currentYear = new Date().getFullYear();
    if (this.route.snapshot.data.menu === undefined) {
      if (this.authService.authToken && this.authService.authToken.scopename) {
        this.isAuthenticated = true;
      } else {
        this.isAuthenticated = false;
      }
    } else {
      this.isAuthenticated = this.route.snapshot.data.menu;
    }

    this.setGlobalFooter();
    this.setMultiLanguageFooter();
    this.setFooterLinks();
    this.setFADFooterFromURL(); // only for FAD Module

    if (this.router.url.includes('/fad')) {
      this.fadModuleBeingDisplayedFlag = true;
    } else {
      this.fadModuleBeingDisplayedFlag = false;
    }
  }

  // get global footer links
  public setGlobalFooter(): void {
    if (!this.footerService.globalFooterData) {
      this.footerService.getGlobalFooter().subscribe(data => {
        if (data && data.length) {
          this.footerGlobalLinks = data[0];
          this.footerService.globalFooterData = data[0];
        }
      });
    } else {
      this.footerGlobalLinks = this.footerService.globalFooterData;
    }
  }

  // get multiLanguage Footer Content MultiLingualFooterModel
  public setMultiLanguageFooter(): void {
    if (!this.footerService.multiLingualFooterData) {
      this.footerService.getMultiLingualFooter().subscribe(data => {
        if (data && data.length) {
          this.footerService.multiLingualFooterData = data;
          this.langTranslation = data;
          this.multiLingualFooter = this.langTranslation.find(lang => {
            return Object.values(lang).includes('English') ? lang : '';
          });
          this.langFooterText = this.multiLingualFooter.Footertext;
        }
      });
    } else {
      this.langTranslation = this.footerService.multiLingualFooterData;
      this.multiLingualFooter = this.langTranslation.find(lang => {
        return Object.values(lang).includes('English') ? lang : '';
      });
      this.langFooterText = this.multiLingualFooter.Footertext;
    }
  }

  // get footer links
  public setFooterLinks(): void {
    if (!this.footerService.footerLinksData) {
      this.footerService.getFooterLinks().subscribe(footerdata => {
        if (footerdata && footerdata.length) {
          this.footerLinks = footerdata;
          this.footerService.footerLinksData = footerdata;
        }
      });
    } else {
      this.footerLinks = this.footerService.footerLinksData;
    }
  }

  // get selected Language for Footer Text
  public selectLang(link) {
    this.langFooterText = link.Footertext;
  }

  public openOtherPartySite(href) {
    $('#openOtherPartySiteWithExternalLink').modal('open');
    console.log('opened modal and href value', href);
    this.href = href;
  }
  continue() {
    $('#openOtherPartySiteWithExternalLink').modal('close');
    this.openUrlinNewWindow(this.href);
  }
  closeModals() {
    $('#openOtherPartySiteWithExternalLink').modal('close');
  }
  openUrlinNewWindow(url) {
    if (url) {
      window.open(url, '_blank');
    }
  }
  // check for FAD - Vitals module
  public setFADFooterFromURL() {
    if (this.router.url.includes('/fad')) {
      this.isFadModule = true;

      this.checkFadDateUpdates();
    }
  }

  /**
   * Check for Fad Last updated date
   */
  public checkFadDateUpdates() {
    const cachedFadDataUpdatesModel = JSON.parse(sessionStorage.getItem('FadLastDataUpdates')) as SessionFadDataUpdatesModel;

    if (cachedFadDataUpdatesModel && cachedFadDataUpdatesModel.lastUpdateDate === moment().format('YYYY-MM-DD')) {

      this.vitalsLastDateUpdate = moment(cachedFadDataUpdatesModel.dataLoadedDate).format('LL');
    } else {

      this.footerService.getFadDataUpdates().subscribe(
        responseData => {
          if (responseData && responseData.dataLoadedDate && moment(responseData.dataLoadedDate).isValid()) {
            const sessionFadDataUpdatesParam = new SessionFadDataUpdatesModel();
            sessionFadDataUpdatesParam.dataLoadedDate = responseData.dataLoadedDate;
            sessionFadDataUpdatesParam.lastUpdateDate = moment().format('YYYY-MM-DD');

            sessionStorage.setItem('FadLastDataUpdates', JSON.stringify(sessionFadDataUpdatesParam));

            this.vitalsLastDateUpdate = moment(responseData.dataLoadedDate).format('LL');
          }
        },
        error => {
          console.log(error);
        }
      );
    }
  }

  public sendProviderInquiryEmail() {
    try {
      if (this.authService.impersonation()) {
        return;
      }
      const suggestAnEditDialogInput: SendProviderInquiryDialog_InputDataInterface = new SendProviderInquiryDialog_InputData();
      suggestAnEditDialogInput.subject = ''

      let dialogRef = this.dialogRef.open(SendProviderEmailInquiryComponent, {
        data: suggestAnEditDialogInput
      });

      dialogRef.afterClosed().subscribe(result => {

        if (result) {
          if (result.dialogDiscardedFlag) {
            return;
          }

          let confirmationDialogRef: MatDialogRef<SendProviderEmailInquiryConfirmationPopupComponent, any> = null;
          if (result.result === 0) {

            const successMessageDialog: SendProviderInquiryDialogConfirmation_InputDataInterface = new SendProviderInquiryDialogConfirmation_InputData();
            successMessageDialog.emailId = result.confirmationToBeSentTo;
            confirmationDialogRef = this.dialogRef.open(SendProviderEmailInquiryConfirmationPopupComponent, {
              data: successMessageDialog
            });
          } else if (result.result < 0 || result.connectionFailureError) {

            const failureMessageDialog: SendProviderInquiryDialogConfirmation_InputDataInterface = new SendProviderInquiryDialogConfirmation_InputData();
            failureMessageDialog.errorFlag = true;
            confirmationDialogRef = this.dialogRef.open(SendProviderEmailInquiryConfirmationPopupComponent, {
              data: failureMessageDialog
            });
          }
        }
      });

    } catch (exception) {
      console.log(exception)
      this.bcbsmaErrorHandler.logError(
        exception,
        'SendProviderEmailInquiryComponent',
        'SendProviderEmailInquiryComponent',
        'openSuggestAnEditDialog'
      );
    }
  }
}
