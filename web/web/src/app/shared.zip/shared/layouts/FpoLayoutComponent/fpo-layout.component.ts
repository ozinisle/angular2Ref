import { AfterViewInit, Component, EventEmitter, HostListener, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from '../../../../environments/environment';
import { ConstantsService } from '../../services/constants.service';
import { FpocontentService } from '../../services/fpocontent.service';
declare let $: any;

@Component({
  selector: 'app-fpo-layout',
  templateUrl: './fpo-layout.component.html',
  styleUrls: ['./fpo-layout.component.scss']
})
export class FpoLayoutComponent implements AfterViewInit, OnInit {
  @Input() targetUrl: string;
  @Input() toolTipdataPlans: object;
  @Input() isplandetails: boolean;
  @Input() displayCategory: string;
  @Input() layout = '';
  @Output() closePullTextEmitter = new EventEmitter();
  @Input() showTitle = false;
  @Input() benefitPage: boolean;
  @Input() hasCvsLinkFlag: boolean;
  fpocontentData: any;
  ismobile = false;
  mobileViewPort = 992;
  fontawesomeIcon = '';
  appstoreImageUrl = '';
  bodyContent = '';
  fpoVideoSourceUrl: string;
  drupalvideolayout: string;
  _temp: string;
  enableOTCLink : boolean;

  //DOAIP-4627
  bodyFromDrupalBeforeUrl: string;
  bodyFromDrupalAfterUrl: string;
  bodyFromDrupalWithinUrl: string;
  urlFromDrupal: string;

  constructor(private fpocontentService: FpocontentService, private constantsService: ConstantsService, private router: Router) {
    this.drupalvideolayout = this.fpocontentService.generateRandomNum();
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.ismobile = event.target.innerWidth <= this.mobileViewPort;
  }
  ngAfterViewInit() {
    $(this._temp).modal({
      dismissible: true, // Modal can be dismissed by clicking outside of the modal
      opacity: 0.5, // Opacity of modal background
      inDuration: 300, // Transition in duration
      outDuration: 200, // Transition out duration
      startingTop: '0%', // Starting top style attribute
      endingTop: '0%', // Ending top style attribute
      ready: (modal, trigger) => {
        // Callback for Modal open. Modal and trigger parameters available.
        console.log(modal, trigger);
        // this.promoService.playPauseVideo($('#imageVideoModal video'), true);
      },
      complete: () => {}
    });
  }
  ngOnInit() {
    if (this.toolTipdataPlans && this.isplandetails) {
      this.prepareDrupalContent(this.toolTipdataPlans);
    } else {
      this.fpocontentService.fetchContent(this.targetUrl).subscribe(response => {
        this.prepareDrupalContent(response);
      });
    }
    this._temp = '#' + this.drupalvideolayout;
    this.enableOTCLink = environment.enableOTCLink;
  }

  prepareDrupalContent(response?) {
    if (response && response[0]) {
      this.fpocontentData = response[0];
      this.getDetails();
    }
  }
  getDetails() {
    this.fpocontentData.RegularImages = this.fpocontentData.RegularImages
      ? environment.drupalTestUrl + this.fpocontentData.RegularImages
      : this.fpocontentData.RegularImages;
    this.fpocontentData.MobileImages = this.fpocontentData.MobileImages
      ? environment.drupalTestUrl + this.fpocontentData.MobileImages
      : this.fpocontentData.MobileImages;
    this.fontawesomeIcon = this.fpocontentData.FontawesomeIconUnicode
      ? '<i class="fa">&#x' + this.fpocontentData.FontawesomeIconUnicode + ';</i>'
      : '';
    let url: string = this.fpocontentData.AppstoreIcon;
    url = url.replace('<img src="', '').trim();
    this.fpocontentData.AppstoreIcon = '<img src="' + this.constantsService.drupalTestUrl + url;
    url = this.fpocontentData.GoogleplayIcon;
    url = url.replace('<img src="', '').trim();
    this.fpocontentData.GoogleplayIcon = '<img src="' + this.constantsService.drupalTestUrl + url;
    this.bodyContent = this.fpocontentData.Body.replace('<p>', '').replace('</p>', '');
    this.extractExternalLink();
    const thumbnail = this.fpocontentData.VideoThumbnailIcon;
    if (thumbnail) {
      this.fpocontentData.VideoThumbnailIconSrc = environment.drupalTestUrl + $(thumbnail).attr('src');
    }
  }

  navigateOTCLink(){
    $('#openOtcCvsLink').modal('open');
  }

  openVideoModal(event, videoSourceUrl: string) {
    event.stopPropagation();
    this.fpoVideoSourceUrl = this.fpocontentData.VideoUrl;
    $(this._temp).modal('open');
  }

  closeVideoModal() {
    $(this._temp).modal('close');
    this.fpoVideoSourceUrl = '';
  }

  openUrl(url) {
    if (url) {
      window.open(url, '_blank');
    }
  }

  closePullText() {
    this.closePullTextEmitter.emit({
      value: 'close'
    });
  }

  //DOAIP-4627
  extractExternalLink() {
    if (this.displayCategory === 'containsEmbeddedLink') {
      if (!this.bodyContent && this.fpocontentData.ShortDescription.indexOf('href=')>0) {
        this.bodyContent = this.fpocontentData.ShortDescription.replace('<p>','').replace('</p>','');
        this.fpocontentData.ShortDescription = '';
      }
      this.bodyFromDrupalBeforeUrl = this.bodyContent.substring(
        0, this.bodyContent.indexOf('<a')
      );

      this.bodyFromDrupalWithinUrl = this.bodyContent.substring(
        this.bodyContent.indexOf('>', this.bodyContent.indexOf('href=')) + 1,
        this.bodyContent.indexOf('<', this.bodyContent.indexOf('href='))
      );

      this.bodyFromDrupalAfterUrl = this.bodyContent.substring(
        this.bodyContent.indexOf('</a>') + 4
      );

      this.urlFromDrupal = this.bodyContent.substring(
        this.bodyContent.indexOf('href=\"') + 6,
        this.bodyContent.indexOf('\">', this.bodyContent.indexOf('href='))
      );
    }
  }
}
