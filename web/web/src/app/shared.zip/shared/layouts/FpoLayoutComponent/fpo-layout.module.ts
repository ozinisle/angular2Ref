import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FpoLayoutComponent } from './fpo-layout.component';
import { MaterialModule } from '../../../material.module';

@NgModule({
  imports: [
    CommonModule,
    MaterialModule
  ],
  declarations: [FpoLayoutComponent],
  exports: [FpoLayoutComponent]
})
export class FpoLayoutModule { }
