import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { AlertService } from '../../services/alert.service';
import { ConstantsService } from '../../services/constants.service';

declare let $: any;

@Component({
  selector: 'app-enroll-header',
  templateUrl: './enroll-header.component.html',
  styleUrls: ['./enroll-header.component.scss']
})

export class EnrollHeaderComponent implements OnInit {
  modalErrorMsg: string;
  hideAccoutImage: boolean;
  errorMessage = 'We\'re currently experiencing technical difficulties. Please try again later, or call 1-888-772-1722 for immediate assistance.';
  encryptionFailureCd = -95900;
  planIdMissingErrorCd = -95901;
  acctNumMissingErrorCd = -95902;
  redirectUrlMissingErrorCd = -95903;
  returnUrlMissingErrorCd = -95904;
  decryptedLogo: Observable<string>;
  returnUrl: Observable<string>;

  constructor(private httpClient: HttpClient, private constants: ConstantsService,
    private alertService: AlertService) { }

  isUrlValid(decryptedUrl) {
    if(decryptedUrl === null || decryptedUrl === '' || !decryptedUrl)
    {
      return false;
    }
    //const res = decryptedUrl.match(/(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g);
    const res = decryptedUrl.match(/https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9]\.[^\s]{2,}/g);

    return (res !== null)
  }

  getURLs(infoFromMicroSite): Observable<any> {
    return this.geturlstodisplay(infoFromMicroSite).pipe(map(
      (urlDetailsResponse: any) => {
        if (urlDetailsResponse.result === 0) {
          console.log("this.urlDetailsResponse::" + JSON.stringify(urlDetailsResponse));
          if (!this.isUrlValid(urlDetailsResponse.redirectUrl)) {
            this.modalErrorMsg = this.errorMessage;
            $('#openEnrollHeaderServiceError').modal('open');
            sessionStorage.setItem('redirectUrl', "");
            this.returnUrl = urlDetailsResponse.returnUrl;
            if (!this.isUrlValid(urlDetailsResponse.logoUrl)) {
              this.hideAccoutImage = true;
            }
            return urlDetailsResponse.logoUrl;
          }
          if (!this.isUrlValid(urlDetailsResponse.returnUrl)) {
            this.modalErrorMsg = this.errorMessage;
            $('#openEnrollHeaderServiceError').modal('open');
            sessionStorage.setItem('redirectUrl', "");
            if (!this.isUrlValid(urlDetailsResponse.logoUrl)) {
              this.hideAccoutImage = true;
            }
            return urlDetailsResponse.logoUrl;
          }
          if (!this.isUrlValid(urlDetailsResponse.logoUrl)) {
            sessionStorage.setItem('redirectUrl', urlDetailsResponse.redirectUrl);
            this.returnUrl = urlDetailsResponse.returnUrl;
            if (!this.isUrlValid(urlDetailsResponse.logoUrl)) {
              this.hideAccoutImage = true;
            }
            return urlDetailsResponse.logoUrl;
          }
          sessionStorage.setItem('redirectUrl', urlDetailsResponse.redirectUrl);
          this.returnUrl = urlDetailsResponse.returnUrl;
          if (!this.isUrlValid(urlDetailsResponse.logoUrl)) {
            this.hideAccoutImage = true;
          }
          return urlDetailsResponse.logoUrl;
        } else if (urlDetailsResponse.result === this.encryptionFailureCd) {
          this.modalErrorMsg = urlDetailsResponse.displaymessage;
          $('#openEnrollHeaderServiceError').modal('open');
          sessionStorage.setItem('returnUrl', this.returnUrl.toString());
          if (!this.isUrlValid(urlDetailsResponse.logoUrl)) {
            this.hideAccoutImage = true;
          }
          return urlDetailsResponse.logoUrl;
        } else if (urlDetailsResponse.result === this.planIdMissingErrorCd ||
          urlDetailsResponse.result === this.acctNumMissingErrorCd ||
          urlDetailsResponse.result === this.returnUrlMissingErrorCd ||
          urlDetailsResponse.result === this.redirectUrlMissingErrorCd) {
          this.modalErrorMsg = this.errorMessage;
          $('#openEnrollHeaderServiceError').modal('open');
          this.returnUrl = urlDetailsResponse.returnUrl;
          if (!this.isUrlValid(urlDetailsResponse.logoUrl)) {
            this.hideAccoutImage = true;
          }
          return urlDetailsResponse.logoUrl;
        } else {
          this.modalErrorMsg = 'Service Not Available.';
          $('#openEnrollHeaderServiceError').modal('open');
          sessionStorage.setItem('returnUrl', this.returnUrl.toString());
          if (!this.isUrlValid(urlDetailsResponse.logoUrl)) {
            this.hideAccoutImage = true;
          }
          return null;

        }
      }
    ));
  }

  geturlstodisplay(infoFromMicroSite): Observable<any> {
    const generatedRequest = {
      info: infoFromMicroSite
    };
    return this.httpClient.post<any>(this.constants.getdisplayurlAPI, generatedRequest);
  }
  ngOnInit() {
    $('#openEnrollHeaderServiceError').modal({ dismissible: true });
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    if ((urlParams.get('info') === null) || (urlParams.get('info') === '')) {
      this.modalErrorMsg = this.errorMessage;
      $('#openEnrollHeaderServiceError').modal('open');
      this.hideAccoutImage = true;
    }
    this.decryptedLogo = this.getURLs(urlParams.get('info'));
  }
  closeModal() {
    $('#openEnrollHeaderServiceError').modal('close');
  }
}

export interface MicrositeDetailsResponse {
  logoURL: string;
  enrollmentURL: string;
}

