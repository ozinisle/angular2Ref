export const FINDADOCTORMENUITEM_TEXT = 'Find a Doctor & Estimate Costs';

export const MYPHARMASUBMENU = [
  { text: 'My Medications', display: 'My Medications', url: '', img: 'far fa-capsules  icons-class', location: '_self' },
  { text: '90-Day Supply', display: '90-Day Mail Order Pharmacy', url: '', img: 'far fa-envelope-open  icons-class', location: '_blank' },
  {
    text: 'Medication Lookup Tool',
    display: 'Medication Lookup Tool',
    url: '',
    img: 'far fa-clipboard-check  icons-class',
    location: '_blank'
  },
  { text: 'PillPack', display: 'PillPack', url: '', img: 'far fa-envelope-open  icons-class', location: '_self' }
];

export const RIGHTTOPMENU = [
  { name: 'Home', url: '/home', img: 'fas fa-home', sso: false },
  {
    name: FINDADOCTORMENUITEM_TEXT,
    url: '/fad',
    img: 'fas fa-stethoscope',
    sso: true
  },
  {
    name: 'My Inbox',
    url: '/message-center',
    img: 'fas fa-envelope override-fa-icon',
    sso: false
  },

  { name: 'My Account', url: '/myaccount', img: 'fas fa-user-shield', sso: false },
  { name: 'My Cards', url: '/mycards', img: 'fas fa-id-card', sso: false },
  { name: 'My Plans & Benefits', url: '/myplans', img: 'fa fa-shield-alt', sso: false },
  { name: 'My Claims', url: '/myclaims', img: 'fas fa-file-alt', sso: false },
  { name: 'My Deductible & Co-Insurance', url: '/mydedco', img: 'fas fa-clipboard-check', sso: false },
  { name: 'My Doctors', url: '/mydoctors', img: 'fas fa-user-md', sso: false },
  { name: 'My Pharmacy', url: '/mypharmacy', img: 'fas fa-prescription-bottle', sso: false },
  { name: 'My Medications', url: '/mymedications', img: 'fas fa-pills', sso: false }
  //Commenting the RQE temporarily for KLO-1083
  //{ name: 'Request Written Estimate', url: '/request-estimate', img: 'fas fa-file-invoice-dollar', sso: false },
  // { name: 'My Financials', url: '/sso/alegeus', img: 'fas fa-chart-line', sso: false }
  // { name: 'Notifications', url: '/notification-preferences', img: 'fal fa-cog' }
];

export const RIGHTTOPMENU_INACTIVE = [
  { name: 'Home', url: '/home', img: 'fas fa-home', sso: false },
  {
    name: FINDADOCTORMENUITEM_TEXT,
    url: '/fad',
    img: 'fas fa-stethoscope',
    sso: true
  },
  {
    name: 'My Inbox',
    url: '/message-center',
    img: 'fas fa-envelope override-fa-icon',
    sso: false
  },
  { name: 'My Account', url: '/myaccount', img: 'fas fa-user-shield', sso: false },
  // { name: 'My Plans & Benefits', url: '/myplans', img: 'fa fa-shield-alt', sso: false },
  { name: 'My Claims', url: '/myclaims', img: 'fas fa-file-alt', sso: false },
  // { name: 'My Deductible & Co-Insurance', url: '/mydedco', img: 'fas fa-clipboard-check', sso: false },
  { name: 'My Doctors', url: '/mydoctors', img: 'fas fa-user-md', sso: false },
  { name: 'My Medications', url: '/mymedications', img: 'fas fa-capsules', sso: false }
  // { name: 'Request Written Estimate', url: '/request-estimate', img: 'fas fa-receipt', sso: false },
  // { name: 'My Financials', url: '/pages/maintenance', img: 'fas fa-chart-line' , sso: false },
  // { name: 'Notifications', url: '/notification-preferences', img: 'fal fa-cog' }
];

export const LEFTTOPMENU = [
  { name: 'Home', url: 'http://bcbsma.info/member' },
  { name: 'About Us', url: 'https://aboutus.bluecrossma.com/' }
  // { name: 'Need a Plan?', url: 'http://20180329home.bluecrossma.acsitefactory.com/landing' },
];

export const LEFTSECONDMENU = [
  { name: 'Looking for a Plan?', url: 'https://myplans.bluecrossma.com/' },
  { name: 'Member', url: 'http://bcbsma.info/member' },
  { name: 'Information about Medicare', url: 'https://medicare.bluecrossma.com/' },
  { name: 'Provider', url: 'https://provider.bluecrossma.com/' },
  { name: 'Broker', url: 'https://broker.bluecrossma.com/' },
  { name: 'Employer', url: 'https://employer.bluecrossma.com/' },
  { name: 'Job Seeker', url: 'https://careers.bluecrossma.com/' }
];

export let MENU_ITEMS = [
  {
    id: 'myPlanAndClaims',
    label: 'My Plan & Claims',
    icon: '',
    hasSubMenu: true,
    isOpen: false,
    isActive: false,
    hasLink: false,
    subMenuItems: [
      {
        id: 'planAndBenefits',
        label: 'Plans & Benefits',
        display: true,
        items: [
          {
            id: 'planBenefits',
            label: 'Plan Benefits',
            url: '/myplans',
            isExternal: false,
            display: true
          },
          {
            id: 'myCards',
            label: 'My Cards',
            url: '/mycards',
            isExternal: false,
            display: true
          },
          {
            id: 'myRewards',
            label: 'My Rewards',
            url: 'https://www.blue365deals.com/ ',
            isExternal: true,
            display: true
          },
          {
            id: 'onlineMentalHealthTool',
            label: 'Online Mental Health Tool',
            url: 'https://www.learntolive.com/partners?code=MentalWellbeing',
            isExternal: false,
            isSsoTrue: true,
            display: false
          },
          {
            id: 'viewChangeOrRenewMyPlan',
            label: 'View, Change or Renew My Plan',
            url: '',
            isExternal: true,
            isSsoTrue: true,
            display: false
          }
        ]
      },
      {
        id: 'claims',
        label: 'Claims',
        display: true,
        items: [
          {
            id: 'myClaims',
            label: 'My Claims',
            url: '/myclaims',
            isExternal: false,
            display: true
          },
          {
            id: 'yearToDateSummary',
            label: 'Year-to-Date Summary',
            url: '/yes',
            isExternal: false,
            display: true
          }
        ]
      },
      {
        id: 'financials',
        label: 'Financials',
        display: true,
        items: [
          {
            id: 'myebilling',
            label: 'Pay My Bill',
            url: '/sso/ebilling',
            isExternal: false,
            display: true
          },
          {
            id: 'myHealthFinancialAccounts',
            label: 'My Health Financial Accounts',
            url: '/sso/alegeus',
            isExternal: false,
            display: false
          },
          {
            id: 'myDeductibles',
            label: 'My Deductibles',
            url: '/mydedco',
            isExternal: false,
            display: true
          }
        ]
      }
    ]
  },
  {
    id: 'myCare',
    label: 'My Care',
    icon: '',
    hasSubMenu: true,
    isOpen: false,
    isActive: false,
    hasLink: false,
    subMenuItems: [
      {
        id: 'findCareAndUnderstandCosts',
        label: 'Find Care & Understand Costs',
        display: true,
        items: [
          {
            id: 'medicalCareAndCosts',
            label: 'Find A Doctor & Estimate Costs',
            url: '/fad',
            isExternal: false,
            display: true
          },
          {
            id: 'startsavingwithsmartShopper',
            label: 'Start Saving with SmartShopper',
            url: '/fad',
            isExternal: false,
            display: true
          }
        ]
      },
      {
        id: 'remoteCare',
        label: 'Remote Care',
        display: true,
        items: [
          // {
          //   id: 'wellConnection',
          //   label: 'Well Connection',
          //   url: 'https://myblue.bluecrossma.com/health-plan/well-connection',
          //   isExternal: true,
          //   display: true
          // },
          {
            id: 'callANurse',
            label: 'Call a Nurse 24/7',
            url: 'https://myblue.bluecrossma.com/tools-resources/find-care/nurse-phone-line',
            isExternal: true,
            display: true
          },
          {
            id: 'virtualVisit',
            label: 'Well Connection Video Visits',
            url: '/virtual-visit',
            isExternal: false,
            display: false
          }
        ]
      },
      {
        id: 'doctors',
        label: 'Doctors',
        display: true,
        items: [
          {
            id: 'myDoctors',
            label: 'My Doctors',
            url: '/mydoctors',
            isExternal: false,
            display: true
          },
          {
            id: 'addChangePrimaryCarePhysician',
            label: 'Add/Change Primary Care Physician',
            url: '/mydoctors/update-pcp-homepage',
            isExternal: false,
            display: false
          }
        ]
      },
      {
        id: 'additionalResources',
        label: 'Additional Resources',
        display: true,
        items: [
          // {
          //   id: 'healthyActions',
          //   label: 'Healthy Actions',
          //   url: 'https://healthy-actions.com/',
          //   isExternal: true,
          //   display: true
          // },
          {
            id: 'aHealthyMe',
            label: 'AHealthyMe',
            url: 'https://bluecrossma.ahealthyme.com/dt/v2/bcbsmaindex.asp',
            isExternal: true,
            display: false
          },
          {
            id: 'wellnessRewardsProgram',
            label: 'Wellness Rewards Program',
            url: 'https://www.join.virginpulse.com/wellness',
            isExternal: true,
            display: false
          },
          {
            id: 'identityProtection',
            label: 'Identity Protection',
            url: '/pages/campaign1',
            isExternal: false,
            display: true
          }
        ]
      }
    ]
  },
  {
    id: 'myMedications',
    label: 'My Medications',
    icon: '',
    hasSubMenu: true,
    isOpen: false,
    isActive: false,
    hasLink: false,
    subMenuItems: [
      {
        id: 'prescriptionPrograms',
        label: 'Pharmacy Programs',
        items: [
          {
            id: 'ExpressScripts®',
            label: 'Express Scripts®',
            url: 'https://www.express-scripts.com/',
            isExternal: true,
            isSsoTrue: true,
            display: false
          },
          {
            id: 'SignUpforPillPack',
            label: 'Sign Up for PillPack',
            url: '/my-pillpack/landing',
            isExternal: false,
            display: false
          },
          {
            id: 'ManageYourPillPackAccount',
            label: 'Manage Your PillPack Account',
            url: 'https://www.pillpack.com',
            isExternal: true,
            isSsoTrue: true,
            display: false
          },
          {
            id: 'Cost-ShareAssistanceProgram',
            label: 'Cost-Share Assistance',
            url: '/cost-share',
            isExternal: false,
            display: false
          },
          {
            id: '90-DayMailOrderPharmacy',
            label: '90-Day Mail Order Pharmacy',
            url: 'https://www.express-scripts.com/',
            isExternal: true,
            isSsoTrue: true,
            display: false
          }
        ]
      },
      {
        id: 'myPharmacy',
        label: 'My Medications',
        items: [
          {
            id: 'allMedications',
            label: 'All Medications',
            url: '/mymedications',
            isExternal: false,
            display: false
          },
          {
            id: 'MedicationLookupTool',
            label: 'Medication Lookup Tool',
            url: 'http://www2.bluecrossma.com/search-app/formulary-2020',
            isExternal: true,
            display: true
          }
        ]
      }
    ]
  },
  {
    id: 'searchBenefits',
    label: 'Search Benefits',
    icon: 'fa-search',
    isOpen: false,
    hasSubMenu: false,
    hasLink: false,
    subMenuItems: []
  },
  {
    id: 'teamBlueSupport',
    label: 'Team Blue Support',
    icon: 'fal fa-question-circle',
    hasSubMenu: false,
    isOpen: false,
    isActive: false,
    hasLink: true,
    subMenuItems: [
      {
        items: [
          {
            id: 'callmemberservice',
            label: 'Call Member Service',
            icon: 'fal fa-phone',
            ph: '1-800-262-2583',
            url: `tel: 1-800-262-2583`,
            isExternal: true,
            display: true,
            isTTY: 'TTY 711'
          },
          {
            id: 'talktoanurse',
            label: 'Talk to a nurse',
            icon: 'fal fa-phone',
            ph: '1-888-247-2583',
            url: `tel: 1-888-247-2583`,
            isExternal: true,
            display: true
          },
          {
            id: 'remotedoctorvisit',
            label: 'Remote Doctor Visit',
            icon: 'fal fa-video',
            url: 'https://myblue.bluecrossma.com/health-plan/telehealth',
            isExternal: true,
            display: true
          },
          {
            id: 'sendsecuremessage',
            label: 'Send Secure Message',
            icon: 'fal fa-lock',
            url: 'https://myblue.bluecrossma.com/form/inquiry',
            isExternal: false,
            display: true
          }
        ]
      }
    ]
  },
  {
    id: 'logout',
    label: 'Log Out',
    icon: 'fal fa-sign-out',
    hasSubMenu: false,
    hasLink: true,
    isOpen: false,
    subMenuItems: []
  }
];

export const MENU_ITEMS_RESET_COPY = () => {
  MENU_ITEMS = [
    {
      id: 'myPlanAndClaims',
      label: 'My Plan & Claims',
      icon: '',
      hasSubMenu: true,
      isOpen: false,
      isActive: false,
      hasLink: false,
      subMenuItems: [
        {
          id: 'planAndBenefits',
          label: 'Plans & Benefits',
          display: true,
          items: [
            {
              id: 'planBenefits',
              label: 'Plan Benefits',
              url: '/myplans',
              isExternal: false,
              display: true
            },
            {
              id: 'myCards',
              label: 'My Cards',
              url: '/mycards',
              isExternal: false,
              display: true
            },
            {
              id: 'myRewards',
              label: 'My Rewards',
              url: 'https://www.blue365deals.com/ ',
              isExternal: true,
              display: true
            },
            {
              id: 'onlineMentalHealthTool',
              label: 'Online Mental Health Tool',
              url: 'https://www.learntolive.com/partners?code=MentalWellbeing',
              isExternal: false,
              isSsoTrue: true,
              display: false
            },
            {
              id: 'viewChangeOrRenewMyPlan',
              label: 'View, Change or Renew My Plan',
              url: '',
              isExternal: true,
              isSsoTrue: true,
              display: false
            }
          ]
        },
        {
          id: 'claims',
          label: 'Claims',
          display: true,
          items: [
            {
              id: 'myClaims',
              label: 'My Claims',
              url: '/myclaims',
              isExternal: false,
              display: true
            },
            {
              id: 'yearToDateSummary',
              label: 'Year-to-Date Summary',
              url: '/yes',
              isExternal: false,
              display: true
            }
          ]
        },
        {
          id: 'financials',
          label: 'Financials',
          display: true,
          items: [
            {
              id: 'myebilling',
              label: 'Pay My Bill',
              url: '/sso/ebilling',
              isExternal: false,
              display: true
            },
            {
              id: 'myHealthFinancialAccounts',
              label: 'My Health Financial Accounts',
              url: '/sso/alegeus',
              isExternal: false,
              display: false
            },
            {
              id: 'myDeductibles',
              label: 'My Deductibles',
              url: '/mydedco',
              isExternal: false,
              display: true
            }
          ]
        }
      ]
    },
    {
      id: 'myCare',
      label: 'My Care',
      icon: '',
      hasSubMenu: true,
      isOpen: false,
      isActive: false,
      hasLink: false,
      subMenuItems: [
        {
          id: 'findCareAndUnderstandCosts',
          label: 'Find Care & Understand Costs',
          display: true,
          items: [
            {
              id: 'medicalCareAndCosts',
              label: 'Find A Doctor & Estimate Costs',
              url: '/fad',
              isExternal: false,
              display: true
            },
            {
              id: 'startsavingwithsmartShopper',
              label: 'Start Saving with SmartShopper',
              url: '/fad',
              isExternal: false,
              display: true
            }
          ]
        },
        {
          id: 'remoteCare',
          label: 'Remote Care',
          display: true,
          items: [
            // {
            //   id: 'wellConnection',
            //   label: 'Well Connection',
            //   url: 'https://myblue.bluecrossma.com/health-plan/well-connection',
            //   isExternal: true,
            //   display: true
            // },
            {
              id: 'callANurse',
              label: 'Call a Nurse 24/7',
              url: 'https://myblue.bluecrossma.com/tools-resources/find-care/nurse-phone-line',
              isExternal: true,
              display: true
            },
            {
              id: 'virtualVisit',
              label: 'Well Connection Video Visits',
              url: '/virtual-visit',
              isExternal: false,
              display: false
            }
          ]
        },
        {
          id: 'doctors',
          label: 'Doctors',
          display: true,
          items: [
            {
              id: 'myDoctors',
              label: 'My Doctors',
              url: '/mydoctors',
              isExternal: false,
              display: true
            },
            {
              id: 'addChangePrimaryCarePhysician',
              label: 'Add/Change Primary Care Physician',
              url: '/mydoctors/update-pcp-homepage',
              isExternal: false,
              display: false
            }
          ]
        },
        {
          id: 'additionalResources',
          label: 'Additional Resources',
          display: true,
          items: [
            // {
            //   id: 'healthyActions',
            //   label: 'Healthy Actions',
            //   url: 'https://healthy-actions.com/',
            //   isExternal: true,
            //   display: true
            // },
            {
              id: 'aHealthyMe',
              label: 'AHealthyMe',
              url: 'https://bluecrossma.ahealthyme.com/dt/v2/bcbsmaindex.asp',
              isExternal: true,
              display: false
            },
            {
              id: 'wellnessRewardsProgram',
              label: 'Wellness Rewards Program',
              url: 'https://www.join.virginpulse.com/wellness',
              isExternal: true,
              display: false
            },
            {
              id: 'identityProtection',
              label: 'Identity Protection',
              url: '/pages/campaign1',
              isExternal: false,
              display: true
            }
          ]
        }
      ]
    },
    {
      id: 'myMedications',
      label: 'My Medications',
      icon: '',
      hasSubMenu: true,
      isOpen: false,
      isActive: false,
      hasLink: false,
      subMenuItems: [
        {
          id: 'prescriptionPrograms',
          label: 'Pharmacy Programs',
          items: [
            {
              id: 'ExpressScripts®',
              label: 'Express Scripts®',
              url: 'https://www.express-scripts.com/',
              isExternal: true,
              isSsoTrue: true,
              display: false
            },
            {
              id: 'SignUpforPillPack',
              label: 'Sign Up for PillPack',
              url: '/my-pillpack/landing',
              isExternal: false,
              display: false
            },
            {
              id: 'ManageYourPillPackAccount',
              label: 'Manage Your PillPack Account',
              url: 'https://www.pillpack.com',
              isExternal: true,
              isSsoTrue: true,
              display: false
            },
            {
              id: 'Cost-ShareAssistanceProgram',
              label: 'Cost-Share Assistance',
              url: '/cost-share',
              isExternal: false,
              display: false
            },
            {
              id: '90-DayMailOrderPharmacy',
              label: '90-Day Mail Order Pharmacy',
              url: 'https://www.express-scripts.com/',
              isExternal: true,
              isSsoTrue: true,
              display: false
            }
          ]
        },
        {
          id: 'myPharmacy',
          label: 'My Medications',
          items: [
            {
              id: 'allMedications',
              label: 'All Medications',
              url: '/mymedications',
              isExternal: false,
              display: false
            },
            {
              id: 'MedicationLookupTool',
              label: 'Medication Lookup Tool',
              url: 'http://www2.bluecrossma.com/search-app/formulary-2020',
              isExternal: true,
              display: true
            }
          ]
        }
      ]
    },
    {
      id: 'searchBenefits',
      label: 'Search Benefits',
      icon: 'fa-search',
      isOpen: false,
      hasSubMenu: false,
      hasLink: false,
      subMenuItems: []
    },
    {
      id: 'teamBlueSupport',
      label: 'Team Blue Support',
      icon: 'fal fa-question-circle',
      hasSubMenu: false,
      isOpen: false,
      isActive: false,
      hasLink: true,
      subMenuItems: [
        {
          items: [
            {
              id: 'callmemberservice',
              label: 'Call Member Service',
              icon: 'fal fa-phone',
              ph: '1-800-262-2583',
              url: `tel: 1-800-262-2583`,
              isExternal: true,
              display: true,
              isTTY: 'TTY 711'
            },
            {
              id: 'talktoanurse',
              label: 'Talk to a nurse',
              icon: 'fal fa-phone',
              ph: '1-888-247-2583',
              url: `tel: 1-888-247-2583`,
              isExternal: true,
              display: true
            },
            {
              id: 'remotedoctorvisit',
              label: 'Remote Doctor Visit',
              icon: 'fal fa-video',
              url: 'https://myblue.bluecrossma.com/health-plan/telehealth',
              isExternal: true,
              display: true
            },
            {
              id: 'sendsecuremessage',
              label: 'Send Secure Message',
              icon: 'fal fa-lock',
              url: 'https://myblue.bluecrossma.com/form/inquiry',
              isExternal: false,
              display: true
            }
          ]
        }
      ]
    },
    {
      id: 'logout',
      label: 'Log Out',
      icon: 'fal fa-sign-out',
      hasSubMenu: false,
      hasLink: true,
      isOpen: false,
      subMenuItems: []
    }
  ];
};
