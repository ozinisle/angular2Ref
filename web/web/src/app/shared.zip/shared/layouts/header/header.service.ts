import { HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import * as moment from 'moment';
import { Observable } from 'rxjs/Observable';
import { map, retry } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import { WorldClockApiResponseModel } from '../../models/worldClockResponse.model';
import { AuthHttp } from '../../services/auth-http.service';
import { AuthService } from '../../services/auth.service';
import { ConstantsService } from '../../services/constants.service';
import { GlobalService } from '../../services/global.service';
import { BsmartSearchResponse, GetMemberPlansResponse, HeaderInboxUnreadMsgCountReponse, HeaderMenu, MedlookupsModel } from './models/header.model';

declare let $: any;
@Injectable()
export class HeaderService {
  public menuItems: HeaderMenu[];
  public searchUrlTarget: string;
  public inbox: HeaderInboxUnreadMsgCountReponse;
  public drupalsecureinquiry: string; // used in header.html

  constructor(
    private http: AuthHttp,
    private authService: AuthService,
    private constants: ConstantsService,
    private globalService: GlobalService,
    private router: Router
  ) {
    this.inbox = new HeaderInboxUnreadMsgCountReponse();
    this.drupalsecureinquiry = this.constants.drupalsecureinquiry;
  }

  // To get the drupal header menu items
  public getMenuItems(): Observable<HeaderMenu[]> {
    let isMedicareUser = false;
    if (
      this.authService &&
      this.authService.authToken &&
      this.authService.authToken.userType &&
      (this.authService.authToken.userType.toLowerCase() === 'medicare' || this.authService.authToken.userType.toLowerCase() === 'medex')
    ) {
      isMedicareUser = true;
    }
    const url = environment.drupalTestUrl + (isMedicareUser ? this.constants.medicareUsersMenuUrl : this.constants.commercialUsersMenuUrl);
    return this.http.get<HeaderMenu[]>(url).pipe(retry(3));
  }

  getformularyandtierInfo(useridin, subscriberId, memberSuffix, groupUaCvg): Observable<MedlookupsModel> {
    const reqParams = {
      coverageType: '',
      useridin: useridin,
      subscriberId: subscriberId,
      memberSuffix: memberSuffix,
      groupUaCvg: groupUaCvg
    };
    this.getTierMapping();
    return this.http.encryptPost(this.constants.medlookupformularyUrl, reqParams).pipe(map(data => data as MedlookupsModel));
  }

  getTierMapping() {
    if (!sessionStorage.getItem('tierMappingData')) {
      const url = `${this.constants.medlookupTierMapping}`;
      const httpOptions = {
        headers: new HttpHeaders({
          Authorization: `Bearer ${this.authService.getAuthToken()}`,
          uitxnid: 'WEB_v5.0_' + this.http.uuid()
        })
      };
      this.http.get(url, httpOptions).subscribe(data => {
        sessionStorage.setItem('tierMappingData', JSON.stringify(data));
      });
    }
  }

  public getESTTime(): Observable<WorldClockApiResponseModel> {
    const worldESTClockUrl = 'http://worldclockapi.com/api/json/est/now';
    return this.http.get<WorldClockApiResponseModel>(worldESTClockUrl);
  }

  set unReadMsgCount(count: any) {
    sessionStorage.setItem('inboxUnreadMsgCount', count);
  }

  get unReadMsgCount() {
    return sessionStorage.getItem('inboxUnreadMsgCount');
  }

  checkBsmartSearchEnable(): Observable<BsmartSearchResponse> {
    const request = {
      useridin: this.authService.useridin,
      effectiveDate: moment().format('YYYY-MM-DD')
    };
    return this.http.encryptPost(this.constants.isBenefitSearchEnabled, request);
  }
  getAllMemberPlans(): Observable<GetMemberPlansResponse> {
    const request = {
      useridin: this.authService.useridin
    };
    return this.http.encryptPost(this.constants.getMemberPlans, request).pipe(map(data => data as GetMemberPlansResponse));
  }

  openFadSSO(postLoginInfoObj) {
    const impersonate = this.authService.impersonation();
    if ((postLoginInfoObj.hasSS || postLoginInfoObj.hasSSO || postLoginInfoObj.hasCI) && !impersonate) {
      this.openFadSsoSite();;
    } else {
      this.router.navigate(['/fad']);
    }
  }

  openFadSsoSite() {
    if(!this.authService.impersonation()){
      sessionStorage.setItem('consentLink', '/sso/vitals');
      $('#openSsoFadSite').modal('open');
    }
  }

  prepareContactObject(aContactList) {
    let oContactObject = {};
    const aChangedContactList = [];
    let oTTY;
    if (this.authService.getScopeName() === 'REGISTERED-AND-VERIFIED') {
      oContactObject['href'] = `tel: 1-800-262-2583`;
      oContactObject['icon'] = 'fas fa-phone';
      oContactObject['number'] = `1-800-262-2583`;
      oContactObject['isTTY'] = 'TTY 711';
      oContactObject['text'] = 'Call Member Service';
      aChangedContactList.push(JSON.parse(JSON.stringify(oContactObject)));
      oContactObject = {};
      oContactObject['href'] = `tel: 1-800-247-2583`;
      oContactObject['icon'] = 'fas fa-phone';
      oContactObject['number'] = `1-800-247-2583`;
      oContactObject['text'] = 'Talk to a Nurse';
      aChangedContactList.push(JSON.parse(JSON.stringify(oContactObject)));
      oContactObject = {};
      oContactObject['href'] = 'https://myblue.bluecrossma.com/health-plan/telehealth';
      oContactObject['icon'] = 'fas fa-video';
      oContactObject['text'] = 'Talk to a Doctor';
      aChangedContactList.push(JSON.parse(JSON.stringify(oContactObject)));
      oContactObject = {};
      oContactObject['href'] = this.drupalsecureinquiry;
      oContactObject['icon'] = 'fas fa-lock';
      oContactObject['text'] = 'Send Message';
      aChangedContactList.push(JSON.parse(JSON.stringify(oContactObject)));
    } else {
      if (aContactList != null) {
        oTTY = aContactList.find(oCnct => (oCnct.text || '').trim() === 'TTY:');
        aContactList.forEach(oContact => {
          if ((oContact.text || '').trim() !== 'TTY:') {
            if (oContact.number) {
              oContactObject['href'] = `tel: ${oContact.number}`;
              oContactObject['icon'] = 'fas fa-phone';
              oContactObject['number'] = `1-${oContact.number}`;
              oContactObject['isTTY'] = (oContact.text || '').trim() === 'Call Member Service:' ? (oTTY ? `TTY ${oTTY.number}` : '') : '';
            } else if ((oContact.text || '').trim() === 'Talk to a Doctor') {
              oContactObject['href'] = 'https://myblue.bluecrossma.com/health-plan/telehealth';
              oContactObject['icon'] = 'fas fa-video';
              oContactObject['number'] = oContact.number;
            } else if ((oContact.text || '').trim() === 'Send a Message') {
              oContactObject['href'] = this.drupalsecureinquiry;
              oContactObject['icon'] = 'fas fa-lock';
              oContactObject['number'] = oContact.number;
            }
            oContactObject['text'] = (oContact.text || '').split(':')[0];
            aChangedContactList.push(JSON.parse(JSON.stringify(oContactObject)));
          }
        });
      }
    }
    return aChangedContactList;
  }
  resetSessionObject() {
    sessionStorage.setItem('isAllowedChangePCP', this.globalService.landingPageMemberInfo.isAllowedChangePCP);
    sessionStorage.setItem('isRequiredPCP', this.globalService.landingPageMemberInfo.isRequiredPCP);
    sessionStorage.setItem('hasPCP', this.globalService.landingPageMemberInfo.hasPCP);
    sessionStorage.setItem('hasCernerMedicare', this.globalService.landingPageMemberInfo.cerner.hasCernerMedicare);
    sessionStorage.setItem('isMedicarePPO', this.globalService.landingPageMemberInfo.isPPO);
    sessionStorage.setItem('hasBqi', this.globalService.landingPageMemberInfo.hasBQi);
  }
  checkEbillingEligibility(postLoginInfo: any = {}) {
    return postLoginInfo.ebillingEligibility;
  }

  getSwitchPlanAPI(memberId, memberSuffix ): Observable<any> {
    const request = {
      mesg: {
      useridin: this.authService.useridin,
      cardMemId: memberId,
      cardMemSuffix: memberSuffix,
      migrationType : this.authService.authToken.migrationtype,
      destinationURL : this.authService.authToken.destinationURL,
      key2id: this.authService.cryptoToken.key2id
    },
    key1id: this.authService.cryptoToken.key1id
    };
    return this.http.encryptPost(this.constants.switchPlanAPI, request).pipe(map(data=> {return data}));
  }
}
