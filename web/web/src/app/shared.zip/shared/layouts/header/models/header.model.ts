export class HeaderMenu {
    title: string;
    absolute: string;
    enabled?: boolean;
    below?: Object[];
}
export class HeaderInboxUnreadMsgCountRequest {
    useridin: string;
}
export class HeaderInboxUnreadMsgCountReponse {
    unreadMessageCount: number;
}

export interface CpcInfo {
    cpcCode: string;
    searchEnabled: boolean;
}

export interface BsmartSearchResponse {
    searchResults: CpcInfo[];
}

export interface MedlookupsModel {
  NPFFlag: boolean;
  tierNumber: string;
}

export interface GetMemberPlansResponse{
    hasMultiplePlans: boolean;
    plans: MemberPlans[];
    result ? : number
}

export interface MemberPlans {
    planName: string;
    cardMemId: string;
    cardMemSuffix: string;
    activePlan: boolean;
}