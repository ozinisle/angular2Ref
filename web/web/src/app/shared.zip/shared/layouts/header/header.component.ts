import { AfterViewInit, Component, HostListener, Inject, OnDestroy, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { DOCUMENT } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment-timezone';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ISubscription } from 'rxjs/Subscription';
import { environment } from '../../../../environments/environment';
import { MemberInfo } from '../../../shared/models/memberInfo.model';
import { ConstantsService } from '../../../shared/services/constants.service';
import { ProfileService } from '../../../shared/services/myprofile/profile.service';
import { ServiceFailureModalComponent } from '../../components/service-failure-modal/service-failure-modal.component';
import { PWKStatus } from '../../models/welcome-kit.model';
import { AlertService } from '../../services/alert.service';
import { AuthHttp } from '../../services/auth-http.service';
import { AuthService } from '../../services/auth.service';
import { GlobalService } from '../../services/global.service';
import { FINDADOCTORMENUITEM_TEXT, LEFTSECONDMENU, LEFTTOPMENU, MENU_ITEMS, MENU_ITEMS_RESET_COPY, RIGHTTOPMENU, RIGHTTOPMENU_INACTIVE } from './constants/header-constants';
import { HeaderService } from './header.service';
import { HeaderMenu } from './models/header.model';

declare let $: any;
let collapse = false;

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit, OnDestroy, AfterViewInit {
  count = 0;
  pharmacymenu: any[] = [];
  private subscription: ISubscription;
  private toggleClick = false;
  private mobileViewPort = 992;
  public memberData: MemberInfo;
  public memberFirstName: string;
  public ismobile: boolean;
  public sideNavStatus: string;
  public leftMenuId: string;
  public isPillPackEnrolledThisSession = false;
  public unReadMsgCount;
  public leftMenuList = LEFTTOPMENU;
  public leftMenuBottomList = LEFTSECONDMENU;
  public rightMenuList = RIGHTTOPMENU;
  public mainMenuItems: any[] = MENU_ITEMS;
  public menuDrupalLinks: HeaderMenu[];
  public noApiLinks = true;
  public isAuthenticated = true; // isAuthenticated = this.authService.authToken && this.authService.authToken.scopename ? true : false;
  public estGreeting: string = null; // this.time.getHours();
  public showSearchBar = false;
  public showContactUs = false;
  public searchText: FormControl = new FormControl();
  public currentScope: string;
  public rweMenuList: any[];
  public isMedexMedicalContactUs = false;
  public isMedicareAdvantageMedicalContactUs = false;
  public isMedicareAdvantageDentalContactUs = false;
  public isMedexDentalContactUs = false;
  public isAllowedChangePCP: string;
  public isRequiredPCP: string;
  public hasPCP: string;
  public hasCernerMedicare: string;
  public isDirectPay: boolean;
  private http: AuthHttp;
  isMedicarePPO: string;

  //formulary variables
  isNPFformularyFlag = false;
  tierNumber: string;
  memberuseridin: string;
  subscriberId: string;
  memberSuffix: string;
  groupUaCvg: string;

  public aContactList: any[];
  isPharmaSubmenuOpen = false;
  isFadLoaded = false;
  memberFullName: any;
  showMenuItems = false;
  showSubMenuItems = false;
  menuItemList: any[] = [];
  mobileSubHeadingName: string;
  isOpenFlag: boolean;
  isMenuIsActive: boolean;
  showActiveMenu: boolean;
  isTeamBlueLink = false;
  isTeamBlueSupport: boolean;
  selectedMenuItem: any;
  menuClosed: boolean;
  postLoginInfoObj: any;
  learnToLive: boolean;
  countArray: any = [];
  focusedInput = false;
  mediCationUrl: string;
  inactiveUser: string;
  isMedexUser: boolean;
  hasEbillingEligibility = false;
  isMedicareUser: boolean;
  isRegisteredUser = false;
  isSearchEnabled = false;
  isSearchEnabledFailed = false;
  searchEnableRetryCount = 0;

  // showFAD = false;
  hasBqi: string;
  teleHealthFlag: boolean;
  isSmartShopperUser = false;
  trimmedSearchText = '';
  wellnessVendorCd: string;
  destroy$ = new Subject<void>();

  //Medication Lookup Tool urls
  medLookUpUrl = 'https://home.bluecrossma.com/medication/?icid=myblueglobalnav';
  npfUrl = 'https://home.bluecrossma.com/medication/national-preferred-formulary';
  directPayMedicareUrl = 'http://www2.bluecrossma.com/search-app/formulary-2021';
  directPayMedexUserUrl = 'https://rxmedicareplans.com/Coverage/PricingTool';
  medLookUpurlMedicare = 'http://www2.bluecrossma.com/search-app/formulary-2020';
  medexWithoutdirectPayUrl =
    'https://home.bluecrossma.com/collateral/sites/g/files/csphws1571/files/acquiadam-assets/50-0207_Medex_Closed_Formulary.pdf';
  medicareWithoutDirectPay =
    'https://home.bluecrossma.com/collateral/sites/g/files/csphws1571/files/acquiadam-assets/55-0184_2021_MedAdvFormulary.pdf';
  foundTierError: boolean;
  userType: string;
  typeOfuser: string;

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    if (event.target.innerWidth <= this.mobileViewPort) {
      this.ismobile = true;
    } else {
      this.ismobile = false;
      this.sideNavStatus = 'in';
    }
    this.leftMenuId = this.ismobile ? 'slide-out-left' : 'dropdown1';
    this.toggleClick = false;
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event) {
    this.showMenuItems = false;
    this.mainMenuItems.forEach(item => {
      item.isOpen = false;
    });
    if (!event.target.classList.contains('search-dropdown-elements') && !event.target.classList.contains('web-search-area')) {
      this.focusedInput = false;
    }
  }

  constructor(
    private globalService: GlobalService,
    private art: ActivatedRoute,
    private router: Router,
    public headerService: HeaderService,
    private authService: AuthService,
    private profileService: ProfileService,
    private constantsService: ConstantsService,
    @Inject(DOCUMENT) private document: any,
    private alertService: AlertService,
    private dialog: MatDialog,
    private authHttpService: AuthHttp,

  ) {
    /* getting session Value*/
    const postLoginInfo = sessionStorage.getItem('postLoginInfo');
    this.postLoginInfoObj = JSON.parse(postLoginInfo);

    this.isSmartShopperUser = postLoginInfo ? this.checkSmartShopperUser(this.postLoginInfoObj) : false;
    this.hasEbillingEligibility = postLoginInfo ? this.headerService.checkEbillingEligibility(this.postLoginInfoObj) : false;
    this.globalService.fadLoaded$.subscribe(value => {
      this.isFadLoaded = value;
    });

    this.learnToLive = this.postLoginInfoObj ? (this.postLoginInfoObj.wellnessPrograms ? true : false) : false;

    this.aContactList = this.prepareContactObject(postLoginInfo ? JSON.parse(postLoginInfo).phoneNumbers : []);

    this.subscription = this.globalService.memberData$.subscribe(data => {
      this.memberData = data;
    });

    router.events.subscribe(val => {
      $('.menu-icon').sideNav('hide');
    });

    if (this.authService.useridin && this.authService.useridin !== 'null') {
      const searchableCpcsJson = sessionStorage.getItem('searchableCPCsResult');
      if (searchableCpcsJson) {
        const searchableCpcs = JSON.parse(searchableCpcsJson);
        this.globalService.updateSearchableCpcs(false, searchableCpcs);
      }
      this.globalService.seachableCpcs$.pipe(takeUntil(this.destroy$)).subscribe(result => {
        this.isSearchEnabled = result.searchableCpcs && result.searchableCpcs.length > 0;
        this.isSearchEnabledFailed = result.hasError;
        if (this.trimmedSearchText && !result.hasError) {
          this.navigateToBenefitSearch();
        }
      });
    }

    if (this.profileService.getProfile() && this.profileService.getProfile().useridin !== 'null') {
      const profileServiceData = this.profileService.getProfile();
      this.memberFullName = profileServiceData.fullName;
      this.isDirectPay = profileServiceData.isDirectPay;
      this.memberuseridin = profileServiceData.useridin;
      this.subscriberId = profileServiceData.subscriberId;
      this.memberSuffix = profileServiceData.memberSuffix;
      this.groupUaCvg = profileServiceData.groupUaCvg;
    }
  }

  navigatePharmacyUrl(url: string) {
    if (url === 'https://www.pillpack.com') {
      this.openOtherPartySite(url);
    } else {
      if (url === '/my-pillpack/landing') {
        window.open("/my-pillpack/landing?icid='PillPack Global'", '_self');
      } else if (url === '/sso/expressscript') {
        this.openSsoEsiSite(url);
      } else {
        window.open(url);
      }
    }
  }

  prepareContactObject(aContactList) {
    let oContactObject = {};
    const aChangedContactList = [];
    let oTTY;
    if (this.authService.getScopeName() === 'REGISTERED-AND-VERIFIED') {
      oContactObject['href'] = `tel: 1-800-262-2583`;
      oContactObject['icon'] = 'fas fa-phone';
      oContactObject['number'] = `1-800-262-2583`;
      oContactObject['isTTY'] = 'TTY 711';
      oContactObject['text'] = 'Call Member Service';
      aChangedContactList.push(JSON.parse(JSON.stringify(oContactObject)));
      oContactObject = {};
      oContactObject['href'] = `tel: 1-800-247-2583`;
      oContactObject['icon'] = 'fas fa-phone';
      oContactObject['number'] = `1-800-247-2583`;
      oContactObject['text'] = 'Talk to a Nurse';
      aChangedContactList.push(JSON.parse(JSON.stringify(oContactObject)));
      oContactObject = {};
      oContactObject['href'] = 'https://myblue.bluecrossma.com/health-plan/telehealth';
      oContactObject['icon'] = 'fas fa-video';
      oContactObject['text'] = 'Talk to a Doctor';
      aChangedContactList.push(JSON.parse(JSON.stringify(oContactObject)));
      oContactObject = {};
      oContactObject['href'] = this.headerService.drupalsecureinquiry;
      oContactObject['icon'] = 'fas fa-lock';
      oContactObject['text'] = 'Send Message';
      aChangedContactList.push(JSON.parse(JSON.stringify(oContactObject)));
    } else {
      if (aContactList != null) {
        oTTY = aContactList.find(oCnct => (oCnct.text || '').trim() === 'TTY:');
        aContactList.forEach(oContact => {
          if ((oContact.text || '').trim() !== 'TTY:') {
            if (oContact.number) {
              oContactObject['href'] = `tel: ${oContact.number}`;
              oContactObject['icon'] = 'fas fa-phone';
              oContactObject['number'] = `1-${oContact.number}`;
              oContactObject['isTTY'] = (oContact.text || '').trim() === 'Call Member Service:' ? (oTTY ? `TTY ${oTTY.number}` : '') : '';
            } else if ((oContact.text || '').trim() === 'Talk to a Doctor') {
              oContactObject['href'] = 'https://myblue.bluecrossma.com/health-plan/telehealth';
              oContactObject['icon'] = 'fas fa-video';
              oContactObject['number'] = oContact.number;
            } else if ((oContact.text || '').trim() === 'Send a Message') {
              oContactObject['href'] = this.headerService.drupalsecureinquiry;
              oContactObject['icon'] = 'fas fa-lock';
              oContactObject['number'] = oContact.number;
            }
            oContactObject['text'] = (oContact.text || '').split(':')[0];
            aChangedContactList.push(JSON.parse(JSON.stringify(oContactObject)));
          }
        });
      }
    }
    return aChangedContactList;
  }

  openOtherPartySite(url) {
    sessionStorage.setItem('consentLink', url);
    $('#openPillPackSite').modal('open');
  }

  openSsoEsiSite(url) {
    if (!this.authService.impersonation()) {
      sessionStorage.setItem('consentLink', url);
      $('#openSsoEsiSite').modal('open');
    }
  }

  checkSmartShopperUser(postLoginInfo: any = {}) {
    return postLoginInfo.hasSS;
  }

  ngOnInit() {

    sessionStorage.setItem("isIPASelected", "false");

    if (environment.displayVirtualVisit) {
      this.fetchVitalsResponse();
    }
    this.isPillPackEnrolledThisSession = false;
    if (this.authService && this.authService.authToken && this.authService.authToken.userType) {
      this.userType = this.authService.authToken.userType.toLowerCase();
    }
    this.getMyPharmacyMenu();

    if (sessionStorage.getItem('isCompleteHanddoff') != null && sessionStorage.getItem('isCompleteHanddoff') !== '') {
      this.isPillPackEnrolledThisSession = JSON.parse(sessionStorage.getItem('isCompleteHanddoff'));
    } else {
      this.isPillPackEnrolledThisSession = false;
    }
    const hour = moment.tz(new Date(), 'America/New_York').hour();

    if (hour < 12) {
      this.estGreeting = 'Good morning';
    } else if (hour >= 12 && hour < 17) {
      this.estGreeting = 'Good afternoon';
    } else {
      this.estGreeting = 'Good evening';
    }
    const minute = moment.tz(new Date(), 'America/New_York').minute();
    const currentTime = parseFloat(parseFloat(`${hour}.${minute}`).toFixed(2));
    const isRtmsUpmode = currentTime >= 6 && currentTime <= 20 ? true : false;
    if (!isRtmsUpmode) {
      if (!this.authService.getRtmsMode()) {
        this.authService.setRtmsMode();
      }
    } else {
      this.authService.removeRtmsMode();
    }

    if (this.globalService.landingPageMemberInfo) {
      sessionStorage.setItem('isAllowedChangePCP', this.globalService.landingPageMemberInfo.isAllowedChangePCP);
      sessionStorage.setItem('isRequiredPCP', this.globalService.landingPageMemberInfo.isRequiredPCP);
      sessionStorage.setItem('hasPCP', this.globalService.landingPageMemberInfo.hasPCP);
      sessionStorage.setItem('hasCernerMedicare', this.globalService.landingPageMemberInfo.cerner.hasCernerMedicare);
      sessionStorage.setItem('isMedicarePPO', this.globalService.landingPageMemberInfo.isPPO);
      sessionStorage.setItem('hasBqi', this.globalService.landingPageMemberInfo.hasBQi);
    }

    this.isAllowedChangePCP = sessionStorage.getItem('isAllowedChangePCP');
    this.isRequiredPCP = sessionStorage.getItem('isRequiredPCP');
    this.hasPCP = sessionStorage.getItem('hasPCP');
    this.hasCernerMedicare = sessionStorage.getItem('hasCernerMedicare');
    this.isMedicarePPO = sessionStorage.getItem('isMedicarePPO');
    this.hasBqi = sessionStorage.getItem('hasBqi');
    this.wellnessVendorCd = sessionStorage.getItem('wellnessVendorCd');
    this.currentScope =
      this.authService && this.authService.authToken && this.authService.authToken.scopename ? this.authService.authToken.scopename : '';

    if (this.currentScope === 'AUTHENTICATED-NOT-VERIFIED') {
      this.memberFirstName =
        this.authService && this.authService.authToken && this.authService.authToken.firstName ? this.authService.authToken.firstName : '';
    } else if (this.currentScope === 'AUTHENTICATED-AND-VERIFIED') {
      this.memberFirstName =
        this.authService && this.authService.authToken && this.authService.authToken.firstName ? this.authService.authToken.firstName : '';
    } else {
      this.memberFirstName = '';
    }

    this.ismobile = window.innerWidth <= this.mobileViewPort ? true : false;
    this.leftMenuId = this.ismobile ? 'slide-out-left' : 'dropdown1';
    if (this.art.snapshot.data.menu === undefined) {
      if (this.authService.authToken && this.authService.authToken.scopename) {
        this.isAuthenticated = true;
      } else {
        this.isAuthenticated = false;
      }
    } else {
      this.isAuthenticated = this.art.snapshot.data.menu;
    }

    const init = function() {
      $('.menu-icon').sideNav({
        menuWidth: '100%',
        edge: 'right',
        onOpen: () => {
          $('body').removeAttr('style');
        }
      });
      $('.mobile-square-logo').sideNav({ menuWidth: '100%', onOpen: () => $('body').removeAttr('style') });

      $('.dropdown-button').dropdown({
        closeOnClick: false
      });
    };

    if (this.isAuthenticated) {
      // To load the drupal menu items
      this.setMenuItems();
      if (!this.headerService.unReadMsgCount) {
        this.setInboxUnreadMsgCount();
      }

      // To load the contact us number
      if (
        this.authService.authToken &&
        this.authService.authToken.userType &&
        this.authService.authToken.userType.toLowerCase() === 'medicare' &&
        this.authService.authToken.planTypes['medical'] === 'true'
      ) {
        this.isMedicareAdvantageMedicalContactUs = true;
      }
      if (
        this.authService.authToken &&
        this.authService.authToken.userType &&
        this.authService.authToken.userType.toLowerCase() === 'medex' &&
        this.authService.authToken.planTypes['medical'] === 'true'
      ) {
        this.isMedexMedicalContactUs = true;
      }
      if (
        this.authService.authToken &&
        this.authService.authToken.userType &&
        this.authService.authToken.userType.toLowerCase() === 'medicare' &&
        this.authService.authToken.planTypes['dental'] === 'true'
      ) {
        this.isMedicareAdvantageDentalContactUs = true;
      }
      if (
        this.authService.authToken &&
        this.authService.authToken.userType &&
        this.authService.authToken.userType.toLowerCase() === 'medex' &&
        this.authService.authToken.planTypes['dental'] === 'true'
      ) {
        this.isMedexDentalContactUs = true;
      }
    }

    $(document).ready(init);

    // preparing rweMenuList;
    this.rweMenuList = JSON.parse(JSON.stringify(RIGHTTOPMENU));
    this.rweMenuList.pop();

    this.mainMenuItems.forEach(items => {
      items.subMenuItems.forEach(element => {
        element.items.forEach(data => {
          if (this.globalService.landingPageMemberInfo && this.globalService.landingPageMemberInfo.userState === 'Inactive') {
            if (data.id === 'myDeductibles' && data.display === true) {
              data.display = false;
            }
            if (data.id === 'myCards' && data.display === true) {
              data.display = false;
            }
            if (data.id === 'planBenefits' && data.display === true) {
              data.display = false;
            }
          }
          if (data.display === false) {
            this.countArray.push(data);
          }
        });
        if (element.items.length === this.countArray.length && element.display) {
          element.display = false;
        }
        this.countArray = [];
      });
      items.isOpen = false;
    });

    this.mediCationUrl =
      this.authService.authToken && this.authService.authToken.userType && this.authService.authToken.userType.toLowerCase() === 'medicare'
        ? 'http://www2.bluecrossma.com/search-app/formulary-2020'
        : 'https://home.bluecrossma.com/medication/?icid=myblueglobalnav';

    if (
      this.authService.authToken &&
      this.authService.authToken.userType &&
      this.authService.authToken.userType.toLowerCase() === 'medicare'
    ) {
      this.mediCationUrl = 'http://www2.bluecrossma.com/search-app/formulary-2020';
    } else {
      this.mediCationUrl = 'https://home.bluecrossma.com/medication/?icid=myblueglobalnav';
    }
  }

  ngAfterViewInit() {
    setTimeout(() => $('.collapsible').collapsible(), 1000);
  }

  getFormularyInformation() {
    if (
      this.authService.getScopeName() !== 'REGISTERED-AND-VERIFIED' &&
      !sessionStorage.getItem('tierName') &&
      this.profileService.getProfile() &&
      this.profileService.getProfile().useridin
    ) {
      this.headerService.getformularyandtierInfo(this.memberuseridin, this.subscriberId, this.memberSuffix, this.groupUaCvg).subscribe(
        data => {
          this.isNPFformularyFlag = data.NPFFlag;
          this.tierNumber = data.tierNumber;
          if (!this.tierNumber) {
            sessionStorage.setItem('isTierErrorFound', JSON.stringify(true));
          } else {
            sessionStorage.setItem('isTierErrorFound', JSON.stringify(false));
            sessionStorage.setItem('tierName', this.tierNumber + '-Tier');
          }
          if (this.isNPFformularyFlag) {
            window.open(this.npfUrl);
          } else {
            this.router.navigate(['/med-lookup']);
          }
        },
        error => {
          sessionStorage.setItem('isTierErrorFound', JSON.stringify(true));
          console.warn(error);
        }
      );
    } else if (sessionStorage.getItem('tierName')) {
      if (this.isNPFformularyFlag) {
        window.open(this.npfUrl);
      } else {
        this.router.navigate(['/med-lookup']);
      }
    }
  }

  getMyPharmacyMenu() {
    const postLoginInfo = sessionStorage.getItem('postLoginInfo');
    if (postLoginInfo != null && postLoginInfo !== '') {
      this.pharmacymenu = JSON.parse(postLoginInfo).pharmacyLinks;
    }
    return this.pharmacymenu;
  }
  getRightMenu() {
    let val = RIGHTTOPMENU;
    if (this.authService.authToken && this.authService.authToken.scopename === 'AUTHENTICATED-AND-VERIFIED') {
      if (!(this.authService.authToken.isALG === 'true' || this.authService.authToken.isHEQ === 'true')) {
        val = val.filter(item => item['name'] !== 'My Financials');
      }
    }

    if (this.authService.authToken && this.authService.authToken.scopename === 'AUTHENTICATED-AND-VERIFIED') {
      if (this.authService.authToken.isHEQ === 'true') {
        val.forEach(item => {
          if (item['name'] === 'My Financials') {
            item['url'] = '/sso/heathequity';
          }
        });
      } else if (this.authService.authToken.isALG === 'true') {
        val.forEach(item => {
          if (item['name'] === 'My Financials') {
            item['url'] = '/sso/alegeus';
          }
        });
      }
    }

    if (this.authService.authToken && this.authService.authToken.scopename !== 'AUTHENTICATED-AND-VERIFIED') {
      val = this.updateFindADoctorUrl(val);
    } else if (
      this.authService.authToken &&
      this.authService.authToken.HasActivePlan === 'false' &&
      this.authService.authToken.scopename === 'AUTHENTICATED-AND-VERIFIED'
    ) {
      val = RIGHTTOPMENU_INACTIVE;
    } else if (
      this.authService.authToken &&
      this.authService.authToken.scopename === 'AUTHENTICATED-AND-VERIFIED' &&
      this.authService.authToken.HasActivePlan &&
      this.authService.authToken.HasActivePlan.toLowerCase() === 'true' &&
      (this.authService.authToken.userType === 'MEDICARE' ||
        this.authService.authToken.userType === 'MEDEX' ||
        (this.authService.authToken.planTypes && this.authService.authToken.planTypes['medical'] !== 'true'))
    ) {
      val = this.rweMenuList.filter(item => item.url !== '/request-estimate');
    }

    if (this.authService.authToken && this.authService.authToken.scopename !== 'AUTHENTICATED-AND-VERIFIED') {
      if (val) {
        val = val.filter(item => item['url'] !== '/myplans');
      } else {
        val = this.rweMenuList.filter(item => item.url !== '/myplans');
      }
    }

    const postLoginInfo = sessionStorage.getItem('postLoginInfo');
    if (postLoginInfo != null && postLoginInfo !== '') {
      const links = JSON.parse(postLoginInfo).pharmacyLinks;
      if (!links || (links && links.length < 1)) {
        val = val.filter(item => item['name'] !== 'My Pharmacy');
        val = val.filter(item => item['name'] !== 'My Medications');
      }
    }

    return val;
  }

  public setMenuItems() {
    this.rightMenuList =
      this.globalService.landingPageMemberInfo && this.globalService.landingPageMemberInfo.userState === 'InActive'
        ? RIGHTTOPMENU_INACTIVE
        : RIGHTTOPMENU;
    if (!this.headerService.menuItems) {
      this.headerService.getMenuItems().subscribe(apiData => {
        if (apiData && apiData.length) {
          this.noApiLinks = false;
          this.menuDrupalLinks = apiData;
          this.headerService.menuItems = apiData;
          const url = apiData[0].absolute;
          this.headerService.searchUrlTarget = url.substring(0, url.lastIndexOf('com') + 3);
        }
      });
    } else {
      this.menuDrupalLinks = this.headerService.menuItems;
    }
  }

  updateFindADoctorUrl(listItems) {
    const currentScope =
      this.authService && this.authService.authToken && this.authService.authToken.scopename ? this.authService.authToken.scopename : '';

    if (currentScope !== 'AUTHENTICATED-AND-VERIFIED' && listItems && listItems.length > 0) {
      const findADoctorIndex = listItems.findIndex(item => item.name === FINDADOCTORMENUITEM_TEXT);
      if (findADoctorIndex > -1) {
        listItems[findADoctorIndex].url = 'https://myblue.bluecrossma.com/health-plan/find-doctor-provider-dentist';
        listItems[findADoctorIndex].sso = false;
      }
    }
    return listItems;
  }

  public redirectToMenuPage(event, url: string): void {
    event.preventDefault();
    if (url && !url.endsWith('bluecrossma.com/sample')) {
      this.document.location.href = url;
      //this.router.navigate([url]);
    }
  }

  public leftMenuSelect(): void {
    this.leftMenuId = this.ismobile ? 'slide-out-left' : 'dropdown1';
    this.toggleClick = !this.toggleClick;
  }

  signOut() {
    this.alertService.clearError();
    this.globalService.logout();
    MENU_ITEMS_RESET_COPY();
  }

  public closeMobileMenu() {
    document.getElementById('mobile-side-menu').classList.remove('side-nav-open');
    document.getElementById('mobile-subside-menu').classList.remove('subside-nav-open');
    document.getElementById('mobile-search-page').classList.remove('side-nav-open');
    this.menuItemList = [];
  }

  public closePlansPage() {
    document.getElementById('mobile-plans-list-page').classList.remove('side-nav-open');
    document.getElementById('mobile-side-menu').classList.add('side-nav-open');
  }

  public closeMobileMenuForNavigatetoSamePage(e, menu, navigateFlag?: boolean): void {
    e.preventDefault();
    if (menu.url === this.router.url) {
      collapse = false;
      $(e.target).sideNav('hide');
    }
    if (navigateFlag) {
      if (/http[s]?:\/\//.test(menu.url)) {
        // if the link points to an external url do the required redirect
        window.location.href = menu.url;
      } else {
        // if the link points to an route url do the neccessary routing
        if (menu.url === '/fad') {
          this.openFadSSO();
          $('.menu-icon').sideNav('hide');
        } else if (
          menu.url === '/sso/alegeus' &&
          this.authService.authToken &&
          this.authService.authToken.scopename === 'AUTHENTICATED-AND-VERIFIED'
        ) {
          window.open('/sso/alegeus', '_blank');
          $('.menu-icon').sideNav('hide');
        } else if (
          menu.url === '/sso/heathequity' &&
          this.authService.authToken &&
          this.authService.authToken.scopename === 'AUTHENTICATED-AND-VERIFIED'
        ) {
          window.open('/sso/heathequity', '_blank');
          $('.menu-icon').sideNav('hide');
        } else if (menu.url === '/mypharmacy') {
          //return;
        } else {
          this.router.navigate([menu.url]);
        }
      }
    }
  }

  menuClick($event, menuItemId) {
    this.focusedInput = false;
    if (menuItemId === 'closebtn') {
      this.menuClosed = true;
      this.showMenuItems = false;
    } else {
      $event.stopPropagation();
      this.mainMenuItems.forEach(item => {
        if ((item.id === menuItemId.id && item.isOpen === false) || (item.id === menuItemId.id && this.menuClosed)) {
          item.isOpen = true;
          this.isOpenFlag = item.isOpen;
          this.menuClosed = false;
        } else if (item.id !== menuItemId.id) {
          item.isOpen = false;
        } else if (item.id === menuItemId.id && item.isOpen === true) {
          item.isOpen = false;
          this.isOpenFlag = item.isOpen;
          this.menuClosed = true;
        }
      });
      if (menuItemId.id === 'teamBlueSupport') {
        this.isTeamBlueSupport = true;
        const tempTeamBlueLinks = this.mainMenuItems.find(item => item.id === menuItemId.id);
        tempTeamBlueLinks.subMenuItems[0].items.forEach(element => {
          if (this.authService.getScopeName() !== 'REGISTERED-AND-VERIFIED') {
            if (
              element.id === 'remotedoctorvisit' &&
              (this.authService.authToken.userType.toLowerCase() === 'medicare' ||
                this.authService.authToken.userType.toLowerCase() === 'medex')
            ) {
              element.display = false;
            }
          } else {
            if (element.id === 'talktoanurse') {
              element.ph = '1-800-247-2583';
              element.url = `tel: 1-800-247-2583`;
            }
          }
          if (
            this.authService.authToken &&
            this.authService.authToken.userType &&
            this.authService.authToken.userType.toLowerCase() === 'medex'
          ) {
            if (element.id === 'callmemberservice') {
              element.ph = '1-800-258-2226';
              element.url = `tel: 1-800-258-2226`;
            }
          }
        });
        this.menuItemList = tempTeamBlueLinks.subMenuItems;
      } else {
        this.isTeamBlueSupport = false;
      }

      this.showMenuItems = this.isOpenFlag;
      const tempList = this.mainMenuItems.find(item => item.id === menuItemId.id).subMenuItems;
      if (this.authService.getScopeName() === 'REGISTERED-AND-VERIFIED') {
        const filterItems = tempList.filter(item => item);
        this.menuItemList = filterItems.filter(item => item.id !== 'prescriptionPrograms');
        this.menuItemList.forEach(item => {
          item.items.forEach(subitem => {
            if (subitem.id === 'startsavingwithsmartShopper') {
              subitem.display = false;
            }
          });
        });
      } else if (menuItemId.id === 'myMedications' && (this.pharmacymenu === undefined || this.pharmacymenu.length === 0)) {
        this.menuItemList = tempList.filter(item => item.id !== 'prescriptionPrograms');
      } else {
        tempList.forEach(item => {
          item.items.forEach(subitem => {
            if (menuItemId.id === 'myPlanAndClaims') {
              if (subitem.id === 'myebilling' && !this.hasEbillingEligibility) {
                subitem.display = false;
              }
            }
            if (menuItemId.id === 'myMedications') {
              this.pharmacymenu.forEach(pharmaItem =>
                pharmaItem.id === subitem.id ? (subitem.display = true) : (subitem.display = subitem.display)
              );
              if (subitem.id === 'allMedications') {
                subitem.display = true;
              }
              if (this.isPillPackEnrolledThisSession === true && subitem.id === 'ManageYourPillPackAccount') {
                subitem.display = true;
              }
              if (this.isPillPackEnrolledThisSession === true && subitem.id === 'SignUpforPillPack') {
                subitem.display = false;
              }
            }
            if (!this.isSmartShopperUser && subitem.id === 'startsavingwithsmartShopper') {
              subitem.display = false;
            }
            if (this.learnToLive) {
              subitem.id === 'onlineMentalHealthTool' ? (subitem.display = true) : (subitem.display = subitem.display);
            }
            if (this.hasBqi === 'true' && subitem.id === 'viewChangeOrRenewMyPlan') {
              subitem.id === 'viewChangeOrRenewMyPlan' ? (subitem.display = true) : (subitem.display = subitem.display);
              const impersonate = this.authService.impersonation();
              console.log('SSO blocked in Impersonation');
              if (!impersonate) {
                subitem.url = 'sso/connecture';
              }
            }
            if (this.authService.authToken.isHEQ === 'true') {
              if (subitem.id === 'myHealthFinancialAccounts') {
                subitem.display = true;
                subitem.url = '/sso/heathequity';
              }
            } else if (this.authService.authToken.isALG === 'true') {
              subitem.id === 'myHealthFinancialAccounts' ? (subitem.display = true) : (subitem.display = subitem.display);
            }
            if (
              this.isMedicarePPO &&
              this.authService.authToken.userType.toLowerCase() === 'medicare' &&
              this.isAllowedChangePCP === 'true' &&
              this.isRequiredPCP === 'true' &&
              this.hasPCP === 'false'
            ) {
              if (subitem.id === 'addChangePrimaryCarePhysician') {
                subitem.display = true;
                subitem.url = '/mydoctors/add-pcp-homepage';
                subitem.isExternal = false;
              }
            } else if (this.isAllowedChangePCP === 'true' && this.isRequiredPCP === 'true' && this.hasPCP === 'false') {
              if (subitem.id === 'addChangePrimaryCarePhysician') {
                subitem.display = true;
                subitem.url = '/mydoctors/add-pcp-homepage';
                subitem.isExternal = false;
              }
            } else if (this.isAllowedChangePCP === 'true' && this.isRequiredPCP === 'true' && this.hasPCP === 'true') {
              subitem.id === 'addChangePrimaryCarePhysician' ? (subitem.display = true) : (subitem.display = subitem.display);
            } else if (
              (this.isAllowedChangePCP === 'false' && this.isRequiredPCP === 'false' && this.hasPCP === 'false') ||
              this.authService.authToken.userType.toLowerCase() === 'medicare'
            ) {
              subitem.id === 'addChangePrimaryCarePhysician' ? (subitem.display = false) : (subitem.display = subitem.display);
            }

            if (this.hasCernerMedicare === 'true' || this.wellnessVendorCd === 'C') {
              subitem.id === 'aHealthyMe' ? (subitem.display = true) : (subitem.display = subitem.display);
            } else if(this.hasCernerMedicare === 'false' && this.wellnessVendorCd === 'VP') {
              subitem.id === 'wellnessRewardsProgram' ? (subitem.display = true) : (subitem.display = subitem.display);
            } 

          });
        });
        this.menuItemList = tempList;
      }
    }
  }

  navigateToMenuItem(menuItem, e) {
    if (menuItem.id === 'onlineMentalHealthTool' && menuItem.isSsoTrue) {
      sessionStorage.setItem('memberLinkLearnToLive', menuItem.url);
      $('#openLearnToLive').modal('open');
    } else if (menuItem.id === 'aHealthyMe') {
      this.openAhealthyme();
    } else if (menuItem.id === 'wellnessRewardsProgram') {
      $('#wellnessRewardsProgram').modal('open');
    } else if (menuItem.id === 'ManageYourPillPackAccount') {
      if (!this.authService.impersonation()) {
        sessionStorage.setItem('consentLink', menuItem.url);
        $('#openPillPackSite').modal('open');
      }
    } else if (menuItem.url === '/sso/heathequity' || menuItem.url === '/sso/alegeus' || menuItem.url === '/sso/ebilling') {
      if (menuItem.url === '/sso/alegeus') {
        sessionStorage.setItem('consentLink', '/sso/alegeus');
        $('#openSsoAlgSite').modal('open');
      } else if (menuItem.url === '/sso/ebilling') {
        $('#openSsoEbilling').modal('open');
      } else {
        sessionStorage.setItem('consentLink', '/sso/heathequity');
        $('#openSsoHeqSite').modal('open');
      }
    } else if (menuItem.id === 'ExpressScripts®' || menuItem.id === '90-DayMailOrderPharmacy') {
      $('#openSsoEsiSite').modal('open');
    } else if (menuItem.id === 'MedicationLookupTool') {
      this.medicationLookupNavigation();
    } else if (menuItem.id === 'sendsecuremessage') {
      window.open(menuItem.url, '_blank');
    } else if (menuItem.id === 'medicalCareAndCosts' || menuItem.id === 'startsavingwithsmartShopper') {
      this.openFadSSO();
    } else if (menuItem.url && !menuItem.isExternal && !menuItem.isSsoTrue) {
      this.router.navigateByUrl(menuItem.url);
    } else if (menuItem.url && menuItem.isExternal && (!menuItem.isSsoTrue || menuItem.isSsoTrue)) {
      window.open(menuItem.url, '_blank');
    } else {
      window.open(menuItem.url);
    }
  }

  medicationLookupNavigation() {
    const postLoginInfo = sessionStorage.getItem('postLoginInfo');
    if (postLoginInfo != null && postLoginInfo !== '') {
      this.pharmacymenu = JSON.parse(postLoginInfo).pharmacyLinks;
    }
    this.typeOfuser =
      this.authService && this.authService.authToken && this.authService.authToken.userType ? this.authService.authToken.userType : '';
    if (this.typeOfuser.toLowerCase() === 'medicare' && this.isDirectPay) {
      window.open(this.directPayMedicareUrl, '_blank');
    } else if (this.typeOfuser.toLowerCase() === 'medicare' && !this.isDirectPay) {
      window.open(this.medicareWithoutDirectPay, '_blank');
    } else if (this.typeOfuser.toLowerCase() === 'medex' && this.isDirectPay) {
      window.open(this.directPayMedexUserUrl, '_blank');
    } else if (this.typeOfuser.toLowerCase() === 'medex' && !this.isDirectPay) {
      window.open(this.medexWithoutdirectPayUrl, '_blank');
    } else if (
      this.currentScope === 'REGISTERED-AND-VERIFIED' ||
      (this.authService && this.authService.authToken && this.authService.authToken.HasActivePlan === 'false')
    ) {
      window.open(this.medLookUpUrl, '_blank');
    } else if (this.pharmacymenu.length === 0) {
      window.open(this.medLookUpUrl, '_blank');
    } else {
      //medlookup tool link
      this.getFormularyInformation();
    }
  }

  openAhealthyme() {
    // Impersonation has SSO blocked
    const impersonate = this.authService.impersonation();
    console.log('SSO blocked in Impersonation');
    if (this.globalService.landingPageMemberInfo.cerner.hasCernerMedicare === 'true' && !impersonate) {
      window.open(this.constantsService.cernerMedicareUrl, '_blank');
    } else if (this.wellnessVendorCd === 'C') {
      window.open('/sso/cerner', '_blank');
    }
  }

  fetchVitalsResponse() {
    const vitalsResponse = JSON.parse(sessionStorage.getItem('vitalsResponse'));
    if (!vitalsResponse && this.count < 20) {
      this.count++;
      setTimeout(() => this.fetchVitalsResponse(), 1000);
    } else {
      if (vitalsResponse) {
        this.teleHealthFlag = vitalsResponse.teleHealthEligible;
        this.mainMenuItems.forEach(items => {
          items.subMenuItems.forEach(element => {
            element.items.forEach(data => {
              if (
                data.id === 'virtualVisit' &&
                this.authService.authToken &&
                (this.authService.authToken.HasActivePlan === 'true' || 'TRUE') &&
                this.teleHealthFlag
              ) {
                data.display = true;
              }
            });
          });
        });
      }
    }
  }

  openMobileMenu(event) {
    document.getElementById('mobile-side-menu').classList.add('side-nav-open');
  }

  openSearchPage(event) {
    document.getElementById('mobile-search-page').classList.add('side-nav-open');
  }


  mobileMenuClick(menuItemId) {
    if (menuItemId === 'logout') {
      this.signOut();
    } else if (menuItemId === 'teamBlueSupport') {
      document.getElementById('mobile-subside-menu').classList.add('subside-nav-open');
      this.showSubMenuItems = true;
      const tempTeamBlueLinks = this.mainMenuItems.find(item => item.id === menuItemId);
      this.mobileSubHeadingName = 'Support';
      this.isTeamBlueSupport = menuItemId;
      tempTeamBlueLinks.subMenuItems[0].items.forEach(element => {
        if (this.authService.getScopeName() !== 'REGISTERED-AND-VERIFIED') {
          if (
            element.id === 'remotedoctorvisit' &&
            (this.authService.authToken.userType.toLowerCase() === 'medicare' ||
              this.authService.authToken.userType.toLowerCase() === 'medex')
          ) {
            element.display = false;
          }
        } else {
          if (element.id === 'talktoanurse') {
            element.ph = '1-800-247-2583';
            element.url = `tel: 1-800-247-2583`;
          }
        }
        if (
          this.authService.authToken &&
          this.authService.authToken.userType &&
          this.authService.authToken.userType.toLowerCase() === 'medex'
        ) {
          if (element.id === 'callmemberservice') {
            element.ph = '1-800-258-2226';
            element.url = `tel: 1-800-258-2226`;
          }
        }
      });
      this.menuItemList = tempTeamBlueLinks.subMenuItems;
    } else {
      this.isTeamBlueSupport = menuItemId;
      document.getElementById('mobile-subside-menu').classList.add('subside-nav-open');
      this.showSubMenuItems = true;
      const tempMenu = this.mainMenuItems.find(item => item.id === menuItemId);
      this.mobileSubHeadingName = tempMenu.label;
      const tempList = tempMenu.subMenuItems;
      if (this.authService.getScopeName() === 'REGISTERED-AND-VERIFIED') {
        this.menuItemList = tempList.filter(item => item);
        this.menuItemList.forEach(item => {
          item.items.forEach(subitem => {
            if (subitem.id === 'startsavingwithsmartShopper') {
              subitem.display = false;
            }
          });
        });
      }
      if (menuItemId === 'myMedications' && (this.pharmacymenu === undefined || this.pharmacymenu.length === 0)) {
        this.menuItemList = tempList.filter(item => item.id !== 'prescriptionPrograms');
      } else {
        tempList.forEach(item => {
          item.items.forEach(subitem => {
            if (menuItemId === 'myMedications') {
              this.pharmacymenu.forEach(pharmaItem =>
                pharmaItem.id === subitem.id ? (subitem.display = true) : (subitem.display = subitem.display)
              );
              if (subitem.id === 'allMedications') {
                subitem.display = true;
              }
            }
            if (this.learnToLive) {
              subitem.id === 'onlineMentalHealthTool' ? (subitem.display = true) : (subitem.display = subitem.display);
            }
            if (this.hasBqi === 'true' && subitem.id === 'viewChangeOrRenewMyPlan') {
              subitem.id === 'viewChangeOrRenewMyPlan' ? (subitem.display = true) : (subitem.display = subitem.display);
              const impersonate = this.authService.impersonation();
              console.log('SSO blocked in Impersonation');
              if (!impersonate) {
                subitem.url = 'sso/connecture';
              }
            }
            if (!this.isSmartShopperUser && subitem.id === 'startsavingwithsmartShopper') {
              subitem.display = false;
            }
            if (this.authService.authToken.isHEQ === 'true') {
              if (subitem.id === 'myHealthFinancialAccounts') {
                subitem.display = true;
                subitem.url = '/sso/heathequity';
              }
            } else if (this.authService.authToken.isALG === 'true') {
              subitem.id === 'myHealthFinancialAccounts' ? (subitem.display = true) : (subitem.display = subitem.display);
            }
            // if ((this.authService.authToken.userType.toLowerCase() === 'medicare') ||
            // this.authService.authToken.userType.toLowerCase() === 'medex') {
            //   subitem.id === 'wellConnection' ? subitem.display = false : subitem.display = subitem.display;
            // }
            if (
              this.isMedicarePPO &&
              this.authService.authToken.userType.toLowerCase() === 'medicare' &&
              this.isAllowedChangePCP === 'true' &&
              this.isRequiredPCP === 'true' &&
              this.hasPCP === 'false'
            ) {
              if (subitem.id === 'addChangePrimaryCarePhysician') {
                subitem.display = true;
                subitem.url = '/mydoctors/add-pcp-homepage';
                subitem.isExternal = false;
              }
            } else if (this.isAllowedChangePCP === 'true' && this.isRequiredPCP === 'true' && this.hasPCP === 'true') {
              subitem.id === 'addChangePrimaryCarePhysician' ? (subitem.display = true) : (subitem.display = subitem.display);
            } else if (this.isAllowedChangePCP === 'true' && this.isRequiredPCP === 'true' && this.hasPCP === 'false') {
              if (subitem.id === 'addChangePrimaryCarePhysician') {
                subitem.display = true;
                subitem.url = '/mydoctors/add-pcp-homepage';
                subitem.isExternal = false;
              }
            } else if (
              (this.isAllowedChangePCP === 'false' && this.isRequiredPCP === 'false' && this.hasPCP === 'false') ||
              this.authService.authToken.userType.toLowerCase() === 'medicare'
            ) {
              subitem.id === 'addChangePrimaryCarePhysician' ? (subitem.display = false) : (subitem.display = subitem.display);
            }
            if (this.hasCernerMedicare === 'true' || this.wellnessVendorCd === 'C') {
              subitem.id === 'aHealthyMe' ? (subitem.display = true) : (subitem.display = subitem.display);
            } else if(this.hasCernerMedicare === 'false' && this.wellnessVendorCd === 'VP') {
              subitem.id === 'wellnessRewardsProgram' ? (subitem.display = true) : (subitem.display = subitem.display);
            } 

          });
        });
        this.menuItemList = tempList;
      }
    }
  }
  navigateToInboxMobile() {
    this.router.navigate(['/message-center']);
  }

  searchDropdownNavigate(url) {
    if (url === 'fad') {
      this.openFadSSO();
    } else {
      this.medicationLookupNavigation();
    }
  }

  public menuCollapse(e): void {
    if (!this.ismobile) {
      collapse = true;
    } else {
      collapse = false;
    }
  }

  togglePharmaSubmenu($event, name) {
    if (name === 'My Pharmacy') {
      $event.preventDefault();
      $event.stopPropagation();
      this.isPharmaSubmenuOpen = !this.isPharmaSubmenuOpen;
    }
  }

  public toggleCollapse(e): void {
    if (($('#collapsible' + 'li') || $('#collapsible1' + 'li')) && collapse === true) {
      // || this.rightMenuList.sso === false
      e.stopPropagation();
    }
    collapse = false;
  }

  /**
   *
   *
   * @param {*} [oSearch]
   * @memberof HeaderComponent
   */
  public redirectToGetSearchResults(oSearch?: any): void {
    const searchTextValue = this.searchText.value;
    if (searchTextValue) {
      this.trimmedSearchText = searchTextValue.trim();
      if (this.trimmedSearchText) {
        if (!oSearch || (oSearch && oSearch.which === 13)) {
          // Redirect to myblue website to get the search results
          this.focusedInput = false;
          this.checkBenefitSearch();
        }
      }
    }
  }

  navigateToBenefitSearch() {
    const url = this.headerService.searchUrlTarget + '/search/node?keys=';
    this.isSearchEnabled
      ? this.router.navigate(['/benefit-search', this.trimmedSearchText])
      : window.open(url + this.trimmedSearchText, '_blank');
    this.trimmedSearchText = '';
  }

  checkBenefitSearch() {
    if (this.isSearchEnabledFailed) {
      const dialog = this.dialog.open(ServiceFailureModalComponent, {
        panelClass: 'service-failure-alert',
        data: {
          showRetry: this.searchEnableRetryCount === 0,
          title: 'Error Occurred',
          description: 'Searching for Benefits is not available at this time. Refresh the page or try again later.',
          ctaRetry: 'Refresh Page',
          cta2Text: 'Close'
        }
      });
      this.searchEnableRetryCount++;
      dialog.componentInstance.onRetryClicked.subscribe(() => {
        dialog.close();
        this.globalService.initIsSearchEnabled().catch(() => {
          this.checkBenefitSearch();
        });
      });
    } else {
      this.navigateToBenefitSearch();
    }
  }

  inputFocused() {
    this.focusedInput = true;
    this.inactiveUser = sessionStorage.getItem('userState');
    this.isMedexUser =
      this.authService.authToken && this.authService.authToken.userType && this.authService.authToken.userType.toLowerCase() === 'medex';
    this.isMedicareUser =
      this.authService.authToken && this.authService.authToken.userType && this.authService.authToken.userType.toLowerCase() === 'medicare';
    this.isRegisteredUser = this.authService.getScopeName().includes('REGISTERED');
  }

  public clearSearch(): void {
    this.searchText.setValue('');
    this.focusedInput = false;
  }

  public clickSearchBar(e): void {
    this.showContactUs = false;
    this.showSearchBar = !this.showSearchBar;
    if (this.showSearchBar) {
      this.document.body.style.overflowX = 'hidden';
    } else {
      this.document.body.removeAttribute('style');
    }
  }

  public toggleContactUs(): void {
    this.showSearchBar = false;
    this.showContactUs = !this.showContactUs;
    const postLoginInfo = sessionStorage.getItem('postLoginInfo');
    this.aContactList = this.prepareContactObject(postLoginInfo ? JSON.parse(postLoginInfo).phoneNumbers : []);
  }

  private setInboxUnreadMsgCount() {
    this.headerService.unReadMsgCount = this.authService.authToken ? Number(this.authService.authToken.unreadMsgCount) : 1;
  }

  get unreadMessageCount() {
    const pwkStatus: PWKStatus = JSON.parse(sessionStorage.getItem('pwkStatus'));
    let medicareMessageCount = 0;
    if (pwkStatus) {
      medicareMessageCount = (pwkStatus.seenMedicarePDF === 0 && pwkStatus.medicareDocExists) ? 1 : 0;
    }
    return Number(this.headerService.unReadMsgCount || '0') + medicareMessageCount  ;
  }

  openFadSSO() {
    // Impersonation has SSO blocked
    const impersonate = this.authService.impersonation();
    if ((this.postLoginInfoObj.hasSS || this.postLoginInfoObj.hasSSO || this.postLoginInfoObj.hasCI) && !impersonate) {
      window.open('sso/vitals', '_blank');
    } else {
      this.router.navigate(['/fad']);
    }
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
    this.subscription.unsubscribe();
  }
}
