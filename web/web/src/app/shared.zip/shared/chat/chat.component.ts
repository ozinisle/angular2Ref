import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import * as moment from 'moment';
import { Observable, Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { MyplansService } from '../../../app/pages/myplans/myplans.service';
import { environment } from '../../../environments/environment';
import { AuthService } from '../services/auth.service';
import { DynamicScriptLoaderService } from '../services/dynamic-script-loader.service';
import * as chat from './utils/chat.utils';

@Component({
  selector: 'app-chat',
  template: '',
})
export class ChatComponent implements OnInit, OnDestroy {

  memProfile: any;
  isChatVisible: boolean = false;
  isChatPopepOut: boolean = false;
  destroy$ = new Subject<void>();

  static readonly config = {
    serverUrl: environment.liveChatServerUrl,
    entryPoint: environment.liveChatEntryPoint,
    template: 'bcbsmyblue',
  }

  constructor(
    private scripLoader: DynamicScriptLoaderService,
    private myplansService: MyplansService,
    public authService: AuthService,
  ) { }

  ngOnInit(): void {
    this.memProfile = JSON.parse(sessionStorage.getItem('memProfile'));

    if (chat.isChatActive() && this.memProfile.useridin && this.authService.getScopeName() !== 'REGISTERED-AND-VERIFIED') {
      this.showAqua();
    }
  }

  ngOnDestroy(): void {
    this.memProfile = JSON.parse(sessionStorage.getItem('memProfile'));
    if (this.memProfile === null || !this.memProfile.useridin) {
      this.destroyChat();
    }
  }

  @HostListener('window:message', ['$event']) onMessage(event) {
    let data = chat.parseData(event.data);

    if (data.Method === 'RESET_CHAT') {
      this.resetChat()
    }

    if (data.Method === 'SET') {
      if (data.Key === 'egPopoutWindow' && data.Value === false && this.isChatPopepOut) {
        this.resetChat() // alow a reset coming from closing the popup window
      }

      if (data.Key === 'CUSTOM_CONFIRM_CLOSE') {
        let returnValue = confirm(data.Value)
        let iframeWin = document.getElementById("egain-chat-iframe") as HTMLIFrameElement
        const iframe = iframeWin.contentWindow;
        iframe.postMessage(returnValue + '', ChatComponent.config.serverUrl);
      }
    }

    if (data.Method === 'REMOVE') {
      if (data.Key === 'egChatInProgress') {
        this.resetChat()
      }
    }

    if (data.Method === 'POPOUT') {
      if (data.Key === 'POPOUT_START') {
        this.isChatPopepOut = true;
      }
    }
  }

  getPlansAccountNumber() {
    let accountNumber: string;
    if (!sessionStorage.getItem('accountNumber')) {
      const effectiveDate = moment().format('YYYY-MM-DD');
      return this.myplansService.getPlansData(effectiveDate).takeUntil(this.destroy$).pipe(map(data => {
        if (data.result < 0) {
          sessionStorage.setItem('accountNumber', "");
          return '';
        } else {
          accountNumber = chat.getAccountDetatils(data["RowSet"]['osplinPlans'].plans);
          sessionStorage.setItem('accountNumber', accountNumber);
          return accountNumber
        }
      }))
    } else {
      accountNumber = sessionStorage.getItem('accountNumber');
      return Observable.of(accountNumber);
    }
  }

  getEgainDockChatObject() {
    let egainDockChat = window['egainDockChat'] || {};
    window['egainDockChat'] = egainDockChat
    return egainDockChat;
  }

  showAqua() {
    this.getPlansAccountNumber().subscribe((accountNumber) => {
      this.isChatVisible = true;
      this.scripLoader.loadScript('livechat').then(() => this.loadAqua(accountNumber))
    })
  }

  loadAqua(accountNumber) {

    let egainDockChat = this.getEgainDockChatObject();

    egainDockChat.serverURL = ChatComponent.config.serverUrl;
    egainDockChat.EntryPointId = ChatComponent.config.entryPoint;
    egainDockChat.Locale = 'en-US';
    egainDockChat.Template = ChatComponent.config.template;
    egainDockChat.PostChatAttributes = true;
    egainDockChat.IntegratedEntryPoint = false;

    egainDockChat.Debug = true

    egainDockChat.VChatParams = ''
    egainDockChat.VChatParams += '&wsname=' + window.top.location.origin;
    egainDockChat.VChatParams += '&subActivity=Chat';

    this.memProfile = JSON.parse(sessionStorage.getItem('memProfile'));

    egainDockChat.SetCustomerParameters = function (egainAttributeName, attributeValue) {
      if (!egainDockChat.SetParameter) {
        egainDockChat.CallQueue = egainDockChat.CallQueue || [];
        egainDockChat.CallQueue.push({ name: 'SetParameter', args: [egainAttributeName, attributeValue] });
      } else {
        egainDockChat.SetParameter(egainAttributeName, attributeValue);
      }
    };

    if (this.memProfile.fullName) {
      egainDockChat.SetCustomerParameters('fieldname_1', this.memProfile.fullName);
    }
    if (this.memProfile.emailAddress) {
      egainDockChat.SetCustomerParameters('fieldname_2', this.memProfile.emailAddress);
    }
    if (this.memProfile.subscriberId) {
      egainDockChat.SetCustomerParameters('fieldname_3', (this.memProfile.subscriberId as string).substring(0, 9));
    }
    const accountNumberVal = accountNumber ? accountNumber : '';
    egainDockChat.SetCustomerParameters('fieldname_4', accountNumberVal);

    if (!egainDockChat.launchChat) {
      egainDockChat.CallQueue = egainDockChat.CallQueue || [];
      egainDockChat.CallQueue.push({ name: 'launchChat', args: [] });
    } else {
      egainDockChat.launchChat();
    }

  }

  destroyChat() {
    let egainDockChat = this.getEgainDockChatObject();

    if (this.isChatVisible) {
      if (egainDockChat.iframeWrapper) {
        egainDockChat.iframeWrapper.parentNode.removeChild(egainDockChat.iframeWrapper);
      }
      this.isChatVisible = false;
    }

    localStorage.removeItem('egSessionId')
    localStorage.removeItem('egChatWindowState')
    localStorage.removeItem('egBadgeCount')
    localStorage.removeItem('EgainLastRequestId')
    localStorage.removeItem('egChatInProgress')
    localStorage.removeItem('egOffRecordBtnState')
    localStorage.removeItem('egChatStateBeforeUnload')
    localStorage.removeItem('isUnDockedChatInProgress')

  }

  resetChat() {
    this.destroyChat()
    if (chat.isChatActive() && this.memProfile.useridin) {
      this.showAqua();
    }
  }

}