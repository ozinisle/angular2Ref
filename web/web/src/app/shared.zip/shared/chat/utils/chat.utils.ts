import * as moment from 'moment-timezone';

export const getAccountDetatils = data => {
    let benefitMap = {};

    if (data.length > 0) {
        data.forEach(data => {

            let code: string, coverageType: string, accountNumber: string = '';
            if (data.osplinPlanMembers.members[0].UACoverageCode) {
                if (data.osplinPlanMembers.members[0].UACoverageCode.medicalCoverageUA) {
                    code = data.osplinPlanMembers.members[0].UACoverageCode.medicalCoverageUA.code;
                    coverageType = 'medical';
                } else if (data.osplinPlanMembers.members[0].UACoverageCode.dentalCoverageUA) {
                    code = data.osplinPlanMembers.members[0].UACoverageCode.dentalCoverageUA.code;
                    coverageType = 'dental';
                } else if (data.osplinPlanMembers.members[0].UACoverageCode.visionCoverageUA) {
                    code = data.osplinPlanMembers.members[0].UACoverageCode.visionCoverageUA.code;
                    coverageType = 'vision';
                } else {
                    code = '';
                    coverageType = '';
                }
            }

            if (data.groupInfo.group) {
                data.groupInfo.group.forEach(element => {
                    if (element.accountNumber) {
                        accountNumber = element.accountNumber; //TODO this might need to be refactored
                        return;
                    }
                });
            }

            if (coverageType) {
                benefitMap[coverageType] = {
                    accountNumber: accountNumber,
                    coverageCode: code,
                }
            }

        });
    }

    let combinedcoverageCodeAndAccNumber: string, key: string;
    if (benefitMap['medical']) {
        key = 'medical'
    } else if (benefitMap['dental']) {
        key = 'dental'
    } else if (benefitMap['vision']) {
        key = 'vision'
    }
    if (key) {
        combinedcoverageCodeAndAccNumber = benefitMap[key].accountNumber + benefitMap[key].coverageCode
    }
    return combinedcoverageCodeAndAccNumber;
}

export const parseData = data => {
    if (!data) return {};
    if (typeof data === 'object') return data;
    if (typeof data === 'string') return JSON.parse(data);
    return {};
}

const HOLIDAYS = [ //Starting from 09/21
    "2021-09-06", // Labor Day
    "2021-10-11", // Columbus Day
    "2021-11-11", // Veteran's Day
    "2021-11-25", // Thanksgiving Day
    "2021-11-26", // Day After Thanksgiving
    "2021-12-24", // Christmans Day (Observed)
]

export const isChatActive = () => {
    const currentDate = moment(new Date()).tz('America/New_York')

    const format = 'hh:mm:ss'

    const beforeTime = moment.tz('08:00:00', format, 'America/New_York');
    const afterTime = moment.tz('21:00:00', format, 'America/New_York');

    const isHoliday = HOLIDAYS.find(x => x === currentDate.format('YYYY-MM-DD'));

    // 0 - Sunday
    return currentDate.day() >= 1 && currentDate.day() <= 5 && currentDate.isBetween(beforeTime, afterTime) && isHoliday === undefined
}