import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { SelectPlanModalService } from '../components/select-plan-modal/select-plan-modal.service';
import { AuthToken } from '../models/authToken';
import { AuthService } from '../shared.module';

@Injectable()
export class HomePlanswitchguardGuard implements CanActivate {
  constructor(private authService: AuthService, public selectPlanSerice: SelectPlanModalService) {}
  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    const selectedPlanDetails = JSON.parse(sessionStorage.getItem('selectedPlanDetails'));
    const defaultIPAPlan = JSON.parse(sessionStorage.getItem('defaultIPAPlan'));
    const hasMultiplePlans =
      sessionStorage.getItem('getMemberPlans') && JSON.parse(sessionStorage.getItem('getMemberPlans')).hasMultiplePlans;
    if (
      selectedPlanDetails &&
      defaultIPAPlan &&
      hasMultiplePlans &&
      selectedPlanDetails.cardMemId &&
      defaultIPAPlan.cardMemId !== selectedPlanDetails.cardMemId
    ) {
      return this.selectPlanSerice.getSwitchPlanAPI(defaultIPAPlan.cardMemId, defaultIPAPlan.cardMemSuffix).pipe(
        map(res => {
          if (res && res.refresh_token) {
            sessionStorage.setItem('isIPASelected', 'true');
            sessionStorage.setItem('selectedPlanDetails', sessionStorage.getItem('defaultIPAPlan'));
            this.authService.authToken = new AuthToken(res);
            sessionStorage.setItem('authToken', JSON.stringify(this.authService.authToken));
            sessionStorage.setItem('postLoginInfo', sessionStorage.getItem('postLoginInfoBackup'));
            return true;
          }
        })
      );
    }
    return true;
  }
}
