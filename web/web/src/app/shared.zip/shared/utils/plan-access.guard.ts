import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanDeactivate, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { MyplansComponent } from '../../pages/myplans/myplans.component';
import { SelectPlanModalService } from '../components/select-plan-modal/select-plan-modal.service';
import { AuthToken } from '../models/authToken';
import { AuthService } from '../services/auth.service';

@Injectable()
export class PlanAccessGuard implements CanDeactivate<MyplansComponent> {
  routerUrlArray = ['mydoctors', 'myclaims', 'myplans', 'mydedco', 'mymedications'];
  constructor(private router: Router, private authService: AuthService, public selectPlanSerice: SelectPlanModalService) {}
  canDeactivate(
    component: MyplansComponent,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot
  ): boolean | Observable<boolean> | Promise<boolean> {
    if (!this.routerUrlArray.includes(nextState.url.split('/')[1])) {
      const selectedPlanDetails = JSON.parse(sessionStorage.getItem('selectedPlanDetails'));
      const defaultIPAPlan = JSON.parse(sessionStorage.getItem('defaultIPAPlan'));
      const hasMultiplePlans =
        sessionStorage.getItem('getMemberPlans') && JSON.parse(sessionStorage.getItem('getMemberPlans')).hasMultiplePlans;

      if (
        selectedPlanDetails &&
        selectedPlanDetails.cardMemId &&
        defaultIPAPlan &&
        hasMultiplePlans &&
        defaultIPAPlan.cardMemId
      ) {
        return this.selectPlanSerice.getSwitchPlanAPI(defaultIPAPlan.cardMemId, defaultIPAPlan.cardMemSuffix).pipe(
          map(res => {
            if (res && res.refresh_token) {
              sessionStorage.setItem('isIPASelected', 'true');
              sessionStorage.setItem('selectedPlanDetails', JSON.stringify(defaultIPAPlan));
              this.authService.authToken = new AuthToken(res);
              sessionStorage.setItem('authToken', JSON.stringify(this.authService.authToken));
              sessionStorage.setItem('postLoginInfo', sessionStorage.getItem('postLoginInfoBackup'));
              return true;
            }
          })
        );
      }
    }
    return true;
  }
}
