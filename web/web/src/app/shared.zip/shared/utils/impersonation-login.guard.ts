import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../../environments/environment';
import { AuthService } from '../services/auth.service';

@Injectable()
export class ImpersonationLoginGuard implements CanActivate {
  constructor(private router: Router) {}

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    const impersonation = environment.impersonation;
    if (impersonation) {
      console.log('Login / Register / Forgot Username & Password Blocked during Impersonation');
      this.router.navigate(['impersonation/error']);
      return false;
    } else {
      console.log('Login not Blocked');
      return true;
    }
  }
}
