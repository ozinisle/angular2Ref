import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class CostShareGuard implements CanActivate {

  constructor(private router: Router) {
  }

  canActivate(): Observable<boolean> | Promise<boolean> | boolean {
    if (!this.hasCostShareAccess()) {
      this.router.navigate(['/home']);
    }
    return this.hasCostShareAccess();
  }

  hasCostShareAccess() {
    const postLoginInfo = JSON.parse(sessionStorage.getItem('postLoginInfo'));
    if (postLoginInfo && postLoginInfo.pharmacyLinks) {
      return postLoginInfo.pharmacyLinks.some(link => link.url === '/cost-share');
    } else {
      setTimeout(() => { this.hasCostShareAccess(); }, 1000);
    }
  }

}
