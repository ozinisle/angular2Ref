import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { AlertType } from '../alerts/alertType.model';
import { SelectPlanModalService } from '../components/select-plan-modal/select-plan-modal.service';
import { AuthToken } from '../models/authToken';
import { AlertService } from '../services/alert.service';
import { AuthHttp } from '../services/auth-http.service';
import { AuthService } from '../services/auth.service';

@Injectable()
export class PlanAccessEntryGurad implements CanActivate {
  routerUrlArray = ['mydoctors', 'myclaims', 'myplans', 'mydedco', 'mymedications'];
  showBlueBar = false;

  constructor(
    private router: Router,
    private authService: AuthService,
    public selectPlanSerice: SelectPlanModalService,
    private authHttpService: AuthHttp,
    private alertService: AlertService
  ) {}
  canActivate(): Observable<boolean> | Promise<boolean> | boolean {
    this.showBlueBar = false;
    const selectedPlanDetails = JSON.parse(sessionStorage.getItem('selectedPlanDetails'));
    const defaultIPAPlan = JSON.parse(sessionStorage.getItem('defaultIPAPlan'));
    const hasMultiplePlans =
      sessionStorage.getItem('getMemberPlans') && JSON.parse(sessionStorage.getItem('getMemberPlans')).hasMultiplePlans;
    this.routerUrlArray.forEach(item => {
      if (this.router.url.includes(item) || this.router.url === '/') {
        this.showBlueBar = true;
        return false;
      }
    });
    if (!this.showBlueBar) {
      if (sessionStorage.getItem('defaultPlan')) {
        sessionStorage.setItem('selectedPlanName', sessionStorage.getItem('defaultPlan'));
      }
    }
    if (!this.showBlueBar && selectedPlanDetails && selectedPlanDetails.cardMemId !== 'null') {
      sessionStorage.setItem('selectedPlanDetails', sessionStorage.getItem('defaultIPAPlan'));
    } else if (this.showBlueBar && selectedPlanDetails && selectedPlanDetails.cardMemId === 'null') {
      sessionStorage.setItem('selectedPlanDetails', sessionStorage.getItem('defaultIPAPlan'));
    }
    if (
      defaultIPAPlan &&
      hasMultiplePlans &&
      defaultIPAPlan.cardMemId &&
      selectedPlanDetails &&
      selectedPlanDetails.cardMemId !== 'null' &&
      defaultIPAPlan.cardMemId !== selectedPlanDetails.cardMemId &&
      sessionStorage.getItem('currentPageReload') === 'false'
    ) {
      return this.selectPlanSerice.getSwitchPlanAPI(selectedPlanDetails.cardMemId, selectedPlanDetails.cardMemSuffix).pipe(
        map(res => {
          if (res && res.result && res.result < 0) {
            this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure);
          } else {
            sessionStorage.setItem('isIPASelected', 'true');
            this.authService.authToken = new AuthToken(res);
            sessionStorage.setItem('authToken', JSON.stringify(this.authService.authToken));
            if (sessionStorage.getItem('isIPASelected') === 'true') {
              this.authHttpService.postlogin().then(response => {
                if (response && response.error !== true) {
                  sessionStorage.setItem('postLoginInfo', JSON.stringify(response));
                }
              });
            }
          }
          return true;
        })
      );
    }
    return true;
  }
}
