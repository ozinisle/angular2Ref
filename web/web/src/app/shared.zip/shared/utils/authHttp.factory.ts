import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Store } from '@ngrx/store';
import { State } from '../../app.reducer';
import { LoadingSpinnerService } from '../../core/components/loading-spinner';
import { PlanConfigService } from '../../services/plan-config/plan-config-service';
import { AuthHttp } from '../services/auth-http.service';
import { AuthService } from '../services/auth.service';
import { ConstantsService } from '../services/constants.service';
import { TimerService } from '../services/timer.service';

export function authHttpFactory(
  httpClient: HttpClient,
  authService: AuthService,
  constantsService: ConstantsService,
  spinner: LoadingSpinnerService,
  store: Store<State>,
  timerService: TimerService,
  planConfigService: PlanConfigService
): HttpClientModule {
  return new AuthHttp(httpClient, authService, constantsService, spinner, store, timerService, planConfigService);
}
