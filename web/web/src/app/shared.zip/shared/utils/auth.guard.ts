import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AuthService } from '../services/auth.service';
import { GlobalService } from '../services/global.service';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private router: Router, private authService: AuthService) {}

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    const isAuthenticated = this.authService.isAuthenticated();
    if (isAuthenticated) {
      if (!this.authService.hasMembershipStarted()) {
        this.router.navigate(['too-soon']);
        return false;
      }
      if (localStorage.getItem('targetRoute')) {
        localStorage.removeItem('targetRoute');
      }
      return true;
    } else {
      sessionStorage.clear();
      localStorage.setItem('targetRoute', state.url);
      this.router.navigate(['login']);
      return false;
    }
  }
}
