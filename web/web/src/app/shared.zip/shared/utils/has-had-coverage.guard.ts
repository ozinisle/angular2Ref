import { Injectable } from '@angular/core';
import { CanActivate, CanActivateChild, CanLoad, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AuthService } from '../services/auth.service';

/**
 * Route guard to determine if the current user has had plan coverage at some
 * point (does not have to be active coverage).
 *
 * All route guard checks redirect to "/home" if not allowed.
 *
 * Can also be injected as a Service. The Observable property ```hasHadCoverage$```
 * can be used to perform the check without redirecting.
 */
@Injectable()
export class HasHadCoverageGuard implements CanLoad, CanActivate, CanActivateChild {
  /**
   * Whether the current user has had plan coverage at some point
   * (does not have to be active coverage).
   *
   * Note: This is a _hot_ Observable -- use rxjs operator take(1)
   * if you only need the current value.
   */
  public get hasHadCoverage$(): Observable<boolean> {
    return this.authService.authToken$.map(authToken => {
      const coverageTimestamp = !authToken || !authToken.coverageEffectiveDate ? null : authToken.coverageEffectiveDate;
      const hasHadCoverage = coverageTimestamp && new Date(coverageTimestamp) < new Date();
      return hasHadCoverage;
    });
  }

  constructor(private router: Router, private authService: AuthService) {}

  canActivate(): Observable<boolean> {
    return this.confirmOrRedirect();
  }

  canActivateChild(): Observable<boolean> {
    return this.confirmOrRedirect();
  }

  canLoad(): Observable<boolean> {
    return this.confirmOrRedirect();
  }

  private confirmOrRedirect(): Observable<boolean> {
    return this.hasHadCoverage$.take(1).do(hasHadCoverage => {
      if (!hasHadCoverage) {
        this.router.navigate(['/home']);
      }
    });
  }
}
