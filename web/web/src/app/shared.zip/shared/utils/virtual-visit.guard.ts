import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../../environments/environment';

@Injectable()
export class VirtualVisitGuard implements CanActivate {
  constructor(private router: Router) {}

  canActivate(): Observable<boolean> | Promise<boolean> | boolean {
    const hasAccess = this.hasVirtualVisitAccess() && !environment.impersonation;
    if (!hasAccess) {
      this.router.navigate(['/home']);
    }
    return hasAccess;
  }

  hasVirtualVisitAccess() {
    const vitalsResponse = JSON.parse(sessionStorage.getItem('vitalsResponse'));
    if (vitalsResponse) {
      return vitalsResponse.teleHealthEligible;
    } else {
      setTimeout(() => {
        this.hasVirtualVisitAccess();
      }, 1000);
    }
  }
}
