import { Injectable } from '@angular/core';
import { CanActivate, CanActivateChild, CanLoad, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { ProfileService } from '../services/myprofile/profile.service';

/**
 * Route guard to determine if the current user is the primary subscriber of
 * their health plan (i.e., not a spouse or dependent).
 *
 * All route guard checks redirect to "/home" if not allowed.
 */
@Injectable()
export class SubscriberGuard implements CanLoad, CanActivate, CanActivateChild {
  constructor(private router: Router, private profileService: ProfileService) {}

  canActivate(): Observable<boolean> {
    return this.confirmOrRedirect();
  }

  canActivateChild(): Observable<boolean> {
    return this.confirmOrRedirect();
  }

  canLoad(): Observable<boolean> {
    return this.confirmOrRedirect();
  }

  private confirmOrRedirect(): Observable<boolean> {
    return this.profileService.isSubscriber$.take(1).do(isSubscriber => {
      if (!isSubscriber) {
        this.router.navigate(['/home']);
      }
    });
  }
}
