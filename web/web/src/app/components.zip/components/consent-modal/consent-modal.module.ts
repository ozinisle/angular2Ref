import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConsentModalComponent } from './consent-modal.component';

@NgModule({
  imports: [CommonModule],
  declarations: [ConsentModalComponent]
})
export class ConsentModalModule {}
