import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material';
import { SESSION_STORAGE } from 'angular-webstorage-service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { createParamObject, createUpdatePrefObject, getPreferenceCID, updateConsentReqParam } from '../../pages/preference-modal/preference.utils';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { GlobalService } from '../../shared/services/global.service';
import { PreferencesService } from '../../shared/services/myprofile/preferences.service';
import { StorageService } from '../../shared/services/storage.service';
import { AuthService } from '../../shared/shared.module';

@Component({
  selector: 'app-consent-modal',
  templateUrl: './consent-modal.component.html',
  styleUrls: ['./consent-modal.component.scss']
})
export class ConsentModalComponent implements OnInit, OnDestroy {
  consentDetails: any = this.data.getConsentRes;
  drupalConsent: any = this.data.drupalConsent ? this.data.drupalConsent[0] : null;
  isConsentScrolled = false;
  prefCID: string;
  showSuccess = false;
  showFailure = false;

  destroy$ = new Subject<void>();

  constructor(
    @Inject(SESSION_STORAGE) private storage: StorageService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private authService: AuthService,
    private globalService: GlobalService,
    private authHttp: AuthHttp,
    private preferenceService: PreferencesService,
    public dialog: MatDialog
  ) {}

  ngOnInit() {
    this.prefCID = getPreferenceCID(this.data.preferences);
  }

  onConsentScrolled($event) {
    const { target } = $event;
    if (target.offsetHeight + target.scrollTop >= target.scrollHeight) {
      this.isConsentScrolled = true;
    }
  }

  submitConsent() {
    const consentData = {
      consentLanguageId: this.drupalConsent.Version,
      consentTS: new Date()
    };
    const requiredParameters = createParamObject(this.authHttp.sessionid(), consentData, new Date(), 'A', this.prefCID);
    this.authHttp.showSpinnerLoading();

    this.preferenceService.updatePreferences(createUpdatePrefObject([], requiredParameters, true)).subscribe(res => {
      if (res.result === 0) {
        this.updateConsentInfo(consentData);
      } else {
        this.showFailure = true;
      }
      this.authHttp.hideSpinnerLoading();
    });
  }

  updateConsentInfo(consentData) {
    const reqParamater = updateConsentReqParam(this.authService.useridin, consentData, this.drupalConsent, true);
    this.globalService
      .updateConsent(reqParamater)
      .pipe(takeUntil(this.destroy$))
      .subscribe(() => {
        this.consentDetails = reqParamater;
        this.showSuccess = true;
        sessionStorage.setItem('consentData', JSON.stringify({ ...this.consentDetails, consentData }));
      });
  }

  dismissModal() {
    this.dialog.closeAll();
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  // closeModalIfTimedOut() {
  //   const isUserLoginValid = this.authService.isLogin();
  //   if (!isUserLoginValid) {
  //     this.dismissModal();
  //   }
  //   return isUserLoginValid;
  // }
}
