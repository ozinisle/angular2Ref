export const EMAIL_FORM_MESSAGES = {
    required: 'You must enter your email address.',
    invalidEmail: 'You must enter a valid email address.'
};
