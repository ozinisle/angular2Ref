import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UNDELIVERABLE_MESSAGE } from '../../pages/preference-modal/preference-modal/preference-modal.constants';
import { AlertType } from '../../shared/alerts/alertType.model';
import { AuthService } from '../../shared/services/auth.service';
import { GlobalService } from '../../shared/services/global.service';
import { PreferencesService } from '../../shared/services/myprofile/preferences.service';
import { ValidationService } from '../../shared/services/validation.service';
import { AlertService } from '../../shared/shared.module';
import { EMAIL_FORM_MESSAGES } from './profile-email.constants';

@Component({
  selector: 'app-profile-email',
  templateUrl: './profile-email.component.html',
  styleUrls: ['./profile-email.component.scss']
})
export class ProfileEmailComponent implements OnInit, OnChanges {

  @Input() profile: any;
  @Input() editEmail: boolean;
  @Input() slot: string;
  @Input() isEmailUnDeliverable: boolean;
  @Input() isChannelEditCancelledEmail: any;
  @Output() cancelEdit: EventEmitter<any> = new EventEmitter();
  @Output() editProfile: EventEmitter<any> = new EventEmitter();

  impersonate = true;

  isFormSubmitted = false;
  profileEmailEditForm: FormGroup;
  emailMessages = EMAIL_FORM_MESSAGES;
  hasActivePlan: string;

  constructor(
    private fb: FormBuilder,
    private validationService: ValidationService,
    private globalService: GlobalService,
    private authService: AuthService,
    private alertService: AlertService,
    private prefService: PreferencesService
  ) {
    this.hasActivePlan = this.authService.isUserActive();
   }

  ngOnInit() {
    this.prefService.closeChannelEdit.subscribe((response) => {
      if (response.channel === 'Email' && response.status === 'true') {
        this.cancelEmail();
      } else if (response.channel === 'Email' && response.status === 'false'){
        this.editEmail = true;
      }
    });
    this.showAlertMessage();
  }

  showAlertMessage() {
    setTimeout(() => {
      if (this.isEmailUnDeliverable) {
        this.alertService.setAlert(UNDELIVERABLE_MESSAGE.email, '', AlertType.Failure,
        'component', 'profileEmailMessage');
      }
    }, 0);
  }

  initializeEmailForm() {
    this.profileEmailEditForm = this.fb.group({
      useridin: '',
      emailAddress: ['', this.editEmail ? [Validators.required, this.validationService.emailValidator()] : []],
      fullName: '',
      isVerifiedEmail: false
    });
    if (this.profile) {
      this.profileEmailEditForm.patchValue(this.profile);
      this.globalService.markFormGroupTouched(this.profileEmailEditForm);
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.editEmail) {
      this.initializeEmailForm();
    }
    if (this.profileEmailEditForm) {
      this.profileEmailEditForm.patchValue(this.profile);
    }
  }

  get isButtonDisabled() {
    return this.impersonation() || !this.profileEmailEditForm.valid ||
          this.hasActivePlan === 'false' ||
          this.profile.emailAddress.toLowerCase() === this.profileEmailEditForm.get('emailAddress').value.toLowerCase();
  }

  impersonation() {
    return this.authService.impersonation();
  }

  onEmailSubmit() {
    this.isFormSubmitted = true;
    this.editEmail = false;
    let profile = JSON.parse(sessionStorage.getItem('memProfile'));
    profile = { ...profile, emailAddress: this.profileEmailEditForm.value.emailAddress, isVerifiedEmail: false };
    sessionStorage.setItem('memProfile', JSON.stringify(profile));
    this.editProfile.emit('EMAIL');
    this.prefService.isChannelEditSaved.next({
      channel: 'Email',
      status: 'true'
    })
  }

  cancelEmail() {
    this.prefService.isChannelEditCancelledD.next({
      channel: 'Email',
      status: 'true'
    });
    this.editEmail = false;
    this.cancelEdit.emit('EMAIL');
    const profile = JSON.parse(sessionStorage.getItem('memProfile'));
    this.profileEmailEditForm.patchValue(profile);
  }
}

