export const PHONE_FORM_MESSAGES = {
  required: 'You must enter a valid mobile number.',
  invalidNumber: 'You must enter a valid mobile number.',
  invalidMobile: 'You must enter a valid mobile number.'
};

export const NON_DIGIT_REGEX = /\D/g;

export const DEFAULT_PHONE_NUM = '0000000000';
