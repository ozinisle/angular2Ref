import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedModule } from '../../shared/shared.module';
import { ProfilePhoneComponent } from './profile-phone.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    TextMaskModule
  ],
  declarations: [ProfilePhoneComponent],
  exports: [ProfilePhoneComponent]
})
export class ProfilePhoneModule { }
