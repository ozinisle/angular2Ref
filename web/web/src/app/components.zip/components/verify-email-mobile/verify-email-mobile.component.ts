import { TitleCasePipe } from '@angular/common';
import { Component, ElementRef, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { pairwise, startWith } from 'rxjs/operators';
import { PROFIE_CONSTANTS } from '../../pages/my-profile/profile-home.constants';
import { RegistrationModuleConstants } from '../../pages/registration/constants/registration-module.constants';
import { FormGroupControlsModel, VerifyAccessCodeInputValidationResultModel } from '../../pages/registration/models/registrationModule.models';
import { AlertType } from '../../shared/alerts/alertType.model';
import { AlertService } from '../../shared/services/alert.service';
import { AuthHttp } from '../../shared/services/auth-http.service';
import { BcbsmaerrorHandlerService } from '../../shared/services/bcbsmaerror-handler.service';
import { PreferencesService } from '../../shared/services/myprofile/preferences.service';
import { ProfileService } from '../../shared/services/myprofile/profile.service';
import { ValidationService } from '../../shared/services/validation.service';
import { AuthService } from '../../shared/shared.module';
import { VerifyEmailMobileService } from './verify-email-mobile.service';

declare let $: any;

@Component({
  selector: 'app-verify-email-mobile',
  templateUrl: './verify-email-mobile.component.html',
  styleUrls: ['./verify-email-mobile.component.scss']
})

export class VerifyEmailMobileComponent implements OnInit, OnDestroy {
  @ViewChild('accesscode1') accesscode1: ElementRef;
  @ViewChild('accesscode2') accesscode2: ElementRef;
  @ViewChild('accesscode3') accesscode3: ElementRef;
  @ViewChild('accesscode4') accesscode4: ElementRef;
  @ViewChild('accesscode5') accesscode5: ElementRef;
  @ViewChild('accesscode6') accesscode6: ElementRef;
  @Input('sendingpage') sendingPageName: string;
  @Output() processCompleteEmitter: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() prefModalVerifyCompleteEmitter = new EventEmitter();
  processComplete = false;
  public verifyaccesscodeFormValidator: VerifyAccessCodeInputValidationResultModel = new VerifyAccessCodeInputValidationResultModel();
  verifyaccesscodeForm: FormGroup;
  errorMsg = false;
  accesscodeMask: any[];
  isFormSubmitted = false;
  location: string;
  maskedVerifiable: string;
  codeMask = { mask: this.validationService.numericMask, guide: false };
  verifyCategory = '';
  private shiftKeyDown = false;
  registeredUserOnly = false;
  alertDisplayContainer;

  destroy$ = new Subject<void>();

  constructor(
    private alertService: AlertService,
    private fb: FormBuilder,
    private router: Router,
    private validationService: ValidationService,
    private profileService: ProfileService,
    private authService: AuthService,
    private titleCase: TitleCasePipe,
    private authHttp: AuthHttp,
    private verifyEmailMobileService: VerifyEmailMobileService,
    private preferenceService: PreferencesService,
    private bcbsmaErrorHandlerService: BcbsmaerrorHandlerService
  ) {

    this.alertService.clearError();
    this.location = this.router.url.split('/')[1];
    this.verifyaccesscodeForm = this.fb.group(
      {
        accesscode1: ['', [Validators.required]],
        accesscode2: ['', [Validators.required]],
        accesscode3: ['', [Validators.required]],
        accesscode4: ['', [Validators.required]],
        accesscode5: ['', [Validators.required]],
        accesscode6: ['', [Validators.required]]
      },
      {
        validator: this.validationService.accessCodeValidator()
      }
    );

    this.verifyaccesscodeForm.valueChanges.pipe(startWith(''), pairwise()).subscribe(accesscodes => {
      const prevVals = accesscodes[0];
      const newVals = accesscodes[1];
      Object.keys(newVals).forEach((key, index) => {
        const newItemValue = (newVals[key] ? newVals[key] : '').toString();
        const oldItemValue = (prevVals[key] ? prevVals[key] : '').toString();
        if (newItemValue !== oldItemValue && newItemValue.length > 1) {
          const digits = newItemValue.split('');
          const currentIndex = index + 1;
          const allEqual = digits.every((val, i, arr) => val === arr[0]);
          if (allEqual) {
            this.verifyaccesscodeForm.get('accesscode' + currentIndex).setValue(digits[0], { emitEvent: false });
          } else {
            digits.forEach(digit => {
              if (digit !== oldItemValue) {
                this.verifyaccesscodeForm.get('accesscode' + currentIndex).setValue(digit, { emitEvent: false });
              }
            });
          }
          this.verifyaccesscodeForm.get('accesscode' + currentIndex).updateValueAndValidity();
        }
      });
    });
    this.verifyEmailMobileService.preferenceModalVerification$.subscribe((response) => {
      if (response && response.date === new Date().toString()) {
        this.verifyCategory = sessionStorage.getItem('maskedVerifyPhone') === 'Y' ? 'Mobile Number' : 'Email';
        this.maskedVerifiable = this.sendingPageName === 'my-pillpack' ? this.maskEmailId(this.profileService.getProfile().emailAddress) :
                                sessionStorage.getItem('maskedVerify');
      }
    });
  }

  ngOnInit() {
    const userRole = this.profileService.getUserRole();
    this.registeredUserOnly = userRole === 'REGISTERED-AND-VERIFIED' ? true : false;
    this.verifyCategory = sessionStorage.getItem('maskedVerifyPhone') === 'Y' ? 'Mobile Number' : 'Email';
    this.sendingPageName = this.sendingPageName ? this.sendingPageName.trim().toString() : null;
    this.alertDisplayContainer = this.sendingPageName && this.sendingPageName === 'preferenceModal' ? 'modalAlert' : '';
    this.maskedVerifiable = this.sendingPageName === 'my-pillpack' ? this.maskEmailId(this.profileService.getProfile().emailAddress) :
                            sessionStorage.getItem('maskedVerify');
  }

  maskEmailId(userId: string): string {
    const sentMailId = JSON.parse(sessionStorage.getItem('sendCodeRes'));
    userId = sentMailId && sentMailId['commChannel'] ? sentMailId['commChannel'] : userId;
    const maskedUserId = userId
      ? userId.replace(/^(.{3})(.*)(@.*)$/, (_, firstCharacter, charToMasked, domain) => {
        return `${firstCharacter}${charToMasked.replace(/./g, '*')}${domain}`;
      })
      : userId;
    return maskedUserId;
  }

  onSubmit() {
    this.isFormSubmitted = true;
    this.alertService.clearError();
    //fix for KLO-595
    const accessCode = [
      this.verifyaccesscodeForm.value.accesscode1, this.verifyaccesscodeForm.value.accesscode2,
      this.verifyaccesscodeForm.value.accesscode3, this.verifyaccesscodeForm.value.accesscode4,
      this.verifyaccesscodeForm.value.accesscode5, this.verifyaccesscodeForm.value.accesscode6
    ].join('');

    const { emailAddress } = JSON.parse(sessionStorage.getItem('memProfile'));
    const { phoneNumber } = JSON.parse(sessionStorage.getItem('memProfile'));
    const isVerifyPhone = sessionStorage.getItem('maskedVerifyPhone') === 'Y';
    const commChannel = isVerifyPhone ? 'MOBILE' : 'EMAIL';
    const commChannelValue = isVerifyPhone ? phoneNumber : emailAddress;
    const verifiedUsers = ['AUTHENTICATED-AND-VERIFIED', 'REGISTERED-AND-VERIFIED'];
    const scopeName = this.authService.authToken ? this.authService.authToken.scopename : '';
    const isVerifyAccessCodeApi = !verifiedUsers.includes(scopeName);
    const verifyAccessCode = verifiedUsers.includes(scopeName) ?
      this.profileService.VerifyCommChlAccCode(accessCode, isVerifyPhone ? '' : commChannelValue, isVerifyPhone ? commChannelValue : '') :
      this.profileService.VerifyAccessCode(accessCode, commChannel, commChannelValue);

    if (this.verifyaccesscodeForm.valid) {
      verifyAccessCode.subscribe((response: any) => {
        if (response.result === '0') {
          const msg = commChannel !== 'MOBILE' ? PROFIE_CONSTANTS.verifiedEmailMsg : PROFIE_CONSTANTS.verifiedPhoneMsg;

          isVerifyAccessCodeApi ? sessionStorage.removeItem('sendCodeRes') :
                                 this.sendNotification(commChannel !== 'MOBILE', commChannel === 'MOBILE', commChannel, commChannelValue);

          if (sessionStorage.getItem('isPendingEmail') === 'true') {
            this.verifyEmailMobileService.verifyEmail(this.alertDisplayContainer === 'modalAlert' ? this.alertDisplayContainer : '');
            this.updateProfileInfo();
            sessionStorage.removeItem('isPendingEmail');
          } else {
            const url = sessionStorage.getItem('communicationPreferencePath') === 'communication-preferences' ?
                        ['myprofile'] : ['myprofile/contact-info'];
            if (this.sendingPageName === 'my-pillpack') {
              this.onPillPackVerificaion(msg);
            } else if (this.sendingPageName === 'preferenceModal') {
              this.prefModalVerifyCompleteEmitter.emit({result: response.result, channel: isVerifyPhone ? 'PHONE' : 'EMAIL'});
            } else if (url[0] === 'myprofile') {
              this.preferenceService.updatePreferenceInfo();
            } else {
              this.onContactInfoVerification(url, msg);
            }
          }
          this.authHttp.hideSpinnerLoading();
        } else {
          this.mapSendAccessErrorCode(response);
          this.authHttp.hideSpinnerLoading();
        }
      });
    }
  }

  private updateProfileInfo() {
    this.resetForm();
    let profile = JSON.parse(sessionStorage.getItem('memProfile'));
    profile = { ...profile, isVerifiedMobile: true };
    sessionStorage.setItem('memProfile', JSON.stringify(profile));
  }

  private onPillPackVerificaion (msg) {
    this.alertService.setAlert(msg, '', AlertType.Success);
    this.processComplete = true;
    this.processCompleteEmitter.emit(true);
  }

  private onContactInfoVerification(url, msg) {
    this.router.navigate(url).then(() => {
      this.alertService.setAlert(msg, '', AlertType.Success);
      sessionStorage.setItem('destination', JSON.stringify('contact-info'));
      this.profileService.initiateUpdateProfile();
      sessionStorage.removeItem('communicationPreferencePath');
    });
  }

  mapSendAccessErrorCode(response) {
    if (response['result'] === '-1') {
      this.alertService.setAlert( PROFIE_CONSTANTS.verifyCodeExpiredMsg, '', AlertType.Failure, 'component', this.alertDisplayContainer);
    } else if (response['result'] === '-2') {
      this.alertService.setAlert(PROFIE_CONSTANTS.verifyCodeCommErrorMsg, '', AlertType.Failure, 'component', this.alertDisplayContainer);
    } else if (response['result'] === '-3') {
      this.alertService.setAlert(PROFIE_CONSTANTS.verifyCodeFeatureNotAvailableMsg, '', AlertType.Failure,
                                 'component', this.alertDisplayContainer);
    } else if (response['result'] === '-4') {
      this.alertService.setAlert(PROFIE_CONSTANTS.verifyCodeDoesNotMach, '', AlertType.Failure, 'component', this.alertDisplayContainer);
    } else {
        this.alertService.setAlert(response['displaymessage'], '', AlertType.Failure, 'component', this.alertDisplayContainer);
    }
    this.resetForm();
    this.validationService.focusFirstError();
  }

  resetForm() {
    this.verifyaccesscodeForm.setValue({
      accesscode1: '', accesscode2: '', accesscode3: '',
      accesscode4: '', accesscode5: '', accesscode6: ''
    });
  }

  sendAccessCode() {
    this.resetForm();
    this.alertService.clearError();
    const { emailAddress } = JSON.parse(sessionStorage.getItem('memProfile'));
    const { phoneNumber } = JSON.parse(sessionStorage.getItem('memProfile'));
    const isVerifyPhone = sessionStorage.getItem('maskedVerifyPhone') === 'Y';
    const commChannel = isVerifyPhone ? 'MOBILE' : 'EMAIL';
    const commChannelValue = isVerifyPhone ? phoneNumber : emailAddress;
    const currScope = this.authService.authToken ? this.authService.authToken.scopename : '';
    if (currScope === 'AUTHENTICATED-AND-VERIFIED' || currScope === 'REGISTERED-AND-VERIFIED') {
      this.sendcommchlaccesscode(isVerifyPhone ? '' : commChannelValue, isVerifyPhone ? commChannelValue : '');
    } else {
      this.sendaccesscode(commChannel, commChannelValue);
    }
  }

  private sendaccesscode(commChannelType, commChannel): void {
    this.profileService.sendaccesscode(commChannelType, commChannel).subscribe(
      res => {
        if (res['result'] === '0' || res['result'] === 0) {
          this.alertService.clearError();
          this.alertService.setAlert(PROFIE_CONSTANTS.verificationCodeResent, '', AlertType.Success,
                                     'component', this.alertDisplayContainer);
        } else {
          if (res['displaymessage']) {
            this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure, 'component', this.alertDisplayContainer);
          }
        }
        this.authHttp.hideSpinnerLoading();
      },
      err => {
        this.authHttp.hideSpinnerLoading();
      }
    );
  }

  private sendcommchlaccesscode(email, mobile): void {
    const isVerifyPhone = sessionStorage.getItem('maskedVerifyPhone') === 'Y';
    this.profileService.sendcommchlaccesscode(email, mobile.replace(/\D/g, '')).subscribe(
      res => {
        if (res['result'] === '0' || res['result'] === 0) {
          this.alertService.clearError();
          const errorMsg = isVerifyPhone ? PROFIE_CONSTANTS.verificationCodeResentPhone : PROFIE_CONSTANTS.verificationCodeResent;
          this.alertService.setAlert(errorMsg, '', AlertType.Success, 'component', this.alertDisplayContainer);
        } else {
          if (res['displaymessage']) {
            this.alertService.setAlert(res['displaymessage'], '', AlertType.Failure, 'component', this.alertDisplayContainer);
          }
        }
      },
      err => {
        console.log('error', err);
      }
    );
  }

  private sendNotification(isEmailEdit: boolean, isMobileEdit: boolean, commChannelType: string, commChannel: string) {
    const myProfileURL = this.getMyProfileUrl();
    const notificationRequest = {
      useridin: this.authService.useridin,
      commChannel: commChannel,
      commChannelType: commChannelType,
      templateKeyword: isEmailEdit ? 'UPDATENOTIFICATION_EMAIL' : 'UPDATENOTIFICATION_MOBILE',
      notificationParms: [
        {
          keyName: 'firstName',
          keyValue:
            this.authService && this.authService.authToken && this.authService.authToken.firstName
              ? this.titleCase.transform(this.authService.authToken.firstName)
              : ''
        },
        {
          keyName: 'myProfileURL',
          keyValue: window.location.origin + myProfileURL
        },
        {
          keyName: 'updatedFields',
          keyValue: isEmailEdit ? ['Email'] : ['Phone Number']
        }
      ]
    };
    this.profileService.sendUpdateNotification(notificationRequest).subscribe(res => { });
  }

  onKeyDown(event) {
    if (event.keyCode === 16) {
      this.shiftKeyDown = true;
    }
    if (this.shiftKeyDown || !this.isValidKeyPressed(event)) {
      return false;
    }
  }

  onKeyUp(event, previousElement, nextElement, materialForm) {
    if (this.shiftKeyDown) {
      if (event.keyCode === 16) {
        this.shiftKeyDown = false;
      }
      return false;
    }

    if (event && event.target['value'] === '' && !this.isValidKeyPressed(event)) {
      return false;
    }
    this.getMatFormClass(materialForm);
    if ((event.key === 'Backspace' || event.which === 37 || event.key === 'ArrowLeft') && previousElement) {
      previousElement.focus();
    }
    if (
      (event.key === 'ArrowRight' ||
        event.which === 39 ||
        (event.keyCode >= 48 && event.keyCode <= 57) ||
        (event.keyCode >= 96 && event.keyCode <= 105)) &&
      nextElement
    ) {
      setTimeout(() => nextElement.focus(), 100);
    }
  }

  isValidKeyPressed(event) {
    const key = event.key;
    return (
      key === 'Backspace' ||
      key === 'Control' ||
      key === 'ArrowLeft' ||
      key === 'ArrowRight' ||
      (event.keyCode >= 48 && event.keyCode <= 57) ||
      (event.keyCode >= 96 && event.keyCode <= 105) || event.keyCode == 86
    );
  }


  splitAndPlacePastedValues(event, materialForm): boolean {
    event.preventDefault();
    let pastedData = '';
    if (event.clipboardData) {
      pastedData = event.clipboardData.getData('text/plain');
    } else if (window['clipboardData']) {
      pastedData = window['clipboardData'].getData('Text');
    }

    pastedData = pastedData.replace(/\D/g, '');

    let pastedCharArr = pastedData.split('');

    if (pastedCharArr.length > 6) {
      pastedCharArr = pastedCharArr.splice(0, 6);
    }

    const accessCodeFields: NodeListOf<Element> = document.querySelectorAll('input.access-code');
    Object.keys(materialForm.controls).forEach((controlName, controlIndex) => {
      const pastedNumber: string = pastedCharArr[controlIndex];
      if (pastedNumber) {
        const formInputControl: FormControl = materialForm.get(controlName);
        // focus method does not work as such in ie11. hence requires a timeout block as fix/workaround for the same
        setTimeout(() => {
          (accessCodeFields[controlIndex] as HTMLInputElement).focus();
          formInputControl.setValue(pastedNumber);
        }, 10);
      } else {
        return false;
      }
    });

    this.getMatFormClass(materialForm);
    return true;
  }

  public getMatFormClass(materialForm: FormGroup): VerifyAccessCodeInputValidationResultModel {
      this.verifyaccesscodeFormValidator = new VerifyAccessCodeInputValidationResultModel();

      if (!materialForm) {
        throw new Error(RegistrationModuleConstants.errorMessages.invalidMaterialFormError);
      }

      const controls: FormGroupControlsModel = materialForm.controls;
      const _controls = RegistrationModuleConstants.controls;
      const accessCode_1_Control = controls[_controls.accessCode1];
      const accessCode_2_Control = controls[_controls.accessCode2];
      const accessCode_3_Control = controls[_controls.accessCode3];
      const accessCode_4_Control = controls[_controls.accessCode4];
      const accessCode_5_Control = controls[_controls.accessCode5];
      const accessCode_6_Control = controls[_controls.accessCode6];

      if (
        !(
          accessCode_1_Control &&
          accessCode_2_Control &&
          accessCode_3_Control &&
          accessCode_4_Control &&
          accessCode_5_Control &&
          accessCode_6_Control
        )
      ) {
        return this.verifyaccesscodeFormValidator;
      }

      const controlErrors: ValidationErrors =
        accessCode_1_Control.errors ||
        accessCode_2_Control.errors ||
        accessCode_3_Control.errors ||
        accessCode_4_Control.errors ||
        accessCode_5_Control.errors ||
        accessCode_6_Control.errors;

      const allTouched: boolean =
        accessCode_1_Control.touched &&
        accessCode_2_Control.touched &&
        accessCode_3_Control.touched &&
        accessCode_4_Control.touched &&
        accessCode_5_Control.touched &&
        accessCode_6_Control.touched;

      const errorFlag: boolean = controlErrors ? true : !allTouched;

      const hasRequiredErrorFlags: boolean =
        (accessCode_1_Control.errors && accessCode_1_Control.errors.required) ||
        (accessCode_2_Control.errors && accessCode_2_Control.errors.required) ||
        (accessCode_3_Control.errors && accessCode_3_Control.errors.required) ||
        (accessCode_4_Control.errors && accessCode_4_Control.errors.required) ||
        (accessCode_5_Control.errors && accessCode_5_Control.errors.required) ||
        (accessCode_6_Control.errors && accessCode_6_Control.errors.required);

      this.verifyaccesscodeFormValidator.isError = errorFlag;
      this.verifyaccesscodeFormValidator.hasErrors = hasRequiredErrorFlags;
    }
    
  getMyProfileUrl() {
    let path;
    const url = sessionStorage.getItem('communicationPreferencePath');
    if (this.sendingPageName === 'my-pillpack') {
      path = '/my-pillpack';
    } else if (this.sendingPageName === 'preferenceModal') {
      path = '/myprofile/communication-preferences';
    } else if (url === 'communication-preferences') {
      path = '/myprofile/communication-preferences';
    } else {
      path = '/myprofile/contact-info';
    }
    return path;
  }

  ngOnDestroy () {
    this.alertService.clearError();
    this.destroy$.next();
    this.destroy$.complete();
  }
}
