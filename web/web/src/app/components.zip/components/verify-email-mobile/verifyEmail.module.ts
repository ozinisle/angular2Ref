import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material';
import { MatInputModule } from '@angular/material/input';
import { TextMaskModule } from 'angular2-text-mask';
import { SharedModule } from '../../shared/shared.module';
import { VerifyEmailMobileComponent } from './verify-email-mobile.component';
import { VerifyEmailMobileService } from './verify-email-mobile.service';

@NgModule({
  imports: [CommonModule, HttpClientModule, FormsModule, ReactiveFormsModule, TextMaskModule, MatInputModule, MatFormFieldModule, SharedModule],
  providers: [VerifyEmailMobileService],
  declarations: [VerifyEmailMobileComponent],
  exports: [VerifyEmailMobileComponent]
})
export class verifyEmail {}
