/**
 * - Do not use objects, only use string, number, boolean
 * - Only put environement related information that changes based on the environement (QA, UAT, PROD..)
 * - Do not put constants value specific to your service or components
 * - Put only the different part (leave the common part as a constant), eg:
 *    https://bcbsma-test.apigee.net, not https://bcbsma-test.apigee.net/member/web/v1/
 * - Use camelCase
 */
export interface EnvironmentConfig {
  stripeKeyString: string;
  dynamicTagLink: string;
  screenNavigationSLA: number;
  tokenbaseurl: string;
  tokensEndPoint: string;
  serviceUrl: string;
  privacyUrl: string;
  drupalTestUrl: string;
  drupalHomeUrl: string;
  contactus: string;
  educationCenter: string;
  drupalsecureinquiry: string;
  impersonation: boolean;
  liveChatServerUrl: string;
  liveChatEntryPoint: number;
  enableLiveChat: boolean;
  LogRocketAppID: string;
  loadLogRocket: boolean;
  uitxnid: boolean;
  serviceUrlV2: string;
  serviceUrlV3: string;
  enableconsolelog: boolean;
  leafLetUrl: string;
  ssoInboundAuthenticationUrl: string;
  ssoInboundAuthUrl: string;
  ssoInboundAuthorize?: string;
  loadadrum: boolean;
  eyeMedBaseUrl: string;
  stripeLink: string;
  LogRocketEndPoint: string;
  enrollServiceUrl: string;
  rewardsServiceUrl: string;
  displayVirtualVisit: boolean;
  enableFitnessBenefits: boolean;
  enableTaxForms: boolean;
  enableSsoInbound: boolean;
  enableL2L: boolean;
  enableFinancialWidget: boolean;
  featureVirginPulseSsoEnabled: boolean;
  showHeqTransactions: boolean;
  enableAngularProdMode: boolean;
  blueFitPlanRegExp: string;
  drupalRecommendedDataUrl: string;
  enableNewPersonalizedHub: boolean;
  forceBlueFitPlan: boolean;
  enableOTCLink:boolean;
}

export type PartialEnvironmentConfig = Partial<EnvironmentConfig>;

// Default values
export const environmentDefault: EnvironmentConfig = {
  uitxnid: true,
  enableconsolelog: true,
  dynamicTagLink: '//assets.adobedtm.com/launch-ENfd28d85532164d63933fc8f696980fe5-staging.min.js',
  screenNavigationSLA: 3000,
  tokenbaseurl: 'https://mobilememberstage.bluecrossma.com',
  tokensEndPoint: '/memwebapi1_test/mobilekeyservice/v1/gettokens',
  serviceUrl: 'https://bcbsma-test.apigee.net/member/web/v1/',
  serviceUrlV2: 'https://bcbsma-test.apigee.net/member/web/v2/',
  serviceUrlV3: 'https://bcbsma-test.apigee.net/member/web/v3/',
  privacyUrl: 'https://myblueapi.bluecrossma.com/page/',
  drupalTestUrl: 'https://games.bluecrossma.com',
  drupalHomeUrl: 'https://myblue.bluecrossma.com/',
  contactus: 'https://myblue.bluecrossma.com/contact-us',
  educationCenter: 'https://myblue.bluecrossma.com/health-plan/plan-education-center',
  drupalsecureinquiry: 'http://20181010myblue.bluecrossma.acsitefactory.com/inquiry',
  leafLetUrl: 'https://api.mapbox.com/',
  impersonation: false,
  ssoInboundAuthenticationUrl: 'https://bcbsma-test.apigee.net/web/sso/inbound/authentication/',
  ssoInboundAuthUrl: 'https://bcbsma-test.apigee.net/mock/sso/inbound/internalidp',
  ssoInboundAuthorize: 'https://bcbsma-test.apigee.net/web/sso/inbound/',
  loadadrum: false,
  stripeLink: 'https://js.stripe.com/v3/',
  stripeKeyString: 'pk_test_gC5yvDgq6qs1LQ1xiYN5im0B',
  LogRocketAppID: 'bcbsma/internal-network-dev',
  LogRocketEndPoint: 'https://bcbsma-test.apigee.net/member/web/v1/logrocket',
  liveChatServerUrl: 'https://staging.ciscochat.bluecrossma.com/system',
  liveChatEntryPoint: 1021,
  enableLiveChat: true,
  loadLogRocket: false,
  eyeMedBaseUrl: 'https://memberuat.eyemedvisioncare.com',
  enrollServiceUrl: 'https://bcbsma-prod.apigee.net/enroll/web/v1/',
  rewardsServiceUrl: 'https://bcbsma-test.apigee.net/digital/rewards/v1/my-rewards',
  displayVirtualVisit: true,
  enableFitnessBenefits: true,
  enableTaxForms: true,
  enableSsoInbound: true,
  enableL2L: true,
  enableFinancialWidget: false,
  featureVirginPulseSsoEnabled: false,
  showHeqTransactions: false,
  enableAngularProdMode: true,
  blueFitPlanRegExp: 'BLUEFIT.*',
  drupalRecommendedDataUrl: 'https://videos.bluecrossma.com/nba/tiles',
  enableNewPersonalizedHub: false,
  forceBlueFitPlan: false,
  enableOTCLink: true
};
