import { PlanConfig } from './plan-config-service';

export const PLAN_CONFIG: PlanConfig[] = [
  {
    uacc: '0315',
    coveragePackageCode: '176664',
    isDigitalFirstCDH: true,
    additionalBenefits: [
      {
        benefitTitle: 'Accident and Critical Illness Coverage',
        summaryContent: '...',
        detailedContent: '...'
      },
      {
        benefitTitle: 'SonicCare',
        summaryContent: '...',
        detailedContent: '...'
      },
      {
        benefitTitle: 'Toothpic',
        summaryContent: '...',
        detailedContent: '...'
      }
    ]
  },
  {
    coveragePackageCode: '176665',
    uacc: '0316',
    isDigitalFirstCDH: true,
    additionalBenefits: [
      {
        benefitTitle: 'Accident and Critical Illness Coverage',
        summaryContent: '...',
        detailedContent: '...'
      },
      {
        benefitTitle: 'SonicCare',
        summaryContent: '...',
        detailedContent: '...'
      },
      {
        benefitTitle: 'Toothpic',
        summaryContent: '...',
        detailedContent: '...'
      }
    ]
  },
  {
    coveragePackageCode: '',
    uacc: '0084',
    isDigitalFirstCDH: true,
    isWelcomeKitEnabled: true,
    hasCvsLink: true,
    additionalBenefits: []
  },
  {
    coveragePackageCode: '',
    uacc: '0086',
    isDigitalFirstCDH: true,
    isWelcomeKitEnabled: true,
    hasCvsLink: true,
    additionalBenefits: []
  },
  {
    coveragePackageCode: '',
    uacc: '0261',
    isWelcomeKitEnabled: true,
    additionalBenefits: []
  },
  {
    coveragePackageCode: '',
    uacc: '0249',
    isWelcomeKitEnabled: true,
    additionalBenefits: []
  }
];
