import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { PLAN_CONFIG } from './plan-config';

export interface AddtionalBenefits {
  benefitTitle: string;
  summaryContent: string;
  detailedContent: string;
}

export interface PlanConfig {
  uacc: string;
  coveragePackageCode: string;
  isDigitalFirstCDH?: boolean;
  isWelcomeKitEnabled?: boolean;
  hasCvsLink?: boolean; //TODO Jason: find a better name
  additionalBenefits?: AddtionalBenefits[];
}

export class PlanConfigService {
  public constructor() {}

  public getCurrentPlanConfig$(): Observable<PlanConfig> {
    let uacc = '0000';
    if (sessionStorage.getItem('authToken')) {
      const authTokenDetailsJson = JSON.parse(sessionStorage.getItem('authToken'));
      uacc = authTokenDetailsJson.uacc;
    }
    return this.getPlanConfigByUacc$(uacc); //this.authService.authToken.uacc
  }

  public getPlanConfigByUacc$(uacc: string): Observable<PlanConfig> {
    let foundPlanConfig = PLAN_CONFIG.filter(obj => obj.uacc === uacc).pop();
    if (environment.forceBlueFitPlan) {
      foundPlanConfig = PLAN_CONFIG.filter(obj => obj.uacc === '0315').pop();
    }
    if (foundPlanConfig == null) {
      foundPlanConfig = {
        uacc: uacc,
        coveragePackageCode: null
      };
    }
    return Observable.of(foundPlanConfig);
  }

  public getPlanConfigByCoveragePackageCode$(cpc: string): Observable<PlanConfig> {
    let foundPlanConfig = PLAN_CONFIG.filter(obj => obj.coveragePackageCode === cpc).pop();
    if (environment.forceBlueFitPlan) {
      foundPlanConfig = PLAN_CONFIG.filter(obj => obj.uacc === '0315').pop();
    }
    if (foundPlanConfig == null) {
      foundPlanConfig = {
        uacc: null,
        coveragePackageCode: cpc
      };
    }
    return Observable.of(foundPlanConfig);
  }
}
