// Protractor configuration file, see link for more information
// https://github.com/angular/protractor/blob/master/lib/config.ts

/** @typedef { import('./e2e/testing/models').ProtractorConfig } ProtractorConfig */

const HtmlReporter = require('protractor-beautiful-reporter');
const { SpecReporter } = require('jasmine-spec-reporter');

/** @type Partial<ProtractorConfig> */
let localConfig = {};
try {
  localConfig = require('./protractor.conf.local');
} catch (e) {
  throw new Error('Please create protractor.conf.local.js before running E2E tests.');
}

/** @type ProtractorConfig */
const defaultConfig = {
  allScriptsTimeout: 11000,
  specs: ['./e2e/**/*.e2e-spec.ts'],
  capabilities: {
    browserName: 'chrome'
  },
  directConnect: true,
  baseUrl: 'http://localhost:4200/',
  framework: 'jasmine',
  jasmineNodeOpts: {
    showColors: true,
    defaultTimeoutInterval: 30000,
    print: function() {}
  },
  onPrepare() {
    require('ts-node').register({
      project: 'e2e/tsconfig.e2e.json'
    });
    jasmine.getEnv().addReporter(new SpecReporter({ spec: { displayStacktrace: true } }));
    jasmine.getEnv().addReporter(
      new HtmlReporter({
        baseDirectory: 'e2e/reports',
        screenshotsSubfolder: 'images',
        jsonsSubfolder: 'json',
        preserveDirectory: false,
        takeScreenShotsOnlyForFailedSpecs: true
      }).getJasmine2Reporter()
    );
  },
  params: {
    /*
     * For security, do not update this file with account credentials.
     * Please create/use the file protractor.conf.local.js,
     * which is excluded from version control.
     */
    accounts: {
      generic: {
        username: '',
        password: ''
      }
    }
  }
};

const mergedConfig = Object.assign(defaultConfig, localConfig);
exports.config = mergedConfig;
