/** @typedef { import('./e2e/testing/models').ProtractorConfig } ProtractorConfig */

/**
 * Protractor config overrides.
 *
 * @type Partial<ProtractorConfig>
 */
module.exports = {
  params: {
    accounts: {
      generic: {
        username: 'azurediamond',
        password: 'hunter2'
      }
    }
  }
};
