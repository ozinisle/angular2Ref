import { browser, by, element, ElementFinder, protractor } from 'protractor';
import { LoginPage } from './pages/login/login.po';
import { BasePageObject } from './testing/page-object';

const EC = protractor.ExpectedConditions;

enum Child {
  ALERT = 'alert'
}

export class AppPage extends BasePageObject<Child> {
  public Child = Child;
  public loginPage = new LoginPage();

  constructor() {
    super(element(by.tagName('app-root')));
  }

  public async clearSession(): Promise<void> {
    try {
      await browser.executeScript('window.sessionStorage.clear()');
      await browser.executeScript('window.localStorage.clear()');
    } catch (e) {
      /* Expected to fail when attempting from the startup "data:" url */
    }
  }

  public async currentUrl(): Promise<string> {
    return browser.getCurrentUrl();
  }

  public async tabCount(): Promise<number> {
    const handles = await browser.getAllWindowHandles();
    return handles.length;
  }

  public async urlIs(url: string, timeout?: number): Promise<boolean> {
    try {
      await browser.wait(EC.urlIs(url), timeout);
      return true;
    } catch (e) {
      return false;
    }
  }

  public async forceSignOut(): Promise<void> {
    await this.clearSession();
    return await this.loginPage.navigateTo();
  }

  /**
   * Simulates pressing the "Back" button in a browser.
   *
   * @param waitForAngular
   *   Set to ```false``` if the previous page in the browser history is not
   *   part of the Angular application.
   */
  public async navigateBack(waitForAngular = true): Promise<void> {
    await browser.navigate().back();
    if (waitForAngular) {
      await browser.waitForAngular();
    }
  }

  /**
   * Simulates pressing the "Forward" button in a browser.
   * @param waitForAngular
   *   Set to ```false``` if the next page in the browser history is not
   *   part of the Angular application.
   */
  public async navigateForward(waitForAngular = true): Promise<void> {
    await browser.navigate().forward();
    if (waitForAngular) {
      await browser.waitForAngular();
    }
  }

  public async refresh(): Promise<void> {
    await browser.navigate().refresh();
  }

  public async signIn(username: string, password: string) {
    await this.forceSignOut();
    await this.loginPage.signIn(username, password);
  }

  protected resolveChild(child: Child): ElementFinder {
    switch (child) {
      case Child.ALERT:
        return this.container
          .all(by.css('app-alerts .alert'))
          .filter(e => e.isDisplayed())
          .first();
      default:
        throw new Error('Child not defined!');
    }
  }
}
