import { AppPage } from '../../../app.po';
import { LanguageAssistanceSection } from './language-assistance-section.po';

export const languageAssistanceSectionSuite = () => {
  describe('Language assistance section', () => {
    const app = new AppPage();
    const page = new LanguageAssistanceSection();

    const linkSpec = (name: string, linkId: any, language: any) =>
      describe(name, () => {
        it('should be visible', async () => {
          expect(await page.isChildVisible(linkId)).toEqual(true);
        });

        it('should translate the message to the appropriate language when clicked', async () => {
          await page.clickChild(linkId);
          expect(await page.messageIs(language)).toEqual(true);
        });
      });

    beforeAll(async () => {
      await app.forceSignOut();
    });

    it('should be visible', async () => {
      expect(await page.isVisible()).toEqual(true);
    });

    it('should default to a message in English', async () => {
      expect(await page.messageIs(page.SupportedLanguage.ENGLISH)).toEqual(true);
    });

    linkSpec('Spanish Link', page.Child.SPANISH_LINK, page.SupportedLanguage.SPANISH);
    linkSpec('English Link', page.Child.ENGLISH_LINK, page.SupportedLanguage.ENGLISH);
    linkSpec('Portugese Link', page.Child.PORTUGESE_LINK, page.SupportedLanguage.PORTUGESE);
    linkSpec('French Link', page.Child.FRENCH_LINK, page.SupportedLanguage.FRENCH);
    linkSpec('Chinese Link', page.Child.CHINESE_LINK, page.SupportedLanguage.CHINESE);
    linkSpec('Haitian Link', page.Child.HAITIAN_CREOLE_LINK, page.SupportedLanguage.HAITIAN_CREOLE);
    linkSpec('Vietnamese Link', page.Child.VIETNAMESE_LINK, page.SupportedLanguage.VIETNAMESE);
    linkSpec('Russian Link', page.Child.RUSSIAN_LINK, page.SupportedLanguage.RUSSIAN);
    linkSpec('Cambodian Link', page.Child.CAMBODIAN_LINK, page.SupportedLanguage.CAMBODIAN);
    linkSpec('Italian Link', page.Child.ITALIAN_LINK, page.SupportedLanguage.ITALIAN);
    linkSpec('Korean Link', page.Child.KOREAN_LINK, page.SupportedLanguage.KOREAN);
    linkSpec('Greek Link', page.Child.GREEK_LINK, page.SupportedLanguage.GREEK);
    linkSpec('Polish Link', page.Child.POLISH_LINK, page.SupportedLanguage.POLISH);
    linkSpec('Hindi Link', page.Child.HINDI_LINK, page.SupportedLanguage.HINDI);
    linkSpec('Gujarati Link', page.Child.GUJARATI_LINK, page.SupportedLanguage.GUJARATI);
    linkSpec('Tagalog Link', page.Child.TAGALOG_LINK, page.SupportedLanguage.TAGALOG);
    linkSpec('Japanese Link', page.Child.JAPANESE_LINK, page.SupportedLanguage.JAPANESE);
    linkSpec('German Link', page.Child.GERMAN_LINK, page.SupportedLanguage.GERMAN);
    linkSpec('Lao Link', page.Child.LAO_LINK, page.SupportedLanguage.LAO);
    linkSpec('Navajo Link', page.Child.NAVAJO_LINK, page.SupportedLanguage.NAVAJO);
  });
};
