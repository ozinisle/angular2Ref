import { AppPage } from '../../../app.po';
import { externalLinkClickSuite } from '../../../testing/suites';
import { SocialMediaSection } from './social-media-section.po';

const app = new AppPage();
const page = new SocialMediaSection();

const socialMediaLinkSpec = (name: string, linkChild: SocialMediaSection['Child'][keyof SocialMediaSection['Child']], urlPart: string) => {
  describe(`${name} link`, () => {
    it('should be visible', async () => {
      expect(await page.isChildVisible(linkChild)).toEqual(true);
    });

    externalLinkClickSuite(
      `should open ${name} in a new tab when clicked`,
      () => page.clickChild(linkChild),
      async tab => {
        const isTargetPage = (await tab.currentUrl()).includes(urlPart);
        if (isTargetPage) {
          return true;
        }

        /* Workaround for BCBSMA VPN security policy */
        return (await tab.containsText('Page Blocked')) && (await tab.containsText(urlPart));
      }
    );
  });
};

export const socialMediaSectionSuite = () => {
  describe('Social media section', () => {
    beforeAll(async () => {
      await app.forceSignOut();
      await page.scrollTo();
    });

    socialMediaLinkSpec('Faceook', page.Child.FACEBOOK_LINK, 'facebook.com');
    socialMediaLinkSpec('Twitter', page.Child.TWITTER_LINK, 'twitter.com');
    socialMediaLinkSpec('LinkedIn', page.Child.LINKEDIN_LINK, 'linkedin.com');
    socialMediaLinkSpec('YouTube', page.Child.YOUTUBE_LINK, 'youtube.com');
  });
};
