import { by, element, ElementFinder } from 'protractor';
import { BasePageObject } from '../../../testing/page-object';

enum Child {}

export class Footer extends BasePageObject<Child> {
  public Child = Child;

  constructor() {
    super(element.all(by.css('app-footer > div')).first());
  }

  protected resolveChild(child: Child): ElementFinder {
    throw new Error('Child not defined.');
  }
}
