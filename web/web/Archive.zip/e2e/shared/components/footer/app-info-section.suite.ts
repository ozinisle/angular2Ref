import { AppPage } from '../../../app.po';
import { externalLinkClickSuite } from '../../../testing/suites';
import { AppInfoSection } from './app-info-section.po';

export const appInfoSectionSuite = () => {
  describe('App info section', () => {
    const app = new AppPage();
    const page = new AppInfoSection();

    beforeAll(async () => {
      await app.forceSignOut();
    });

    it('should be visible', async () => {
      expect(await page.isVisible()).toEqual(true);
    });

    describe('App Store link', () => {
      it('should be visible', async () => {
        expect(await page.isChildVisible(page.Child.APP_STORE_LINK)).toEqual(true);
      });

      externalLinkClickSuite(
        'should open App Store in a new tab when clicked',
        () => page.clickChild(page.Child.APP_STORE_LINK),
        async tab => (await tab.currentUrl()).includes('apps.apple.com')
      );
    });

    describe('Google Play link', () => {
      it('should be visible', async () => {
        expect(await page.isChildVisible(page.Child.GOOGLE_PLAY_LINK)).toEqual(true);
      });

      externalLinkClickSuite(
        'should open Google Play in a new tab when clicked',
        () => page.clickChild(page.Child.GOOGLE_PLAY_LINK),
        async tab => (await tab.currentUrl()).includes('play.google.com')
      );
    });
  });
};
