import { by, element, ElementFinder } from 'protractor';
import { NavigablePageObject } from '../../../testing/page-object';

enum Child {}

export class ForgotUsernamePage extends NavigablePageObject<Child> {
  public Child = Child;

  constructor() {
    super('/account/forgotusername', element.all(by.css('app-forgot-username > div')).first());
  }

  protected resolveChild(child: Child): ElementFinder {
    throw new Error('Method not implemented.');
  }
}
