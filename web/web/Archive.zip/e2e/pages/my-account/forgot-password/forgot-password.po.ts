import { by, element, ElementFinder } from 'protractor';
import { NavigablePageObject } from '../../../testing/page-object';

enum Child {}

export class ForgotPasswordPage extends NavigablePageObject<Child> {
  public Child = Child;

  constructor() {
    super('/account/forgotPassword', element.all(by.css('app-forgot-password > div')).first());
  }

  protected resolveChild(child: Child): ElementFinder {
    throw new Error('Method not implemented.');
  }
}
