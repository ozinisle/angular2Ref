import { by, element, ElementFinder } from 'protractor';
import { BasePageObject } from '../../testing/page-object';

enum Child {}

export class OtherPartySiteDialog extends BasePageObject<Child> {
  public Child = Child;

  constructor() {
    super(element(by.css(`[data-qa="change-me"]`)));
  }

  protected resolveChild(child: Child): ElementFinder {
    throw new Error('Method not implemented.');
  }
}
