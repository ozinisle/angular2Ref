import { browser } from 'protractor';
import { AppPage } from '../../app.po';
import { BrowserParams } from '../../testing/models';
import { AuthenticatedUserPage } from '../landing/authenticated-user/authenticated-user.po';
import { ForgotPasswordPage } from '../my-account/forgot-password/forgot-password.po';
import { ForgotUsernamePage } from '../my-account/forgot-username/forgot-username.po';
import { RegistrationPage } from '../registration/registration.po';
import { LoginPage } from './login.po';

describe('Login page', () => {
  const app = new AppPage();
  const page = new LoginPage();
  const authenticatedUserPage = new AuthenticatedUserPage();
  const registrationPage = new RegistrationPage();
  const forgotUsernamePage = new ForgotUsernamePage();
  const forgotPasswordPage = new ForgotPasswordPage();

  const browserParams: BrowserParams = browser.params;

  it('should be navigable', async () => {
    await page.navigateTo();
    expect(await page.isVisible()).toEqual(true);
  });

  describe('Username field', () => {
    it('should be visible', async () => {
      expect(await page.isChildVisible(page.Child.USERNAME_INPUT)).toEqual(true);
    });
  });

  describe('Password field', () => {
    it('should be visible', async () => {
      expect(await page.isChildVisible(page.Child.PASSWORD_INPUT)).toEqual(true);
    });

    it('should hide password text by default', async () => {
      expect(await page.passwordIsHidden()).toEqual(true);
    });
  });

  describe('Show password button', () => {
    it('should be visible', async () => {
      expect(await page.isChildVisible(page.Child.PASSWORD_TOGGLE_BUTTON)).toEqual(true);
    });

    it('should toggle whether password text is hidden when clicked', async () => {
      const originalState = await page.passwordIsHidden();
      await page.clickChild(page.Child.PASSWORD_TOGGLE_BUTTON);
      expect(await page.passwordIsHidden()).toEqual(!originalState);
      await page.clickChild(page.Child.PASSWORD_TOGGLE_BUTTON);
      expect(await page.passwordIsHidden()).toEqual(originalState);
    });
  });

  describe('Forgot username link', () => {
    it('should be visible', async () => {
      expect(await page.isChildVisible(page.Child.FORGOT_USERNAME_LINK)).toEqual(true);
    });

    it('should navigate to the Forgot Username page', async () => {
      await page.clickChild(page.Child.FORGOT_USERNAME_LINK);
      expect(await forgotUsernamePage.isVisible()).toBe(true);
    });
  });

  describe('Forgot password link', () => {
    it('should be visible', async () => {
      await page.navigateTo();
      expect(await page.isChildVisible(page.Child.FORGOT_PASSWORD_LINK)).toEqual(true);
    });

    it('should navigate to the Forgot Password page', async () => {
      await page.clickChild(page.Child.FORGOT_PASSWORD_LINK);
      expect(await forgotPasswordPage.isVisible()).toBe(true);
    });
  });

  describe('Help page link', () => {
    it('should be visible', async () => {
      await page.navigateTo();
      expect(await page.isChildVisible(page.Child.HELP_LINK)).toEqual(true);
    });

    it('should navigate to the help page', async () => {
      await page.clickChild(page.Child.HELP_LINK);
      expect(app.urlIs('https://myblue.bluecrossma.com/newtoblue')).toEqual(true);
      await page.navigateTo(); /* Protractor wants to detect Angular upon test completion */
    });
  });

  describe('Registration page link', () => {
    it('should be visible upon arriving at the page with a blank session', async () => {
      await app.clearSession();
      await page.navigateTo();
      expect(await page.isChildVisible(page.Child.REGISTER_LINK)).toEqual(true);
    });

    it('should navigate to the registration page', async () => {
      await page.clickChild(page.Child.REGISTER_LINK);
      expect(await registrationPage.isVisible()).toBe(true);
    });
  });

  describe('Remember me checkbox', () => {
    it('should be visible upon arriving at the page with a blank session', async () => {
      await app.clearSession();
      await page.navigateTo();
      expect(await page.isChildVisible(page.Child.REMEMBER_ME_CHECKBOX)).toBe(true);
    });

    it('should be checked by default', async () => {
      expect(await page.rememberMeIsChecked()).toBe(true);
    });

    it('should toggle state when clicked', async () => {
      await page.clickChild(page.Child.REMEMBER_ME_CHECKBOX);
      expect(await page.rememberMeIsChecked()).toBe(false);
      await page.clickChild(page.Child.REMEMBER_ME_CHECKBOX);
      expect(await page.rememberMeIsChecked()).toBe(true);
    });
  });

  it('should display an error when entering invalid credentials', async () => {
    await app.forceSignOut();
    await page.signIn('invalid-username', 'invalid-password');
    expect(await app.isChildVisible(app.Child.ALERT)).toEqual(true);
    expect(await app.childContainsText(app.Child.ALERT, 'Incorrect username or password. Please try again.'));
  });

  it('should proceed to the authenticated user landing page when entering valid credentials', async () => {
    await app.forceSignOut();
    const account = browserParams.accounts.generic;
    await page.signIn(account.username, account.password);
    expect(await authenticatedUserPage.isPresent()).toEqual(true);
  });
});
