export * from './element-has-class.function';
export * from './is-visible.function';
