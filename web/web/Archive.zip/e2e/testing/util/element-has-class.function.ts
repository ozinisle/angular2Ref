import { ElementFinder } from 'protractor';

export async function elementHasClass(element: ElementFinder, className: string): Promise<boolean> {
  const classNamesRaw = await element.getAttribute('className');
  const classNames = classNamesRaw.split(' ');
  return classNames.indexOf(className) > -1;
}
