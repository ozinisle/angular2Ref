import { Config } from 'protractor';
import { BrowserParams } from './browser-params.model';

export interface ProtractorConfig extends Config {
  params: BrowserParams;
}
