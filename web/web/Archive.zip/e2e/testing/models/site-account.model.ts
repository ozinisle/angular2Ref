export interface SiteAccount {
  username: string;
  password: string;
}
