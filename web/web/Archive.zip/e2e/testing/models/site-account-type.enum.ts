export enum SiteAccountType {
  /**
   * xxx
   */
  GENERIC = 'generic'
}
