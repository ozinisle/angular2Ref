import { browser } from 'protractor';
import { AppPage } from '../../app.po';
import { BrowserTab } from '../page-object/browser-tab.po';

type ClickAction = () => Promise<void>;
type ValidatorCallback = (tab: BrowserTab) => Promise<boolean> | boolean;

/**
 * A reusable suite for testing any link that opens an external page
 * in a new tab when clicked.
 *
 * @param expectation Textual description of what this spec is checking
 * @param clickAction Asynchronous callback that performs the actual click
 * @param validatorCallback Callback to validate the new tab
 */
export const externalLinkClickSuite = (expectation: string, clickAction: ClickAction, validatorCallback: ValidatorCallback): void => {
  const app = new AppPage();
  it(expectation, async () => {
    const previousWaitForAngular = await browser.waitForAngular();
    await browser.waitForAngularEnabled(false);
    const tabCount = await app.tabCount();
    await clickAction();
    const newTabCount = await app.tabCount();
    expect(newTabCount).toBe(tabCount + 1);
    const firstTab = await BrowserTab.fromFirstTab();
    const newTab = await BrowserTab.fromLastTab();
    const isValid = await browser.wait(() => validatorCallback(newTab));
    expect(isValid).toBe(true);
    await newTab.close();
    await firstTab.switchTo();
    await browser.waitForAngularEnabled(previousWaitForAngular);
  });
};
