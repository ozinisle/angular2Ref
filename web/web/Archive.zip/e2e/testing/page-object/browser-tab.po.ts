import { browser, by, element, ElementFinder } from 'protractor';
import { BasePageObject } from './base.po';

enum Child {}

export class BrowserTab extends BasePageObject<Child> {
  public Child = Child;

  private handle: string;

  /**
   * Should not be called directly.
   *
   * See static ```fromFirstTab()``` and ```fromLastTab()``` methds
   * for async initialization.
   */
  constructor(handle?: string) {
    super(element(by.tagName('body')));
    if (!handle) {
      throw new Error('Constructor should not be called directly. Use the available static factory methods.');
    }
    this.handle = handle;
  }

  /**
   * BrowserTab factory method.
   * Returns an instance referencing the first tab in the stack.
   */
  public static async fromFirstTab(): Promise<BrowserTab> {
    const handles = await browser.getAllWindowHandles();
    const handle = handles[0];
    return new BrowserTab(handle);
  }

  /**
   * BrowserTab factory method.
   * Returns an instance referencing the last tab in the stack.
   */
  public static async fromLastTab(): Promise<BrowserTab> {
    const handles = await browser.getAllWindowHandles();
    const handle = handles[handles.length - 1];
    return new BrowserTab(handle);
  }

  public async close(): Promise<void> {
    await this.switchTo();
    return await browser.close();
  }

  public async currentUrl(): Promise<string> {
    await this.switchTo();
    return await browser.getCurrentUrl();
  }

  public async isAngular(): Promise<boolean> {
    return (await browser.executeScript('return !!(window.angular || window.ng);')) as boolean;
  }

  public async switchTo(): Promise<void> {
    return await browser.switchTo().window(this.handle);
  }

  protected resolveChild(child: Child): ElementFinder {
    throw new Error('Method not implemented.');
  }
}
