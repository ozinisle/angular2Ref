var replace = require('replace-in-file');
const fs = require('fs')

console.log('[pre.build.version] !!!!!!!!! Setting build and version !!!!!!!!!!!');
console.log(`[pre.build.version] TAG = ${process.env.TAG}`);
console.log(`[pre.build.version] RELEASE = ${process.env.RELEASE}`);
console.log(`[pre.build.version] BUILD_NUMBER = ${process.env.BUILD_NUMBER}`);

// Inject version info
try {

    var fullVersion = process.env.BUILD_NUMBER;
    if (process.env.TAG != null && process.env.TAG != '') {
        fullVersion = process.env.TAG;
    } else if (process.env.RELEASE != null && process.env.RELEASE != '') {
        fullVersion = process.env.RELEASE + "." + process.env.BUILD_NUMBER;
    }
    
    const optionsVersion = {
        files: 'src/environments/environment.ts',
        from: /{BUILD_VERSION}/g,
        to: fullVersion,
        allowEmptyPaths: false,
    };
    replace.sync(optionsVersion);

    const optionsTimestamp = {
        files: 'src/environments/environment.ts',
        from: /{BUILD_TIMESTAMP}/g,
        to: new Date().toISOString().slice(0, 10),
        allowEmptyPaths: false,
    };
    replace.sync(optionsTimestamp);

    console.log('[pre.build.version] Build version set: ' + fullVersion);
} catch (error) {
    console.error('[pre.build.version] Error occurred:', error);
    process.exit(1);
}

