var replace = require('replace-in-file');
const fs = require('fs')

// Get all config from code and generate a JSON file in assets
const config = {};
try {
    const data = fs.readFileSync('./src/app/services/environement/environment.config.ts', 'utf8')
    var reg = new RegExp('environmentDefault.*(\{(.|\n|\r)*\})\;');
    const match = data.match(reg);
    eval("var result = " + match[1]);
    config.DEFAULT = result;
    for (var i of ['DEV', 'QA', 'UAT', 'PERF', 'PROD']) {
        const data = fs.readFileSync('./src/environments/environment.' + i.toLowerCase() + ".ts", 'utf8');
        var reg = new RegExp('environment.*(\{(.|\n|\r)*\})\;');
        const match = data.match(reg);
        eval("var result = " + match[1]);
        config[i] = result;
    }
    const jsonData = JSON.stringify(config);
    const destination = "./src/assets/config.json"
    fs.writeFileSync(destination, jsonData);
    console.log('[pre.build.config] Config extract generated:', destination);
} catch (err) {
    console.error('[pre.build.config] Error occurred:', err);
    process.exit(1);
}

